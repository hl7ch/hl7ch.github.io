# Home - CH IPS (R4) v2.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-ips/ImplementationGuide/ch.fhir.ig.ch-ips | *Version*:2.0.0 |
| Active as of 2025-12-16 | *Computable Name*:CH_IPS |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

An **International Patient Summary (IPS) document** is an electronic health record extract containing essential healthcare information about a subject of care. As specified in EN 17269 and ISO 27269, it is designed for supporting the use case scenario for ‘unplanned, cross border care’, but it is not limited to it. It is intended to be international, i.e., to provide generic solutions for global application beyond a particular region or country.

The primary **purpose** of CH IPS is to:

* Ensure full compatibility and conformance between IPS-UV and CH IPS
* Provide an implementable, testable FHIR specification for the Swiss healthcare context
* Support Swiss-specific requirements through CH Core profiles
* Enable validation against Swiss Electronic Patient Record (EPR) requirements through specialized CH Core EPR profiles

CH IPS provides two complementary document profiles that enable different **validation levels** to support different implementation scenarios:

1. The[CH IPS Document Profile](StructureDefinition-ch-ips-document.md)ensures:
* **IPS-UV Conformance**: Full validation against the [HL7 IPS-UV specification](https://hl7.org/fhir/uv/ips/STU2/), guaranteeing international interoperability. **All documents conforming to CH IPS Document are valid IPS documents.**
* **Swiss Healthcare Context**: Validation against CH Core profiles, supporting Swiss-specific requirements such as: 
* Swiss identifier systems and extensions
* Swiss terminology
* Swiss-specific data elements and business rules
 

1. The[CH IPS Document EPR Profile](StructureDefinition-ch-ips-document-epr.md)builds upon the CH IPS Document profile and additionally validates:
* **Swiss EPR Conformance**: Compliance with all requirements of the Swiss Electronic Patient Record, including: 
* Patient identification
* Healthcare professional identification
* Document confidentiality
 

The **conformance approach** of CH IPS is based on deriving profiles from the respective CH Core profiles, where conformity with the corresponding IPS-UV profiles is ensured through the [imposeProfile extension](https://hl7.org/fhir/extensions/StructureDefinition-structuredefinition-imposeProfile.html). To ensure Swiss EPR conformance, the additional CH IPS Document EPR profile is provided, which also uses the imposeProfile extension to reference the CH Core Document EPR profile, thereby enforcing all EPR-specific requirements. This approach guarantees that CH IPS documents are "proper IPS" documents while supporting both general Swiss healthcare context and specific EPR integration requirements.

The **CH IPS** is an implementable, testable FHIR specification based on the IPS specification as defined by HL7 and ISO. 
 The CH IPS profile set is closely aligned with the [HL7 IPS-UV specification](https://hl7.org/fhir/uv/ips/STU2/) while still supporting localized needs for Switzerland and reducing barriers to early adoption. 
 To be able to guarantee this, the CH IPS profiles are derived from the respective [CH Core profiles](https://fhir.ch/ig/ch-core/6.0.0-ballot/index.html) and conformity with the corresponding IPS profile is ensured with the [imposeProfile extension](https://hl7.org/fhir/extensions/StructureDefinition-structuredefinition-imposeProfile.html).

![](ig-overview.png)

*Fig. 1: Schematic representation of the dependency mechanism of the implementation guides*

When processing **non-Swiss IPS documents**, Swiss systems receiving IPS documents from other countries that do not conform to Swiss-specific requirements should be able to process the core clinical IPS content for immediate care decisions.

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in the [npm package](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) format from [here](package.tgz).

### Principles & Design

CH IPS follows the [General Principles](https://hl7.org/fhir/uv/ips/STU2/General-Principles.html) and [Design Conventions](https://hl7.org/fhir/uv/ips/STU2/Design-Conventions.html) of the International Patient Summary IG. Please check the detailed information there. 
 In the CH IPS IG, only a few key points are highlighted and visualized in a simplified form:

* The IPS is composed of different elements and sections, see the description in the [IPS IG](https://hl7.org/fhir/uv/ips/STU2/Structure-of-the-International-Patient-Summary.html). The [CH IPS Document](document.md) is based on this **structure**.
* The principles for representing **empty sections & missing data** described in the [IPS IG](https://hl7.org/fhir/uv/ips/STU2/Design-Conventions.html#empty-sections--missing-data) apply for CH IPS and are illustrated in Fig. 2.
* In this IG no elements are actively flagged as [mustSupport](https://hl7.org/fhir/r4/conformance-rules.html#mustSupport) = `true`. **Must Support (MS)** in CH IPS applies to the same elements as defined in IPS and the same [rules](https://hl7.org/fhir/uv/ips/STU2/Design-Conventions.html#must-support) also take effect.

![](sections.png)

*Fig. 2: Summary illustration of some principles for the sections*

Profiling in CH IPS is kept to a minimum and focuses on Swiss use. In order to avoid duplication, which could lead to conflicts in future versions, not all restrictions (e.g. must support, cardinalities, constraints) of the IPS are repeated in the CH IPS profiles. The imposeProfile extension ensures the validation of conformity with both profiles.

### Safety Considerations

This implementation guide defines data elements, resources, formats, and methods for exchanging healthcare data between different participants in the healthcare process. As such, clinical safety is a key concern. Additional guidance regarding safety for the specification’s many and various implementations is available at: [https://www.hl7.org/FHIR/safety.html](https://www.hl7.org/FHIR/safety.html).

Although the present specification does gives users the opportunity to observe data protection and data security regulations, its use does not guarantee compliance with these regulations. Effective compliance must be ensured by appropriate measures during implementation projects and in daily operations. The corresponding implementation measures are explained in the standard. In addition, the present specification can only influence compliance with the security regulations in the technical area of standardization. It cannot influence organizational and contractual matters.

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [eCH-011 Types](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11.html): [ChIpsPatient](StructureDefinition-ch-ips-patient.md)
* [CH VACD Swissmedic Authorized Vaccines](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ch-vacd-swissmedic-cs.html): [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md) and [Immunization/19efd704-3461-4120-b3cf-a76ae046e150](Immunization-19efd704-3461-4120-b3cf-a76ae046e150.md)
* [EDQM - Standard Terms](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-edqm-standardterms.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 7 more,[Immunization/19efd704-3461-4120-b3cf-a76ae046e150](Immunization-19efd704-3461-4120-b3cf-a76ae046e150.md),[MedicationStatement/6f369210-adb1-4f11-893d-9977e34932de](MedicationStatement-6f369210-adb1-4f11-893d-9977e34932de.md),[MedicationStatement/88ee1ffb-26d0-49a2-95e4-6212261805a6](MedicationStatement-88ee1ffb-26d0-49a2-95e4-6212261805a6.md),[MedicationStatement/MedStatCandesartan](MedicationStatement-MedStatCandesartan.md),[MedicationStatement/MedStatMetformin](MedicationStatement-MedStatMetformin.md),[MedicationStatement/e463547f-7414-47cb-b97f-04a81e1ab7d8](MedicationStatement-e463547f-7414-47cb-b97f-04a81e1ab7d8.md)and[MedicationStatement/f27b9345-6ba6-4fd6-83ab-6db6c2acd981](MedicationStatement-f27b9345-6ba6-4fd6-83ab-6db6c2acd981.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [CH_IPS](index.md), [ChIpsAllergyIntolerance](StructureDefinition-ch-ips-allergyintolerance.md)...Show 12 more,[ChIpsComposition](StructureDefinition-ch-ips-composition.md),[ChIpsCondition](StructureDefinition-ch-ips-condition.md),[ChIpsDocument](StructureDefinition-ch-ips-document.md),[ChIpsDocumentEPR](StructureDefinition-ch-ips-document-epr.md),[ChIpsImmunization](StructureDefinition-ch-ips-immunization.md),[ChIpsMedication](StructureDefinition-ch-ips-medication.md),[ChIpsMedicationRequest](StructureDefinition-ch-ips-medicationrequest.md),[ChIpsMedicationStatement](StructureDefinition-ch-ips-medicationstatement.md),[ChIpsOrganization](StructureDefinition-ch-ips-organization.md),[ChIpsPatient](StructureDefinition-ch-ips-patient.md),[ChIpsPractitioner](StructureDefinition-ch-ips-practitioner.md)and[ChIpsPractitionerRole](StructureDefinition-ch-ips-practitionerrole.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 4 more,[MedicationStatement/88ee1ffb-26d0-49a2-95e4-6212261805a6](MedicationStatement-88ee1ffb-26d0-49a2-95e4-6212261805a6.md),[MedicationStatement/MedStatMetformin](MedicationStatement-MedStatMetformin.md),[Observation/07b2e450-a62e-4734-98bf-51462f008e0f](Observation-07b2e450-a62e-4734-98bf-51462f008e0f.md)and[Observation/db5ef7b0-e946-4260-a604-128b8887a41b](Observation-db5ef7b0-e946-4260-a604-128b8887a41b.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 5 more,[ChIpsComposition](StructureDefinition-ch-ips-composition.md),[Composition/UC1-Composition1](Composition-UC1-Composition1.md),[Observation/07b2e450-a62e-4734-98bf-51462f008e0f](Observation-07b2e450-a62e-4734-98bf-51462f008e0f.md),[Observation/93fe0d81-a547-494e-941c-113506108b76](Observation-93fe0d81-a547-494e-941c-113506108b76.md)and[Observation/db5ef7b0-e946-4260-a604-128b8887a41b](Observation-db5ef7b0-e946-4260-a604-128b8887a41b.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [AllergyIntolerance/27da84cc-526a-4098-afb5-f08c7836d893](AllergyIntolerance-27da84cc-526a-4098-afb5-f08c7836d893.md), [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md)...Show 19 more,[Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md),[Composition/UC1-Composition1](Composition-UC1-Composition1.md),[Condition/12d8debe-5e03-465d-83f3-17675be9db4a](Condition-12d8debe-5e03-465d-83f3-17675be9db4a.md),[Condition/2c67cf62-d712-44c7-aedb-b5582bc707f1](Condition-2c67cf62-d712-44c7-aedb-b5582bc707f1.md),[Condition/506b9fef-be0a-4398-bb7e-7d14c311912f](Condition-506b9fef-be0a-4398-bb7e-7d14c311912f.md),[Condition/8a79d459-0d2f-460b-87fd-a7de12d49871](Condition-8a79d459-0d2f-460b-87fd-a7de12d49871.md),[Condition/CoronaryHeartDisease](Condition-CoronaryHeartDisease.md),[Condition/DiabetesMellitus](Condition-DiabetesMellitus.md),[Condition/HighBloodPressure](Condition-HighBloodPressure.md),[Immunization/19efd704-3461-4120-b3cf-a76ae046e150](Immunization-19efd704-3461-4120-b3cf-a76ae046e150.md),[MedicationStatement/6f369210-adb1-4f11-893d-9977e34932de](MedicationStatement-6f369210-adb1-4f11-893d-9977e34932de.md),[MedicationStatement/88ee1ffb-26d0-49a2-95e4-6212261805a6](MedicationStatement-88ee1ffb-26d0-49a2-95e4-6212261805a6.md),[MedicationStatement/MedStatCandesartan](MedicationStatement-MedStatCandesartan.md),[MedicationStatement/MedStatMetformin](MedicationStatement-MedStatMetformin.md),[MedicationStatement/e463547f-7414-47cb-b97f-04a81e1ab7d8](MedicationStatement-e463547f-7414-47cb-b97f-04a81e1ab7d8.md),[MedicationStatement/f27b9345-6ba6-4fd6-83ab-6db6c2acd981](MedicationStatement-f27b9345-6ba6-4fd6-83ab-6db6c2acd981.md),[Procedure/StentPlacement](Procedure-StentPlacement.md),[Procedure/ad3ec07d-1814-4faf-86fd-1a8ebeecb5fe](Procedure-ad3ec07d-1814-4faf-86fd-1a8ebeecb5fe.md)and[Procedure/d646c888-7af0-4439-8aae-9fd490054583](Procedure-d646c888-7af0-4439-8aae-9fd490054583.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/27da84cc-526a-4098-afb5-f08c7836d893](AllergyIntolerance-27da84cc-526a-4098-afb5-f08c7836d893.md) and [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-verification.html): [AllergyIntolerance/27da84cc-526a-4098-afb5-f08c7836d893](AllergyIntolerance-27da84cc-526a-4098-afb5-f08c7836d893.md) and [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)
* [Condition Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-category.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 7 more,[Condition/12d8debe-5e03-465d-83f3-17675be9db4a](Condition-12d8debe-5e03-465d-83f3-17675be9db4a.md),[Condition/2c67cf62-d712-44c7-aedb-b5582bc707f1](Condition-2c67cf62-d712-44c7-aedb-b5582bc707f1.md),[Condition/506b9fef-be0a-4398-bb7e-7d14c311912f](Condition-506b9fef-be0a-4398-bb7e-7d14c311912f.md),[Condition/8a79d459-0d2f-460b-87fd-a7de12d49871](Condition-8a79d459-0d2f-460b-87fd-a7de12d49871.md),[Condition/CoronaryHeartDisease](Condition-CoronaryHeartDisease.md),[Condition/DiabetesMellitus](Condition-DiabetesMellitus.md)and[Condition/HighBloodPressure](Condition-HighBloodPressure.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-clinical.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 7 more,[Condition/12d8debe-5e03-465d-83f3-17675be9db4a](Condition-12d8debe-5e03-465d-83f3-17675be9db4a.md),[Condition/2c67cf62-d712-44c7-aedb-b5582bc707f1](Condition-2c67cf62-d712-44c7-aedb-b5582bc707f1.md),[Condition/506b9fef-be0a-4398-bb7e-7d14c311912f](Condition-506b9fef-be0a-4398-bb7e-7d14c311912f.md),[Condition/8a79d459-0d2f-460b-87fd-a7de12d49871](Condition-8a79d459-0d2f-460b-87fd-a7de12d49871.md),[Condition/CoronaryHeartDisease](Condition-CoronaryHeartDisease.md),[Condition/DiabetesMellitus](Condition-DiabetesMellitus.md)and[Condition/HighBloodPressure](Condition-HighBloodPressure.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.0.1/CodeSystem-condition-ver-status.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md)...Show 7 more,[Condition/12d8debe-5e03-465d-83f3-17675be9db4a](Condition-12d8debe-5e03-465d-83f3-17675be9db4a.md),[Condition/2c67cf62-d712-44c7-aedb-b5582bc707f1](Condition-2c67cf62-d712-44c7-aedb-b5582bc707f1.md),[Condition/506b9fef-be0a-4398-bb7e-7d14c311912f](Condition-506b9fef-be0a-4398-bb7e-7d14c311912f.md),[Condition/8a79d459-0d2f-460b-87fd-a7de12d49871](Condition-8a79d459-0d2f-460b-87fd-a7de12d49871.md),[Condition/CoronaryHeartDisease](Condition-CoronaryHeartDisease.md),[Condition/DiabetesMellitus](Condition-DiabetesMellitus.md)and[Condition/HighBloodPressure](Condition-HighBloodPressure.md)
* [List Empty Reasons](http://terminology.hl7.org/7.0.1/CodeSystem-list-empty-reason.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md) and [Composition/UC1-Composition1](Composition-UC1-Composition1.md)
* [Observation Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-observation-category.html): [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md), [Observation/07b2e450-a62e-4734-98bf-51462f008e0f](Observation-07b2e450-a62e-4734-98bf-51462f008e0f.md) and [Observation/db5ef7b0-e946-4260-a604-128b8887a41b](Observation-db5ef7b0-e946-4260-a604-128b8887a41b.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md), [ChIpsPatient](StructureDefinition-ch-ips-patient.md) and [Patient/8383926c-ece1-4384-94bc-b4250b4cb71b](Patient-8383926c-ece1-4384-94bc-b4250b4cb71b.md)
* [ActClass](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActClass.html): [Bundle/UC1-SwissIpsDocument1](Bundle-UC1-SwissIpsDocument1.md), [Bundle/UC1-SwissIpsDocument2](Bundle-UC1-SwissIpsDocument2.md) and [Composition/UC1-Composition1](Composition-UC1-Composition1.md)
* [RoleCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-RoleCode.html): [ChIpsPatient](StructureDefinition-ch-ips-patient.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-ips.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-ips.r4b)](package.r4b.tgz) are available.

### Dependency Table








### Globals Table

*There are no Global profiles defined*

