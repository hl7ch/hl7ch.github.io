# Études de cas - CH LAB-Order (R4) v3.0.0

* [**Table of Contents**](toc.md)
* **Études de cas**

## Études de cas

### Contrôle de l'effet de l'anticoagulation

Mme Birgit Blum a fait une chute malencontreuse en skiant et a subi une fracture multifragmentaire du plateau tibial. Elle a été transférée par hélicoptère au Kantonsspital, un hôpital central, où elle attend son opération. La patiente reçoit quotidiennement Liquemin 5000 E s.c. pour prévenir les événements thromboemboliques. Pour surveiller l'effet de ce traitement, des analyses sanguines régulières sont effectuées pour déterminer l'activité anti-Xa. Un récipient spécial contenant un additif au citrate est utilisé à cet effet. L'échantillon doit être centrifugé et refroidi dans l'heure qui suit. Les maladies cardiaques constituent un élément important de la liste des problèmes de la patiente.

* [CH LAB-Order document avec demande de service](Bundle-0-best-practice-document-with-sr.md)

### Soupçon de thrombose veineuse profonde szenario

Le patient Tobias Timmermann se présente chez le Dr Marc Mustermann au cabinet de groupe d'Olten. Il s'identifie oralement par ses données de base comme Tobias Timmermann, né le 01.01.1984. Il signale des douleurs peu claires dans la jambe gauche ainsi que des douleurs respiratoires et une toux simultanées. Le médecin procède à l'anamnèse et à l'examen physique et prescrit les paramètres de laboratoire suivants :

* hémogramme, y compris différenciation
* CRP
* D-dimères

Le médecin effectue lui-même l'hémogramme et la détermination de la CRP au moyen d'un diagnostic au point de service, le diagnostic des D-dimères est prescrit en tant que diagnostic quantitatif dans un laboratoire d'envoi externe. Pour obtenir l'échantillon, un échantillon de sang est prélevé en position allongée (1 tube EDTA, 2 tubes citrate de 5 ml). La commande est transmise au laboratoire externe et l'échantillon est envoyé au laboratoire d'envoi externe par courrier commandé par téléphone. Les résultats des diagnostics internes au point de service (numération sanguine et CRP) sont saisis dans la fiche de laboratoire du patient dans le logiciel du cabinet médical (manuellement ou par le biais d'interfaces électroniques installées localement). Une ordonnance est alors délivrée par le médecin au patient pour l'auto-administration d'un agent anti-thrombotique. Les résultats du laboratoire d'envoi parviennent électroniquement au médecin généraliste le soir même et sont également inscrits sur la fiche de laboratoire du patient. En utilisant le format d'échange actuel, ce processus peut être entièrement automatisé. Après une demande téléphonique du médecin du laboratoire expéditeur en raison d'un résultat D-dimère limite, l'information est donnée qu'une thrombose veineuse profonde ne peut pas être exclue dans cette situation au moyen du D-dimère et le patient est donc rappelé le jour suivant pour une échographie des jambes. 
 Comme il s'agit probablement d'une thrombose primaire de la veine de la jambe, le Dr Eva Erlenmeier du laboratoire Pipette envoie un retour au Dr Mustermann avec la recommandation d'effectuer un dépistage de la thrombophilie, qui comprend les analyses suivantes : Quick, aPTT, fibrinogène, antithrombine (funct.), temps de thrombine I 2.5 NIH/ml, résistance APC, D-dimères, protéine C, (méthode aPTT), protéine S antigène. Les analyses peuvent être effectuées directement à partir des échantillons des tubes de citrate envoyés.

* [CH LAB-Order document avec demande de service](Bundle-1-tvt-document-with-sr.md)
* [CH LAB-Order document avec demande de service et formulaire](Bundle-1-tvt-document-with-sr-and-form.md)

### Contrôle gynécologique annuel

Le médecin assistant du service de gynécologie du cabinet communautaire d'Olten, le Dr Peter Pap, prépare les consultations du lendemain. Comme le cabinet ne dispose que d'un laboratoire propre minimal, certaines patientes sont envoyées avant le rendez-vous au laboratoire ambulatoire Pipette situé à proximité, dont la jeune patiente Mme Marina Rubella, née le 8. 8. 1992. Dans le logiciel de son cabinet, l'assistante médicale prescrit les analyses standard convenues avec le laboratoire pour l'examen gynécologique triennal de la patiente Rubella. Cela comprend également le prélèvement de sérum sanguin pour d'éventuelles prescriptions ultérieures. Le laboratoire transmet les résultats au cabinet médical au plus tard 90 minutes après la prise de sang. Le Dr Pap prescrit les examens suivants au cours de la consultation :

* Cytologie cervicale gynécologique : Frottis de Papanicolaou - si cela est indiqué, la détection et le typage du HPV (virus du papillome humain) doivent également être effectués. Matériel de prélèvement selon les instructions du laboratoire. L'examen cytologique est effectué dans le laboratoire Pipette. Le laboratoire Pipette n'effectue pas le typage lui-même.
* Statut urinaire partiel (test Combur9) : effectué par le MPA dans le cabinet : les paramètres suivants sont examinés : pH, leucocytes, érythrocytes, nitrites, protéines, glucose, cétones, urobilinogène, bilirubine (examens semi-quantitatifs, les résultats sont probablement saisis manuellement dans le système du laboratoire du cabinet).
* Bactériologie urinaire : matériel de prélèvement selon les instructions du laboratoire. Bactéries générales, y compris les champignons, à la pipette du laboratoire. La transmission de la commande est déclenchée par le MPA (temps de collecte).
* Ordonnance complémentaire "Dépistage avant la grossesse" : Tous les tests peuvent être effectués à partir du matériel (sérum, sang EDTA) prélevé au préalable dans la clinique ambulatoire (anticorps de l'hépatite Bc, VIH 1+2 (Ak+p24), IgG de la rubéole, test de dépistage de la lésion/syphilis).
* [CH LAB-Order document avec demande de service](Bundle-3-gyn-document.md)
* [CH LAB-Order document avec demande de service et formulaire](Bundle-3-gyn-document-with-sr-and-form.md)

### Histopathology examination

Simone Studer, une patiente de 45 ans, s'est présentée à l'Arztpraxis du dermatologue Armin Ahrens pour un contrôle régulier de sa peau, et cette lésion a été notée : Naevus de jonction composé d'une zone séborrhéique à l'extrémité supérieure et d'un réseau atypique constitué de nombreux points, structures, etc. distincts, suggérant une implication mélanocytaire. Excision. Images dermatoscopiques jointes. Spécimen : Ellipse cutanée de 29 x 11 x 5 mm Site corporel :

* Dos paralombaire gauche
* L'échantillon de peau, le formulaire de commande et l'image dermatoscopique sont envoyés au laboratoire.

![](Dermatoscopic-image-of-superficial-spreading-melanoma.png)

*Fig. : Image dermatoscopique*

* [CH LAB-Order document avec demande de service](Bundle-6-histopath-document-with-sr.md)
* [CH LAB-Order document avec demande de service et formulaire](Bundle-6-histopath-document-with-sr-and-form.md)

### Suspicion de coqueluche

Une mère se rend chez le médecin de famille Peter Presto du cabinet de groupe d'Olten avec son fils Emil Kummer, 6 ans, né le 5 mai 2014, car l'enfant tousse de plus en plus depuis une quinzaine de jours, avec des quintes de toux, et a de la fièvre. La réceptionniste du médecin mesure la fièvre, prélève un échantillon de sang au bout du doigt, détermine la CRP et prépare un frottis sanguin. Le médecin soupçonne une infection virale, mais veut exclure la coqueluche, bien que l'enfant ait été vacciné contre cette maladie. Comme il est pressé par l'urgence, il ne veut pas effectuer lui-même le prélèvement de gorge nécessaire, mais demande à la mère d'accompagner l'enfant au laboratoire le plus proche pour que le prélèvement soit effectué en toute tranquillité. Il prépare un ordre de laboratoire pour effectuer une PCR coqueluche sur le prélèvement de gorge de l'enfant et donne l'ordre à la mère. La mère elle-même n'est pas sûre d'avoir été vaccinée contre la coqueluche. 
 En conséquence, le médecin de famille Peter Presto la vaccine immédiatement contre la coqueluche et recommande de faire de même pour le père et les grands-parents de l'enfant. Entre-temps, l'AMP a examiné au microscope le frottis sanguin de l'enfant et trouve beaucoup de lymphocytes réactifs, ce qui lui semble suspect. Elle n'est pas sûre et interroge le médecin, qui donne l'ordre de remettre les frottis sanguins de l'enfant à la mère et de les faire examiner de plus près au laboratoire. La mère arrive au laboratoire avec son fils, où le médecin ordonne d'abord d'établir l'identité du fils. Ensuite, un prélèvement pharyngé et une ponction cubitale droite sont effectués sur l'enfant dans la salle de prélèvement sanguin du laboratoire et transmis au laboratoire avec les frottis sanguins et l'ordre d'examen du médecin.

* [CH LAB-Order document avec demande de service](Bundle-2-pertussis-document-with-sr.md)
* [CH LAB-Order document avec demande de service et formulaire](Bundle-2-pertussis-document-with-sr-and-form.md)

### Surveillance biologique SUVA

Les entreprises qui travaillent avec des substances dangereuses pour la santé et dans lesquelles les employés sont exposés à des risques particuliers sont soumises à un examen de santé au travail par la SUVA. La surveillance biologique est l'une des possibilités de contrôle. Il permet d'évaluer l'exposition des travailleurs à des agents chimiques en déterminant les agents ou les métabolites dans le matériel biologique (par exemple l'urine). La prévention médicale du travail (AMV) de la SUVA envoie au laboratoire une liste mensuelle contenant les informations suivantes par entreprise (ordre collectif) :

* Établissement (nom, adresse, numéro d'établissement)
* Nombre d'employés pour le contrôle biologique
* Examens à effectuer (par exemple arsenic, plomb, mercure, acide mandélique). Les entreprises reçoivent de l'AMV une liste comprenant les étiquettes des employés concernés. Nous prenons ici le document d'un employé, Beat Borer, né le 6. 6. 1986. Le laboratoire imprime les bons de commande avec le numéro de l'entreprise et envoie le nombre nécessaire de gobelets d'urine et de bons de commande aux entreprises. Dans l'entreprise, les bons de commande et les gobelets d'urine sont étiquetés avec les étiquettes fournies par l'AMV et remis aux employés. Les échantillons, y compris le bon de commande, sont envoyés de l'entreprise au laboratoire.
* [CH LAB-Order document avec demande de service](Bundle-5-biol-monit-document-with-sr.md)
* [CH LAB-Order document avec demande de service et formulaire](Bundle-5-biol-monit-document-with-sr-and-form.md)

