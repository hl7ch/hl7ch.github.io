# Home - CH LAB-Order (R4) v3.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-lab-order/ImplementationGuide/ch.fhir.ig.ch-lab-order | *Version*:3.0.0 |
| Active as of 2025-12-16 | *Computable Name*:CH_LAB_ORDER |
| **Copyright/Legal**: CC0-1.0 | |

### HL7 Swiss FHIR Implementation Guide for Generic Laboratory Orders

During the STU3 ballot by [HL7 Switzerland](https://www.hl7.ch/de/) negative comments were raised that a further evolution of the Laboratory Order Implementation Guide should not be document-based, but based on the fundamental patterns described in the [Clinical Order Workflow (COW) Implementation Guide](https://hl7.org/fhir/uv/cow/2025May/). The lab group agreed that clinical order workflows should be the long-term goal and future of LAB Order. However, due to lack of resources it is proposed to stick with the document-based approach. The successful implementation and establishment of this approach is already considered a significant improvement.

[Changelog](changelog.md) with significant changes, open and closed issues.

#### Laboratory Order with Service Request

This is the HL7 Swiss FHIR Implementation Guide for Laboratory Orders. Electronic Medical Records (EMR) systems can send an electronic laboratory order to a Laboratory Information System (the order filler of a LIS). This laboratory order consists of a FHIR bundle resource of type 'document' with the necessary information about the patient, his medication and his conditions (the clinical context), the ordering practitioner, the organization, the laboratory, etc. The analyses that are requested are available as code and as text in the ServiceRequest resource. This resource contains further important information about the reason for the order, the payer, and the material sample. This specimen resource, in turn, contains information about the collection, the processing details, any required additives, and the container type to be used, among other things. So all the necessary information for executing the laboratory order is available for the receiving laboratory, and there is no necessity for a Questionnaire and QuestionnaireResponse resource. This quite common use case primarily occurs in hospitals that operate their own medical laboratory.

[CH Core](https://fhir.ch/ig/ch-core/index.html) and [CH Term](https://fhir.ch/ig/ch-term/index.html) are used to take account of national requirements.

#### Laboratory Order with Service Request and Form (optional)

There is another use case in which the commissioning laboratory provides the client with a form, similar to how laboratories forms are used to serve clients with paper-based forms. The lab order appears again as a FHIR bundle resource of type 'document'. This situation is implemented here using [CH ORF, Order & Referral by Form Implementation Guide](http://fhir.ch/ig/ch-orf/index.html) to structure the input of the administrative and clinical data (data provider, contact for order-document, recipient, copy recipient, document type and document class, patient, author, tests, specimen etc). It includes the two resources Questionnaire (form) and QuestionnaireResponse (completed form) in the document in addition to the ServiceRequest resource. The CH ORF Implementation Guide is based on the [SDC](http://hl7.org/fhir/uv/sdc/STU3/) framework and applies its concepts to provide user-friendly forms featuring pre-populated fields and ValueSet-driven selections.

#### Download

You can download this Implementation Guide in [NPM-format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](https://fhir.ch/ig/ch-lab-order/package.tgz).

### Foundation

Data exchange with different information systems (practice, hospital, laboratory) quickly becomes confusing due to proprietary solutions (n:m cardinality). Therefore, the question arises whether a standardized order interface is the more favorable solution in the long run.

#### Laboratory Order with Service Request

This implementation Guide uses FHIR Resources. The complete laboratory order is a bundle resource of type document. The first entry is the composition containing the structured data of the order (status, type, category, subject, encounter, date, author, confidentiality, attester etc). A section element has an entry with the Service request reference.

The ServiceRequest may instantiate an ActivityDefinition, a coded procedure to execute a single laboratory test (e.g. Sodium concentration in Serum), or to execute an entire test panel (e.g. concentration of Electrolytes in Serum). Using a ServiceRequest Container we can reference to other ServiceRequest Containers or to Single Test Service Requests.

#### Laboratory Order with Service Request and Form

The lab order can optionally and in addition to the ServiceRequest contain forms as resources, which in this context are called Questionnaire and QuestionnaireResponse. The structure of these forms is [based on ORF](http://fhir.ch/ig/ch-orf/ImplementationGuide/ch.fhir.ig.ch-orf). This allows the data for the laboratory order to be placed in a structured way.

### Requirements

The lab order should define the structure of the order details so it can be used by different laboratories and different providers of practice or clinic systems or independent tool.

1. The partly or fully filled electronic order should be storable in the order placer system (practice system, hospital system), so it can be changed until the samples are scanned by the receiver laboratory.
1. Data about practitioner, patient and treatment should be transferable to the electronic order.
1. In the electronic order all available analyses should be presentable, a search option should be available. The content of panels should be visible.
* The the electronic order should contain analyses and test-panels. Groups of tests, e.g. for "blood count" are usually requested as panels. They are split into service requests for single analyses in the ServiceRequest Container. If the LIS (Laboratory Information System) knows the components of the panels, it can do the splitting itself.

1. Analyses, Sample type, required Sample additives and pre-analytic handling should be presented to the order filler.
* Information for the sample taking should be available for the person preparing the taking of blood.
* A numbering system should be supported, so that relabeling at the laboratory can be limited (eg. practitioner number + number-range).

1. The electronic order should be able to handle the request of analyses for samples that were sent at an earlier point of time.
1. The electronic order should receive updates on the process of the laboratory analyses: as sample received in laboratory, first results available, report finished [Domain of Lab-Report].
* The status of the order at the practitioner site should be supported as well: new order, replaced order (enhanced or partly deleted), printed sample labels, documentation of blood take (additional Information as urine volume and Date and Time of withdrawal of blood).

### Case Studies with Examples for the Order Document

Using concrete case studies ([en](case-studies-english.md), [de](case-studies-german.md), [fr](case-studies-french.md)), we have created examples of documents that contain a laboratory order. These are requirements of laboratory analyses in the field of hematology, clinical chemistry, coagulation and infectious serology. The biological monitoring example covers the special case where several employees of a company send their biological material (serum, urine) to the laboratory for determination of substances hazardous to health (toxicology).

### Copyright

This artefact includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these artifacts must have the appropriate SNOMED CT Affiliate license - for more information contact [http://www.snomed.org/snomed-ct/getsnomed-ct](http://www.snomed.org/snomed-ct/getsnomed-ct) or [info@snomed.org](mailto:info@snomed.org).

This artefact includes content from LOINC®. This content LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at [http://loinc.org/terms-of-use](http://loinc.org/terms-of-use).

### Safety Considerations

This Implementation Guide defines data elements, resources, formats, and methods for exchanging healthcare data between different participants in the healthcare process. As such, clinical safety is a key concern. Additional guidance regarding safety for the specification’s many and various implementations is available at: [https://www.hl7.org/FHIR/safety.html](https://www.hl7.org/FHIR/safety.html).

Although the present specification gives users the opportunity to observe data protection and data security regulations, its use does not guarantee compliance with these regulations. Effective compliance must be ensured by appropriate measures during implementation projects and in daily operations. The corresponding implementation measures are explained in the standard. In addition, the present specification can only influence compliance with the security regulations in the technical area of standardisation. It cannot influence organisational and contractual matters.

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This Implementation Guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [BFS Medizinische Statistik - 25 1.4.V02 - Hauptkostenträger für Grundversicherungsleistungen / Prise en charge des soins de base / Unità d’imputazione principale per le prestazioni dell’assicurazione di base](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-25-mainguarantor.html): [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [eCH-011 MaritalStatus](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11-maritalstatus.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 12 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md),[Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md),[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md)and[LabOrderFormCaseStudies](Questionnaire-LabOrder-form.md)
* [Service Request Categories for Questionnaires](CodeSystem-ServiceRequest.categories.md): [ServiceRequestCategories](ValueSet-ServiceRequest.categories.md)
* [Coverage Identifier Type](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-coverageidentifiertype.html): [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [ch-ehealth-codesystem-medreg](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.5.html): [Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md), [Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md), [Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md) and [Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md), [Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md)...Show 19 more,[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md),[CH_LAB_ORDER](index.md),[ChLabOrderCompositionWithSR](StructureDefinition-ch-lab-order-composition-with-sr.md),[ChLabOrderCompositionWithSR_AndForm](StructureDefinition-ch-lab-order-composition-with-sr-and-form.md),[ChLabOrderDocumentReference](StructureDefinition-ch-lab-order-document-reference.md),[ChLabOrderDocumentWithSR](StructureDefinition-ch-lab-order-document-with-sr.md),[ChLabOrderDocumentWithSR_AndForm](StructureDefinition-ch-lab-order-document-with-sr-and-form.md),[ChLabOrderLabStudyTypes](ValueSet-ch-lab-order-study-types.md),[ChLabOrderSR](StructureDefinition-ch-lab-order-SR.md),[ChLabOrderServiceRequestCategories](CodeSystem-ServiceRequest.categories.md),[ChLabOrderSpecimenProcessingProcedure](CodeSystem-Specimen.processing.procedure.md),[ChLabVSOrderControl](ValueSet-ch-lab-vs-order-control.md),[LabOrderFormCaseStudies](Questionnaire-LabOrder-form.md),[MicrobiolProcedures](ValueSet-MicrobiolProcedures.md),[ReasonsForOrder](ValueSet-reasons-for-order.md)and[ServiceRequestCategories](ValueSet-ServiceRequest.categories.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 14 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md),[Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md),[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md),[ChLabOrderCompositionWithSR_AndForm](StructureDefinition-ch-lab-order-composition-with-sr-and-form.md),[ChLabOrderLabStudyTypes](ValueSet-ch-lab-order-study-types.md)and[LabOrderFormCaseStudies](Questionnaire-LabOrder-form.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 16 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md),[Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md),[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md),[ChLabOrderCompositionWithSR](StructureDefinition-ch-lab-order-composition-with-sr.md),[ChLabOrderCompositionWithSR_AndForm](StructureDefinition-ch-lab-order-composition-with-sr-and-form.md),[ChLabOrderSR](StructureDefinition-ch-lab-order-SR.md),[MicrobiolProcedures](ValueSet-MicrobiolProcedures.md)and[ReasonsForOrder](ValueSet-reasons-for-order.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-category.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-clinical.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.0.1/CodeSystem-condition-ver-status.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [diagnosticServiceSectionId](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0074.html): [Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md) and [Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md)
* [orderControlCodes](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0119.html): [Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md), [Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md), [ChLabOrderSR](StructureDefinition-ch-lab-order-SR.md) and [ChLabVSOrderControl](ValueSet-ch-lab-vs-order-control.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 12 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md),[Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md),[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md)and[ChLabOrderSR](StructureDefinition-ch-lab-order-SR.md)
* [additivePreservative](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0371.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md) and [Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md)
* [relevantClincialInformation](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0916.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 5 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md)and[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md)
* [Religious Affiliation](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ReligiousAffiliation.html): [Bundle/0-best-practice-document-with-sr](Bundle-0-best-practice-document-with-sr.md), [Bundle/1-tvt-document-with-sr](Bundle-1-tvt-document-with-sr.md)...Show 11 more,[Bundle/1-tvt-document-with-sr-and-form](Bundle-1-tvt-document-with-sr-and-form.md),[Bundle/2-pertussis-document-with-sr](Bundle-2-pertussis-document-with-sr.md),[Bundle/2-pertussis-document-with-sr-and-form](Bundle-2-pertussis-document-with-sr-and-form.md),[Bundle/3-gyn-document](Bundle-3-gyn-document.md),[Bundle/3-gyn-document-with-sr-and-form](Bundle-3-gyn-document-with-sr-and-form.md),[Bundle/5-biol-monit-document-with-sr](Bundle-5-biol-monit-document-with-sr.md),[Bundle/5-biol-monit-document-with-sr-and-form](Bundle-5-biol-monit-document-with-sr-and-form.md),[Bundle/6-histopath-document-with-sr](Bundle-6-histopath-document-with-sr.md),[Bundle/6-histopath-document-with-sr-and-form](Bundle-6-histopath-document-with-sr-and-form.md),[Bundle/ch-lab-order-document-with-sr](Bundle-ch-lab-order-document-with-sr.md)and[Bundle/ch-lab-order-with-sr-and-form](Bundle-ch-lab-order-with-sr-and-form.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-lab-order.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-lab-order.r4b)](package.r4b.tgz) are available.

### Dependency Table









### Globals Table

*There are no Global profiles defined*

