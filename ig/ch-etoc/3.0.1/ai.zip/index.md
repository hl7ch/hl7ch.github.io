# Home - CH eTOC (R4) v3.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-etoc/ImplementationGuide/ch.fhir.ig.ch-etoc | *Version*:3.0.1 |
| Active as of 2025-12-16 | *Computable Name*:CH_eTOC |
| **Copyright/Legal**: CC0-1.0 | |

### Purpose

The CH eTransition of Care (CH eTOC) Implementation Guide defines the content of a referral from a GP to the hospital, to a specialist, from one hospital to another etc.

CH eTOC is intended primarily for use in directional information exchange and for the use in the SWISS EPR. It however may be implemented in other settings too.

[Significant changes, open and closed issues.](changelog.md)

**Download:** You can download this implementation guide in [npm format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](package.tgz).

### Foundation

This Implementation Guide uses FHIR defined resources. For details on HL7 FHIR R4 see [http://hl7.org/fhir/r4](http://hl7.org/fhir/r4).

Because the Implementation Guide relies heavily on the FHIR Resources Questionnaire and QuestionnaireResponse, forms are addressed here as Questionnaires.

This Implementation Guide is derived from the [CH Order & Referral by Form (CH ORF) Implementation Guide (CH ORF)](https://fhir.ch/ig/ch-orf/3.0.0/index.html) which relies on HL7 Structured Data Capture Implementation Guide, see [SDC](https://hl7.org/fhir/uv/sdc/STU3/) and uses the Swiss Core Profiles, see [CH Core](https://fhir.ch/ig/ch-core/5.0.0/index.html).

April 7, 2022 the HL7 Switzerland Technical Committee discussed #39 and finally voted to set cardinality for the Questionnaire and QuestionnaireResponse to 1.. in the composition resource thus making the use of Questionnaires and QuestionnaireResponses mandatory (see also [CH ORF](https://fhir.ch/ig/ch-orf/3.0.0/index.html)).

Applications claiming for conformance with a CH ORF derived implementation guide shall: 
 Render (and in case of the Questionnaire Filler allow for data entry) all elements of a questionnaire in the user interface (e.g. on screen, in print). Grouping of items and the order of items within shall be adequately reproduced according to the questionnaire.

Vendors of applications with Questionnaire Filler/Questionnaire Receiver actors are strongly recommended to implement interfaces to other applications (such as HIS and PACS) at least for all data in the generics elements of questionnaires.

In the 3rd report of the Interprofessional Working Group on Electronic Patient Record (IPAG) [eDischarge Report](https://www.e-health-suisse.ch/upload/documents/Bericht_IPAG_eTOC_eUeberweisungsbericht.pdf), recommendations are formulated that are important for the inter-professional exchange of information during transitions of treatment (transition of care). The information relevant to treatment shall be be described in an exchange format that makes suggestions for structuring the content of interprofessional data content.

#### Relation to the International Patient Summary

At the IPAG working group meeting in February 2021, it was decided that a first version of CH eTOC shall be based on the the HL7 IPS-UV specification, especially regarding the structure. See also the table below where the sections of both formats are compared.

However, this version of CH eTOC still allows many free text entries. The reason for this is that, according to IPAG, the items shall be implemented as text in a first step. It can be expected, that users will copy and paste results: it seems reasonable to have multiple entries for the lab, but other findings are usually in free text form and therefore it makes sense to copy all findings in one copy and paste action.

Clinical content uses mostly the same resources as the IPS. The resource definitions are however constrained from FHIR base definitions and CH Core definitions and NOT from CH IPS or UV IPS. This decision was made in order to focus on the sections relevant to CH eTOC and to minimize the unexpected effects of future changes within the IPS.

* IPS Section: IPS Medication Summary
  * CH eTOC Section: Medication
  * Profile used in CH eTOC: [CH Core MedicationStatement](https://fhir.ch/ig/ch-core/5.0.0/StructureDefinition-ch-core-medicationstatement.html)
  * Comments (on differences): -
* IPS Section: IPS Allergies and Intolerances
  * CH eTOC Section: Allergies and intolerances
  * Profile used in CH eTOC: [CH eTOC Allergy Intolerance](StructureDefinition-ch-etoc-allergyintolerance.md)
  * Comments (on differences): -
* IPS Section: IPS Problems
  * CH eTOC Section: Problems
  * Profile used in CH eTOC: [CH eTOC Primary Diagnosis Condition](StructureDefinition-ch-etoc-primary-diagnosis.md)
  * Comments (on differences): CH eTOC allows to distinguish between primary and secondary diagnosis, both are referenced in this section.
* IPS Section: [CH eTOC Secondary Diagnosis Condition](StructureDefinition-ch-etoc-secondary-diagnosis.md)
* IPS Section: IPS History of Procedures
  * CH eTOC Section: History of Procedures
  * Profile used in CH eTOC: [CH eTOC Procedure](StructureDefinition-ch-etoc-procedure.md)
  * Comments (on differences): -
* IPS Section: IPS Immunizations
  * CH eTOC Section: Immunizations
  * Profile used in CH eTOC: [CH eTOC immunizationstatus](StructureDefinition-ch-etoc-immunization.md)
  * Comments (on differences): -
* IPS Section: IPS Medical Devices
  * CH eTOC Section: Medical devices
  * Profile used in CH eTOC: [CH eTOC Device](StructureDefinition-ch-etoc-device.md)
  * Comments (on differences): -
* IPS Section: IPS Results
  * CH eTOC Section: Diagnostic results
  * Profile used in CH eTOC: [CH eTOC Lab Observation](StructureDefinition-ch-etoc-lab-observation.md)
  * Comments (on differences): -
* IPS Section: [CH eTOC Pathology Observation](StructureDefinition-ch-etoc-pathology-observation.md)
* IPS Section: [CH eTOC Radiology Observation](StructureDefinition-ch-etoc-radiology-observation.md)
* IPS Section: [CH eTOC Cardiology Observation](StructureDefinition-ch-etoc-cardiology-observation.md)
* IPS Section: IPS Vital Signs
  * CH eTOC Section: [CH eTOC Body Weight Observation](StructureDefinition-ch-etoc-bodyweight-observation.md)
  * Profile used in CH eTOC: There is no Vital Signs section in CH eTOC, to avoid duplicate content.
* IPS Section: [CH eTOC Body Height Observation](StructureDefinition-ch-etoc-bodyheight-observation.md)
* IPS Section: IPS History of Past Illness
  * CH eTOC Section: History of past illness
  * Profile used in CH eTOC: [CH eTOC Past History of Illnesses Condition](StructureDefinition-ch-etoc-illness.md)
  * Comments (on differences): -
* IPS Section: IPS Functional Status
  * CH eTOC Section: Functional Status
  * Profile used in CH eTOC: [CH eTOC Functional Status Condition](StructureDefinition-ch-etoc-functionalstatus.md)
  * Comments (on differences): -
* IPS Section: IPS Plan of Care
  * CH eTOC Section: -
  * Profile used in CH eTOC: -
  * Comments (on differences): This section is omitted in CH eTOC for the following reason: It is assumed that care plans will only be available as PDF files in the foreseeable future at best. Therefore, there is a need to provide care plans as attachments. The Attachments section is provided for this purpose.
* IPS Section: IPS Social History
  * CH eTOC Section: Social history
  * Profile used in CH eTOC: [CH eTOC Social History Condition](StructureDefinition-ch-etoc-socialhistory.md)
  * Comments (on differences): -
* IPS Section: IPS History of Pregnancy
  * CH eTOC Section: Pregnancy
  * Profile used in CH eTOC: [CH eTOC Pregnancy Status Observation](StructureDefinition-ch-etoc-pregnancystatus.md)
  * Comments (on differences): -
* IPS Section: [CH eTOC Expected Delivery Date Observation](StructureDefinition-ch-etoc-expecteddeliverydate.md)
* IPS Section: IPS Advance Directives
  * CH eTOC Section: -
  * Profile used in CH eTOC: -
  * Comments (on differences): Not defined (yet) in CH eTOC.
* IPS Section: IPS Alerts Section
  * CH eTOC Section: -
  * Profile used in CH eTOC: -
  * Comments (on differences): Not defined (yet) in CH eTOC.
* IPS Section: IPS Patient Story Section
  * CH eTOC Section: -
  * Profile used in CH eTOC: -
  * Comments (on differences): Not defined (yet) in CH eTOC.
* IPS Section: -
  * CH eTOC Section: Order and Referral
  * Profile used in CH eTOC: [CH ORF Questionnaire](https://fhir.ch/ig/ch-orf/3.0.0/StructureDefinition-ch-orf-questionnaire.html)
  * Comments (on differences): Additional section in CH eTOC containing the data that supports the order and referral by form.
* IPS Section: [CH ORF QuestionnaireResponse](https://fhir.ch/ig/ch-orf/3.0.0/StructureDefinition-ch-orf-questionnaireresponse.html)
* IPS Section: [CH eTOC Service Request](StructureDefinition-ch-etoc-servicerequest.md)
* IPS Section: -
  * CH eTOC Section: Purpose
  * Profile used in CH eTOC: [CH eTOC ServiceRequest](StructureDefinition-ch-etoc-servicerequest.md)
  * Comments (on differences): Additional section in CH eTOC to provide information about the purpose/reason.
* IPS Section: -
  * CH eTOC Section: Attachments
  * Profile used in CH eTOC: [CH ORF DocumentReference](https://fhir.ch/ig/ch-orf/3.0.0/StructureDefinition-ch-orf-documentreference.html)
  * Comments (on differences): Additional section to support multiple attachments (for anything considered important).

[Table 1] **Comparison between the sections of IPS and CH eTOC**

### Terminology

Value sets and codings are preliminary and not yet approved by eHealth Suisse.

### Safety Considerations

This implementation guide defines data elements, resources, formats, and methods for exchanging healthcare data between different participants in the healthcare process. As such, clinical safety is a key concern. Additional guidance regarding safety for the specification’s many and various implementations is available at: [https://www.hl7.org/FHIR/safety.html](https://www.hl7.org/FHIR/safety.html).

Although the present specification does gives users the opportunity to observe data protection and data security regulations, its use does not guarantee compliance with these regulations. Effective compliance must be ensured by appropriate measures during implementation projects and in daily operations. The corresponding implementation measures are explained in the standard. In addition, the present specification can only influence compliance with the security regulations in the technical area of standardization. It cannot influence organizational and contractual matters.

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [BFS Medizinische Statistik - 21 1.3.V02 - Klasse / Classe / Classe](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-21-encountertype.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md) and [QuestionnaireResponse/QuestionnaireResponseEtocTransCare](QuestionnaireResponse-QuestionnaireResponseEtocTransCare.md)
* [BFS Medizinische Statistik - 25 1.4.V02 - Hauptkostenträger für Grundversicherungsleistungen / Prise en charge des soins de base / Unità d’imputazione principale per le prestazioni dell’assicurazione di base](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-25-mainguarantor.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md) and [Coverage/CoverageKVG](Coverage-CoverageKVG.md)
* [eCH-011 MaritalStatus](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11-maritalstatus.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md), [QuestionnaireResponse/QuestionnaireResponseEtocRequestPrevious](QuestionnaireResponse-QuestionnaireResponseEtocRequestPrevious.md) and [QuestionnaireResponse/QuestionnaireResponseEtocTransCare](QuestionnaireResponse-QuestionnaireResponseEtocTransCare.md)
* [Condition Category](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ch-etoc-conditioncategory.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [ChEtocFunctionalStatusCondition](StructureDefinition-ch-etoc-functionalstatus.md)...Show 8 more,[ChEtocPastHistoryofIllnessesCondition](StructureDefinition-ch-etoc-illness.md),[ChEtocPrimaryDiagnosisCondition](StructureDefinition-ch-etoc-primary-diagnosis.md),[ChEtocSecondaryDiagnosisCondition](StructureDefinition-ch-etoc-secondary-diagnosis.md),[ChEtocSocialHistoryCondition](StructureDefinition-ch-etoc-socialhistory.md),[Condition/PastHistoryofIllnessesConditionEtoc](Condition-PastHistoryofIllnessesConditionEtoc.md),[Condition/PrimaryDiagnosis](Condition-PrimaryDiagnosis.md),[Condition/SecondaryDiagnosis1](Condition-SecondaryDiagnosis1.md)and[Condition/SecondaryDiagnosis2](Condition-SecondaryDiagnosis2.md)
* [Consent Status](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-consentstatus.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md), [QuestionnaireResponse/QuestionnaireResponseEtocRequestPrevious](QuestionnaireResponse-QuestionnaireResponseEtocRequestPrevious.md) and [QuestionnaireResponse/QuestionnaireResponseEtocTransCare](QuestionnaireResponse-QuestionnaireResponseEtocTransCare.md)
* [Coverage Identifier Type](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-coverageidentifiertype.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md) and [Coverage/CoverageKVG](Coverage-CoverageKVG.md)
* [ch-ehealth-codesystem-language](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.10.12.html): [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [CH_eTOC](index.md)...Show 32 more,[ChEtocAllergyIntolerance](StructureDefinition-ch-etoc-allergyintolerance.md),[ChEtocBodyHeightObservation](StructureDefinition-ch-etoc-bodyheight-observation.md),[ChEtocBodyWeightObservation](StructureDefinition-ch-etoc-bodyweight-observation.md),[ChEtocCardiologyObservation](StructureDefinition-ch-etoc-cardiology-observation.md),[ChEtocComposition](StructureDefinition-ch-etoc-composition.md),[ChEtocDevice](StructureDefinition-ch-etoc-device.md),[ChEtocDocument](StructureDefinition-ch-etoc-document.md),[ChEtocFunctionalStatusCondition](StructureDefinition-ch-etoc-functionalstatus.md),[ChEtocImmunization](StructureDefinition-ch-etoc-immunization.md),[ChEtocLabObservation](StructureDefinition-ch-etoc-lab-observation.md),[ChEtocPastHistoryofIllnessesCondition](StructureDefinition-ch-etoc-illness.md),[ChEtocPathologyObservation](StructureDefinition-ch-etoc-pathology-observation.md),[ChEtocPregnancyExpectedDeliveryDateObservation](StructureDefinition-ch-etoc-expecteddeliverydate.md),[ChEtocPregnancyStatusObservation](StructureDefinition-ch-etoc-pregnancystatus.md),[ChEtocPrimaryDiagnosisCondition](StructureDefinition-ch-etoc-primary-diagnosis.md),[ChEtocProcedure](StructureDefinition-ch-etoc-procedure.md),[ChEtocRadiologyObservation](StructureDefinition-ch-etoc-radiology-observation.md),[ChEtocSecondaryDiagnosisCondition](StructureDefinition-ch-etoc-secondary-diagnosis.md),[ChEtocServiceRequest](StructureDefinition-ch-etoc-servicerequest.md),[ChEtocSocialHistoryCondition](StructureDefinition-ch-etoc-socialhistory.md),[ModuleQuestionnaireAttachment](Questionnaire-ch-etoc-module-attachment.md),[ModuleQuestionnaireEtocAnamnesis](Questionnaire-ch-etoc-module-anamnesis.md),[ModuleQuestionnaireEtocDiagnosis](Questionnaire-ch-etoc-module-diagnosis.md),[ModuleQuestionnaireEtocImaging](Questionnaire-ch-etoc-module-imaging.md),[ModuleQuestionnaireEtocLab](Questionnaire-ch-etoc-module-lab.md),[ModuleQuestionnaireEtocMedication](Questionnaire-ch-etoc-module-medication.md),[ModuleQuestionnaireEtocPathology](Questionnaire-ch-etoc-module-pathology.md),[ModuleQuestionnaireEtocPurpose](Questionnaire-ch-etoc-module-purpose.md),[ModuleQuestionnaireImmunization](Questionnaire-ch-etoc-module-immunizationstatus.md),[ModuleQuestionnaireallergyIntolerance](Questionnaire-ch-etoc-module-cardiology.md),[QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md)and[QuestionnaireEtoc-modular](Questionnaire-QuestionnaireEtoc-modular.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [Observation/BodyHeight](Observation-BodyHeight.md) and [Observation/BodyWeight](Observation-BodyWeight.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [ChEtocCardiologyObservation](StructureDefinition-ch-etoc-cardiology-observation.md)...Show 13 more,[ChEtocComposition](StructureDefinition-ch-etoc-composition.md),[ChEtocLabObservation](StructureDefinition-ch-etoc-lab-observation.md),[ChEtocPathologyObservation](StructureDefinition-ch-etoc-pathology-observation.md),[ChEtocPregnancyStatusObservation](StructureDefinition-ch-etoc-pregnancystatus.md),[ChEtocRadiologyObservation](StructureDefinition-ch-etoc-radiology-observation.md),[Composition/CompositionEtoc](Composition-CompositionEtoc.md),[Observation/Biopsy](Observation-Biopsy.md),[Observation/BodyHeight](Observation-BodyHeight.md),[Observation/BodyWeight](Observation-BodyWeight.md),[Observation/Electrocardiogram](Observation-Electrocardiogram.md),[Observation/HbA1c](Observation-HbA1c.md),[Observation/Hemoglobin](Observation-Hemoglobin.md)and[Observation/Imaging](Observation-Imaging.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [ChEtocComposition](StructureDefinition-ch-etoc-composition.md), [ChEtocServiceRequest](StructureDefinition-ch-etoc-servicerequest.md), [Composition/CompositionEtoc](Composition-CompositionEtoc.md) and [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/AllergyIntolerance](AllergyIntolerance-AllergyIntolerance.md)
* [Observation Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-observation-category.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [Observation/BodyHeight](Observation-BodyHeight.md) and [Observation/BodyWeight](Observation-BodyWeight.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [ChEtocServiceRequest](StructureDefinition-ch-etoc-servicerequest.md) and [ServiceRequest/ServiceRequestEtoc](ServiceRequest-ServiceRequestEtoc.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [Bundle/DocumentEtoc](Bundle-DocumentEtoc.md), [QuestionnaireEtoc](Questionnaire-QuestionnaireEtoc.md) and [QuestionnaireResponse/QuestionnaireResponseEtocTransCare](QuestionnaireResponse-QuestionnaireResponseEtocTransCare.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-etoc.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-etoc.r4b)](package.r4b.tgz) are available.

### Dependency Table







### Globals Table

*There are no Global profiles defined*

