# ch.fhir.ig.ch-alis-connect#1.0.0-ballot: CH ALIS Connect (R4)

## Pages

* [Home](index.md)
* [Mapping](mapping.md)
* [Profiles](profiles.md)
* [Extensions](extensions.md)
* [Artifacts Summary](artifacts.md)
* [Changelog](changelog.md)
* [Terminology](terminology.md)
* [Logical Models](logicalmodels.md)

## Resources

### CodeSystems

* [Leistungskatalog ambulante Arzttarife (LKAAT)](CodeSystem-LKAAT.md)
* [CH ALIS ParamTyp](CodeSystem-ch-alis-connect-paramtyp.md)
* [CH ALIS PersonTyp](CodeSystem-ch-alis-connect-persontyp.md)
* [Swiss Medical Specialties (Fachbereiche)](CodeSystem-swiss-medical-specialties.md)

### ValueSets

* [SwissMedicalSpecialities](ValueSet-SwissMedicalSpecialities.md)
* [CH ALIS ParamTyp](ValueSet-ch-alis-connect-paramtyp.md)
* [CH ALIS PersonTyp](ValueSet-ch-alis-connect-persontyp.md)
* [LKAAT](ValueSet-lkaat.md)

### Logicals

* [CH ALIS Data Type Boolean](StructureDefinition-Boolean.md)
* [CH ALIS Data Type Date](StructureDefinition-Date.md)
* [CH ALIS Data Type DateTime](StructureDefinition-DateTime.md)
* [CH ALIS Data Type Decimal](StructureDefinition-Decimal.md)
* [CH ALIS Leistungsschnittstelle - Diagnosis](StructureDefinition-Diagnosis.md)
* [CH ALIS Leistungsschnittstelle - ParameterV40](StructureDefinition-ParameterV40.md)
* [CH ALIS Leistungsschnittstelle - PersonV40](StructureDefinition-PersonV40.md)
* [CH ALIS Leistungsschnittstelle - Service](StructureDefinition-Service.md)
* [CH ALIS Leistungsschnittstelle - ServiceAssignment](StructureDefinition-ServiceAssignment.md)
* [CH ALIS Leistungsschnittstelle - SessionSectionB](StructureDefinition-SessionSectionB.md)
* [CH ALIS Data Type Text](StructureDefinition-Text.md)
* [CH ALIS Data Type UnsignedInt](StructureDefinition-UnsignedInt.md)
* [CH ALIS Leistungsschnittstelle - Visit](StructureDefinition-Visit.md)

### Resource Profiles

* [CH ALIS ChargeItem Profile](StructureDefinition-ch-alis-connect-chargeitem.md)
* [CH ALIS Condition Profile](StructureDefinition-ch-alis-connect-condition.md)
* [CH ALIS Encounter Profile](StructureDefinition-ch-alis-connect-encounter.md)
* [CH ALIS Patient Profile](StructureDefinition-ch-alis-connect-patient.md)

### Extensions

* [CH ALIS Extension DiagnosisConfidential](StructureDefinition-ch-alis-connect-ext-diagnosisconfidential.md)
* [CH ALIS Extension Form](StructureDefinition-ch-alis-connect-ext-form.md)
* [CH ALIS Extension ItemNumber](StructureDefinition-ch-alis-connect-ext-itemnumber.md)
* [CH ALIS Extension OrderDate](StructureDefinition-ch-alis-connect-ext-orderdate.md)
* [CH ALIS Extension OrderID](StructureDefinition-ch-alis-connect-ext-orderid.md)
* [CH ALIS Extension ParameterV40](StructureDefinition-ch-alis-connect-ext-parameterv40.md)
* [CH ALIS Extension RefItemNumber](StructureDefinition-ch-alis-connect-ext-refitemnumber.md)
* [CH ALIS Extension SectionCode](StructureDefinition-ch-alis-connect-ext-sectioncode.md)
* [CH ALIS Extension ServiceAssignment](StructureDefinition-ch-alis-connect-ext-serviceassignment.md)
* [CH ALIS Extension ServiceItemErrorCode](StructureDefinition-ch-alis-connect-ext-serviceitemerrorcode.md)
* [CH ALIS Extension SessionAnnexB](StructureDefinition-ch-alis-connect-ext-sessionannexb.md)
* [CH ALIS Extension SessionID](StructureDefinition-ch-alis-connect-ext-sessionid.md)
* [CH ALIS Extension Termination](StructureDefinition-ch-alis-connect-ext-termination.md)
* [CH ALIS Extension TPValue](StructureDefinition-ch-alis-connect-ext-tpvalue.md)

### ConceptMaps

* [ALIS Diagnosis to FHIR Mapping](ConceptMap-Alis2FhirDiagnosis.md)
* [ALIS ParameterV40 to FHIR Mapping](ConceptMap-Alis2FhirParameterV40.md)
* [ALIS PersonV40 to FHIR Mapping](ConceptMap-Alis2FhirPersonV40.md)
* [ALIS Service to FHIR Mapping](ConceptMap-Alis2FhirService.md)
* [ALIS ServiceAssignment to FHIR Mapping](ConceptMap-Alis2FhirServiceAssignment.md)
* [ALIS SessionSectionB to FHIR Mapping](ConceptMap-Alis2FhirSessionSectionB.md)
* [ALIS Visit to FHIR Mapping](ConceptMap-Alis2FhirVisit.md)

### ImplementationGuides

* [CH ALIS Connect (R4)](index.md)

### Examples

* [VisitLKAATIcd (Binary)](Binary-VisitLKAATIcd.md)
* [VisitLKAATIcdSessionB (Binary)](Binary-VisitLKAATIcdSessionB.md)
* [VisitLabServiceAssignment (Binary)](Binary-VisitLabServiceAssignment.md)
* [VisitPauschaleKomplett (Binary)](Binary-VisitPauschaleKomplett.md)
* [ChargeItemLKAATIcd-45679 (ChargeItem)](ChargeItem-ChargeItemLKAATIcd-45679.md)
* [ChargeItemLKAATIcd-45680 (ChargeItem)](ChargeItem-ChargeItemLKAATIcd-45680.md)
* [ChargeItemLKAATIcd (ChargeItem)](ChargeItem-ChargeItemLKAATIcd.md)
* [ChargeItemLKAATIcdSessionB-45679 (ChargeItem)](ChargeItem-ChargeItemLKAATIcdSessionB-45679.md)
* [ChargeItemLKAATIcdSessionB-45680 (ChargeItem)](ChargeItem-ChargeItemLKAATIcdSessionB-45680.md)
* [ChargeItemLKAATIcdSessionB (ChargeItem)](ChargeItem-ChargeItemLKAATIcdSessionB.md)
* [ChargeItemLabServiceAssignment (ChargeItem)](ChargeItem-ChargeItemLabServiceAssignment.md)
* [ChargeItemPauschaleKomplett (ChargeItem)](ChargeItem-ChargeItemPauschaleKomplett.md)
