# Changelog - CH IG (R4) v1.2.3

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

All significant changes to this FHIR implementation guide are documented on this page.

### STU 1 (2025-12-15)

* [#Nº](https://github.com/ahdis/ch-ig/issues): Description

