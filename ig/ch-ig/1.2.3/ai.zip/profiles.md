# Profiles - CH IG (R4) v1.2.3

* [**Table of Contents**](toc.md)
* **Profiles**

## Profiles

### Resource Profiles

* [CH IG Encounter](StructureDefinition-ch-ig-encounter.md) 
CH IG Encounter profile is just an example! 

* [CH IG Practitioner](StructureDefinition-ch-ig-practitioner.md) 
Example profile defining a Practitioner resource. 

### Data Type Profiles

