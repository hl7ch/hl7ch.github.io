# Home - CH IG (R4) v1.2.3

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-ig/ImplementationGuide/ch.fhir.ig.ch-ig | *Version*:1.2.3 |
| Draft as of 2025-12-10 | *Computable Name*:CH_IG |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

**CH IG** is a template for creating a FHIR implementation guide (IG) published by [HL7 Switzerland](https://www.hl7.ch/). 
 The source is available in the [GitHub Repository](https://github.com/ahdis/ch-ig).

For detailed instructions and best practice approaches for developing implementation guides, see the [Guidance](guidance.md) page.

**✂️ Template starts here - delete everything above for your own IG ✂️**

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in the [NPM package](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) format from [here](package.tgz).

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [CH IG Designations](CodeSystem-example.md): [DesignationsVS](ValueSet-example.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [CH_IG](index.md), [ChIgEncounter](StructureDefinition-ch-ig-encounter.md)...Show 4 more,[ChIgPractitioner](StructureDefinition-ch-ig-practitioner.md),[DesignationsCS](CodeSystem-example.md),[DesignationsVS](ValueSet-example.md)and[SctVS](ValueSet-sct.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [SctVS](ValueSet-sct.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [ResearchSubjectState](http://terminology.hl7.org/7.0.0/CodeSystem-research-subject-state.html): [Encounter/xver-encounter-r4](Encounter-xver-encounter-r4.md)
* [identifierType](http://terminology.hl7.org/7.0.0/CodeSystem-v2-0203.html): [ChIgEncounter](StructureDefinition-ch-ig-encounter.md)
* [ActCode](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ActCode.html): [Encounter/xver-encounter-r4](Encounter-xver-encounter-r4.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-ig.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-ig.r4b)](package.r4b.tgz) are available.

### Dependency Table





### Globals Table

*There are no Global profiles defined*

