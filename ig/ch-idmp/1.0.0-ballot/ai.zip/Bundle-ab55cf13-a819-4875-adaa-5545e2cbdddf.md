# Xospata 40 mg, Filmtabletten (Bundle) - CH IDMP (R5) v1.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Xospata 40 mg, Filmtabletten (Bundle)**

## Example Bundle: Xospata 40 mg, Filmtabletten (Bundle)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ab55cf13-a819-4875-adaa-5545e2cbdddf",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-bundle"]
  },
  "language" : "de-CH",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/MedicinalProductDefinition/Xospata-Filmcoatedtablet",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Xospata-Filmcoatedtablet",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-medicinalproductdefinition"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Xospata-Filmcoatedtablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Xospata-Filmcoatedtablet</b></p><a name=\"Xospata-Filmcoatedtablet\"> </a><a name=\"hcXospata-Filmcoatedtablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-medicinalproductdefinition.html\">MedicinalProductDefinition</a></p></div><p><b>CH SMC - Authorized Dose Form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10221000}\">Film-coated tablet</span></p><p><b>identifier</b>: <a href=\"NamingSystem-MPID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Medical Product Identifier</a>/CH-01100869-0672110010000</p><p><b>indication</b>: </p><div><p>Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.</p>\n</div><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply 756005034000001}\">A: Single dispensing requiring a medical or veterinary prescription</span></p><p><b>additionalMonitoringIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-additional-monitoring-indicator 756005001003}\">No Warning</span></p><p><b>pediatricUseIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-pediatric-use-indicator 756005003002}\">Not authorised for the treatment in children</span></p><p><b>classification</b>: <span title=\"Codes:{http://www.whocc.no/atc L01EX13}\">gilteritinib</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-MedicinalProductCategory 756005039000001}\">Synthetic</span></p><h3>MarketingStatuses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Status</b></td><td><b>DateRange</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-marketing-status 7560050074000003}\">No interruption of distribution reported</span></td><td>2020-09-24 --&gt; (ongoing)</td></tr></table><p><b>attachedDocument</b>: </p><ul><li><a href=\"DocumentReference-DocRef-FI-Xospata.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-idmp/sid/attno#Application / Assessment Tracking Number#123456989-initial submission-Example-xyz-123; status = current; type = Information for healthcare professionals; date = 2021-11-09 00:00:00+0000</a></li><li><a href=\"DocumentReference-DocRef-PI-Xospata.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-idmp/sid/attno#Application / Assessment Tracking Number#123456989-initial submission-Example-abc-123; status = current; type = Patient Information; date = 2021-11-09 00:00:00+0000</a></li></ul><blockquote><p><b>name</b></p><p><b>productName</b>: Xospata 40 mg, Filmtabletten</p><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 de-CH}\">German (Switzerland)</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-idmp/StructureDefinition/authorizedDoseForm",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "10221000",
            "display" : "Film-coated tablet"
          }]
        }
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/mpid",
        "value" : "CH-01100869-0672110010000"
      }],
      "indication" : "Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.",
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply",
          "code" : "756005034000001",
          "display" : "A: Single dispensing requiring a medical or veterinary prescription"
        }]
      },
      "additionalMonitoringIndicator" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-additional-monitoring-indicator",
          "code" : "756005001003",
          "display" : "No Warning"
        }]
      },
      "pediatricUseIndicator" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-pediatric-use-indicator",
          "code" : "756005003002",
          "display" : "Not authorised for the treatment in children"
        }]
      },
      "classification" : [{
        "coding" : [{
          "system" : "http://www.whocc.no/atc",
          "code" : "L01EX13"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-MedicinalProductCategory",
          "code" : "756005039000001",
          "display" : "Synthetic"
        }]
      }],
      "marketingStatus" : [{
        "country" : {
          "coding" : [{
            "system" : "urn:iso:std:iso:3166",
            "code" : "CH",
            "display" : "Switzerland"
          }]
        },
        "status" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-marketing-status",
            "code" : "7560050074000003",
            "display" : "No interruption of distribution reported"
          }]
        },
        "dateRange" : {
          "start" : "2020-09-24"
        }
      }],
      "attachedDocument" : [{
        "reference" : "DocumentReference/DocRef-FI-Xospata"
      },
      {
        "reference" : "DocumentReference/DocRef-PI-Xospata"
      }],
      "name" : [{
        "productName" : "Xospata 40 mg, Filmtabletten",
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH",
              "display" : "Switzerland"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "de-CH"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/DocumentReference/DocRef-FI-Xospata",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "DocRef-FI-Xospata",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-documentreference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_DocRef-FI-Xospata\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-FI-Xospata</b></p><a name=\"DocRef-FI-Xospata\"> </a><a name=\"hcDocRef-FI-Xospata\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456989-initial submission-Example-xyz-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type 756005040000001}\">Information for healthcare professionals</span></p><p><b>date</b>: 2021-11-09 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://Swissmedicinfo.ch/showText.aspx?textType=FI&amp;lang=DE&amp;authNr=67211&amp;supportMultipleResults=1\">https://Swissmedicinfo.ch/showText.aspx?textType=FI&amp;lang=DE&amp;authNr=67211&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/attno",
        "value" : "123456989-initial submission-Example-xyz-123"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type",
          "code" : "756005040000001",
          "display" : "Information for healthcare professionals"
        }]
      },
      "date" : "2021-11-09T00:00:00Z",
      "content" : [{
        "attachment" : {
          "url" : "https://Swissmedicinfo.ch/showText.aspx?textType=FI&lang=DE&authNr=67211&supportMultipleResults=1"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/DocumentReference/DocRef-PI-Xospata",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "DocRef-PI-Xospata",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-documentreference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_DocRef-PI-Xospata\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-PI-Xospata</b></p><a name=\"DocRef-PI-Xospata\"> </a><a name=\"hcDocRef-PI-Xospata\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456989-initial submission-Example-abc-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type 756005040000002}\">Patient Information</span></p><p><b>date</b>: 2021-11-09 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Language</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>German (Switzerland)</td><td><a href=\"https://Swissmedicinfo.ch/showText.aspx?textType=PI&amp;lang=DE&amp;authNr=67211&amp;supportMultipleResults=1\">https://Swissmedicinfo.ch/showText.aspx?textType=PI&amp;lang=DE&amp;authNr=67211&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/attno",
        "value" : "123456989-initial submission-Example-abc-123"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type",
          "code" : "756005040000002",
          "display" : "Patient Information"
        }]
      },
      "date" : "2021-11-09T00:00:00Z",
      "content" : [{
        "attachment" : {
          "language" : "de-CH",
          "url" : "https://Swissmedicinfo.ch/showText.aspx?textType=PI&lang=DE&authNr=67211&supportMultipleResults=1"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/RegulatedAuthorisation/MA-6721101",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "MA-6721101",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-regulatedauthorization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-6721101\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-6721101</b></p><a name=\"MA-6721101\"> </a><a name=\"hcMA-6721101\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/6721101</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status 756005010000001}\">approved</span></p><p><b>statusDate</b>: 2021-11-09</p><p><b>validityPeriod</b>: 2021-11-09 --&gt; (ongoing)</p><p><b>holder</b>: <a href=\"#hcMA-6721101/holder-Astellas-Pharma-AG\">Organization Astellas Pharma AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-6721101/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Astellas-Pharma-AG</b></p><a name=\"MA-6721101/holder-Astellas-Pharma-AG\"> </a><a name=\"hcMA-6721101/holder-Astellas-Pharma-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-SMCLocID.html\" title=\"Temporary NamingSystem in this implementation guide until officially released by Swissmedic\">Swissmedic Location Identifier</a>/01100869, <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010745, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001000964</p><p><b>name</b>: Astellas Pharma AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-6721101/regulator-SMC\"> </a><a name=\"hcMA-6721101/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "holder-Astellas-Pharma-AG",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://www.swissmedic.ch/fhir/identifier/locations",
          "value" : "01100869"
        },
        {
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010745"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001000964"
        }],
        "name" : "Astellas Pharma AG"
      },
      {
        "resourceType" : "Organization",
        "id" : "regulator-SMC",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010911"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001398511"
        }],
        "name" : "SMC"
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/authno",
        "value" : "6721101"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs",
          "code" : "756000002001",
          "display" : "Marketing Authorisation"
        }]
      },
      "region" : [{
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH",
          "display" : "Switzerland"
        }]
      }],
      "status" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status",
          "code" : "756005010000001",
          "display" : "approved"
        }]
      },
      "statusDate" : "2021-11-09",
      "validityPeriod" : {
        "start" : "2021-11-09"
      },
      "holder" : {
        "reference" : "#holder-Astellas-Pharma-AG"
      },
      "regulator" : {
        "reference" : "#regulator-SMC"
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/PackagedProductDefinition/PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-packagedproductdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet</b></p><a name=\"PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><a name=\"hcPMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-packagedproductdefinition.html\">PackagedProductDefinition</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-PCID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Clinical Product Identifier</a>/CH-01100869-0672110010000-0001</p><p><b>packageFor</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><p><b>containedItemQuantity</b>: 48 Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span></p><p><b>description</b>: </p><div><p>4 Blister zu 7 Tabletten in 1 Box</p>\n</div><h3>LegalStatusOfSupplies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply 756005034000001}\">A: Single dispensing requiring a medical or veterinary prescription</span></td></tr></table><h3>MarketingStatuses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Status</b></td><td><b>DateRange</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-Refdata-marketing-status 756002026002}\">Marketed</span></td><td>2020-09-24 --&gt; (ongoing)</td></tr></table><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/7.1.0/NamingSystem-gtin.html\" title=\"The GS1 GTIN is a globally unique identifier of trade items. A trade item is any item (product or service) upon which there is a need to retrieve pre-defined information and that may be priced, or ordered, or invoiced at any point in any supply chain. Note: GTINs may be used in both Codes (http://build.fhir.org/datatypes.html#Coding) and Identifiers (http://build.fhir.org/datatypes.html#Identifier).\">GTIN Global Trade Item Number</a>/7680672110011</p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30009000}\">Box</span></p><p><b>quantity</b>: 1</p><h3>ShelfLifeStorages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period[x]</b></td><td><b>SpecialPrecautionsForStorage</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/100000073343 100000073403}\">Shelf life of the medicinal product as packaged for sale</span></td><td>No display for Duration  (value: 36; unit: month; system: http://unitsofmeasure.org; code: mo)</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage 756005041000009}\">Do not store above 30°C</span></td></tr></table><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30007000}\">Blister</span></p><p><b>quantity</b>: 4</p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></td></tr></table><p><b>amount</b>: 12 countable unit(s)<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/pcid",
        "value" : "CH-01100869-0672110010000-0001"
      }],
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "containedItemQuantity" : [{
        "value" : 48,
        "unit" : "Tablet",
        "system" : "http://standardterms.edqm.eu",
        "code" : "15054000"
      }],
      "description" : "4 Blister zu 7 Tabletten in 1 Box",
      "legalStatusOfSupply" : [{
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply",
            "code" : "756005034000001",
            "display" : "A: Single dispensing requiring a medical or veterinary prescription"
          }]
        }
      }],
      "marketingStatus" : [{
        "country" : {
          "coding" : [{
            "system" : "urn:iso:std:iso:3166",
            "code" : "CH",
            "display" : "Switzerland"
          }]
        },
        "status" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-Refdata-marketing-status",
            "code" : "756002026002",
            "display" : "Marketed"
          }]
        },
        "dateRange" : {
          "start" : "2020-09-24"
        }
      }],
      "packaging" : {
        "identifier" : [{
          "system" : "https://www.gs1.org/gtin",
          "value" : "7680672110011"
        }],
        "type" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "30009000",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "shelfLifeStorage" : [{
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000073343",
              "code" : "100000073403",
              "display" : "Shelf life of the medicinal product as packaged for sale"
            }]
          },
          "periodDuration" : {
            "value" : 36,
            "unit" : "month",
            "system" : "http://unitsofmeasure.org",
            "code" : "mo"
          },
          "specialPrecautionsForStorage" : [{
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage",
              "code" : "756005041000009",
              "display" : "Do not store above 30°C"
            }]
          }]
        }],
        "packaging" : [{
          "type" : {
            "coding" : [{
              "system" : "http://standardterms.edqm.eu",
              "code" : "30007000",
              "display" : "Blister"
            }]
          },
          "quantity" : 4,
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
              }
            },
            "amount" : {
              "value" : 12,
              "unit" : "countable unit(s)",
              "system" : "http://unitsofmeasure.org",
              "code" : "1"
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/RegulatedAuthorisation/MA-67211001",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "MA-67211001",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-regulatedauthorization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-67211001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-67211001</b></p><a name=\"MA-67211001\"> </a><a name=\"hcMA-67211001\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/67211001</p><p><b>subject</b>: <a href=\"PackagedProductDefinition-PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">PackagedProductDefinition: identifier = http://fhir.ch/ig/ch-idmp/sid/pcid#Clinical Product Identifier#CH-01100869-0672110010000-0001; containedItemQuantity = 48 Tablet; description = 4 Blister zu 7 Tabletten in 1 Box</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status 756005010000001}\">approved</span></p><p><b>statusDate</b>: 2021-11-09</p><p><b>validityPeriod</b>: 2021-11-09 --&gt; (ongoing)</p><p><b>holder</b>: <a href=\"#hcMA-67211001/holder-Astellas-Pharma-AG\">Organization Astellas Pharma AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-67211001/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Astellas-Pharma-AG</b></p><a name=\"MA-67211001/holder-Astellas-Pharma-AG\"> </a><a name=\"hcMA-67211001/holder-Astellas-Pharma-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-SMCLocID.html\" title=\"Temporary NamingSystem in this implementation guide until officially released by Swissmedic\">Swissmedic Location Identifier</a>/01100869, <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010745, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001000964</p><p><b>name</b>: Astellas Pharma AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-67211001/regulator-SMC\"> </a><a name=\"hcMA-67211001/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "holder-Astellas-Pharma-AG",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://www.swissmedic.ch/fhir/identifier/locations",
          "value" : "01100869"
        },
        {
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010745"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001000964"
        }],
        "name" : "Astellas Pharma AG"
      },
      {
        "resourceType" : "Organization",
        "id" : "regulator-SMC",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010911"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001398511"
        }],
        "name" : "SMC"
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/authno",
        "value" : "67211001"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/PMP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs",
          "code" : "756000002001",
          "display" : "Marketing Authorisation"
        }]
      },
      "region" : [{
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH",
          "display" : "Switzerland"
        }]
      }],
      "status" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status",
          "code" : "756005010000001",
          "display" : "approved"
        }]
      },
      "statusDate" : "2021-11-09",
      "validityPeriod" : {
        "start" : "2021-11-09"
      },
      "holder" : {
        "reference" : "#holder-Astellas-Pharma-AG"
      },
      "regulator" : {
        "reference" : "#regulator-SMC"
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-manufactureditemdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet</b></p><a name=\"MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><a name=\"hcMI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10221000}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15054000}\">Tablet</span></p></div>"
      },
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10221000",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15054000",
          "display" : "Tablet"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-administrableproductdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet</b></p><a name=\"PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><a name=\"hcPhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-administrableproductdefinition.html\">AdministrableProductDefinition</a></p></div><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10221000}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15054000}\">Tablet</span></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20053000}\">Oral use</span></td></tr></table></div>"
      },
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10221000",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15054000",
          "display" : "Tablet"
        }]
      },
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20053000",
            "display" : "Oral use"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/GilteritinibiHemifumaras40",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "GilteritinibiHemifumaras40",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_GilteritinibiHemifumaras40\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient GilteritinibiHemifumaras40</b></p><a name=\"GilteritinibiHemifumaras40\"> </a><a name=\"hcGilteritinibiHemifumaras40\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 5RZZ0Z1GJT}\">Gilteritinib fumarate</span></td></tr></table><blockquote><p><b>strength</b></p><p><b>presentation</b>: 44.2 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span></p><blockquote><p><b>referenceStrength</b></p><h3>Substances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 66D92MGC8M}\">Gilteritinib</span></td></tr></table><p><b>strength</b>: 40 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span></p></blockquote></blockquote></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000001",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "5RZZ0Z1GJT",
              "display" : "Gilteritinib fumarate"
            }]
          }
        },
        "strength" : [{
          "presentationRatio" : {
            "numerator" : {
              "value" : 44.2,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "tablet",
              "system" : "http://standardterms.edqm.eu",
              "code" : "15054000"
            }
          },
          "referenceStrength" : [{
            "substance" : {
              "concept" : {
                "coding" : [{
                  "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
                  "code" : "66D92MGC8M",
                  "display" : "Gilteritinib"
                }]
              }
            },
            "strengthRatio" : {
              "numerator" : {
                "value" : 40,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "tablet",
                "system" : "http://standardterms.edqm.eu",
                "code" : "15054000"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Mannitolum",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Mannitolum",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Mannitolum\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Mannitolum</b></p><a name=\"Mannitolum\"> </a><a name=\"hcMannitolum\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 3OWL53L36A}\">Mannitol</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "3OWL53L36A",
              "display" : "Mannitol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Hydroxypropylcellulosum",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Hydroxypropylcellulosum",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Hydroxypropylcellulosum\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Hydroxypropylcellulosum</b></p><a name=\"Hydroxypropylcellulosum\"> </a><a name=\"hcHydroxypropylcellulosum\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 9XZ8H6N6OH}\">Hyprolose</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "9XZ8H6N6OH",
              "display" : "Hyprolose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/HydroxypropylcellulosumSubstitutumHumile",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "HydroxypropylcellulosumSubstitutumHumile",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_HydroxypropylcellulosumSubstitutumHumile\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient HydroxypropylcellulosumSubstitutumHumile</b></p><a name=\"HydroxypropylcellulosumSubstitutumHumile\"> </a><a name=\"hcHydroxypropylcellulosumSubstitutumHumile\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 2165RE0K14}\">Hydroxypropylcellulose, low-substituted</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "2165RE0K14",
              "display" : "Hydroxypropylcellulose, low-substituted"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Talcum",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Talcum",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Talcum\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Talcum</b></p><a name=\"Talcum\"> </a><a name=\"hcTalcum\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 7SEV7J4R1U}\">Talc</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "7SEV7J4R1U",
              "display" : "Talc"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Macrogolum8000",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Macrogolum8000",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Macrogolum8000\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Macrogolum8000</b></p><a name=\"Macrogolum8000\"> </a><a name=\"hcMacrogolum8000\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance Q662QK8M3B}\">Macrogol 8000</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "Q662QK8M3B",
              "display" : "Macrogol 8000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/E171",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "E171",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_E171\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient E171</b></p><a name=\"E171\"> </a><a name=\"hcE171\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 15FIX9V2JP}\">Titanium dioxide</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "15FIX9V2JP",
              "display" : "Titanium dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/E172Flavum",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "E172Flavum",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_E172Flavum\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient E172Flavum</b></p><a name=\"E172Flavum\"> </a><a name=\"hcE172Flavum\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 15FIX9V2JP}\">Titanium dioxide</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "15FIX9V2JP",
              "display" : "Titanium dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/MagnesiumStearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "MagnesiumStearate",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_MagnesiumStearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient MagnesiumStearate</b></p><a name=\"MagnesiumStearate\"> </a><a name=\"hcMagnesiumStearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Hypromellosum",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Hypromellosum",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Hypromellosum\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Hypromellosum</b></p><a name=\"Hypromellosum\"> </a><a name=\"hcHypromellosum\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 3NXW29V3WO}\">Hypromellose</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "3NXW29V3WO",
              "display" : "Hypromellose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10081514",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10081514",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10081514\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10081514</b></p><a name=\"IND-10081514\"> </a><a name=\"hcIND-10081514\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10081514}\">Acute myeloid leukemia refractory</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10081514",
              "display" : "Acute myeloid leukemia refractory"
            }]
          }
        },
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10081513",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10081513",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10081513\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10081513</b></p><a name=\"IND-10081513\"> </a><a name=\"hcIND-10081513\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10081513}\">Acute myeloid leukaemia refractory</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10081513",
              "display" : "Acute myeloid leukaemia refractory"
            }]
          }
        },
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10059034",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10059034",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10059034\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10059034</b></p><a name=\"IND-10059034\"> </a><a name=\"hcIND-10059034\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10059034}\">Acute myeloid leukaemia recurrent</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10059034",
              "display" : "Acute myeloid leukaemia recurrent"
            }]
          }
        },
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10060558",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10060558",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10060558\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10060558</b></p><a name=\"IND-10060558\"> </a><a name=\"hcIND-10060558\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10060558}\">Acute myeloid leukemia recurrent</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10060558",
              "display" : "Acute myeloid leukemia recurrent"
            }]
          }
        },
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10084619",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10084619",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10084619\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10084619</b></p><a name=\"IND-10084619\"> </a><a name=\"hcIND-10084619\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Xospata-Filmcoatedtablet.html\">MedicinalProductDefinition: extension = Film-coated tablet; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-01100869-0672110010000; indication = Xospata wird angewendet für die Behandlung von erwachsenen Patienten, die an rezidivierter oder refraktärer akuter myeloider Leukämie (AML) mit FMS-ähnlichen Tyrosinkinase 3 (FLT3)-Mutationen leiden.; legalStatusOfSupply = A: Single dispensing requiring a medical or veterinary prescription; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = gilteritinib,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10084619}\">FLT3-Gen-Mutation</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Xospata-Filmcoatedtablet"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10084619",
              "display" : "FLT3-Gen-Mutation"
            }]
          }
        },
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  }]
}

```
