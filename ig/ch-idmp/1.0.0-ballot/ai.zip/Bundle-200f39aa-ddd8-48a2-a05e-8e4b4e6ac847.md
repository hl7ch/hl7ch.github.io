# Comprehensive Sample Product, Creme and Pessary (Bundle) - CH IDMP (R5) v1.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Comprehensive Sample Product, Creme and Pessary (Bundle)**

## Example Bundle: Comprehensive Sample Product, Creme and Pessary (Bundle)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "200f39aa-ddd8-48a2-a05e-8e4b4e6ac847",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-bundle"]
  },
  "language" : "de-CH",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/MedicinalProductDefinition/Comprehensive-Sample-Combipack",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Comprehensive-Sample-Combipack",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-medicinalproductdefinition"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Comprehensive-Sample-Combipack\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Comprehensive-Sample-Combipack</b></p><a name=\"Comprehensive-Sample-Combipack\"> </a><a name=\"hcComprehensive-Sample-Combipack\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-medicinalproductdefinition.html\">MedicinalProductDefinition</a></p></div><p><b>CH SMC - Authorized Dose Form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 14001000}\">Cream + Pessary</span></p><p><b>identifier</b>: <a href=\"NamingSystem-MPID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Medical Product Identifier</a>/CH-11111111-1234560010000</p><p><b>combinedPharmaceuticalDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 14001000}\">Cream + Pessary</span></p><p><b>indication</b>: </p><div><p>Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose)</p>\n</div><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply 756005034000005}\">D: Dispensed following expert advice</span></p><p><b>additionalMonitoringIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-additional-monitoring-indicator 756005001003}\">No Warning</span></p><p><b>pediatricUseIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-pediatric-use-indicator 756005003002}\">Not authorised for the treatment in children</span></p><p><b>classification</b>: <span title=\"Codes:{http://www.whocc.no/atc G01AA01}\">nystatin</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-category 756005011000015}\">NA NAS</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-MedicinalProductCategory 756005039000001}\">Synthetic</span></p><h3>MarketingStatuses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Status</b></td><td><b>DateRange</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-marketing-status 7560050074000003}\">No interruption of distribution reported</span></td><td>2020-09-24 --&gt; 2026-12-31</td></tr></table><p><b>attachedDocument</b>: </p><ul><li><a href=\"DocumentReference-DocRef-FI-Comprehensive.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-idmp/sid/attno#Application / Assessment Tracking Number#999999999-FI-123; status = current; type = Information for healthcare professionals; date = 2023-07-01 00:00:00+0000</a></li><li><a href=\"DocumentReference-DocRef-PI-Comprehensive.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-idmp/sid/attno#Application / Assessment Tracking Number#999999999-PI-123; status = current; type = Patient Information; date = 2023-07-01 00:00:00+0000</a></li></ul><blockquote><p><b>name</b></p><p><b>productName</b>: Comprehensive Sample Combipack 20 mg Vaginal  Salbe und 100 mg Vaginaltabletten</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-medicinal-product-name-type SMC}\">Authorised Medicinal Product Name</span></p><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 de-CH}\">German (Switzerland)</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-idmp/StructureDefinition/authorizedDoseForm",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "14001000",
            "display" : "Cream + Pessary"
          }]
        }
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/mpid",
        "value" : "CH-11111111-1234560010000"
      }],
      "combinedPharmaceuticalDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "14001000",
          "display" : "Cream + Pessary"
        }]
      },
      "indication" : "Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose)",
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply",
          "code" : "756005034000005",
          "display" : "D: Dispensed following expert advice"
        }]
      },
      "additionalMonitoringIndicator" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-additional-monitoring-indicator",
          "code" : "756005001003",
          "display" : "No Warning"
        }]
      },
      "pediatricUseIndicator" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-pediatric-use-indicator",
          "code" : "756005003002",
          "display" : "Not authorised for the treatment in children"
        }]
      },
      "classification" : [{
        "coding" : [{
          "system" : "http://www.whocc.no/atc",
          "code" : "G01AA01"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-category",
          "code" : "756005011000015",
          "display" : "NA NAS"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-MedicinalProductCategory",
          "code" : "756005039000001",
          "display" : "Synthetic"
        }]
      }],
      "marketingStatus" : [{
        "country" : {
          "coding" : [{
            "system" : "urn:iso:std:iso:3166",
            "code" : "CH",
            "display" : "Switzerland"
          }]
        },
        "status" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-marketing-status",
            "code" : "7560050074000003",
            "display" : "No interruption of distribution reported"
          }]
        },
        "dateRange" : {
          "start" : "2020-09-24",
          "end" : "2026-12-31"
        }
      }],
      "attachedDocument" : [{
        "reference" : "DocumentReference/DocRef-FI-Comprehensive"
      },
      {
        "reference" : "DocumentReference/DocRef-PI-Comprehensive"
      }],
      "name" : [{
        "productName" : "Comprehensive Sample Combipack 20 mg Vaginal  Salbe und 100 mg Vaginaltabletten",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-medicinal-product-name-type",
            "code" : "SMC",
            "display" : "Authorised Medicinal Product Name"
          }]
        },
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH",
              "display" : "Switzerland"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "de-CH"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/DocumentReference/DocRef-FI-Comprehensive",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "DocRef-FI-Comprehensive",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-documentreference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_DocRef-FI-Comprehensive\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-FI-Comprehensive</b></p><a name=\"DocRef-FI-Comprehensive\"> </a><a name=\"hcDocRef-FI-Comprehensive\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/999999999-FI-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type 756005040000001}\">Information for healthcare professionals</span></p><p><b>date</b>: 2023-07-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Language</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>German (Switzerland)</td><td><a href=\"https://swissmedicinfo-pro.ch/showText.aspx?textType=FI&amp;lang=DE&amp;authNr=69093&amp;supportMultipleResults=1\">https://swissmedicinfo-pro.ch/showText.aspx?textType=FI&amp;lang=DE&amp;authNr=69093&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/attno",
        "value" : "999999999-FI-123"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type",
          "code" : "756005040000001",
          "display" : "Information for healthcare professionals"
        }]
      },
      "date" : "2023-07-01T00:00:00Z",
      "content" : [{
        "attachment" : {
          "language" : "de-CH",
          "url" : "https://swissmedicinfo-pro.ch/showText.aspx?textType=FI&lang=DE&authNr=69093&supportMultipleResults=1"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/DocumentReference/DocRef-PI-Comprehensive",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "DocRef-PI-Comprehensive",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-documentreference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_DocRef-PI-Comprehensive\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-PI-Comprehensive</b></p><a name=\"DocRef-PI-Comprehensive\"> </a><a name=\"hcDocRef-PI-Comprehensive\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/999999999-PI-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type 756005040000002}\">Patient Information</span></p><p><b>date</b>: 2023-07-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Language</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>German (Switzerland)</td><td><a href=\"https://swissmedicinfo.ch/detailpage/69093002\">https://swissmedicinfo.ch/detailpage/69093002</a></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/attno",
        "value" : "999999999-PI-123"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-attached-document-type",
          "code" : "756005040000002",
          "display" : "Patient Information"
        }]
      },
      "date" : "2023-07-01T00:00:00Z",
      "content" : [{
        "attachment" : {
          "language" : "de-CH",
          "url" : "https://swissmedicinfo.ch/detailpage/69093002"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/RegulatedAuthorisation/MA-12345601",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "MA-12345601",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-regulatedauthorization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-12345601\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-12345601</b></p><a name=\"MA-12345601\"> </a><a name=\"hcMA-12345601\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/12345601</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status 756005010000001}\">approved</span></p><p><b>statusDate</b>: 2023-11-07</p><p><b>validityPeriod</b>: 2023-11-07 --&gt; 2028-11-06</p><p><b>holder</b>: <a href=\"#hcMA-12345601/holder-Example-AG\">Organization Example AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-12345601/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Example-AG</b></p><a name=\"MA-12345601/holder-Example-AG\"> </a><a name=\"hcMA-12345601/holder-Example-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-SMCLocID.html\" title=\"Temporary NamingSystem in this implementation guide until officially released by Swissmedic\">Swissmedic Location Identifier</a>/12345678, <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/0123456789, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601123456789</p><p><b>name</b>: Example AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-12345601/regulator-SMC\"> </a><a name=\"hcMA-12345601/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "holder-Example-AG",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://www.swissmedic.ch/fhir/identifier/locations",
          "value" : "12345678"
        },
        {
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "0123456789"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601123456789"
        }],
        "name" : "Example AG"
      },
      {
        "resourceType" : "Organization",
        "id" : "regulator-SMC",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010911"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001398511"
        }],
        "name" : "SMC"
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/authno",
        "value" : "12345601"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs",
          "code" : "756000002001",
          "display" : "Marketing Authorisation"
        }]
      },
      "region" : [{
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH",
          "display" : "Switzerland"
        }]
      }],
      "status" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status",
          "code" : "756005010000001",
          "display" : "approved"
        }]
      },
      "statusDate" : "2023-11-07",
      "validityPeriod" : {
        "start" : "2023-11-07",
        "end" : "2028-11-06"
      },
      "holder" : {
        "reference" : "#holder-Example-AG"
      },
      "regulator" : {
        "reference" : "#regulator-SMC"
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/PackagedProductDefinition/PMP-Comprehensive-Sample-Combipack",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "PMP-Comprehensive-Sample-Combipack",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-packagedproductdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_PMP-Comprehensive-Sample-Combipack\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition PMP-Comprehensive-Sample-Combipack</b></p><a name=\"PMP-Comprehensive-Sample-Combipack\"> </a><a name=\"hcPMP-Comprehensive-Sample-Combipack\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-packagedproductdefinition.html\">PackagedProductDefinition</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-PCID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Clinical Product Identifier</a>/CH-11111111-1234560010000-0002</p><p><b>packageFor</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><p><b>containedItemQuantity</b>: 1 Tube<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15058000 = 'Tube')</span>, 6 Vaginal Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span></p><p><b>description</b>: </p><div><p>Comprehensive Sample Combipack 40 g Salbe und 3 x 2 Vaginalzäpfchen</p>\n</div><h3>LegalStatusOfSupplies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply 756005034000005}\">D: Dispensed following expert advice</span></td></tr></table><h3>MarketingStatuses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Status</b></td><td><b>DateRange</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-Refdata-marketing-status 756002026002}\">Marketed</span></td><td>2020-09-24 --&gt; 2026-12-31</td></tr></table><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/7.1.0/NamingSystem-gtin.html\" title=\"The GS1 GTIN is a globally unique identifier of trade items. A trade item is any item (product or service) upon which there is a need to retrieve pre-defined information and that may be priced, or ordered, or invoiced at any point in any supply chain. Note: GTINs may be used in both Codes (http://build.fhir.org/datatypes.html#Coding) and Identifiers (http://build.fhir.org/datatypes.html#Identifier).\">GTIN Global Trade Item Number</a>/7680612345678</p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30009000}\">Box</span></p><p><b>quantity</b>: 1</p><h3>ShelfLifeStorages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period[x]</b></td><td><b>SpecialPrecautionsForStorage</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/100000073343 100000073403}\">Shelf life of the medicinal product as packaged for sale</span></td><td>No display for Duration  (value: 24; unit: month; system: http://unitsofmeasure.org; code: mo)</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage 756005041000006}\">at room temperature (15 - 25°C)</span></td></tr><tr><td style=\"display: none\">*</td><td> </td><td> </td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage 756005041000004}\">protect from light</span></td></tr><tr><td style=\"display: none\">*</td><td> </td><td> </td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage 756005041000011}\">Store in the original container</span></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/100000073343 100000073404}\">Shelf life after first opening the immediate packaging</span></td><td>No display for Duration  (value: 6; unit: month; system: http://unitsofmeasure.org; code: mo)</td><td> </td></tr></table><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15007000}\">Blister</span></p><p><b>quantity</b>: 3</p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalPessary.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Pessary; unitOfPresentation = Pessary</a></td></tr></table><p><b>amount</b>: 2 countable unit(s)<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></blockquote><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15058000}\">Tube</span></p><p><b>quantity</b>: 1</p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></td></tr></table><p><b>amount</b>: 10 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p></blockquote></blockquote></blockquote><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30054000}\">Sachet</span></p><p><b>quantity</b>: 1</p></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/pcid",
        "value" : "CH-11111111-1234560010000-0002"
      }],
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "containedItemQuantity" : [{
        "value" : 1,
        "unit" : "Tube",
        "system" : "http://standardterms.edqm.eu",
        "code" : "15058000"
      },
      {
        "value" : 6,
        "unit" : "Vaginal Tablet",
        "system" : "http://standardterms.edqm.eu",
        "code" : "15054000"
      }],
      "description" : "Comprehensive Sample Combipack 40 g Salbe und 3 x 2 Vaginalzäpfchen",
      "legalStatusOfSupply" : [{
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-legal-status-of-supply",
            "code" : "756005034000005",
            "display" : "D: Dispensed following expert advice"
          }]
        }
      }],
      "marketingStatus" : [{
        "country" : {
          "coding" : [{
            "system" : "urn:iso:std:iso:3166",
            "code" : "CH",
            "display" : "Switzerland"
          }]
        },
        "status" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-Refdata-marketing-status",
            "code" : "756002026002",
            "display" : "Marketed"
          }]
        },
        "dateRange" : {
          "start" : "2020-09-24",
          "end" : "2026-12-31"
        }
      }],
      "packaging" : {
        "identifier" : [{
          "system" : "https://www.gs1.org/gtin",
          "value" : "7680612345678"
        }],
        "type" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "30009000",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "shelfLifeStorage" : [{
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000073343",
              "code" : "100000073403",
              "display" : "Shelf life of the medicinal product as packaged for sale"
            }]
          },
          "periodDuration" : {
            "value" : 24,
            "unit" : "month",
            "system" : "http://unitsofmeasure.org",
            "code" : "mo"
          },
          "specialPrecautionsForStorage" : [{
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage",
              "code" : "756005041000006",
              "display" : "at room temperature (15 - 25°C)"
            }]
          }]
        },
        {
          "specialPrecautionsForStorage" : [{
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage",
              "code" : "756005041000004",
              "display" : "protect from light"
            }]
          }]
        },
        {
          "specialPrecautionsForStorage" : [{
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-special-precautions-for-storage",
              "code" : "756005041000011",
              "display" : "Store in the original container"
            }]
          }]
        },
        {
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000073343",
              "code" : "100000073404",
              "display" : "Shelf life after first opening the immediate packaging"
            }]
          },
          "periodDuration" : {
            "value" : 6,
            "unit" : "month",
            "system" : "http://unitsofmeasure.org",
            "code" : "mo"
          }
        }],
        "packaging" : [{
          "type" : {
            "coding" : [{
              "system" : "http://standardterms.edqm.eu",
              "code" : "15007000",
              "display" : "Blister"
            }]
          },
          "quantity" : 3,
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalPessary"
              }
            },
            "amount" : {
              "value" : 2,
              "unit" : "countable unit(s)",
              "system" : "http://unitsofmeasure.org",
              "code" : "1"
            }
          }],
          "packaging" : [{
            "type" : {
              "coding" : [{
                "system" : "http://standardterms.edqm.eu",
                "code" : "15058000",
                "display" : "Tube"
              }]
            },
            "quantity" : 1,
            "containedItem" : [{
              "item" : {
                "reference" : {
                  "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
                }
              },
              "amount" : {
                "value" : 10,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              }
            }]
          }]
        },
        {
          "type" : {
            "coding" : [{
              "system" : "http://standardterms.edqm.eu",
              "code" : "30054000",
              "display" : "Sachet"
            }]
          },
          "quantity" : 1
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/RegulatedAuthorisation/MA-123456002",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "MA-123456002",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-regulatedauthorization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-123456002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-123456002</b></p><a name=\"MA-123456002\"> </a><a name=\"hcMA-123456002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/123456002</p><p><b>subject</b>: <a href=\"PackagedProductDefinition-PMP-Comprehensive-Sample-Combipack.html\">PackagedProductDefinition: identifier = http://fhir.ch/ig/ch-idmp/sid/pcid#Clinical Product Identifier#CH-11111111-1234560010000-0002; containedItemQuantity = 1 Tube,6 Vaginal Tablet; description = Comprehensive Sample Combipack 40 g Salbe und 3 x 2 Vaginalzäpfchen</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status 756005010000001}\">approved</span></p><p><b>statusDate</b>: 2023-11-07</p><p><b>validityPeriod</b>: 2023-11-07 --&gt; 2028-11-06</p><p><b>holder</b>: <a href=\"#hcMA-123456002/holder-Example-AG\">Organization Example AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-123456002/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Example-AG</b></p><a name=\"MA-123456002/holder-Example-AG\"> </a><a name=\"hcMA-123456002/holder-Example-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-SMCLocID.html\" title=\"Temporary NamingSystem in this implementation guide until officially released by Swissmedic\">Swissmedic Location Identifier</a>/12345678, <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/0123456789, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601123456789</p><p><b>name</b>: Example AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-123456002/regulator-SMC\"> </a><a name=\"hcMA-123456002/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-organization.html\">Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "holder-Example-AG",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://www.swissmedic.ch/fhir/identifier/locations",
          "value" : "12345678"
        },
        {
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "0123456789"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601123456789"
        }],
        "name" : "Example AG"
      },
      {
        "resourceType" : "Organization",
        "id" : "regulator-SMC",
        "meta" : {
          "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-organization"]
        },
        "identifier" : [{
          "system" : "https://spor.ema.europa.eu/v1/locations",
          "value" : "100010911"
        },
        {
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601001398511"
        }],
        "name" : "SMC"
      }],
      "identifier" : [{
        "system" : "http://fhir.ch/ig/ch-idmp/sid/authno",
        "value" : "123456002"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/PMP-Comprehensive-Sample-Combipack"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-authorisation-type-cs",
          "code" : "756000002001",
          "display" : "Marketing Authorisation"
        }]
      },
      "region" : [{
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH",
          "display" : "Switzerland"
        }]
      }],
      "status" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-authorisation-status",
          "code" : "756005010000001",
          "display" : "approved"
        }]
      },
      "statusDate" : "2023-11-07",
      "validityPeriod" : {
        "start" : "2023-11-07",
        "end" : "2028-11-06"
      },
      "holder" : {
        "reference" : "#holder-Example-AG"
      },
      "regulator" : {
        "reference" : "#regulator-SMC"
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalPessary",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "MI-Comprehensive-Sample-VaginalPessary",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-manufactureditemdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Comprehensive-Sample-VaginalPessary\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Comprehensive-Sample-VaginalPessary</b></p><a name=\"MI-Comprehensive-Sample-VaginalPessary\"> </a><a name=\"hcMI-Comprehensive-Sample-VaginalPessary\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10909000}\">Pessary</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15039000}\">Pessary</span></p></div>"
      },
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10909000",
          "display" : "Pessary"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15039000",
          "display" : "Pessary"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "MI-Comprehensive-Sample-VaginalCream",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-manufactureditemdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Comprehensive-Sample-VaginalCream\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Comprehensive-Sample-VaginalCream</b></p><a name=\"MI-Comprehensive-Sample-VaginalCream\"> </a><a name=\"hcMI-Comprehensive-Sample-VaginalCream\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10901000}\">Vaginal Cream</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15058000}\">Tube</span></p></div>"
      },
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10901000",
          "display" : "Vaginal Cream"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15058000",
          "display" : "Tube"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalPessary",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "PhP-Comprehensive-Sample-VaginalPessary",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-administrableproductdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_PhP-Comprehensive-Sample-VaginalPessary\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition PhP-Comprehensive-Sample-VaginalPessary</b></p><a name=\"PhP-Comprehensive-Sample-VaginalPessary\"> </a><a name=\"hcPhP-Comprehensive-Sample-VaginalPessary\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-administrableproductdefinition.html\">AdministrableProductDefinition</a></p></div><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10909000}\">Pessary</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15039000}\">Pessary</span></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20072000}\">Vaginal use</span></td></tr></table></div>"
      },
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10909000",
          "display" : "Pessary"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15039000",
          "display" : "Pessary"
        }]
      },
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20072000",
            "display" : "Vaginal use"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "PhP-Comprehensive-Sample-VaginalCream",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-administrableproductdefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_PhP-Comprehensive-Sample-VaginalCream\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition PhP-Comprehensive-Sample-VaginalCream</b></p><a name=\"PhP-Comprehensive-Sample-VaginalCream\"> </a><a name=\"hcPhP-Comprehensive-Sample-VaginalCream\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-administrableproductdefinition.html\">AdministrableProductDefinition</a></p></div><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10901000}\">Vaginal Cream</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15058000}\">Tube</span></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20072000}\">Vaginal use</span></td></tr></table></div>"
      },
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10901000",
          "display" : "Vaginal Cream"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "15058000",
          "display" : "Tube"
        }]
      },
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20072000",
            "display" : "Vaginal use"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/ClindamycinPhosphate100",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ClindamycinPhosphate100",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ClindamycinPhosphate100\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ClindamycinPhosphate100</b></p><a name=\"ClindamycinPhosphate100\"> </a><a name=\"hcClindamycinPhosphate100\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalPessary.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Pessary; unitOfPresentation = Pessary</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalPessary.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Pessary; unitOfPresentation = Pessary</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance EH6D7113I8}\">Clindamycin phosphate</span></td></tr></table><blockquote><p><b>strength</b></p><blockquote><p><b>referenceStrength</b></p><h3>Substances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 3U02EL437C}\">Clindamycin</span></td></tr></table><p><b>strength</b>: 100 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Pessary<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15039000 = 'Pessary')</span></p></blockquote></blockquote></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalPessary"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalPessary"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000001",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "EH6D7113I8",
              "display" : "Clindamycin phosphate"
            }]
          }
        },
        "strength" : [{
          "referenceStrength" : [{
            "substance" : {
              "concept" : {
                "coding" : [{
                  "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
                  "code" : "3U02EL437C",
                  "display" : "Clindamycin"
                }]
              }
            },
            "strengthRatio" : {
              "numerator" : {
                "value" : 100,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "Pessary",
                "system" : "http://standardterms.edqm.eu",
                "code" : "15039000"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/HardFat",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "HardFat",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_HardFat\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient HardFat</b></p><a name=\"HardFat\"> </a><a name=\"hcHardFat\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalPessary.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Pessary; unitOfPresentation = Pessary</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalPessary.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Pessary; unitOfPresentation = Pessary</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 8334LX7S21}\">Hard Fat</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalPessary"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalPessary"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "8334LX7S21",
              "display" : "Hard Fat"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/ClindamycinPhosphate20",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ClindamycinPhosphate20",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ClindamycinPhosphate20\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ClindamycinPhosphate20</b></p><a name=\"ClindamycinPhosphate20\"> </a><a name=\"hcClindamycinPhosphate20\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance EH6D7113I8}\">Clindamycin phosphate</span></td></tr></table><blockquote><p><b>strength</b></p><p><b>presentation</b>: 950.4 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tube<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15058000 = 'Tube')</span></p><p><b>concentration</b>: 23.76 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></p><blockquote><p><b>referenceStrength</b></p><h3>Substances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 3U02EL437C}\">Clindamycin</span></td></tr></table><p><b>strength</b>: 800 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tube<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15058000 = 'Tube')</span></p></blockquote><blockquote><p><b>referenceStrength</b></p><h3>Substances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 3U02EL437C}\">Clindamycin</span></td></tr></table><p><b>strength</b>: 20 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></p></blockquote></blockquote></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000001",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "EH6D7113I8",
              "display" : "Clindamycin phosphate"
            }]
          }
        },
        "strength" : [{
          "presentationRatio" : {
            "numerator" : {
              "value" : 950.4,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Tube",
              "system" : "http://standardterms.edqm.eu",
              "code" : "15058000"
            }
          },
          "concentrationRatio" : {
            "numerator" : {
              "value" : 23.76,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "g",
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            }
          },
          "referenceStrength" : [{
            "substance" : {
              "concept" : {
                "coding" : [{
                  "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
                  "code" : "3U02EL437C",
                  "display" : "Clindamycin"
                }]
              }
            },
            "strengthRatio" : {
              "numerator" : {
                "value" : 800,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "Tube",
                "system" : "http://standardterms.edqm.eu",
                "code" : "15058000"
              }
            }
          },
          {
            "substance" : {
              "concept" : {
                "coding" : [{
                  "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
                  "code" : "3U02EL437C",
                  "display" : "Clindamycin"
                }]
              }
            },
            "strengthRatio" : {
              "numerator" : {
                "value" : 20,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "g",
                "system" : "http://unitsofmeasure.org",
                "code" : "g"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/BenzylAlcohol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "BenzylAlcohol",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_BenzylAlcohol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient BenzylAlcohol</b></p><a name=\"BenzylAlcohol\"> </a><a name=\"hcBenzylAlcohol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance LKG8494WBH}\">Benzyl Alcohol</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "LKG8494WBH",
              "display" : "Benzyl Alcohol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/SorbitanStearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "SorbitanStearate",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_SorbitanStearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient SorbitanStearate</b></p><a name=\"SorbitanStearate\"> </a><a name=\"hcSorbitanStearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance NVZ4I0H58X}\">Sorbitan monostearate</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "NVZ4I0H58X",
              "display" : "Sorbitan monostearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Polysorbate60",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Polysorbate60",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Polysorbate60\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Polysorbate60</b></p><a name=\"Polysorbate60\"> </a><a name=\"hcPolysorbate60\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance CAL22UVI4M}\">Polysorbate 60</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "CAL22UVI4M",
              "display" : "Polysorbate 60"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/PropyleneGlycol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "PropyleneGlycol",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_PropyleneGlycol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient PropyleneGlycol</b></p><a name=\"PropyleneGlycol\"> </a><a name=\"hcPropyleneGlycol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 6DC9Q167V3}\">Propylene Glycol</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "6DC9Q167V3",
              "display" : "Propylene Glycol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/StearicAcid",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "StearicAcid",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_StearicAcid\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient StearicAcid</b></p><a name=\"StearicAcid\"> </a><a name=\"hcStearicAcid\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 4ELV7Z65AP}\">Stearic Acid</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "4ELV7Z65AP",
              "display" : "Stearic Acid"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/CetostaerylAlcohol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "CetostaerylAlcohol",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_CetostaerylAlcohol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient CetostaerylAlcohol</b></p><a name=\"CetostaerylAlcohol\"> </a><a name=\"hcCetostaerylAlcohol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 2DMT128M1S}\">CETOSTEARYL ALCOHOL</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "2DMT128M1S",
              "display" : "CETOSTEARYL ALCOHOL"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/CetylPalmitate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "CetylPalmitate",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_CetylPalmitate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient CetylPalmitate</b></p><a name=\"CetylPalmitate\"> </a><a name=\"hcCetylPalmitate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Comprehensive-Sample-VaginalCream.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li><li><a href=\"ManufacturedItemDefinition-MI-Comprehensive-Sample-VaginalCream.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Vaginal Cream; unitOfPresentation = Tube</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 5ZA2S6B08X}\">CETYL PALMITATE</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Comprehensive-Sample-VaginalCream"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Comprehensive-Sample-VaginalCream"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "5ZA2S6B08X",
              "display" : "CETYL PALMITATE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/LiquidParaffin",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "LiquidParaffin",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_LiquidParaffin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient LiquidParaffin</b></p><a name=\"LiquidParaffin\"> </a><a name=\"hcLiquidParaffin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance T5L8T28FGP}\">LIQUID PARAFFIN</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "T5L8T28FGP",
              "display" : "LIQUID PARAFFIN"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/Ingredient/Water",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "Water",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-ingredient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Water\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Water</b></p><a name=\"Water\"> </a><a name=\"hcWater\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"ManufacturedItemDefinition-MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role 756005035000002}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance 059QF0KO0R}\">Water</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "for" : [{
        "reference" : "AdministrableProductDefinition/PhP-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      },
      {
        "reference" : "ManufacturedItemDefinition/MI-Gilteritinibi-hemifumaras-40-Filmcoatedtablet"
      }],
      "role" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-ingredient-role",
          "code" : "756005035000002",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "http://fhir.ch/ig/ch-idmp/CodeSystem/ch-SMC-substance",
              "code" : "059QF0KO0R",
              "display" : "Water"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10004055",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10004055",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10004055\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10004055</b></p><a name=\"IND-10004055\"> </a><a name=\"hcIND-10004055\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10004055}\">Bacterial vaginosis</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10038141}\">Recurrent UTI</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10004055",
              "display" : "Bacterial vaginosis"
            }]
          }
        },
        "comorbidity" : [{
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10038141",
              "display" : "Recurrent UTI"
            }]
          }
        }],
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10046961",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10046961",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10046961\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10046961</b></p><a name=\"IND-10046961\"> </a><a name=\"hcIND-10046961\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10046961}\">Vaginosis bacterial NOS</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10029883}\">Obesity</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10046961",
              "display" : "Vaginosis bacterial NOS"
            }]
          }
        },
        "comorbidity" : [{
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10029883",
              "display" : "Obesity"
            }]
          }
        }],
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10079528",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10079528",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10079528\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10079528</b></p><a name=\"IND-10079528\"> </a><a name=\"hcIND-10079528\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org IND-10079528}\">Bacterial vulvovaginitis</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10012601}\">Diabetes mellitus</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "IND-10079528",
              "display" : "Bacterial vulvovaginitis"
            }]
          }
        },
        "comorbidity" : [{
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10012601",
              "display" : "Diabetes mellitus"
            }]
          }
        }],
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10046950",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10046950",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10046950\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10046950</b></p><a name=\"IND-10046950\"> </a><a name=\"hcIND-10046950\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10046950}\">Vaginitis</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10020161}\">HIV infection</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10046950",
              "display" : "Vaginitis"
            }]
          }
        },
        "comorbidity" : [{
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10020161",
              "display" : "HIV infection"
            }]
          }
        }],
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch-idmp.smc.admin.ch/ClinicalUseDefinition/IND-10050348",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "IND-10050348",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-idmp/StructureDefinition/ch-idmp-clinicalusedefinition-indication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10050348\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10050348</b></p><a name=\"IND-10050348\"> </a><a name=\"hcIND-10050348\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Comprehensive-Sample-Combipack.html\">MedicinalProductDefinition: extension = Cream + Pessary; identifier = http://fhir.ch/ig/ch-idmp/sid/mpid#Medical Product Identifier#CH-11111111-1234560010000; combinedPharmaceuticalDoseForm = Cream + Pessary; indication = Comprehensive Sample Combipack wird angewendet zur Behandlung der bakteriellen Vaginose (früher bezeichnet als Haemophilus-Vaginitis, Gardnerella-Vaginitis, unspezifische Vaginitis, Corynebacterium-Vaginitis oder anaerobe Vaginose); legalStatusOfSupply = D: Dispensed following expert advice; additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = nystatin,NA NAS,Synthetic</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10050348}\">Genital infection NOS, female</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10012601}\">Diabetes mellitus</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 756005042000002}\">therapeutic</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Comprehensive-Sample-Combipack"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10050348",
              "display" : "Genital infection NOS, female"
            }]
          }
        },
        "comorbidity" : [{
          "concept" : {
            "coding" : [{
              "system" : "https://www.meddra.org",
              "code" : "10012601",
              "display" : "Diabetes mellitus"
            }]
          }
        }],
        "intendedEffect" : {
          "concept" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
              "code" : "756005042000002",
              "display" : "therapeutic"
            }]
          }
        }
      }
    }
  }]
}

```
