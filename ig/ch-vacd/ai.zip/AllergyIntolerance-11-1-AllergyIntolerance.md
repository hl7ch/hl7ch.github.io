# 11.1 AllergyIntolerance - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **11.1 AllergyIntolerance**

## Example AllergyIntolerance: 11.1 AllergyIntolerance

Profile: [CH VACD AllergyIntolerance](StructureDefinition-ch-vacd-allergyintolerances.md)

**identifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.3.0/NamingSystem-uri.html)/urn:uuid:0028b459-11f0-4d8a-8d37-5276f88ddb06

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**code**: Allergy to egg protein (finding)

**patient**: [Monika Wegmueller Female, DoB: 1967-02-10 ( Medical record number)](Patient-3-1-Patient.md)

**recordedDate**: 2004-07-11 00:00:00+0200

**recorder**: [PractitionerRole](PractitionerRole-6-1-PractitionerRole.md)



## Resource Content

```json
{
  "resourceType" : "AllergyIntolerance",
  "id" : "11-1-AllergyIntolerance",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-allergyintolerances"]
  },
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:0028b459-11f0-4d8a-8d37-5276f88ddb06"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
      "code" : "confirmed",
      "display" : "Confirmed"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "213020009",
      "display" : "Allergy to egg protein (finding)"
    }]
  },
  "patient" : {
    "reference" : "Patient/3-1-Patient"
  },
  "recordedDate" : "2004-07-11T00:00:00+02:00",
  "recorder" : {
    "reference" : "PractitionerRole/6-1-PractitionerRole"
  }
}

```
