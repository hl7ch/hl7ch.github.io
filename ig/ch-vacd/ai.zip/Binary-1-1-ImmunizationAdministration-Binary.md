# 13.1 Binary Original Representation (Immunization Certificate) - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **13.1 Binary Original Representation (Immunization Certificate)**

## Binary: 13.1 Binary Original Representation (Immunization Certificate)

[The Content Type 'application/pdf' is not rendered in this context]



## Resource Binary Content

application/pdf:

```
{snip}
```
