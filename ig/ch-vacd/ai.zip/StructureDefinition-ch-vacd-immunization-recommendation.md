# CH VACD Immunization Recommendations - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH VACD Immunization Recommendations**

## Resource Profile: CH VACD Immunization Recommendations 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization-recommendation | *Version*:7.0.0-ballot |
| Active as of 2026-06-11 | *Computable Name*:CHVACDImmunizationRecommendation |
| **Copyright/Legal**: CC0-1.0 | |

 
Definition of the immunization recommendation part for all documents. 

### Scope and Usage

The ImmunizationRecommendation resource is defined to use in a recommendation response from a clinical decision support system (CDS).

For more information look at the description about [CDS for immunization recommendation](CDS-immunization-recommendation.md).

### Description out of FHIR R6 ballot

#### Scope and Usage

The ImmunizationRecommendation resource is intended to cover the expression of a customized set of immunization recommendations and status for a specific individual with the ultimate goal of achieving long-lasting immunity in the individual. This can include recommending future doses to progress the individual along the path to immunity and/or indicating that vaccination is not needed (e.g., the individual has completed the recommended set of doses and has presumed immunity, a contraindication or other condition would render further doses inadvisable, an acquired immunity negates the need for additional doses, the patient has aged out of a series). Where the individual is not yet fully protected, recommendations may be used to initiate clinical activity such as the ordering and administration of a vaccine. These recommendations may be used for non-clinical purposes such as presentation of vaccination credentials, satisfaction of school enrollment requirements or public health purposes. While not explicitly expressed in the resource itself, the "intent" of an ImmunizationRecommendation resource is always considered to be "proposal".

An ImmunizationRecommendation is a point-in-time representation of an individual's data compared against a set of guidelines designed by healthcare professionals to protect individuals against a wide range of vaccine preventable diseases. These sets of guidelines go by various names in different locales, but for the sake of what follows, they will be referred to as a "schedule". Schedules are often age-based but can also contain recommendations based on other information about the patient including things like allergies, underlying medical conditions, prescribed medications, personal behaviors and other attributes. For example, in the United States, all infants are recommended to receive their first dose of the polio vaccine by 2 months of age while healthcare professionals are recommended to be vaccinated against Hepatitis B if they are routinely exposed to blood products. Documented within the schedule for a given vaccine preventable disease, one or more “series” may be defined. A series is a set of one or more recommended vaccinations that is intended to produce immunity in the vaccinated individual. Examples of series include the standard 2-dose MMR series to protect against measles, mumps and rubella or the 3-dose HepA/HepB series to protect against Hepatitis A and B. An individualized immunization recommendation is typically the product of a clinical decision support (CDS) engine which takes the individual's data and a machine computable schedule as inputs to evaluate the patient's current immunization status and forecast future needs. Note that an immunization recommendation may also indicate that further vaccination is not required for a given target disease if the individual has completed their path to immunity. A comparison of the individual's data against different guidelines may result in a different set of recommendations. Also note that schedules themselves may evolve over time potentially resulting in new recommendations for a given individual. As noted in the figure below, a set of individualized immunization recommendations may then be used for a variety of purposes. Perhaps the most obvious usage is as the basis for a healthcare provider to develop and implement a plan to vaccinate the individual. However, other usages are possible including as a basis for vaccine credentialling, meeting school admission requirements, and performing public health activities. Because the recommendations for an individual can change over time, the data contained in an ImmunizationRecommendation resource is expected to be the basis for clinical action for only a short period of time.

An individual recommendation in the ImmunizationRecommendation resource will often relate to the recommendation of a specific dose of vaccine. The base ImmunizationRecommendation is silent on the time frame for the recommended administration date for a recommendation contained in the resource. That is, it is a system decision about how far in advance (1 day, 1 week, 6 weeks, 6 months, etc) of the recommendation administration date a recommendation is made. A recommendation may also be used to indicate that additional doses are not needed for some reason (such as the series is complete, the patient has aged out of the series, the patient is immune through some other mechanism or additional doses are contraindicated). This functionality may be important to convey to end users that they should not take action.

The display of immunization recommendations to end users is the responsibility of the system using the data contained in the ImmunizationRecommendation resource. Use case specific Implementation Guides can define specific display or usage expectations (if any) of systems using the recommendations contained in the resource.

#### Boundaries and Relationships

As noted above, the comparison of an individual's data against a schedule includes an evaluation of each prior dose of vaccine against the guidelines set forth in the schedule. The outcome of this evaluation is either the validation of the prior dose (that is, the dose is "valid" and advances the individual on the path to immunity) or the determination that the prior dose was "invalid" for some reason and cannot count towards meeting the guidelines in the schedule. The evaluation outcome for a given dose of vaccine can be expressed in the ImmunizationEvaluation resource.

An ImmunizationRecommendation resource may reference the relevant Immunization and ImmunizationEvaluation resources that underly the recommendation. Additional resources may be referenced where they document other factors (such as underlying medical conditions, behaviors, etc) which impact the recommendation.

The recommendations contained within an ImmunizationRecommendation resource may be used to initiate a set of clinical activities leading to the administration and documentation of one or more doses of vaccine. Where a record of an order to administer a vaccine is required, the MedicationRequest resource is used. The value of MedicationRequest.intent is used to distinguish between a plan to vaccinate and an authorized order. MedicationRequest.basedOn may be used to link the order to the initiating ImmunizationRecommendation. The documentation of the administration of the vaccine should be accomplished through the use of the Immunization resource.

Note that the ImmunizationRecommendation resource allows the inclusion of multiple recommendations in a single instance of the resource. Where the output of the evaluation process results in only a single recommendation, the use of MedicationRequest where .intent is valued "proposal" is allowed as an alternative to the ImmunizationRecommendation resource if it simplifies the subsequent clinical workflow.

**Fig.: Immunization Recommendation**

![](immunizationrecommendation.png)

**Usages:**

* Use this Profile: [CH VACD Message Immunization Recommendation Response](StructureDefinition-ch-vacd-recommendation-response-message.md)
* Refer to this Profile: [CH VACD Immunization Recommendation Response MessageHeader](StructureDefinition-ch-vacd-recommendation-response-messageheader.md)
* Examples for this Profile: [ImmunizationRecommendation/10-1-ImmunizationRecommendation](ImmunizationRecommendation-10-1-ImmunizationRecommendation.md), [ImmunizationRecommendation/10-2-ImmunizationRecommendation](ImmunizationRecommendation-10-2-ImmunizationRecommendation.md), [ImmunizationRecommendation/10-3-ImmunizationRecommendation](ImmunizationRecommendation-10-3-ImmunizationRecommendation.md) and [ImmunizationRecommendation/10-4-ImmunizationRecommendation](ImmunizationRecommendation-10-4-ImmunizationRecommendation.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-vacd|current/StructureDefinition/StructureDefinition-ch-vacd-immunization-recommendation.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ch-vacd-immunization-recommendation.csv), [Excel](StructureDefinition-ch-vacd-immunization-recommendation.xlsx), [Schematron](StructureDefinition-ch-vacd-immunization-recommendation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ch-vacd-immunization-recommendation",
  "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization-recommendation",
  "version" : "7.0.0-ballot",
  "name" : "CHVACDImmunizationRecommendation",
  "title" : "CH VACD Immunization Recommendations",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-11T13:35:24+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  }],
  "description" : "Definition of the immunization recommendation part for all documents.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CHE"
    }]
  }],
  "copyright" : "CC0-1.0",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ImmunizationRecommendation",
  "baseDefinition" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-immunization-recommendation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ImmunizationRecommendation",
      "path" : "ImmunizationRecommendation",
      "short" : "CH VACD Immunization Recommendation"
    },
    {
      "id" : "ImmunizationRecommendation.contained",
      "path" : "ImmunizationRecommendation.contained",
      "short" : "ImmunizationRecommendation inline resource",
      "max" : "1"
    },
    {
      "id" : "ImmunizationRecommendation.recommendation.vaccineCode",
      "path" : "ImmunizationRecommendation.recommendation.vaccineCode",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.ch/ig/ch-vacd/ValueSet/ch-vacd-ch-vaccination-plan-immunizations-vs"
      }
    },
    {
      "id" : "ImmunizationRecommendation.recommendation.targetDisease",
      "path" : "ImmunizationRecommendation.recommendation.targetDisease",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.ch/ig/ch-vacd/ValueSet/ch-vacd-targetdiseasesandillnessesundergoneforimmunization-vs"
      }
    },
    {
      "id" : "ImmunizationRecommendation.recommendation.forecastReason",
      "path" : "ImmunizationRecommendation.recommendation.forecastReason",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.ch/ig/ch-vacd/ValueSet/ch-vacd-recommendation-categories-vs"
      }
    },
    {
      "id" : "ImmunizationRecommendation.recommendation.dateCriterion",
      "path" : "ImmunizationRecommendation.recommendation.dateCriterion",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
