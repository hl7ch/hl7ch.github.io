# Usecase 5 Cda De - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* **Usecase 5 Cda De**

## Usecase 5 Cda De

# UC 5: Stationäre Impfstelle mit elektronischer KG

**Ausführlichere Bezeichnung**: Impfstelle Spital (Arzt arbeitet mit elektronischer Krankengeschichte) Siehe Kapitel [UC 2](usecase_2_cda_de]: Ambulante Impfstelle mit elektronischer KG. Anstelle der APS benutzt der Arzt ein Krankenhausinformationssystem (KIS). Die [UC 2a / 2b / 2c](usecase_2_cda_de] werden analog ausgeführt.

