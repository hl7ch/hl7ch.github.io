# TC1 Immunization by HCP2 - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TC1 Immunization by HCP2**

## Example Immunization: TC1 Immunization by HCP2

Profile: [CH VACD Immunization](StructureDefinition-ch-vacd-immunization.md)

**Author of the content**: [PractitionerRole](PractitionerRole-TC-HCP2-ORG2-ROLE-author.md)

**CH VACD Extension Immunization Medication Reference**: [Medication PRIORIX Trockensub c Solv](Medication-TC-IMMUN-MEDIC-PRIORIX.md)

**CH VACD Extension verificationStatus**: [SNOMED CT: 59156000](http://snomed.info/id/59156000) (Confirmed)

**identifier**: `urn:oid:2.999.1.2.3.4`/urn:uuid:58457607-9160-4d0a-9a79-55495755a677

**status**: Completed

**vaccineCode**: Priorix

**patient**: [Monika Wegmueller Female, DoB: 1967-02-10 ( Medical record number)](Patient-TC-patient.md)

**occurrence**: 2020-12-09

**recorded**: 2020-12-09 11:00:00+0200

**lotNumber**: A69FE297A

**route**: Intramuscular use

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [PractitionerRole](PractitionerRole-TC-HCP2-ORG2-ROLE-performer.md) |

### ProtocolApplieds

| | | |
| :--- | :--- | :--- |
| - | **TargetDisease** | **DoseNumber[x]** |
| * | Mumps (disorder) | 1 |



## Resource Content

```json
{
  "resourceType" : "Immunization",
  "id" : "TCD01-IMMUN4",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"]
  },
  "extension" : [{
    "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
    "valueReference" : {
      "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-author"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
    "valueReference" : {
      "reference" : "Medication/TC-IMMUN-MEDIC-PRIORIX"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "59156000",
      "display" : "Confirmed"
    }
  }],
  "identifier" : [{
    "system" : "urn:oid:2.999.1.2.3.4",
    "value" : "urn:uuid:58457607-9160-4d0a-9a79-55495755a677"
  }],
  "status" : "completed",
  "vaccineCode" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
      "code" : "615",
      "display" : "Priorix"
    }]
  },
  "patient" : {
    "reference" : "Patient/TC-patient"
  },
  "occurrenceDateTime" : "2020-12-09",
  "recorded" : "2020-12-09T11:00:00.390+02:00",
  "lotNumber" : "A69FE297A",
  "route" : {
    "coding" : [{
      "system" : "http://standardterms.edqm.eu",
      "code" : "20035000",
      "display" : "Intramuscular use"
    }]
  },
  "performer" : [{
    "actor" : {
      "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-performer"
    }
  }],
  "protocolApplied" : [{
    "targetDisease" : [{
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "36989005",
        "display" : "Mumps (disorder)"
      }]
    }],
    "doseNumberPositiveInt" : 1
  }]
}

```
