# Use Cases Deutsch - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Use Cases Deutsch**

## Use Cases Deutsch

Es gibt viele Szenarien rund um die Dokumentation von impfrelevanten Angaben. Die Mechanismen und Prozesse in Zusammenhang mit den beschriebenen Dokumenten des Austauschformates bleiben unabhängig von der Speicherung, sei es via XDS Repository, Filesysteme und andere, immer die gleichen. Es geht immer um das Zusammenführen von Elementen in verschiedenen Dokumenten zu einem Dokument.

### Anwendungsfälle im Zusammenhang mit dem EPD

Die nachfolgend aufgeführten Use Cases beschreiben die möglichen Szenarien rund um die Impf-Dokumentation im Kontext zum EPD. Das EPD basiert auf eine IHE Umgebung und die Gesundheitsdaten sind als Dokumente in einem XDS Repository gespeichert. Das Problem Synchronisierung der Metadaten im XDS und im FHIR Austauschformat ist bekannt, ist aber nicht Bestandteil dieses IG, der das Austauschformat beschreibt.

* [Use Case 1 (DE): Impfdokumentation sichten](Use-Case-1-Impfdokumentation-sichten.md)
* [Use Case 2 (DE): Impfung dokumentieren](Use-Case-2-Impfung-dokumentieren.md)
* [Use Case 3 (DE): Impfdossier verifizieren und aktualisieren](Use-Case-3-Impfdossier-verifizieren-und-aktualisieren.md)
* [Use Case 4 (DE): Impfcheck ausführen](Use-Case-4-Impfcheck-ausfuehren.md)
* [Use Case 5 (DE): Verifizierbares Zertifikat erstellen](Use-Case-5-Verifizierbares-Zertifikat-erstellen.md)

### Anwendungsfälle generell

Nachfolgend werden Use Cases aufgeführt, welche nicht im Kontext des EPD vorkommen können.

* [Use Case 14 (DE): Impfcheck ausführen](Use-Case-14-Impfcheck-ausfuehren.md)

