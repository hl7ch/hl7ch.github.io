# 1.5 Immunization Recommendation Response - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1.5 Immunization Recommendation Response**

## Example Bundle: 1.5 Immunization Recommendation Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "1-5-ImmunizationRecommendationResponse",
  "meta" : {
    "lastUpdated" : "2021-06-01T00:00:00.159+02:00",
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-recommendation-response-message"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:5b8a26b2-dd6d-4c04-acaf-e4a44b7bcf47"
  },
  "type" : "message",
  "timestamp" : "2021-06-01T00:00:00.159+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/MessageHeader/2-5-ImmunizationRecommendationResponseMessageHeader",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "2-5-ImmunizationRecommendationResponseMessageHeader",
      "meta" : {
        "lastUpdated" : "2021-06-01T00:00:00.394+02:00",
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-recommendation-response-messageheader"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_2-5-ImmunizationRecommendationResponseMessageHeader\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 2-5-ImmunizationRecommendationResponseMessageHeader</b></p><a name=\"2-5-ImmunizationRecommendationResponseMessageHeader\"> </a><a name=\"hc2-5-ImmunizationRecommendationResponseMessageHeader\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-01 00:00:00+0200</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-recommendation-response-messageheader.html\">CH VACD Immunization Recommendation Response MessageHeader</a></p></div><p><b>event</b>: <a href=\"CodeSystem-ch-vacd-clinical-decision-support-event-cs.html#ch-vacd-clinical-decision-support-event-cs-immunrecoresponse\">CDS Event: immunrecoresponse</a> (Immunization Recommendation Response)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>Example Portal EPR</td><td>urn:oid:2.999.1.2.3.4.5</td></tr></table><p><b>sender</b>: <a href=\"Organization-CDSS-Organization.html\">Organization Immunization CDS Service</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>Example Vaccination Clinical Decision Support System</td><td><a href=\"https://example.com/cds/immunization/ws\">https://example.com/cds/immunization/ws</a></td></tr></table><p><b>responsible</b>: <a href=\"Organization-CDSS-Organization.html\">Organization Immunization CDS Service</a></p><p><b>reason</b>: <span title=\"Codes:{http://snomed.info/sct 830152006}\">Recommendation regarding vaccination (procedure)</span></p><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>1-4-ImmunizationRecommendationRequest</td><td>OK</td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"ImmunizationRecommendation-10-4-ImmunizationRecommendation.html\">ImmunizationRecommendation: identifier = urn:oid:2.999.1.2.3.4#1; date = 2021-06-01 00:00:00+0200</a></li><li><a href=\"ImmunizationRecommendation-10-3-ImmunizationRecommendation.html\">ImmunizationRecommendation: identifier = urn:oid:2.999.1.2.3.4#2; date = 2021-06-01 00:00:00+0200</a></li></ul></div>"
      },
      "eventCoding" : {
        "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-clinical-decision-support-event-cs",
        "code" : "immunrecoresponse",
        "display" : "Immunization Recommendation Response"
      },
      "destination" : [{
        "name" : "Example Portal EPR",
        "endpoint" : "urn:oid:2.999.1.2.3.4.5"
      }],
      "sender" : {
        "reference" : "Organization/CDSS-Organization"
      },
      "source" : {
        "name" : "Example Vaccination Clinical Decision Support System",
        "endpoint" : "https://example.com/cds/immunization/ws"
      },
      "responsible" : {
        "reference" : "Organization/CDSS-Organization"
      },
      "reason" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "830152006",
          "display" : "Recommendation regarding vaccination (procedure)"
        }]
      },
      "response" : {
        "identifier" : "1-4-ImmunizationRecommendationRequest",
        "code" : "ok"
      },
      "focus" : [{
        "reference" : "ImmunizationRecommendation/10-4-ImmunizationRecommendation"
      },
      {
        "reference" : "ImmunizationRecommendation/10-3-ImmunizationRecommendation"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/3-2-Patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "3-2-Patient",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_3-2-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 3-2-Patient</b></p><a name=\"3-2-Patient\"> </a><a name=\"hc3-2-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Monika Wegmueller  Female, DoB: 1967-03-10 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">9876 </td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "12345678"
      }],
      "name" : [{
        "family" : "Wegmueller",
        "given" : ["Monika"]
      }],
      "gender" : "female",
      "birthDate" : "1967-03-10",
      "address" : [{
        "postalCode" : "9876"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/CDSS-Organization",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "CDSS-Organization",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_CDSS-Organization\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization CDSS-Organization</b></p><a name=\"CDSS-Organization\"> </a><a name=\"hcCDSS-Organization\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000000781</p><p><b>name</b>: Immunization CDS Service</p><p><b>address</b>: Mustergasse 99 Beispielen SG 9876 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000781"
      }],
      "name" : "Immunization CDS Service",
      "address" : [{
        "line" : ["Mustergasse 99"],
        "city" : "Beispielen",
        "state" : "SG",
        "postalCode" : "9876",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ImmunizationRecommendation/10-3-ImmunizationRecommendation",
    "resource" : {
      "resourceType" : "ImmunizationRecommendation",
      "id" : "10-3-ImmunizationRecommendation",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization-recommendation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImmunizationRecommendation_10-3-ImmunizationRecommendation\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImmunizationRecommendation 10-3-ImmunizationRecommendation</b></p><a name=\"10-3-ImmunizationRecommendation\"> </a><a name=\"hc10-3-ImmunizationRecommendation\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization-recommendation.html\">CH VACD Immunization Recommendations</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/2</p><p><b>patient</b>: <a href=\"Patient-3-2-Patient.html\">Monika Wegmueller  Female, DoB: 1967-03-10 ( Medical record number)</a></p><p><b>date</b>: 2021-06-01 00:00:00+0200</p><blockquote><p><b>recommendation</b></p><p><b>vaccineCode</b>: <span title=\"Codes:{http://snomed.info/sct 1181000221105}\">Vaccine product containing only Influenza virus antigen (medicinal product)</span></p><p><b>targetDisease</b>: <span title=\"Codes:{http://snomed.info/sct 719590007}\">Influenza caused by seasonal influenza virus (disorder)</span></p><p><b>forecastStatus</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-forecast-status-cs due}\">Due</span></p><p><b>forecastReason</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-categories-cs 41503}\">Empfohlene Impfungen für Risikogruppen</span></p><h3>DateCriterions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 30980-7}\">Date vaccine due</span></td><td>2021-06-01 00:00:00+0200</td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "2"
      }],
      "patient" : {
        "reference" : "Patient/3-2-Patient"
      },
      "date" : "2021-06-01T00:00:00+02:00",
      "recommendation" : [{
        "vaccineCode" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1181000221105",
            "display" : "Vaccine product containing only Influenza virus antigen (medicinal product)"
          }]
        }],
        "targetDisease" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "719590007",
            "display" : "Influenza caused by seasonal influenza virus (disorder)"
          }]
        },
        "forecastStatus" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-forecast-status-cs",
            "code" : "due",
            "display" : "Due"
          }]
        },
        "forecastReason" : [{
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-categories-cs",
            "code" : "41503",
            "display" : "Empfohlene Impfungen für Risikogruppen"
          }]
        }],
        "dateCriterion" : [{
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "30980-7",
              "display" : "Date vaccine due"
            }]
          },
          "value" : "2021-06-01T00:00:00+02:00"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ImmunizationRecommendation/10-4-ImmunizationRecommendation",
    "resource" : {
      "resourceType" : "ImmunizationRecommendation",
      "id" : "10-4-ImmunizationRecommendation",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization-recommendation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImmunizationRecommendation_10-4-ImmunizationRecommendation\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImmunizationRecommendation 10-4-ImmunizationRecommendation</b></p><a name=\"10-4-ImmunizationRecommendation\"> </a><a name=\"hc10-4-ImmunizationRecommendation\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization-recommendation.html\">CH VACD Immunization Recommendations</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/1</p><p><b>patient</b>: <a href=\"Patient-3-2-Patient.html\">Monika Wegmueller  Female, DoB: 1967-03-10 ( Medical record number)</a></p><p><b>date</b>: 2021-06-01 00:00:00+0200</p><blockquote><p><b>recommendation</b></p><p><b>vaccineCode</b>: <span title=\"Codes:{http://snomed.info/sct 72093006}\">Poliomyelitis vaccination</span></p><p><b>targetDisease</b>: <span title=\"Codes:{http://snomed.info/sct 398102009}\">Acute poliomyelitis (disorder)</span></p><p><b>forecastStatus</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-forecast-status-cs due}\">Due</span></p><p><b>forecastReason</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-categories-cs 41501}\">Empfohlene Basisimpfungen</span></p><h3>DateCriterions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 30980-7}\">Date vaccine due</span></td><td>2021-06-01 00:00:00+0200</td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "1"
      }],
      "patient" : {
        "reference" : "Patient/3-2-Patient"
      },
      "date" : "2021-06-01T00:00:00+02:00",
      "recommendation" : [{
        "vaccineCode" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "72093006",
            "display" : "Poliomyelitis vaccination"
          }]
        }],
        "targetDisease" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "398102009",
            "display" : "Acute poliomyelitis (disorder)"
          }]
        },
        "forecastStatus" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-forecast-status-cs",
            "code" : "due",
            "display" : "Due"
          }]
        },
        "forecastReason" : [{
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-recommendation-categories-cs",
            "code" : "41501",
            "display" : "Empfohlene Basisimpfungen"
          }]
        }],
        "dateCriterion" : [{
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "30980-7",
              "display" : "Date vaccine due"
            }]
          },
          "value" : "2021-06-01T00:00:00+02:00"
        }]
      }]
    }
  }]
}

```
