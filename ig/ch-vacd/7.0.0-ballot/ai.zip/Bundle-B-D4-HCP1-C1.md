# Test Case B 03: Document HCP1 with Medical Problem Entries - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Case B 03: Document HCP1 with Medical Problem Entries**

## Example Bundle: Test Case B 03: Document HCP1 with Medical Problem Entries



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "B-D4-HCP1-C1",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-document-immunization-administration"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:ddd50da7-3358-4d36-85cf-569ba7473dc5"
  },
  "type" : "document",
  "timestamp" : "2021-10-20T14:00:00.390+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/B-D4-HCP1-C1-Composition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "B-D4-HCP1-C1-Composition",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-composition-immunization-administration"]
      },
      "language" : "en-US",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><div class=\"hapiHeaderText\"><a name=\"Composition_B-D4-HCP1-C1-Composition\"> </a>Immunization Administration</div><table class=\"hapiPropertyTable\"><tr><td>Patient</td><td>Monika <b>WEGMUELLER</b></td></tr><tr><td>Author</td><td><div><div class=\"hapiHeaderText\">Monika <b>WEGMUELLER</b></div><table class=\"hapiPropertyTable\"><tbody><tr><td>Identifier</td><td>123.71.332.115</td></tr><tr><td>Address</td><td><span>CH-</span><span>9876 </span><span>Specimendorf</span></td></tr><tr><td>Date of birth</td><td><span>10 February 1967</span></td></tr></tbody></table></div></td></tr><tr><td>Status</td><td>FINAL</td></tr><tr><td>Language</td><td>en-US</td></tr><tr><td>Sections</td><td><table><tr><td>Medical Problems</td></tr></table></td></tr></table></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ddd50da7-3358-4d36-85cf-569ba7473dc5"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "41000179103",
          "display" : "Immunization record"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "urn:oid:2.16.756.5.30.1.127.3.10.10",
          "code" : "urn:che:epr:ch-vacd:immunization-administration:2022"
        }]
      }],
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "date" : "2021-10-20T14:00:00.390+02:00",
      "author" : [{
        "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
      }],
      "title" : "Immunization Administration",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal (qualifier value)"
            }]
          }
        }]
      },
      "custodian" : {
        "reference" : "Organization/TC-ORG1"
      },
      "section" : [{
        "id" : "medicalproblems",
        "title" : "Medical Problems",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4",
            "display" : "Problem list Reported"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Problem list Reported (http://loinc.org#11450-4)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Condition-TCB03-EXPRISK1.html\">Condition/TCB03-EXPRISK1</a></td></tr></table></div>"
        },
        "entry" : [{
          "reference" : "Condition/TCB03-EXPRISK1"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/TC-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "TC-patient",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_TC-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient TC-patient</b></p><a name=\"TC-patient\"> </a><a name=\"hcTC-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: tel:+41.32.685.12.34(Home)</li><li>Leidensweg 10 Specimendorf 9876 CH </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "12345678"
      }],
      "name" : [{
        "family" : "Wegmueller",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.685.12.34",
        "use" : "home"
      }],
      "gender" : "female",
      "birthDate" : "1967-02-10",
      "address" : [{
        "type" : "both",
        "line" : ["Leidensweg 10"],
        "city" : "Specimendorf",
        "postalCode" : "9876",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG1</b></p><a name=\"TC-ORG1\"> </a><a name=\"hcTC-ORG1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601777777718</p><p><b>name</b>: Gruppenpraxis Müller</p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:bereit@gruppenpraxis.ch\">mailto:bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich ZH 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601777777718"
      }],
      "name" : "Gruppenpraxis Müller",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "state" : "ZH",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP1-C1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "TC-HCP1-C1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP1-C1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP1-C1</b></p><a name=\"TC-HCP1-C1\"> </a><a name=\"hcTC-HCP1-C1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601888888884</p><p><b>active</b>: true</p><p><b>name</b>: Peter Müller </p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:allzeit.bereit@gruppenpraxis.ch\">mailto:allzeit.bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601888888884"
      }],
      "active" : true,
      "name" : [{
        "family" : "Müller",
        "given" : ["Peter"],
        "prefix" : ["Dr. med."]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:allzeit.bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "type" : "physical",
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP1-ORG1-ROLE-author",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP1-ORG1-ROLE-author",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP1-ORG1-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP1-ORG1-ROLE-author</b></p><a name=\"TC-HCP1-ORG1-ROLE-author\"> </a><a name=\"hcTC-HCP1-ORG1-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP1-C1.html\">Practitioner Peter Müller </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG1.html\">Organization Gruppenpraxis Müller</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP1-C1"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG1"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Condition/TCB03-EXPRISK1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "TCB03-EXPRISK1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medical-problems"]
      },
      "language" : "en-US",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en-US\" lang=\"en-US\"><a name=\"Condition_TCB03-EXPRISK1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition TCB03-EXPRISK1</b></p><a name=\"TCB03-EXPRISK1\"> </a><a name=\"hcTCB03-EXPRISK1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en-US</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medical-problems.html\">CH VACD Medical Problems</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/30327ea1-6893-4c65-896e-c32c394f1ec6</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 223366009}\">Healthcare professional (occupation)</span></p><p><b>subject</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>onset</b>: 2021-10-01</p><p><b>recordedDate</b>: 2021-10-20</p><p><b>recorder</b>: <a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-author.html\">PractitionerRole</a></p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "30327ea1-6893-4c65-896e-c32c394f1ec6"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "223366009",
          "display" : "Healthcare professional (occupation)"
        }]
      },
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "onsetDateTime" : "2021-10-01",
      "recordedDate" : "2021-10-20",
      "recorder" : {
        "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
      }
    }
  }]
}

```
