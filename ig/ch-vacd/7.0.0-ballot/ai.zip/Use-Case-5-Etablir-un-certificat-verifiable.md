# Use Case 5 Etablir Un Certificat Verifiable - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Use Case 5 Etablir Un Certificat Verifiable**

## Use Case 5 Etablir Un Certificat Verifiable

### Établir un certificat vérifiable

Un patient requiert un certificat vérifiable (p. ex. un certificat COVID-19) auprès d’un professionnel de la santé, en tant que justificatif internationalement reconnu de vaccination, de guérison confirmée ou de test confirmé par un laboratoire pour prouver l’immunité.

Le professionnel de la santé établit un certificat vérifiable dans le système primaire ou sur le portail de la communauté.

Le système primaire ou le portail de la communauté fait appel à un service central pour établir un certificat vérifiable internationalement reconnu et un code-barres. Le système primaire ou le portail de la communauté sauvegarde le certificat vérifiable et le code-barres dans le DEP du patient.

Sur demande, le patient présente le certificat vérifiable sur la version mobile du portail pour les patients ou dans une application mobile spécifique.

