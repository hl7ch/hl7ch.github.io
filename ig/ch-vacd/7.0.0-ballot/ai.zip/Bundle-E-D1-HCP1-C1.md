# Test Case E 01: Document HCP1 with Immunization Entries French - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Case E 01: Document HCP1 with Immunization Entries French**

## Example Bundle: Test Case E 01: Document HCP1 with Immunization Entries French



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "E-D1-HCP1-C1",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-document-immunization-administration"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:0b2c85af-aea2-4052-8cc2-09ce6e11bf24"
  },
  "type" : "document",
  "timestamp" : "2021-06-08T10:00:00.390+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/E-D1-HCP1-C1-Composition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "E-D1-HCP1-C1-Composition",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-composition-immunization-administration"]
      },
      "language" : "fr-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"fr-CH\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"fr-CH\"><a name=\"Composition_E-D1-HCP1-C1-Composition\"> </a><h3>Vaccin administré</h3><p><b>Id: </b>E-D1-HCP1-C1-Composition</p><p><b>Identifier: </b><span>urn:ietf:rfc:3986#urn:uuid:0b2c85af-aea2-4052-8cc2-09ce6e11bf24</span></p><p><b>Status: </b>Final</p><p><b>Code: </b><span>Immunization record (http://snomed.info/sct#41000179103)</span></p><p><b>Patient: </b><a href=\"Patient-TC-patient.html\">Patient/TC-patient</a> Wegmueller Monika</p><p><b>Date: </b>June 8, 2021</p><p><b>Authors:</b></p><table><tr><td><p><a href=\"Practitioner-TC-HCP1-C1.html\">Practitioner/TC-HCP1-C1</a> Bereit Allzeit</p><p><a href=\"Organization-TC-ORG1.html\">Organization/TC-ORG1</a> Gruppenpraxis CH</p></td></tr></table><p><b>Confidentiality: </b>null<span> Normal (qualifier value) (http://snomed.info/sct#17621005)</span></p><p><b>Sections:</b></p><table><tr><td>Liste Vaccin administré</td></tr></table></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:0b2c85af-aea2-4052-8cc2-09ce6e11bf24"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "41000179103",
          "display" : "Immunization record"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "urn:oid:2.16.756.5.30.1.127.3.10.10",
          "code" : "urn:che:epr:ch-vacd:immunization-administration:2022"
        }]
      }],
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "date" : "2021-06-08T10:00:00.390+02:00",
      "author" : [{
        "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
      }],
      "title" : "Vaccin administré",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal (qualifier value)"
            }]
          }
        }]
      },
      "custodian" : {
        "reference" : "Organization/TC-ORG1"
      },
      "section" : [{
        "id" : "administration",
        "title" : "Liste Vaccin administré",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6",
            "display" : "Hx of Immunization"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"fr-CH\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"fr-CH\"><p><b>Code: </b><span>Hx of Immunization (http://loinc.org#11369-6)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Immunization-TCE01-IMMUN1-fr.html\">Immunization/TCE01-IMMUN1-fr</a></td></tr><tr><td><a href=\"Immunization-TCE01-IMMUN2-fr.html\">Immunization/TCE01-IMMUN2-fr</a></td></tr></table></div>"
        },
        "entry" : [{
          "reference" : "Immunization/TCE01-IMMUN1-fr"
        },
        {
          "reference" : "Immunization/TCE01-IMMUN2-fr"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/TC-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "TC-patient",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_TC-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient TC-patient</b></p><a name=\"TC-patient\"> </a><a name=\"hcTC-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: tel:+41.32.685.12.34(Home)</li><li>Leidensweg 10 Specimendorf 9876 CH </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "12345678"
      }],
      "name" : [{
        "family" : "Wegmueller",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.685.12.34",
        "use" : "home"
      }],
      "gender" : "female",
      "birthDate" : "1967-02-10",
      "address" : [{
        "type" : "both",
        "line" : ["Leidensweg 10"],
        "city" : "Specimendorf",
        "postalCode" : "9876",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG1</b></p><a name=\"TC-ORG1\"> </a><a name=\"hcTC-ORG1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601777777718</p><p><b>name</b>: Gruppenpraxis Müller</p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:bereit@gruppenpraxis.ch\">mailto:bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich ZH 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601777777718"
      }],
      "name" : "Gruppenpraxis Müller",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "state" : "ZH",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP1-C1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "TC-HCP1-C1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP1-C1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP1-C1</b></p><a name=\"TC-HCP1-C1\"> </a><a name=\"hcTC-HCP1-C1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601888888884</p><p><b>active</b>: true</p><p><b>name</b>: Peter Müller </p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:allzeit.bereit@gruppenpraxis.ch\">mailto:allzeit.bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601888888884"
      }],
      "active" : true,
      "name" : [{
        "family" : "Müller",
        "given" : ["Peter"],
        "prefix" : ["Dr. med."]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:allzeit.bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "type" : "physical",
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP1-ORG1-ROLE-performer",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP1-ORG1-ROLE-performer",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP1-ORG1-ROLE-performer\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP1-ORG1-ROLE-performer</b></p><a name=\"TC-HCP1-ORG1-ROLE-performer\"> </a><a name=\"hcTC-HCP1-ORG1-ROLE-performer\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP1-C1.html\">Practitioner Peter Müller </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG1.html\">Organization Gruppenpraxis Müller</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP1-C1"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG1"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP1-ORG1-ROLE-author",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP1-ORG1-ROLE-author",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP1-ORG1-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP1-ORG1-ROLE-author</b></p><a name=\"TC-HCP1-ORG1-ROLE-author\"> </a><a name=\"hcTC-HCP1-ORG1-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP1-C1.html\">Practitioner Peter Müller </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG1.html\">Organization Gruppenpraxis Müller</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP1-C1"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG1"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Immunization/TCE01-IMMUN1-fr",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "TCE01-IMMUN1-fr",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"]
      },
      "language" : "fr-CH",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Immunization_TCE01-IMMUN1-fr\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization TCE01-IMMUN1-fr</b></p><a name=\"TCE01-IMMUN1-fr\"> </a><a name=\"hcTCE01-IMMUN1-fr\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization.html\">CH VACD Immunization</a></p></div><p><b>Author of the content</b>: <a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-author.html\">PractitionerRole</a></p><p><b>CH VACD Extension Immunization Medication Reference</b>: <a href=\"Medication-TC-IMMUN-MEDIC-FSMEIMMCC.html\">Medication FSME-IMMUN CC Inj Susp sep Nadel</a></p><p><b>CH VACD Extension verificationStatus</b>: <a href=\"http://snomed.info/id/59156000\">SNOMED CT: 59156000</a> (confirmé)</p><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/urn:uuid:4386ca26-6866-4322-a203-b488b84ab499</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs 450}\">FSME-Immun CC</span></p><p><b>patient</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>occurrence</b>: 2021-06-22</p><p><b>recorded</b>: 2021-06-22 11:00:00+0200</p><p><b>lotNumber</b>: 12-34244</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-performer.html\">PractitionerRole</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>TargetDisease</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 712986001}\">encéphalite à tiques</span></td><td>1</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
        "valueReference" : {
          "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
        "valueReference" : {
          "reference" : "Medication/TC-IMMUN-MEDIC-FSMEIMMCC"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "59156000",
          "display" : "confirmé"
        }
      }],
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "urn:uuid:4386ca26-6866-4322-a203-b488b84ab499"
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
          "code" : "450",
          "display" : "FSME-Immun CC"
        }]
      },
      "patient" : {
        "reference" : "Patient/TC-patient"
      },
      "occurrenceDateTime" : "2021-06-22",
      "recorded" : "2021-06-22T11:00:00.390+02:00",
      "lotNumber" : "12-34244",
      "route" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "20035000",
          "display" : "Intramuscular use"
        }]
      },
      "performer" : [{
        "actor" : {
          "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-performer"
        }
      }],
      "protocolApplied" : [{
        "targetDisease" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "712986001",
            "display" : "encéphalite à tiques"
          }]
        }],
        "doseNumberPositiveInt" : 1
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Medication/TC-IMMUN-MEDIC-FSMEIMMCC",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "TC-IMMUN-MEDIC-FSMEIMMCC",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medication-for-immunization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_TC-IMMUN-MEDIC-FSMEIMMCC\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication TC-IMMUN-MEDIC-FSMEIMMCC</b></p><a name=\"TC-IMMUN-MEDIC-FSMEIMMCC\"> </a><a name=\"hcTC-IMMUN-MEDIC-FSMEIMMCC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medication-for-immunization.html\">CH VACD Medication For Immunization</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/01194ac7-70ad-4259-b5f4-c5ff0c1b40c5</p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680004500039}\">FSME-IMMUN CC Inj Susp sep Nadel</span></p><p><b>status</b>: Active</p><p><b>manufacturer</b>: <a href=\"Organization-TC-ORG-PFIZER.html\">Organization Pfizer AG</a></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 11202000}\">Suspension for injection</span></p><p><b>amount</b>: 0.5 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span>/1 Syringe (unit of presentation)<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code733020007 = 'Syringe')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106181007}\">Immunologic substance (substance)</span></td></tr></table><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>VNR1T10C</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "01194ac7-70ad-4259-b5f4-c5ff0c1b40c5"
      }],
      "code" : {
        "coding" : [{
          "system" : "urn:oid:2.51.1.1",
          "code" : "7680004500039",
          "display" : "FSME-IMMUN CC Inj Susp sep Nadel"
        }],
        "text" : "FSME-IMMUN CC Inj Susp sep Nadel"
      },
      "status" : "active",
      "manufacturer" : {
        "reference" : "Organization/TC-ORG-PFIZER"
      },
      "form" : {
        "coding" : [{
          "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
          "code" : "11202000",
          "display" : "Suspension for injection"
        }]
      },
      "amount" : {
        "numerator" : {
          "value" : 0.5,
          "unit" : "milliliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "denominator" : {
          "value" : 1,
          "unit" : "Syringe (unit of presentation)",
          "system" : "http://snomed.info/sct",
          "code" : "733020007"
        }
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "106181007",
            "display" : "Immunologic substance (substance)"
          }],
          "text" : "Immunologic substance (substance)"
        }
      }],
      "batch" : {
        "lotNumber" : "VNR1T10C"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG-PFIZER",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG-PFIZER",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG-PFIZER\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG-PFIZER</b></p><a name=\"TC-ORG-PFIZER\"> </a><a name=\"hcTC-ORG-PFIZER\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601001010604</p><p><b>name</b>: Pfizer AG</p><p><b>telecom</b>: ph: tel:+41 800 562 825(Work), fax: fax:+41 44 583 07 00(Work), <a href=\"mailto:mailto:customer.ch@pfizer.com\">mailto:customer.ch@pfizer.com</a>, <a href=\"https://www.pfizer.ch\">https://www.pfizer.ch</a></p><p><b>address</b>: Schärenmoosstrasse 99 Postfach Zürich ZH 8052 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601001010604"
      }],
      "name" : "Pfizer AG",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41 800 562 825",
        "use" : "work"
      },
      {
        "system" : "fax",
        "value" : "fax:+41 44 583 07 00",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:customer.ch@pfizer.com",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "https://www.pfizer.ch",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Schärenmoosstrasse 99", "Postfach"],
        "city" : "Zürich",
        "state" : "ZH",
        "postalCode" : "8052",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Immunization/TCE01-IMMUN2-fr",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "TCE01-IMMUN2-fr",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"]
      },
      "language" : "fr-CH",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Immunization_TCE01-IMMUN2-fr\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization TCE01-IMMUN2-fr</b></p><a name=\"TCE01-IMMUN2-fr\"> </a><a name=\"hcTCE01-IMMUN2-fr\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization.html\">CH VACD Immunization</a></p></div><p><b>Author of the content</b>: <a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-author.html\">PractitionerRole</a></p><p><b>CH VACD Extension Immunization Medication Reference</b>: <a href=\"Medication-TC-IMMUN-MEDIC-BOOSTRIX.html\">Medication BOOSTRIX Inj Susp</a></p><p><b>CH VACD Extension verificationStatus</b>: <a href=\"http://snomed.info/id/59156000\">SNOMED CT: 59156000</a> (confirmé)</p><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/urn:uuid:ebcf6de2-ed9c-463c-8b08-cb487af8ce4e</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs 637}\">Boostrix</span></p><p><b>patient</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>occurrence</b>: 2020-12-09</p><p><b>recorded</b>: 2020-12-09 11:00:00+0200</p><p><b>lotNumber</b>: AHAVB946A</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-performer.html\">PractitionerRole</a></td></tr></table><blockquote><p><b>protocolApplied</b></p><p><b>targetDisease</b>: <span title=\"Codes:{http://snomed.info/sct 76902006}\">tétanos</span>, <span title=\"Codes:{http://snomed.info/sct 27836007}\">coqueluche</span>, <span title=\"Codes:{http://snomed.info/sct 397430003}\">diphtérie causée par Corynebacterium diphtheriae</span></p><p><b>doseNumber</b>: 1</p></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
        "valueReference" : {
          "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
        "valueReference" : {
          "reference" : "Medication/TC-IMMUN-MEDIC-BOOSTRIX"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "59156000",
          "display" : "confirmé"
        }
      }],
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "urn:uuid:ebcf6de2-ed9c-463c-8b08-cb487af8ce4e"
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
          "code" : "637",
          "display" : "Boostrix"
        }]
      },
      "patient" : {
        "reference" : "Patient/TC-patient"
      },
      "occurrenceDateTime" : "2020-12-09",
      "recorded" : "2020-12-09T11:00:00.390+02:00",
      "lotNumber" : "AHAVB946A",
      "route" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "20035000",
          "display" : "Intramuscular use"
        }]
      },
      "performer" : [{
        "actor" : {
          "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-performer"
        }
      }],
      "protocolApplied" : [{
        "targetDisease" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "76902006",
            "display" : "tétanos"
          }]
        },
        {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "27836007",
            "display" : "coqueluche"
          }]
        },
        {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "397430003",
            "display" : "diphtérie causée par Corynebacterium diphtheriae"
          }]
        }],
        "doseNumberPositiveInt" : 1
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Medication/TC-IMMUN-MEDIC-BOOSTRIX",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "TC-IMMUN-MEDIC-BOOSTRIX",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medication-for-immunization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_TC-IMMUN-MEDIC-BOOSTRIX\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication TC-IMMUN-MEDIC-BOOSTRIX</b></p><a name=\"TC-IMMUN-MEDIC-BOOSTRIX\"> </a><a name=\"hcTC-IMMUN-MEDIC-BOOSTRIX\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medication-for-immunization.html\">CH VACD Medication For Immunization</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/ead68e47-34a6-4534-a658-b718e565fb91</p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680006370012}\">BOOSTRIX Inj Susp</span></p><p><b>status</b>: Active</p><p><b>manufacturer</b>: <a href=\"Organization-TC-ORG-GSK.html\">Organization GlaxoSmithKline AG</a></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 11202000}\">Suspension for injection</span></p><p><b>amount</b>: 0.5 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span>/1 Syringe (unit of presentation)<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code733020007 = 'Syringe')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106181007}\">Immunologic substance (substance)</span></td></tr></table><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>AHAVB946A</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "ead68e47-34a6-4534-a658-b718e565fb91"
      }],
      "code" : {
        "coding" : [{
          "system" : "urn:oid:2.51.1.1",
          "code" : "7680006370012",
          "display" : "BOOSTRIX Inj Susp"
        }],
        "text" : "BOOSTRIX Inj Susp"
      },
      "status" : "active",
      "manufacturer" : {
        "reference" : "Organization/TC-ORG-GSK"
      },
      "form" : {
        "coding" : [{
          "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
          "code" : "11202000",
          "display" : "Suspension for injection"
        }]
      },
      "amount" : {
        "numerator" : {
          "value" : 0.5,
          "unit" : "milliliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "denominator" : {
          "value" : 1,
          "unit" : "Syringe (unit of presentation)",
          "system" : "http://snomed.info/sct",
          "code" : "733020007"
        }
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "106181007",
            "display" : "Immunologic substance (substance)"
          }],
          "text" : "Immunologic substance (substance)"
        }
      }],
      "batch" : {
        "lotNumber" : "AHAVB946A"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG-GSK",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG-GSK",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG-GSK\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG-GSK</b></p><a name=\"TC-ORG-GSK\"> </a><a name=\"hcTC-ORG-GSK\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601001000674</p><p><b>name</b>: GlaxoSmithKline AG</p><p><b>telecom</b>: ph: tel:+41 31 862 21 11(Work), fax: fax:+41 31 862 22 00(Work), <a href=\"mailto:mailto:swiss.info@gsk.com\">mailto:swiss.info@gsk.com</a>, <a href=\"https://www.gsk.com\">https://www.gsk.com</a></p><p><b>address</b>: Talstrasse 3-5 Münchenbuchsee BE 3053 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601001000674"
      }],
      "name" : "GlaxoSmithKline AG",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41 31 862 21 11",
        "use" : "work"
      },
      {
        "system" : "fax",
        "value" : "fax:+41 31 862 22 00",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:swiss.info@gsk.com",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "https://www.gsk.com",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Talstrasse 3-5"],
        "city" : "Münchenbuchsee",
        "state" : "BE",
        "postalCode" : "3053",
        "country" : "CH"
      }]
    }
  }]
}

```
