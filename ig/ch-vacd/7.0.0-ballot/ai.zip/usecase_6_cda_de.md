# Usecase 6 Cda De - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Usecase 6 Cda De**

## Usecase 6 Cda De

# UC 6: Verabreichung einer Impfung delegieren

**Ausführlichere Bezeichnung**: Delegierte Verabreichung einer Impfung an nichtärztliche Gesundheitsfachperson bei Spitex oder einer Institution (z.B. Pflegeheim)

Bei Herrn Muster Max ist die Grippeimpfung fällig. Der Hausarzt delegiert dies an die nichtärztliche Gesund- heitsfachperson der Spitex. Dafür öffnet die nichtärztliche Gesundheitsfachperson das Impfportal (Pfeil Nr. 1). Sie ergänzt nun die neu ausgeführte Impfung des Patienten im elektronischen Impf- und Immunschutz- ausweis. Sie kann auch einen neuen Papierausweis ausdrucken. Falls der Hausarzt mit einer APS arbeitet, das strukturierte Impfinformationen enthält, kann diese bei der nächsten Konsultation aktualisiert werden (Pfeil Nr. 2) so dass der Hausarzt stets den aktualisierten Immunstatus seines Patienten kennt.

**Fig.: Use Case 6 (DE)**

![](uc_6_de.png)

