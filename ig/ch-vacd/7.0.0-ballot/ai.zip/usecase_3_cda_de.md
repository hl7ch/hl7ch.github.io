# Usecase 3 Cda De - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Usecase 3 Cda De**

## Usecase 3 Cda De

# UC 3: Anfrage Impfempfehlung

**Ausführlichere Bezeichnung**: Impfempfehlung/Impfstelle Serviceanbieter z.B. Apotheker (Apotheker arbei- tet mit einem Impfportal).

Herr Muster Max, der ein elektronisches Impf- und Immunschutzdossier besitzt, geht zu einem Apotheker um seinen Impfplan zu aktualisieren. Dafür öffnet der Apotheker das Impfportal (Pfeil Nr. 1), kontrolliert die Immunisierungsinformationen und ergänzt eventuell Angaben (wie anderweitig erhaltene Impfungen oder neue Risikofaktoren). Im nächsten Schritt sendet der Apotheker den aktualisierten Immunstatus via eVAC- DOC an den e-Impfcheckservice (Pfeil Nr. 2). Die Anfrage erfolgt pseudonymisiert (siehe UC1). Im nächsten Schritt sendet der e-Impfcheckservice (Pfeil Nr. 3) nach Analyse der Immunisierungsinforma- tionen eine Impfempfehlung bzw. den individuellen Impfplan via eVACDOC zurück an das Impfportal. Der individuelle Impfplan und die aktuellen Impfempfehlungen werden dem Apotheker angezeigt. Der Apothe- ker kann nun die Impfungen ausführen oder dem Patient einen Impfausweis (neu) mit den Empfehlungen ausdrucken. Der Patient kann diesen zur nächsten Konsultation bei seinem Arzt mitbringen (Pfeil Nr. 4), um z.B. eine Auffrischungsimpfung durchführen zu lassen.

**Fig.: Use Case 3 (DE)**

![](uc_3_de.png)

