# 7.7 Immunization (Recommendation Request/Response) - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **7.7 Immunization (Recommendation Request/Response)**

## Example Immunization: 7.7 Immunization (Recommendation Request/Response)

Profile: [CH VACD Immunization](StructureDefinition-ch-vacd-immunization.md)

**Author of the content**: [PractitionerRole](PractitionerRole-6-5-PractitionerRole.md)

**CH VACD Extension verificationStatus**: [SNOMED CT: 59156000](http://snomed.info/id/59156000) (Confirmed)

**identifier**: `urn:oid:2.999.1.2.3.4`/12345

**status**: Completed

**vaccineCode**: Boostrix

**patient**: [Monika Wegmueller Female, DoB: 1967-03-10 ( Medical record number)](Patient-3-2-Patient.md)

**occurrence**: 2013-09-15 00:00:00+0200

**recorded**: 2013-09-15 00:00:00+0200

**lotNumber**: 12345

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [PractitionerRole](PractitionerRole-6-5-PractitionerRole.md) |

**reasonCode**: Immunization

> **protocolApplied****targetDisease**: Diphtheria caused by Corynebacterium diphtheriae (disorder), Tetanus (disorder), Pertussis (disorder)**doseNumber**: 1



## Resource Content

```json
{
  "resourceType" : "Immunization",
  "id" : "7-7-Immunization",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"]
  },
  "extension" : [{
    "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
    "valueReference" : {
      "reference" : "PractitionerRole/6-5-PractitionerRole"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "59156000",
      "display" : "Confirmed"
    }
  }],
  "identifier" : [{
    "system" : "urn:oid:2.999.1.2.3.4",
    "value" : "12345"
  }],
  "status" : "completed",
  "vaccineCode" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
      "code" : "637",
      "display" : "Boostrix"
    }]
  },
  "patient" : {
    "reference" : "Patient/3-2-Patient"
  },
  "occurrenceDateTime" : "2013-09-15T00:00:00+02:00",
  "recorded" : "2013-09-15T00:00:00+02:00",
  "lotNumber" : "12345",
  "performer" : [{
    "actor" : {
      "reference" : "PractitionerRole/6-5-PractitionerRole"
    }
  }],
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "IMMUNIZ",
      "display" : "Immunization"
    }]
  }],
  "protocolApplied" : [{
    "targetDisease" : [{
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "397430003",
        "display" : "Diphtheria caused by Corynebacterium diphtheriae (disorder)"
      }]
    },
    {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "76902006",
        "display" : "Tetanus (disorder)"
      }]
    },
    {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "27836007",
        "display" : "Pertussis (disorder)"
      }]
    }],
    "doseNumberPositiveInt" : 1
  }]
}

```
