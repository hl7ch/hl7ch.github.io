# 7.12 Immunization - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **7.12 Immunization**

## Example Immunization: 7.12 Immunization

Profile: [CH VACD Immunization](StructureDefinition-ch-vacd-immunization.md)

**Author of the content**: [PractitionerRole](PractitionerRole-6-6-PractitionerRole.md)

**CH VACD Extension verificationStatus**: [SNOMED CT: 59156000](http://snomed.info/id/59156000) (Confirmed)

**identifier**: `urn:oid:2.999.1.2.3.4`/12312

**status**: Completed

**vaccineCode**: HBVAXPRO 40

**patient**: [Monika Wegmueller Female, DoB: 1967-03-10 ( Medical record number)](Patient-3-2-Patient.md)

**occurrence**: Somewhen in childhood

**recorded**: 2025-02-26 00:00:00+0100

**lotNumber**: 12345

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [PractitionerRole](PractitionerRole-6-6-PractitionerRole.md) |

**reasonCode**: Immunization

### ProtocolApplieds

| | | |
| :--- | :--- | :--- |
| - | **TargetDisease** | **DoseNumber[x]** |
| * | Viral hepatitis type B (disorder) | 1 |



## Resource Content

```json
{
  "resourceType" : "Immunization",
  "id" : "7-12-Immunization",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"]
  },
  "extension" : [{
    "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
    "valueReference" : {
      "reference" : "PractitionerRole/6-6-PractitionerRole"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "59156000",
      "display" : "Confirmed"
    }
  }],
  "identifier" : [{
    "system" : "urn:oid:2.999.1.2.3.4",
    "value" : "12312"
  }],
  "status" : "completed",
  "vaccineCode" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
      "code" : "545",
      "display" : "HBVAXPRO 40"
    }]
  },
  "patient" : {
    "reference" : "Patient/3-2-Patient"
  },
  "occurrenceString" : "Somewhen in childhood",
  "recorded" : "2025-02-26T00:00:00+01:00",
  "lotNumber" : "12345",
  "performer" : [{
    "actor" : {
      "reference" : "PractitionerRole/6-6-PractitionerRole"
    }
  }],
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "IMMUNIZ",
      "display" : "Immunization"
    }]
  }],
  "protocolApplied" : [{
    "targetDisease" : [{
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "66071002",
        "display" : "Viral hepatitis type B (disorder)"
      }]
    }],
    "doseNumberPositiveInt" : 1
  }]
}

```
