# Patient Document 5 Stammgemeinschaft Composition - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Document 5 Stammgemeinschaft Composition**

## Example Composition: Patient Document 5 Stammgemeinschaft Composition

### Immunization Administration

**Id: **A-D5-P-C1-Composition

**Identifier: **urn:ietf:rfc:3986#urn:uuid:c2e1d265-f3fa-4023-92a3-2e9efe1ca192

**Status: **Final

**Code: **Immunization record (http://snomed.info/sct#41000179103)

**Patient: **[Patient/TC-patient](Patient-TC-patient.md) Wegmueller Monika

**Date: **September 1, 2021

**Authors:**

| |
| :--- |
| [Patient/TC-patient](Patient-TC-patient.md) Wegmueller Monika |

**Confidentiality: **null Normal (qualifier value) (http://snomed.info/sct#17621005)

**Sections:**

| |
| :--- |
| Immunization Administration |
| Comments |



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "A-D5-P-C1-Composition",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-composition-immunization-administration"]
  },
  "language" : "en-US",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:79dabe89-63f4-45e0-9b0f-e4b88950bcd2"
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "41000179103",
      "display" : "Immunization record"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "urn:oid:2.16.756.5.30.1.127.3.10.10",
      "code" : "urn:che:epr:ch-vacd:immunization-administration:2022"
    }]
  }],
  "subject" : {
    "reference" : "Patient/TC-patient"
  },
  "date" : "2021-09-01T00:00:00.390+02:00",
  "author" : [{
    "reference" : "Patient/TC-patient"
  }],
  "title" : "Immunization Administration",
  "confidentiality" : "N",
  "_confidentiality" : {
    "extension" : [{
      "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "17621005",
          "display" : "Normal (qualifier value)"
        }]
      }
    }]
  },
  "custodian" : {
    "reference" : "Organization/TC-ORG1"
  },
  "section" : [{
    "id" : "administration",
    "title" : "Immunization Administration",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "11369-6",
        "display" : "Hx of Immunization"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Hx of Immunization (http://loinc.org#11369-6)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Immunization-TCA03-IMMUN5-patient.html\">Immunization/TCA03-IMMUN5-patient</a></td></tr></table></div>"
    },
    "entry" : [{
      "reference" : "Immunization/TCA03-IMMUN5-patient"
    }]
  },
  {
    "id" : "Annotation",
    "title" : "Comments",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "48767-8",
        "display" : "Annotation comment Imp"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Annotation comment [Interpretation] Narrative (http://loinc.org#48767-8)</span></p></div>"
    }
  }]
}

```
