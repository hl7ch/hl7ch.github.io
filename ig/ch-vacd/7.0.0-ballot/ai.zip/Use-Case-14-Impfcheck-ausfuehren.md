# Use Case 14 Impfcheck Ausfuehren - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Use Case 14 Impfcheck Ausfuehren**

## Use Case 14 Impfcheck Ausfuehren

### Impfcheck ausführen (Gesundheitsfachperson)

Eine Gesundheitsfachperson aktualisiert die Impfdaten ihrer Patientin bzw. ihres Patienten in seinem Primärsystem.

Die Gesundheitsfachperson stellt ggf. die zusätzlichen und für den Impfcheck benötigten medizinischen Informationen mit Bezug zum Immunitätsstatus der Patientin bzw. des Patienten im Primärsystem zusammen.

Die Gesundheitsfachperson ruft den automatischen Impfcheck auf, sichtet die Impfempfehlungen und bespricht diese mit der Patientin bzw. dem Patienten.

Falls eine Impfempfehlung besteht und die Patientin bzw. der Patient die Impfung wünscht, führt die Gesundheitsfachperson die Impfung durch und dokumentiert diese.

Falls eine Impfempfehlung besteht und die Patientin bzw. der Patient die Impfung ablehnt, dokumentiert die Gesundheitsfachperson dies ebenfalls im System.

### Impfcheck ausführen (Patient)

Eine Patientin bzw. ein Patient sichtet die Impfdaten und wählt die zusätzlichen und für den Impfcheck benötigten medizinischen Informationen mit Bezug zum Immunitätsstatus in ihrer bzw. seiner Impf-App.

Die Patientin bzw. der Patient ruft den automatischen Impfcheck auf und sichtet die Impfempfehlungen.

Falls der Impfcheck eine Empfehlung ausgibt und die Patientin bzw. der Patient diese wünscht macht er einen Termin beim seiner Gesundheitsfachperson aus.

Die Gesundheitsfachperson führt die Impfung durch und dokumentiert diese in ihrem System.

Die Patientin bzw. der Patient überprüft die aktualisierten Daten in seiner App. Diese zeigt den aktualisierten Status an.

