# Usecases Cda - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* **Usecases Cda**

## Usecases Cda

The following use cases will describe possible scenarios for the vaccination/immunization.

### The Use Cases (from the CDA-CH-VACD):

* [Use Case 1 (DE): Ambulante Impfstelle mit Papier KG](usecase_1_cda_de.md)
* [Use Case 1 (FR): Centre de vaccination ambulatoire avec DM sur papier](usecase_1_cda_fr.md)
* [Use Case 2 (DE): Ambulante Impfstelle mit elektronischer KG](usecase_2_cda_de.md)
* [Use Case 2 (FR): Centre de vaccination ambulatoire avec DM électronique](usecase_2_cda_fr.md)
* [Use Case 3 (DE): Anfrage Impfempfehlung](usecase_3_cda_de.md)
* [Use Case 3 (FR): Demande de recommandation de vaccination](usecase_3_cda_fr.md)
* [Use Case 4 (DE): Stationäre Impfstelle mit Papier KG](usecase_4_cda_de.md)
* [Use Case 4 (FR): Centre de vaccination hospitalier avec DM sur papier](usecase_4_cda_fr.md)
* [Use Case 5 (DE): Stationäre Impfstelle mit elektronischer KG](usecase_5_cda_de.md)
* [Use Case 5 (FR): Centre de vaccination hospitalier avec DM électronique](usecase_5_cda_fr.md)
* [Use Case 6 (DE): Verabreichung einer Impfung delegieren](usecase_6_cda_de.md)
* [Use Case 6 (FR): Déléguer l’administration d’un vaccin](usecase_6_cda_fr.md)
* [Use Case 7 (DE): Reihenimpfungen](usecase_7_cda_de.md)
* [Use Case 7 (FR): Vaccinations en série](usecase_7_cda_fr.md)

