# Test Case D 03: Aggregated Dokument (RDD03) - Implementation Guide CH VACD v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Case D 03: Aggregated Dokument (RDD03)**

## Example Bundle: Test Case D 03: Aggregated Dokument (RDD03)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "RDD03b",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-document-vaccination-record"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:080ab372-6084-448a-9604-589a547070b2"
  },
  "type" : "document",
  "timestamp" : "2021-11-20T14:00:00.390+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/RDD03-Composition-b",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "RDD03-Composition-b",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-composition-vaccination-record"]
      },
      "language" : "en-US",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><a name=\"Composition_RDD03-Composition-b\"> </a><h3>Vaccination Record</h3><p><b>Id: </b>RDD03-Composition</p><p><b>Identifier: </b><span>urn:ietf:rfc:3986#urn:uuid:080ab372-6084-448a-9604-589a547070b2</span></p><p><b>Status: </b>Final</p><p><b>Code: </b><span>Immunization record (http://snomed.info/sct#41000179103)</span></p><p><b>Patient: </b><a href=\"Patient-TC-patient.html\">Patient/TC-patient</a> Wegmueller Monika</p><p><b>Date: </b>November 20, 2021</p><p><b>Authors:</b></p><table><tr><td><p><a href=\"Patient-TC-patient.html\">Patient/TC-patient</a> Wegmueller Monika</p></td></tr></table><p><b>Confidentiality: </b>null<span> Normal (qualifier value) (http://snomed.info/sct#17621005)</span></p><p><b>Sections:</b></p><table><tr><td>Medical Problems</td></tr></table></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:080ab372-6084-448a-9604-589a547070b2"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "41000179103",
          "display" : "Immunization record"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "urn:oid:2.16.756.5.30.1.127.3.10.10",
          "code" : "urn:che:epr:ch-vacd:vaccination-record:2022"
        }]
      }],
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "date" : "2021-11-20T14:00:00.390+02:00",
      "author" : [{
        "reference" : "Device/TC-Device-Aggregator"
      }],
      "title" : "Vaccination Record",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal (qualifier value)"
            }]
          }
        }]
      },
      "custodian" : {
        "reference" : "Organization/TC-ORG1"
      },
      "section" : [{
        "id" : "medicalproblems",
        "title" : "Medical Problems",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4",
            "display" : "Problem list Reported"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Problem list Reported (http://loinc.org#11450-4)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Condition-TCD03-EXPRISK3-2.html\">Condition/TCD03-EXPRISK3-2</a></td></tr></table></div>"
        },
        "entry" : [{
          "reference" : "Condition/TCD03-EXPRISK3-2"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/TC-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "TC-patient",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_TC-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient TC-patient</b></p><a name=\"TC-patient\"> </a><a name=\"hcTC-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: tel:+41.32.685.12.34(Home)</li><li>Leidensweg 10 Specimendorf 9876 CH </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "12345678"
      }],
      "name" : [{
        "family" : "Wegmueller",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.685.12.34",
        "use" : "home"
      }],
      "gender" : "female",
      "birthDate" : "1967-02-10",
      "address" : [{
        "type" : "both",
        "line" : ["Leidensweg 10"],
        "city" : "Specimendorf",
        "postalCode" : "9876",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG1</b></p><a name=\"TC-ORG1\"> </a><a name=\"hcTC-ORG1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601777777718</p><p><b>name</b>: Gruppenpraxis Müller</p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:bereit@gruppenpraxis.ch\">mailto:bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich ZH 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601777777718"
      }],
      "name" : "Gruppenpraxis Müller",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "state" : "ZH",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Device/TC-Device-Aggregator",
    "resource" : {
      "resourceType" : "Device",
      "id" : "TC-Device-Aggregator",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_TC-Device-Aggregator\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device TC-Device-Aggregator</b></p><a name=\"TC-Device-Aggregator\"> </a><a name=\"hcTC-Device-Aggregator\"> </a><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601999999981</p><p><b>status</b>: Active</p><p><b>manufacturer</b>: The Aggregator Company</p><p><b>manufactureDate</b>: 2023-01-01</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Vaccination Aggregator</td><td>Manufacturer name</td></tr></table><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>v1.0.0</td></tr></table><p><b>contact</b>: ph: tel:+41.56.299.55.22(Work), <a href=\"mailto:mailto:resultate@aggregator.ch\">mailto:resultate@aggregator.ch</a>, <a href=\"http://www.aggregator.ch\">http://www.aggregator.ch</a></p><p><b>location</b>: <a href=\"Location-TC-Device-Aggregator-Location.html\">Location: status = active; telecom = ph: tel:+41.56.299.55.22(Work),mailto:resultate@labor-messenalles.ch(Work),http://www.labor-messenalles.ch(Work)</a></p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601999999981"
      }],
      "status" : "active",
      "manufacturer" : "The Aggregator Company",
      "manufactureDate" : "2023-01-01",
      "deviceName" : [{
        "name" : "Vaccination Aggregator",
        "type" : "manufacturer-name"
      }],
      "version" : [{
        "value" : "v1.0.0"
      }],
      "contact" : [{
        "system" : "phone",
        "value" : "tel:+41.56.299.55.22",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:resultate@aggregator.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.aggregator.ch",
        "use" : "work"
      }],
      "location" : {
        "reference" : "Location/TC-Device-Aggregator-Location"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/TC-Device-Aggregator-Location",
    "resource" : {
      "resourceType" : "Location",
      "id" : "TC-Device-Aggregator-Location",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_TC-Device-Aggregator-Location\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location TC-Device-Aggregator-Location</b></p><a name=\"TC-Device-Aggregator-Location\"> </a><a name=\"hcTC-Device-Aggregator-Location\"> </a><p><b>status</b>: Active</p><p><b>telecom</b>: ph: tel:+41.56.299.55.22(Work), <a href=\"mailto:mailto:resultate@labor-messenalles.ch\">mailto:resultate@labor-messenalles.ch</a>, <a href=\"http://www.labor-messenalles.ch\">http://www.labor-messenalles.ch</a></p><p><b>address</b>: Messweg 1 Wissen ZG 6310 CH </p></div>"
      },
      "status" : "active",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.56.299.55.22",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:resultate@labor-messenalles.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.labor-messenalles.ch",
        "use" : "work"
      }],
      "address" : {
        "line" : ["Messweg 1"],
        "city" : "Wissen",
        "state" : "ZG",
        "postalCode" : "6310",
        "country" : "CH"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP1-C1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "TC-HCP1-C1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP1-C1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP1-C1</b></p><a name=\"TC-HCP1-C1\"> </a><a name=\"hcTC-HCP1-C1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601888888884</p><p><b>active</b>: true</p><p><b>name</b>: Peter Müller </p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:allzeit.bereit@gruppenpraxis.ch\">mailto:allzeit.bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich 8005 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601888888884"
      }],
      "active" : true,
      "name" : [{
        "family" : "Müller",
        "given" : ["Peter"],
        "prefix" : ["Dr. med."]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:allzeit.bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "type" : "physical",
        "line" : ["Grabenstrasse 2"],
        "city" : "Zürich",
        "postalCode" : "8005",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP1-ORG1-ROLE-author",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP1-ORG1-ROLE-author",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP1-ORG1-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP1-ORG1-ROLE-author</b></p><a name=\"TC-HCP1-ORG1-ROLE-author\"> </a><a name=\"hcTC-HCP1-ORG1-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP1-C1.html\">Practitioner Peter Müller </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG1.html\">Organization Gruppenpraxis Müller</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP1-C1"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG1"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP2-C2",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "TC-HCP2-C2",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP2-C2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP2-C2</b></p><a name=\"TC-HCP2-C2\"> </a><a name=\"hcTC-HCP2-C2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601999999998</p><p><b>active</b>: true</p><p><b>name</b>: Gabriela Meier </p><p><b>telecom</b>: ph: tel:+41.32.234.77.88(Work), <a href=\"mailto:mailto:leitung@praxis-gesund.ch\">mailto:leitung@praxis-gesund.ch</a>, <a href=\"http://www.praxis-gesund.ch\">http://www.praxis-gesund.ch</a></p><p><b>address</b>: Werthgasse 34 Bern ZH 3000 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601999999998"
      }],
      "active" : true,
      "name" : [{
        "family" : "Meier",
        "given" : ["Gabriela"],
        "prefix" : ["Dr. med."]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.77.88",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:leitung@praxis-gesund.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.praxis-gesund.ch",
        "use" : "work"
      }],
      "address" : [{
        "type" : "physical",
        "line" : ["Werthgasse 34"],
        "city" : "Bern",
        "state" : "ZH",
        "postalCode" : "3000",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG2",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "TC-ORG2",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG2</b></p><a name=\"TC-ORG2\"> </a><a name=\"hcTC-ORG2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601999999912</p><p><b>name</b>: Praxis Dr. G. Meier</p><p><b>telecom</b>: ph: tel:+41.32.234.77.88(Work), <a href=\"mailto:mailto:leitung@praxis-gesund.ch\">mailto:leitung@praxis-gesund.ch</a>, <a href=\"http://www.praxis-gesund.ch\">http://www.praxis-gesund.ch</a></p><p><b>address</b>: Werthgasse 34 Bern ZH 3000 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601999999912"
      }],
      "name" : "Praxis Dr. G. Meier",
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.32.234.77.88",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:leitung@praxis-gesund.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.praxis-gesund.ch",
        "use" : "work"
      }],
      "address" : [{
        "line" : ["Werthgasse 34"],
        "city" : "Bern",
        "state" : "ZH",
        "postalCode" : "3000",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP2-ORG2-ROLE-author",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP2-ORG2-ROLE-author",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP2-ORG2-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP2-ORG2-ROLE-author</b></p><a name=\"TC-HCP2-ORG2-ROLE-author\"> </a><a name=\"hcTC-HCP2-ORG2-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP2-C2.html\">Practitioner Gabriela Meier </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG2.html\">Organization Praxis Dr. G. Meier</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP2-C2"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG2"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP3-C1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "TC-HCP3-C1",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP3-C1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP3-C1</b></p><a name=\"TC-HCP3-C1\"> </a><a name=\"hcTC-HCP3-C1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601077777777</p><p><b>active</b>: true</p><p><b>name</b>: Macht Gesund </p><p><b>telecom</b>: ph: tel:+41.11.222.55.66(Work), <a href=\"mailto:mailto:macht.gesund@gruppenpraxis.ch\">mailto:macht.gesund@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Doktorgasse 2 Musterhausen 8888 CH </p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601077777777"
      }],
      "active" : true,
      "name" : [{
        "family" : "Gesund",
        "given" : ["Macht"],
        "prefix" : ["Dr. med."]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "tel:+41.11.222.55.66",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:macht.gesund@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "type" : "physical",
        "line" : ["Doktorgasse 2"],
        "city" : "Musterhausen",
        "postalCode" : "8888",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP3-ORG1-ROLE-author",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "TC-HCP3-ORG1-ROLE-author",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP3-ORG1-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP3-ORG1-ROLE-author</b></p><a name=\"TC-HCP3-ORG1-ROLE-author\"> </a><a name=\"hcTC-HCP3-ORG1-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/7.0.0-ballot/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP3-C1.html\">Practitioner Macht Gesund </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG1.html\">Organization Gruppenpraxis Müller</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/TC-HCP3-C1"
      },
      "organization" : {
        "reference" : "Organization/TC-ORG1"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Condition/TCD03-EXPRISK1-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "TCD03-EXPRISK1-2",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medical-problems"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_TCD03-EXPRISK1-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition TCD03-EXPRISK1-2</b></p><a name=\"TCD03-EXPRISK1-2\"> </a><a name=\"hcTCD03-EXPRISK1-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medical-problems.html\">CH VACD Medical Problems</a></p></div><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK2-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK3-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/85b0d0dc-200b-4f8c-9583-900802e88783</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1186914001}\">Intellectual disability nurse (occupation)</span></p><p><b>subject</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>onset</b>: 2021-10-01</p><p><b>recordedDate</b>: 2021-10-20</p><p><b>recorder</b>: <a href=\"PractitionerRole-TC-HCP1-ORG1-ROLE-author.html\">PractitionerRole</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK2-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      },
      {
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK3-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      }],
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "85b0d0dc-200b-4f8c-9583-900802e88783"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1186914001",
          "display" : "Intellectual disability nurse (occupation)"
        }]
      },
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "onsetDateTime" : "2021-10-01",
      "recordedDate" : "2021-10-20",
      "recorder" : {
        "reference" : "PractitionerRole/TC-HCP1-ORG1-ROLE-author"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Condition/TCD03-EXPRISK2-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "TCD03-EXPRISK2-2",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medical-problems"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_TCD03-EXPRISK2-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition TCD03-EXPRISK2-2</b></p><a name=\"TCD03-EXPRISK2-2\"> </a><a name=\"hcTCD03-EXPRISK2-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medical-problems.html\">CH VACD Medical Problems</a></p></div><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK1-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK3-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/60f7b06c-b960-4a21-b596-5b149832ed9f</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1186914001}\">Intellectual disability nurse (occupation)</span></p><p><b>subject</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>onset</b>: 2021-10-01</p><p><b>recordedDate</b>: 2021-10-21</p><p><b>recorder</b>: <a href=\"PractitionerRole-TC-HCP3-ORG1-ROLE-author.html\">PractitionerRole</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK1-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      },
      {
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK3-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      }],
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "60f7b06c-b960-4a21-b596-5b149832ed9f"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1186914001",
          "display" : "Intellectual disability nurse (occupation)"
        }]
      },
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "onsetDateTime" : "2021-10-01",
      "recordedDate" : "2021-10-21",
      "recorder" : {
        "reference" : "PractitionerRole/TC-HCP3-ORG1-ROLE-author"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Condition/TCD03-EXPRISK3-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "TCD03-EXPRISK3-2",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medical-problems"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_TCD03-EXPRISK3-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition TCD03-EXPRISK3-2</b></p><a name=\"TCD03-EXPRISK3-2\"> </a><a name=\"hcTCD03-EXPRISK3-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medical-problems.html\">CH VACD Medical Problems</a></p></div><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK1-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><blockquote><p><b>CH VACD Extension Merging Conflict Entry Reference</b></p><ul><li>entry: <a href=\"Condition-TCD03-EXPRISK2-2.html\">Condition Intellectual disability nurse (occupation)</a></li><li>conflict: duplicate</li></ul></blockquote><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/f9c5a902-42e6-4ac1-a623-70c75634f162</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1186914001}\">Intellectual disability nurse (occupation)</span></p><p><b>subject</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>onset</b>: 2021-10-01</p><p><b>recordedDate</b>: 2021-10-22</p><p><b>recorder</b>: <a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-author.html\">PractitionerRole</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK1-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      },
      {
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "reference" : "Condition/TCD03-EXPRISK2-2"
          }
        },
        {
          "url" : "conflict",
          "valueCode" : "duplicate"
        }],
        "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-merging-conflict-entry-reference"
      }],
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "f9c5a902-42e6-4ac1-a623-70c75634f162"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1186914001",
          "display" : "Intellectual disability nurse (occupation)"
        }]
      },
      "subject" : {
        "reference" : "Patient/TC-patient"
      },
      "onsetDateTime" : "2021-10-01",
      "recordedDate" : "2021-10-22",
      "recorder" : {
        "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-author"
      }
    }
  }]
}

```
