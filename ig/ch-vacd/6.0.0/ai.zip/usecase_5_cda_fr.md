# Usecase 5 Cda Fr - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* **Usecase 5 Cda Fr**

## Usecase 5 Cda Fr

# UC 5: Centre de vaccination hospitalier avec DM électronique

**Désignation détaillée**: centre de vaccination dans un hôpital (médecin travaillant avec un dossier médical électronique) Cf. chapitre [UC 2](usecase_2_cda_fr.md): centre de vaccination ambulatoire avec DM électronique. Le médecin utilise un système d’information hospitalier (SIH) en lieu et place d’un logiciel de cabinet médical. Les UC [2a / 2b / 2c](usecase_2_cda_fr.md) sont exécutés de la même manière.

