# Test Case D 01: Document HCP1 with Immunization Entries (RDD01) - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Case D 01: Document HCP1 with Immunization Entries (RDD01)**

## Example Bundle: Test Case D 01: Document HCP1 with Immunization Entries (RDD01)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "D-D2-HCP2-C2",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-document-immunization-administration"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:cb155588-9718-42b0-9e2e-f50f8bab5bcf"
  },
  "type" : "document",
  "timestamp" : "2021-12-08T10:00:00.390+02:00",
  "entry" : [
    {
      "fullUrl" : "http://test.fhir.ch/r4/Composition/D-D2-HCP2-C2-Composition",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "D-D2-HCP2-C2-Composition",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-composition-immunization-administration"
          ]
        },
        "language" : "en-US",
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><a name=\"Composition_D-D2-HCP2-C2-Composition\"> </a><h3>Immunization Administration</h3><p><b>Id: </b>D-D2-HCP2-C2-Composition</p><p><b>Identifier: </b><span>urn:ietf:rfc:3986#urn:uuid:cb155588-9718-42b0-9e2e-f50f8bab5bcf</span></p><p><b>Status: </b>Final</p><p><b>Code: </b><span>Immunization record (http://snomed.info/sct#41000179103)</span></p><p><b>Patient: </b><a href=\"Patient-TC-patient.html\">Patient/TC-patient</a> Wegmueller Monika</p><p><b>Date: </b>October 6, 2021</p><p><b>Authors:</b></p><table><tr><td><p><a href=\"Patient-TC-patient.html\">Patient/TC-patient</a> Wegmueller Monika</p></td></tr></table><p><b>Confidentiality: </b>null<span> Normal (qualifier value) (http://snomed.info/sct#17621005)</span></p><p><b>Sections:</b></p><table><tr><td>Immunization Administration</td></tr><tr><td>Comments</td></tr></table></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:cb155588-9718-42b0-9e2e-f50f8bab5bcf"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "41000179103",
              "display" : "Immunization record"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "urn:oid:2.16.756.5.30.1.127.3.10.10",
                "code" : "urn:che:epr:ch-vacd:immunization-administration:2022"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/TC-patient"
        },
        "date" : "2021-10-06T00:00:00.390+02:00",
        "author" : [
          {
            "reference" : "Patient/TC-patient"
          }
        ],
        "title" : "Immunization Administration",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "custodian" : {
          "reference" : "Organization/TC-ORG1"
        },
        "section" : [
          {
            "id" : "administration",
            "title" : "Immunization Administration",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "11369-6",
                  "display" : "Hx of Immunization"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Hx of Immunization (http://loinc.org#11369-6)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Immunization-TCD01-IMMUN3.html\">Immunization/TCD01-IMMUN3</a></td></tr><tr><td><a href=\"Immunization-TCD01-IMMUN4.html\">Immunization/TCD01-IMMUN4</a></td></tr><tr><td><a href=\"Immunization-TCD01-IMMUN5.html\">Immunization/TCD01-IMMUN5</a></td></tr></table></div>"
            },
            "entry" : [
              {
                "reference" : "Immunization/TCD01-IMMUN3"
              },
              {
                "reference" : "Immunization/TCD01-IMMUN4"
              },
              {
                "reference" : "Immunization/TCD01-IMMUN5"
              }
            ]
          },
          {
            "id" : "Annotation",
            "title" : "Comments",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "48767-8",
                  "display" : "Annotation comment Imp"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>Annotation comment [Interpretation] Narrative (http://loinc.org#48767-8)</span></p></div>"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Patient/TC-patient",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "TC-patient",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_TC-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient TC-patient</b></p><a name=\"TC-patient\"> </a><a name=\"hcTC-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: tel:+41.32.685.12.34(Home)</li><li>Leidensweg 10 Specimendorf 9876 CH </li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "12345678"
          }
        ],
        "name" : [
          {
            "family" : "Wegmueller",
            "given" : ["Monika"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41.32.685.12.34",
            "use" : "home"
          }
        ],
        "gender" : "female",
        "birthDate" : "1967-02-10",
        "address" : [
          {
            "type" : "both",
            "line" : ["Leidensweg 10"],
            "city" : "Specimendorf",
            "postalCode" : "9876",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG1",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "TC-ORG1",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG1</b></p><a name=\"TC-ORG1\"> </a><a name=\"hcTC-ORG1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601777777718</p><p><b>name</b>: Gruppenpraxis Müller</p><p><b>telecom</b>: ph: tel:+41.32.234.55.66(Work), <a href=\"mailto:mailto:bereit@gruppenpraxis.ch\">mailto:bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Grabenstrasse 2 Zürich ZH 8005 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601777777718"
          }
        ],
        "name" : "Gruppenpraxis Müller",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41.32.234.55.66",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "mailto:bereit@gruppenpraxis.ch",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "http://www.gruppenpraxis.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Grabenstrasse 2"],
            "city" : "Zürich",
            "state" : "ZH",
            "postalCode" : "8005",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Practitioner/TC-HCP2-C2",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "TC-HCP2-C2",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_TC-HCP2-C2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner TC-HCP2-C2</b></p><a name=\"TC-HCP2-C2\"> </a><a name=\"hcTC-HCP2-C2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601999999998</p><p><b>active</b>: true</p><p><b>name</b>: Gabriela Meier </p><p><b>telecom</b>: ph: tel:+41.32.234.77.88(Work), <a href=\"mailto:mailto:leitung@praxis-gesund.ch\">mailto:leitung@praxis-gesund.ch</a>, <a href=\"http://www.praxis-gesund.ch\">http://www.praxis-gesund.ch</a></p><p><b>address</b>: Werthgasse 34 Bern ZH 3000 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601999999998"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Meier",
            "given" : ["Gabriela"],
            "prefix" : ["Dr. med."]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41.32.234.77.88",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "mailto:leitung@praxis-gesund.ch",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "http://www.praxis-gesund.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "type" : "physical",
            "line" : ["Werthgasse 34"],
            "city" : "Bern",
            "state" : "ZH",
            "postalCode" : "3000",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG2",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "TC-ORG2",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG2</b></p><a name=\"TC-ORG2\"> </a><a name=\"hcTC-ORG2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601999999912</p><p><b>name</b>: Praxis Dr. G. Meier</p><p><b>telecom</b>: ph: tel:+41.32.234.77.88(Work), <a href=\"mailto:mailto:leitung@praxis-gesund.ch\">mailto:leitung@praxis-gesund.ch</a>, <a href=\"http://www.praxis-gesund.ch\">http://www.praxis-gesund.ch</a></p><p><b>address</b>: Werthgasse 34 Bern ZH 3000 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601999999912"
          }
        ],
        "name" : "Praxis Dr. G. Meier",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41.32.234.77.88",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "mailto:leitung@praxis-gesund.ch",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "http://www.praxis-gesund.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Werthgasse 34"],
            "city" : "Bern",
            "state" : "ZH",
            "postalCode" : "3000",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP2-ORG2-ROLE-performer",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "TC-HCP2-ORG2-ROLE-performer",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP2-ORG2-ROLE-performer\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP2-ORG2-ROLE-performer</b></p><a name=\"TC-HCP2-ORG2-ROLE-performer\"> </a><a name=\"hcTC-HCP2-ORG2-ROLE-performer\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP2-C2.html\">Practitioner Gabriela Meier </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG2.html\">Organization Praxis Dr. G. Meier</a></p></div>"
        },
        "active" : true,
        "practitioner" : {
          "reference" : "Practitioner/TC-HCP2-C2"
        },
        "organization" : {
          "reference" : "Organization/TC-ORG2"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/TC-HCP2-ORG2-ROLE-author",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "TC-HCP2-ORG2-ROLE-author",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole-epr"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_TC-HCP2-ORG2-ROLE-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole TC-HCP2-ORG2-ROLE-author</b></p><a name=\"TC-HCP2-ORG2-ROLE-author\"> </a><a name=\"hcTC-HCP2-ORG2-ROLE-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-practitionerrole-epr.html\">CH Core PractitionerRole EPR</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-TC-HCP2-C2.html\">Practitioner Gabriela Meier </a></p><p><b>organization</b>: <a href=\"Organization-TC-ORG2.html\">Organization Praxis Dr. G. Meier</a></p></div>"
        },
        "active" : true,
        "practitioner" : {
          "reference" : "Practitioner/TC-HCP2-C2"
        },
        "organization" : {
          "reference" : "Organization/TC-ORG2"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Immunization/TCD01-IMMUN3",
      "resource" : {
        "resourceType" : "Immunization",
        "id" : "TCD01-IMMUN3",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_TCD01-IMMUN3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization TCD01-IMMUN3</b></p><a name=\"TCD01-IMMUN3\"> </a><a name=\"hcTCD01-IMMUN3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization.html\">CH VACD Immunization</a></p></div><p><b>Author of the content</b>: <a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-author.html\">PractitionerRole</a></p><p><b>CH VACD Extension Immunization Medication Reference</b>: <a href=\"Medication-TC-IMMUN-MEDIC-BOOSTRIX.html\">Medication BOOSTRIX Inj Susp</a></p><p><b>CH VACD Extension verificationStatus</b>: <a href=\"http://snomed.info/id/59156000\">SNOMED CT: 59156000</a> (Confirmed)</p><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/urn:uuid:58457607-9160-4d0a-9a79-55495755a677</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs 637}\">Boostrix</span></p><p><b>patient</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>occurrence</b>: 2020-12-09</p><p><b>recorded</b>: 2020-12-09 11:00:00+0200</p><p><b>lotNumber</b>: AHAVB946A</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-performer.html\">PractitionerRole</a></td></tr></table><blockquote><p><b>protocolApplied</b></p><p><b>targetDisease</b>: <span title=\"Codes:{http://snomed.info/sct 76902006}\">Tetanus (disorder)</span>, <span title=\"Codes:{http://snomed.info/sct 27836007}\">Pertussis (disorder)</span>, <span title=\"Codes:{http://snomed.info/sct 397430003}\">Diphtheria caused by Corynebacterium diphtheriae (disorder)</span></p><p><b>doseNumber</b>: 1</p></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
            "valueReference" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-author"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
            "valueReference" : {
              "reference" : "Medication/TC-IMMUN-MEDIC-BOOSTRIX"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "59156000",
              "display" : "Confirmed"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "urn:uuid:58457607-9160-4d0a-9a79-55495755a677"
          }
        ],
        "status" : "completed",
        "vaccineCode" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
              "code" : "637",
              "display" : "Boostrix"
            }
          ]
        },
        "patient" : {
          "reference" : "Patient/TC-patient"
        },
        "occurrenceDateTime" : "2020-12-09",
        "recorded" : "2020-12-09T11:00:00.390+02:00",
        "lotNumber" : "AHAVB946A",
        "route" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "20035000",
              "display" : "Intramuscular use"
            }
          ]
        },
        "performer" : [
          {
            "actor" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-performer"
            }
          }
        ],
        "protocolApplied" : [
          {
            "targetDisease" : [
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "76902006",
                    "display" : "Tetanus (disorder)"
                  }
                ]
              },
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "27836007",
                    "display" : "Pertussis (disorder)"
                  }
                ]
              },
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "397430003",
                    "display" : "Diphtheria caused by Corynebacterium diphtheriae (disorder)"
                  }
                ]
              }
            ],
            "doseNumberPositiveInt" : 1
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Medication/TC-IMMUN-MEDIC-BOOSTRIX",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "TC-IMMUN-MEDIC-BOOSTRIX",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medication-for-immunization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_TC-IMMUN-MEDIC-BOOSTRIX\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication TC-IMMUN-MEDIC-BOOSTRIX</b></p><a name=\"TC-IMMUN-MEDIC-BOOSTRIX\"> </a><a name=\"hcTC-IMMUN-MEDIC-BOOSTRIX\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medication-for-immunization.html\">CH VACD Medication For Immunization</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/ead68e47-34a6-4534-a658-b718e565fb91</p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680006370012}\">BOOSTRIX Inj Susp</span></p><p><b>status</b>: Active</p><p><b>manufacturer</b>: <a href=\"Organization-TC-ORG-GSK.html\">Organization GlaxoSmithKline AG</a></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 11202000}\">Suspension for injection</span></p><p><b>amount</b>: 0.5 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span>/1 Syringe (unit of presentation)<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code733020007 = 'Syringe')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106181007}\">Immunologic substance (substance)</span></td></tr></table><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>AHAVB946A</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "ead68e47-34a6-4534-a658-b718e565fb91"
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:2.51.1.1",
              "code" : "7680006370012",
              "display" : "BOOSTRIX Inj Susp"
            }
          ],
          "text" : "BOOSTRIX Inj Susp"
        },
        "status" : "active",
        "manufacturer" : {
          "reference" : "Organization/TC-ORG-GSK"
        },
        "form" : {
          "coding" : [
            {
              "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
              "code" : "11202000",
              "display" : "Suspension for injection"
            }
          ]
        },
        "amount" : {
          "numerator" : {
            "value" : 0.5,
            "unit" : "milliliter",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Syringe (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "733020007"
          }
        },
        "ingredient" : [
          {
            "itemCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "106181007",
                  "display" : "Immunologic substance (substance)"
                }
              ],
              "text" : "Immunologic substance (substance)"
            }
          }
        ],
        "batch" : {
          "lotNumber" : "AHAVB946A"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Immunization/TCD01-IMMUN4",
      "resource" : {
        "resourceType" : "Immunization",
        "id" : "TCD01-IMMUN4",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_TCD01-IMMUN4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization TCD01-IMMUN4</b></p><a name=\"TCD01-IMMUN4\"> </a><a name=\"hcTCD01-IMMUN4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization.html\">CH VACD Immunization</a></p></div><p><b>Author of the content</b>: <a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-author.html\">PractitionerRole</a></p><p><b>CH VACD Extension Immunization Medication Reference</b>: <a href=\"Medication-TC-IMMUN-MEDIC-PRIORIX.html\">Medication PRIORIX Trockensub c Solv</a></p><p><b>CH VACD Extension verificationStatus</b>: <a href=\"http://snomed.info/id/59156000\">SNOMED CT: 59156000</a> (Confirmed)</p><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/urn:uuid:58457607-9160-4d0a-9a79-55495755a677</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs 615}\">Priorix</span></p><p><b>patient</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>occurrence</b>: 2020-12-09</p><p><b>recorded</b>: 2020-12-09 11:00:00+0200</p><p><b>lotNumber</b>: A69FE297A</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-performer.html\">PractitionerRole</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>TargetDisease</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 36989005}\">Mumps (disorder)</span></td><td>1</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
            "valueReference" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-author"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
            "valueReference" : {
              "reference" : "Medication/TC-IMMUN-MEDIC-PRIORIX"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "59156000",
              "display" : "Confirmed"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "urn:uuid:58457607-9160-4d0a-9a79-55495755a677"
          }
        ],
        "status" : "completed",
        "vaccineCode" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
              "code" : "615",
              "display" : "Priorix"
            }
          ]
        },
        "patient" : {
          "reference" : "Patient/TC-patient"
        },
        "occurrenceDateTime" : "2020-12-09",
        "recorded" : "2020-12-09T11:00:00.390+02:00",
        "lotNumber" : "A69FE297A",
        "route" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "20035000",
              "display" : "Intramuscular use"
            }
          ]
        },
        "performer" : [
          {
            "actor" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-performer"
            }
          }
        ],
        "protocolApplied" : [
          {
            "targetDisease" : [
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "36989005",
                    "display" : "Mumps (disorder)"
                  }
                ]
              }
            ],
            "doseNumberPositiveInt" : 1
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Medication/TC-IMMUN-MEDIC-PRIORIX",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "TC-IMMUN-MEDIC-PRIORIX",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medication-for-immunization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_TC-IMMUN-MEDIC-PRIORIX\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication TC-IMMUN-MEDIC-PRIORIX</b></p><a name=\"TC-IMMUN-MEDIC-PRIORIX\"> </a><a name=\"hcTC-IMMUN-MEDIC-PRIORIX\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medication-for-immunization.html\">CH VACD Medication For Immunization</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/47fd8496-cadb-4546-9533-5fad5127a1d5</p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680006150010}\">PRIORIX Trockensub c Solv</span></p><p><b>status</b>: Active</p><p><b>manufacturer</b>: <a href=\"Organization-TC-ORG-GSK.html\">Organization GlaxoSmithKline AG</a></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 11202000}\">Suspension for injection</span></p><p><b>amount</b>: 0.5 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span>/1 Syringe (unit of presentation)<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code733020007 = 'Syringe')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106181007}\">Immunologic substance (substance)</span></td></tr></table><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>A69FE297A</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "47fd8496-cadb-4546-9533-5fad5127a1d5"
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:2.51.1.1",
              "code" : "7680006150010",
              "display" : "PRIORIX Trockensub c Solv"
            }
          ],
          "text" : "PRIORIX Trockensub c Solv"
        },
        "status" : "active",
        "manufacturer" : {
          "reference" : "Organization/TC-ORG-GSK"
        },
        "form" : {
          "coding" : [
            {
              "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
              "code" : "11202000",
              "display" : "Suspension for injection"
            }
          ]
        },
        "amount" : {
          "numerator" : {
            "value" : 0.5,
            "unit" : "milliliter",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Syringe (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "733020007"
          }
        },
        "ingredient" : [
          {
            "itemCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "106181007",
                  "display" : "Immunologic substance (substance)"
                }
              ],
              "text" : "Immunologic substance (substance)"
            }
          }
        ],
        "batch" : {
          "lotNumber" : "A69FE297A"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG-GSK",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "TC-ORG-GSK",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG-GSK\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG-GSK</b></p><a name=\"TC-ORG-GSK\"> </a><a name=\"hcTC-ORG-GSK\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001000674</p><p><b>name</b>: GlaxoSmithKline AG</p><p><b>telecom</b>: ph: tel:+41 31 862 21 11(Work), fax: fax:+41 31 862 22 00(Work), <a href=\"mailto:mailto:swiss.info@gsk.com\">mailto:swiss.info@gsk.com</a>, <a href=\"https://www.gsk.com\">https://www.gsk.com</a></p><p><b>address</b>: Talstrasse 3-5 Münchenbuchsee BE 3053 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001000674"
          }
        ],
        "name" : "GlaxoSmithKline AG",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41 31 862 21 11",
            "use" : "work"
          },
          {
            "system" : "fax",
            "value" : "fax:+41 31 862 22 00",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "mailto:swiss.info@gsk.com",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "https://www.gsk.com",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Talstrasse 3-5"],
            "city" : "Münchenbuchsee",
            "state" : "BE",
            "postalCode" : "3053",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Immunization/TCD01-IMMUN5",
      "resource" : {
        "resourceType" : "Immunization",
        "id" : "TCD01-IMMUN5",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-immunization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_TCD01-IMMUN5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization TCD01-IMMUN5</b></p><a name=\"TCD01-IMMUN5\"> </a><a name=\"hcTCD01-IMMUN5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-immunization.html\">CH VACD Immunization</a></p></div><p><b>Author of the content</b>: <a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-author.html\">PractitionerRole</a></p><p><b>CH VACD Extension Immunization Medication Reference</b>: <a href=\"Medication-TC-IMMUN-MEDIC-GARDASIL9.html\">Medication GARDASIL 9 Inj Susp Fertspr</a></p><p><b>CH VACD Extension verificationStatus</b>: <a href=\"http://snomed.info/id/59156000\">SNOMED CT: 59156000</a> (Confirmed)</p><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/urn:uuid:cc632c23-ffb4-4cd9-a090-61afd0746aff</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs 65387}\">Gardasil 9</span></p><p><b>patient</b>: <a href=\"Patient-TC-patient.html\">Monika Wegmueller  Female, DoB: 1967-02-10 ( Medical record number)</a></p><p><b>occurrence</b>: 2021-03-29</p><p><b>recorded</b>: 2021-03-29 11:00:00+0200</p><p><b>lotNumber</b>: 12435</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"PractitionerRole-TC-HCP2-ORG2-ROLE-performer.html\">PractitionerRole</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>TargetDisease</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 240532009}\">Human papillomavirus infection (disorder)</span></td><td>1</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-author",
            "valueReference" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-author"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-immunization-medication-reference",
            "valueReference" : {
              "reference" : "Medication/TC-IMMUN-MEDIC-GARDASIL9"
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-ext-verification-status",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "59156000",
              "display" : "Confirmed"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "urn:uuid:cc632c23-ffb4-4cd9-a090-61afd0746aff"
          }
        ],
        "status" : "completed",
        "vaccineCode" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-cs",
              "code" : "65387",
              "display" : "Gardasil 9"
            }
          ]
        },
        "patient" : {
          "reference" : "Patient/TC-patient"
        },
        "occurrenceDateTime" : "2021-03-29",
        "recorded" : "2021-03-29T11:00:00.390+02:00",
        "lotNumber" : "12435",
        "route" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "20035000",
              "display" : "Intramuscular use"
            }
          ]
        },
        "performer" : [
          {
            "actor" : {
              "reference" : "PractitionerRole/TC-HCP2-ORG2-ROLE-performer"
            }
          }
        ],
        "protocolApplied" : [
          {
            "targetDisease" : [
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "240532009",
                    "display" : "Human papillomavirus infection (disorder)"
                  }
                ]
              }
            ],
            "doseNumberPositiveInt" : 1
          }
        ]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Medication/TC-IMMUN-MEDIC-GARDASIL9",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "TC-IMMUN-MEDIC-GARDASIL9",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-vacd/StructureDefinition/ch-vacd-medication-for-immunization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_TC-IMMUN-MEDIC-GARDASIL9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication TC-IMMUN-MEDIC-GARDASIL9</b></p><a name=\"TC-IMMUN-MEDIC-GARDASIL9\"> </a><a name=\"hcTC-IMMUN-MEDIC-GARDASIL9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-vacd-medication-for-immunization.html\">CH VACD Medication For Immunization</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/cdd3c568-516b-4dea-94b4-1a05683595fc</p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680653870019}\">GARDASIL 9 Inj Susp Fertspr</span></p><p><b>status</b>: Active</p><p><b>manufacturer</b>: <a href=\"Organization-TC-ORG-MSD.html\">Organization MSD Merck Sharp &amp; Dohme AG</a></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 11202000}\">Suspension for injection</span></p><p><b>amount</b>: 0.5 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span>/1 Syringe (unit of presentation)<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code733020007 = 'Syringe')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106181007}\">Immunologic substance (substance)</span></td></tr></table><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td></tr><tr><td style=\"display: none\">*</td><td>A69FE297A</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.999.1.2.3.4",
            "value" : "cdd3c568-516b-4dea-94b4-1a05683595fc"
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:2.51.1.1",
              "code" : "7680653870019",
              "display" : "GARDASIL 9 Inj Susp Fertspr"
            }
          ],
          "text" : "GARDASIL 9 Inj Susp Fertspr"
        },
        "status" : "active",
        "manufacturer" : {
          "reference" : "Organization/TC-ORG-MSD"
        },
        "form" : {
          "coding" : [
            {
              "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
              "code" : "11202000",
              "display" : "Suspension for injection"
            }
          ]
        },
        "amount" : {
          "numerator" : {
            "value" : 0.5,
            "unit" : "milliliter",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Syringe (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "733020007"
          }
        },
        "ingredient" : [
          {
            "itemCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "106181007",
                  "display" : "Immunologic substance (substance)"
                }
              ],
              "text" : "Immunologic substance (substance)"
            }
          }
        ],
        "batch" : {
          "lotNumber" : "A69FE297A"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/TC-ORG-MSD",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "TC-ORG-MSD",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_TC-ORG-MSD\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization TC-ORG-MSD</b></p><a name=\"TC-ORG-MSD\"> </a><a name=\"hcTC-ORG-MSD\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001000674</p><p><b>name</b>: MSD Merck Sharp &amp; Dohme AG</p><p><b>telecom</b>: ph: tel:+41 58 618 30 30(Work), <a href=\"mailto:mailto:msd.kundendienst@msd.com\">mailto:msd.kundendienst@msd.com</a>, <a href=\"https://www.msd.ch\">https://www.msd.ch</a></p><p><b>address</b>: Werftestrasse 4 Lucerne LU 6005 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001000674"
          }
        ],
        "name" : "MSD Merck Sharp & Dohme AG",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+41 58 618 30 30",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "mailto:msd.kundendienst@msd.com",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "https://www.msd.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Werftestrasse 4"],
            "city" : "Lucerne",
            "state" : "LU",
            "postalCode" : "6005",
            "country" : "CH"
          }
        ]
      }
    }
  ]
}

```
