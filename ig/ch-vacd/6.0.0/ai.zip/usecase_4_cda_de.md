# Usecase 4 Cda De - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* **Usecase 4 Cda De**

## Usecase 4 Cda De

# UC 4: Stationäre Impfstelle mit Papier KG

**Ausführlichere Bezeichnung**: Impfstelle Spital (Arzt arbeitet mit Papier-Krankengeschichte) Siehe Kapitel [UC 1](usecase_1_cda_de.md): Ambulante Impfstelle mit Papier KG.

