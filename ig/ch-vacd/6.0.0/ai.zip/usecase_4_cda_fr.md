# Usecase 4 Cda Fr - Implementation Guide CH VACD v6.0.0

* [**Table of Contents**](toc.md)
* **Usecase 4 Cda Fr**

## Usecase 4 Cda Fr

# UC 4: Centre de vaccination hospitalier avec DM sur papier

**Désignation détaillée**: centre de vaccination dans un hôpital (médecin travaillant avec un dossier médical sur papier) Cf. chapitre [UC 1](usecase_1_cda_fr.md): centre de vaccination ambulatoire avec DM sur papier.

