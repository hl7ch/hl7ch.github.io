# Example Encounter - CH EMS (R4) v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Encounter**

## Example Encounter: Example Encounter



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "EncounterExample",
  "extension" : [{
    "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
        "code" : "1000126",
        "display" : "wedding ring"
      }],
      "text" : "Ehering"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
        "code" : "1000131",
        "display" : "billfold"
      }],
      "text" : "Brieftasche"
    }
  },
  {
    "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-emergencydoctorsystem",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
        "code" : "1000005",
        "display" : "pickup by EMS"
      }],
      "text" : "Abholung durch Rettungsdienst"
    }
  },
  {
    "extension" : [{
      "url" : "offender",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000080",
          "display" : "person, unknown"
        }],
        "text" : "Drittperson unbekannt"
      }
    },
    {
      "url" : "form",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000043",
          "display" : "contumeliousness"
        }],
        "text" : "Beschimpfung"
      }
    },
    {
      "url" : "result",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260413007",
          "display" : "None (qualifier value)"
        }],
        "text" : "keine"
      }
    }],
    "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-violence"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
        "code" : "MN",
        "display" : "Mission number"
      }],
      "text" : "Einsatznummer"
    },
    "system" : "http://example.com",
    "value" : "S89898989"
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "EMER",
    "display" : "emergency"
  },
  "serviceType" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
      "code" : "1000001",
      "display" : "primary mission"
    }],
    "text" : "Primäreinsatz"
  },
  "priority" : {
    "extension" : [{
      "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-urgencyadequate",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000135",
          "display" : "no, siren not necessary"
        }],
        "text" : "nein, Sondersignal nicht notwendig"
      }
    }],
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
      "code" : "1000007",
      "display" : "with siren"
    }],
    "text" : "mit Sondersignal"
  },
  "subject" : {
    "reference" : "Patient/PatientExample"
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/1-AufbietendeOrganisation"
  }],
  "participant" : [{
    "extension" : [{
      "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "133932002",
          "display" : "Caregiver (person)"
        }],
        "text" : "Betreuer"
      }
    }],
    "individual" : {
      "reference" : "Practitioner/1-TeamMemberPetraMuster"
    }
  },
  {
    "extension" : [{
      "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "133932002",
          "display" : "Caregiver (person)"
        }],
        "text" : "Betreuer"
      }
    }],
    "individual" : {
      "reference" : "Practitioner/1-TeamMemberHansTransportsanitaeter"
    }
  },
  {
    "extension" : [{
      "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "309343006",
          "display" : "Physician (occupation)"
        }],
        "text" : "Ärztin / Arzt"
      }
    }],
    "individual" : {
      "reference" : "Practitioner/1-TeamMemberPierreUrgentiste"
    }
  }],
  "period" : {
    "start" : "2016-12-10"
  },
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
      "code" : "1000110",
      "display" : "emergency mission"
    }],
    "text" : "Notfall-Einsatz"
  }],
  "hospitalization" : {
    "destination" : {
      "reference" : "Location/1-Zielort"
    }
  },
  "location" : [{
    "location" : {
      "reference" : "Location/1-Einsatzort"
    }
  }]
}

```
