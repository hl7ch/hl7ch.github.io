# Example Patient - CH EMS (R4) v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Patient**

## Example Patient: Example Patient



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PatientExample",
  "extension" : [{
    "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-ech-11-placeoforigin",
    "valueAddress" : {
      "city" : "Musterdorf",
      "state" : "ZH"
    }
  },
  {
    "extension" : [{
      "url" : "source",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "116154003",
          "display" : "Patient (person)"
        }],
        "text" : "Patient"
      }
    },
    {
      "url" : "medium",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000053",
          "display" : "Identity card"
        }],
        "text" : "Identitätskarte"
      }
    }],
    "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-identification"
  }],
  "identifier" : [{
    "system" : "urn:oid:2.16.756.5.32",
    "value" : "7562295883070"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "MR"
      }]
    },
    "system" : "http://example.com",
    "value" : "111111111"
  }],
  "name" : [{
    "use" : "official",
    "family" : "Muster",
    "_family" : {
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-name",
        "valueCode" : "officialName"
      }]
    },
    "given" : ["Patricia"],
    "_given" : [{
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-firstname",
        "valueCode" : "officialFirstName"
      }]
    }]
  }],
  "gender" : "female",
  "birthDate" : "1999-11-11",
  "address" : [{
    "use" : "home",
    "line" : ["Bahnhofstrasse"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "1"
      }]
    }],
    "city" : "Zürich",
    "postalCode" : "8003",
    "country" : "Schweiz",
    "_country" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding",
        "valueCoding" : {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      }]
    }
  }]
}

```
