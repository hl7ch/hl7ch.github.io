# 2 Einsatzprotokoll - CH EMS (R4) v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **2 Einsatzprotokoll**

## Example Bundle: 2 Einsatzprotokoll



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "2-Einsatzprotokoll",
  "meta" : {
    "lastUpdated" : "2020-04-24T15:53:22.889+00:00"
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:662e3c16-0aac-11e8-ba89-0ed5f89f718b"
  },
  "type" : "document",
  "timestamp" : "2016-12-10T13:05:00.000+01:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/2-Einsatzprotokoll-Composition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "2-Einsatzprotokoll-Composition",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:662e3c16-0aac-11e8-ba89-0ed5f89f718b"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "67796-3",
          "display" : "EMS patient care report - version 3 Document NEMSIS"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "371535009",
          "display" : "Transfer summary report (record artifact)"
        }],
        "text" : "Einsatzprotokoll Rettungsdienst"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "date" : "2016-12-10T13:05:00.000+01:00",
      "author" : [{
        "reference" : "Practitioner/1-SaniPetraMuster"
      },
      {
        "reference" : "PractitionerRole/1-SaniPetraMuster-PR"
      }],
      "title" : "Einsatzprotokoll Rettungsdienst",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal"
            }],
            "text" : "Normal"
          }
        }]
      },
      "attester" : [{
        "mode" : "legal",
        "time" : "2016-12-10T13:13:05.000+01:00",
        "party" : {
          "reference" : "Practitioner/1-SaniPetraMuster"
        }
      }],
      "custodian" : {
        "reference" : "Organization/1-Rettungsdienst"
      },
      "section" : [{
        "title" : "Einsatz",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100001",
            "display" : "intervention"
          }],
          "text" : "Einsatz"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Einsatz</th></tr><tr><td>Einsatzdatum</td><td>10.12.2016</td></tr><tr><td>Einsatznummer</td><td>S12345678</td></tr><tr><td>aufbietende Organisation</td><td>7601002156370 (SNZ)</td></tr><tr><td>augebotene Organisation</td><td>7601002156363 (Rettungsdienst Schutz &amp; Rettung Zürich)</td></tr><tr><td>Team</td><td>Petra Muster, GLN 7601003330434, Betreuerin / Hans Transportsanitäter, GLN 7601000028105, Betreuer</td></tr><tr><td>Einsatzort</td><td>wird 8050 Zürich, Sternen Oerlikon, Schaffhauserstr. 350</td></tr><tr><td>Zielort</td><td>USZ Notfall</td></tr></tbody></table><table><tbody><tr><th>Alarm</th><th>Status DP</th><th>Status 1</th><th>Status 2</th><th>Kontakt Patient</th><th>Status 3</th><th>Status 4</th><th>Status 5</th><th>Status 6</th></tr><tr><th id=\"alarm\">12.09</th><th id=\"disposition\">12.11</th><th id=\"rollout\">12.13</th><th id=\"arrivalonscene\">12.17</th><th id=\"arrivalpatient\">12.18</th><th id=\"departurefromscene\">12.48</th><th id=\"arrivalattarget\">12.54</th><th id=\"departurefromtarget\">-</th><th id=\"operationalreadiness\">-</th></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "Encounter/2-Einsatz"
        },
        {
          "reference" : "Observation/2-Alarm"
        },
        {
          "reference" : "Observation/2-Disposition"
        },
        {
          "reference" : "Observation/2-Rollout"
        },
        {
          "reference" : "Observation/2-ArrivalOnScene"
        },
        {
          "reference" : "Observation/2-ArrivalPatient"
        },
        {
          "reference" : "Observation/2-DepartureFromScene"
        },
        {
          "reference" : "Observation/2-ArrivalAtTarget"
        }]
      },
      {
        "title" : "Administrativ",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100003",
            "display" : "administrative"
          }],
          "text" : "Administrativ"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Vorbehandlung",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100004",
            "display" : "pretreatment"
          }],
          "text" : "Vorbehandlung"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Anamnese",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100005",
            "display" : "anamnesis"
          }],
          "text" : "Anamnese"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Befund",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100006",
            "display" : "findings"
          }],
          "text" : "Befund"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Breathing:Der Patient hat eine unauffällige Spontanatmung</p><p>Cardiology: Sein Puls ist tastbar, es liegt kein Herz-Kreislaufstillstand vor; Frequenz 84/Minute, Blutdruck 170/90, gemessen am rechten Arm</p><p>Temperatur 37.2 °C, die Augen zeigen eine deutliche Anisokorie vor</p><table><tbody><tr><th>Airways</th><td id=\"airways\">Die Atemwege sind nicht verlegt</td></tr><tr><th>GCS</th><td id=\"gcs1\">Total 9 Augenöffnung bei Ansprache (3), gibt Einzelworte von sich (3), Dekortikationsstarre (3)</td></tr><tr><th>AVPU</th><td id=\"avpu\">V (=reagiert auf laute Ansprache)</td></tr></tbody></table></div>"
        },
        "section" : [{
          "title" : "Airway",
          "entry" : [{
            "reference" : "Observation/2-AirwaysBefund"
          }]
        },
        {
          "title" : "Disability",
          "entry" : [{
            "reference" : "Observation/2-GCSBefund"
          },
          {
            "reference" : "Observation/2-AVPUBefund"
          }]
        }]
      },
      {
        "title" : "Diagnosen",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100007",
            "display" : "diagnosis"
          }],
          "text" : "Diagnosen"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Verdachtsdiagnose</th></tr><tr><td id=\"diagnose1\">Stroke (I63)</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "Observation/2-Diagnose"
        }]
      },
      {
        "title" : "Massnahmen",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100008",
            "display" : "measures"
          }],
          "text" : "Massnahmen"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>Infusion mit 500 ml Ringer. Der Patient wird liegend in den Rettungswagen verladen.</span></div>"
        }
      },
      {
        "title" : "Todesfall",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100009",
            "display" : "death"
          }],
          "text" : "Todesfall"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Transport",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100010",
            "display" : "transport"
          }],
          "text" : "Transport"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>Fahrt mit Sondersignal ins USZ.</span></div>"
        }
      },
      {
        "title" : "Übergabe",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100011",
            "display" : "handover"
          }],
          "text" : "Übergabe"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Schmerz 4</p><table><tbody><tr><th>GCS</th></tr><tr><td id=\"gcs2\">Total 10 Augenöffnung bei Ansprache (3), Konversationsfähig aber desorientiert (4), Dekortikationsstarre (3)</td></tr><tr><th>NACA</th></tr><tr><td id=\"naca\">NACA: III</td></tr><tr><th>Zustand</th></tr><tr><td id=\"statusdischarge\">der Zustand des Patienten hat sich im Verlauf des Einsatzes verbessert</td></tr></tbody></table><p>Übergabe an USZ Effekten sowie Wertsachenverzeichnis</p></div>"
        },
        "entry" : [{
          "reference" : "Observation/2-ZustandUebergabe"
        },
        {
          "reference" : "Observation/2-NACAUebergabe"
        },
        {
          "reference" : "Observation/2-GCSUebergabe"
        },
        {
          "reference" : "Practitioner/1-InformationRecipientSpitalarzt"
        },
        {
          "reference" : "Organization/1-InformationRecipientUSZ"
        }]
      },
      {
        "title" : "Kommentar",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48767-8",
            "display" : "Annotation comment [Interpretation] Narrative"
          }],
          "text" : "Kommentar"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Encounter/2-Einsatz",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "2-Einsatz",
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "MN",
            "display" : "Mission number"
          }],
          "text" : "Einsatznummer"
        },
        "system" : "http://example.com",
        "value" : "S12345678"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "EMER",
        "display" : "emergency"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/2-AufbietendeOrganisation"
      }],
      "participant" : [{
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "133932002",
              "display" : "Caregiver (person)"
            }],
            "text" : "Betreuer"
          }
        }],
        "individual" : {
          "reference" : "Practitioner/1-TeamMemberPetraMuster"
        }
      },
      {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "133932002",
              "display" : "Caregiver (person)"
            }],
            "text" : "Betreuer"
          }
        }],
        "individual" : {
          "reference" : "Practitioner/1-TeamMemberHansTransportsanitaeter"
        }
      }],
      "period" : {
        "start" : "2016-12-10"
      },
      "hospitalization" : {
        "destination" : {
          "reference" : "Location/1-Zielort"
        }
      },
      "location" : [{
        "location" : {
          "reference" : "Location/2-Einsatzort"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/2-PatientUnbekannt",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "2-PatientUnbekannt",
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "http://example.com",
        "value" : "MU43221"
      }],
      "gender" : "male"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-InformationRecipientSpitalarzt",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-InformationRecipientSpitalarzt",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000404268"
      }],
      "name" : [{
        "family" : "Claude",
        "given" : ["Spitalarzt"]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-InformationRecipientUSZ",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-InformationRecipientUSZ",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002155939"
      }],
      "name" : "USZ",
      "address" : [{
        "line" : ["Rämistrasse 100"],
        "city" : "Zürich",
        "postalCode" : "8091",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-SaniPetraMuster",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-SaniPetraMuster",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601003330434"
      }],
      "name" : [{
        "family" : "Muster",
        "given" : ["Petra"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "397897005",
            "display" : "Paramedic (occupation)"
          }],
          "text" : "Rettungssanitäter/in HF"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/1-SaniPetraMuster-PR",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "1-SaniPetraMuster-PR",
      "practitioner" : {
        "reference" : "Practitioner/1-SaniPetraMuster"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "133932002",
          "display" : "Caregiver (person)"
        }],
        "text" : "Betreuer"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-TeamMemberPetraMuster",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-TeamMemberPetraMuster",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601003330434",
        "assigner" : {
          "reference" : "Organization/1-TeamRettungsdienst"
        }
      }],
      "name" : [{
        "family" : "Muster",
        "given" : ["Petra"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "397897005",
            "display" : "Paramedic (occupation)"
          }],
          "text" : "Rettungssanitäter/in HF"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-TeamMemberHansTransportsanitaeter",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-TeamMemberHansTransportsanitaeter",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000211804",
        "assigner" : {
          "reference" : "Organization/1-TeamRettungsdienst"
        }
      }],
      "name" : [{
        "family" : "Transportsanitäter",
        "given" : ["Hans"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "159738005",
            "display" : "Ambulanceman (occupation)"
          }],
          "text" : "Transportsanitäter/in FA"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-Rettungsdienst",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-Rettungsdienst",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002156363"
      }],
      "name" : "Rettungsdienst Schutz und Rettung Zürich"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-TeamRettungsdienst",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-TeamRettungsdienst",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002156363"
      }],
      "name" : "Rettungsdienst Schutz und Rettung Zürich",
      "address" : [{
        "line" : ["Bahnhofquai 3, Amtshaus I"],
        "city" : "Zürich",
        "postalCode" : "8001",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ServiceRequest/2-AufbietendeOrganisation",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "2-AufbietendeOrganisation",
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "2-requesting",
        "identifier" : [{
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601002156370"
        }],
        "name" : "SNZ"
      }],
      "status" : "completed",
      "intent" : "order",
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "requester" : {
        "reference" : "#2-requesting"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/2-Einsatzort",
    "resource" : {
      "resourceType" : "Location",
      "id" : "2-Einsatzort",
      "name" : "Sternen Oerlikon",
      "address" : {
        "line" : ["Schaffhauserstr. 350"],
        "city" : "Zürich",
        "postalCode" : "8050",
        "country" : "CH"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "74964007",
          "display" : "Other (qualifier value)"
        }],
        "text" : "andere / anderes"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/1-Zielort",
    "resource" : {
      "resourceType" : "Location",
      "id" : "1-Zielort",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002155939"
      }],
      "name" : "Universitätsspital Zürich, Notfall",
      "address" : {
        "line" : ["Rämistrasse 100"],
        "city" : "Zürich",
        "postalCode" : "8091",
        "country" : "Switzerland"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "22232009",
          "display" : "Hospital (environment)"
        }],
        "text" : "Spital"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-Alarm",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-Alarm",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000033",
          "display" : "alarm"
        }],
        "text" : "Alarmierungszeit"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:09:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-Disposition",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-Disposition",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000034",
          "display" : "disposition"
        }],
        "text" : "Dispositionszeit"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:11:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-Rollout",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-Rollout",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000035",
          "display" : "rollout"
        }],
        "text" : "Ausrückzeit"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:13:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-ArrivalOnScene",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-ArrivalOnScene",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000036",
          "display" : "arrival on scene"
        }],
        "text" : "Ankunftszeit am Einsatzort"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:17:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-ArrivalPatient",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-ArrivalPatient",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000037",
          "display" : "arrival patient"
        }],
        "text" : "Ankunftszeit beim Patienten"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:17:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-DepartureFromScene",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-DepartureFromScene",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000038",
          "display" : "departure from scene"
        }],
        "text" : "Abfahrtszeit vom Einsatzort"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:48:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-ArrivalAtTarget",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-ArrivalAtTarget",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000039",
          "display" : "arrival at target"
        }],
        "text" : "Ankunftszeit am Zielort"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:54:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-AirwaysBefund",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-AirwaysBefund",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "301252002",
          "display" : "Finding of respiratory obstruction (finding)"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "23875004",
          "display" : "No pathologic diagnosis (finding)"
        }],
        "text" : "Atemwege frei"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-GCSBefund",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-GCSBefund",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "valueQuantity" : {
        "value" : 9,
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 3
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000154",
            "display" : "bending"
          }],
          "text" : "auf Schmerz Beugesynergismen"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 3
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000159",
            "display" : "incoherent words"
          }],
          "text" : "unzusammenhängende Worte"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 3
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000151",
            "display" : "on request"
          }],
          "text" : "auf Aufforderung"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-AVPUBefund",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-AVPUBefund",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11454-6",
          "display" : "Responsiveness assessment at First encounter"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "V",
          "display" : "Reaktion nur bei lauter Ansprache"
        }],
        "text" : "Reaktion nur bei lauter Ansprache"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-Diagnose",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-Diagnose",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "2931005",
          "display" : "Probable diagnosis (contextual qualifier) (qualifier value)"
        }],
        "text" : "Verdachtsdiagnose"
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "performer" : [{
        "reference" : "Practitioner/1-SaniPetraMuster"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "code" : "I63",
          "display" : "Hirninfarkt"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-ZustandUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-ZustandUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75527-2",
          "display" : "Vital status at discharge"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "385425000",
          "display" : "Improved (qualifier value)"
        }],
        "text" : "verbessert"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-NACAUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-NACAUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "88076-5",
          "display" : "Injury severity score NACA"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "III",
          "display" : "mässige bis schwere Störung"
        }],
        "text" : "mässige bis schwere Störung"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/2-GCSUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2-GCSUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        }]
      },
      "subject" : {
        "reference" : "Patient/2-PatientUnbekannt"
      },
      "encounter" : {
        "reference" : "Encounter/2-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T13:03:00.000+01:00",
      "valueQuantity" : {
        "value" : 10,
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 3
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000154",
            "display" : "bending"
          }],
          "text" : "auf Schmerz Beugesynergismen"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 4
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000160",
            "display" : "conversational, disoriented"
          }],
          "text" : "konversationsfähig, desorientierts"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 3
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000151",
            "display" : "on request"
          }],
          "text" : "auf Aufforderung"
        }
      }]
    }
  }]
}

```
