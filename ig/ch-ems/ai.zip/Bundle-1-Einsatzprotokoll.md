# 1 Einsatzprotokoll - CH EMS (R4) v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1 Einsatzprotokoll**

## Example Bundle: 1 Einsatzprotokoll



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "1-Einsatzprotokoll",
  "meta" : {
    "lastUpdated" : "2020-04-24T07:53:22.889+00:00"
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:658ab5ea-1f63-11e6-b6ba-3e1d05defe78"
  },
  "type" : "document",
  "timestamp" : "2016-12-10T13:05:00.000+01:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/1-Einsatzprotokoll-Composition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "1-Einsatzprotokoll-Composition",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:658ab5ea-1f63-11e6-b6ba-3e1d05defe78"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "67796-3",
          "display" : "EMS patient care report - version 3 Document NEMSIS"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "371535009",
          "display" : "Transfer summary report (record artifact)"
        }],
        "text" : "Einsatzprotokoll Rettungsdienst"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "date" : "2016-12-10T13:05:00.000+01:00",
      "author" : [{
        "reference" : "PractitionerRole/1-SaniPetraMuster-PR"
      },
      {
        "reference" : "PractitionerRole/1-NotarztPierreUrgentiste-PR"
      }],
      "title" : "Einsatzprotokoll Rettungsdienst",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal"
            }],
            "text" : "Normal"
          }
        }]
      },
      "attester" : [{
        "mode" : "legal",
        "time" : "2016-12-10T13:13:05.000+01:00",
        "party" : {
          "reference" : "Practitioner/1-SaniPetraMuster"
        }
      }],
      "custodian" : {
        "reference" : "Organization/1-Rettungsdienst"
      },
      "section" : [{
        "title" : "Einsatz",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100001",
            "display" : "intervention"
          }],
          "text" : "Einsatz"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Einsatz</th></tr><tr><td>Einsatzdatum:</td><td>10.12.2016</td></tr><tr><td>Einsatznummer:</td><td>S12345678</td></tr><tr><td>Aufbietende Organisation:</td><td>SNZ (GLN 7601002156370)</td></tr><tr><td>Aufgebotene Organisation:</td><td>Rettungsdienst Schutz und Rettung Zürich (GLN 7601002156363)</td></tr><tr><td>Teammitglieder:</td><td>Petra Muster (Rettungssanitäterin), Hans Transportsanitäter (Transportsanitäter), Pierre Urgentiste (Notarzt)</td></tr><tr><td>Einsatzort:</td><td>Zürich, Waldrand (47.392115, 8.553192)</td></tr><tr><td>Zielort:</td><td>Universitätsspital Zürich, Notfall</td></tr></tbody></table><table><tbody><tr><th>Alarmierungszeit:</th><th>Dispositionszeit:</th><th>Ausrückzeit:</th><th>Ankunftszeit am Einsatzort:</th><th>Ankunftszeit beim Patienten:</th><th>Abfahrtszeit vom Einsatzort:</th><th>Ankunftszeit am Zielort:</th></tr><tr><th>12:09</th><th>12:11</th><th>12:13</th><th>12:17</th><th>12:22</th><th>12:48</th><th>12:54</th></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "Encounter/1-Einsatz"
        },
        {
          "reference" : "Observation/1-Alarm"
        },
        {
          "reference" : "Observation/1-Disposition"
        },
        {
          "reference" : "Observation/1-Rollout"
        },
        {
          "reference" : "Observation/1-ArrivalOnScene"
        },
        {
          "reference" : "Observation/1-ArrivalPatient"
        },
        {
          "reference" : "Observation/1-DepartureFromScene"
        },
        {
          "reference" : "Observation/1-ArrivalAtTarget"
        },
        {
          "reference" : "Procedure/1-Transport"
        },
        {
          "reference" : "Location/1-Rettungswagen"
        }]
      },
      {
        "title" : "Administrativ",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100003",
            "display" : "administrative"
          }],
          "text" : "Administrativ"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Beteiligte Person</th></tr><tr><td>Ehefrau:</td><td>Erika Müller</td></tr></tbody></table></div>"
        }
      },
      {
        "title" : "Vorbehandlung",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100004",
            "display" : "pretreatment"
          }],
          "text" : "Vorbehandlung"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Anamnese",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100005",
            "display" : "anamnesis"
          }],
          "text" : "Anamnese"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Ereignis:</th></tr><tr><td>Hat sich beim Spazieren im Wald schlecht gefühlt und ist abgesessen.</td></tr></tbody></table><table><tbody><tr><th>Symptome:</th></tr><tr><td>Starke Schmerzen in der Brust und im linken Oberarm verspürt.</td></tr></tbody></table><h4>Allergien / Unverträglichkeiten:</h4><ul><li>Allergisch auf Baumpollen</li><li>bekannte Unverträglichkeitsreaktion auf einzelne Medikamente</li></ul><h4>Bestehende Medikation</h4><ul><li>Aspirin Cardio 100 (1 Tbl./Tag)</li></ul><h4>Medizinische Vorgeschichte:</h4><ul><li>Herzvorfall vor vier Jahren, der im Triemlispital in Zürich behandelt wurde</li></ul><h4>Weiteres:</h4><ul><li>Seit dem Frühstück um ca. 8 Uhr hat er nichts mehr gegessen</li><li>Thomas Müller hat keine Patientenverfügung erstellt</li><li>Es sind keine anderen medizinischen Probleme bekannt</li></ul></div>"
        },
        "entry" : [{
          "reference" : "Observation/1-Anamnese"
        },
        {
          "reference" : "Observation/1-Symptome"
        },
        {
          "reference" : "AllergyIntolerance/1-Baumpollen"
        },
        {
          "reference" : "AllergyIntolerance/1-Medikamente"
        },
        {
          "reference" : "MedicationStatement/1-AspirinCardio"
        }]
      },
      {
        "title" : "Befund",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100006",
            "display" : "findings"
          }],
          "text" : "Befund"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Zeitpunkt des Befundes: 12:25</p><table><tbody><tr><th>Blutdruck:</th><th>GCS:</th><th>Weiteres:</th></tr><tr><td>120/80 mmHg, gemessen am rechten Arm</td><td>Total 15: Augenöffnung spontan (4), verbale Antwort orientiert (5), motorische Reaktion befolgt Antweisungen (6)</td><td>Schmerz: 5</td></tr></tbody></table></div>"
        },
        "section" : [{
          "title" : "Circulation",
          "entry" : [{
            "reference" : "Observation/1-Blutdruck"
          }]
        },
        {
          "title" : "Disability",
          "entry" : [{
            "reference" : "Observation/1-GCSBefund"
          }]
        }]
      },
      {
        "title" : "Diagnosen",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100007",
            "display" : "diagnosis"
          }],
          "text" : "Diagnosen"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>Verdachtsdiagnose:</th></tr><tr><td>Akuter transmuraler Myokardinfarkt der Vorderwand (ACS/STEMI VW)</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "Observation/1-Diagnose"
        }]
      },
      {
        "title" : "Massnahmen",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100008",
            "display" : "measures"
          }],
          "text" : "Massnahmen"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>Sofortige Infusion gelegt und Verabreichung einer ersten Dosis von 2 Hüben Nitrolingual-Spray um 12:30.</span></div>"
        },
        "entry" : [{
          "reference" : "MedicationAdministration/1-Infusion"
        },
        {
          "reference" : "MedicationAdministration/1-Spray"
        }]
      },
      {
        "title" : "Todesfall",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100009",
            "display" : "death"
          }],
          "text" : "Todesfall"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      },
      {
        "title" : "Transport",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100010",
            "display" : "transport"
          }],
          "text" : "Transport"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>Fahrt mit Sondersignal ins USZ.</span></div>"
        }
      },
      {
        "title" : "Übergabe",
        "code" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1100011",
            "display" : "handover"
          }],
          "text" : "Übergabe"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><th>GCS:</th><th>NACA:</th><th>Zustand:</th><th>Weiteres:</th></tr><tr><td>Total 15: Augenöffnung spontan (4), verbale Antwort orientiert (5), motorische Reaktion befolgt Antweisungen (6)</td><td>III</td><td>Zustand des Patienten hat sich im Verlaufe des Einsatzes verbessert</td><td>Schmerz: 4</td></tr></tbody></table><p>Übergabe an USZ mit Wertsachenbeutel mit Portemonnaie, Handy, Uhr, Schlüssel, Bargeld sowie Wertsachenverzeichnis.</p></div>"
        },
        "entry" : [{
          "reference" : "Observation/1-ZustandUebergabe"
        },
        {
          "reference" : "Observation/1-NACAUebergabe"
        },
        {
          "reference" : "Observation/1-GCSUebergabe"
        },
        {
          "reference" : "Practitioner/1-InformationRecipientSpitalarzt"
        },
        {
          "reference" : "Organization/1-InformationRecipientUSZ"
        }]
      },
      {
        "title" : "Kommentar",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48767-8",
            "display" : "Annotation comment [Interpretation] Narrative"
          }],
          "text" : "Kommentar"
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><span>-</span></div>"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Encounter/1-Einsatz",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "1-Einsatz",
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000127",
            "display" : "wallet"
          }]
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "74964007",
            "display" : "Other"
          }],
          "text" : "Handy"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000128",
            "display" : "wrist watch"
          }]
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "74964007",
            "display" : "Other"
          }],
          "text" : "Schlüssel"
        }
      },
      {
        "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-valuablespatient",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "74964007",
            "display" : "Other"
          }],
          "text" : "Bargeld"
        }
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "MN",
            "display" : "Mission number"
          }],
          "text" : "Einsatznummer"
        },
        "system" : "http://example.com",
        "value" : "S12345678"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "EMER",
        "display" : "emergency"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/1-AufbietendeOrganisation"
      }],
      "participant" : [{
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "133932002",
              "display" : "Caregiver (person)"
            }],
            "text" : "Betreuer"
          }
        }],
        "individual" : {
          "reference" : "Practitioner/1-TeamMemberPetraMuster"
        }
      },
      {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "133932002",
              "display" : "Caregiver (person)"
            }],
            "text" : "Betreuer"
          }
        }],
        "individual" : {
          "reference" : "Practitioner/1-TeamMemberHansTransportsanitaeter"
        }
      },
      {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-teamrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "309343006",
              "display" : "Physician (occupation)"
            }],
            "text" : "Ärztin / Arzt"
          }
        }],
        "individual" : {
          "reference" : "Practitioner/1-TeamMemberPierreUrgentiste"
        }
      }],
      "period" : {
        "start" : "2016-12-10"
      },
      "hospitalization" : {
        "destination" : {
          "reference" : "Location/1-Zielort"
        }
      },
      "location" : [{
        "location" : {
          "reference" : "Location/1-Einsatzort"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/1-ThomasMueller",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "1-ThomasMueller",
      "extension" : [{
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-ech-11-placeoforigin",
        "valueAddress" : {
          "city" : "Musterdorf",
          "state" : "ZH"
        }
      }],
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7562295883070"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "http://example.com",
        "value" : "762354"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Müller",
        "_family" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-name",
            "valueCode" : "officialName"
          }]
        },
        "given" : ["Thomas"],
        "_given" : [{
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-firstname",
            "valueCode" : "officialFirstName"
          }]
        }]
      }],
      "gender" : "male",
      "birthDate" : "1961-10-01",
      "address" : [{
        "use" : "home",
        "line" : ["Bahnhofstrasse"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "1"
          }]
        }],
        "city" : "Zürich",
        "postalCode" : "8003",
        "country" : "Schweiz",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }],
      "contact" : [{
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-ems/StructureDefinition/ch-ems-ext-personrole",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "74964007",
              "display" : "Other (qualifier value)"
            }],
            "text" : "Ehefrau"
          }
        }],
        "relationship" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
            "code" : "thirdParty"
          }]
        }],
        "name" : {
          "family" : "Müller",
          "given" : ["Erika"]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Coverage/1-CoverageThomasMueller",
    "resource" : {
      "resourceType" : "Coverage",
      "id" : "1-CoverageThomasMueller",
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "kpt",
        "name" : "KPT"
      }],
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.30.1.123.100.1.1.1",
        "value" : "80756003760012390001"
      }],
      "status" : "active",
      "beneficiary" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "payor" : [{
        "reference" : "#kpt"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-InformationRecipientSpitalarzt",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-InformationRecipientSpitalarzt",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000404268"
      }],
      "name" : [{
        "family" : "Claude",
        "given" : ["Spitalarzt"]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-InformationRecipientUSZ",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-InformationRecipientUSZ",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002155939"
      }],
      "name" : "USZ",
      "address" : [{
        "line" : ["Rämistrasse 100"],
        "city" : "Zürich",
        "postalCode" : "8091",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-SaniPetraMuster",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-SaniPetraMuster",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601003330434"
      }],
      "name" : [{
        "family" : "Muster",
        "given" : ["Petra"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "397897005",
            "display" : "Paramedic (occupation)"
          }],
          "text" : "Rettungssanitäter/in HF"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/1-SaniPetraMuster-PR",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "1-SaniPetraMuster-PR",
      "practitioner" : {
        "reference" : "Practitioner/1-SaniPetraMuster"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "133932002",
          "display" : "Caregiver (person)"
        }],
        "text" : "Betreuer"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-NotarztPierreUrgentiste",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-NotarztPierreUrgentiste",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000028105"
      }],
      "name" : [{
        "family" : "Urgentiste",
        "given" : ["Pierre"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "309294001",
            "display" : "Emergency department physician (occupation)"
          }],
          "text" : "Notarzt/Notärztin SGNOR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/1-NotarztPierreUrgentiste-PR",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "1-NotarztPierreUrgentiste-PR",
      "practitioner" : {
        "reference" : "Practitioner/1-NotarztPierreUrgentiste"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "309343006",
          "display" : "Physician (occupation)"
        }],
        "text" : "Ärztin / Arzt"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-TeamMemberPetraMuster",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-TeamMemberPetraMuster",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601003330434",
        "assigner" : {
          "reference" : "Organization/1-TeamRettungsdienst"
        }
      }],
      "name" : [{
        "family" : "Muster",
        "given" : ["Petra"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "397897005",
            "display" : "Paramedic (occupation)"
          }],
          "text" : "Rettungssanitäter/in HF"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-TeamMemberHansTransportsanitaeter",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-TeamMemberHansTransportsanitaeter",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000211804",
        "assigner" : {
          "reference" : "Organization/1-TeamRettungsdienst"
        }
      }],
      "name" : [{
        "family" : "Transportsanitäter",
        "given" : ["Hans"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "159738005",
            "display" : "Ambulanceman (occupation)"
          }],
          "text" : "Transportsanitäter/in FA"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/1-TeamMemberPierreUrgentiste",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1-TeamMemberPierreUrgentiste",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000028105",
        "assigner" : {
          "reference" : "Organization/1-TeamRettungsdienst"
        }
      }],
      "name" : [{
        "family" : "Urgentiste",
        "given" : ["Pierre"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "309294001",
            "display" : "Emergency department physician (occupation)"
          }],
          "text" : "Notarzt/Notärztin SGNOR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-Rettungsdienst",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-Rettungsdienst",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002156363"
      }],
      "name" : "Rettungsdienst Schutz und Rettung Zürich"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1-TeamRettungsdienst",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1-TeamRettungsdienst",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002156363"
      }],
      "name" : "Rettungsdienst Schutz und Rettung Zürich",
      "address" : [{
        "line" : ["Bahnhofquai 3, Amtshaus I"],
        "city" : "Zürich",
        "postalCode" : "8001",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ServiceRequest/1-AufbietendeOrganisation",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "1-AufbietendeOrganisation",
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "1-requesting",
        "identifier" : [{
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601002156370"
        }],
        "name" : "SNZ"
      }],
      "status" : "completed",
      "intent" : "order",
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "requester" : {
        "reference" : "#1-requesting"
      },
      "insurance" : [{
        "reference" : "Coverage/1-CoverageThomasMueller"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/1-Einsatzort",
    "resource" : {
      "resourceType" : "Location",
      "id" : "1-Einsatzort",
      "name" : "Waldrand",
      "address" : {
        "city" : "Zürich",
        "postalCode" : "8044",
        "country" : "CH"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "257710009",
          "display" : "Street (environment)"
        }],
        "text" : "Strasse / öffentlicher Raum"
      },
      "position" : {
        "longitude" : 8.553192,
        "latitude" : 47.392115
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/1-Zielort",
    "resource" : {
      "resourceType" : "Location",
      "id" : "1-Zielort",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002155939"
      }],
      "name" : "Universitätsspital Zürich, Notfall",
      "address" : {
        "line" : ["Rämistrasse 100"],
        "city" : "Zürich",
        "postalCode" : "8091",
        "country" : "Switzerland"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "22232009",
          "display" : "Hospital (environment)"
        }],
        "text" : "Spital"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Alarm",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Alarm",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000033",
          "display" : "alarm"
        }],
        "text" : "Alarmierungszeit"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:09:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Disposition",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Disposition",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000034",
          "display" : "disposition"
        }],
        "text" : "Dispositionszeit"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:11:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Rollout",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Rollout",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000035",
          "display" : "rollout"
        }],
        "text" : "Ausrückzeit"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:13:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-ArrivalOnScene",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-ArrivalOnScene",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000036",
          "display" : "arrival on scene"
        }],
        "text" : "Ankunftszeit am Einsatzort"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:17:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-ArrivalPatient",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-ArrivalPatient",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000037",
          "display" : "arrival patient"
        }],
        "text" : "Ankunftszeit beim Patienten"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:22:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-DepartureFromScene",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-DepartureFromScene",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000038",
          "display" : "departure from scene"
        }],
        "text" : "Abfahrtszeit vom Einsatzort"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:48:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-ArrivalAtTarget",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-ArrivalAtTarget",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000039",
          "display" : "arrival at target"
        }],
        "text" : "Ankunftszeit am Zielort"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueDateTime" : "2016-12-10T12:54:00.000+01:00"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Anamnese",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Anamnese",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "272379006",
          "display" : "Event (event)"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "261665006",
          "display" : "Unknown"
        }],
        "text" : "Hat sich beim Spazieren im Wald schlecht gefühlt und ist abgesessen."
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Symptome",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Symptome",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "404684003",
          "display" : "Clinical finding (finding)"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueCodeableConcept" : {
        "text" : "Starke Schmerzen in der Brust und im linken Oberarm verspürt."
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-GCSBefund",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-GCSBefund",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "valueQuantity" : {
        "value" : 15,
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 6
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000157",
            "display" : "take orders"
          }],
          "text" : "befolgt Aufforderungen"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 5
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000161",
            "display" : "conversational, oriented"
          }],
          "text" : "konversationsfähig, orientiert"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 4
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000152",
            "display" : "spontaneous"
          }],
          "text" : "spontan"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Diagnose",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Diagnose",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "2931005",
          "display" : "Probable diagnosis (contextual qualifier) (qualifier value)"
        }],
        "text" : "Verdachtsdiagnose"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "performer" : [{
        "reference" : "Practitioner/1-NotarztPierreUrgentiste"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "code" : "I21.0",
          "display" : "ST elevation (STEMI) myocardial infarction of anterior wall"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-ZustandUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-ZustandUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75527-2",
          "display" : "Vital status at discharge"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "385425000",
          "display" : "Improved (qualifier value)"
        }],
        "text" : "verbessert"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-NACAUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-NACAUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "88076-5",
          "display" : "Injury severity score NACA"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "III",
          "display" : "mässige bis schwere Störung"
        }],
        "text" : "mässige bis schwere Störung"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-GCSUebergabe",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-GCSUebergabe",
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T13:03:00.000+01:00",
      "valueQuantity" : {
        "value" : 15,
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 6
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000157",
            "display" : "take orders"
          }],
          "text" : "befolgt Aufforderungen"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 5
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000161",
            "display" : "conversational, oriented"
          }],
          "text" : "konversationsfähig, orientiert"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
              "valueDecimal" : 4
            }],
            "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
            "code" : "1000152",
            "display" : "spontaneous"
          }],
          "text" : "spontan"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Location/1-Rettungswagen",
    "resource" : {
      "resourceType" : "Location",
      "id" : "1-Rettungswagen",
      "name" : "Rettungswagen (Z-220)",
      "physicalType" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "83887000",
          "display" : "Rescue vehicle"
        }],
        "text" : "Rettungswagen"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/1-Blutdruck",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1-Blutdruck",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85354-9",
          "display" : "Blood pressure panel with all children optional"
        }]
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:25:00.000+01:00",
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "368209003",
          "display" : "Right upper arm structure (body structure)"
        }],
        "text" : "rechter Arm"
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "22762002",
          "display" : "Non-invasive (qualifier value)"
        }],
        "text" : "nicht invasiv"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8480-6",
            "display" : "Systolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 120,
          "unit" : "millimeter of mercury",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8462-4",
            "display" : "Diastolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 80,
          "unit" : "millimeter of mercury",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/MedicationAdministration/1-Infusion",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "1-Infusion",
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "1-Fentanyl",
        "code" : {
          "coding" : [{
            "system" : "urn:oid:2.51.1.1",
            "code" : "7680539870027",
            "display" : "FENTANYL Sintetica Inj Lös 0.5 mg/10ml"
          }],
          "text" : "FENTANYL Sintetica Inj Lös 0.5 mg/10ml"
        },
        "form" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "11201000",
            "display" : "Solution for injection"
          }],
          "text" : "Injektionslösung"
        },
        "amount" : {
          "numerator" : {
            "value" : 10,
            "unit" : "Ampule (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "732978007"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Package - unit of product usage (qualifier value)",
            "system" : "http://snomed.info/sct",
            "code" : "1681000175101"
          }
        },
        "ingredient" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "373492002",
              "display" : "Fentanyl (substance)"
            }],
            "text" : "Fentanyl"
          },
          "strength" : {
            "numerator" : {
              "value" : 0.5,
              "unit" : "milligram",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 10,
              "unit" : "milligram",
              "system" : "http://unitsofmeasure.org",
              "code" : "mL"
            }
          }
        }]
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "#1-Fentanyl"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "context" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:30:00.000+01:00",
      "reasonCode" : [{
        "text" : "Verdacht auf Myokardinfarkt"
      }],
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "20045000",
            "display" : "Intravenous use"
          }],
          "text" : "intravenöse Anwendung"
        },
        "method" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "0009",
            "display" : "Infusion"
          }]
        },
        "dose" : {
          "value" : 1,
          "unit" : "Ampule (unit of presentation)",
          "system" : "http://snomed.info/sct",
          "code" : "732978007"
        }
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/MedicationAdministration/1-Spray",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "1-Spray",
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "1-Nitrolingual",
        "code" : {
          "coding" : [{
            "system" : "urn:oid:2.51.1.1",
            "code" : "7680405580012",
            "display" : "NITROLINGUAL Pumpspray"
          }],
          "text" : "NITROLINGUAL Pumpspray"
        },
        "form" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "10309200",
            "display" : "Sublingual spray, solution"
          }],
          "text" : "Sublingualspray, Lösung"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Inhaler (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "732997007"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Package - unit of product usage (qualifier value)",
            "system" : "http://snomed.info/sct",
            "code" : "1681000175101"
          }
        },
        "ingredient" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "387404004",
              "display" : "Glyceryl trinitrate (substance)"
            }],
            "text" : "Nitroglycerin"
          },
          "strength" : {
            "numerator" : {
              "value" : 0.4,
              "unit" : "milligram",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Actuation (unit of presentation)",
              "system" : "http://snomed.info/sct",
              "code" : "732981002"
            }
          }
        }]
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "#1-Nitrolingual"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "context" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectiveDateTime" : "2016-12-10T12:30:00.000+01:00",
      "reasonCode" : [{
        "text" : "Verdacht auf Myokardinfarkt"
      }],
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "20067000",
            "display" : "Sublingual use"
          }],
          "text" : "Sublingual"
        },
        "method" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "0017",
            "display" : "Spraying"
          }]
        },
        "dose" : {
          "value" : 2,
          "unit" : "Actuation (unit of presentation)",
          "system" : "http://snomed.info/sct",
          "code" : "732981002"
        }
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/AllergyIntolerance/1-Baumpollen",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "1-Baumpollen",
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "type" : "allergy",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "419263009",
          "display" : "Allergy to tree pollen (finding)"
        }],
        "text" : "Allergie gegen Baumpollen"
      },
      "patient" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/AllergyIntolerance/1-Medikamente",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "1-Medikamente",
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "type" : "intolerance",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "410942007",
          "display" : "Drug or medicament (substance)"
        }],
        "text" : "Arzneimittel oder Medikament"
      },
      "patient" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/MedicationStatement/1-AspirinCardio",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "1-AspirinCardio",
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "1-Aspirin",
        "code" : {
          "text" : "Aspirin Cardio 100"
        }
      }],
      "status" : "active",
      "medicationReference" : {
        "reference" : "#1-Aspirin"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "context" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "effectivePeriod" : {
        "start" : "2012-05"
      },
      "reasonCode" : [{
        "text" : "Herzvorfall vor 4 Jahren"
      }],
      "dosage" : [{
        "timing" : {
          "repeat" : {
            "when" : ["MORN"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Tablet (unit of presentation)",
            "system" : "http://snomed.info/sct",
            "code" : "732936001"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Procedure/1-Transport",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "1-Transport",
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "229824005",
          "display" : "Positioning patient (procedure)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.ch/ig/ch-ems/CodeSystem/IVR",
          "code" : "1000103",
          "display" : "laying"
        }],
        "text" : "liegend"
      },
      "subject" : {
        "reference" : "Patient/1-ThomasMueller"
      },
      "encounter" : {
        "reference" : "Encounter/1-Einsatz"
      },
      "usedCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "156009",
          "display" : "Spine board, device (physical object)"
        }],
        "text" : "Rettungsbrett"
      }]
    }
  }]
}

```
