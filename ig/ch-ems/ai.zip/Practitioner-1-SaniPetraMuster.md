# 1 Rettungssanitaeterin - CH EMS (R4) v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1 Rettungssanitaeterin**

## Example Practitioner: 1 Rettungssanitaeterin



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "1-SaniPetraMuster",
  "identifier" : [{
    "system" : "urn:oid:2.51.1.3",
    "value" : "7601003330434"
  }],
  "name" : [{
    "family" : "Muster",
    "given" : ["Petra"]
  }],
  "qualification" : [{
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "397897005",
        "display" : "Paramedic (occupation)"
      }],
      "text" : "Rettungssanitäter/in HF"
    }
  }]
}

```
