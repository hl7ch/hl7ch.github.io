# Bundle: PRE Paracetamol Axapharm 1g - CH EMED EPR v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: PRE Paracetamol Axapharm 1g**

## Example Bundle: Bundle: PRE Paracetamol Axapharm 1g



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DocumentPreParacetamolAxapharmCARAPMP004",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-document-medicationprescription"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:e0c06f3c-1b63-468a-9c46-e800d39b6a15"
  },
  "type" : "document",
  "timestamp" : "2023-10-01T00:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:e0c06f3c-1b63-468a-9c46-e800d39b6a15",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "CompositionPreParacetamolAxapharmCARAPMP004",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-composition-medicationprescription"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Composition_CompositionPreParacetamolAxapharmCARAPMP004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition CompositionPreParacetamolAxapharmCARAPMP004</b></p><a name=\"CompositionPreParacetamolAxapharmCARAPMP004\"> </a><a name=\"hcCompositionPreParacetamolAxapharmCARAPMP004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-composition-medicationprescription.html\">PRE Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:e0c06f3c-1b63-468a-9c46-e800d39b6a15</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 761938008}, {http://loinc.org 57833-6}\">Medicinal prescription record (record artifact)</span></p><p><b>date</b>: 2023-10-01 00:00:00+0200</p><p><b>author</b>: <a href=\"Bundle-BundleUtc6bPml.html#urn-uuid-213d609a-1164-459a-bb10-727516ae3d0c\">PractitionerRole</a></p><p><b>title</b>: Ordonnance</p><p><b>confidentiality</b>: normal</p></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:e0c06f3c-1b63-468a-9c46-e800d39b6a15"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "761938008",
              "display" : "Medicinal prescription record (record artifact)"
            },
            {
              "system" : "http://loinc.org",
              "code" : "57833-6",
              "display" : "Prescription for medication"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "date" : "2023-10-01T00:00:00+02:00",
        "author" : [
          {
            "reference" : "urn:uuid:213d609a-1164-459a-bb10-727516ae3d0c"
          }
        ],
        "title" : "Ordonnance",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "section" : [
          {
            "title" : "Prescription médicamenteuse",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "57828-6",
                  "display" : "Prescription list"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">L'ordonnance #1 pour paracétamol Axapharm comprimé 1g - 1 comprimé MATIN MIDI SOIR - à prendre avec des repas</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:ac8ad5cd-aa46-49d6-a5ec-fbc48a9287b4"
              }
            ]
          },
          {
            "title" : "Représentation originale",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "55108-5",
                  "display" : "Clinical presentation Document"
                }
              ]
            },
            "text" : {
              "extension" : [
                {
                  "extension" : [
                    {
                      "url" : "htmlid",
                      "valueString" : "uuid-a4f624e3-fa5a-4889-9bd1-821c8fefff60"
                    },
                    {
                      "url" : "data",
                      "valueUri" : "urn:uuid:a4f624e3-fa5a-4889-9bd1-821c8fefff60"
                    }
                  ],
                  "url" : "http://hl7.org/fhir/StructureDefinition/textLink"
                }
              ],
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Placeholder original representation of a prescription: <span id=\"uuid-a4f624e3-fa5a-4889-9bd1-821c8fefff60\">not a valid binary</span></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:a4f624e3-fa5a-4889-9bd1-821c8fefff60"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "PatientCARAPMP004",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientCARAPMP004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient PatientCARAPMP004</b></p><a name=\"PatientCARAPMP004\"> </a><a name=\"hcPatientCARAPMP004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-patient.html\">CH EMED EPR Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus 9}\">unbekannt</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Medical record number/100001368 (use: secondary, )</li><li>Medical record number/CARAPMP004 (use: secondary, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.1625.3.1.3.1",
            "value" : "7857bf60-93a1-409d-a647-ee260cec9c0e"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.177.2.2.1.1",
            "value" : "100001368"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "CARAPMP004"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Karce",
            "given" : ["Michaël Christopher"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1973-12-25",
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus",
              "code" : "9",
              "display" : "unbekannt"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:9fc8530b-b77d-4b53-8a21-fc786b697edf",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "PractitionerCox",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_PractitionerCox\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner PractitionerCox</b></p><a name=\"PractitionerCox\"> </a><a name=\"hcPractitionerCox\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-practitioner.html\">CH EMED EPR Practitioner</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000234438</p><p><b>name</b>: Perry Cox </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601000234438"
          }
        ],
        "name" : [
          {
            "family" : "Cox",
            "given" : ["Perry"]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:213d609a-1164-459a-bb10-727516ae3d0c",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "PractitionerRoleCoxAtHug",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_PractitionerRoleCoxAtHug\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole PractitionerRoleCoxAtHug</b></p><a name=\"PractitionerRoleCoxAtHug\"> </a><a name=\"hcPractitionerRoleCoxAtHug\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-practitionerrole.html\">CH EMED EPR PractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-BundleUtc6bPml.html#urn-uuid-9fc8530b-b77d-4b53-8a21-fc786b697edf\">Practitioner Perry Cox </a></p><p><b>organization</b>: <a href=\"Bundle-BundleUtc6bPml.html#urn-uuid-580fbe82-8734-4edf-ad4b-48124cdd03c6\">Organization Hôpitaux universitaires de Genève</a></p></div>"
        },
        "practitioner" : {
          "reference" : "urn:uuid:9fc8530b-b77d-4b53-8a21-fc786b697edf"
        },
        "organization" : {
          "reference" : "urn:uuid:580fbe82-8734-4edf-ad4b-48124cdd03c6"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:580fbe82-8734-4edf-ad4b-48124cdd03c6",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "OrganizationHug",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationHug\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization OrganizationHug</b></p><a name=\"OrganizationHug\"> </a><a name=\"hcOrganizationHug\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000234438</p><p><b>name</b>: Hôpitaux universitaires de Genève</p><p><b>address</b>: Rue Gabrielle-Perret-Gentil 4 Genève 1205 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601000234438"
          }
        ],
        "name" : "Hôpitaux universitaires de Genève",
        "address" : [
          {
            "line" : ["Rue Gabrielle-Perret-Gentil 4"],
            "city" : "Genève",
            "postalCode" : "1205",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:ac8ad5cd-aa46-49d6-a5ec-fbc48a9287b4",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "MedicationRequestParacetamolAxapharmPre",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medicationrequest"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"MedicationRequest_MedicationRequestParacetamolAxapharmPre\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest MedicationRequestParacetamolAxapharmPre</b></p><a name=\"MedicationRequestParacetamolAxapharmPre\"> </a><a name=\"hcMedicationRequestParacetamolAxapharmPre\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medicationrequest.html\">PRE MedicationRequest</a></p></div><blockquote><p><b>CH EMED Extension Treatment Plan</b></p><ul><li>id: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:17837392-0340-414d-a3bf-fa9f237b91ff</li><li>externalDocumentId: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:0399ef84-c71b-413b-8a66-b5a835f4f4c5</li></ul></blockquote><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:ac8ad5cd-aa46-49d6-a5ec-fbc48a9287b4</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>medication</b>: <a href=\"#hcMedicationRequestParacetamolAxapharmPre/MedicationParacetamolAxapharm\">Medication PARACETAMOL Axapharm cpr pell 1g blister 20pce</a></p><p><b>subject</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-9b00e81e-1165-4039-9d60-698ef838ae1a\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</a></p><p><b>authoredOn</b>: 2023-10-01 00:00:00+0200</p><p><b>requester</b>: <a href=\"Bundle-BundleUtc6bPml.html#urn-uuid-213d609a-1164-459a-bb10-727516ae3d0c\">PractitionerRole</a></p><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: Un comprimé à avaler et prendre pendant les repas avec de l'eau le matin, le midi et le soir du 2023-10-01 au 2024-01-05.</p><p><b>additionalInstruction</b>: <span title=\"Codes:{http://snomed.info/sct 311504000}\">À prendre pendant les repas</span></p><p><b>patientInstruction</b>: À prendre pendant les repas avec de l'eau</p><p><b>timing</b>: Morning, Noon, Evening, Once</p><p><b>route</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 20053000}\">À avaler</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #MedicationParacetamolAxapharm</b></p><a name=\"MedicationRequestParacetamolAxapharmPre/MedicationParacetamolAxapharm\"> </a><a name=\"hcMedicationRequestParacetamolAxapharmPre/MedicationParacetamolAxapharm\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medication.html\">CH EMED EPR Medication</a></p></div><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680669830045}, {http://www.whocc.no/atc N02BE01}\">PARACETAMOL Axapharm cpr pell 1g</span></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 10221000}\">Comprimé pelliculé</span></p><p><b>amount</b>: 20 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span>/1 plaquette<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732984005 = 'Blister (unit of presentation)')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>IsActive</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 387517004}\">Paracétamol</span></td><td>true</td><td>1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Medication",
            "id" : "MedicationParacetamolAxapharm",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medication"
              ]
            },
            "language" : "fr-CH",
            "code" : {
              "coding" : [
                {
                  "system" : "urn:oid:2.51.1.1",
                  "code" : "7680669830045",
                  "display" : "PARACETAMOL Axapharm cpr pell 1g blister 20pce"
                },
                {
                  "system" : "http://www.whocc.no/atc",
                  "code" : "N02BE01",
                  "display" : "paracetamol"
                }
              ],
              "text" : "PARACETAMOL Axapharm cpr pell 1g"
            },
            "form" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "10221000",
                  "display" : "Comprimé pelliculé"
                }
              ],
              "text" : "Comprimé pelliculé"
            },
            "amount" : {
              "numerator" : {
                "value" : 20,
                "unit" : "comprimé",
                "system" : "http://snomed.info/sct",
                "code" : "732936001"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "plaquette",
                "system" : "http://snomed.info/sct",
                "code" : "732984005"
              }
            },
            "ingredient" : [
              {
                "itemCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://snomed.info/sct",
                      "code" : "387517004",
                      "display" : "Paracetamol (substance)"
                    }
                  ],
                  "text" : "Paracétamol"
                },
                "isActive" : true,
                "strength" : {
                  "numerator" : {
                    "value" : 1,
                    "unit" : "g",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "g"
                  },
                  "denominator" : {
                    "value" : 1,
                    "unit" : "comprimé",
                    "system" : "http://snomed.info/sct",
                    "code" : "732936001"
                  }
                }
              }
            ]
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "id",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:17837392-0340-414d-a3bf-fa9f237b91ff"
                }
              },
              {
                "url" : "externalDocumentId",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:0399ef84-c71b-413b-8a66-b5a835f4f4c5"
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-treatmentplan"
          }
        ],
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:uuid:ac8ad5cd-aa46-49d6-a5ec-fbc48a9287b4"
          }
        ],
        "status" : "active",
        "intent" : "order",
        "medicationReference" : {
          "reference" : "#MedicationParacetamolAxapharm"
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "authoredOn" : "2023-10-01T00:00:00+02:00",
        "requester" : {
          "reference" : "urn:uuid:213d609a-1164-459a-bb10-727516ae3d0c"
        },
        "dosageInstruction" : [
          {
            "text" : "Un comprimé à avaler et prendre pendant les repas avec de l'eau le matin, le midi et le soir du 2023-10-01 au 2024-01-05.",
            "additionalInstruction" : [
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "311504000",
                    "display" : "With or after food"
                  }
                ],
                "text" : "À prendre pendant les repas"
              }
            ],
            "patientInstruction" : "À prendre pendant les repas avec de l'eau",
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2023-10-01",
                  "end" : "2024-01-05"
                },
                "when" : ["MORN", "NOON", "EVE"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "20053000",
                  "display" : "Oral use"
                }
              ],
              "text" : "À avaler"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "comprimé",
                  "system" : "http://snomed.info/sct",
                  "code" : "732936001"
                }
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:a4f624e3-fa5a-4889-9bd1-821c8fefff60",
      "resource" : {
        "resourceType" : "Binary",
        "id" : "original-representation-pdf",
        "contentType" : "application/pdf"
      }
    }
  ]
}

```
