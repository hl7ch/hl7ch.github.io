# Bundle: PMLC document with Dafalgan self-medication - CH EMED EPR v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: PMLC document with Dafalgan self-medication**

## Example Bundle: Bundle: PMLC document with Dafalgan self-medication



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DocumentUCSF3CARAPMP004PMLCDafalganSelfMedication",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-document-medicationcard"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:549fd427-6758-400e-ad63-46d0c43fbb0f"
  },
  "type" : "document",
  "timestamp" : "2026-01-24T14:48:55.602+01:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:549fd427-6758-400e-ad63-46d0c43fbb0f",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "CompositionUCSF3CARAPMP004PMLCDafalganSelfMedication",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-composition-medicationcard"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Composition_CompositionUCSF3CARAPMP004PMLCDafalganSelfMedication\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition CompositionUCSF3CARAPMP004PMLCDafalganSelfMedication</b></p><a name=\"CompositionUCSF3CARAPMP004PMLCDafalganSelfMedication\"> </a><a name=\"hcCompositionUCSF3CARAPMP004PMLCDafalganSelfMedication\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-composition-medicationcard.html\">PMLC Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:549fd427-6758-400e-ad63-46d0c43fbb0f</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 736378000}\">Medication management plan (record artifact)</span></p><p><b>date</b>: 2026-01-24 14:48:55+0100</p><p><b>author</b>: <a href=\"Bundle-DocumentUCSF1CARAPMP004PMLCEmpty.html#urn-uuid-c35ef74f-fcf6-4a9c-9782-fdb79116f368\">Device: type = Pharmaceutical information system application software (physical object)</a></p><p><b>title</b>: Plan de médication</p><p><b>confidentiality</b>: normal</p><p><b>custodian</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:549fd427-6758-400e-ad63-46d0c43fbb0f"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medication management plan (record artifact)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "date" : "2026-01-24T14:48:55.602+01:00",
        "author" : [
          {
            "reference" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368"
          }
        ],
        "title" : "Plan de médication",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "custodian" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        },
        "section" : [
          {
            "title" : "Medication List",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "10160-0",
                  "display" : "History of Medication use Narrative"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Ce plan de médication a été généré automatiquement par le service eMedication CARA le 14 décembre 2023 à 14:35:07 UTC. Tous les traitements actifs sont considérés.</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:0972e4a0-b4ce-4d1d-bffa-1172a58f499d"
              }
            ]
          },
          {
            "title" : "Original representation",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "55108-5",
                  "display" : "Clinical presentation Document"
                }
              ]
            },
            "text" : {
              "extension" : [
                {
                  "extension" : [
                    {
                      "url" : "htmlid",
                      "valueString" : "pmlc-pdf"
                    },
                    {
                      "url" : "data",
                      "valueUri" : "urn:uuid:03a8e3f0-4bdf-4770-8ce5-a034b46ef99d"
                    }
                  ],
                  "url" : "http://hl7.org/fhir/StructureDefinition/textLink"
                }
              ],
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">The original representation as a <span id=\"pmlc-pdf\">PDF</span> file</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:03a8e3f0-4bdf-4770-8ce5-a034b46ef99d"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "PatientCARAPMP004",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientCARAPMP004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient PatientCARAPMP004</b></p><a name=\"PatientCARAPMP004\"> </a><a name=\"hcPatientCARAPMP004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-patient.html\">CH EMED EPR Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus 9}\">unbekannt</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Medical record number/100001368 (use: secondary, )</li><li>Medical record number/CARAPMP004 (use: secondary, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.1625.3.1.3.1",
            "value" : "7857bf60-93a1-409d-a647-ee260cec9c0e"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.177.2.2.1.1",
            "value" : "100001368"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "CARAPMP004"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Karce",
            "given" : ["Michaël Christopher"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1973-12-25",
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus",
              "code" : "9",
              "display" : "unbekannt"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368",
      "resource" : {
        "resourceType" : "Device",
        "id" : "DevicePmp",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-device"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_DevicePmp\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device DevicePmp</b></p><a name=\"DevicePmp\"> </a><a name=\"hcDevicePmp\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-device.html\">CH EMED EPR Device</a></p></div><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>PMP CARA v0.1</td><td>Model name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 701612004}\">Pharmaceutical information system application software (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>8153cba</td></tr></table><p><b>owner</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "deviceName" : [
          {
            "name" : "PMP CARA v0.1",
            "type" : "model-name"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "701612004",
              "display" : "Pharmaceutical information system application software (physical object)"
            }
          ]
        },
        "version" : [
          {
            "value" : "8153cba"
          }
        ],
        "owner" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "OrganizationCara",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationCara\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization OrganizationCara</b></p><a name=\"OrganizationCara\"> </a><a name=\"hcOrganizationCara\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001407428</p><p><b>name</b>: Association CARA</p><p><b>address</b>: Route de la Corniche 3a Épalinges Vaud 1066 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001407428"
          }
        ],
        "name" : "Association CARA",
        "address" : [
          {
            "line" : ["Route de la Corniche 3a"],
            "city" : "Épalinges",
            "state" : "Vaud",
            "postalCode" : "1066",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:0972e4a0-b4ce-4d1d-bffa-1172a58f499d",
      "resource" : {
        "resourceType" : "MedicationStatement",
        "id" : "MedicationStatementCardParacetamolSelfMedication",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medicationstatement-card"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"MedicationStatement_MedicationStatementCardParacetamolSelfMedication\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement MedicationStatementCardParacetamolSelfMedication</b></p><a name=\"MedicationStatementCardParacetamolSelfMedication\"> </a><a name=\"hcMedicationStatementCardParacetamolSelfMedication\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medicationstatement-card.html\">PMLC MedicationStatement</a></p></div><blockquote><p><b>CH EMED Extension Treatment Plan</b></p><ul><li>id: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:cb13d6de-051f-4a3e-ab85-c05650fa254e</li><li>externalDocumentId: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858</li></ul></blockquote><p><b>CH EMED Extension Last Considered Document</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858</p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:0972e4a0-b4ce-4d1d-bffa-1172a58f499d</p><p><b>status</b>: Active</p><p><b>medication</b>: <a href=\"#hcMedicationStatementCardParacetamolSelfMedication/MedicationParacetamolDafalganEff\">Medication DAFALGAN cpr eff 500mg</a></p><p><b>subject</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-9b00e81e-1165-4039-9d60-698ef838ae1a\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</a></p><p><b>dateAsserted</b>: 2026-01-22 14:50:55+0100</p><p><b>informationSource</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-9b00e81e-1165-4039-9d60-698ef838ae1a\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</a></p><p><b>reasonCode</b>: <span title=\"Codes:\">J'ai souvent mal à la tête.</span></p><blockquote><p><b>dosage</b></p><p><b>text</b>: 1 comprimé en réserve, à avaler si besoin, à partir du 22 janvier 2026.</p><p><b>timing</b>: Once</p><p><b>asNeeded</b>: true</p><p><b>route</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 20053000}\">À avaler</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #MedicationParacetamolDafalganEff</b></p><a name=\"MedicationStatementCardParacetamolSelfMedication/MedicationParacetamolDafalganEff\"> </a><a name=\"hcMedicationStatementCardParacetamolSelfMedication/MedicationParacetamolDafalganEff\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medication.html\">CH EMED EPR Medication</a></p></div><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680475030011}, {http://www.whocc.no/atc N02BE01}\">DAFALGAN cpr eff 500mg</span></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 10222000}\">Comprimé effervescent</span></p><p><b>amount</b>: 40 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span>/1 plaquette<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732984005 = 'Blister (unit of presentation)')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>IsActive</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 387517004}\">Paracétamol</span></td><td>true</td><td>500 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Medication",
            "id" : "MedicationParacetamolDafalganEff",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medication"
              ]
            },
            "language" : "fr-CH",
            "code" : {
              "coding" : [
                {
                  "system" : "urn:oid:2.51.1.1",
                  "code" : "7680475030011",
                  "display" : "DAFALGAN cpr eff 500mg"
                },
                {
                  "system" : "http://www.whocc.no/atc",
                  "code" : "N02BE01",
                  "display" : "paracetamol"
                }
              ],
              "text" : "DAFALGAN cpr eff 500mg"
            },
            "form" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "10222000",
                  "display" : "Comprimé effervescent"
                }
              ],
              "text" : "Comprimé effervescent"
            },
            "amount" : {
              "numerator" : {
                "value" : 40,
                "unit" : "comprimé",
                "system" : "http://snomed.info/sct",
                "code" : "732936001"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "plaquette",
                "system" : "http://snomed.info/sct",
                "code" : "732984005"
              }
            },
            "ingredient" : [
              {
                "itemCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://snomed.info/sct",
                      "code" : "387517004",
                      "display" : "Paracetamol (substance)"
                    }
                  ],
                  "text" : "Paracétamol"
                },
                "isActive" : true,
                "strength" : {
                  "numerator" : {
                    "value" : 500,
                    "unit" : "mg",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "mg"
                  },
                  "denominator" : {
                    "value" : 1,
                    "unit" : "comprimé",
                    "system" : "http://snomed.info/sct",
                    "code" : "732936001"
                  }
                }
              }
            ]
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "id",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:cb13d6de-051f-4a3e-ab85-c05650fa254e"
                }
              },
              {
                "url" : "externalDocumentId",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858"
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-treatmentplan"
          },
          {
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-last-considered-document",
            "valueIdentifier" : {
              "system" : "urn:ietf:rfc:3986",
              "value" : "urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:uuid:0972e4a0-b4ce-4d1d-bffa-1172a58f499d"
          }
        ],
        "status" : "active",
        "medicationReference" : {
          "reference" : "#MedicationParacetamolDafalganEff"
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "dateAsserted" : "2026-01-22T14:50:55.602+01:00",
        "informationSource" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "reasonCode" : [
          {
            "text" : "J'ai souvent mal à la tête."
          }
        ],
        "dosage" : [
          {
            "text" : "1 comprimé en réserve, à avaler si besoin, à partir du 22 janvier 2026.",
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2026-01-22"
                }
              }
            },
            "asNeededBoolean" : true,
            "route" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "20053000",
                  "display" : "Oral use"
                }
              ],
              "text" : "À avaler"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "comprimé",
                  "system" : "http://snomed.info/sct",
                  "code" : "732936001"
                }
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:03a8e3f0-4bdf-4770-8ce5-a034b46ef99d",
      "resource" : {
        "resourceType" : "Binary",
        "id" : "original-representation-pdf",
        "contentType" : "application/pdf",
        "data" : "JVBERi0xLjYKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS43Ci9QYWdlcyAyIDAgUgovTWV0YWRhdGEgMTgyIDAgUgovTWFya0luZm8gMTgzIDAgUgovTGFuZyAoRlJFTkNIKQovVmlld2VyUHJlZmVyZW5jZXMgMTg0IDAgUgovT3V0cHV0SW50ZW50cyBbMTg1IDAgUl0KL1N0cnVjdFRyZWVSb290IDE4NyAwIFIKPj4KZW5kb2JqCjE1NiAwIG9iago8PAovTGVuZ3RoIDMxOTYKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgNDA0OAo+PgpzdHJlYW0NCnicbVcLWIxZHz/nvcwkSZmaCqWZqZlKKXPdfCohlSLpIhImpkKIQVddtJHUIrm0hco9kUutXHJdYhf53JZdD7vLuqy+x34WX5vm7fu/7wzt5/lm5v+8c857zv/y+9/OQRghZIbyEYlQslafBiMroFJ2Njk1M0mqX8KOKxDql5Oi085xLc/8BiFLdk6dAhMOcwU6GIfA2CVlwdKMWoVZMIxTYVydumi2FmGnKwj1N4NxzQJtRhpahS/BeB+MndOW6NJSeKVFMIY1iI8wwj09qD8i0HWEaDldAFrxEQq0FlkLRNYiWv6hKpy83q2gC7rygL6nXiJE9FQhRL2AtXxW80BSghVYQpI8Hh+LSKkUx/9xk5z0ALtcDKvmD7BgNhP9k/gWuJqZw3LB1WRMP7HQUES4S8NB/uKeDvoWvRkNAU52PEoilkkJlVKjdlHIKTu+VCoR83mErY1QIXehzq7LZc7daS4qKp07Fy979gAP9Wlyad9yYm3p5h/PV4At9VNP7w8NwRaH37e1PWjepUn7Mi6OOXPryvONYC1GOpD1C8gSIRTkjKz/rxS1RiPSiEgeRTxj2pnDIKig8xEerDnvemHT2Q0bvu74oaQ7QcHEOxMxc0qZizb4C+zQ9e2le/t2qfX62Fjm4s3bzyMmMDWMdcZCVmYA4FoLWFmYkCI1gBaWYJwy7yy2PltcSlS+MwwgvH5l3AiR4TFdYJhQQMgNJd3viDrTfl497B9i2i8QCu3Uag0WYYkAnpYEH7CXSmU8Hj5ypR5bd7RSVhYDlQMJd4yY1w1NA0SWTirPAYaHOSdIW2uqP2X94TVd0O0tSI5SzVeRV7vyyJrpm0cEpEwe0h1ONlmWrXBKAB9zeheD3P7I3ihZJLcTCm1teKw8jVytUkolIhIvWgxWEHMqF2nn37+NLW78Oby5ZVMFE6MjQg3H6QL1sJ3zTz90NOwhQrdsWZOWYehkeQ/r6aC8qInIC/mBJ8RSlVKtkfB4Evafi6uG4y3m8WVqtUIOIvkkj3ONhg9Gcn/AcHYAP3JHQgyFeVFHc0sbcR8sfiGYNyM9a9BRr8enD7QJxvd1d3McYikaZfDWTtBOnJhkNagtfbXU1dN8QriVs1Wubt/KE2cocqZz/JSYKY4bi2pWj45nVsmlri78NDMz7BY2w8N91YQVFOniODgOcTE0pqeDfAm6D0ZIB8FiR4hYrTWcqsZIYtWytcJ3k9d7VGcxJ87dCA15fWj/JfMjvNT4jbVu5uZZev1wpvXHS1cPNOysr3DQzj1+drjOh3mHWGyCel5R++lraBCgY8TGxFsBRgsUbJZJlCxaMrnGn+CQ4luyoYs3bGv09390MLvKmeZb8ic3vbMU0A22dGjd6HNakbdD3uKsYO9g2Qzb1t3fnTt7PGWGe6Qb3vlBMC7NXbFgZuzanepN1aNWrA3xOXk7NjvHpEsHJQNbHdiMCeTxjflhZ/IUlz2se1xFGs5hGPHIolXa7Z4lob/UXH0cHIyJ2utP7Q19iDiqIHPVcfwfcUTRV7OiAgozHn/XVrfjyI3TKbqSkJwvDwCuYqgptmA34Bpo8juPT0KMq5TAmv2LOeNxXtRefcUm8755zbkDjkWv0wmXH8POTWF97C3JAv3U8hLnyXKDniia6rd3yo6Fhjr6GpMr18k5e8AK/A5kGGscX6IRgAD8TtwkTrp97BZ9raGBWfjhMjWC9XPvWhTIpus75jHIoa91KWHSqC8vjJrAekkr+BixrL4ahQ2oqWBtsPsUwJLeJURFjkN47NKDg5Yf22MjqDfvR5OhG5M6HaNqU1ZvsM07yr1tGLycyMpShkVcrjHsIqNmFvODIgcvmfZiZVJ5SYAO7ONeXqwx1Jp0oYSgi7FGsGWhV4fPcMThy5v2mAvMObmfIUnMMNSRUd5Lx7LCPoeSxQ9in5KDHCsuHmwIvjES1MYI5Vt9DEU2StRqSj5pfNj9km+f0kHjOo/fenSyc3WkeoJ7flbyCm/vfxAHVjIvErWJHd+3V22v+6kNOwUNq22Nq6gaFzr+CfSY68wUajjEnhipuTyQScAOHsHnzPvcQrYQALYm4Rp/EsAmPNhMoChK6X3sL7oPRZtRe3lmJBVal76t0c/vZ+nssuHOPpAWOSEuvm62M2xSZtCiQYOYP9/QPHsfe2f/IQMC/a1mxrbuvtZ65gT5Q2SkenNV4Iq14dLcLVv8IEM43InXoCNbIaWmKP2oHt8UAsQND59xOdNsFjbV8frxQI/6QWbU6PxoTwVZ3093KM1wjfSXBIkdfQfvVxalWnI1hoYac48KQ0NZlFmIZRqhUOGsUsqk7Jetl73VBky2475Ccm3n74euu28UrV2GJQrlroKAUWNf3D7SJtwpzErOKfJwc/sqf1RgMPara1yW+0XcpDP+Hu6KoTK3+cEbtuXlO0SMiwjx8LWz83Jzd0/j9Ejo6SDyaU/If1MlEkg0CjBNwZf0lmQsiNH2z10xMG9uhveVgVdWWHh5yfwEs22SojVhxLrCN28KDdkjJZ6elkX2LE/gTCVCivXn8opUCJwIOzsWMUwlGirvfnNKRwKM1EC7YfY4nxrBpqNhlNB3tEyl8o73JC6wcTgV4jAR+rg1kgEXCAArPntygGrIgU9CBFCmdLMkQU/i4fH2iROZX68133ALV036PXLLLGmgwkWQnhqe7e0z4QvHdHrz+4c96PUff2HiScZfv00rLut6Oc+jYFv93rCqapVKdbD9XkJVNau/CiHyMvRFc6j/fDgpCGiNq4IkLzt1lznh5JvMFgnO3PO2srKSGva46bcPrM09b8HmGNBXZtwDSvoTGk7V/+l0bCBbsknFJ5sdu6fba4rHy3VzfIIhXdQr5i2oc61Xd57KaklWiBcdK9nYPKyyMi+hfKRb0Cgnr2kKRWZ4YmZ6umv9sak7UuYmjspYNSVha4ixZ/kAXlqQ78mi1SvTxVQd+EJjCrFnLy7SjGskGkJ9vDlTl35AfHQE7nvq1P3zjbiwfKTfb5V5s68qdjkdzi7bsbkgx4kcVF6akJq1yPJkc0tN5Xk7auC27JxEbapn/GOfpWWbctOyq416sH0/w3iW0fE+xbVJI8hsEV9EmjKavDLmVe2JZ547h2xftqepZOnO9MMXSJGjoXCJfH1Uy68Xkhft3jV0yaJTDVnrdcT7SibQw+duUwvEhh5k6MFWJ1P//NSojOlCkJ+gNh0mTE6AISHMb02KjsLi1s3nJXsclkTueqYceXyxvkE7eswrJrN4SUJ5dHpawsSI6TZZP65/86rDsK7YJTKOeci8nzZzVn3a1vyC9fhE4e7kpiX61R5Dqzmb74Dvj4LNEAhaCet5kj1fGg8vxh8+dtomwMNDu+ZSWXeXI3l+cFrl0KHhYrHfQFVE0oXp0xu/fVtbWV54UqOZr1TOVc17yfWycWBnKNgpQT5sb+ac9+mwwLoVWPP/BvIAgdJULdjzE7lyzP7k9KnTEkePfl1ReGK22N9jVMSkk9qvz0q32y+P3/44qmRBRUtu6szJ+4gGXZJS0bJ4a17uev2d8uRHN6NzIyLHl6z1ipmORUR8Zvn91qxVihTQKRIMfg653dtfgfBz94vuDkDUiPb27k3t7cZYmMXEkVOglUIeBSJrK4GEsLZCruQUw5n2Q/ewJ3aExk0aNEw28wOW4S14KZH0kM0lXyaO8IF9fREaA0d4QqYYABvpNmJ0csqhe8wd5gkThw3E1Qs4roJ5wMxlSg1fP4R9pVDLXvb2c+KlYWwtcRb6uTP9M4I7EHfWoZ/ypCxn0N8VJ6He+exP81L0b07/RuoIUUw/RTTHD05mRCFTMoM0PKDbmN9t8BDWR2uoi8QDOrsXDwkQ8UByUPJPSaOEzm6BD8sLKDo7v1Mvmtl/5DtEslc3hB503rJjnz+lmf2r63D3E+EsszjgyQPCyIgh4vszE9EY4dGuw12xwlnkC3QX/f0j4yF0nfCFk3xsTxXdhhbzfJGOjkUBvHoUAOMASo+GUQAkPINMJMZtSMQSrBGzYyB433OdYMfACvglwDMN5qcCqeDdW3j6cLz0SA90B2gcrIuEPbOI+h5fwren9KMMmGsEWmPS0dNEGUBPwSg4ZuOtAB7cLAm405JuQMWQQzZA+UCwhoZ3NEQ9fRrOYC5A6wEJJRDcoc1gnVkKUANCfWBvn+lAEDjmc4DgztsX+Pc9jJDFWCDoRRZwL7b4Ge7aIL4f5Gg/4Nsvmr17cyjL8GQUDT2LZ8L844dCRAvuKTpMlaH/Akr4bKANCmVuZHN0cmVhbQplbmRvYmoKMTU3IDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/nzzwAwBvFzjBDQplbmRzdHJlYW0KZW5kb2JqCjE1OCAwIG9iago8PAovTGVuZ3RoIDExMwovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic7Y7JDoIADEQfKogCKqCyi6z//4k2bCFwIUTDxZc0M23aSQGFHbCn5dCpKqXRc2SKLnXijNF0JlajF67csHHEu9x5iD6HGw+fgFBcREwi+prlriVdtPUmW5iXr3/lz5coZpNygy9+RzXy9QdXmALmDQplbmRzdHJlYW0KZW5kb2JqCjE1OSAwIG9iago8PAovTGVuZ3RoIDM4MAovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnicXZPNjoIwFEb3fYounYWBFgRMCIkiJi7mJ+PMAyBcDclQSMUFbz/1ftVJhsSc9NCvva2XoDzsDqabZPBhh+ZIkzx3prV0HW62IXmiS2eE0rLtmsmPBKPp61EELn2crxP1B3MeRJ7L4NO9vE52lotNO5zoRQTvtiXbmYtcfJdHNz7exvGHejKTDEVRyJbOwq30Wo9vdU8y4Nzy0LoJ3TQvXYin8IyveSSpEVGopxlauo51Q7Y2FxJ56J5C5nv3FIJM+++90BFyp/NfQLnAEzosWGpIIFaQMSQQR5AZJBCnkCUkEG8hK0gg3rFUEY88VhoSOY8Eu6vqUSBL7K6R0ygpySBTyC1kCbmD3DNSbBTh0B5pAplArgFcSITFIqwSrSCx2ANrlomvBYg2LFOUlOKWNOrMcD4PV5mTKuZjeoQVr6lWHPcIK75PtcVMINzGLEve1iPcZNwFj3+bO+Leus9+a27WulbjBuceu3dXZ+j5DYzDeE/x7xcoz80kDQplbmRzdHJlYW0KZW5kb2JqCjE2NCAwIG9iago8PAovTGVuZ3RoIDQwMDUKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgNTMxNgo+PgpzdHJlYW0NCnicbVgJQFNX1r73viUoCCQkAWQNYXHFSliKIoozWNwo4oLiqGi1REuVilWEX5BVRFHbKhZFXACLFBUQUeuuRVxArNuMv7Vq1U7rSqlWCsnlP/clFafzhxzeu8s75zvnnu0FYYSQBVqJOITiZyclwsgWaC2bjU9Y/mFT6uz9cL8RIXmFft7sud65yw8jpAiBuUA9TDjm2xyF8RIYe+o/XpIs/mi/F8ZfIoRRwqIPZiMywRkhOzbmP56dnIi24zqElMWw3z1x8bxEvbg2B8bHYCyDR3BXF7JBBDUjJPgJGYBKhlCYXCO308g1gl/n1nFcs0EnZHSkA13if2Fi9Nw57C7tRWGclsPu6gKVkEHDMQBj6+l0KikRmpheYd6EBPgrFEE6kciVCoU9bk0rez+qbMW+o/vH7UijU/OwNx578iweh71XXaED6OPDtJ7eKJD4WAGf/iY+EwMVigBb4qNTKxQqJSEyq7Qd4/Yf3ZdWGhVVCmzW4v549DfYHl/9Lo/+L60/dYYeoLfzTHg0pJYYAa814JFxnE+QV5DA6Tgve4EULyssXnac/jwQW1rl9cIWA+lPpCMCky4U0T469yPcl96Kzx4NPEA1nIZuM53nqbQBOO3s7du3YR51PSXBgJHZAmsxCabzd+GtQlOHu3APgV2jup7yWqEQWaLesMOWaD2I3Fah8VNw/t7eWg9RVCkVap2fgtf+8dtvL59h9MezQ8NyExbmDw/LW7B9IzlNt9O1eDH+AH+EF9DPaVFTV/LSrsvnu1AKdgb5cK68DejWk+HSBGjkQoCXTs7bGApwPD2Dx+8uKiriQx5UPup0kGwRD/utAI/WtD+UBAUGwjfAn4GR+QQG6vzUKqUoE6Uvb2WYrvusLKrPe+4j3s9bnrSp12Hl6zM3Ho0d47VOn5TnWlSU/mndhlA3+MubsmTlik/ke85fOBK9a0KftMkzN48CeZGgvyPI6wPaK0Wth7dPkFrjJ8nTBuj8/luwSq3mHdt/utnl8I0ntsnbWvPVh3M2luZkLfvC6iDIvv5k84aSapxz9ubp4/KO3OykjOKMxZ9kpSyy3numoXrVHldeXsvsPgj0DJLsYsf8WSvXBGCdXKfy0sj9A4NANe6TSqOe5Bw/ZyjBbZiz97DGw+lpPHwtV28Yt24d8fOd7jsgSMlsFg06uAAvV6YDMumg7sautdOoNBzDr+Zd6OsnDW3u9S6fL/2srHzt6LTh1YM4jTHL6dN9a5oS8aW7XaiqVKWfv78op8w3iPxeRMNiF50DvHqzneyRJ5Ni8hMEPO1l3uxeso9MEqhSStJ5x7Ybzw1YbNtxoW+Vf92WPYNrk84+OlSYm7Z1TMakzI24+S6leA6Oxgtx3ob1blX0Pm2dPuvlzaLdX2QkVMzaL/nDfMkfMqRYFYlMJCqtvyIoUBEEvsRbJRQNmDbt2JARIUcyjZZcKf+inNKZR+nGs2uxZvsmPPZYEbN1HGBXAHYH5MV83GwhcGo7kZ24d4A/gFe8AQ/YA3kFff2qvLF/VeDhrZV8nzNL0o7p2+88afu2OCuzsHBlZFYUuUM30ZQ1W52qsTu2jP146c31d4y0bH9lS83mLQciMkCuFJP8EHPOgqi0M0Xm2bP8kJYWw6aWFhb/BPGQ26JBR5mkJafFOgxZi/mAhvP2xgm7zpHht0jg2Z30pHyQ8gCxOWjti4vpXJb1cDE3+d3V/jQAf6ddyXJf11NhOejqBPHjbmcv8loPT5bhPHV+PBwVqIggz6k5d9xnU3EMbbhykzaVl2H/m/ex73sHB9/a9JgaUu+vxl6R9Sdq8eh79/HIquq9IamZ9BrtqKLG9YC3AvDOA7w9JN9VEl4LudgdcbZIAzdgPWHeXnqpyfgrvoo/xDmn2MHSX/GQbf9eSVru0hP7IBkX0YNYxHadNflUOmfgyVPgaSnFvVxjJp52VvIDDZ9zfobLxcVCRjEN2UJV5v2fSRhM0SPtx/EnuV8MNzkFGWpsgM3GlyVSTgGb7ACbQHzM8wsMCmBpyGwYgNxtF1vEDcx/MYZOJ5MT6dET39MzVTgRj3+MPd+vD7m27SW4q2LVpAi6g/ZevIIZB8fg5JJ9gckL6S36kr6il0z53L3rKacHbHKEwruDUc7EKkV84cB1j6OKtFn6ZLBJ8w/KI0fclmSuz+fCiw3a5idmWwjDTbZguunk4BCQu0G7k+Sr+8YKUvHM2EycjQ+FDGMoOWMsNjwgFWabDILnBJMNIc0OMiw/yczW6WTmKxJYdzHzxWq1PSRYyDtac9IBKZxajaMrO/EypZcoOjuLOPFVlcA79lfSjbl0/TQicFWGSUKGYdDQVa5Os6Zac991pHNVkYUR0wr8DCO4U9hhbKFZB3dzTZNkeQcAIC2WuP9AOqyqfjJaEwuuwjAV4EU0xHDFHel89chsk3/xjyX9Jf+CINWwI/bjZbYmB+MfL71VSOecJBOeYf4UPUxzcNaOHdytnG8/Mt4WMn5ownLj9QIpthgOdha9kNrsKX48S+PMnhDwEjswLNn8HHOHduIN39PPcfRX2+hQ3Ly5nIw2HhIybpzYdtPZuJOMxqWpGcZ2U+2fATmlHXxKxxDyGnfuTcr18fb28SU+LK14aqT8aM4r9vBn/vLttIU+MRqjj7hfOXDkwvDg4JK4RZviPPwCsAqTVqo75rZvy57a8LBh5yaUjOo71tm7Pysp+EOv9GXpqeFTnJ291Y7vBLj6prx/8NsvajSJ8xIXhU12cRlg19dNPti932IJoy/YsU7KK+YKo1GRKyeoM5/LP+p04h8VF5v8FWJIGA/7rEw9guQXUHWxMN54+pzx9AWc6+CjUg5Q4mxTn2VwH5YWGpqn4+6Znl/A1xCF8JD5HWQ5HKAjipm0voVvUGK1C5xBDNgqiY+EyqGTIgLybVDQn4UVeg21Ss6ybpBKSsc+WlG0k7HyLuViVvxxSWnZnd9/S0xevtDymC/Obrrcb6izm8co7dzpohh+yNCQNnLkqFlT544bP01ZVVhRJ/JDsxdHx8qx59Ea6hs1QZZoYTE/8X/iST8eOzrMnTA1buDAbRMl7ICNuwjYejNkrPXRvX1kcKJB9taE9H3wovXe7tvOR6wXz1+/Mm91XIZNvfWiGiV2w3ZYjt2qNlvHLjhx/19X9AlW+i2TQOcpwPcF9F2OrObM9iUBWqbcnwJ0PhAM4BFY2V2nub9BbPF+5SnNpxsbU8v8CKnjOKNn8qqi/PzNecsth41x1sdiJXbATtgpds5yfLrTbvIiJ+L64Nvrd/95/oKpljBbO4A+dlI/Z9aAaMySFXKVj6SbDCu3bPy0wLFkNq1o7ez85cXzb2w2rMoqEvHrby7OjBjYhbAr7o2tsCu9R+875H+9bX+RZC/IHSREuIhUJp+CHkmqnvYqyWIqnQrPr/vyy8zcsf7vuIeHXuMOGUZzh7JSNmZarbYY9Y/ZWQzjFBrDveDHQo8HXVBYd4b8i438wQd1IviGaPdWaSaeNVddDypS5+auIrraZY1HLzQn7fElvEi+Fn8ctHNFftrS9St30pg1K3uPnVCybZ9+PrYAi7lh+fzZysnj+MBKQ8PDh9y5hgfn7/1w5i7TaR1C3HM4K+hAw0x9HkuIkkgp/SpZZhw2pHRF9VcH45PTi+rqeA5zGQs+OHTOOIjs+yKzepMxU2iiaX2mhclAv9XAdJjUc/9Z94ENHlZXVyc0VVXRhZ3noClApOsyjTHvU5j2cR4+AeZiwaTCIyGRg21dbcPfrUtmj7av6bGG8BF6vrxzRFG+dB7wH4ea+3smJRRkdPjDBKzB64WoBV/oZ1qD1KRzJSqdpKK97r81lW5w2AGOqyQ84YYUJqSud+be3f5J2abaKYlLs+BfUi5JMhZwE2clqdQjwl2TYud89HFc7SVmhm3J+3caC9i12iSbe26Kq27ZfxWKR9YxWRzBXGjp8tryg3NTMwvfCLAbMso7cUZ9I2O+NaXW5N9TWK8LfC2hE+1+X9FJ7ytvfIR36Xj+rO23tvbHx3O2lRSs2bRrDXGlD+ljrIFodcAO9AW9f+9Sy/c3/3kFeGbTGOA53hSrEk8frRlkt8X+IqCxsWOKwAP8fVjg+XdKMs6fO56Ss3F9XlFuKvGgj+ijY7JSOk0QJy5y4kdNsJs7AzqEOz+eaX5042KDyT4kD/RwfMs+HEgKCnwTTd3W4V09tbEjvTw9QhOXEn9jExcanBbuOybIq8ecQD+fnuU9T0u+EAw5px7iasBb7zJ/FiVzRQrU/WdFYl+u/t9XLt7WbLffsHJ1+tQ5S1aPUY8cc+3igWvOu2yyFqYsGTljxY+Dg4fi/kW7cwrcYiZMmjQiqrdbH5de3gujNm5NW6OMGD9mbNB79q7vafsuYjjculpJP2EAyxHzGIwAliaCdJActKZET/pNnZmQsCI7IPn8ed1wj1EWDqkp5GpWW1uWcXLkcGvGIwd0eQJh4sh4mJjo5Mo3saG210KZ5QJNbjMvJbOQ2QoL5EjijJom8p0xeldSbQlJMuyduUQlTIqT7APRyP0BPHuZ65ydqf+x4/6gCTfoslPPZR7OvRwdLX/nh7AQNY5QLpvjMznKjZyBx7u6THVMeCh6s7dT4OaBjr2Zd5DmvaX5oTjx/533QHfemr/2Zj4UvXprPvXNfAhql3BH8DW41VxfMWQTHW6l9TNvtQiN9DGUICkuBvJnSayQ2p1ztEAktvRRuZB6GD6Mv/SeIbYCf4XEfziOlPhjqN+bhWusD5gI3OEtxUcrw4+b7s2/TX7mocpZ0zblnj2mWi90EIXYaq71XqzWL6YXW0Rr5S0Xtg40KTW+/+tfZ9mEvEKcBYtadKv9qiO73k60eNa52/BAHWcxFYYi4MbI1EMgWSiNRH9T13bu7khRx5nnuz8jRISaSTBsXYX0pBKlA1lxLkgDc0fZPJ+EooCKgeKBIoEGAUUD6YHmA8WxvcIUxAuNSA9UAfcV/ANUIQbDMwi5S+MkGFfCmnndfJ0B+3zh2gPkLoA9MbA/Bq5T2D3wdTHfr8ONaDVu7LoM13zgkwdzeea1bMLGCAXDfjcY58C9TOL1F4J9EUADGVbyNcIkFi0w22GAmcaZfoND34NF3IHeBQKb4sNAP4NDwD25Av7uDLQSCDyJD2H9IBA8I/QBWgsELZwIb50irIlVQE8BErzhy/4OVA0EYwvgbbEBoR7+QP8AgraxB3h+T5DRE/ZYAi9LyGeWUHSsYN0K+FhdR6gX1NNe8Ewv2GMNjmANa9aAyQb428Aem1aEbEGObTYQ8LQFbLbAw/YhkAEhOeglh3U5PCfPY783Sl4xAkejSSgOvOc/fYQH5XFXTjVfgP4Pl8nifg0KZW5kc3RyZWFtCmVuZG9iagoxNjUgMCBvYmoKPDwKL0xlbmd0aCAxMwovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic+/+f2uAHAJFxUqcNCmVuZHN0cmVhbQplbmRvYmoKMTY2IDAgb2JqCjw8Ci9MZW5ndGggMTQ2Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJztzNUOwkAQheEfd3cpxd3def+3YlK4aFNISRPu9ktm9+wkZ8HgwcyLDz+B9ytIiDARosSIkyBJSrZpMpZOViZHngJFSsamTIUqNeqSNZkGOk25W9i16cjZpUefAUNGjJnIZsqMOQuWkles2bBl96FvtTflA0dOnB07dheuLlovN9fN7+5/+FNRlF88nmhmB+ENCmVuZHN0cmVhbQplbmRvYmoKMTY3IDAgb2JqCjw8Ci9MZW5ndGggMzcyCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkt2KgzAQhe/zFLnsXhQ1Rm2hCNZa6MX+sN19AKtjEdYo0V749pvOsV1YQQ75MidnQsbLT4eTaSfpfdi+OtMkm9bUlsb+ZiuSF7q2RgRK1m01LSvBUnXlIDznPs/jRN3JNL3Y7aT36TbHyc5yldX9hV6E925rsq25ytV3fnbr820YfqgjM0lfpKmsqRHupNdyeCs7kh771qfaFbTTvHYmLuGKr3kgqWAJ0E/V1zQOZUW2NFcSO999qdwd3ZcKMvW/faEUfJfmzxA6w1OUnzLMAA+ACcMg4FWAPVUA5oCoDLcMlUYJRAeAMSDsOgRcfDhaZwxD9LJIhJbCCDABVIDbRyzDmKGGTyM9hl0jXSMvRro+wgdDnDOMEBThzARBMbpepMCZiY8SSIG7J7jKIsUGUAEiqMA1N+hlkb0GLAAhGezZHitIjvQD+oSoPOYHfzwsP/59Sp+jVd2sdVPFs8zjdB+k1tBz3Id+uLv4/wWwqskQDQplbmRzdHJlYW0KZW5kb2JqCjE3MiAwIG9iago8PAovTGVuZ3RoIDE1MDMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgMTkxMgo+PgpzdHJlYW0NCnicbVV7UJRVFL/3ey0oj12Wb3eWEdxlYVFBtF12N2JTQB1IQRExcUwBeabIM0EMBPPBYIqalSYB2R/mg4DMB2aSjqUloPYwQwqdMJVR02bMB7CXzv126TXu7PnuPec73zm/c8/jIowQckFViEUoO624ADg50GYqzc4ty8q4+bgT9m8jxH+Zk5mWYagua0NISAaZJQcEmk2etcBvAz4gZ8Vrq+a+JbQCfxj4uNz89DSEzLsQkgGLElakrSpARRjeyRKA1xYUZRbkCJs3AE/9yhBGeHgYeSIGdYE/I78WUMGnUQqdQqlT6HjjYF0c2zVk4tcOVAJ1cP0IdGtAtxB0XZESdL0ZTg+6WoTDDHq9wmS0WPjCFtJx3n4WE5yBN5Ird3u+Hag8nsV0/EpO7efXkvfIJ333h2JKr1KUDntysDfaYU8QqD2FzsjxYTq6Wnh5xc1G8iHpZsrsWEGukAFyEYevXs+eqfm+lMCn/Vd7ibUMQTxqhLgusOWMQmfWiSxPukk4d5SrH0zn6m/cQFQvmmtkpvK9iAc9UY/NOmbqftKEGa59LPYOduCyDd/lqrjZKACZEJrhbzCHWaxWM0TpL8gCvXRGlajwVpmMVhEQ+xuC9IKglAkyQRAlqcVixjX1rT2X+mcmzX7JlfRY8e6u3vGTtX5hMy3LMkcJEYcubUsfNz44JiLaapnifbBuXzPHWZdlxyR64Kjzn5GSRTOEXe7uOZnLljOuDC/3irXFzwoIqIyh+BMAmxWw+VBkSCFHJqNKzRsoNsm9xcp7MEziI/IQezz5YkBLfnNLTV6Rm5+XkOuOfTzXXfLGgVjAbjj41H6PeelHjp44kZnhXnQwBeJOAtuv8J1IgwIRSgtlzHoaIKOQe1EnpiA4V2+VGktuHMfBxjEuPBfaVHXyQve54o8mMgzWcJzdNz8vf/XKosK8UZFxPkuX4iDsit1xYGrKIfzmoNZYMp0Z09Z25nDLyWPSedOYJkJMShpVlDMKRucMz0shBkrxyXDpytyZKUrsWkw+eEgG8KiH/Y/IA5e8xenLWXyrYU9UpJpcxTosQnha0kF+dGldt25TuZR3PThqhthER33ozSbIqsmoFqWTE00i7ia3Gxreb0xMHTchNuIyWz60ni1vL9xRKz/iGh47vx1wbgVD+8CGo1dEnRmDJbyP3MIacovvvHiR5A2e5V6Q/FVDbzZwc9AEh78wQ5DOjxFNFot0lNIiSnLqfmRDbfEsdmMEnguryy3f6SNYd5c27CX9iYmJefQ5fzkz3f45G7sgP8Rt4WKxvKCkZE3elW/sc5mUrbWNm+0tdG12+OcywL/PM/w/0194U2lTG7mdmpZV8T8XP3Q6zLeM5GoH5Go07bgoOXJkyTkFRmqQ20F+JsROrmMtZiH3kJY1q6qqKkreWMv4kafkMg6BGuRxMLlG/jjdfKztyMnjDswMAcyaf2FmAbPV8nem/kbMcSw3TqdNjrbopplfXcko7fdY28LSUNcp8dM9C56bFOJ5x/MA2IwFvGPBZgitLI62q1XlrN+gUCbIYJDKQKWWjbSQWkX/3Fgy3HftXtBjMbuqJHdBzpyKhWPmLbjfc/qO71O3JVkZGfGLKr+yRcRgW/2nW94JjI+0RYa9KMr9fN3HVy2p+/jdWp/oKJNtktXLx2owlAIOzfDvzHb+eVp/mXRqmGkJWk1QeHrHMGG2Z1WXb6zZmdza1WWb6hcp96+uYda0E9JuvzBnlgeCeS31Cd8rGGAC0ynOo1+kWgNKen3P3IqIFE/bn4h1oVMMdT/5TkPXngKXe4N7h/pUqS7JoCtADrGkAE/ZFDIbTVMdGtw7sFqV6pT/81MKCHUx4TClz6Ea/mVUw/UhNXMAZmgxsgElAJ9EV5DpQW+rzBdVg4xSAkv3xSgW3mmojtNmiJNoV34N9ACAeAPBXca4Aa0Huo0QCzos3H3sT1DHk4HgnuSuA5IcoCZ6R0polTgRJaFUiOq/2DmE2/DwhlZuC/oLHpT7Tw0KZW5kc3RyZWFtCmVuZG9iagoxNzMgMCBvYmoKPDwKL0xlbmd0aCAxMwovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic+/8fGRwAAHdYDrMNCmVuZHN0cmVhbQplbmRvYmoKMTc0IDAgb2JqCjw8Ci9MZW5ndGggNTYKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nGNgAANGBuoAJhzizFCaBYc8KwMbkGRn4GDgZOACi3BDZXgYeBn4wCx+BgEGQTLcJAQALMEArA0KZW5kc3RyZWFtCmVuZG9iagoxNzUgMCBvYmoKPDwKL0xlbmd0aCAyOTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nF2R3WqEMBCF7/MUudxeLGr82S6IUNwWvOgPtX0ATUYJ1CTEeOHbN2ZcCw3IYb6ck5iZqG5ujZKORh9W8xYcHaQSFma9WA60h1EqkjAqJHd7RYLwqTMk8ul2nR1MjRo0KUsaffrN2dmVnp6E7uGBRO9WgJVqpKfvuvV1uxjzAxMoR2NSVVTAQPxJr5156yagUcidG+EN0q1nHwqW4PhaDVCGkQT/h2sBs+k42E6NQMrYr4qWL35VBJT4t0+SGHP98BdIfeAQFlcbZBesULIswBQtu+ToTNGyS47OLL3nNinQmRUIrwhThDVClOIaYB7jYQzhDWGOEC+6sAAvCVYoz4/h0ffHhQZskzrayxdrfWfDPENLt2ZKBcfIjTZbKny/vEeWpA0KZW5kc3RyZWFtCmVuZG9iagoxNzcgMCBvYmoKPDwKL0xlbmd0aCA1NDkyCi9UeXBlIC9YT2JqZWN0Ci9TdWJ0eXBlIC9Gb3JtCi9SZXNvdXJjZXMgMTc4IDAgUgovQkJveCBbMC4wIDAuMCA4NS4wIDMwLjBdCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9NYXRyaXggWzAuNzUgMC4wIDAuMCAwLjc1IDAuMCAwLjBdCj4+CnN0cmVhbQ0KeJxtW0uOLLcR3M8p+gJukUwmP1vLgNe2Fj7AQJYN9BgQBBjw7R0RSbJq3gwMeTqqWPwkk5E/vt/ffn/7G/5LD0uPj7fhz+L8+Vo//5T4/y+8v37p9b/e/vH2H3z4019+/e+/33/9+1///Pj5l7f0zKk80jNN/cnJ5+OXn++N3v/4ttEf728//fZHfvz2x1t95jbx3DAfew7Hz5YGhrRnG7XyzSj9Yc/Kr4vnht+5Jhdqj/e3gq9mJ6zeH+XpsxBZHwWoWl5dsmXpzm6Gm+NdSTYeGb0ZWxa8BKpm0TSVDNhLmXzZjX2njO6iUzzz6FQD4uHo47EmU54Nne+ZAmW0xBrynEITYsf6PL6bXN/QjBom9k6heCF2d4liplHZd8vs1C3zi2T5DAGUs2s61g7E9EMI7YC9wEDpWVPlQDaytj9X9oh5xW9O2ivWSdjU8SyQFmBKpT6u3XuHjvQn5YoRsJf4PTp+D/f86M9ae+MwGVPuGIBS8MkJN/xwjVqA/Tn6zBeyUW9tHVo0ox/Iuj5nqxqjO9sm6NZZ33qZnnMmveSHCYvBqle30JjUotsxsBjpPKbCGWHvN9R0T1ssxercPWGVbY49ChC62TOgPLhtWx65QPPzMzVoEt7YZK+92MSAQ9pd61gSmZWTteSGl3V2TQD6DVSmDkIxtUxQCUGoIJcxdGKo1/7s904de9OMI5qa1jo5tTScTS+54Q30mcrSU+ab2LichXrtoS11yW0aFdo5KUxm5ib1TqaJ9qP67el4VngOuYaeUtZnvWvx904hmqoR06REsxWpLkRCqY3pNwFnHN4Wemv4+GM/gEq0zpNDjJ/sjmQCmHriSaoTRJDBBBqrF54I0IQVwpm7XmKjJ49SEUo+b+ds4qNpepvzY+JoF560MXA05zNLS9GdWgaa3Ui0kKH/gDj/lDnfaPsjxvKpXoKti4cSNH4+izWRE4aelN+UGFPTqG5iLrfJt71WsZJVgNkuVsLKcm/aHCov+bat7xqhm9gR3dYlpK7llIKjDNhBLppR1dc91z1ftSa+1oMtw8Es/b5l8eDaMuAaGjAK6Lk+h2WR2OSAFbMWecee1afNMbRno/EtCGZoV8hEYNWSb5uGB+pl7Rpg5iFZ25bRi4+zbwfGVgF6Lv4FX4tbH3x5cLaP2DT51IeGT12WxFyTtTwkeVBETNZJYWQ/nEEuptdxIJYKSro1hyhaq7u3yudnpAorEyZgbcx68GlnBjRgsFEZsTPnQR20yBtjK3B8gbJ2fna26c/QRSEMgBMvTY23DcNoatMPIi+qIQFNSCbxhrZAwuix+ppi1wI7BJDi/aAEBq3ylC3KVRNyF1WrNd5WIwJDe8w+VZNnYPAb0BvIbAaxa7DlU+S+5j/kKghzNWbLj1hgiek9JJcHn7RCse33QC+hss5wdNR0QiakxQWXRoHCrVijwpTxLNZsmlUKqToNAmVc+0YSCFQh315PG/18jPW2fu8cszSNTDdAu9c1LSjV2kzNmSsqUBwtuAyjKhQ6QhKmzigglkHxmLQMsuAppLRA04D0nbaRKrQ5Qw5aJiPBJNG0kF7hGhSaq7Z6VuPs+hgnt/BtGoXSgwEahPwTmqN3mjOskF5xLlhf5xyiW9LU6hZGhoen1qp+4M8Reud5xISz+4bvb1qQaG+/hyNWztchjNN3yIp00JZw+nIFS5Y0as7iETg2SzZBIpoXrPomlTy5oRymHJBxZqRmCyee8sf+Todj+O52Q62glhRPJg8i+DWVdVjAlJx0eNex3yCP9X2w8nrA9y+CFA6TkEFnRiD8bnQLtad+g91pWzaWqXntTn9E03N0C9vmXzA8ThK+HpTSvnlwvoDErX2FLX9q/AnKA9ud0ahCERP3AHAoYCmD5s7o81MemcZIK/MREksFpkhCWaY8c1WVscLhV8kYxxc9VznJkDAYJm34IixOr977CNia/I2FefYh4d1c3Q16hIeurwdB1xsHXWv07JuR0b/TnzmEXeDcBV3Ee3+Khsr+fQIjAnKo8fnYQQPnSzduhw0YLtEaETutOQi2TdJtkpHr4UpGR2oekZ+CTqASPi/YT1NPKYmNjLEV/eNwyV3GrNCE2MZciLzgBpuwQGbAcO1CV5QismaDsuErYMqLrYk8z8XWXG7uF58CzxqcQr7lBpZeg401SzfJU1CzHOFLx3sGBLOcr7vCyatzTLMonAFdW+xeKZuu92YevjZ82BhENYbReJwZmzkU6kWY2ifYXU5Rkx4ZA8mxNZeKtJ9g7MEDv3GReTb6R5dTZSSWdvOx8ACeqOLThtkZYqPmXPZA5EjYU9uhrVqnFAF29ZhdVsjqhevJ4aZgSKgGYV/xYFFADYfCDjaydd5OxkKZzqRH28DNLcZpLfY9MKZJn0LQpInUGqjCAimOxztbagPpGXOKdIi7orXM3AQMlwynovJYHzeQPMEVSjrbyWlDS0rlirZpS/IKt3GKucIIxhN1h4sYOhjQyljT6J+9uKvJ5J8PPoA20DjD9+vqwhW/8gwZcxnykqr1JablNjEbgtnNWbWcyWAn09uXYR9rccWb7wdcq0JOY9i0Qe+7LTG217Xq0iTg9V0viuts9bvWsB687ouapmVWLuCms4FPEFG5aSuIgLQB65DvXHl8AMsJ+yplK59LIYQhVGrJdggBWNu4afdkAB8RBtxug0s8kmy9UbgDPmuLYdQaTijPDF8j8DIw8oR28zyBnAA937oGI/S+Ak6MQA9Up25Qo6wFoa3g5MAIRgDz/AFdWrEaf3lwAhNi+WYM41xjxbED5XAeRUfSSKUaevYaISJF0yO21iHshPUkvOCg5oioSqy+KEBRaAk4uxJnCC2XsHKeeYeWhEPCVGhJGNmlFcLsB7dVDW76d0+gFzWgM/yDVtBmG6NvpSVgVjTCZI5yzU97XbQW0j6A1yDBHrCPITYnfYcaFXnfCL8aVSz7HArAoOmEZVyTX/h+cGtlruOu0vFgs/CCQcLV5IIu3anY+EuPgCrPHAkY4RFginB/cOwKWRz2rUX+9GFfYGx1bC10rtJWKfZujBk0zOZezOAwb2UuU6Qu6t3wcO/1IMgWHXW5tgemNvdrTJChkbg3fh/qJRzlUG9lWsgP9QJOuayLerk4bxf1Si52US9nMQ/zVqYcc+ReYKG4iFpnfF1hp7WGvJl3oU/7txss3uUWRWTbmeDl6whsfMABAvSSb8SLB2Z5Ey8Q4p5DvJUEUi/irdSyDblOW6y7fy/SDRicq2/8kCq7zP1Gumv+h3Ov9WzKnfLR6Bh9BEBbaiF+y2tBlAQbVXnISvgmoWQIRKdGahGJVzh/ObJ69PcAver9oDHZkIc09vE8UIaQX4+gG7YGw5pvpMG8yMtqFWcZcGQlt7h0TDR5veUa8cBkJVqnM8T3RZHbhE+Cbxs9Z/IxaJUj1XY7Zn2Z0HUGO1NP6irdkLKYapy1E+KQyiSyzB82leIJ6a18ApdgkkepYmcuQsejpB6LqEokw+AtIB1bCwpcl3B6zeE3H1EtpDmBwVYyeYTc21BM75qjbY8cbcH5yyOPDUQwMlbmpWhLZjg5uVuIqpUrGOCs0obUHEVS9LMP6DPcc4danmP1EXAzoEDwn5NqbMvemY64GWlnTacdBnQGeeMwICDXuTmQb6UwiwOB4SOs9HRl36UObWxbQ0UYFTToJaYamNOysXlwoUODBwftoavq5WJFTuSQpDMPG6eVifeFDhPyQbdgQhgdLsmVvjJmwgDbxYNOl9QvHqR0vFw8yHm0iwidDn26iJArLOMiQq6ibR4McKdBPpEGTuYItIMW8Rh67fq6KPvjE3zFzocKIbtMQY9TDwqsqzNWidCOER6FHzF5aLAzbzM2pvxUiwkJxO91LhbOKlfxs4j5TN8xyPAD3/cSFn5dGI5IrJFZvHJX03hw3E/iYafsAFhbP2UHQPjY2/8ESmWesoOzyNJ22cFZjrlHV3iQ5XhGBtsrxDpPBhvQpx0n8cBwCwGzst2f4LV5q/mXB8dNJG7KfFFBgBpzIvTXTGP3qAwY8/YafRadswpd4cRrCt7mAXYGNqcIAejddhGCMhh2ihCA01K5PEWKrLdThADMUZGVp0iYj3Or1sSflHSycOb3HVxPguB8PMftt7fIlOEneXsluw6KXNeCK7+0+/sCIzd1Gn+CJ7Pl8I1H/oJPc5qe5N/glu+t7+gkuojbTnM5jY+CWaW5fPncJ82FB8Z8405zURh1x12ZUIR0T3M1ul3MNoBaPt4a6GyBF0HaiYdG1ikH3T56RSfML6+8zceF6UK9NmTwWh/81o7/i34tsg9xYFoSz++3yifvxNZCO7W1YOSkmqqBixU5WUaomyMbA4oRxKeKMS8DlBrZrULoZV7ZrabLBVd+CziVevJbjfFvP/ktDpbHLb/VSOAbcj2ymAzgFriltyiMttMcH2+nQZgYwcQTPejnEIoQUoI0W4pgSamkNW5Xng/kDB3g7uUaEUAXtOIbSSbNPN9ez6zKa3zMfLPfO1dNOcI7SQxcVDWxsXc0Zs1V/VO3Vn64fEIdLmEUJ5b89eLJDw1ul05ObaSx2qlaFx00EinzlCwxgHOUTRysyqmCpngbMWKU5rB/IDO6L51lZQhqEg6aykznZghmLoBsgv3V68T7D87t4scd6szEr75NI/IA4NGqkbPVYN+h9GKeiggGa+jMNxcJUnqhhD5b66BWlUMGLxr8KbGQYJ1ae36+3tSMIRh9QNFBYbCTYagQVO9BIIQo+kIGZZdTuWO8hpJhv3KEmWortyHmP422Fi4AaJlXLypv0qS4YEPbN1iPHuSXToNOKCEPlnpZPk+8OsIU2GSVO4fEMz1opl8ocZqEKDgX3TMBqbGgX6KmWJ8x+zJ2SbkwitEmwglhZZX1KtZQlegstKJrgVFsoVvXo+XaYVN5HFGhKINnJb5giMBy+2D+lkVcBqEMNOJjiHuE24fOR1xwaK1oMpkFgM6YJBQs8xTim6TJB33hbSZS1tTxKVcNtWVS3XnrQFVCX3c8sBwVAgdTWc6j1R8q22Y7F2QmuUyt9ZqlJGu8EqKPWUmyWVffrGXNdfUG65qqi9BrYA4I0TNrODykg8rnhNGa24S1sVhQKm8cDJa0AOsI1VAKmbjrPFG8tId8kLUhUIH43kyV+d6VzU9R9jdeMtF4quOp9k1fAxudm/Bke4t4S7VPXR3hgW/1FFDmUuuExiqg4Oyr0p7lkUGwun6BNbtF4SHFtYIaniJz/jikD82HuSpeX6qhSGNowo31A0zr1AygtjU0Ue2L1IjCp4MIzO7wmdVoXlSOwOGnj6XPhzAmqpKETApVIIJtzqBGebsm5p/wJe+8sdxt3D96qvpgthYrkL/NcjltFGXA2yDANkMGqkwOFpU0AKPTrIpx5Iaw1TpLjJbZwYSO9gV3vrxExRnBWI4MODM8dCUixV1iPFVEARV+cULkVGPeJGuCiXbFKvMkWo+zrLJx5QH0qFaAEfRENVx0iPjDtCd1qKYwdejRbuWlZ1yvyNwZY2TjcRckSFqTJ4zV86aYIBV6sBrbhEdUcY5KVVsFJxo6hhc02b5qq0W0VkgFwXD/U9cL0UlKkbXD8DNp0gj+HywBh4wQSMjOpO6SUeclEF63Scxk4liQ7ugusbnTJohzRYdMZdL9+fKAp31jGSxyO/PWFAKPY6XZG5E41Wm1fvLcVqRt1ldmOyXVqVRNYEKZeir5RN3H4xpLYYaWdSGGGkUWlV4BVgTvkKguo6IoQ2ayg71MQbos6qTcQ+kEQ6k7b0ECTwZ8hbcrw8Zmi/sKJmeE+enQauO9OBGKZaW/8AvcrTXHQYZS6sCBtI0LrbRmfL564JI9jrxuJA0V4XQeGSRx3vEB7/rpWFha76MuNvqMeqWp0lJFqGT8Fmo6dUvLuTVThZtFkPQ4eGpUVtsEDAGaByM3uqJSEVNdOofGSNq2k3RG5sz0IgZ9JZ6qSnFLebU9lqs0xKL+gA1SQJN5w0sTgPmaxJNJJdZ0mAArpxCmpKR6NN4v5V5ZEq7MZFH9Gd0R55AnQrwRuIh7pS+8Izu1cFdzjacNUPQQJktLsah78S6HLs3RhtDatXUhZLLwRo+IeXr8nUq6sQ4bt1T4djtAfFss7mhFL135fOY0XYtIc8YRjzSWyzHkIj3iS7FR+IDgz4fjaM3wICt51ulVDXl9Q9TPNFSXw5npGgEmOjwsG9NNrDMUtTTdMVXWcErjs0f6tvIWyXdPeBdQkSD6UNb0ywNw7ejnCe8xZLqyRfnG3nS7BmdjcFY5NqEV23kpESF3uSgxNaT20E8WtZzXWbrc15VrYgTL81nBN67auJQ287KA8xJG1aHUhSfnpQrSLra6RgYCZ0JK3ei7bKkT9pUtuW+DIkuckMvkA9UaV/Fk8oET32yT3+gp5pvFb7wmkuax+I2Xsks+Fp+RKQ/iZfIbs37hBNDkM7aZ/Vh8hYbZL5PPB4n2aJl8fe7tmHzGlvNm8Jtqi/kYfEwwt9KPwecKvNwsPh7M0Y/BpwRY0NwGn/Kh4bksfqMQpx2L33Tr2I7Fb7q25zeT3xjheD8mv9G40+tZJr/Nda1uG/3G8+XtGP1OB3Eem99zKPsx+ufBsfqdF8hqO1YfPcJjHMfqYwqztG30G91Bz8foN56qcll9LKm07QWECEbOfux+Y/aKTvuy+0epttH3qSspl81vca+Bph6NG3ckzD679rqsfuPl57GNPmaZeRyW1ceSqm7ELqtPIU0bx+p33o5Ifsx+L5HzOGa+N15R+4K31SfU9bZl9YFxdO1Y/e5Rpr/Mfpd7asfsd94qjdsqMvudp+dm9DurMp6P0e+sGM25jX5nFjhIbFl9KUpaVp934XnFUQ0G771vzSNWHNEUFcvu06YwccIMEfvPkd5SPgNmP/Wd4SjilyQRNBYSTAzSmZ5utLIlzD6tReM/Q4k7RnX1gCXTzcbxZTm40SGXdZJxwwT7ao/INk5Gmet91noGUwA0+516xTxgC7PvS1Fnm2H2mRWmDoTV553YRn9nhtWXEejMKOWw+ix79bT+/QoD3S4JT5GvKnQ6RworSGKYH48VeZfmbMT+6NKZrkPO6D/uQLMQmzWBpnuU5HGeOjiGy2tY4sECWZAqKiyLK4a38AIoWMgr/BbiHvLsyhrzgdirLXuiIHXTawzokXZyyraomtiVxeJVKJl9HCKcxC5Hfhl+pj95M3kbfkcAVC6777xr1q/UB1/nOY7lx/vOu2jb8u/E7mX6v81VMXhuKk0o2ZJ4J/+bfyn1Tatb1qpPuvmiuKobAuvB1Ar2v+H6jLAO6s3rx4+/eRBT5//+D6T1ZUsNCmVuZHN0cmVhbQplbmRvYmoKMTgxIDAgb2JqCjw8Ci9MZW5ndGggMTkzNgovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnicpVpZb9w2EBawb0qf4vREA+ghyNEHmsObQBDA9tpxUhe+4xZNH4IUaRtYieMG6N/v8NiVVsuhjRaOltJQJIcfP34kR+GMS6u7f1rRvWx5974F3v3U/vpbx7vf282t689/vXvz9nO3eXT98Qq67flOy5mySkPHmXZKhtRIL0R3/Ue7fdZu7kEHmNWdvWsxD/+gE45J3WlrmXHY1lnfPuWcK85hh3Mxx2sPLzRxwH+j+2if5/fU8J5wOfXJNi3Hd9P7EFIZy4O2eG9zvkr22Ha43811b+G1nfN4yo/v7wy+xjpzOxbrk+iLxDIO82V+Xt5jnRLLSPTTumfd2ft29yyhJDoQY4yscswagbgGnEIDEIB63Mhm3rxs9pvZk2pxxxlo9Gxa/N4NxQxzQvO1VmfN8xvbdBwLY5uKbHP3p50ph0TkUJUoaE1IZKI4Dmo3DnZK5ymNBLHDYMSB2MngmzQA8d7l55wf37VpYIwa3o31bQ8DPa1f7A6kkDAi2CKfZ+LxTMacH+vLz5FgfiBheBlkSBfk+LQEwxjDFAitOpFhftsjah+ve+jmH9vjiO6nNk8ufNnjQOqubx1IpvFejKyXI2sogfMQ0JgKrxnG5f5sL9oP01GUcRQLw6uoDE1lGCrDUhmOyvBUBmoalQNkjiBzyN4D2X0g+w8kAEAiACQEQGIgEgY86DaSymNqveEu6HYadWWBWSSaRA5li0Bxt4EzyAwtmUE6EsZl2cCYd0UHEtSFIv3IqAwTeBMqV0bExQko6y3aTINYKtOPraMuGQPMO4sAEdZbtJoIUirTE/UPs5Ow3qJVknxCT5BfwtmXh1WCYsJNkRlZR+NBeZNoXSrTU/UbxSAKP2G9RatpypTK9ET9CjHmZgLAYLxFm2kyFor0ROVF3pXZTrVJTnNJSp0kpU6SUidJqZMqbwYlB2+CmEiL/eTM4U5HDaIivWYQu7UQFakEg8VkVqEcYVuWJGGQpKpKUlUlqaqSVFVJwq2yqjKvPA7jNEUYwhwOK/54Zvcj67ibwZp2cWXrmC8BEqWZcnYV5KXtP8IcBMFPKx2MoxqCUUyrHYyTetd96Is+rPfpstinWCfOmbBFglUEBuu4v6i7xlSsBRzE1OFi7wqIXZYRC/Via0wagfo/9nlkHb0f1goUZ9o6xbjQx57oYwm7SwK7UHeJsSs8Hr0/4nHZOvG71M+e6GcJv0sCP0I21EgJT6/efMhWsdgg4d/iMCs70MyuHFIkLpidRkoKPZzQLpoDPC8dNxeVo4+id82q6JAezkpi7ayU3EBJTZBGTzh6sdf8iP783RziGe4h3p+j7RX6d9Kc4tM+Ps8a1jxoNOa+fjwc8UpukSKqSBFVpIgqX+qkJtcrTa5XWhRrkjfDFRiI3NALuGbNXby+bL7B9B6m4ff75rvmqwoqmj7jkMuRJpHUJJKaRFKTy5Eh0TRFzpvRcbxIdVzX4z5NS8tshu1RZNEx8uoTpvsI4BGy6zk+v4j8S7PhpDmugGjIuWCKc8HcMBeWfoYV8v9NiOYOEiFQYQPJcBfvNvD6Fu33mq+b+0iVjeaLWs/IoTa22DNXHYLF0cxmmY3dsuj0HLtxge4fJd3BLs3Qthexf9G8qnlI0sfykoc2UQe68LcQRmKGKVRfNzgKiPJRDCb9HGlyFWkSKHJ0o1xacldqZdFNVaOI0I45E5YFpTXTA0UeoYuvUoyt5gw5ta0pOmNrzihjl6eiFbweRrwWQxqG+LzuFqkRtqi2jtfcMsEtGY+mq255dOsgzvR9dGuGU+kkDuJhnEq3me+OFHNXFHNXFfPRYOLM55CDhWG+J2eqrpD67XTRFVOVHvBMp2Pb1JWDQPaaI3SEyxUd8VVHjM87t4kjJg7eecURT64avrhqeFElN6BkxYjCqh+AGnBQnfGeXBR8cVHwurBjo4SJK6asXoSoKQUNdzPMu8KnsDT8gr/3ay6Tau+Lau9dDTrN83nIOubxRi4k6kHz+gn+bDY/4C+gh3u4eJ1Hf1/g3yyuShvYk5c1Xyvx0aLwA6ejo5wOj3I6PsrpACmnI6S8KLHA6fgopwOknEahFiamkYCigEGOEnOcC9aEwMhqOtAVp61e/aySSWBUPEFmDb5TGVmoBJ6hKGoAK6q25oNkzq37UDssQCVcDUU9A/BVHwwu01MPTnHWnsd9zlVcIMPO87Dul6BHVVSi/zS/Bc1vOgYLgua3oD8BiKKKgHA15EABg8Lw1batQIcUQZbVIQcUCSeWWqYBc/K3waecb23jvkJyrsMVPmvhPkOjACk7PIf88GzRrk1+3hvywpE3XvnzGah8r/NzSP2zSm/pkCfI4u4SFgHPGxYb4TXzsbvS6BzGzd8x56MrO83lipPj5uoHHjxlrNWfQVUqARlBw7bwSMS1G2yDH1WAaE7KMidz+LT4gamyefIp2jTuzGOc3mEffBrPanhqqPGWjs2CKvM2h39uGsmwSc9hswnS8evwVkJa7WTkzQhpP9A6/LeDmM/z+3vp2WyNaK3yO4HyIqWhPEBthBRNYVWmsKqekMLuP4fbVgdj2P2fRO09rB5JQA1Cd9z+C/f54HwNCmVuZHN0cmVhbQplbmRvYmoKMTgyIDAgb2JqCjw8Ci9MZW5ndGggNDk0OQovVHlwZSAvTWV0YWRhdGEKL1N1YnR5cGUgL1hNTAo+PgpzdHJlYW0NCjw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+PHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6cGRmYWlkPSJodHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvaWQvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDxwZGZhaWQ6Y29uZm9ybWFuY2U+QTwvcGRmYWlkOmNvbmZvcm1hbmNlPgogICAgICAgICA8cGRmYWlkOnBhcnQ+MjwvcGRmYWlkOnBhcnQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOnBkZj0iaHR0cDovL25zLmFkb2JlLmNvbS9wZGYvMS4zLyIgcmRmOmFib3V0PSIiPgogICAgICAgICA8cGRmOlBERlZlcnNpb24+MS43PC9wZGY6UERGVmVyc2lvbj4KICAgICAgICAgPHBkZjpQcm9kdWNlcj5wbXA8L3BkZjpQcm9kdWNlcj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDI2LTAxLTI2VDE3OjAxOjE3KzAxOjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDxkYzpmb3JtYXQ+YXBwbGljYXRpb24vcGRmPC9kYzpmb3JtYXQ+CiAgICAgICAgIDxkYzpjcmVhdG9yPgogICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgPHJkZjpsaT5wbXAgYnkgQXNzb2NpYXRpb24gQ0FSQSAoMC42LjYtSFVHKTwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwvZGM6Y3JlYXRvcj4KICAgICAgICAgPGRjOnRpdGxlPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij5DYXJ0ZSBkZSBtw6lkaWNhdGlvbjwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6dGl0bGU+CiAgICAgICAgIDxkYzpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+TWljaGHDq2wgQ2hyaXN0b3BoZXIgS2FyY2U8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOmRlc2NyaXB0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczpwZGZhRXh0ZW5zaW9uPSJodHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvZXh0ZW5zaW9uLyIKICAgICAgICAgICAgICAgICAgICAgICB4bWxuczpwZGZhUHJvcGVydHk9Imh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9wcm9wZXJ0eSMiCiAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM6cGRmYVNjaGVtYT0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL3NjaGVtYSMiCiAgICAgICAgICAgICAgICAgICAgICAgcmRmOmFib3V0PSIiPgogICAgICAgICA8cGRmYUV4dGVuc2lvbjpzY2hlbWFzPgogICAgICAgICAgICA8cmRmOkJhZz4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnNjaGVtYT5BZG9iZSBQREYgU2NoZW1hPC9wZGZhU2NoZW1hOnNjaGVtYT4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6bmFtZXNwYWNlVVJJPmh0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy88L3BkZmFTY2hlbWE6bmFtZXNwYWNlVVJJPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpwcmVmaXg+cGRmPC9wZGZhU2NoZW1hOnByZWZpeD4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6cHJvcGVydHk+CiAgICAgICAgICAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPlBERlZlcnNpb248L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5UZXh0PC9wZGZhUHJvcGVydHk6dmFsdWVUeXBlPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmNhdGVnb3J5PmludGVybmFsPC9wZGZhUHJvcGVydHk6Y2F0ZWdvcnk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+VGhlIFBERiBmaWxlIHZlcnNpb24uPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPktleXdvcmRzPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+VGV4dDwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5leHRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPktleXdvcmRzLjwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5Qcm9kdWNlcjwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPkFnZW50TmFtZTwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPlRoZSBuYW1lIG9mIHRoZSB0b29sIHRoYXQgY3JlYXRlZCB0aGUgUERGIGRvY3VtZW50LjwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICAgICAgICAgICA8L3BkZmFTY2hlbWE6cHJvcGVydHk+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6c2NoZW1hPlBERi9BIElEIFNjaGVtYTwvcGRmYVNjaGVtYTpzY2hlbWE+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOm5hbWVzcGFjZVVSST5odHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvaWQvPC9wZGZhU2NoZW1hOm5hbWVzcGFjZVVSST4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6cHJlZml4PnBkZmFpZDwvcGRmYVNjaGVtYTpwcmVmaXg+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5wYXJ0PC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+SW50ZWdlcjwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPlBhcnQgb2YgUERGL0Egc3RhbmRhcmQ8L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+Y29uZm9ybWFuY2U8L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5UZXh0PC9wZGZhUHJvcGVydHk6dmFsdWVUeXBlPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmNhdGVnb3J5PmludGVybmFsPC9wZGZhUHJvcGVydHk6Y2F0ZWdvcnk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+Q29uZm9ybWFuY2UgbGV2ZWwgb2YgUERGL0Egc3RhbmRhcmQ8L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgIDwvcmRmOlNlcT4KICAgICAgICAgICAgICAgICAgPC9wZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QmFnPgogICAgICAgICA8L3BkZmFFeHRlbnNpb246c2NoZW1hcz4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9InciPz4KDQplbmRzdHJlYW0KZW5kb2JqCjE4NiAwIG9iago8PAovTGVuZ3RoIDI0NzIKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL04gMwo+PgpzdHJlYW0NCnic7ZlnUFRZFoDve50TDd1Nk6HJSaKEBiTnJDmKCnQ3mRaaDCqKDI7ACCIiSRFEFHDA0SHIKCqiGBAFBVTUaWQQUMbBUURFZWn8Mbs1P7a2amv/bJ8f73117ql3zn11q95X9QCQISawElNgfQASuak8X2c7RnBIKAPzAGABCRABBaAjWClJnn5O/mA1BLXgb/F+DECC+30dwXruOVJM0Qcdw2MzLo/fTjRv/nv9vwSRnchlAwDRVjmOzUlhrfKuVY5hJ7IF+VkBZ6QmpQIAe68yjbc64CqzBRz5jTMFHP2Ni9dq/H3tV/kYAFhi9BrjTws4co0p3QJmxfASAZDuX61XYSXxVp8vLeil+G2GtRAV7IcRzeFyeBGpHDbj32zlP49/6oVKWX35//UG/+M+grPzjd5arp0JiF75V25bOQDM1wAgSv/KqRwBgLwHgM7ev3KRJwDoKgVA8hkrjZf+LYdcmx3gARnQgBSQB8pAA+gAQ2AKLIANcARuwAv4gxCwBbBADEgEPJABtoPdoAAUgVJwCFSDOtAImkEbOAu6wAVwBVwHt8E9MAomAB9Mg1dgAbwHyxAEYSASRIWkIAVIFdKGDCEmZAU5Qh6QLxQChUPREBdKg7ZDe6AiqAyqhuqhZugn6Dx0BboJDUOPoEloDvoT+gQjYCJMg+VgNVgPZsK2sDvsD2+Go+FkOBvOh/fDlXADfBruhK/At+FRmA+/ghcRAEFA0BGKCB0EE2GP8EKEIqIQPMRORCGiAtGAaEP0IAYQ9xF8xDziIxKNpCIZSB2kBdIFGYBkIZORO5HFyGrkKWQnsh95HzmJXEB+RZFQsihtlDnKFRWMikZloApQFagmVAfqGmoUNY16j0aj6Wh1tCnaBR2CjkPnoIvRR9Dt6MvoYfQUehGDwUhhtDGWGC9MBCYVU4CpwpzGXMKMYKYxH7AErALWEOuEDcVysXnYCmwLthc7gp3BLuNEcao4c5wXjo3LwpXgGnE9uLu4adwyXgyvjrfE++Pj8Lvxlfg2/DX8E/xbAoGgRDAj+BBiCbsIlYQzhBuEScJHIoWoRbQnhhHTiPuJJ4mXiY+Ib0kkkhrJhhRKSiXtJzWTrpKekT6IUEV0RVxF2CK5IjUinSIjIq/JOLIq2Za8hZxNriCfI98lz4viRNVE7UUjRHeK1oieFx0XXRSjihmIeYklihWLtYjdFJulYChqFEcKm5JPOU65SpmiIqjKVHsqi7qH2ki9Rp2moWnqNFdaHK2I9iNtiLYgThE3Eg8UzxSvEb8ozqcj6Gp0V3oCvYR+lj5G/yQhJ2ErwZHYJ9EmMSKxJCkjaSPJkSyUbJcclfwkxZBylIqXOiDVJfVUGimtJe0jnSF9VPqa9LwMTcZChiVTKHNW5rEsLKsl6yubI3tcdlB2UU5ezlkuSa5K7qrcvDxd3kY+Tr5cvld+ToGqYKUQq1CucEnhJUOcYctIYFQy+hkLirKKLoppivWKQ4rLSupKAUp5Su1KT5XxykzlKOVy5T7lBRUFFU+V7SqtKo9VcapM1RjVw6oDqktq6mpBanvVutRm1SXVXdWz1VvVn2iQNKw1kjUaNB5oojWZmvGaRzTvacFaxloxWjVad7VhbRPtWO0j2sPrUOvM1nHXNawb1yHq2Oqk67TqTOrSdT1083S7dF/rqeiF6h3QG9D7qm+sn6DfqD9hQDFwM8gz6DH401DLkGVYY/hgPWm90/rc9d3r3xhpG3GMjho9NKYaexrvNe4z/mJiasIzaTOZM1UxDTetNR1n0pjezGLmDTOUmZ1ZrtkFs4/mJuap5mfN/7DQsYi3aLGY3aC+gbOhccOUpZJlhGW9Jd+KYRVudcyKb61oHWHdYP3cRtmGbdNkM2OraRtne9r2tZ2+Hc+uw27J3tx+h/1lB4SDs0Ohw5AjxTHAsdrxmZOSU7RTq9OCs7FzjvNlF5SLu8sBl3FXOVeWa7Prgpup2w63fneiu597tftzDy0PnkePJ+zp5nnQ88lG1Y3cjV1ewMvV66DXU29172TvX3zQPt4+NT4vfA18t/sO+FH9tvq1+L33t/Mv8Z8I0AhIC+gLJAeGBTYHLgU5BJUF8YP1gncE3w6RDokN6Q7FhAaGNoUubnLcdGjTdJhxWEHY2Gb1zZmbb26R3pKw5eJW8taIrefCUeFB4S3hnyO8IhoiFiNdI2sjF1j2rMOsV2wbdjl7jmPJKePMRFlGlUXNRltGH4yei7GOqYiZj7WPrY59E+cSVxe3FO8VfzJ+JSEooT0RmxieeJ5L4cZz+7fJb8vcNpyknVSQxE82Tz6UvMBz5zWlQCmbU7pTaasf6cE0jbTv0ibTrdJr0j9kBGacyxTL5GYOZmll7cuayXbKPpGDzGHl9G1X3L57++QO2x31O6GdkTv7cpVz83OndznvOrUbvzt+9508/byyvHd7gvb05Mvl78qf+s75u9YCkQJewfhei7113yO/j/1+aN/6fVX7vhayC28V6RdVFH0uZhXf+sHgh8ofVvZH7R8qMSk5Woou5ZaOHbA+cKpMrCy7bOqg58HOckZ5Yfm7Q1sP3awwqqg7jD+cdphf6VHZXaVSVVr1uTqmerTGrqa9VrZ2X+3SEfaRkaM2R9vq5OqK6j4diz32sN65vrNBraHiOPp4+vEXjYGNAyeYJ5qbpJuKmr6c5J7kn/I91d9s2tzcIttS0gq3prXOnQ47fe9Hhx+723Ta6tvp7UVnwJm0My9/Cv9p7Kz72b5zzHNtP6v+XNtB7SjshDqzOhe6Yrr43SHdw+fdzvf1WPR0/KL7y8kLihdqLopfLOnF9+b3rlzKvrR4Oeny/JXoK1N9W/smrgZffdDv0z90zf3ajetO168O2A5cumF548JN85vnbzFvdd02ud05aDzYccf4TseQyVDnXdO73ffM7vUMbxjuHbEeuXLf4f71B64Pbo9uHB0eCxh7OB42zn/Ifjj7KOHRm8fpj5cndj1BPSl8Kvq04pnss4ZfNX9t55vwL046TA4+93s+McWaevVbym+fp/NfkF5UzCjMNM8azl6Yc5q793LTy+lXSa+W5wt+F/u99rXG65//sPljcCF4YfoN783Kn8Vvpd6efGf0rm/Re/HZ+8T3y0uFH6Q+nPrI/DjwKejTzHLGZ8znyi+aX3q+un99spK4siJ0AaELCF1A6AJCFxC6gNAFhC4gdAGhCwhdQOgCQhcQuoDQBf6PXWDtP85qIASX4+MA+OcA4HEHgKpqANSiACCHpXIyUwWr3G0M1rakLF5sdEzqOkZaCocRxeNwErIEa/8ANSYTGw0KZW5kc3RyZWFtCmVuZG9iagoyNTEgMCBvYmoKPDwKL0xlbmd0aCA0MTE1Ci9UeXBlIC9PYmpTdG0KL04gMjAwCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9GaXJzdCAxNzUzCj4+CnN0cmVhbQ0KeJztW/1vGze2/Vf4Y4OHjIbfnIfFAo4TN0G3bZBk3+6rYSwUW3W0dSRDll+b//6dczkSaX1Eo9TtboEFkmjuHfLw8vJe8nBCGtUqq5xRTumolVfGeBWUcalTURmvjUr4sV51yoRWK93iN0SltTLRWoUCJnad0laZFLzSTpnOopxXtm2N0gG/EeWistqhlaSsQWHd4TehMtq3Di1qZR3BDX4jZKust2jUKRta2AW8AAsN8KJDY8BLaMQALyX8Aq/zKNwq1xJU47cDGLqmA37ZS0tw5SzsQo8cAAGqnKM+4hf9sEk5H4DTKRcA6oAXW/wDvBhbcVWiALyuxXvgdQl6r3zrWEl5DbtcxG8CaFLesH6H32hQSHkLcA9nWw8Zfxyc4S1+k8M/ynsWBl6AMz3wAjrr8SegPx54MaAwikT4KQAvobEAvA7ORVd9h8FDkdDiJboSNJyBoQkG/Q6ogoFT6HqwMD6gigV4QBUHZ0ZW6ayKrNIGBZODh8AqAXZHVAkwOgIvws80ISbUA0RCfETgJYBF4HXwE1wTOC4Jr1oMHoY8tp1XiU20SaHLUaMyhjAi6lRik+gEXIfwsorQDuPPeKSfOjTpOq3wJ8JBqqMpMIYmBwxCB7wI/6OJGDF+HfAYnx3waFcHvITGO5oIp2uMTWoRZbqlsRh+DS8ljaHVLZrXiTFP+4GoaYhh9MMzyUphmM5xzH0xBOzwADM0ojnRRI1cSQExpplNgcmCBEiRWYARThE+YsikhODRSJjUaRYGcgd3aoxq1zJ1pPsIAA2/owg0ho6AKzTSpjOwTsOCjnHG15211NA5iCgN72NE+CrigcgYb4wNcego2KuRPl3AmDJkuohg17Ab8Y3CGIwuYfg1UqhLiRogc2w1kgh+REPa0jet5XxA52jBpCs1bUIy4QlDrB29yrzQbKPliGtH51nDtxwOy9KOTnfwv6ZvWqQintgGc0U7tuE9dWwjwFOaUive9myDuatlfCLblBGXXtBu9JI6zyfEhg4ciEBZhi0m6ugwTFl44mxnI3X0XeAb1sL8x/lNvIdI5jwKYLpeHOk0n+guJzr6xiF9NYcdcx1qIB5RnuXYK8x7kBO96WkRUgF+5RwqTmcUa1rmGDS6Y+/lDePAiSc78SY9RsucZRlGpHPsGwPZecMa9LXM6kgPPGEe0EgQeJgzOAPVJfgvj1PCVGJY1nWG8zbb6NCmQZrA645v6VcGroSi17DZIFPgf0uUyKfIchwni9EzTDPP8TWMFEx8XAlkTBAvhsHqA8ZCVgyoUEOzjYjpzLD3PlmWYxvJ8y3b6BCJf/rT6N2n24kavR5fT+7U6Jvp1Z06t1ju3qgLNTqd38+WSqs///lhSTX6dnI1HT+b/6LO26ZV/IvpvkmYYnznG4PfCxZdTFDfCNzozeRufr+4RDMuK07nsyXe3ynOHqJ5u1zcXy5ztTuoRu/G72HV296A14v57WSxnALC5wpnc9rn++p///79PyeXS4koKkotTNO5CAXMhUXAFFMEpGwRmFNF4pxTpMgVfS0x3orEeCiSDFglMkMq0XDJLyKjtxIdCUARPXlAEYUOFDGSFRQxkRwUUThCcUFLqlBEYQxFJFupRJKWSiR3qURSmEoMJBVFjOQWRUykGEXsyDTKWLQkHEXU5B1FFPpRREsWUkQhI0X05CRFDKQmRYxkKEVMJCpFFL5SgkJoSxE12UsRDUlMES25TBHJeyqR9KcSyYIqMZLnFDGR7hSxI+sp0dmS/BRRkwMV0ZAKFdGSERXRkRgV0ZMfFTGQJhUxki0VkUyoEkmIqixpSaGKqMmkimhIqIpoyauK6EiviujJsooYSLaKGMm5iphIvYooDKxka0siVkStYmUVcGJlFXBiZRVwYmUVcFJlFXBSPS1EMrciJhK4IpLyVLMGiU8lkv5UopC7IgrHK6Ij1SuiJ+MrYiDxK2Ik/ytiIg0sYkc2WGavlqSwiJrcsIiGFLGIJDuV6EgYi+iFNxY5CH0schQWWeQkZLLInXDKaipthVtWCi0cs1IIhakVwmRqhRPuWSm8cNBKEYSLVooonLRSJOGmlaITjlrN8pmrVgotnLVSZO5aKaxw2EqRuWyl8MJpK0UQblsponDcSpGE61aKTjhvtQC1wn0rhRYOXCkyF64UVjhxpcjcuFJ44ciVInPlShGFM1eKzJ0rhTDAem1shUtXCi2culIYodaVwgrDrhROiHal8MK3K0Wm3ZUiCvuuFElIeKXohItXy3am5JVCCzOvFEYIeqWwwtMrhRO6Xim8sHYqNujYdDZeTuezIepn48ufrhdgdVd4FvpmUgMfWGcahKTnns423nBbHRowxJZE7o+C4FvbxOjbPyqCtU1oW34P8m3XYKfILzCmbYzw6qCbEI+EsV2DWRNz3q+D2WHNGvkwTNtEqbJGwUZZtgjH2LICsVqscgXEu0YfCaJD44PxBYOoXxymrnONNUMDxEXdwFz5avKg/gBf7rVAMIcagDEMDyK0mDQQwYXG7DBgCEKJKme85IXhd9TGBuI55ApghljiU5NyHa8b1z8FGWB3BI4LMUd0MScQxlI1GCUQxT5AWcXWEV3aNzxrdx/hlLUdlmlnxSmubbowBMfqrvEPu2MB3WmxZjBK6BonVdYoro1NOg7FabhlA6Uf5yNQ+szpfKPZr7Vr187+zQGqwG/bxibZScQGe03tG2eOsGEr/ddW/eYApRPWxT5nsRI49KblfrxrUhoA41tJMFZZwxg8daz8JSjRNclzVdhCOTypft4YQR6QeJ3kf+0XRinD3w3vESejwIWpoHAysqIaCsK5KOgHIDnQBiPsIhApSIS0u1btb09fPQcxfVzQATjGNS1dozHRtOixztAP7dKPh7cPYlV+G+HfDkBcYn5rc3ZRR2zFm4Ac1QX1gVH2cTGPYrXbIfAfmH8DmC3O7zrTRFm5tlm/BJF7XMzhOwnWTWlrKyFG+cdCG7qx0ME2pmVabG8txKLwiIAD+I5NvYc1egpcbzc2C2JUfETAY3YNBuSn9YK7RdXFsPTIoIe3Iuv+efSPW8s9LuseE/Hw3mYNEhmfoEZhn2H6EBs4EvSYDY9JrvHZ9Vvbg2zcIUpwLOox2yh0d88GKNt2aG0+DvOIrZlNqWl3b6qyZQcX6KMwj9nu2ZDJ+D7LDs36x2EesYHTznH/xHlxaxOXTTs89x8FesxWSMcVzvZeKBt3aBk4FvWYHRYZZd5hBdM48cBD4w4tB0eCDoPJX24LzLrbR8BgJyPBtoHyKy3pUQ9PibssQURZu21JdvSh5e0IwH0QKUNsA+gvRkhWgq/9cht+Q4Ts2EOr8yNYVCoUz+pG74i6vPE7tCwfAbgXAnRnsD2HVuKBYHs3suvy/0HYRDgug39PhBwaBz9S/GqLjpxws1mHWNAjzeLcP3S5ghAXsL6IfoVGb304Me6BdIhxDEP+HP2U/wZY1bfY3rT7LDtEMIaiHf5e2tf3yTeJ8m57DnGK4XiHP772CFEjFruuC/tsOrT8HoN4puUUrxwaODNyUjc/WzmNu3l2QE5Posm7SX46OTl59sPZf50sph/nT18txzfTSzV6e/9+KaVZp1WjF7PL+dV0dq1Gr64ms+V0+enpSzV6Prm7nMyuxrMloe6Qnn59ivTd/K+zKSpNeOh0jxHrVuATavjOHLQNhd9+ultOPr6a/TiXw8q5u6hBgxbT2+V8IUeXRf83dd6qc6QkIiEp3s+4UA4KQ5qY8ADtBbdg5/kdNhZYEZmsWMv7Yhivc+/5Tca2zHYewwuq1/j8zkhJizp8IsKqTC7nPIk/tG225IKHBAXrgmf8zuvSuYbvHmoveAivt4PHos4zDI/3CLLNVrv1G2vd2m63ruqw2T7PZR3ipn+8EMe+m3/96vm341ueGa4G7c3kenq3XHxSX51czd9PnqjR94uryYIB8dUqIJ5wPG9vbyYfefy33RruamxE/m78cbJnhM9uxtd3PCYoBf82mV5/WMpWCZGYy5zMrm8m6qk2VLFQTpunIfTfGZ9yo4JU4HnZ2AU5pKxbZ7DtS3TN6IShu+SlgcZE3vboo3mpnhqtMUG5NsAl49uXufmQ+J9DyarR33uN5wcznvAevUUw/g/vyGCfyWPqYtHZ9GYiZ7RzGDJqJzy2HIdk5P/+8Kr3CVx/fzNefHlK9sc6H6Zk2GfFkJTcYdxGTq7Ojm7m5OoQaclJROY6jqHiQf1VKGMEqY35Pf9upsh2yqwStY//sEpqm3Iq8y81QWuVE59pySSkljWZuDnpsU/pa2NWO69rXvCcbf8O/+S0lvbjxvRQW81pIU8Sce8kkTYmCXkjUwRPKK5yn5PVdt954KyeB+Lafl4R6NM8BM4OnduR8SH8Xhm/I4ByyrtDGd9u5Lt3tukcxudfke8WzLOF1+p0X52LXqV7fzD6QLqf/nDaO+TZ/ObqV+R6tyPX4z4ThuT6pmUbib46rL2Z6KtT2zsT3a7X1SrFEPg5tXYklBxO16LJURzDCivhfeKdPrzP9SWFUleV5inbPnU2Y74/MP47xPymI3cFfPwDBvzqQP4q4PsT+T01nS8+gp3GerV58cvy67fL8XIi972K/vpOy72vzVgt5UfPvuX9oY+34+X0PXzTE+rx4qfJlVou7lea59O725vxp+fzy3fTJcpVrzLk9/fL2/vlK7mIxItGo6/fvf3H6+dnJ1qctMzvXy/mP6KPSq9O6EvIf3X35utn6tWL06C7EJ6aRj9ZAZ7OZ1dTOX07pFCOqB+nk8Xu4qtolAj66sNyefvfo9HPP//cXM5v5otmvrh+8qBT+RrVu8Vk8mY+R7fezG8mEuOrKwTfyNW4fLZYLlux7HeTX5bfTD4pXSuxu6xH5tXsZjqbvP0wliCfXt8vcnPTnybzezrwdjyD4xbzW0RTKfFidvXdnMOW/0X3CbMqjsknZ0pR3E4WD1Uns9l8mc8zrzQLuGx8iRKv0eJ0fL0YfywtnqHjdZN/nSF960afIW6mc1S6/fBJpBcz5vvo9MN4sVzjbHv1BfJdAgUxdS+ZP/rLmNPC2ZsX352+fEJz9Ormxjdy8XAzjDeBpv+XK61G5FrZVXVhQXw2/a2Gi88hvRszF4i1vg3yECsnqO6vf5j+6sTnMV9OxlcZUx/qybtn86tPddkH7evOHQR4k2vbndb73mo7wOrnGcjtBAq9Gwa49KXJQH4bqB0yqLsqnuv+0oxp9WELcri+Xpu7ASUXUI8ASdsgpj0Yo6X+jiA1X26+6e//bH4Q2wNi2s24+sIYMP29ItNfJxoQA6u4ewDkBsTAzor+s5afybQ9KOfWgbYr4027CrQBMbLq5o5xCoNmnZ1Vz01/ucr0t4xMf1PI9Nddhs0+pt01O5r+npbpr0V9HksmF6N3Oqq/32X6W1ymv6tl9BAjn2fgrTnvRLZbfRurb4/frz12Or+RwDZcoX/uH7+0Hb9qJ+1t57PB+lnw9XLWbYE/sPz/AQeI/AsNCmVuZHN0cmVhbQplbmRvYmoKMjUyIDAgb2JqCjw8Ci9MZW5ndGggODI5Ci9UeXBlIC9PYmpTdG0KL04gMzMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0ZpcnN0IDI3Ngo+PgpzdHJlYW0NCnicpVZhbxo5EP0r862Jrikee2zvnmgkAuROStU7Jekneh8IrNqtCItgSZR/32evadJku6HcB5hZ7Pf8xn6eRXNGijTn5DLSWlEuCEycGURNWjCqkeceUcjYMG5JmBEdiXeInqwJ8IycCs9gM8AaRS7gDJMPvPgtE4toKMe62gjlAW8ssTI5EkfMKiQeSRYgGbGWwJETG/ZREBsPtEClMKSJRuKhRwyxFaDwYeuhHKuxkzAHzF6FesDsLZYQMGeM1QXMmcNki4/Kc+r3e9cPq4J6V/V6O6vHi+IWOfWuR9T7F3vF2LFLpF/INNkgbmBML1AJnZ4Gjn+AmN4swHNZ3V+tpkvSaaSd/bJhV8/ZL2gSTiTk4USaaFKUGP/rJG5k6xZilHIgsLuUDqA5FCidwLNq/hCxKn+JDUYN6eu7D2e3oP2r6KTbtThDZz9KsC+cMawW0RnZ/yjOqH2La0FPwuWMVjLJWrKLLkW/t8XM83M7ANJoSvY2e9h7VN41TLrFNO5QZOhJr1QQDy7ipbWGZv/QsjrlP7K0WG8SGmFzCvwbO/HChhexke5dj29V0rgHfbtTxIeGImu5CfLUqLgDH8pN3Xx/3N7eFOty+YV6H6tlcXiRBzluEN8cOw6Rn1U+u6mdbejHFkqLpSZa4gspnqfd0xXS4i3d6eqOi4VGdiCwuz+dV1X9tD81c3GoG5oomnCerkLeuEIrlWJqPUpSTJuj0jxOrYjTOKeWxGn8lbfirnE/tpPEn9y53C4Wz792F2238Y/R/qIt7s5xuC6mdVktR9O6oKPRn1ppp1g7/O1g9n8ofqPUm2Ns07qab2fFmo5Wtys8X21vvhWzmvoycrkzLnM8PnNDbApyr/EHynhx515hxHq8G+UMnBoz7Sm8u62/Vg0X3TzQYLOpZmXUQcPB5YA+H6l37p07+fvTX5+Psdq82MzW5SpO6Fvrxs5qBS4wYpWQN9+jcY4sjyMhnruxVtBw7qMGNwyzoMy6AVSJhl7ngRmPc68RMTpWcR43nG7kGKtJVH1XFveral3T0X05r7++nxd35aw4iQ9vqVyWdTldnGxm00XxnqH6uqxxB/uyl87TcCDfAZHKnKcNCmVuZHN0cmVhbQplbmRvYmoKMjUzIDAgb2JqCjw8Ci9MZW5ndGggNDgxCi9Sb290IDEgMCBSCi9JbmZvIDI1MCAwIFIKL0lEIFs8MTQwRTJENjM2OTRCNTIxNUY3MDFBMjAzRTAwRThBODU+IDwxNDBFMkQ2MzY5NEI1MjE1RjcwMUEyMDNFMDBFOEE4NT5dCi9UeXBlIC9YUmVmCi9TaXplIDI1NAovSW5kZXggWzAgMjUzXQovVyBbMSAyIDFdCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJwV0+fbD1QYwPFzHmWvlMh8eGwZKSPZycrOHhEKGZnZm6xHNlkZSZERkZWZ9Mof4G9xu/j8Xnyuc537fnHenG9K6VVO1VJRelGQKaIMb/AmZSlHeSpQkUpUpgpVqUZ13qIGb/MONXmXWtTmPepQl3rUpwENKaYRjSmhCU1pRnNa0JJWtOZ92tCWdrTnAzrwIR/RkU50pgsf05VP6EZ3etCTXvSmD5/Sl8/oR38GMJBBfM5ghjCUYQxnBCP5glGMZgxjGcd4JjCRSUzmS6Ywla+YxnRm8DXfMJNZzOZb5jCXecznOxawkEUsZglL+Z5lLGcFK1nFatawlnWsZwMb2cRmtvADW9nGdnawk1J28SO72cNe9rGfAxzkEIf5iSM5PUu5ylki5aq3C3/uKMc4zolcfUPKxQXPU250s7D/mZOc4nQuWZZyy6spt6pAaWF/Jrd+WTh/4Sy/5j5tUh5UsTA7x2/8niffKNzPc4E/uMglLnOFP7nKNf7iOjf4m5vc4jZ3uMs/3OM+D3jIIx7zL0/4j6f8X5TC+6Gv0FfoK/QV+gp9hb5CX6Gv0FfoK/QV+gp9hb5CX6Gv0FfoK/QV+gp9hb5CX6Gv0FfoK/QV+gp9hb6iOM+8kvLy9uk1cNpEzA0KZW5kc3RyZWFtCmVuZG9iagpzdGFydHhyZWYKMzE3MDQKJSVFT0YK"
      }
    }
  ]
}

```
