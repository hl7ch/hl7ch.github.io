# Bundle: PMLC document with no treatments - CH EMED EPR v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: PMLC document with no treatments**

## Example Bundle: Bundle: PMLC document with no treatments



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DocumentUCSF1CARAPMP004PMLCEmpty",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-document-medicationcard"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:358909b2-6fa7-4aad-9242-d645e9d69b92"
  },
  "type" : "document",
  "timestamp" : "2026-01-22T14:48:55.602+01:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:358909b2-6fa7-4aad-9242-d645e9d69b92",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "CompositionPmlcUcsf1CARAPMP004Empty",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-composition-medicationcard"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Composition_CompositionPmlcUcsf1CARAPMP004Empty\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition CompositionPmlcUcsf1CARAPMP004Empty</b></p><a name=\"CompositionPmlcUcsf1CARAPMP004Empty\"> </a><a name=\"hcCompositionPmlcUcsf1CARAPMP004Empty\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-composition-medicationcard.html\">PMLC Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:358909b2-6fa7-4aad-9242-d645e9d69b92</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 736378000}\">Medication management plan (record artifact)</span></p><p><b>date</b>: 2026-01-22 14:48:55+0100</p><p><b>author</b>: <a href=\"Bundle-DocumentUCSF1CARAPMP004PMLCEmpty.html#urn-uuid-c35ef74f-fcf6-4a9c-9782-fdb79116f368\">Device: type = Pharmaceutical information system application software (physical object)</a></p><p><b>title</b>: Plan de médication</p><p><b>confidentiality</b>: normal</p><p><b>custodian</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:358909b2-6fa7-4aad-9242-d645e9d69b92"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medication management plan (record artifact)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:41dbd27e-84f6-4074-be17-82f76e7dfb23"
        },
        "date" : "2026-01-22T14:48:55.602+01:00",
        "author" : [
          {
            "reference" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368"
          }
        ],
        "title" : "Plan de médication",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "custodian" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        },
        "section" : [
          {
            "title" : "Medication List",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "10160-0",
                  "display" : "History of Medication use Narrative"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Ce plan de médication a été généré automatiquement par le service eMedication CARA le 14 décembre 2023 à 14:35:07 UTC. Tous les traitements actifs sont considérés.</div>"
            }
          },
          {
            "title" : "Original representation",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "55108-5",
                  "display" : "Clinical presentation Document"
                }
              ]
            },
            "text" : {
              "extension" : [
                {
                  "extension" : [
                    {
                      "url" : "htmlid",
                      "valueString" : "pmlc-pdf"
                    },
                    {
                      "url" : "data",
                      "valueUri" : "urn:uuid:6acacf40-7f4f-46ed-9852-8f3d49ca21ed"
                    }
                  ],
                  "url" : "http://hl7.org/fhir/StructureDefinition/textLink"
                }
              ],
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">The original representation as a <span id=\"pmlc-pdf\">PDF</span> file</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:6acacf40-7f4f-46ed-9852-8f3d49ca21ed"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:41dbd27e-84f6-4074-be17-82f76e7dfb23",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "PatientCARAPMP004",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientCARAPMP004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient PatientCARAPMP004</b></p><a name=\"PatientCARAPMP004\"> </a><a name=\"hcPatientCARAPMP004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-patient.html\">CH EMED EPR Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus 9}\">unbekannt</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Medical record number/100001368 (use: secondary, )</li><li>Medical record number/CARAPMP004 (use: secondary, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.1625.3.1.3.1",
            "value" : "7857bf60-93a1-409d-a647-ee260cec9c0e"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.177.2.2.1.1",
            "value" : "100001368"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "CARAPMP004"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Karce",
            "given" : ["Michaël Christopher"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1973-12-25",
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus",
              "code" : "9",
              "display" : "unbekannt"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368",
      "resource" : {
        "resourceType" : "Device",
        "id" : "DevicePmp",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-device"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_DevicePmp\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device DevicePmp</b></p><a name=\"DevicePmp\"> </a><a name=\"hcDevicePmp\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-device.html\">CH EMED EPR Device</a></p></div><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>PMP CARA v0.1</td><td>Model name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 701612004}\">Pharmaceutical information system application software (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>8153cba</td></tr></table><p><b>owner</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "deviceName" : [
          {
            "name" : "PMP CARA v0.1",
            "type" : "model-name"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "701612004",
              "display" : "Pharmaceutical information system application software (physical object)"
            }
          ]
        },
        "version" : [
          {
            "value" : "8153cba"
          }
        ],
        "owner" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "OrganizationCara",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationCara\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization OrganizationCara</b></p><a name=\"OrganizationCara\"> </a><a name=\"hcOrganizationCara\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001407428</p><p><b>name</b>: Association CARA</p><p><b>address</b>: Route de la Corniche 3a Épalinges Vaud 1066 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001407428"
          }
        ],
        "name" : "Association CARA",
        "address" : [
          {
            "line" : ["Route de la Corniche 3a"],
            "city" : "Épalinges",
            "state" : "Vaud",
            "postalCode" : "1066",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:6acacf40-7f4f-46ed-9852-8f3d49ca21ed",
      "resource" : {
        "resourceType" : "Binary",
        "id" : "original-representation-pdf",
        "contentType" : "application/pdf",
        "data" : "JVBERi0xLjYKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS43Ci9QYWdlcyAyIDAgUgovTWV0YWRhdGEgMTE1IDAgUgovTWFya0luZm8gMTE2IDAgUgovTGFuZyAoRlJFTkNIKQovVmlld2VyUHJlZmVyZW5jZXMgMTE3IDAgUgovT3V0cHV0SW50ZW50cyBbMTE4IDAgUl0KL1N0cnVjdFRyZWVSb290IDEyMCAwIFIKPj4KZW5kb2JqCjg5IDAgb2JqCjw8Ci9MZW5ndGggMzQ3MQovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoMSA0NDEyCj4+CnN0cmVhbQ0KeJxtWAlYU1cWvvctCSJEMBBAFkkCYREEsxYrIFgXBEUEEUXQoAFUVBSVfZOiiFAVWUrBBbQuiOICBVTEtWhHxXGrtn6109pWW+ZzptUORfKY816CdPpNkvO9d++79yz/We55QRghZIIKEIlQkjYtFUYWQGXsbFJKZuJjbf/XcF+JkOBusk67wrUi8zOExqyAOXUyTNitFCbDuB7GLslrNmacLDP5FsaXYHw0Zd1yLcLzrIAlrEHNa7QZqWg7vo6QJcwh59QNutRkXlkxjJUw5iOM8NAQGoMIdBshWk4XglZ8hIIsxZZCsaWYlr+tCyNvDyrowoF8oL9RLxEihuoQol7AWj6reRApxQosJUkej4/FpEyGY/91l5z3BLtcDa3njzVjqokxiXwzXM+sYLngenKBuUSkLyY8ZGEgf/1QH32PrkbjgZMNj5JK3GSESqlRuyjklA1fJpNK+DzC2kqkkLtQ3TvzmEsP2oqLy1auxJt+fIIn+La69NZ07iir/upyJdjStOjCsZBZ2OzU7z09T9oOaVI/jIlhLt678dMesBYjHcj6B8gSIzTdGSD4f1LUGo1YIyZ5FPEj08ucAkGF/d9gB81l1ytV3bt3f9L3ZelgnIKJdSYWrChjrlrh97DdwLXrj44eUqelRUczV+/e/yl8DnOAscxYy8oMBFwbACszI1KkBtDCUoyTV3Vjy+6SMqL2jX4s4f0d406I9c/oQv2cQkKuLx18QzQa9/OaYP94436hSGSjVmuwGEuFcBUQfMBeJnPj8fDpG03Ysq+LsjAbpxxHeGDEvGpuHSsWOKm8xuqf5nSS1pbUGMry7Su6cNBHmBSpWq0ibw7kkweWVE8OTJ4/fjCMbBWU5zrFgY85vUtA7hhka5AsltuIRNZWPFaeRq5WKWVSMYnXrQcriBW167SrH9/HZnd+m9TWUVXJLNARIfp2ulA98eDqC08d9YeJkJqa7akZ+n6W98ShPsqbmou8kT94QiJTKdUaKY8nZe9cXDUcbwmP76ZWK+Qgkk/yONdo+GAkdwOGswP4kfvjFlCYF3kmr6wFj8KSF8JV8elZ9me8n1043iOcPdrD3XG8QDxV76Odo507N9HCvid9m8zVy3ROmIWzRZ7u6JbOixS51Dl24YKFjnuKD2wLjmW2ymWuLvxUExPsHhrv6bF1Ti5Fujg6xCAuhqYN9ZEvQXcHhHQQLDaEmNVaw6lqiCRWLWsL/DBpl2d9FtN56U7IrFcnj103Pc1Lid3T4G5qmpWWNonp+ur6zePNB5sq7bQr27sn6XyZN4jFZvrQL9Qx+hayB3QM2Bh5K8BooYLNMqmSRctNrgkgOKT4AjZ08e69LQEB35zIrnOm+QL+/NY3AiHdbE2HNAZf0op97PLXZ830mekWb9316ReXutuT4z0i3PHBt8IZqR6KNUujdxxUV9VPzd0xy/fc/ejsHKMufZQb2GrHZkwQj2/IDxujp7jsYd3jKtZwDsOIRxZv1e7zKg35x4Gbz2bOxETD7ee2+lFEDFWYubUd/0cSXvzRssjAooxnX/Q07j9950KyrnRWzofHAVcJ1BRrsBtwDTL6nccnIcZVSmDN3mLOeJwfeSStssp0dH5b3tizUTt1os1nsXNr6ChbAVmYtqii1Hm+XJ9GFC/yP7Jw/1p9I32LyZPr5Jw9YAV+AzIMNY4v1QhBAH4jaZUk3j97j77V3Mysffs5NZn188haFMSm6xvmGcihbw0oYdKgLy+UmsN6SSscjlhWX43CCtRUsDbYvAtg6cgSojLHLix64wn7zWcPWwmbTM1pMmRPYr9jZEPytt3W+We4p80Om4msLGVo+OcH9IfIyKUl/OkRDhsWv9iSWFEaqAP7uIdXD+gbjLpQItDFUCPYsjCiw19wxGGbWw+bCk05uX9BkojXN5KRPhs/YIX9FUoWP4h9Sg5yLLh4sCL4hkhQGyKUbzEcimyUqNWUfN7s0Mel157T02f0t9/75lz/tgj1HI+CrKRcH5/3ieNbmBcJ2oS+v/XW7Wv8ugc7TZ/Y0BVTWTcjZPb3cMbcZhZSkyD2JEjN5YGbFOzgEXzOvL9ayBYCwNYoXBNAAtiEJ5sJFEUpfc7+QY+iaBPqCM+EpEIa0/e2+Pt/K1tePsnZF9IiZ5aLn7t1vFVyPC22t2d++5Xm2fraOgeMHxsUYLE0uuvTW10XO8kvIyLU1XVBuTvCZHk1Nf6QIRzuxCvQka2QMmOUDqvHN4YAccfTd0bOYqu1rY08cx7o0WRvQgUXRHkpyCZz3clU/S0yQDpd4ujncExZnCLgagwNNeYRFYomsCizELtpRCKFs0rpJmO/bL0cqTZgsg33FZE7+n8+edtjj3jHJixVKA8VBk794MX90z2ig6KspJxiT3f3jwqmBs3E/o0tm/Lei5l3McDTQzHBzX31zN178wvswmeEz/L0s7HxdvfwSOX0iBvqIwpoL8h/YyUSSjUKME3Bl46UZCxcoB2Tlzsuf2WGz41xN3LNvL3d/IXLrRKjNKHEzqJffy3SZ0+RenkJim1ZntFD/6RmQ4o5Q/00FhJjYbO2grgZqXFwS/RxEUqP4htDNNF6OHoFVCcboSL5+2KiXJ8dE3Bk4YE1RPzgCQhfkw/m23P6gxVUAsgaw+UwqRA6ETY2rHcwlaCvffjZeR0JLqPG2Uy0xQXUZDb19VNFfsFuKpVPrBdxhY35RRDzCdAzWCI34ALBZsFnuxSCU1utJiHaKGNqC0jAhHja3jt3LvPdrbY77mGqeT9H1CyTBSlchOkpYdk+vnPec0ynq39/OoRe/esPTHyf8ccPi0vKB16u8izc23QktK5epVKd6H0UV1fP6q9CiPwczmBTwIoPXYmQ1rgqSPJzp8FyJ5x0l6mR4szDr2tra6mJz1p/eMviO/QabF4A+roZ9oCSAYSGU/V/TlU2aQRsAvPJNsfBJbaaktly3QrfmZCa6txVaxpdm9T957M6khSSdWdL97RNrK3Nj6uY4j59qpP3YoUiMywhMz3dtensov3JKxOmZmxdGPfxLMP56At4aUG+F4vWiEwXYyXiiwzpyvZ5XFQb1kg1hLq9LVOXflxyZjIeff7848stuKhiiv8PtfnLbyoOOZ3KLt9fXZjjRNpXlMWlZK0TnGvrOFB72YYatzc7J0Gb4hX7zHdjeVVeajbbGIPfzAEHGYed0FAVxdB4kQq+oU2FLCXnBrQG6NPsSUVPxwWHuw6THRkHfD/ZxBwHMpdxYBn52WDYR+QMSbBEf4eQyELBNrZvyTD0YobY/ZMFEqhMYr6YNFYk8sa0Xxo6f/Q6OH7fpsOtpRsPpp+6Qood9UUb5LsiO767krTu00MTNqw735y1S0f8XssEefo+bO0AvdNARhrg52Q8/98dtIZ0J8h37jM2Q0bHwpAQFXQlRkViSVf1Zelhuw0Rh35UTmlfn9asDZ72C5NZsiGuIio9NW5u+BKrrK92/fpLn35niUtEDPOU+X3x0mVNqR8XFO7CnUWfJrVuSNvmOaGe8+cDwPEM2AzBpZWy0USy/bGh+TL88NkLVoGentrt18sHBxzJyw6ptRMmhEkk/uNU4YlXlixpufa6obai6JxGs1qpXKlaBa8QcKqqwc4kugpqiyuaZMis4fCgDFVBo2KNdxEORxFb6CSGssPOEJe6X5zYg9duYp7/8fDlZy2xKzB1ZmtVUX5x9XbH+uOVH1a219JV7XVl10SU+JO1d19/caa6142S1SSdvqGv3lmcsGZrflL6jsPVqfnNe9blsjEzA3QKAeylyJftd7ggfdeAsfqBufw/OX6scFgxticlt0w7lpS+aHFCcPCryqLO5ZIAz6nh885pP+mW7bPdHLvvWWTpmsqOvJSl848SzbpEpaJj/cf5ebvSHlQkfXM3Ki88YnbpDu8FS7CYiM2seNyVtVWRDDpFgBN+gho20rMA4Z88rnrYAVGTe3sHq3p7Dbm3jIkhF0J7AvUiCFlaCKWEpQVyJRfqL/aefIS9sCM0Q6Rew2QzX2I3XIM3EolP2Zrhx8QQvrBvNELT4LWIcFOMhY10DxGclHzyEfOA+Z6JwXri5hUcU8k8YVYyZfpPnsK+MjgfXo70SMRL/QcNRDf0SM70twjeK7n+kX7Ok7GcQX93nIhG5rPfzXugf3P6t1CniRL6OaI5fnASEEVMaTypf0L3MD9b4fGsj7ZTV4kndPYIHlIg4on0hPTv0hYpnd0BH5YXUFQ2kdBvv3TMlDeINGERQk/679mw169TTf45cGrwe9EykxjgyQPCyIAh4gcwc9E00ZmBUwPRomXkC/QQ/fnjyUPoNuEHb0fRQ3V0D1rP80M6OhoF8ppQIIwDqTQ0kQIg4TrdSBLcg8QswRoJOwaC50O3CXYMrIBfHMxFw30qXBcBqeD5a7j6AplzPNNQGtADIDXQDNgTAfuXEU1DfoTfUNmwPJhrAdpu1NfLSBlAz8FAeI3BHwOQ8OZOpEAiugOVQI5bARUAwRoantGQAfQF6HFdgHYBKkqgMoRMYJ1JMhDUhVFQE0ZVAt1AyBTKv+ldhEbD+tHAzwyemcH5aw4mmYM882tAgwgJgI8gCghkCz4EOsr+z8Gh74nnoyg4s3lGXwx/KER04KHiU1Q5+i8KodpLDQplbmRzdHJlYW0KZW5kb2JqCjkwIDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/nzzwAwBvFzjBDQplbmRzdHJlYW0KZW5kb2JqCjkxIDAgb2JqCjw8Ci9MZW5ndGggMTE1Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJztjtkOglAMRI+oqCCgIvvuCv//g9yAEgIvhEB44SRNp007GWCDBGyp2f36XpTMnwNdjqJOKKjVdEaruo7BhSs3oU3uWNg4zY+Lh09ASERMQkrW8x3LY9DVk9dAv/f4KCsT8eltvgukmI+8pYsSpOMDXg0KZW5kc3RyZWFtCmVuZG9iago5MiAwIG9iago8PAovTGVuZ3RoIDM2MgovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnicXZJNboMwEIX3PoWX7SICDAEqIaRAiMSiPyrtAQgMEVIxyJAFt68zj6RSLaGn+TzPM8bj5OWx1P0inQ8zNhUtsut1a2ger6YheaZLr4WnZNs3yxYJlmaoJ+FYd7XOCw2l7kaRJNL5tJvzYlb5dGjHMz0L5920ZHp9kU/feWXj6jpNPzSQXqQr0lS21Al70ms9vdUDSYd9u7K1Cf2y7qyJUzjja51IKlg89NOMLc1T3ZCp9YVE4tqVyuRkVypIt//2hXLhO3d/Bs8aHqLclKEChAQeYAAICXzAGBASRIA5ICTIAAtASHBk6PkcbbJXgPBtEqK6V9wbZIjqCj6FlsIYMALMAHPAI0c+rhmhkB8CniC4e7gdBvEPDCOcGeGaCoViNLiJOt2gF3Cfm7jFC8M92zdxC/4hXoZMiJsFDHMuu4l7iPkZ78/FT3qbvcfANFdj7KzwhPKQ3Maj1/QY4mmcbi7+fgElBcCrDQplbmRzdHJlYW0KZW5kb2JqCjk3IDAgb2JqCjw8Ci9MZW5ndGggMjk0MwovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoMSAzODI4Cj4+CnN0cmVhbQ0KeJxlVwlYVNUXv/e+ZVAQHGYBZB0GBtywZljCBYU+dyUhBaRUNBQolElMBRIYAUWUtBJsFCgFFAkVEFDLNBfABdKs7O9npqTWlyvZIh/MXP7nvRnDauadd9+5796z3XN+9z6EEUI2KBcxCCUtTtcDNxRoi9CblJqxbPYLLi3wvB0hu4+Sly5O1GzIOIrQkFHQF5wMHS5FDpXAJwLvk7x81dr6yKFJwBcC/0lq2huLEQbByN4fblXLF6/Vo424CfgO4L30K5fqk/ktBcA/AF6CMML9/cgBEdSJEKflDGCVBKFwqUoqU0lVnLZv1yym06TjDL05QBfZXxHMQf0PSCjXIXgQjtWYhNKUPXgX19Hrxd0S3pchxDqArMEILVWoglRSLshXJ2UdTMU4iZ7Gs/cajUZ2/O3au33OSBgP9rN2XClSW8aHkZDgYLiCAjVqb17iFxys0yoVcl7CixdrZ3pN937VHP+pXpNeKcxILxlyVP709Hd3Z87wfS85vdDDaMx5p2lbmCf8C2NW5a57W7r/3Plj0Xui/LPnLdwxBfRF9j9gXUAfxChczqu9NX4hSpVW1KcO0mn/q1ihVLIuPT9f7Xf+zAc7FO5q2LdsyfbKgrw1H9o1g+5v7+/YVlGPC85cPfWFtHdDfrqhzLDy7bzMNPsDp1vrN+73YKWNgp/RoNcd4uIh6EUWvcoBfWqZSqFiBJ1K1p0+vd/6xKvF/YPV71dVb5mePbF+DKMy57m+c3Bzhx5fvNmP6ioVySmHjAVVASHkLyMNj09rAx0pYiwNQk6F80TCE4U60DEk2DEE1oG1SzWOmj//+NhJ44+tN9sylezjakoXfk63n9mCVR+X4JnHjQhyIQHsdIT4OCNfkDLUaqlO6yjjhWhpggLBSEeJaLVCLngQzDrSp39Wt4+sCz66q5b1P70q+3hyz437T86W5a0vLc2NzJtDbtASmrl5l2s99sK28ctXX916w0yrDtVeatix8/A0A+hlIQejwXaJaD2jxjqsZjAsOaNiNBqcuqeNTLxGgs/spielY+SHiUOzfQAuo4lCduIyZt5LmwJpEP5anQtxSO5/wGWAD66QU14yJ55Ve/uQoEBHH52WdZJowHQklTsqGS/sX1IWS1svX6Ud1VU48GoXDpja/OK1knvUlNW1CftGtpxoxNNvdeGIuvoD47PW029obx01bwV7a8DepWDvICQTVpSwaqgZL8QMRSp4gKhwSw/Qix3m3/AVvAwXfEm7aDf9DY8t/yWXXLpJTxzkDNRImzGPZX0NRVSsBZDJUpBpK9aCVGUllvbVsqNNHzBa01dlZZyhjI7fSRWW8dxEy/hwqVqqk0LQoCZx0smTZF+XuYbUPDR3EjfzHc5gDiOnzWWm26TGMo8nMM/dOg8rlU5QeFgHTGBwCAQdpDBKJY6u7cNr5L487+bGY/2fdRzrMlJOt2+gW+cTjqkzzeUMpjHjNnq4LoqzZ77uzWHqIkunzS/WmiYxX2LnmaVWG71Al/0zXZogMFSNRek/kl67up/N9sSGqTHFcYa+aa2xTFlvDlsfkW+JMXtP9E+MMSSgCkSotKxkqCXI7L3V10rpkpMk6iFmv6RHaQHO++QT5lrB2bfM1znDjx1Yav62GCHreiWDrCFIabEExAjlLcQLklkUB4EjOx5h5shuvO0H+gGO3ldOx+HOHdVkuvkIZ/juRPlVN/NuMh1XZhnMPcXimi2AeumBXNMJFrIqL+bvsvbTaPwCiJ9QMj4qrdKSeELNOMHferE99BK9bzZHH/O6fPjY+YmhoRUJaSUJ3togrMCkm+qOex7cub9xcviEtqiKKcNnumlGClCDl/nmrMnJmhzj5qZRurwQ5BGQ+Urz2Q8bVPql+rTwee7uo2TDPaUveo1YKdo4CHyfDb7bWTBbXG9AWczNNp9qM586jzc4+ynko+Q434L1Jq8J2WFhhToGEF2IXSz4mM5GIh/By8neAgaEhDwDSkfwTSEVkCBEIUKEn5rnZRIBrkV8EMAcV1RW3fjrd/3ajBW2xwNwfsdXI8a5eXpPUSe+xvOTj5hasyMipiyKS5w1e768rrSmiWfH5a+Mjpdin88baMCcKInexiZF/24SGcFiF+fEqLiE0aPLXxV9A9uYC2DbMMEyIh3qqHs+1LASIU72hAy//bj71t7rbsfsV6ZszS3clGBwaLFPa5BjTyzDUuxZt8M+/s0TXf+7nJxql7xzLvgcA3Ifwz7nIuDg4gASpBace6ZA5wdJDCuJ5QMYzrwMNcFqqzM7T7W3Z1VpCWliGLPP2o3GoqIdhRm2E2a4JcdjOXbGrtg1fkkGPtUnm5fmSjxun/325vfnzg/E2hn8kQkehVs9ICqrZkepwk/0TYLlO7e/U+xSsZjWdPf1/fr40WcO2zbmGXn89LMLC6eN7kfYAw/DdtiD3qJdzkWflh8yivJjaCzzmJ0J++0YkD+wDf3Lv0DIDx0P68rLnoN64tNwxaPZMStxw0aia1zT/vn5zvT9AYTlyaf8T2N2ryvKXr01dzeN3Zw7bGZURfnB5BRsA956YmnKYvm8WWxwran1zh2mrfX2uVs/nr4prN97CDGPIM5wGgi37LkCCIkqRUiTC2g0YWzluvp9zUlrc4xNTSyDGcObbxxpM48hBz9cX19iXs910Gz/+eES8G8TCJ0gnk+Es4xCHSQDMXhCU1MT11FXR1f0tbFjBb1FcAuznmOEEWHwvjcQOuAdnKd4NazBCMs7KGWdB1HoRPOcdP+1UnzA4YcZppawhBlbmpq11Y156eO3q0oaY/Sr8+CWvoGkm4uZVxelK5STJnukxy95a3lC40XBhfK1h3abi4W23qKbeWTJ5wHd/1aKI5oEXQzBTFhlRmN1c2LW+tK/FcjGTtHoF7S0C8J3ZTZa8ipGOH+AXFvkJOzr5NlaOzLPrS/r3vvo4ZPfn/Tc+6KgvKJ4c8mezcSD3qH3sAqqxBk708e069bFSz9c/f4yyMynsSBztqVGRJl+aquRAxH7l4L29t4YjgXzD2KOZV+oMJxr+yKzYPvWQuOGLOJN79K7xyWVdD7Hv5rmyk6JkiUuoH/QGz+d7rz73YVWS3xIIfjh8lx8GNAUIuhyUvwzOqyHjzo+wtfHO0y/mgSaO5iw0OzJATNCfActCdb6Da4efErEkFCo9RaoiVHPnQmfgbgVwYN1/0Rw4WJafrl84brqY6dtuZty4pas2jRDGTHjmwuHv3Hb45C3InNVxIJ1P70YOg6PNO4tKPaMjZo7d9KcYZ7+7kM0K+Zs35W9WT5t9oyZIVOdPKaqh6cJdnj2d5MR3CikgP1fMCNICkfSEJ1Cp1BbAJaMiFuYmrouP2jtuXO6id5TbJyzMsmVvCdP8szzIifaCzIKwJf7kOIuggyLEJ3UglIWyFLDtsQEW9Jmaeb6UiFWmCPH9AsaOsjX5ug96Y0VJN10YOEqBTc3Ac77/RZM4u7wGiF3oK40WP9cf9bf/X6oR4znNLYBd3N3ECfuN0EyHe6mLQuvXeLa6T2AXDEfR7NnSDyXNVCnaiASX3m3mss6Cj/xWwPhuVky97hfFjmM/xMxNkImo2s9V1yE9rre5mHfXtNtZYJNHLA8yMTiALhLwmgkelnZ2Le3N1OZYO0f+PnzCHWSUDADiE1HZUBJQJFA0UApQAlcDGK5dpQMVAPPIvG10D7jLe0CoEEwPhYOsLHQxojPlvY93I42ARXBvELgC639+UTgEQoF/Z7AF1jnxEL/NKDRVjtHWWkW0LtA8N2G4dsPnwPLYS8n+UCXAS8CgQTcgKAx3eDR60AfAd2BfX88EGzjvBfQcYiMHAi+NyUgywZk2gDg2fyB0CA4dQ+C/kEwZ/BLQHVIOFYiW5BrC2PsYL4d9NvNAVolfJ+KUfXH0WguSoDo/zPGLMJHcX9BPVuM/g/ylzu7DQplbmRzdHJlYW0KZW5kb2JqCjk4IDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/Hw38AwCqZhHuDQplbmRzdHJlYW0KZW5kb2JqCjk5IDAgb2JqCjw8Ci9MZW5ndGggMTA0Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJyVjtkOglAMRA+CIAgosiio7Oj//6HDfTJISJzkdJpJmxaMLLa0EzYOe7krPHFYzPgi4Ej4lUUi5qR6FgkXk6arNzKRU3CV3yipTHrnwZOaRn1LR8+w+emvRlOnP7dmvXh/AH21Aw0NCmVuZHN0cmVhbQplbmRvYmoKMTAwIDAgb2JqCjw8Ci9MZW5ndGggMzc0Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkt2KwjAQhe/zFLl0L6SaplVBCloVvNgf1t0HqM1UCts0pPXCt984J7qwhXLI15zJmWaS8rg72naUyYfv6xONsmmt8TT0V1+TPNOltWKupGnrMa4ES91VTiTBfboNI3VH2/RivZbJZ/g4jP4mJxvTn+lFJO/ekG/tRU6+y1NYn67O/VBHdpQzURTSUCNCpdfKvVUdyYR906MJG9rxNg0m3sI7vm6OpIJljjx1b2hwVU2+shcS61l4Crk+hKcQZM2/70Ip+M7NnyENhqeoWXGHc8WrKOoAqAFzlnQOuASEpBngBhCSLgBLQEi6YqhQM4pGTYUTFGrqFHAPCNFbhunskYXhDhCtRMnQUUjGEKUzBbh6ZGGYM9QxCyRHJA2fRqQckTT60+goR5v6gGI4PS8ZZjg9g32B0xcIH2WPH7KAL8oebS53vIqy1YD4E1E2S77wx8Xy5d+n9Dla9dX7MFU8yzxO90FqLT3H3fXu7uL3FxQQyHANCmVuZHN0cmVhbQplbmRvYmoKMTA1IDAgb2JqCjw8Ci9MZW5ndGggMTIwNAovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoMSAxNTIwCj4+CnN0cmVhbQ0KeJxtVGtMFFcUPnfmzixY2Acwu4EUZFhYfFC1+xqRrQXUQLWgXbFAjALhWVxwKxXEomLUEozP9KGRArY/iFWrxFZjakPbNG3a6lbSl0ES+0NbIWofibWWx6Xn7q72ESf7zb3nzJnv++69ZxYIAERAO4gAtRVNfoyMiD08W+trrdlp6VmF89cAaFVddUWVraP1PM7vY85dh4n43YZOAGkexql1DS9tWjBCf8e4COP5vvWVFQCJ8zHmfJ6Gik1+aCDvY/wFxsn+DdX+OnnPLoxHMNYBATI1BQYQIIA5u7QdXekAckyqKVY1qZJ9vOtZMTDhkLaPbUNcpKOAtVzfiLWPQSzWxsmyFWtNqp1KTpWPbsm45ede9jYbEloniYldYWPsMsncvFP8tPPbFoavjl69xrRWQH0Lri2AXGFV1aUqosSGWCY9R7vHK2n3jRvANT1Tt2k7LYRUcAAsSbG5nG5Nczlt1hRZlxaj2s2KKc7ssGsKukmxpVtlOVYn62RZCWbdbhfp7O4fHhxdWlT4TCQb1siRwLWZ85KTnEvd9dXT5KwzgwcqZ8ycnZeVq7kXxp3oOnaKUq2+Ns+rJzlffcCaVy+RD0dH11XXrxMiBckYk+8pWJaaui2Pr2EFetPQWwJ3BiYjOOxmi2Tj3oLybk3SC4L3HrtL9Pc/GktmP0WVlzT41jeu8EWTBMOOwTiSRmQSRWZ//I5+ZeXZcxcuVFdFbzhRhuvm3E8gdyxnzwmzCWpYJsakpAV1dKRlo29pWSyJbGJH77IxMu3u6D32W0Tjmsp1IrnZ81ZOtoVdJSpRUCaZXWQ/RPTv2LG7Dbh/K27wKekSKKEzsLocuLsOu0UJrkBxKGSIjfT0vNnrLZ8xKz/re7FtYqfYNvDiq/uMZyMz81cNoM/9SHQMOUL9o6gugkzkGLtJ4tlN6dLly6xx/HO6IKjXASD30OUwK6TntKWrSYLicLv5voUGJZjn8g8mnEsSSZQgS9TZ5Ws7lCBrR1p6+tio1+tt5PdV64TFkx+K+cXrM6JK1yht/ubmrY1Xvpx8Tijbv693z+RpPp4K6dMq1E94hP4j9TJPtpw8z0bKK2q2/E/iu0sh+tPhdQkMeeP/xSsir+Z+uJsPWSkV6Qw1uSTXrS5yvbBRiJ28I3pKW+ZELixYbPA/OTfDcMtwHDnz8fynI2cGP33KW1sz8ybA1k+fI6TbbMGjMlt0D9rNYuY/Op1NXf/xTvqfSm17s6+4bvmW0sdXFv86/MmtxL+i1tZUVRWs3vaZJyuPeLrf2/t6WkG2J9v5lGJMSoye2b6269039iXk5jg8c7WYBM1ma0Ef8VO/CAel+bxHqvkX5uJtojmwOayhD084WNPR9krnoZL+QMDzdFK2MaWjU9g6wNjA5NfLl+n5/iCKXj5Q2NhdZvD8AWIE8Gvo/jfxfBz2R9wZ75u4bi6PKMFaGXuKBAvwrlvICmGR+cx439hmc3k4/8+llwECQib+Kz0PnfQ6WGgTeBArOITjYMVn+3WJ0IHPOkQ+NkE+5uPD72eEsQlxFAU9iMOICTzPbIQPcRtAXIzAPE3m/RN0oSdeKIJydPtfTxTIeTK1q5/uhb8BpvmHqA0KZW5kc3RyZWFtCmVuZG9iagoxMDYgMCBvYmoKPDwKL0xlbmd0aCAxMQovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic+/8fDgBByQr2DQplbmRzdHJlYW0KZW5kb2JqCjEwNyAwIG9iago8PAovTGVuZ3RoIDQzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxjYAADRgbaAiYozYxTBQsQswIxGwM7mM8BFedk4IKyuBl4GHgBB6cAXA0KZW5kc3RyZWFtCmVuZG9iagoxMDggMCBvYmoKPDwKL0xlbmd0aCAyODMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nF2Ry2rFIBCG9z6Fy9PFwdxPAyFQcihk0QtN+wCJToLQqBizyNvXOGkKFeRnPudXZ4Y17b1V0lH2bjXvwNFRKmFh0avlQAeYpCJxQoXk7ohIED73hjDv7rbFwdyqUZOqouzDHy7ObvTyJPQAD4S9WQFWqolevprOx91qzDfMoByNSF1TASPxN7305rWfgbLgu7bCJ0i3Xb0ppISMz80ATdAS43+4FrCYnoPt1QSkivyqafXsV01AiX/npETbMP7lpz7/lCSqd5hidEh+wBtClDwLMMtCdEgRIywQohQpwkeEJcIcYYMQpSgDzCN8IUZ4R5gjxNdvSSjvt45Q6j6Ts5F8tdb3MEwuNG9vm1RwDtdos7vC/gEIxZJfDQplbmRzdHJlYW0KZW5kb2JqCjExMCAwIG9iago8PAovTGVuZ3RoIDU0OTIKL1R5cGUgL1hPYmplY3QKL1N1YnR5cGUgL0Zvcm0KL1Jlc291cmNlcyAxMTEgMCBSCi9CQm94IFswLjAgMC4wIDg1LjAgMzAuMF0KL0ZpbHRlciAvRmxhdGVEZWNvZGUKL01hdHJpeCBbMC43NSAwLjAgMC4wIDAuNzUgMC4wIDAuMF0KPj4Kc3RyZWFtDQp4nG1bS44stxHczyn6Am6RTCY/W8uA17YWPsBAlg30GBAEGPDtHRFJsmreDAx5OqpY/CSTkT++399+f/sb/ksPS4+Pt+HP4vz5Wj//lPj/L7y/fun1v97+8fYffPjTX37977/ff/37X//8+PmXt/TMqTzSM039ycnn45ef743e//i20R/vbz/99kd+/PbHW33mNvHcMB97DsfPlgaGtGcbtfLNKP1hz8qvi+eG37kmF2qP97eCr2YnrN4f5emzEFkfBahaXl2yZenOboab411JNh4ZvRlbFrwEqmbRNJUM2EuZfNmNfaeM7qJTPPPoVAPi4ejjsSZTng2d75kCZbTEGvKcQhNix/o8vptc39CMGib2TqF4IXZ3iWKmUdl3y+zULfOLZPkMAZSzazrWDsT0QwjtgL3AQOlZU+VANrK2P1f2iHnFb07aK9ZJ2NTxLJAWYEqlPq7de4eO9CflihGwl/g9On4P9/zoz1p74zAZU+4YgFLwyQk3/HCNWoD9OfrMF7JRb20dWjSjH8i6PmerGqM72ybo1lnfepmecya95IcJi8GqV7fQmNSi2zGwGOk8psIZYe831HRPWyzF6tw9YZVtjj0KELrZM6A8uG1bHrlA8/MzNWgS3thkr73YxIBD2l3rWBKZlZO15IaXdXZNAPoNVKYOQjG1TFAJQagglzF0YqjX/uz3Th1704wjmprWOjm1NJxNL7nhDfSZytJT5pvYuJyFeu2hLXXJbRoV2jkpTGbmJvVOpon2o/rt6XhWeA65hp5S1me9a/H3TiGaqhHTpESzFakuREKpjek3AWcc3hZ6a/j4Yz+ASrTOk0OMn+yOZAKYeuJJqhNEkMEEGqsXngjQhBXCmbteYqMnj1IRSj5v52zio2l6m/Nj4mgXnrQxcDTnM0tL0Z1aBprdSLSQof+AOP+UOd9o+yPG8qlegq2LhxI0fj6LNZEThp6U35QYU9OobmIut8m3vVaxklWA2S5Wwspyb9ocKi/5tq3vGqGb2BHd1iWkruWUgqMM2EEumlHV1z3XPV+1Jr7Wgy3DwSz9vmXx4Noy4BoaMArouT6HZZHY5IAVsxZ5x57Vp80xtGej8S0IZmhXyERg1ZJvm4YH6mXtGmDmIVnbltGLj7NvB8ZWAXou/gVfi1sffHlwto/YNPnUh4ZPXZbEXJO1PCR5UERM1klhZD+cQS6m13EglgpKujWHKFqru7fK52ekCisTJmBtzHrwaWcGNGCwURmxM+dBHbTIG2MrcHyBsnZ+drbpz9BFIQyAEy9NjbcNw2hq0w8iL6ohAU1IJvGGtkDC6LH6mmLXAjsEkOL9oAQGrfKULcpVE3IXVas13lYjAkN7zD5Vk2dg8BvQG8hsBrFrsOVT5L7mP+QqCHM1ZsuPWGCJ6T0klweftEKx7fdAL6GyznB01HRCJqTFBZdGgcKtWKPClPEs1myaVQqpOg0CZVz7RhIIVCHfXk8b/XyM9bZ+7xyzNI1MN0C71zUtKNXaTM2ZKypQHC24DKMqFDpCEqbOKCCWQfGYtAyy4CmktEDTgPSdtpEqtDlDDlomI8Ek0bSQXuEaFJqrtnpW4+z6GCe38G0ahdKDARqE/BOao3eaM6yQXnEuWF/nHKJb0tTqFkaGh6fWqn7gzxF653nEhLP7hu9vWpBob7+HI1bO1yGM03fIinTQlnD6cgVLljRqzuIRODZLNkEimhes+iaVPLmhHKYckHFmpGYLJ57yx/5Oh2P47nZDraCWFE8mDyL4NZV1WMCUnHR417HfII/1fbDyesD3L4IUDpOQQWdGIPxudAu1p36D3WlbNpapee1Of0TTc3QL2+ZfMDxOEr4elNK+eXC+gMStfYUtf2r8CcoD253RqEIRE/cAcChgKYPmzujzUx6Zxkgr8xESSwWmSEJZpjxzVZWxwuFXyRjHFz1XOcmQMBgmbfgiLE6v3vsI2Jr8jYV59iHh3VzdDXqEh66vB0HXGwdda/Tsm5HRv9OfOYRd4NwFXcR7f4qGyv59AiMCcqjx+dhBA+dLN26HDRgu0RoRO605CLZN0m2SkevhSkZHah6Rn4JOoBI+L9hPU08piY2MsRX943DJXcas0ITYxlyIvOAGm7BAZsBw7UJXlCKyZoOy4StgyoutiTzPxdZcbu4XnwLPGpxCvuUGll6DjTVLN8lTULMc4UvHewYEs5yvu8LJq3NMsyicAV1b7F4pm673Zh6+NnzYGEQ1htF4nBmbORTqRZjaJ9hdTlGTHhkDybE1l4q0n2DswQO/cZF5NvpHl1NlJJZ287HwAJ6o4tOG2Rlio+Zc9kDkSNhT26GtWqcUAXb1mF1WyOqF68nhpmBIqAZhX/FgUUANh8IONrJ13k7GQpnOpEfbwM0txmkt9j0wpkmfQtCkidQaqMICKY7HO1tqA+kZc4p0iLuitczcBAyXDKei8lgfN5A8wRVKOtvJaUNLSuWKtmlL8gq3cYq5wgjGE3WHixg6GNDKWNPon724q8nknw8+gDbQOMP36+rCFb/yDBlzGfKSqvUlpuU2MRuC2c1ZtZzJYCfT25dhH2txxZvvB1yrQk5j2LRB77stMbbXterSJOD1XS+K62z1u9awHrzui5qmZVYu4KazgU8QUblpK4iAtAHrkO9ceXwAywn7KmUrn0shhCFUasl2CAFY27hp92QAHxEG3G6DSzySbL1RuAM+a4th1BpOKM8MXyPwMjDyhHbzPIGcAD3fugYj9L4CToxAD1SnblCjrAWhreDkwAhGAPP8AV1asRp/eXACE2L5ZgzjXGPFsQPlcB5FR9JIpRp69hohIkXTI7bWIeyE9SS84KDmiKhKrL4oQFFoCTi7EmcILZewcp55h5aEQ8JUaEkY2aUVwuwHt1UNbvp3T6AXNaAz/INW0GYbo2+lJWBWNMJkjnLNT3tdtBbSPoDXIMEesI8hNid9hxoVed8IvxpVLPscCsCg6YRlXJNf+H5wa2Wu467S8WCz8IJBwtXkgi7dqdj4S4+AKs8cCRjhEWCKcH9w7ApZHPatRf70YV9gbHVsLXSu0lYp9m6MGTTM5l7M4DBvZS5TpC7q3fBw7/UgyBYddbm2B6Y292tMkKGRuDd+H+olHOVQb2VayA/1Ak65rIt6uThvF/VKLnZRL2cxD/NWphxz5F5gobiIWmd8XWGntYa8mXehT/u3Gyze5RZFZNuZ4OXrCGx8wAEC9JJvxIsHZnkTLxDinkO8lQRSL+Kt1LINuU5brLt/L9INGJyrb/yQKrvM/Ua6a/6Hc6/1bMqd8tHoGH0EQFtqIX7La0GUBBtVechK+CahZAhEp0ZqEYlXOH85snr09wC96v2gMdmQhzT28TxQhpBfj6AbtgbDmm+kwbzIy2oVZxlwZCW3uHRMNHm95RrxwGQlWqczxPdFkduET4JvGz1n8jFolSPVdjtmfZnQdQY7U0/qKt2QsphqnLUT4pDKJLLMHzaV4gnprXwCl2CSR6liZy5Cx6OkHouoSiTD4C0gHVsLClyXcHrN4TcfUS2kOYHBVjJ5hNzbUEzvmqNtjxxtwfnLI48NRDAyVualaEtmODm5W4iqlSsY4KzShtQcRVL0sw/oM9xzh1qeY/URcDOgQPCfk2psy96ZjrgZaWdNpx0GdAZ54zAgINe5OZBvpTCLA4HhI6z0dGXfpQ5tbFtDRRgVNOglphqY07KxeXChQ4MHB+2hq+rlYkVO5JCkMw8bp5WJ94UOE/JBt2BCGB0uyZW+MmbCANvFg06X1C8epHS8XDzIebSLCJ0OfbqIkCss4yJCrqJtHgxwp0E+kQZO5gi0gxbxGHrt+roo++MTfMXOhwohu0xBj1MPCqyrM1aJ0I4RHoUfMXlosDNvMzam/FSLCQnE73UuFs4qV/GziPlM3zHI8APf9xIWfl0YjkiskVm8clfTeHDcT+Jhp+wAWFs/ZQdA+Njb/wRKZZ6yg7PI0nbZwVmOuUdXeJDleEYG2yvEOk8GG9CnHSfxwHALAbOy3Z/gtXmr+ZcHx00kbsp8UUGAGnMi9NdMY/eoDBjz9hp9Fp2zCl3hxGsK3uYBdgY2pwgB6N12EYIyGHaKEIDTUrk8RYqst1OEAMxRkZWnSJiPc6vWxJ+UdLJw5vcdXE+C4Hw8x+23t8iU4Sd5eyW7Dopc14Irv7T7+wIjN3Uaf4Ins+XwjUf+gk9zmp7k3+CW763v6CS6iNtOczmNj4JZpbl8+dwnzYUHxnzjTnNRGHXHXZlQhHRPczW6Xcw2gFo+3hrobIEXQdqJh0bWKQfdPnpFJ8wvr7zNx4XpQr02ZPBaH/zWjv+Lfi2yD3FgWhLP77fKJ+/E1kI7tbVg5KSaqoGLFTlZRqibIxsDihHEp4oxLwOUGtmtQuhlXtmtpssFV34LOJV68luN8W8/+S0Olsctv9VI4BtyPbKYDOAWuKW3KIy20xwfb6dBmBjBxBM96OcQihBSgjRbimBJqaQ1bleeD+QMHeDu5RoRQBe04htJJs08317PrMprfMx8s987V005wjtJDFxUNbGxdzRmzVX9U7dWfrh8Qh0uYRQnlvz14skPDW6XTk5tpLHaqVoXHTQSKfOULDGAc5RNHKzKqYKmeBsxYpTmsH8gM7ovnWVlCGoSDprKTOdmCGYugGyC/dXrxPsPzu3ixx3qzMSvvk0j8gDg0aqRs9Vg36H0Yp6KCAZr6Mw3FwlSeqGEPlvroFaVQwYvGvwpsZBgnVp7fr7e1IwhGH1A0UFhsJNhqBBU70EghCj6QgZll1O5Y7yGkmG/coSZaiu3IeY/jbYWLgBomVcvKm/SpLhgQ9s3WI8e5JdOg04oIQ+Welk+T7w6whTYZJU7h8QzPWimXyhxmoQoOBfdMwGpsaBfoqZYnzH7MnZJuTCK0SbCCWFllfUq1lCV6Cy0omuBUWyhW9ej5dphU3kcUaEog2clvmCIwHL7YP6WRVwGoQw04mOIe4Tbh85HXHBorWgymQWAzpgkFCzzFOKbpMkHfeFtJlLW1PEpVw21ZVLdeetAVUJfdzywHBUCB1NZzqPVHyrbZjsXZCa5TK31mqUka7wSoo9ZSbJZV9+sZc119QbrmqqL0GtgDgjRM2s4PKSDyueE0ZrbhLWxWFAqbxwMlrQA6wjVUAqZuOs8Uby0h3yQtSFQgfjeTJX53pXNT1H2N14y0Xiq46n2TV8DG52b8GR7i3hLtU9dHeGBb/UUUOZS64TGKqDg7KvSnuWRQbC6foE1u0XhIcW1ghqeInP+OKQPzYe5Kl5fqqFIY2jCjfUDTOvUDKC2NTRR7YvUiMKngwjM7vCZ1WheVI7A4aePpc+HMCaqkoRMClUggm3OoEZ5uybmn/Al77yx3G3cP3qq+mC2FiuQv81yOW0UZcDbIMA2QwaqTA4WlTQAo9OsinHkhrDVOkuMltnBhI72BXe+vETFGcFYjgw4Mzx0JSLFXWI8VUQBFX5xQuRUY94ka4KJdsUq8yRaj7OssnHlAfSoVoAR9EQ1XHSI+MO0J3WopjB16NFu5aVnXK/I3BljZONxFyRIWpMnjNXzppggFXqwGtuER1RxjkpVWwUnGjqGFzTZvmqrRbRWSAXBcP9T1wvRSUqRtcPwM2nSCP4fLAGHjBBIyM6k7pJR5yUQXrdJzGTiWJDu6C6xudMmiHNFh0xl0v358oCnfWMZLHI789YUAo9jpdkbkTjVabV+8txWpG3WV2Y7JdWpVE1gQpl6KvlE3cfjGkthhpZ1IYYaRRaVXgFWBO+QqC6joihDZrKDvUxBuizqpNxD6QRDqTtvQQJPBnyFtyvDxmaL+womZ4T56dBq4704EYplpb/wC9ytNcdBhlLqwIG0jQuttGZ8vnrgkj2OvG4kDRXhdB4ZJHHe8QHv+ulYWFrvoy42+ox6panSUkWoZPwWajp1S8u5NVOFm0WQ9Dh4alRW2wQMAZoHIze6olIRU106h8ZI2raTdEbmzPQiBn0lnqpKcUt5tT2WqzTEov6ADVJAk3nDSxOA+ZrEk0kl1nSYACunEKakpHo03i/lXlkSrsxkUf0Z3RHnkCdCvBG4iHulL7wjO7VwV3ONpw1Q9BAmS0uxqHvxLocuzdGG0Nq1dSFksvBGj4h5evydSrqxDhu3VPh2O0B8WyzuaEUvXfl85jRdi0hzxhGPNJbLMeQiPeJLsVH4gODPh+NozfAgK3nW6VUNeX1D1M80VJfDmekaASY6PCwb002sMxS1NN0xVdZwSuOzR/q28hbJd094F1CRIPpQ1vTLA3Dt6OcJ7zFkurJF+cbedLsGZ2NwVjk2oRXbeSkRIXe5KDE1pPbQTxa1nNdZutzXlWtiBMvzWcE3rtq4lDbzsoDzEkbVodSFJ+elCtIutrpGBgJnQkrd6LtsqRP2lS25b4MiS5yQy+QD1RpX8WTygRPfbJPf6Cnmm8VvvCaS5rH4jZeySz4Wn5EpD+Jl8huzfuEE0OQztpn9WHyFhtkvk88HifZomXx97u2YfMaW82bwm2qL+Rh8TDC30o/B5wq83Cw+HszRj8GnBFjQ3Aaf8qHhuSx+oxCnHYvfdOvYjsVvurbnN5PfGOF4Pya/0bjT61kmv811rW4b/cbz5e0Y/U4HcR6b33Mo+zH658Gx+p0XyGo7Vh89wmMcx+pjCrO0bfQb3UHPx+g3nqpyWX0sqbTtBYQIRs5+7H5j9opO+7L7R6m20fepKymXzW9xr4GmHo0bdyTMPrv2uqx+4+XnsY0+Zpl5HJbVx5KqbsQuq08hTRvH6nfejkh+zH4vkfM4Zr43XlH7grfVJ9T1tmX1gXF07Vj97lGmv8x+l3tqx+x33iqN2yoy+52n52b0O6syno/R76wYzbmNfmcWOEhsWX0pSlpWn3fhecVRDQbvvW/NI1Yc0RQVy+7TpjBxwgwR+8+R3lI+A2Y/9Z3hKOKXJBE0FhJMDNKZnm60siXMPq1F4z9DiTtGdfWAJdPNxvFlObjRIZd1knHDBPtqj8g2TkaZ633WegZTADT7nXrFPGALs+9LUWebYfaZFaYOhNXnndhGf2eG1ZcR6Mwo5bD6LHv1tP79CgPdLglPka8qdDpHCitIYpgfjxV5l+ZsxP7o0pmuQ87oP+5AsxCbNYGme5TkcZ46OIbLa1jiwQJZkCoqLIsrhrfwAihYyCv8FuIe8uzKGvOB2Kste6IgddNrDOiRdnLKtqia2JXF4lUomX0cIpzELkd+GX6mP3kzeRt+RwBULrvvvGvWr9QHX+c5juXH+867aNvy78TuZfq/zVUxeG4qTSjZkngn/5t/KfVNq1vWqk+6+aK4qhsC68HUCva/4fqMsA7qzevHj795EFPn//4PpPVlSw0KZW5kc3RyZWFtCmVuZG9iagoxMTQgMCBvYmoKPDwKL0xlbmd0aCAxMjE5Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJylWN1v3EQQX7g3P6KCEEJoH6rSPrC332tLCKnJXSglVZI2H0iUh6ooQIWbNFTi3+e3H44dZ8eJhO58a894dn6e+c3s+qSQJjj+b6P580byd42S/EXz629c8t+b9dOrj3+dv3n7ka8Pry4uFd/Z7DZS2GCd4lK41po4etNpza/+aHaOm/We4goqfnzeQIeP4roVxnEXgvAtfB33zfdSSiul2pVSb3Ds4YBIKnwn50m+KffZ8T7dlrHLsrmd3Ob7VRxNslcu4DwUvc3y5Dueb8vcT3HsFJ3M+nT/7og1zVn8BMxngMXApoXelOvrc8xpYGOAM7Q/8ON3zfY4R0lzpacxCrYVwWvENcYpOlAxUI+ZYRv2nD1jqyeL5q0UygHZ3PzBHWZetNrJW15X7Mc7fbYSxvBpSZ/bF7tzDunEoUWiQJojUYjSSmW3Kdl53OQxESSMyUiJGILvcwLSeVuu47hb7o3JQbK9zaMZ5tsZEz2fX29HUhg1Idigl4V4spCx6NN85ToRrBtJGG9WJo4DOT5cB8N7L6zSznJdwvy2R9QurnrFNxfNUYruh6YUF27ukEjH+6ZVRjic64n074k0WqAOFYTZ+JZgavdnc9a8n2fRpCxW0msphaMUnlIEStFSio5SoKdRGkVqNKkhn16Rj6/I51dkAFSOgIydFjToMIbOyzZ22pwnG5QIoIZB1otEox2HmGXk0gQRe3tVdm0ZM3xedZ/jfNuiH2XWCw2Kxplt6IROLCKk9/CYE1iz6afSyfN4rYX10RchvdurzuSo2fTE/GMtEdJ7eCWJp/XNuF9Hs69m1Mgg2thBKOkkGxSWTOiaTU/N750IgEJK7+E1F0vNpifmt8iGU3rGgYn0Hl5zIdZsemr+KvPqfKe8kkWuyTan27Ld6mwHj/NxbALXoIYmYDonlMkNPZIybwzq0ukjRfBR083S3U+k/2fu2kNOevaryzfvy/Iih86Hz7CvNFyBEzf2C8YIz511Qrtxs3TG9rF1OWJnC7sQQ1af0VVAZty26FvblgwDsc+PnZBIoNhjPwPPP+wA26lHOD+B7BT4XrJXuHqG6xUT7CFz0L5+PO62arDIlcWQK4shSWdC9SHJhdWQK6uVtZmsujtckSUoGjeEa8U+w/E5+xLjA4zx92v2FftiISqWXKMtvUMhI2nJSFoykpYsX0tG01Y57+QYswrVhwU/lDpMUQug0AakOgOZDjPpQbAVZHupDH5ipwvRc2QRuGoRuBxTbNvxGaqSSK+1uqwaCagC5w/TS8Uv+D1klziL9bEZYC/BpPeUrgrTL5FPAxjWc26dE24s128B8DS/aS1BIbPt2iqUbgmKba1wJq8gN6L1KEVrSGhM8MkiLE9ub72qwfJ6CZbXQYS0nM1gdYAVW+sKxxl+D3AdU3iQ2lpuvC/Z0RJQsiq9rQJ190qlkUKq8sIYW0mGsgiELGhfbY2+XWxo6GUyr3hzKPuR6EtAyM4aqp01LHfWgN1Bm3ZNN4H4lLqTBSCBbKXBVIHYRWpHDqV3+BkQhQawv1jugezCwVeBjG9JJsT1BFC8DO3C/1G5Q0krbHDDfxafIlnf4Hj9hH3C1uw7rD0PMfK4MPMoXS9hHqv/qPkP61pmyg0KZW5kc3RyZWFtCmVuZG9iagoxMTUgMCBvYmoKPDwKL0xlbmd0aCA0OTQ5Ci9UeXBlIC9NZXRhZGF0YQovU3VidHlwZSAvWE1MCj4+CnN0cmVhbQ0KPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz48eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczpwZGZhaWQ9Imh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9pZC8iIHJkZjphYm91dD0iIj4KICAgICAgICAgPHBkZmFpZDpjb25mb3JtYW5jZT5BPC9wZGZhaWQ6Y29uZm9ybWFuY2U+CiAgICAgICAgIDxwZGZhaWQ6cGFydD4yPC9wZGZhaWQ6cGFydD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6cGRmPSJodHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDxwZGY6UERGVmVyc2lvbj4xLjc8L3BkZjpQREZWZXJzaW9uPgogICAgICAgICA8cGRmOlByb2R1Y2VyPnBtcDwvcGRmOlByb2R1Y2VyPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHJkZjphYm91dD0iIj4KICAgICAgICAgPHhtcDpDcmVhdGVEYXRlPjIwMjYtMDEtMjJUMTQ6NDg6NTUrMDE6MDA8L3htcDpDcmVhdGVEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHJkZjphYm91dD0iIj4KICAgICAgICAgPGRjOmZvcm1hdD5hcHBsaWNhdGlvbi9wZGY8L2RjOmZvcm1hdD4KICAgICAgICAgPGRjOmNyZWF0b3I+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpPnBtcCBieSBBc3NvY2lhdGlvbiBDQVJBICgwLjYuNi1IVUcpPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOlNlcT4KICAgICAgICAgPC9kYzpjcmVhdG9yPgogICAgICAgICA8ZGM6dGl0bGU+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPkNhcnRlIGRlIG3DqWRpY2F0aW9uPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkFsdD4KICAgICAgICAgPC9kYzp0aXRsZT4KICAgICAgICAgPGRjOmRlc2NyaXB0aW9uPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij5NaWNoYcOrbCBDaHJpc3RvcGhlciBLYXJjZTwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6ZGVzY3JpcHRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOnBkZmFFeHRlbnNpb249Imh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9leHRlbnNpb24vIgogICAgICAgICAgICAgICAgICAgICAgIHhtbG5zOnBkZmFQcm9wZXJ0eT0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL3Byb3BlcnR5IyIKICAgICAgICAgICAgICAgICAgICAgICB4bWxuczpwZGZhU2NoZW1hPSJodHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvc2NoZW1hIyIKICAgICAgICAgICAgICAgICAgICAgICByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDxwZGZhRXh0ZW5zaW9uOnNjaGVtYXM+CiAgICAgICAgICAgIDxyZGY6QmFnPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6c2NoZW1hPkFkb2JlIFBERiBTY2hlbWE8L3BkZmFTY2hlbWE6c2NoZW1hPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+aHR0cDovL25zLmFkb2JlLmNvbS9wZGYvMS4zLzwvcGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByZWZpeD5wZGY8L3BkZmFTY2hlbWE6cHJlZml4PgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+UERGVmVyc2lvbjwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPlRleHQ8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5UaGUgUERGIGZpbGUgdmVyc2lvbi48L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+S2V5d29yZHM8L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5UZXh0PC9wZGZhUHJvcGVydHk6dmFsdWVUeXBlPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmNhdGVnb3J5PmV4dGVybmFsPC9wZGZhUHJvcGVydHk6Y2F0ZWdvcnk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+S2V5d29yZHMuPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPlByb2R1Y2VyPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+QWdlbnROYW1lPC9wZGZhUHJvcGVydHk6dmFsdWVUeXBlPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmNhdGVnb3J5PmludGVybmFsPC9wZGZhUHJvcGVydHk6Y2F0ZWdvcnk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+VGhlIG5hbWUgb2YgdGhlIHRvb2wgdGhhdCBjcmVhdGVkIHRoZSBQREYgZG9jdW1lbnQuPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgICAgICAgICAgIDwvcGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpzY2hlbWE+UERGL0EgSUQgU2NoZW1hPC9wZGZhU2NoZW1hOnNjaGVtYT4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6bmFtZXNwYWNlVVJJPmh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9pZC88L3BkZmFTY2hlbWE6bmFtZXNwYWNlVVJJPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpwcmVmaXg+cGRmYWlkPC9wZGZhU2NoZW1hOnByZWZpeD4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6cHJvcGVydHk+CiAgICAgICAgICAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPnBhcnQ8L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5JbnRlZ2VyPC9wZGZhUHJvcGVydHk6dmFsdWVUeXBlPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmNhdGVnb3J5PmludGVybmFsPC9wZGZhUHJvcGVydHk6Y2F0ZWdvcnk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+UGFydCBvZiBQREYvQSBzdGFuZGFyZDwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5jb25mb3JtYW5jZTwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPlRleHQ8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5Db25mb3JtYW5jZSBsZXZlbCBvZiBQREYvQSBzdGFuZGFyZDwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICAgICAgICAgICA8L3BkZmFTY2hlbWE6cHJvcGVydHk+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpCYWc+CiAgICAgICAgIDwvcGRmYUV4dGVuc2lvbjpzY2hlbWFzPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPD94cGFja2V0IGVuZD0idyI/PgoNCmVuZHN0cmVhbQplbmRvYmoKMTE5IDAgb2JqCjw8Ci9MZW5ndGggMjQ3MgovRmlsdGVyIC9GbGF0ZURlY29kZQovTiAzCj4+CnN0cmVhbQ0KeJztmWdQVFkWgO97nRMN3U2ToclJooQGJOckOYoKdDeZFpoMKooMjsAIIiJJEUQUcMDRIcgoKqIYEAUFVNRpZBBQxsFRREVlafwxuzU/trZqa/9snx/vfXXuqXfOfXWr3lf1AJAhJrASU2B9ABK5qTxfZztGcEgoA/MAYAEJEAEFoCNYKUmefk7+YDUEteBv8X4MQIL7fR3Beu45UkzRBx3DYzMuj99ONG/+e/2/BJGdyGUDANFWOY7NSWGt8q5VjmEnsgX5WQFnpCalAgB7rzKNtzrgKrMFHPmNMwUc/Y2L12r8fe1X+RgAWGL0GuNPCzhyjSndAmbF8BIBkO5frVdhJfFWny8t6KX4bYa1EBXshxHN4XJ4EakcNuPfbOU/j3/qhUpZffn/9Qb/4z6Cs/ON3lqunQmIXvlXbls5AMzXACBK/8qpHAGAvAeAzt6/cpEnAOgqBUDyGSuNl/4th1ybHeABGdCAFJAHykAD6ABDYAosgA1wBG7AC/iDELAFsEAMSAQ8kAG2g92gABSBUnAIVIM60AiaQRs4C7rABXAFXAe3wT0wCiYAH0yDV2ABvAfLEARhIBJEhaQgBUgV0oYMISZkBTlCHpAvFAKFQ9EQF0qDtkN7oCKoDKqG6qFm6CfoPHQFugkNQ4+gSWgO+hP6BCNgIkyD5WA1WA9mwrawO+wPb4aj4WQ4G86H98OVcAN8Gu6Er8C34VGYD7+CFxEAQUDQEYoIHQQTYY/wQoQiohA8xE5EIaIC0YBoQ/QgBhD3EXzEPOIjEo2kIhlIHaQF0gUZgGQhk5E7kcXIauQpZCeyH3kfOYlcQH5FkVCyKG2UOcoVFYyKRmWgClAVqCZUB+oaahQ1jXqPRqPpaHW0KdoFHYKOQ+egi9FH0O3oy+hh9BR6EYPBSGG0MZYYL0wEJhVTgKnCnMZcwoxgpjEfsASsAtYQ64QNxXKxedgKbAu2FzuCncEu40RxqjhznBeOjcvCleAacT24u7hp3DJeDK+Ot8T74+Pwu/GV+Db8NfwT/FsCgaBEMCP4EGIJuwiVhDOEG4RJwkcihahFtCeGEdOI+4kniZeJj4hvSSSSGsmGFEpKJe0nNZOukp6RPohQRXRFXEXYIrkiNSKdIiMir8k4sirZlryFnE2uIJ8j3yXPi+JE1UTtRSNEd4rWiJ4XHRddFKOKGYh5iSWKFYu1iN0Um6VgKGoURwqbkk85TrlKmaIiqMpUeyqLuofaSL1Gnaahaeo0V1ocrYj2I22ItiBOETcSDxTPFK8RvyjOpyPoanRXegK9hH6WPkb/JCEnYSvBkdgn0SYxIrEkKSNpI8mRLJRslxyV/CTFkHKUipc6INUl9VQaKa0l7SOdIX1U+pr0vAxNxkKGJVMoc1bmsSwsqyXrK5sje1x2UHZRTl7OWS5Jrkruqty8PF3eRj5Ovly+V35OgapgpRCrUK5wSeElQ5xhy0hgVDL6GQuKsoouimmK9YpDistK6koBSnlK7UpPlfHKTOUo5XLlPuUFFQUVT5XtKq0qj1VxqkzVGNXDqgOqS2rqakFqe9W61GbVJdVd1bPVW9WfaJA0rDWSNRo0HmiiNZma8ZpHNO9pwVrGWjFaNVp3tWFtE+1Y7SPaw+tQ68zWcdc1rBvXIerY6qTrtOpM6tJ1PXTzdLt0X+up6IXqHdAb0Puqb6yfoN+oP2FAMXAzyDPoMfjTUMuQZVhj+GA9ab3T+tz13evfGGkbcYyOGj00php7Gu817jP+YmJqwjNpM5kzVTENN601HWfSmN7MYuYNM5SZnVmu2QWzj+Ym5qnmZ83/sNCxiLdosZjdoL6Bs6Fxw5SlkmWEZb0l34phFW51zIpvrWgdYd1g/dxG2YZt02QzY6tpG2d72va1nb4dz67Dbsne3H6H/WUHhIOzQ6HDkCPFMcCx2vGZk5JTtFOr04KzsXOO82UXlIu7ywGXcVc5V5Zrs+uCm6nbDrd+d6K7n3u1+3MPLQ+eR48n7OnmedDzyUbVjdyNXV7Ay9XroNdTb3XvZO9ffNA+3j41Pi98DXy3+w74Uf22+rX4vfe38y/xnwjQCEgL6AskB4YFNgcuBTkElQXxg/WCdwTfDpEOiQ3pDsWEBoY2hS5uctx0aNN0mHFYQdjYZvXNmZtvbpHekrDl4lby1oit58JR4UHhLeGfI7wiGiIWI10jayMXWPasw6xXbBt2OXuOY8kp48xEWUaVRc1GW0YfjJ6LsY6piJmPtY+tjn0T5xJXF7cU7xV/Mn4lISihPRGbGJ54nkvhxnP7t8lvy9w2nKSdVJDETzZPPpS8wHPnNaVAKZtTulNpqx/pwTSNtO/SJtOt0mvSP2QEZpzLFMvkZg5maWXty5rJdso+kYPMYeX0bVfcvnv75A7bHfU7oZ2RO/tylXPzc6d3Oe86tRu/O373nTz9vLK8d3uC9vTky+Xvyp/6zvm71gKRAl7B+F6LvXXfI7+P/X5o3/p9Vfu+FrILbxXpF1UUfS5mFd/6weCHyh9W9kftHyoxKTlaii7llo4dsD5wqkysLLts6qDnwc5yRnlh+btDWw/drDCqqDuMP5x2mF/pUdldpVJVWvW5OqZ6tMaupr1WtnZf7dIR9pGRozZH2+rk6orqPh2LPfaw3rm+s0GtoeI4+nj68ReNgY0DJ5gnmpukm4qavpzknuSf8j3V32za3Nwi21LSCremtc6dDjt970eHH7vbdNrq2+ntRWfAmbQzL38K/2nsrPvZvnPMc20/q/5c20HtKOyEOrM6F7piuvjdId3D593O9/VY9HT8ovvLyQuKF2ouil8s6cX35veuXMq+tHg56fL8legrU31b+yauBl990O/TP3TN/dqN607Xrw7YDly6YXnjwk3zm+dvMW913Ta53TloPNhxx/hOx5DJUOdd07vd98zu9QxvGO4dsR65ct/h/vUHrg9uj24cHR4LGHs4HjbOf8h+OPso4dGbx+mPlyd2PUE9KXwq+rTimeyzhl81f23nm/AvTjpMDj73ez4xxZp69VvKb5+n81+QXlTMKMw0zxrOXphzmrv3ctPL6VdJr5bnC34X+732tcbrn/+w+WNwIXhh+g3vzcqfxW+l3p58Z/Sub9F78dn7xPfLS4UfpD6c+sj8OPAp6NPMcsZnzOfKL5pfer66f32ykriyInQBoQsIXUDoAkIXELqA0AWELiB0AaELCF1A6AJCFxC6gNAF/o9dYO0/zmogBJfj4wD45wDgcQeAqmoA1KIAIIelcjJTBavcbQzWtqQsXmx0TOo6RloKhxHF43ASsgRr/wA1JhMbDQplbmRzdHJlYW0KZW5kb2JqCjE2MiAwIG9iago8PAovTGVuZ3RoIDMzNDgKL1R5cGUgL09ialN0bQovTiAxNDQKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0ZpcnN0IDEyMTcKPj4Kc3RyZWFtDQp4nO1a+28bNxL+V/hbY/S84vtRpAFkW06MXB6w3WsB1zgo1tbZq60VpHVT//f3DfdBSZatteO2V+CKxsshhx+Hw284XC0l40wxLZlmwglmmJSaWSaUt8wxoXlgHg8lWcAjoIozYaxkQjBhJWQUbVDoAQBDSkx4aaCEZ8AfgAWLp2OSK6rEMwAzMCmshoAhpYWAZ5D4w6QyUFJMaoVGqOgAZZhmLJ5QtQrtwHMcjVSE5RJNXitGXQKMUFTl8ZSo0oEpNAmqpyYvGExR0qDS4mnxx0EFuPS/5mhEFw1jNfyjvWGauhhOrlIWk6OhrIcMPJq/RhcHuzWgPIzRwPPkV+AFOIdMIHsIghvDjAAkJmOgIuBXQ6tgPTMa0BgcKlpz1Fs84STj8PRoxxAGlXC1Jn9Y4FkYb4HnuGVYGu3gXAs8B324GOajHXjecYap6gB8C2iO1aUhOZwOKMPhf6gYATAig3CaOQkTMVmnYCLmgSqj4HyHKSjY7WCKBogDnvboDzyDyTjgWSwiXGTIPrjcOMwHKsZB2QPPBcHIJR7jwcUmcM7AO8uxeB4ma0ySpgBDGFwMdwsWQM+ARQS1nIKxATzVIIFAm3OYkOBkBJZNcBo9UlZjeDhUEJs1kVDQwFQD+noNWwWm5iO/QVhvog6MpJkIsMAbzENgGbwjroOs3nv0guOwuFDGTIPkMAN8DRKTFCBsUPA2LXLQFDbwWtCOlD3MVxQ7AfZTk6KJkDJmHhwZTxHnaTogbvCOAgzIAe1xPI7/ULJUIhsJjcfJqugLR3rRGTKGMXmDQhY0RslTnSTHYPkQ3SgZ+gsyo0RT1TSG1aRHY1gygCQejdM0hiN7NY3hYaMwNIanHcDQGIF0DO0THO4X0Y8c6yxAcLhfUGtcCHII+IyVIGRDK6CwhAJER8lRXVweLLQA2RHDpEdIUBbs5cvB6e0sZ4OP48t8wQZvi8mCnSlsa8fsnA32y5tpxQR79WpVkw3e5ZNivFf+zs54xhn981pknngdTCbxPCfVeY7+MsINjvNFeTO/wDC6rtgvpxXaF2RVXXNSzW8uqrrbAlWD0/EnWHXSGPBxXs7yeVUAwtQdDgFBQRCFnz58+k9+UUWiUkXqJLApRxUSQPAkgLdJAEWSQEuYJHJxkuLG3Umetu9Oipt4J8UNf0mkfX9JlLSzJ1HRBp9ETft8Eg1t90mMu34SHW3+SYw5IImBUkFyAaeMkERBiSGJkvJDEhWliSRqyhZJNJQ0kmgpdyTRUQpJoqdMkkTKEktrwSmvJFFQekmipCyTREXJJomack4SDaWeJFrKQEl0lIiS6CkfJTFQWkqk4JSdkigoSSWREsaSqChlJVFT5kqioQSWREt5LImO0lkSPWW1JAZKbomdnHJcEgWluiRSmlgSFSW+JGrKf0k0lAaTaCkbJtFRUkyip9yYxEApMkUJp0yZREEJM4mS8mYSKSctiZSalkRDyTSJlnJqEh2l1iR6yrBJDJRoU7RyyrdJFJR2kygp+yZRURJOoqZcnERDKTmJljJzEmOCTqKnPJ12om7/LKbjqiinfar3xhe/Xs6xDU9Qjvut9BmdvrDLYn+HOUJlBkForM2CNJw23r8HgOEqcw7Hp78pglKZpYOEpKNfxmVE4T4mP2NFZt0jUVTI6GSivw7lri0d7hMXVged4bTfszvOzxlspuPjav+vMCBC9h1f8ug0udadLOqJoG0mcQJ9CkJaCC1NJBK9kclMxJIGuQDTxxItM0sjG5FpS7ZopzNOXukPor3OTOzS2WKFi3N7BAreUzMXu3QoLbUeMZ/71qbzdW+PdFbgoJvVL3pZsH0g8AaWcbO6OMryDK925OD+OA6adZ8OR5Njo329YTQ5dnVKaZF7o9wXM52r/3CAJc5znikfk6TLcIwSJtPycRBLu6CNBvFN++C7/aMDZNbnBe2BI7E8tGLCYpcFbUUNvWqXeD68+yBa/bsI/3MA0SXyjzZnUwLEq3pmEe4ioa4YpZ4X8zEwGyjwf5i/HGb9ACOsyiSnxb57hIkM0s8I2GN3VT4mYkm/eGV0NlBrp5JolHlGwP7HE+l85jcfLKJV9jkRtx94upkZ7TLj7nWWe07E7SeoDsQhNapYtdku/6yQ/c9U0voG5M4BJNoVnhPxUec0HKLV/XaJrYeBR2E+5uSnfMjs5pNfbdrW88DjQB9znMTpWm8+TtambcvLj8N8xAFRCBnnvOGMWFvWPzn3wTyMn0jqn4wlfQ2piyp++Fj/hSb+qIwhF3ldGg6HH/dffzucF9fl7lE1viou2ODk5lMVtakPZ4PR9KKcFNNLNjia5NOqqG5337DBQb64yKeT8bQiqAU787b9bf20/GFaoE/OgrzHhG4MeIRqqE1utQzKJ7eLKr8+mv5S0peg7pdysmZezKpyTh+GYvWP7IyzM+wWtN0yax1M06iQ5DuPAmrPiSdndZtAI32wOKefphs1CT36qHZOvwSfIcZY/MRW15i6TUZNhT5UIoRWp9bThpZU0Ve1aElsQfmcfvU8W9Z96N85fcbBELXRZCFhqtpe3bUopTuLtWqLIHatT9bItngeHXpavj46eDeesbBMl+P8slhU81v2YjgpP+U7bPBhPsnnxIIXLQt2aBlns6v8mj6F8DurvLQmUX4/vs7vWdjDq/Hlgn4zjYo/5sXl5yqyH/SrdYbTy6uc7SIOeK1Ux8qutc0JaJf2FWE5fTxwwcYPNoJjzw7Wk2cGQ+JrxQKnjzhK65bCFduVQmQBXrTwyHj2ph7eerzoea/Y4KemxtChRyL5DE7AwX/BrQE7h/C6tuiwuAKHffObKnE1p+H6BOGPo8PGI3D8zdV4/uQoDPpuFBJznh6GG2xbjcNgNsZhsOtxCE52DPZtSfLVIDinzzkNb6XtSikQbRuwytdhSv+a8O7atK+DuQ5jvHw29UbVfRrJtfW2w3d3At0thWkd7O7eYPcbgv08fk0+a4umK2qxHMXr4Rj+rHDcsMB1POpt4cjXgtFolQWc0f6SYFR47eDWLsdicKux6PvE4vt3+4079sqryZMDka4bbIjE+0zoE4nrlq2GIV1r2BSHdMvh/kBcCg0Q0wpxNxjqUsPgmqvOtv09NOjGQ90z0t8HljTXWC24+7Nove6tTZx2fz9OC25WSC24XfLoYTm/phsQyxv+6Pfq9Uk1rvK4D6X6y4WI11vWCZn0B3vv6C7D9WxcFZ/gm+YUO57/mk9YNb9paw6KxexqfHtQXpwWFfSWmmrIDzfV7KY6ipci6NLD4PXpyb8/HhwORXRSVbd/nJe/YI7xeBOnGHn9YnH8eo8djfatCNbuykzstID75XRSxA+LfZRqRv1S5PPN6i0bI4NefK6q2XeDwZcvX7KL8qqcZ+X8cmdlUvWVjtN5nh+XJaZ1XF7lkePt5YW38R5Q/dE0Xvwg3ff579Xb/JaJ5cp4gyWtw9H0qpjmJ5/HkeTF5c28Hq74NS9vyIGz8RSOm5czsClpjKaT9yUtW/0X0yeYVh07TB0pqWKWz1erhtNpWdWfatuaOVw2voDGR4xYjC/n4+s04iEmvjzkD1OE7/Kge+BNUaLT7PNtlEZTivfB/ufxvOpw7np1hHiPRAGnbmLkD/45pm3h8Hj0fv/NDpkj2jsjb+M1q3UarwMVv9Wd2hW5ZKrtfiaaKySiuYdx/hDS6ZhiIWKpjVh1gIrm4olQtgfmm3w8qTH1tpmc7pWT22XdlfGFdFsBjuvedlPvuwlqvfdB3dttnHto5sy3z/mNrIH8XSDeayU3dDwTzR0dofR2C2qOfuzMXYOKl+0eASI2+FNtJWbqv4GZ8ivMb24crf9Wdi/IOpke4sBh3PF60bVbro3B0tx0Es0Vpz6EURuYp/sF7KauZ6K5TyWaa0fC9LAlBWx3OWsVs6Gh6REITTzqjavYXOcSzcUt0VzREs1lrIeB61DVd4g5jJc7mzHaX9U/dJ7aL68iLSQltS9N8anjmHYce+84D6/eQ+CuBXd3wL/e8tCC+yeCP7SupiVIs77NjThheuxbjdVmA3B4Yj/x4Jb7UEfx1I4P+65LcpviS5jlQ+9Dzu+uEq703p4iG7vvpMhhvIDc7e73Utr32z7V8lv++5vrRXxHS2m0TWZqJal1u+aWzWEbyVpHnHd025/n8fh3QMf/FwffSS7xxiMlRvDGfMvFN5x/sxMvAU5uLugkPbuexVe0+oLyS31gg1XWWzHas/uSa5SdtMEpp+2h42gxTqJ+zwrUK2tewak31eeyxmKfbtlwsSgvivoYuj88HrKfX/DMZnb3zQ+vf97BaJPmnY8UXuJdc2SN5MACIkahcv33YBRQCrGFnod2JDlsOHTRBrtPWrDM2CGs0hL2Woc+o1FwEk+0jnjUEzWmPbACo+lo9W9F/mVW4hj74ksxqT5/P8l/Ky7y3Sj8gxVTvHSMr3YXF+Or/Ht6v6jfjV7qXna+ogX5L8e31qsNCmVuZHN0cmVhbQplbmRvYmoKMTYzIDAgb2JqCjw8Ci9MZW5ndGggMzE1Ci9Sb290IDEgMCBSCi9JbmZvIDE2MSAwIFIKL0lEIFs8RjAyMzE5NzRDMzQ0QUM2NDIyQUIwNzM3RkI1QUZDM0E+IDxGMDIzMTk3NEMzNDRBQzY0MjJBQjA3MzdGQjVBRkMzQT5dCi9UeXBlIC9YUmVmCi9TaXplIDE2NAovSW5kZXggWzAgMTYzXQovVyBbMSAyIDFdCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJwV0ElbjmEYBuDnKVJRn5SMJeor85hEAzKWTEVkjJAGQwkZSqgoYmlvY2vVn+joN9X5Ls7jOu7r2t0hhMUYUiEj/E1EMshkGcvJYgXZ5JDLSlaRRz4pVlPAGgopYi3FrGM9G9jIJjZTQilbKGMr2yingjSVVLGdHexkF7vZw172sZ8DHOQQ1RymhiPUcpRj1FFPA40c5wQnaeIUpznDWc5xnmZauEArF7nEZa5wlTbaucZ1OmJYCDF/LsRUHvPJn29wk05uxYLxEEs6+R9iaXey3+YOd7kXy9IhpquZCbEyJPv9WNWTZBcPeBgb/oTY9C/punnE49jRltxP6OEpvfTRzwDPeM4LXjLIEK8Y5jVveMsI73jPBz4yyhifGOczX/jKBJNM8Y3vTDPDD34yyy9+x67WsARM3I+HDQplbmRzdHJlYW0KZW5kb2JqCnN0YXJ0eHJlZgoyODExMAolJUVPRgo="
      }
    }
  ]
}

```
