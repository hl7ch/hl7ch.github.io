# Bundle: PMLC document with Dafalgan self-medication - CH EMED EPR v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: PMLC document with Dafalgan self-medication**

## Example Bundle: Bundle: PMLC document with Dafalgan self-medication



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DocumentUCSF5CARAPMP004PMLCDafalganSelfMedication",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-document-medicationcard"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:52733043-1430-4a01-aef7-3aef12505fd4"
  },
  "type" : "document",
  "timestamp" : "2026-02-12T14:50:55.602+01:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:52733043-1430-4a01-aef7-3aef12505fd4",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "CompositionUCSF5CARAPMP004PMLCDafalganSelfMedication",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-composition-medicationcard"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Composition_CompositionUCSF5CARAPMP004PMLCDafalganSelfMedication\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition CompositionUCSF5CARAPMP004PMLCDafalganSelfMedication</b></p><a name=\"CompositionUCSF5CARAPMP004PMLCDafalganSelfMedication\"> </a><a name=\"hcCompositionUCSF5CARAPMP004PMLCDafalganSelfMedication\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-composition-medicationcard.html\">PMLC Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:52733043-1430-4a01-aef7-3aef12505fd4</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 736378000}\">Medication management plan (record artifact)</span></p><p><b>date</b>: 2026-02-12 14:50:55+0100</p><p><b>author</b>: <a href=\"Bundle-DocumentUCSF1CARAPMP004PMLCEmpty.html#urn-uuid-c35ef74f-fcf6-4a9c-9782-fdb79116f368\">Device: type = Pharmaceutical information system application software (physical object)</a></p><p><b>title</b>: Plan de médication</p><p><b>confidentiality</b>: normal</p><p><b>custodian</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:52733043-1430-4a01-aef7-3aef12505fd4"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medication management plan (record artifact)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "date" : "2026-02-12T14:50:55.602+01:00",
        "author" : [
          {
            "reference" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368"
          }
        ],
        "title" : "Plan de médication",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "custodian" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        },
        "section" : [
          {
            "title" : "Medication List",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "10160-0",
                  "display" : "History of Medication use Narrative"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Ce plan de médication a été généré automatiquement par le service eMedication CARA le 14 décembre 2023 à 14:35:07 UTC. Tous les traitements actifs sont considérés.</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:8ba8cb30-2be0-4d67-9ad4-435666a79412"
              }
            ]
          },
          {
            "title" : "Original representation",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "55108-5",
                  "display" : "Clinical presentation Document"
                }
              ]
            },
            "text" : {
              "extension" : [
                {
                  "extension" : [
                    {
                      "url" : "htmlid",
                      "valueString" : "pmlc-pdf"
                    },
                    {
                      "url" : "data",
                      "valueUri" : "urn:uuid:084ef91f-75a3-4d9b-9ce0-3d30e807fd9b"
                    }
                  ],
                  "url" : "http://hl7.org/fhir/StructureDefinition/textLink"
                }
              ],
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">The original representation as a <span id=\"pmlc-pdf\">PDF</span> file</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:084ef91f-75a3-4d9b-9ce0-3d30e807fd9b"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "PatientCARAPMP004",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientCARAPMP004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient PatientCARAPMP004</b></p><a name=\"PatientCARAPMP004\"> </a><a name=\"hcPatientCARAPMP004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-patient.html\">CH EMED EPR Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus 9}\">unbekannt</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Medical record number/100001368 (use: secondary, )</li><li>Medical record number/CARAPMP004 (use: secondary, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.1625.3.1.3.1",
            "value" : "7857bf60-93a1-409d-a647-ee260cec9c0e"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.177.2.2.1.1",
            "value" : "100001368"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "CARAPMP004"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Karce",
            "given" : ["Michaël Christopher"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1973-12-25",
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus",
              "code" : "9",
              "display" : "unbekannt"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:c35ef74f-fcf6-4a9c-9782-fdb79116f368",
      "resource" : {
        "resourceType" : "Device",
        "id" : "DevicePmp",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-device"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_DevicePmp\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device DevicePmp</b></p><a name=\"DevicePmp\"> </a><a name=\"hcDevicePmp\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-device.html\">CH EMED EPR Device</a></p></div><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>PMP CARA v0.1</td><td>Model name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 701612004}\">Pharmaceutical information system application software (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>8153cba</td></tr></table><p><b>owner</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-dd9fd2e4-92d4-4a56-bda2-cf921e432eea\">Organization Association CARA</a></p></div>"
        },
        "deviceName" : [
          {
            "name" : "PMP CARA v0.1",
            "type" : "model-name"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "701612004",
              "display" : "Pharmaceutical information system application software (physical object)"
            }
          ]
        },
        "version" : [
          {
            "value" : "8153cba"
          }
        ],
        "owner" : {
          "reference" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:dd9fd2e4-92d4-4a56-bda2-cf921e432eea",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "OrganizationCara",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationCara\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization OrganizationCara</b></p><a name=\"OrganizationCara\"> </a><a name=\"hcOrganizationCara\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001407428</p><p><b>name</b>: Association CARA</p><p><b>address</b>: Route de la Corniche 3a Épalinges Vaud 1066 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001407428"
          }
        ],
        "name" : "Association CARA",
        "address" : [
          {
            "line" : ["Route de la Corniche 3a"],
            "city" : "Épalinges",
            "state" : "Vaud",
            "postalCode" : "1066",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:37310437-d3bb-48a2-b2f2-a3f0e41440c7",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "PharmacistDoe",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_PharmacistDoe\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner PharmacistDoe</b></p><a name=\"PharmacistDoe\"> </a><a name=\"hcPharmacistDoe\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-practitioner.html\">CH EMED EPR Practitioner</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601234567890</p><p><b>name</b>: John Doe </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601234567890"
          }
        ],
        "name" : [
          {
            "family" : "Doe",
            "given" : ["John"]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:e901b242-7f96-434e-acee-685dd24aad17",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "PractitionerRoleDoeAtPharmaSI",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_PractitionerRoleDoeAtPharmaSI\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole PractitionerRoleDoeAtPharmaSI</b></p><a name=\"PractitionerRoleDoeAtPharmaSI\"> </a><a name=\"hcPractitionerRoleDoeAtPharmaSI\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-practitionerrole.html\">CH EMED EPR PractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-DocumentUCSF4CARAPMP004DISDafalganWithoutPrescription.html#urn-uuid-37310437-d3bb-48a2-b2f2-a3f0e41440c7\">Practitioner John Doe </a></p><p><b>organization</b>: <a href=\"Bundle-DocumentUCSF4CARAPMP004DISDafalganWithoutPrescription.html#urn-uuid-7ba4c339-2731-4ac9-9fe2-8eabcce3d9eb\">Organization Pharma SI</a></p></div>"
        },
        "practitioner" : {
          "reference" : "urn:uuid:37310437-d3bb-48a2-b2f2-a3f0e41440c7"
        },
        "organization" : {
          "reference" : "urn:uuid:7ba4c339-2731-4ac9-9fe2-8eabcce3d9eb"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:7ba4c339-2731-4ac9-9fe2-8eabcce3d9eb",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "OrganizationPharmaSI",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationPharmaSI\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization OrganizationPharmaSI</b></p><a name=\"OrganizationPharmaSI\"> </a><a name=\"hcOrganizationPharmaSI\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601234567890</p><p><b>name</b>: Pharma SI</p><p><b>address</b>: Rue de la Vie s/n Ville la Ville CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601234567890"
          }
        ],
        "name" : "Pharma SI",
        "address" : [
          {
            "line" : ["Rue de la Vie s/n"],
            "city" : "Ville la Ville",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:8ba8cb30-2be0-4d67-9ad4-435666a79412",
      "resource" : {
        "resourceType" : "MedicationStatement",
        "id" : "MedicationStatementCardParacetamolSelfMedicationAfterDispense",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medicationstatement-card"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"MedicationStatement_MedicationStatementCardParacetamolSelfMedicationAfterDispense\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement MedicationStatementCardParacetamolSelfMedicationAfterDispense</b></p><a name=\"MedicationStatementCardParacetamolSelfMedicationAfterDispense\"> </a><a name=\"hcMedicationStatementCardParacetamolSelfMedicationAfterDispense\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medicationstatement-card.html\">PMLC MedicationStatement</a></p></div><blockquote><p><b>CH EMED Extension Treatment Plan</b></p><ul><li>id: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:cb13d6de-051f-4a3e-ab85-c05650fa254e</li><li>externalDocumentId: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858</li></ul></blockquote><p><b>CH EMED Extension Last Considered Document</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858</p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:8ba8cb30-2be0-4d67-9ad4-435666a79412</p><p><b>status</b>: Active</p><p><b>medication</b>: <a href=\"#hcMedicationStatementCardParacetamolSelfMedicationAfterDispense/MedicationParacetamolDafalganEff\">Medication DAFALGAN cpr eff 500mg</a></p><p><b>subject</b>: <a href=\"Bundle-BundleUtc1Pml.html#urn-uuid-9b00e81e-1165-4039-9d60-698ef838ae1a\">Michaël Christopher Karce  Male, DoB: 1973-12-25 ( Medical record number (use: official, ))</a></p><p><b>dateAsserted</b>: 2026-02-12 14:50:55+0100</p><p><b>informationSource</b>: <a href=\"Bundle-DocumentUCSF4CARAPMP004DISDafalganWithoutPrescription.html#urn-uuid-e901b242-7f96-434e-acee-685dd24aad17\">PractitionerRole</a></p><p><b>reasonCode</b>: <span title=\"Codes:\">J'ai souvent mal à la tête.</span></p><blockquote><p><b>dosage</b></p><p><b>text</b>: 1 comprimé en réserve, à avaler si besoin, à partir du 22 janvier 2026.</p><p><b>timing</b>: Once</p><p><b>asNeeded</b>: true</p><p><b>route</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 20053000}\">À avaler</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #MedicationParacetamolDafalganEff</b></p><a name=\"MedicationStatementCardParacetamolSelfMedicationAfterDispense/MedicationParacetamolDafalganEff\"> </a><a name=\"hcMedicationStatementCardParacetamolSelfMedicationAfterDispense/MedicationParacetamolDafalganEff\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medication.html\">CH EMED EPR Medication</a></p></div><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680475030011}, {http://www.whocc.no/atc N02BE01}\">DAFALGAN cpr eff 500mg</span></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 10222000}\">Comprimé effervescent</span></p><p><b>amount</b>: 40 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span>/1 plaquette<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732984005 = 'Blister (unit of presentation)')</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>IsActive</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 387517004}\">Paracétamol</span></td><td>true</td><td>500 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet (unit of presentation)')</span></td></tr></table></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Medication",
            "id" : "MedicationParacetamolDafalganEff",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medication"
              ]
            },
            "language" : "fr-CH",
            "code" : {
              "coding" : [
                {
                  "system" : "urn:oid:2.51.1.1",
                  "code" : "7680475030011",
                  "display" : "DAFALGAN cpr eff 500mg"
                },
                {
                  "system" : "http://www.whocc.no/atc",
                  "code" : "N02BE01",
                  "display" : "paracetamol"
                }
              ],
              "text" : "DAFALGAN cpr eff 500mg"
            },
            "form" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "10222000",
                  "display" : "Comprimé effervescent"
                }
              ],
              "text" : "Comprimé effervescent"
            },
            "amount" : {
              "numerator" : {
                "value" : 40,
                "unit" : "comprimé",
                "system" : "http://snomed.info/sct",
                "code" : "732936001"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "plaquette",
                "system" : "http://snomed.info/sct",
                "code" : "732984005"
              }
            },
            "ingredient" : [
              {
                "itemCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://snomed.info/sct",
                      "code" : "387517004",
                      "display" : "Paracetamol (substance)"
                    }
                  ],
                  "text" : "Paracétamol"
                },
                "isActive" : true,
                "strength" : {
                  "numerator" : {
                    "value" : 500,
                    "unit" : "mg",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "mg"
                  },
                  "denominator" : {
                    "value" : 1,
                    "unit" : "comprimé",
                    "system" : "http://snomed.info/sct",
                    "code" : "732936001"
                  }
                }
              }
            ]
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "id",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:cb13d6de-051f-4a3e-ab85-c05650fa254e"
                }
              },
              {
                "url" : "externalDocumentId",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858"
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-treatmentplan"
          },
          {
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-last-considered-document",
            "valueIdentifier" : {
              "system" : "urn:ietf:rfc:3986",
              "value" : "urn:uuid:a6deb711-dc0e-4a87-9ca9-f72bb9ecc858"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:uuid:8ba8cb30-2be0-4d67-9ad4-435666a79412"
          }
        ],
        "status" : "active",
        "medicationReference" : {
          "reference" : "#MedicationParacetamolDafalganEff"
        },
        "subject" : {
          "reference" : "urn:uuid:9b00e81e-1165-4039-9d60-698ef838ae1a"
        },
        "dateAsserted" : "2026-02-12T14:50:55.602+01:00",
        "informationSource" : {
          "reference" : "urn:uuid:e901b242-7f96-434e-acee-685dd24aad17"
        },
        "reasonCode" : [
          {
            "text" : "J'ai souvent mal à la tête."
          }
        ],
        "dosage" : [
          {
            "text" : "1 comprimé en réserve, à avaler si besoin, à partir du 22 janvier 2026.",
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2026-01-22"
                }
              }
            },
            "asNeededBoolean" : true,
            "route" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "20053000",
                  "display" : "Oral use"
                }
              ],
              "text" : "À avaler"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "comprimé",
                  "system" : "http://snomed.info/sct",
                  "code" : "732936001"
                }
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:084ef91f-75a3-4d9b-9ce0-3d30e807fd9b",
      "resource" : {
        "resourceType" : "Binary",
        "id" : "original-representation-pdf",
        "contentType" : "application/pdf",
        "data" : "JVBERi0xLjYKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS43Ci9QYWdlcyAyIDAgUgovTWV0YWRhdGEgMTgyIDAgUgovTWFya0luZm8gMTgzIDAgUgovTGFuZyAoRlJFTkNIKQovVmlld2VyUHJlZmVyZW5jZXMgMTg0IDAgUgovT3V0cHV0SW50ZW50cyBbMTg1IDAgUl0KL1N0cnVjdFRyZWVSb290IDE4NyAwIFIKPj4KZW5kb2JqCjE1NiAwIG9iago8PAovTGVuZ3RoIDMxOTYKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgNDA0OAo+PgpzdHJlYW0NCnicbVcLWIxZHz/nvcwkSZmaCqWZqZlKKXPdfCohlSLpIhImpkKIQVddtJHUIrm0hco9kUutXHJdYhf53JZdD7vLuqy+x34WX5vm7fu/7wzt5/lm5v+8c857zv/y+9/OQRghZIbyEYlQslafBiMroFJ2Njk1M0mqX8KOKxDql5Oi085xLc/8BiFLdk6dAhMOcwU6GIfA2CVlwdKMWoVZMIxTYVydumi2FmGnKwj1N4NxzQJtRhpahS/BeB+MndOW6NJSeKVFMIY1iI8wwj09qD8i0HWEaDldAFrxEQq0FlkLRNYiWv6hKpy83q2gC7rygL6nXiJE9FQhRL2AtXxW80BSghVYQpI8Hh+LSKkUx/9xk5z0ALtcDKvmD7BgNhP9k/gWuJqZw3LB1WRMP7HQUES4S8NB/uKeDvoWvRkNAU52PEoilkkJlVKjdlHIKTu+VCoR83mErY1QIXehzq7LZc7daS4qKp07Fy979gAP9Wlyad9yYm3p5h/PV4At9VNP7w8NwRaH37e1PWjepUn7Mi6OOXPryvONYC1GOpD1C8gSIRTkjKz/rxS1RiPSiEgeRTxj2pnDIKig8xEerDnvemHT2Q0bvu74oaQ7QcHEOxMxc0qZizb4C+zQ9e2le/t2qfX62Fjm4s3bzyMmMDWMdcZCVmYA4FoLWFmYkCI1gBaWYJwy7yy2PltcSlS+MwwgvH5l3AiR4TFdYJhQQMgNJd3viDrTfl497B9i2i8QCu3Uag0WYYkAnpYEH7CXSmU8Hj5ypR5bd7RSVhYDlQMJd4yY1w1NA0SWTirPAYaHOSdIW2uqP2X94TVd0O0tSI5SzVeRV7vyyJrpm0cEpEwe0h1ONlmWrXBKAB9zeheD3P7I3ihZJLcTCm1teKw8jVytUkolIhIvWgxWEHMqF2nn37+NLW78Oby5ZVMFE6MjQg3H6QL1sJ3zTz90NOwhQrdsWZOWYehkeQ/r6aC8qInIC/mBJ8RSlVKtkfB4Evafi6uG4y3m8WVqtUIOIvkkj3ONhg9Gcn/AcHYAP3JHQgyFeVFHc0sbcR8sfiGYNyM9a9BRr8enD7QJxvd1d3McYikaZfDWTtBOnJhkNagtfbXU1dN8QriVs1Wubt/KE2cocqZz/JSYKY4bi2pWj45nVsmlri78NDMz7BY2w8N91YQVFOniODgOcTE0pqeDfAm6D0ZIB8FiR4hYrTWcqsZIYtWytcJ3k9d7VGcxJ87dCA15fWj/JfMjvNT4jbVu5uZZev1wpvXHS1cPNOysr3DQzj1+drjOh3mHWGyCel5R++lraBCgY8TGxFsBRgsUbJZJlCxaMrnGn+CQ4luyoYs3bGv09390MLvKmeZb8ic3vbMU0A22dGjd6HNakbdD3uKsYO9g2Qzb1t3fnTt7PGWGe6Qb3vlBMC7NXbFgZuzanepN1aNWrA3xOXk7NjvHpEsHJQNbHdiMCeTxjflhZ/IUlz2se1xFGs5hGPHIolXa7Z4lob/UXH0cHIyJ2utP7Q19iDiqIHPVcfwfcUTRV7OiAgozHn/XVrfjyI3TKbqSkJwvDwCuYqgptmA34Bpo8juPT0KMq5TAmv2LOeNxXtRefcUm8755zbkDjkWv0wmXH8POTWF97C3JAv3U8hLnyXKDniia6rd3yo6Fhjr6GpMr18k5e8AK/A5kGGscX6IRgAD8TtwkTrp97BZ9raGBWfjhMjWC9XPvWhTIpus75jHIoa91KWHSqC8vjJrAekkr+BixrL4ahQ2oqWBtsPsUwJLeJURFjkN47NKDg5Yf22MjqDfvR5OhG5M6HaNqU1ZvsM07yr1tGLycyMpShkVcrjHsIqNmFvODIgcvmfZiZVJ5SYAO7ONeXqwx1Jp0oYSgi7FGsGWhV4fPcMThy5v2mAvMObmfIUnMMNSRUd5Lx7LCPoeSxQ9in5KDHCsuHmwIvjES1MYI5Vt9DEU2StRqSj5pfNj9km+f0kHjOo/fenSyc3WkeoJ7flbyCm/vfxAHVjIvErWJHd+3V22v+6kNOwUNq22Nq6gaFzr+CfSY68wUajjEnhipuTyQScAOHsHnzPvcQrYQALYm4Rp/EsAmPNhMoChK6X3sL7oPRZtRe3lmJBVal76t0c/vZ+nssuHOPpAWOSEuvm62M2xSZtCiQYOYP9/QPHsfe2f/IQMC/a1mxrbuvtZ65gT5Q2SkenNV4Iq14dLcLVv8IEM43InXoCNbIaWmKP2oHt8UAsQND59xOdNsFjbV8frxQI/6QWbU6PxoTwVZ3093KM1wjfSXBIkdfQfvVxalWnI1hoYac48KQ0NZlFmIZRqhUOGsUsqk7Jetl73VBky2475Ccm3n74euu28UrV2GJQrlroKAUWNf3D7SJtwpzErOKfJwc/sqf1RgMPara1yW+0XcpDP+Hu6KoTK3+cEbtuXlO0SMiwjx8LWz83Jzd0/j9Ejo6SDyaU/If1MlEkg0CjBNwZf0lmQsiNH2z10xMG9uhveVgVdWWHh5yfwEs22SojVhxLrCN28KDdkjJZ6elkX2LE/gTCVCivXn8opUCJwIOzsWMUwlGirvfnNKRwKM1EC7YfY4nxrBpqNhlNB3tEyl8o73JC6wcTgV4jAR+rg1kgEXCAArPntygGrIgU9CBFCmdLMkQU/i4fH2iROZX68133ALV036PXLLLGmgwkWQnhqe7e0z4QvHdHrz+4c96PUff2HiScZfv00rLut6Oc+jYFv93rCqapVKdbD9XkJVNau/CiHyMvRFc6j/fDgpCGiNq4IkLzt1lznh5JvMFgnO3PO2srKSGva46bcPrM09b8HmGNBXZtwDSvoTGk7V/+l0bCBbsknFJ5sdu6fba4rHy3VzfIIhXdQr5i2oc61Xd57KaklWiBcdK9nYPKyyMi+hfKRb0Cgnr2kKRWZ4YmZ6umv9sak7UuYmjspYNSVha4ixZ/kAXlqQ78mi1SvTxVQd+EJjCrFnLy7SjGskGkJ9vDlTl35AfHQE7nvq1P3zjbiwfKTfb5V5s68qdjkdzi7bsbkgx4kcVF6akJq1yPJkc0tN5Xk7auC27JxEbapn/GOfpWWbctOyq416sH0/w3iW0fE+xbVJI8hsEV9EmjKavDLmVe2JZ547h2xftqepZOnO9MMXSJGjoXCJfH1Uy68Xkhft3jV0yaJTDVnrdcT7SibQw+duUwvEhh5k6MFWJ1P//NSojOlCkJ+gNh0mTE6AISHMb02KjsLi1s3nJXsclkTueqYceXyxvkE7eswrJrN4SUJ5dHpawsSI6TZZP65/86rDsK7YJTKOeci8nzZzVn3a1vyC9fhE4e7kpiX61R5Dqzmb74Dvj4LNEAhaCet5kj1fGg8vxh8+dtomwMNDu+ZSWXeXI3l+cFrl0KHhYrHfQFVE0oXp0xu/fVtbWV54UqOZr1TOVc17yfWycWBnKNgpQT5sb+ac9+mwwLoVWPP/BvIAgdJULdjzE7lyzP7k9KnTEkePfl1ReGK22N9jVMSkk9qvz0q32y+P3/44qmRBRUtu6szJ+4gGXZJS0bJ4a17uev2d8uRHN6NzIyLHl6z1ipmORUR8Zvn91qxVihTQKRIMfg653dtfgfBz94vuDkDUiPb27k3t7cZYmMXEkVOglUIeBSJrK4GEsLZCruQUw5n2Q/ewJ3aExk0aNEw28wOW4S14KZH0kM0lXyaO8IF9fREaA0d4QqYYABvpNmJ0csqhe8wd5gkThw3E1Qs4roJ5wMxlSg1fP4R9pVDLXvb2c+KlYWwtcRb6uTP9M4I7EHfWoZ/ypCxn0N8VJ6He+exP81L0b07/RuoIUUw/RTTHD05mRCFTMoM0PKDbmN9t8BDWR2uoi8QDOrsXDwkQ8UByUPJPSaOEzm6BD8sLKDo7v1Mvmtl/5DtEslc3hB503rJjnz+lmf2r63D3E+EsszjgyQPCyIgh4vszE9EY4dGuw12xwlnkC3QX/f0j4yF0nfCFk3xsTxXdhhbzfJGOjkUBvHoUAOMASo+GUQAkPINMJMZtSMQSrBGzYyB433OdYMfACvglwDMN5qcCqeDdW3j6cLz0SA90B2gcrIuEPbOI+h5fwren9KMMmGsEWmPS0dNEGUBPwSg4ZuOtAB7cLAm405JuQMWQQzZA+UCwhoZ3NEQ9fRrOYC5A6wEJJRDcoc1gnVkKUANCfWBvn+lAEDjmc4DgztsX+Pc9jJDFWCDoRRZwL7b4Ge7aIL4f5Gg/4Nsvmr17cyjL8GQUDT2LZ8L844dCRAvuKTpMlaH/Akr4bKANCmVuZHN0cmVhbQplbmRvYmoKMTU3IDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/nzzwAwBvFzjBDQplbmRzdHJlYW0KZW5kb2JqCjE1OCAwIG9iago8PAovTGVuZ3RoIDExMwovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic7Y7JDoIADEQfKogCKqCyi6z//4k2bCFwIUTDxZc0M23aSQGFHbCn5dCpKqXRc2SKLnXijNF0JlajF67csHHEu9x5iD6HGw+fgFBcREwi+prlriVdtPUmW5iXr3/lz5coZpNygy9+RzXy9QdXmALmDQplbmRzdHJlYW0KZW5kb2JqCjE1OSAwIG9iago8PAovTGVuZ3RoIDM4MAovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnicXZPNjoIwFEb3fYounYWBFgRMCIkiJi7mJ+PMAyBcDclQSMUFbz/1ftVJhsSc9NCvva2XoDzsDqabZPBhh+ZIkzx3prV0HW62IXmiS2eE0rLtmsmPBKPp61EELn2crxP1B3MeRJ7L4NO9vE52lotNO5zoRQTvtiXbmYtcfJdHNz7exvGHejKTDEVRyJbOwq30Wo9vdU8y4Nzy0LoJ3TQvXYin8IyveSSpEVGopxlauo51Q7Y2FxJ56J5C5nv3FIJM+++90BFyp/NfQLnAEzosWGpIIFaQMSQQR5AZJBCnkCUkEG8hK0gg3rFUEY88VhoSOY8Eu6vqUSBL7K6R0ygpySBTyC1kCbmD3DNSbBTh0B5pAplArgFcSITFIqwSrSCx2ANrlomvBYg2LFOUlOKWNOrMcD4PV5mTKuZjeoQVr6lWHPcIK75PtcVMINzGLEve1iPcZNwFj3+bO+Leus9+a27WulbjBuceu3dXZ+j5DYzDeE/x7xcoz80kDQplbmRzdHJlYW0KZW5kb2JqCjE2NCAwIG9iago8PAovTGVuZ3RoIDQwOTQKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgNTQzMgo+PgpzdHJlYW0NCnicbVgJQFNX1r73vvcSFAQSkgCyhrC4YiUsogji/ChuFHFBcVS0WqOlSsUqwi8ICCKK2hZwUMQFVKRUARG17gvgAmK1av3RundaV4ZqSyG5zLkvqTidH3LIu9vZ7jnfOQ+EEUJmaDXiEFowJyEeRtZAG9jsgriVHyctEUbDcx5CcoVu/px5nlkrj8JzGcz562DCPsfqBIwfwNhd9+myxF4OdpYI2fAIYT5uyUdzENENQUhhBmOzT+ckxqOduAYhJZPhGr90frxOsiETxh/AWIowwl1dyAoR1ISQ4COkgVZShEJlapmNWqYWfDq3jeea9FohrSMV6Ar/C7BFOq4eu4p7USin4bCrKlcppNEwfByYwnoqnUaKhUZmV6gnIX6+cnmAVkJkCrncFremlH4YWbrqwPGD43em0GnZ2BOPO30ej8eea6/RAfTZUVpLb+aKfCyAT38jn0n+crmfNfHSquRypYIQqUXKzvEHjx9IKYmMLAE2G3B/POZbbIuvf5dN/4/WnjlHD9GWbKM+alJNDKAv+ClUynFeAR4BAqflPGwFUrSioGjFSfrzQGxukd0Lmw2kP5GOcEy6UHj7mKxPcF96Z8GaMcADTMMpqIXZPF+p8cMp51taWmAedb0ggaAj8wXWYBJIF+7G24TGDlcBroigyK4XvEYoQOaoN+ywJho3IrOWq33knK+np8ZNIlEq5Cqtj5zX/PHrr29eYvTHyyPDs+IW54SEZi/akUfO0h10A16KP8Kf4EX0S1rY2JW4vOvqxS6UhB1BfhFCvBXY1pPppfZTywQ/D62Mt9Ln4gX0HJ6wt7CwkA96XP600070xQLYbwH6aIz7g0mAvz98/HyZMlIvf3+tj0qpkEgl4oe30M/QflEa2We064gPs1cm5Pc6qvj93M2n48Z6bNQlZDsXFqZ+XrM52AV+s6cuW73qM9n+i5eORe2e2Cdlyqwto0BeBNhvD/L6gPUKicbN0ytApfYR5Wn8tD7/LVipUvH27T/d6rL71h1bZW+r2vfx3LySzIwVX1kcBtnfP9+yubgSZ56/dfakrCNrTUJaUdrSzzKSllh+c66ucu1+Z15Wzfw+COwMEP1iw+JZI1P7Ya1Mq/RQy3z9A8A07rNyg45knqzXF+M2zNm6WeIQehaHbOBq9eM3biQ+3jO8BwQomM+iwAYn4OXMbEBGG1Tdumts1Eo1x/RX8U709+d1ba61Tl8u/6J0z4YxKSGVgzi1IcPh8wPrG+PxlftdqKJEqVt4sDCz1DuA/FZIQ2OW1IO+OpOfbJE7k2KMEwQ8baWe7Fn0j1QUqFSI0nn7tpuv9FjStvNS3wrfmq37B1cnnH96pCArZdvYtMnpebjpPqV4Lo7Ci3H25k0uFfQhbZ0x+82twr1fpcWVzT4oxsNCMR7SxFyVEKmEKDW+8gB/eQDEEm8RVzhg+vQTQ0cEHUs3mHMl/Os9lM46TvPOb8DqHfl43IlC5utY0F0OutshDxbjJg9BUNtI2I17+vmC8vJ3yoPu/ryc/v52T0P/Cv+j28r5PueWpZzQtd973nahKCO9oGB1REYkuUfzadL6bQ6V2BWbx3y6/NamewZaerC8uWrL1kPhaSBXzEl+qAmzICttjJl5/jw/tLlZn9/czPKfIMBGIQpslIpWchqsxYBaLAbUnKcnjttdT0LuEP/zu+hp2SDFIWJ12NIbF9F5DPVwETdlyDpf6oe/06xm2Nf1QlgJtjpA/rja2Ep4jZs7Qzh3rQ8PVwUmIsA5FeeK++QXRdO6a7do455S7HvrIfYefXjwnfxnVJ/8cB32iKg9VY3HPHiIR1ZUfhOUnE5v0I4KatgE+gLWC/NB3x5i7CoIrwEsdkWcNVLDA3hPmP8NvdJo+Be+jj/GmWfYxdJ/4aHb/7maNN+npw4AGBfSw1iCbTqrcqh4z8CTp8DTXMx7mdpEPO0s5wfqv+R89FeLioS0Ihq0lSpN+78QdTBmj7gfLzjN/aK/xcnJMEMdbDa8KRYxBXyyE3wC+THfxz/Aj8GQyTGgcrdfrBE3MOf1WDqDTImnx0/dpecqcDye8Ay7f1gbdGP7GwhX+drJ4XQn7b10FXMOjsaJxQf8ExfTO/QNfUuvGPHctesFpwPdZAiFdSejjIlVSPClQ9+7HZenzNYlgk+aflQcO+ayLH1TDhdWpNc0PTf5Qggx+oLZppVBQAB2g3Wnyb6HhjJS9tLQRBwNT4Q0QzA5ZyjSPyZlJp8MgnOC0YcAs4P0K08zt3U6mPhKCKw7mfhilcoWABZwR2MCHZDCqVQ4qrwTr1B4SCSOjhIc/7ZC4O37K2heFt00nQhchX6ykKYfNGyts8PsaZbcdx2pXEVEQfj0XB/9CO4MthtXYLLB1VTTRFmefqCQBovcfyQdFhU/GSyJGVemnwbqhddFc0UdqXzlyDUQX3Pgvm7DfVkhR1N8dcewXMryV4xhrQ8Sbn9N62//QBv278OBd3/AgfvP0z9a22h74qPiN1ggDY/o0apKHP74EQ6tKKenn2ApHkB/oG8rqSEXDzTGMv9M9LUYywAIahZOPrzU2hjM/LPldwro3NNk4kvMn6FHaSbO2LmTu5N54RNDi5D2YyOWGb7PFfOY2czuvRdSmaLSh2clg90dgIvIDi6RbHmFuSO78Oa79EsctW87HYabtuwhYwxHhLSbp7bfcjTsImNwSXKaod3YZ8wE/GoHf2iZhrzalXsH716enl7exItBmLtaxGIThtnCr+nDt9Nm+txgiDrmeu3QsUshgYHFsUvyY918/LASk1aqPeFyYOv+6rDQ4fUTi0f1Hefo2Z+VL/yxR+qK1OSwqY6Onir7D/ycvZM+PHzhqyp1/Pz4JaFTnJwG2PR1kQ127bdU1NEb/FgjYpipmqmV5Nop6shn8U87HfinRUXG3IB8FSbAPgtjPyLGIFR4LEwwnK03nL2Es+y8lIoBCrzG2NPpXYenBAdna7kHxvOL+CoiF56wGAdExX5aIp9Fa5v5OgVWOcEdRIOvEvgIqFJaMfsA2wMC/izi0NeolDKG8AFKEfq9NBKJjZS1EiLus0YDF5eU3vvt1/jElYvNT3jjNY1X+w1zdHEbpZk3QyIJO6KvSxk5ctTsafPGT5iuqCgoq5Hww9YsjYqRYffjVdQ7cqI03sxsYfz/LiD9eGxvN2/itNiBA7dPEnUH3bjLoFtvphlrs7TvXxncaICtJSF9H79ufbC3xfGY5dKFm1Znr4tNs6q1XFKlwC7YBsuwS8UWy5hFpx7+cE0XZ6HbOhlsngp8X0OPZ8/q2xxv4qdhxv0pQOsFiQcRgRXdPQH3N8hj3mdPUtPZhobkUh9CajjO4J64tjAnZ0v2SvPhYx11MViB7bADdoiZuxKf7bSZssSBOD++8P392xcvGesW87Ud2GMj9o4mC4jaJFkuU3qJtkmxYmve57n2xXNoWWtn5y+vX31rtXltRqEE//7t5VnhA7sQdsa9sQV2pg/oQ7ucr7cfLBT9BThFgoTLSGmMKejHxEptqxQ9ptQq8cKaf/wjPWuc7weuYcE3uCP6MdyRjKS8dIt1ZqP+PieD6TiVRnOv+XHQT0LHFdqNxn/xkS/EoFYCsSGxea8NIO5V150Py5PnZa0l2uoVDccvNSXs9ya8hHwteTRo16qclOWbVu+i0etX9x43sXj7Ad1CbAYec8GyhXMUU8bz/uX6uidPuPq6xxcf/HjuPrNpI0LcK7gr6HZDjT0lA19RpAj1CobCw4eWrKrcd3hBYmphTQ3PYS5t0UdH6g2DyIGv0ivzDelCI03pMz1UCvatA6bDxf7+zx4D2ODhNTU1QmNFBV3cWQ8NCCJdV2m0aZ/cuI9z8/IzFSYmFY4ERQy2drYOG1KTyI62r++xnvDhOn5P54jCHPE+4C8ONr1LMCnBIKPDFyZgDV5lJBqIhX7GNYAmrTNRakUTbbX/ban4gEMPcVw54Qk3tCAueZMjN2THZ6X51VPjl2fAn4QskmDI5SbNTlCqRoQ5J8TM/eTT2OorzA3bEw/uMuSy70qjbO6VMa+6Zf9VKB5Zw2RxBHPBJSur9xyel5xe8E6AzdBRnvEzaxsY821J1cb4nsr6auBrDl1v97uRVnw3ehcjvFPHq5dtv7a1PzuZub04d33+7vXEmT6hz7AastUO29HX9OGDK813b92+BjzX0GjgOcGYqyJPL41JyW6P/UVAQ0PHVIEH9Q9ggec/KE67WH8yKTNvU3ZhVjJxo0/p0xPSEjpdkExa4sCPmmgzbyZ0I/cenWt6evNyndE/JBvssH/PPxxICvB/l03d3uGd3TUxIz3c3YLjlxNfQyMXHJgS5j02wKPHXH8fr557ep4VYyEQMKcW8mrAe+9NfxYlU0Xy1/5nRWIfrvaf1y63qHfYbl69LnXa3GXrxqpGjr1x+dANx91WGYuTlo2cuerR4MBhuH/h3sxcl+iJkyePiOzt0sepl+fiyLxtKesV4RPGjgsYbes8WtN3CdPDpauV9BMGMIyYz9TwYzARoAVw0BiBnvSbNisubtUav8SLF7UhbqPM7JKTyPWMtrYMw5SIEEvGIxNseQ5pYs94GJloZYp3uaGy1UCZ5fyNYTM/Kb2A+Qq6i2PxM6sayXeGqN0J1cUkQf/NrGVKYXKs6B/IRu4P4NnLVOdsjL2WDfcHjbtJV5x5JXVz7GVvb/4bP5SlqGGEYsVcrymRLuQcHO/qMtYx4YnEk71vATcNOvFu3k6c9xLng3D8/zuvQffem7/xbj4EvX1vPvnd/HDULuodzlfhVlN9xYAmWtxKa2fdaRYa6DMoQWJeDOTPkxghuRtzNEAkpuTpHiH5KPww/uI7jaQV+MtF/iNwhMgfQ/3eItxgfcAk4A5vRF4aKX7W+GBhC/mZhypnSdsU+/cba73QQeSSVlOt92C1fim93CyxVNxxYutAk5PptZTDs62C3iLOjGUtutN+3Z59t8Sbvezcq3+sijWbBkMJ6I2RsYdA0mAagf6mqu7c25GkijXNd/+EShBqIoGwdS3SkXKUCmTBOSE1zB1n83wCigQqAloAFAE0CCgKSAe0ECiW7RWmIl5oQDqgMngu4x+jMkkgnEHIVRwnwLgc1hrE+TlszrR3Juz1hu8eIHsR7IuGM9HwPZU9A28n0/NG3IDW4Yauq/CdA7yyYS7btLaGsDFCgbDfBcaZ8CwVef2FYF840ECmL/kaYRKDFpl8McBE443/80N3wSuuQEOAwK/4KNDPEBTwTK5BzEPHzq0Ggmjig1hPCARnhD5AG4CgjZPAW64E1iQVQC9AJYhw6f8AVQLBmN2XWSmQHqEeO4EuItQTLrcn8Oh5ASFzkGEOupi/QcgC9LCA9V5QT3uNAFoDBGcsYY/lMiBYswJZVpsRsoY91n8HAjnWrQjJgKcMbJEBD1kkkA4IdJTBugzOyd6w/3GK0RGKo9BkFAtR9J+xwoMDcFdmJZ+L/g0hfAxuDQplbmRzdHJlYW0KZW5kb2JqCjE2NSAwIG9iago8PAovTGVuZ3RoIDEzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJz7/5/a4AcAkXFSpw0KZW5kc3RyZWFtCmVuZG9iagoxNjYgMCBvYmoKPDwKL0xlbmd0aCAxNDcKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nO3M1Q7CQBCF4R93KO5W3N31/Z+KSeGiTSGQJtztl+zuzEnOgsGFmRsPXnyvzU+AICHCRIgSI05CUo2kpZOSkyZDlhx5IylQpESZClVqstdp0JRXx65FW+4OXXr0GTBkxFiSCVNmzFnIvGTFmg3bN32rnWnec+DI6WvH7szFQevp6rj52e0PfyqK8ov7A4pRCCENCmVuZHN0cmVhbQplbmRvYmoKMTY3IDAgb2JqCjw8Ci9MZW5ndGggMzY3Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkt2KgzAQhe/zFLnsXhRrjNqCCNZa8GJ/2O4+gNWxCGuUaC/69pvOsV1YQQ75MidnNOPl5aE03Sy9DzvUJ5pl25nG0jRcbU3yTJfOCF/JpqvnZSVY6r4ahefcp9s0U1+adhBJIr1PtznN9iZXWTOc6UV477Yh25mLXH3nJ7c+Xcfxh3oys9yINJUNtcKd9FqNb1VP0mPfumxcQTff1s7EJVzxdRtJKlh89FMPDU1jVZOtzIVEsnFPKpOje1JBpvm3L9TiO7d/hsAZnqI2KcMM8AAYM/R9XvnYUwVgDojKYMdQaZRAtA8YAcKuA8DFh3SdMQxCwJglVIC7RwLDiKFefAiK0LxGkMbREYL0ET4YopxhiKAQZ8YIitDgIgXOjDcogRT4zBg/ZJFiC6gAEVTgi7boZZG9BiwAIRns2R4rSI70A/qEqDziu33cId/zfSCfU1RfrXUDxGPLk3Ofmc7Qc7LHYby7+P0FgRHFCA0KZW5kc3RyZWFtCmVuZG9iagoxNzIgMCBvYmoKPDwKL0xlbmd0aCAxNTAzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGgxIDE5MTIKPj4Kc3RyZWFtDQp4nG1Ve1CUVRS/93stKI9dlm93lhHcZWFRQbRddjdiU0AdSEERMXFMAXmmyDNBDATzwWCKmpUmAdkf5oOAzAdmko6lJaD2MEMKnTCVUdNmzAewl879duk17uz57j3nO985v3PP4yKMEHJBVYhFKDutuAA4OdBmKs3OLcvKuPm4E/ZvI8R/mZOZlmGoLmtDSEgGmSUHBJpNnrXAbwM+IGfFa6vmviW0An8Y+Ljc/PQ0hMy7EJIBixJWpK0qQEUY3skSgNcWFGUW5AibNwBP/coQRnh4GHkiBnWBPyO/FlDBp1EKnUKpU+h442BdHNs1ZOLXDlQCdXD9CHRrQLcQdF2REnS9GU4PulqEwwx6vcJktFj4whbScd5+FhOcgTeSK3d7vh2oPJ7FdPxKTu3n15L3yCd994diSq9SlA57crA32mFPEKg9hc7I8WE6ulp4ecXNRvIh6WbK7FhBrpABchGHr17Pnqn5vpTAp/1Xe4m1DEE8aoS4LrDljEJn1oksT7pJOHeUqx9M5+pv3EBUL5prZKbyvYgHPVGPzTpm6n7ShBmufSz2Dnbgsg3f5aq42SgAmRCa4W8wh1msVjNE6S/IAr10RpWo8FaZjFYREPsbgvSCoJQJMkEQJanFYsY19a09l/pnJs1+yZX0WPHurt7xk7V+YTMtyzJHCRGHLm1LHzc+OCYi2mqZ4n2wbl8zx1mXZcckeuCo85+RkkUzhF3u7jmZy5Yzrgwv94q1xc8KCKiMofgTAJsVsPlQZEghRyajSs0bKDbJvcXKezBM4iPyEHs8+WJAS35zS01ekZufl5Drjn08113yxoFYwG44+NR+j3npR46eOJGZ4V50MAXiTgLbr/CdSIMCEUoLZcx6GiCjkHtRJ6YgOFdvlRpLbhzHwcYxLjwX2lR18kL3ueKPJjIM1nCc3Tc/L3/1yqLCvFGRcT5Ll+Ig7IrdcWBqyiH85qDWWDKdGdPWduZwy8lj0nnTmCZCTEoaVZQzCkbnDM9LIQZK8clw6crcmSlK7FpMPnhIBvCoh/2PyAOXvMXpy1l8q2FPVKSaXMU6LEJ4WtJBfnRpXbduU7mUdz04aobYREd96M0myKrJqBalkxNNIu4mtxsa3m9MTB03ITbiMls+tJ4tby/cUSs/4hoeO78dcG4FQ/vAhqNXRJ0ZgyW8j9zCGnKL77x4keQNnuVekPxVQ282cHPQBIe/MEOQzo8RTRaLdJTSIkpy6n5kQ23xLHZjBJ4Lq8st3+kjWHeXNuwl/YmJiXn0OX85M93+ORu7ID/EbeFisbygpGRN3pVv7HOZlK21jZvtLXRtdvjnMsC/zzP8P9NfeFNpUxu5nZqWVfE/Fz90Osy3jORqB+RqNO24KDlyZMk5BUZqkNtBfibETq5jLWYh95CWNauqqipK3ljL+JGn5DIOgRrkcTC5Rv443Xys7cjJ4w7MDAHMmn9hZgGz1fJ3pv5GzHEsN06nTY626KaZX13JKO33WNvC0lDXKfHTPQuemxTiecfzANiMBbxjwWYIrSyOtqtV5azfoFAmyGCQykCllo20kFpF/9xYMtx37V7QYzG7qiR3Qc6cioVj5i2433P6ju9TtyVZGRnxiyq/skXEYFv9p1veCYyPtEWGvSjK/Xzdx1ctqfv43Vqf6CiTbZLVy8dqMJQCDs3w78x2/nlaf5l0aphpCVpNUHh6xzBhtmdVl2+s2Znc2tVlm+oXKfevrmHWtBPSbr8wZ5YHgnkt9QnfKxhgAtMpzqNfpFoDSnp9z9yKiBRP25+IdaFTDHU/+U5D154Cl3uDe4f6VKkuyaArQA6xpABP2RQyG01THRrcO7BaleqU//NTCgh1MeEwpc+hGv5lVMP1ITVzAGZoMbIBJQCfRFeQ6UFvq8wXVYOMUgJL98UoFt5pqI7TZoiTaFd+DfQAgHgDwV3GuAGtB7qNEAs6LNx97E9Qx5OB4J7krgOSHKAmekdKaJU4ESWhVIjqv9g5hNvw8IZWbgv6Cx6U+08NCmVuZHN0cmVhbQplbmRvYmoKMTczIDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/HxkcAAB3WA6zDQplbmRzdHJlYW0KZW5kb2JqCjE3NCAwIG9iago8PAovTGVuZ3RoIDU2Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxjYAADRgbqACYc4sxQmgWHPCsDG5BkZ+Bg4GTgAotwQ2V4GHgZ+MAsfgYBBkEy3CQEACzBAKwNCmVuZHN0cmVhbQplbmRvYmoKMTc1IDAgb2JqCjw8Ci9MZW5ndGggMjkzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkd1qhDAQhe/zFLncXixq/NkuiFDcFrzoD7V9AE1GCdQkxHjh2zdmXAsNyGG+nJOYmahubo2SjkYfVvMWHB2kEhZmvVgOtIdRKpIwKiR3e0WC8KkzJPLpdp0dTI0aNClLGn36zdnZlZ6ehO7hgUTvVoCVaqSn77r1dbsY8wMTKEdjUlVUwED8Sa+deesmoFHInRvhDdKtZx8KluD4Wg1QhpEE/4drAbPpONhOjUDK2K+Kli9+VQSU+LdPkhhz/fAXSH3gEBZXG2QXrFCyLMAULbvk6EzRskuOziy95zYp0JkVCK8IU4Q1QpTiGmAe42EM4Q1hjhAvurAALwlWKM+P4dH3x4UGbJM62ssXa31nwzxDS7dmSgXHyI02Wyp8v7xHlqQNCmVuZHN0cmVhbQplbmRvYmoKMTc3IDAgb2JqCjw8Ci9MZW5ndGggNTQ5MgovVHlwZSAvWE9iamVjdAovU3VidHlwZSAvRm9ybQovUmVzb3VyY2VzIDE3OCAwIFIKL0JCb3ggWzAuMCAwLjAgODUuMCAzMC4wXQovRmlsdGVyIC9GbGF0ZURlY29kZQovTWF0cml4IFswLjc1IDAuMCAwLjAgMC43NSAwLjAgMC4wXQo+PgpzdHJlYW0NCnicbVtLjiy3EdzPKfoCbpFMJj9by4DXthY+wECWDfQYEAQY8O0dEUmyat4MDHk6qlj8JJORP77f335/+xv+Sw9Lj4+34c/i/PlaP/+U+P8vvL9+6fW/3v7x9h98+NNffv3vv99//ftf//z4+Ze39MypPNIzTf3Jyefjl5/vjd7/+LbRH+9vP/32R3789sdbfeY28dwwH3sOx8+WBoa0Zxu18s0o/WHPyq+L54bfuSYXao/3t4KvZies3h/l6bMQWR8FqFpeXbJl6c5uhpvjXUk2Hhm9GVsWvASqZtE0lQzYS5l82Y19p4zuolM88+hUA+Lh6OOxJlOeDZ3vmQJltMQa8pxCE2LH+jy+m1zf0IwaJvZOoXghdneJYqZR2XfL7NQt84tk+QwBlLNrOtYOxPRDCO2AvcBA6VlT5UA2srY/V/aIecVvTtor1knY1PEskBZgSqU+rt17h470J+WKEbCX+D06fg/3/OjPWnvjMBlT7hiAUvDJCTf8cI1agP05+swXslFvbR1aNKMfyLo+Z6saozvbJujWWd96mZ5zJr3khwmLwapXt9CY1KLbMbAY6Tymwhlh7zfUdE9bLMXq3D1hlW2OPQoQutkzoDy4bVseuUDz8zM1aBLe2GSvvdjEgEPaXetYEpmVk7Xkhpd1dk0A+g1Upg5CMbVMUAlBqCCXMXRiqNf+7PdOHXvTjCOamtY6ObU0nE0vueEN9JnK0lPmm9i4nIV67aEtdcltGhXaOSlMZuYm9U6mifaj+u3peFZ4DrmGnlLWZ71r8fdOIZqqEdOkRLMVqS5EQqmN6TcBZxzeFnpr+PhjP4BKtM6TQ4yf7I5kAph64kmqE0SQwQQaqxeeCNCEFcKZu15ioyePUhFKPm/nbOKjaXqb82PiaBeetDFwNOczS0vRnVoGmt1ItJCh/4A4/5Q532j7I8byqV6CrYuHEjR+Pos1kROGnpTflBhT06huYi63ybe9VrGSVYDZLlbCynJv2hwqL/m2re8aoZvYEd3WJaSu5ZSCowzYQS6aUdXXPdc9X7UmvtaDLcPBLP2+ZfHg2jLgGhowCui5PodlkdjkgBWzFnnHntWnzTG0Z6PxLQhmaFfIRGDVkm+bhgfqZe0aYOYhWduW0YuPs28HxlYBei7+BV+LWx98eXC2j9g0+dSHhk9dlsRck7U8JHlQREzWSWFkP5xBLqbXcSCWCkq6NYcoWqu7t8rnZ6QKKxMmYG3MevBpZwY0YLBRGbEz50EdtMgbYytwfIGydn52tunP0EUhDIATL02Ntw3DaGrTDyIvqiEBTUgm8Ya2QMLosfqaYtcCOwSQ4v2gBAat8pQtylUTchdVqzXeViMCQ3vMPlWTZ2DwG9AbyGwGsWuw5VPkvuY/5CoIczVmy49YYInpPSSXB5+0QrHt90AvobLOcHTUdEImpMUFl0aBwq1Yo8KU8SzWbJpVCqk6DQJlXPtGEghUId9eTxv9fIz1tn7vHLM0jUw3QLvXNS0o1dpMzZkrKlAcLbgMoyoUOkISps4oIJZB8Zi0DLLgKaS0QNOA9J22kSq0OUMOWiYjwSTRtJBe4RoUmqu2elbj7PoYJ7fwbRqF0oMBGoT8E5qjd5ozrJBecS5YX+ccolvS1OoWRoaHp9aqfuDPEXrnecSEs/uG729akGhvv4cjVs7XIYzTd8iKdNCWcPpyBUuWNGrO4hE4Nks2QSKaF6z6JpU8uaEcphyQcWakZgsnnvLH/k6HY/judkOtoJYUTyYPIvg1lXVYwJScdHjXsd8gj/V9sPJ6wPcvghQOk5BBZ0Yg/G50C7WnfoPdaVs2lql57U5/RNNzdAvb5l8wPE4Svh6U0r55cL6AxK19hS1/avwJygPbndGoQhET9wBwKGApg+bO6PNTHpnGSCvzERJLBaZIQlmmPHNVlbHC4VfJGMcXPVc5yZAwGCZt+CIsTq/e+wjYmvyNhXn2IeHdXN0NeoSHrq8HQdcbB11r9OybkdG/0585hF3g3AVdxHt/iobK/n0CIwJyqPH52EED50s3bocNGC7RGhE7rTkItk3SbZKR6+FKRkdqHpGfgk6gEj4v2E9TTymJjYyxFf3jcMldxqzQhNjGXIi84AabsEBmwHDtQleUIrJmg7LhK2DKi62JPM/F1lxu7hefAs8anEK+5QaWXoONNUs3yVNQsxzhS8d7BgSznK+7wsmrc0yzKJwBXVvsXimbrvdmHr42fNgYRDWG0XicGZs5FOpFmNon2F1OUZMeGQPJsTWXirSfYOzBA79xkXk2+keXU2UklnbzsfAAnqji04bZGWKj5lz2QORI2FPboa1apxQBdvWYXVbI6oXryeGmYEioBmFf8WBRQA2Hwg42snXeTsZCmc6kR9vAzS3GaS32PTCmSZ9C0KSJ1BqowgIpjsc7W2oD6RlzinSIu6K1zNwEDJcMp6LyWB83kDzBFUo628lpQ0tK5Yq2aUvyCrdxirnCCMYTdYeLGDoY0MpY0+ifvbiryeSfDz6ANtA4w/fr6sIVv/IMGXMZ8pKq9SWm5TYxG4LZzVm1nMlgJ9Pbl2Efa3HFm+8HXKtCTmPYtEHvuy0xtte16tIk4PVdL4rrbPW71rAevO6LmqZlVi7gprOBTxBRuWkriIC0AeuQ71x5fADLCfsqZSufSyGEIVRqyXYIAVjbuGn3ZAAfEQbcboNLPJJsvVG4Az5ri2HUGk4ozwxfI/AyMPKEdvM8gZwAPd+6BiP0vgJOjEAPVKduUKOsBaGt4OTACEYA8/wBXVqxGn95cAITYvlmDONcY8WxA+VwHkVH0kilGnr2GiEiRdMjttYh7IT1JLzgoOaIqEqsvihAUWgJOLsSZwgtl7BynnmHloRDwlRoSRjZpRXC7Ae3VQ1u+ndPoBc1oDP8g1bQZhujb6UlYFY0wmSOcs1Pe120FtI+gNcgwR6wjyE2J32HGhV53wi/GlUs+xwKwKDphGVck1/4fnBrZa7jrtLxYLPwgkHC1eSCLt2p2PhLj4AqzxwJGOERYIpwf3DsClkc9q1F/vRhX2BsdWwtdK7SVin2bowZNMzmXszgMG9lLlOkLurd8HDv9SDIFh11ubYHpjb3a0yQoZG4N34f6iUc5VBvZVrID/UCTrmsi3q5OG8X9UoudlEvZzEP81amHHPkXmChuIhaZ3xdYae1hryZd6FP+7cbLN7lFkVk25ng5esIbHzAAQL0km/EiwdmeRMvEOKeQ7yVBFIv4q3Usg25Tlusu38v0g0YnKtv/JAqu8z9Rrpr/odzr/Vsyp3y0egYfQRAW2ohfstrQZQEG1V5yEr4JqFkCESnRmoRiVc4fzmyevT3AL3q/aAx2ZCHNPbxPFCGkF+PoBu2BsOab6TBvMjLahVnGXBkJbe4dEw0eb3lGvHAZCVapzPE90WR24RPgm8bPWfyMWiVI9V2O2Z9mdB1BjtTT+oq3ZCymGqctRPikMoksswfNpXiCemtfAKXYJJHqWJnLkLHo6Qei6hKJMPgLSAdWwsKXJdwes3hNx9RLaQ5gcFWMnmE3NtQTO+ao22PHG3B+csjjw1EMDJW5qVoS2Y4OblbiKqVKxjgrNKG1BxFUvSzD+gz3HOHWp5j9RFwM6BA8J+TamzL3pmOuBlpZ02nHQZ0BnnjMCAg17k5kG+lMIsDgeEjrPR0Zd+lDm1sW0NFGBU06CWmGpjTsrF5cKFDgwcH7aGr6uViRU7kkKQzDxunlYn3hQ4T8kG3YEIYHS7Jlb4yZsIA28WDTpfULx6kdLxcPMh5tIsInQ59uoiQKyzjIkKuom0eDHCnQT6RBk7mCLSDFvEYeu36uij74xN8xc6HCiG7TEGPUw8KrKszVonQjhEehR8xeWiwM28zNqb8VIsJCcTvdS4WzipX8bOI+UzfMcjwA9/3EhZ+XRiOSKyRWbxyV9N4cNxP4mGn7ABYWz9lB0D42Nv/BEplnrKDs8jSdtnBWY65R1d4kOV4RgbbK8Q6TwYb0KcdJ/HAcAsBs7Ldn+C1eav5lwfHTSRuynxRQYAacyL010xj96gMGPP2Gn0WnbMKXeHEawre5gF2BjanCAHo3XYRgjIYdooQgNNSuTxFiqy3U4QAzFGRladImI9zq9bEn5R0snDm9x1cT4LgfDzH7be3yJThJ3l7JbsOilzXgiu/tPv7AiM3dRp/giez5fCNR/6CT3OanuTf4Jbvre/oJLqI205zOY2PglmluXz53CfNhQfGfONOc1EYdcddmVCEdE9zNbpdzDaAWj7eGuhsgRdB2omHRtYpB90+ekUnzC+vvM3HhelCvTZk8Fof/NaO/4t+LbIPcWBaEs/vt8on78TWQju1tWDkpJqqgYsVOVlGqJsjGwOKEcSnijEvA5Qa2a1C6GVe2a2mywVXfgs4lXryW43xbz/5LQ6Wxy2/1UjgG3I9spgM4Ba4pbcojLbTHB9vp0GYGMHEEz3o5xCKEFKCNFuKYEmppDVuV54P5Awd4O7lGhFAF7TiG0kmzTzfXs+symt8zHyz3ztXTTnCO0kMXFQ1sbF3NGbNVf1Tt1Z+uHxCHS5hFCeW/PXiyQ8NbpdOTm2ksdqpWhcdNBIp85QsMYBzlE0crMqpgqZ4GzFilOawfyAzui+dZWUIahIOmspM52YIZi6AbIL91evE+w/O7eLHHerMxK++TSPyAODRqpGz1WDfofRinooIBmvozDcXCVJ6oYQ+W+ugVpVDBi8a/CmxkGCdWnt+vt7UjCEYfUDRQWGwk2GoEFTvQSCEKPpCBmWXU7ljvIaSYb9yhJlqK7ch5j+NthYuAGiZVy8qb9KkuGBD2zdYjx7kl06DTighD5Z6WT5PvDrCFNhklTuHxDM9aKZfKHGahCg4F90zAamxoF+iplifMfsydkm5MIrRJsIJYWWV9SrWUJXoLLSia4FRbKFb16Pl2mFTeRxRoSiDZyW+YIjAcvtg/pZFXAahDDTiY4h7hNuHzkdccGitaDKZBYDOmCQULPMU4pukyQd94W0mUtbU8SlXDbVlUt1560BVQl93PLAcFQIHU1nOo9UfKttmOxdkJrlMrfWapSRrvBKij1lJsllX36xlzXX1BuuaqovQa2AOCNEzazg8pIPK54TRmtuEtbFYUCpvHAyWtADrCNVQCpm46zxRvLSHfJC1IVCB+N5Mlfnelc1PUfY3XjLReKrjqfZNXwMbnZvwZHuLeEu1T10d4YFv9RRQ5lLrhMYqoODsq9Ke5ZFBsLp+gTW7ReEhxbWCGp4ic/44pA/Nh7kqXl+qoUhjaMKN9QNM69QMoLY1NFHti9SIwqeDCMzu8JnVaF5UjsDhp4+lz4cwJqqShEwKVSCCbc6gRnm7Juaf8CXvvLHcbdw/eqr6YLYWK5C/zXI5bRRlwNsgwDZDBqpMDhaVNACj06yKceSGsNU6S4yW2cGEjvYFd768RMUZwViODDgzPHQlIsVdYjxVRAEVfnFC5FRj3iRrgol2xSrzJFqPs6yyceUB9KhWgBH0RDVcdIj4w7QndaimMHXo0W7lpWdcr8jcGWNk43EXJEhakyeM1fOmmCAVerAa24RHVHGOSlVbBScaOoYXNNm+aqtFtFZIBcFw/1PXC9FJSpG1w/AzadII/h8sAYeMEEjIzqTuklHnJRBet0nMZOJYkO7oLrG50yaIc0WHTGXS/fnygKd9Yxkscjvz1hQCj2Ol2RuRONVptX7y3FakbdZXZjsl1alUTWBCmXoq+UTdx+MaS2GGlnUhhhpFFpVeAVYE75CoLqOiKENmsoO9TEG6LOqk3EPpBEOpO29BAk8GfIW3K8PGZov7CiZnhPnp0GrjvTgRimWlv/AL3K01x0GGUurAgbSNC620Zny+euCSPY68biQNFeF0Hhkkcd7xAe/66VhYWu+jLjb6jHqlqdJSRahk/BZqOnVLy7k1U4WbRZD0OHhqVFbbBAwBmgcjN7qiUhFTXTqHxkjatpN0RubM9CIGfSWeqkpxS3m1PZarNMSi/oANUkCTecNLE4D5msSTSSXWdJgAK6cQpqSkejTeL+VeWRKuzGRR/RndEeeQJ0K8EbiIe6UvvCM7tXBXc42nDVD0ECZLS7Goe/Euhy7N0YbQ2rV1IWSy8EaPiHl6/J1KurEOG7dU+HY7QHxbLO5oRS9d+XzmNF2LSHPGEY80lssx5CI94kuxUfiA4M+H42jN8CAredbpVQ15fUPUzzRUl8OZ6RoBJjo8LBvTTawzFLU03TFV1nBK47NH+rbyFsl3T3gXUJEg+lDW9MsDcO3o5wnvMWS6skX5xt50uwZnY3BWOTahFdt5KREhd7koMTWk9tBPFrWc11m63NeVa2IEy/NZwTeu2riUNvOygPMSRtWh1IUn56UK0i62ukYGAmdCSt3ou2ypE/aVLblvgyJLnJDL5APVGlfxZPKBE99sk9/oKeabxW+8JpLmsfiNl7JLPhafkSkP4mXyG7N+4QTQ5DO2mf1YfIWG2S+TzweJ9miZfH3u7Zh8xpbzZvCbaov5GHxMMLfSj8HnCrzcLD4ezNGPwacEWNDcBp/yoeG5LH6jEKcdi99069iOxW+6tuc3k98Y4Xg/Jr/RuNPrWSa/zXWtbhv9xvPl7Rj9TgdxHpvfcyj7MfrnwbH6nRfIajtWHz3CYxzH6mMKs7Rt9BvdQc/H6DeeqnJZfSyptO0FhAhGzn7sfmP2ik77svtHqbbR96krKZfNb3GvgaYejRt3JMw+u/a6rH7j5eexjT5mmXkcltXHkqpuxC6rTyFNG8fqd96OSH7Mfi+R8zhmvjdeUfuCt9Un1PW2ZfWBcXTtWP3uUaa/zH6Xe2rH7HfeKo3bKjL7nafnZvQ7qzKej9HvrBjNuY1+ZxY4SGxZfSlKWlafd+F5xVENBu+9b80jVhzRFBXL7tOmMHHCDBH7z5HeUj4DZj/1neEo4pckETQWEkwM0pmebrSyJcw+rUXjP0OJO0Z19YAl083G8WU5uNEhl3WSccME+2qPyDZORpnrfdZ6BlMANPudesU8YAuz70tRZ5th9pkVpg6E1eed2EZ/Z4bVlxHozCjlsPose/W0/v0KA90uCU+Rryp0OkcKK0himB+PFXmX5mzE/ujSma5Dzug/7kCzEJs1gaZ7lORxnjo4hstrWOLBAlmQKiosiyuGt/ACKFjIK/wW4h7y7Moa84HYqy17oiB102sM6JF2csq2qJrYlcXiVSiZfRwinMQuR34ZfqY/eTN5G35HAFQuu++8a9av1Adf5zmO5cf7zrto2/LvxO5l+r/NVTF4bipNKNmSeCf/m38p9U2rW9aqT7r5oriqGwLrwdQK9r/h+oywDurN68ePv3kQU+f//g+k9WVLDQplbmRzdHJlYW0KZW5kb2JqCjE4MSAwIG9iago8PAovTGVuZ3RoIDE5NDUKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nJ1aW28UNxQead+GPhF6VZHmAXGpVMfHd0sIKclmCRCUe9Kq9AFR0RZlIaRI/fs9vuzO7KyPE1Vhd2aOx/bn7xx/ts/CGZdWd/+2onvZ8u5DC7x73f72e8e7P9rNresvf79/++5Lt3l4/ekKuu3pTsuZskpDx5l2SoarkV6I7vrPdvu03ZxBB1jUnb5vsQz/oBOOSd1pa5lx2NfpvH3KOVecww7nYoqfGX7QxAH/De6jfZrfU/17wuWrT7ZxPb6b3odwlbE+aIv3NperZI99h/vd3PYWfrZzGU/l8f2dHmtsM/djsT2JWCTWcVgu8/PyHtuUWEciTuuedacf2t3TxJLoQAw5ssoxawTyGngKHUAg6nEjm2nzstlrJk+q1R1noBHZuPq9G6oZ5oTma71Omuc39uk4VsY+Fdnn7uudcQyJGEPVQEFrYiIHiuOgdqOz03WarjFAbO+M6IidTL5JDoj3Lj/n8viuTY4xqi+L7W33jh63L3b7oJAwCLBFOc+Bx3Mw5vLYXn6OAeb7IAwvgwzXRXB8XpJhjGEKhFadyDS/myNrn67n0E0/tUeR3c9tnlz4skdH6m7eOpBM470YWC8H1lAD5yGgMVVeMwzr/dVetB/HXpTRiwX3KqpAUwWGKrBUgaMKPFWAmkaVAFkiyBJy9EAOH8jxA0kAkAwASQGQHIjEAQ+6jUHl8Wq94S7odvK6ssAsBprEGMoWgeJuQ8xgZGjJDIYjYVzWDRHzvgggUV2oMh8YlWECb0Ljyoi4OAFlvUWfyYmlOvOhdTAkY4B5Z5EgwnqLXlOAlOrMifb72UlYb9ErGXxCj5hf0jkvu1WCYsKNmRlYB/6g0KSwLtWZU+0bxSAKP2G9Ra9pypTqzIn2FXLMzYiA3niLPtNkLFSZE40X464c7VSf5DSXpNRJUuokKXWSlDqp8mZQcvAmiIm0OE7OHO50VC8q0msGcVgLUZFKMFhMZhXqEbZlTZIGSaqqJFVVkqoqSVWVJN0qqyrzyqMbx1ekIczhsOIPZ/Z8YB0OM1jTLq5sHcZLoERpppxdJXlp+580B0Hw40Z746CFYBTjZnvjqN11DPMihvUxXRbHFNvEORO2SLDKQG8djhd115iKtcCDGAMujq7A2GWZsdAu9sakEaj/Q8wD6+D9sFagONPWMceFMc6JMZa4uyS4C22XInYljgfvD+K4bB3hLo1zToyzxN8lwR8hG2qghCdXbz9mq1hskPBvcZiVHWhmVw4pEhfMTmNICt2f0C6afTwvHTUXlaOPonfNqghI92clsXZWSjBQUhOlEQlHFLPmFeL5pznAM9xDvD9D2zniO25O8GkPnycNax40GkvfPO6PeCVYpIgqUkQVKaLKlwapyfVKk+uVFsWW5M10hQjE2NALuibNXfx83XyH13t4Dd8/Nj8031RY0fQZh1yONMmkJpnUJJOaXI4MyaYpxrwZHMdLoe4801ENtLTMZtoexSg6wrj6jNc9JPAQo+s5Pr+I8Zdmw3FzVCHRkHPBFOeCqc+FHmdYIfsJ8TPCeIVQJwhaxHBv7qCbv0VHb6Cr7+L9Bn6+R/s9tN7HQNhovqrhJh1pbBG3qxK8OHjZLKIRtEVWp8jgBXJ7mFQFZ/AEbbPI7IvmvIaQDA7LSwhtCgzowt9C9oj5o1BbXQ8UkN3DmCr6JQbBVQyCEACHN4qhJfecVhZhqloACO2YM0H0ldZM9wHwCCGepwxaDQw5ca0pgrE1MMrY5Zlnha+Hka+FS4OLz+qwSAWwRS11vAbLBFgyHjxXYXmEtR/n8R7CmuDKcRydeBBXjtvMZkdKtStKtatK9cCZkjMOORUY9DqBqUIh1dnpIhRTFRZAYUmHsjGU/RDsNSB0/soVgfgqEOPzvmwExETnnVWAeHJN8MU1wYtqcANKVswXrOIA1ID96oz3pOT7ouR7XdiPUcLEFVNWLxLQlILuxaXgDIXqPK5hv+L3/RpkUu19Ue29q1GneT7tWMc83siFRD1o3jzBr83mJ/wGRDjDvdpZxPsC/yZxVdrAkbysYa1kP4vCD5zOfXI6+cnp7Cen05+czn/yosQCp7OfnE5/cpqFWhKYZgKKAgY5B8xxLlgT0h6r1z5ccdrq1R9NchAYFc+HWYPvVDwLlbQyFEUNYEXV1jBI5tw6htpRACrJaCjqGYCvYjC4TI8RnOCsPYv7nKu4QIZ95UEdl6C9Kiq5fTq+BR3fdIYVBB3fgk7wi6KKgHA15kABg4L7attWoBOGIMvqkNOFBIillmnAkvzL31POt7ZxXyE51+ETfrTCfYZGAVK2fw7l4dmiXZv8POvLwoE2fvKPY6Dyvc7P4eqfVUZLJzRBFneXsEhn3rDYCK+Zj8OVRuckbf6Vcjr4ZNBcroAcdlc/zuApY639TKpSichIGvaFBx6uXW/rcVQJomNSlmMyJ0eLPx9VNk8+5ZKGg3mM0zvsg09iagJPDbW4pTOvoMpxm5M7N3kybNJzUmzEdPztdysxrXYy82bAtO/DOvyngljO8/uz9Gy2BmGt8jsh5EW6hvoANQ8pOoRVOYRV9YQUdv85mbbqjH73fxy196B6JAHVC91R+x8529vkDQplbmRzdHJlYW0KZW5kb2JqCjE4MiAwIG9iago8PAovTGVuZ3RoIDQ5NDkKL1R5cGUgL01ldGFkYXRhCi9TdWJ0eXBlIC9YTUwKPj4Kc3RyZWFtDQo8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOnBkZmFpZD0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2lkLyIgcmRmOmFib3V0PSIiPgogICAgICAgICA8cGRmYWlkOmNvbmZvcm1hbmNlPkE8L3BkZmFpZDpjb25mb3JtYW5jZT4KICAgICAgICAgPHBkZmFpZDpwYXJ0PjI8L3BkZmFpZDpwYXJ0PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczpwZGY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8iIHJkZjphYm91dD0iIj4KICAgICAgICAgPHBkZjpQREZWZXJzaW9uPjEuNzwvcGRmOlBERlZlcnNpb24+CiAgICAgICAgIDxwZGY6UHJvZHVjZXI+cG1wPC9wZGY6UHJvZHVjZXI+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgcmRmOmFib3V0PSIiPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAyNi0wMS0yNlQxNzowMjoyMiswMTowMDwveG1wOkNyZWF0ZURhdGU+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgcmRmOmFib3V0PSIiPgogICAgICAgICA8ZGM6Zm9ybWF0PmFwcGxpY2F0aW9uL3BkZjwvZGM6Zm9ybWF0PgogICAgICAgICA8ZGM6Y3JlYXRvcj4KICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgIDxyZGY6bGk+cG1wIGJ5IEFzc29jaWF0aW9uIENBUkEgKDAuNi42LUhVRyk8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICA8L2RjOmNyZWF0b3I+CiAgICAgICAgIDxkYzp0aXRsZT4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+Q2FydGUgZGUgbcOpZGljYXRpb248L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOnRpdGxlPgogICAgICAgICA8ZGM6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPk1pY2hhw6tsIENocmlzdG9waGVyIEthcmNlPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkFsdD4KICAgICAgICAgPC9kYzpkZXNjcmlwdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6cGRmYUV4dGVuc2lvbj0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2V4dGVuc2lvbi8iCiAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM6cGRmYVByb3BlcnR5PSJodHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvcHJvcGVydHkjIgogICAgICAgICAgICAgICAgICAgICAgIHhtbG5zOnBkZmFTY2hlbWE9Imh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9zY2hlbWEjIgogICAgICAgICAgICAgICAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICAgPHBkZmFFeHRlbnNpb246c2NoZW1hcz4KICAgICAgICAgICAgPHJkZjpCYWc+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpzY2hlbWE+QWRvYmUgUERGIFNjaGVtYTwvcGRmYVNjaGVtYTpzY2hlbWE+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOm5hbWVzcGFjZVVSST5odHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvPC9wZGZhU2NoZW1hOm5hbWVzcGFjZVVSST4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6cHJlZml4PnBkZjwvcGRmYVNjaGVtYTpwcmVmaXg+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5QREZWZXJzaW9uPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+VGV4dDwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPlRoZSBQREYgZmlsZSB2ZXJzaW9uLjwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5LZXl3b3JkczwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPlRleHQ8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+ZXh0ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5LZXl3b3Jkcy48L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+UHJvZHVjZXI8L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5BZ2VudE5hbWU8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5UaGUgbmFtZSBvZiB0aGUgdG9vbCB0aGF0IGNyZWF0ZWQgdGhlIFBERiBkb2N1bWVudC48L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgIDwvcmRmOlNlcT4KICAgICAgICAgICAgICAgICAgPC9wZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnNjaGVtYT5QREYvQSBJRCBTY2hlbWE8L3BkZmFTY2hlbWE6c2NoZW1hPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+aHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2lkLzwvcGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByZWZpeD5wZGZhaWQ8L3BkZmFTY2hlbWE6cHJlZml4PgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+cGFydDwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPkludGVnZXI8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5QYXJ0IG9mIFBERi9BIHN0YW5kYXJkPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPmNvbmZvcm1hbmNlPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+VGV4dDwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPkNvbmZvcm1hbmNlIGxldmVsIG9mIFBERi9BIHN0YW5kYXJkPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgICAgICAgICAgIDwvcGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkJhZz4KICAgICAgICAgPC9wZGZhRXh0ZW5zaW9uOnNjaGVtYXM+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJ3Ij8+Cg0KZW5kc3RyZWFtCmVuZG9iagoxODYgMCBvYmoKPDwKL0xlbmd0aCAyNDcyCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9OIDMKPj4Kc3RyZWFtDQp4nO2ZZ1BUWRaA73udEw3dTZOhyUmihAYk5yQ5igp0N5kWmgwqigyOwAgiIkkRRBRwwNEhyCgqohgQBQVU1GlkEFDGwVFERWVp/DG7NT+2tmpr/2yfH+99de6pd859daveV/UAkCEmsBJTYH0AErmpPF9nO0ZwSCgD8wBgAQkQAQWgI1gpSZ5+Tv5gNQS14G/xfgxAgvt9HcF67jlSTNEHHcNjMy6P3040b/57/b8EkZ3IZQMA0VY5js1JYa3yrlWOYSeyBflZAWekJqUCAHuvMo23OuAqswUc+Y0zBRz9jYvXavx97Vf5GABYYvQa408LOHKNKd0CZsXwEgGQ7l+tV2El8VafLy3opfhthrUQFeyHEc3hcngRqRw2499s5T+Pf+qFSll9+f/1Bv/jPoKz843eWq6dCYhe+VduWzkAzNcAIEr/yqkcAYC8B4DO3r9ykScA6CoFQPIZK42X/i2HXJsd4AEZ0IAUkAfKQAPoAENgCiyADXAEbsAL+IMQsAWwQAxIBDyQAbaD3aAAFIFScAhUgzrQCJpBGzgLusAFcAVcB7fBPTAKJgAfTINXYAG8B8sQBGEgEkSFpCAFSBXShgwhJmQFOUIekC8UAoVD0RAXSoO2Q3ugIqgMqobqoWboJ+g8dAW6CQ1Dj6BJaA76E/oEI2AiTIPlYDVYD2bCtrA77A9vhqPhZDgbzof3w5VwA3wa7oSvwLfhUZgPv4IXEQBBQNARiggdBBNhj/BChCKiEDzETkQhogLRgGhD9CAGEPcRfMQ84iMSjaQiGUgdpAXSBRmAZCGTkTuRxchq5ClkJ7IfeR85iVxAfkWRULIobZQ5yhUVjIpGZaAKUBWoJlQH6hpqFDWNeo9Go+lodbQp2gUdgo5D56CL0UfQ7ejL6GH0FHoRg8FIYbQxlhgvTAQmFVOAqcKcxlzCjGCmMR+wBKwC1hDrhA3FcrF52ApsC7YXO4KdwS7jRHGqOHOcF46Ny8KV4BpxPbi7uGncMl4Mr463xPvj4/C78ZX4Nvw1/BP8WwKBoEQwI/gQYgm7CJWEM4QbhEnCRyKFqEW0J4YR04j7iSeJl4mPiG9JJJIayYYUSkol7Sc1k66SnpE+iFBFdEVcRdgiuSI1Ip0iIyKvyTiyKtmWvIWcTa4gnyPfJc+L4kTVRO1FI0R3itaInhcdF10Uo4oZiHmJJYoVi7WI3RSbpWAoahRHCpuSTzlOuUqZoiKoylR7Kou6h9pIvUadpqFp6jRXWhytiPYjbYi2IE4RNxIPFM8UrxG/KM6nI+hqdFd6Ar2EfpY+Rv8kISdhK8GR2CfRJjEisSQpI2kjyZEslGyXHJX8JMWQcpSKlzog1SX1VBoprSXtI50hfVT6mvS8DE3GQoYlUyhzVuaxLCyrJesrmyN7XHZQdlFOXs5ZLkmuSu6q3Lw8Xd5GPk6+XL5Xfk6BqmClEKtQrnBJ4SVDnGHLSGBUMvoZC4qyii6KaYr1ikOKy0rqSgFKeUrtSk+V8cpM5SjlcuU+5QUVBRVPle0qrSqPVXGqTNUY1cOqA6pLaupqQWp71brUZtUl1V3Vs9Vb1Z9okDSsNZI1GjQeaKI1mZrxmkc072nBWsZaMVo1Wne1YW0T7VjtI9rD61DrzNZx1zWsG9ch6tjqpOu06kzq0nU9dPN0u3Rf66noheod0BvQ+6pvrJ+g36g/YUAxcDPIM+gx+NNQy5BlWGP4YD1pvdP63PXd698YaRtxjI4aPTSmGnsa7zXuM/5iYmrCM2kzmTNVMQ03rTUdZ9KY3sxi5g0zlJmdWa7ZBbOP5ibmqeZnzf+w0LGIt2ixmN2gvoGzoXHDlKWSZYRlvSXfimEVbnXMim+taB1h3WD93EbZhm3TZDNjq2kbZ3va9rWdvh3PrsNuyd7cfof9ZQeEg7NDocOQI8UxwLHa8ZmTklO0U6vTgrOxc47zZReUi7vLAZdxVzlXlmuz64KbqdsOt353orufe7X7cw8tD55Hjyfs6eZ50PPJRtWN3I1dXsDL1eug11Nvde9k71980D7ePjU+L3wNfLf7DvhR/bb6tfi997fzL/GfCNAISAvoCyQHhgU2By4FOQSVBfGD9YJ3BN8OkQ6JDekOxYQGhjaFLm5y3HRo03SYcVhB2Nhm9c2Zm29ukd6SsOXiVvLWiK3nwlHhQeEt4Z8jvCIaIhYjXSNrIxdY9qzDrFdsG3Y5e45jySnjzERZRpVFzUZbRh+MnouxjqmImY+1j62OfRPnElcXtxTvFX8yfiUhKKE9EZsYnnieS+HGc/u3yW/L3DacpJ1UkMRPNk8+lLzAc+c1pUApm1O6U2mrH+nBNI2079Im063Sa9I/ZARmnMsUy+RmDmZpZe3Lmsl2yj6Rg8xh5fRtV9y+e/vkDtsd9TuhnZE7+3KVc/Nzp3c57zq1G787fvedPP28srx3e4L29OTL5e/Kn/rO+bvWApECXsH4Xou9dd8jv4/9fmjf+n1V+74WsgtvFekXVRR9LmYV3/rB4IfKH1b2R+0fKjEpOVqKLuWWjh2wPnCqTKwsu2zqoOfBznJGeWH5u0NbD92sMKqoO4w/nHaYX+lR2V2lUlVa9bk6pnq0xq6mvVa2dl/t0hH2kZGjNkfb6uTqiuo+HYs99rDeub6zQa2h4jj6ePrxF42BjQMnmCeam6Sbipq+nOSe5J/yPdXfbNrc3CLbUtIKt6a1zp0OO33vR4cfu9t02urb6e1FZ8CZtDMvfwr/aeys+9m+c8xzbT+r/lzbQe0o7IQ6szoXumK6+N0h3cPn3c739Vj0dPyi+8vJC4oXai6KXyzpxffm965cyr60eDnp8vyV6CtTfVv7Jq4GX33Q79M/dM392o3rTtevDtgOXLpheePCTfOb528xb3XdNrndOWg82HHH+E7HkMlQ513Tu933zO71DG8Y7h2xHrly3+H+9QeuD26PbhwdHgsYezgeNs5/yH44+yjh0ZvH6Y+XJ3Y9QT0pfCr6tOKZ7LOGXzV/beeb8C9OOkwOPvd7PjHFmnr1W8pvn6fzX5BeVMwozDTPGs5emHOau/dy08vpV0mvlucLfhf7vfa1xuuf/7D5Y3AheGH6De/Nyp/Fb6Xennxn9K5v0Xvx2fvE98tLhR+kPpz6yPw48Cno08xyxmfM58ovml96vrp/fbKSuLIidAGhCwhdQOgCQhcQuoDQBYQuIHQBoQsIXUDoAkIXELqA0AX+j11g7T/OaiAEl+PjAPjnAOBxB4CqagDUogAgh6VyMlMFq9xtDNa2pCxebHRM6jpGWgqHEcXjcBKyBGv/ADUmExsNCmVuZHN0cmVhbQplbmRvYmoKMjUxIDAgb2JqCjw8Ci9MZW5ndGggNDExNQovVHlwZSAvT2JqU3RtCi9OIDIwMAovRmlsdGVyIC9GbGF0ZURlY29kZQovRmlyc3QgMTc1Mwo+PgpzdHJlYW0NCnic7Vv9bxs5kv1X+OMEi7Sa3+zDYgHHiSe5uckESfYDaxgHxdY4unEkQ5ZvJv/9vVdsibQ+olbGM3sDLJBEXdXkY7FYRT52SKNaZZUzyikdtfLKGK+CMi51KirjtVEJP9arTpnQaqVb/IaotFYmWqtQwMSuU9oqk4JX2inTWZTzyratUTrgN6JcVFY7tJKUNSisO/wmVEb71qFFrawjuMFvhGyV9RaNOmVDC7uAF2ChAV50aAx4CY0Y4KWEX+B1HoVb5VqCavx2AEPXdMAve2kJrpyFXeiRAyBAlXPUR/yiHzYp5wNwOuUCQB3wYot/gBdjK65KFIDXtXgPvC5B75VvHSspr2GXi/hNAE3KG9bv8BsNCilvAe7hbOsh44+DM7zFb3L4R3nPwsALcKYHXkBnPf4E9McDLwYURpEIPwXgJTQWgNfBueiq7zB4KBJavERXgoYzMDTBoN8BVTBwCl0PFp0IqGLRSEAVB+dGVkE7kVXgd5gcPARWCbA7Ai/A6Ai8CD/ThJiSisBLiI8IvASwCLwOfoJrAscl4VULfAx5bDuvkkUTbVLoctSonNgUnJVggkEn4DqEl1WEdrCD8Ug/dWjSdVrhT4SDFE31MKYDXsAgdMCL8D+aiBHj1wGP8dkBj3Z1wEtovKOJcLrG2KQWUaZbGovh1/BS0hha3aJ5nRjztB+ImoYYRn+LnlgpDNM5jrkvhoAdHmCGRjQnmqiRKykgxjSzKTBZkAApMgswwinCRwyZlBA8GgmTOs3CQO7gTo1R7VqmjnQfAaDhdxSBxtARcIVG2nQG1mlY0DHO+Lqzlho6BxGl4X2MCF9FPBAZyYOxIQ4dBXs10qcLGFOGTBcR7Bp2I75RGIPRJQy/Rgp1KVEDZI6tRhLBj2hIW/qmtZwP6BwtmHSlpk1IJjxhiLWjV5kXmm20HHHt6Dxr+JbDYVna0ekO/tf0TYtUxBPbYK5oxza8p45tBHhKU2rF255tMHe1jE9kmzLi0gvajV5S5/mE2NCBAxEoy7DFRB0dZjWfONtZxKoO9F1gadbC/IfSUbyHSOQ8CmDOjeJIx3Gmt5FufKJvHNJZc9gx16EG4hHOZDn2CvMeEBK96TnaSAX4laji9MT4o2VOyzzK3otPaQVSGHIn3qQXkRZ4Yj1GpHPsPwPZefq5o689AxLpAQ+z50gQeNhQxzYi5DxOKXC2ZhuINMW5BE+wwyBN4HXHt/QrQ1lC0dMTBpkC/xuiRD5FluM4yazPNPOYsDH/c5yYNyaPCfxpGKw+YKqTFcNjYsAT2+AMaDTbSJbl2AZyDU9so0MS/PnPo/efbydq9GZ8PblTo++mV3fq3GK5e6su1Oh0fj9bKq3+8peHJdXo+8nVdPxs/os6b5tW8S+m+yZhmHznG4PfCxZdTFDfCNzo7eRufr+4RDMuK07nsyXe3ynOHqJ5t1zcXy5ztTuoRu/HH2DVu96AN4v57WSxnALC5wpnc9rn++r/+OHD/0wulxJRVJRamKZzEQqYC4uAKaYISNkiMKeKxDmnSJEr+lpivBWJ8VAkGbBK1Fzri2i45BeRsV2JDM1KZMRUotCBIkaygiImkoMiCkcoLmhJFYoojKGIZCuVSNJSieQulUgKU4mBpKKIkdyiiIkUo4gdmUYZi5aEo4iavKOIQj+KaMlCiihkpIienKSIgdSkiJEMpYiJRKWIwldKUAhtKaImeymiIYkpoiWXKSJ5TyWS/lQiWVAlRvKcIibSnSJ2ZD0lOluSnyJqcqAiGlKhIloyoiI6EqMievKjIgbSpCJGsqUikglVIglRlSUtKVQRNZlUEQ0JVRGFVxXRkV4V0ZNlFTGQbBUxknMVMZF6FVEYWMnWlkSsiFrFyirgxMoq4MTKKuDEyirgpMoq4KR6WohkbkVMJHBFJOWpZg0Sn0ok/alEIXdFFI5XREeqV0RPxlfEQOJXxEj+V8REGljEjmywzF4tSWERNblhEQ0pYhFJdirRkTAW0QtvLHIQ+ljkKCyyyEnIZJE74ZTVVNoKt6wUWjhmpRAKUyuEydQKJ9yzUnjhoJUiCBetFFE4aaVIwk0rRScctZrlM1etFFo4a6XI3LVSWOGwlSJz2UrhhdNWiiDctlJE4biVIgnXrRSdcN5qAWqF+1YKLRy4UmQuXCmscOJKkblxpfDCkStF5sqVIgpnrhSZO1cKYYD12tgKl64UWjh1pTBCrSuFFYZdKZwQ7UrhhW9Xiky7K0UU9l0pkpDwStEJF6+W7UzJK4UWZl4pjBD0SmGFp1cKJ3S9Unhh7VRs0LHpbLyczmdD1M/Glz9dL8DqrvAs9M2kBj6wzjQISc89nW284bY6NJ3h3vbiD4PgW9vE6Ns/KoK1TWhbfg/ybddgp8gvMBFPWmB0E+KRMLZrMGtizvt1MDusWSMfhEld46XKGgUbZdkiHGHLGsRqscoVEO8afSSIDo0PxhcMon51mGI71lgzNEBc1A3Mla8mD+oP8OVeCwRzqAGmFa9vVqdJAxFcaMwOA4YglKhyxkteGH5HbWwgnkOuAGaIJT41KdfxunH9U2gi9qDuCBwXYmO4by3mBMJYqgajBKLYByir2DqiS/uGZ+3uI5yytsMy7aw4xbVNF4bgWI1MedgdC+hOizWDUULXOKmyRnFtbNJxKE7DLRso/TgfgdJnTucbzX6tXbt29m8OUAV+2zY2yU4iNthrat84c4QNW+m/tuo3ByidsC72OYuVwKE3LffjXZPSABjfSoKxyhrG4Klj5a9Bia5JnqvCFsrhSfXLxgjygMTrJP9rvzBKGf5ueI84GQUuTAWFk5EV1VAQzkVBPwDJgTYYYReBSEEipN21an9/+uo5iOnjgg7AMa5p6RodMivRGfqhXfrx8PZBrMpvI/y/AxCXmN/anF3UEVvxJiBHdUF9YJR9XMyjWO12CPwb5l8Ps835Pame3Un6JYbco0IO30d408mUu7mTEKP8o8EN3VjoYBvTMi22txZiUnhEwAF8x6YmCt/Qtm2A6+3GZkGMio8IeMyuwYD8tF5wt6i6GJYeGfTwVmTdP4/+cWu5x2XdYyIe3tusQUCrmgRqFPYZpg+xgSNBj9nwmOQan12/tT3Ixh2iBMeiHrONQnf3bICybYfW5uMwj9ia2ZSadvemKlt2cIE+CvOY7Z4NmYzvs+zQtH8c5hEbOO0c90+cF7c2cdm0g5P/caDHbIV0XOFs74WycYeWgWNRj9lhkVHmHVYwjRMPPDTu0HJwJOgwmPzltsCsu30EDHYyEmwbKL/Skh718JS4yxJElLXblmRHH1rejgDcB5EyxDaA/mqEZCX42q+34TdEyI49tDo/gkWlQvGsbvSOqMsbv0PL8hGAeyFAdwbbc2glHgi2dyO7Lv9vhE2E4zL490TIoXHwI8WvtujICTebdYgFPdIszv1DlysIcQHri+hXaPTWhxPjHkiHGMcw5C/RT/lvgFV9i+1Nu8+yQwRjKNrh76V9fZ98kyjvtucQpxiOd/jja48QNWKx67qwz6ZDy+8xiGdaTvHKoYEzIyd187OV07ibZwfk9CSavJvkp5OTk2f/PPvTyWL6af701XJ8M71Uo3f3H5ZSmnVaNXoxu5xfTWfXavTqajJbTpefn75Uo+eTu8vJ7Go8WxLqDunp16dI38//Opui0oSHTvcYsW4FPqGG78xB21D43ee75eTTq9mPczmsnLuLGjRoMb1dzhdydFn0f1fnrTpHSiISkuL9jAvloDCkiQkP0F5wC3ae32FjgRWRyYq1vC+G8Tr3nt9kbMts5zG8oHqNz++MlLSowycirMrkcs6T+EPbZksueEhQsC54xu+8Lp1r+O6h9oKH8Ho7eCzqPMPweI8g22y1W7+x1q3tduuqDpvt81zWIW76xwtx7Pv5t6+efz++5ZnhatDeTq6nd8vFZ/XNydX8w+SJGv2wuJosGBDfrALiCcfz9vZm8onHf9ut4a7GRuTX40+TPSN8djO+vuMxQSn498n0+uNStkqIxFzmZHZ9M1FPtaGKhXLaPA2h/874lBsVpALPy8YuyCFl3TqDbV+ia0YnDN0lLw00JvI8eB/NS/XUaI0JyrUBLhnfvszNh8T/HEpWjf7Razw/mPGE9+gdgvFvvCODfSaPqYtFZ9ObiZzRzmHIqJ3w2HIckpGvn/1n7xO4/v5mvPj6lOyPdT5MybDPiiEpucO4jZxcnR3dzMnVIdKSk4jMdRxDxYP6q1DGCFIb83v+3UyR7ZRZJWof/2GV1DblVOZfaoLWKic+05JJSC1rMnGl5HqywJx2Xte74CnbHhf/5KSW1uPG5FDbzEkhTxFx7xSRNqYIeSMTBM8nrjKfU9V2z3ncrJ4Fol7ZyAsCfZLzXga4gNuR7yH8Xvm+I3xywrtD+d5uZLt3tul4b+Nfke0WvLOF1+pkX52KXiV7fyz6QLKf/vO0d8iz+c3Vr8j0bkemx30mDMn0Tcs20nx1VHszzVdntnemuV2vqn4dolirz3Nq7UgoOZquRZOjOIYVVsL7xBt9eJ/rSwqlrirNM7Z96mzGfH9c/HeI+U1H7gr4+AcM+NVx/FXA9+fxe2I6X3zi7a96rXnxy/Lbd8vxciK3vYr++k7Lra/NWC3lR8++5+2hT7fj5fQDfNPT6fHip8mVWi7uV5rn07vbm/Hn5/PL99MlylWvMuQP98vb++UruYbEa0ajb9+/++83z89OtDhpmd+/Wcx/RB+VXp3Pl5D/5u7tt8/UqxenQXchPDWNfrICPJ3PrqZy9nZIoRxRP04ni93FV9EoEfTNx+Xy9j9Go59//rm5nN/MF818cf3kQafyJar3i8nk7XyObr2d30wkxlcXCL6Ti3H5ZLFctWLZ15Nflt9NPitdK7G3rEfm1exmOpu8+ziWIJ9e3y9yc9OfJvN7OvB2PIPjFvNbRFMp8WJ29XrOYcv/ovuEWRXH5JMzpShuJ4uHqpPZbL7Mp5lXmgVcNr5EiTdocTq+Xow/lRbP0PG6yb/OkL51o88QN9M5Kt1+/CzSixnzfXT6cbxYrnG2vfoC+S6Bgpi6l8wf/deY08LZ2xevT18+oTl6dW/jO7l2uBnGm0DT/82VViNyreyqunAgPpv+TsPFl5Dej5kLxFrfBXmIlRNU95c/TH9x4suYLyfjq4ypD/Xk/bP51ee67IP2decOArzNte1O631vtR1g9fMM5HYChd4NA1z60mQgvw3UDhnUXRXPdX9lxrT6sAU5XN+szd2AkuunR4CkbRDTHozRUn9HkJqvN9/0t382P4ftATHtZlx9ZQyY/laR6S8TDYiBVdw9AHIDYmBnRf9Fy89k2h6Uc+tA25Xxpl0F2oAYWXVzxziFQbPOzqrnpr9aZfo7Rqa/J2T6yy7DZh/T7podTX9Ly/SXor6MJZOL0Tsd1d/uMv0dLtPf1DJ6iJHPM/DWnHci262+jdWXxx/WHjud30hgG67QP/ePX9uOX7WT9rbzxWD9Ivh6Oeu2wB9Y/n+R4PsADQplbmRzdHJlYW0KZW5kb2JqCjI1MiAwIG9iago8PAovTGVuZ3RoIDgyNgovVHlwZSAvT2JqU3RtCi9OIDMzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9GaXJzdCAyNzYKPj4Kc3RyZWFtDQp4nKVWXU8bMRD8K/sGqIX4Y23fVQEpJKGVQLQC+hT6kI8TvSrkouQC4t937HOAwvWSpg/J7sWe8aw93ouSCQlSMiWbkFKCUkaQJBONqEgxRhXy1CEyaePHDbGUiJbYWURHRnt4Qlb4Z7BpYLUg63FakvO8+C1hg6gpxbpKM6Uerw1JoVMklqQUPnFIEg9JSCr2HClJLV0QJLUDmqGSJaSxQuKghzVJw0DhI42DcqwmLfs5YHbC1wNmZ7AEgzmRWJ3BnFhMNviINKV2u3XzNM+odV0uVuOyP83ukVPrpketb9griR27QnpHuso6YQNDeo5K6OTEc3wFYjiagueqeLyeD2ek4kg9+1XFLt6yn9PAn4jP/YlUUcfIIf5oJK5kqxpilLIjsLmUBqDeFciNwNNi8hSwIn2P9Ub16ebdh7Nr0G4jOuq2Nc5QyXMJ5p0zusU0OCP5j+K02La4GvTAX85gJR2txetoY3RbW0y/PbcdIJWmaG+9hb17+UPFpGpMY3dF+p60oYJwcAHPtTVU+4eW1Sj/haXGegPfCKtTkP+wE+9seB4a6db1uFollXvQtxtFXFQUSc1N4NdGxR24yJdl9X25uh9li3x2R63LYpbtXuROjuuEN8eag/lPlW9uamMbet5CrrHUQHF4IYXzNFu6gmu8pRpd3XCx0Mh2BDb3p7OiKF/3p2ouDnVJA0EDmcarkFauUELEGFuP4Bjj5og4T8ZWJOO4jC1JxvENb8V1435pJ5E/unO2mk7ffq0v2nrjX6L5S1tcn2N3kQ3LvJj1hmVG+71PSigrpLL+b4dSH4TcE2LvANu0KCarcbag/fn9HM/Xq9GvbFxSm3s2tdomVvZPbRebgtwp/IHSju2ZExgxDu9GPgWnwkxzAu+uyp9FxUWjJ+osl8U4Dzqo27nq0O2+OLJH9vDL98+3B1htki3Hi3weJrSNsX1rlAAXGLGKz6vvXj9FloYRH89sXwloOHNBg+36WVBmbAeqWEGvdcD0+6lTiBjtizBPVpy2ZyVW46D6Ic8e58WipP3HfFL+PJ5kD/k4OwwPHymf5WU+nB4ux8Npdiyh+iYvcQfbvJXOE38gvwGNepykDQplbmRzdHJlYW0KZW5kb2JqCjI1MyAwIG9iago8PAovTGVuZ3RoIDQ4NgovUm9vdCAxIDAgUgovSW5mbyAyNTAgMCBSCi9JRCBbPEIzQ0UzNzI1RUJERTMxOURGQUU0RTlENzIyRkI2REY5PiA8QjNDRTM3MjVFQkRFMzE5REZBRTRFOUQ3MjJGQjZERjk+XQovVHlwZSAvWFJlZgovU2l6ZSAyNTQKL0luZGV4IFswIDI1M10KL1cgWzEgMiAxXQovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnicFdPnvw9UHMDxcy6RcW2Rec0ySmSTce1dRqhcSnSzCtnz2ikzKxWKioiKzMyMJ/wDnvk7fF+vev8evF/ndb7fB+fJ+aSU/supdipKzwsyRVSiMi9Qhaq8SDWqU4OaFFOL2tShLvWoTwMa8hKNaMzLNKEpzWhOC1pSQita04a2tKM9r/AqHehIJzrzGq/ThTfoSjfepDs96EkvetOHvvSjP28xgIEMYjClDGEowxjOCEYyitGMYSzjGM8E3uYdJjKJyUzhXaYyjem8x/t8wAzKmMksPuQjZvMxc5jLJ5TzKfOYzwIWsojP+JzFLGEpX7CM5axgJatYzRrWso71bGAjFWxiM1vYyja2s4Mv2clXfM0udrOHvexjP99wgIMc4jBH+DanJykXnyJSrnWt8OeO8h3f80OuU5FyydOUW3VLuXXdwv4YxznBj7nN45Q7VqGMZ4X9T7nzxMJ5klP8nEs3pTy6vDD7hV85ncvqF+5n+I2znON3znOBP/iTv7jIJf7mMle4yjWuc4N/uMktbnOHu9zjX+7zgIc8Kkrh/dBX6Cv0FfoKfYW+Ql+hr9BX6Cv0FfoKfYW+Ql+hr9BX6Cv0FfoKfYW+Ql+hr9BX6Cv0FfoKfYW+Ql9RksuLU165O/0P6DZDVA0KZW5kc3RyZWFtCmVuZG9iagpzdGFydHhyZWYKMzE3OTUKJSVFT0YK"
      }
    }
  ]
}

```
