# Bundle: PMLC #1 - CH EMED EPR v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: PMLC #1**

## Example Bundle: Bundle: PMLC #1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundlePmlc1",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-document-medicationcard"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:cdce5856-7ef7-4f0c-a456-45531110aeb5"
  },
  "type" : "document",
  "timestamp" : "2023-04-21T08:47:22.320+02:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:cdce5856-7ef7-4f0c-a456-45531110aeb5",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "Inline-Instance-for-pmlc1-1",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-composition-medicationcard"
          ]
        },
        "language" : "fr-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr-CH\" lang=\"fr-CH\"><a name=\"Composition_Inline-Instance-for-pmlc1-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition Inline-Instance-for-pmlc1-1</b></p><a name=\"Inline-Instance-for-pmlc1-1\"> </a><a name=\"hcInline-Instance-for-pmlc1-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fr-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-composition-medicationcard.html\">PMLC Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:cdce5856-7ef7-4f0c-a456-45531110aeb5</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 736378000}\">Medication management plan (record artifact)</span></p><p><b>date</b>: 2023-04-21 08:47:22+0200</p><p><b>author</b>: <a href=\"Bundle-BundlePmlc1.html#urn-uuid-a7082159-24c8-4991-97ae-ffee0c3e3ce8\">Device: type = Pharmaceutical information system application software (physical object)</a></p><p><b>title</b>: Plan de médication</p><p><b>confidentiality</b>: normal</p><p><b>custodian</b>: <a href=\"Bundle-BundlePmlc1.html#urn-uuid-5f1b39a0-7cc3-4885-8263-8e39a6f71b22\">Organization Association CARA</a></p></div>"
        },
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:cdce5856-7ef7-4f0c-a456-45531110aeb5"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medication management plan (record artifact)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:574d95b5-6ee1-4726-b399-e16eaf225e60"
        },
        "date" : "2023-04-21T08:47:22+02:00",
        "author" : [
          {
            "reference" : "urn:uuid:a7082159-24c8-4991-97ae-ffee0c3e3ce8"
          }
        ],
        "title" : "Plan de médication",
        "confidentiality" : "N",
        "_confidentiality" : {
          "extension" : [
            {
              "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "code" : "17621005",
                    "display" : "Normal (qualifier value)"
                  }
                ]
              }
            }
          ]
        },
        "custodian" : {
          "reference" : "urn:uuid:5f1b39a0-7cc3-4885-8263-8e39a6f71b22"
        },
        "section" : [
          {
            "title" : "Medication List",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "10160-0",
                  "display" : "History of Medication use Narrative"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Ce plan de médication a été généré automatiquement par le service eMedication CARA le 21 avril 2023 à 08:47:22 CEST. Tous les traitements actifs sont considérés.</div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2"
              }
            ]
          },
          {
            "title" : "Original representation",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "55108-5",
                  "display" : "Clinical presentation Document"
                }
              ]
            },
            "text" : {
              "extension" : [
                {
                  "extension" : [
                    {
                      "url" : "htmlid",
                      "valueString" : "pmlc-original-representation"
                    },
                    {
                      "url" : "data",
                      "valueUri" : "urn:uuid:8139d696-e83c-49ea-a94a-651edfaecd7b"
                    }
                  ],
                  "url" : "http://hl7.org/fhir/StructureDefinition/textLink"
                }
              ],
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">The original representation as a <span id=\"pmlc-original-representation\">PDF file</span></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:8139d696-e83c-49ea-a94a-651edfaecd7b"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:574d95b5-6ee1-4726-b399-e16eaf225e60",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "Inline-Instance-for-pmlc1-2",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_Inline-Instance-for-pmlc1-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient Inline-Instance-for-pmlc1-2</b></p><a name=\"Inline-Instance-for-pmlc1-2\"> </a><a name=\"hcInline-Instance-for-pmlc1-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-patient.html\">CH EMED EPR Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Leandra Corina Behluli-Qazimi  Female, DoB: 2002-12-21 ( Medical record number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Medical record number/MAGMED005 (use: secondary, )</li><li>Medical record number/3486389 (use: secondary, )</li><li>Medical record number/3503409 (use: secondary, )</li><li>Medical record number/3505915 (use: secondary, )</li><li>Medical record number/99146298 (use: secondary, )</li><li>Medical record number/3475203 (use: secondary, )</li><li>Medical record number/11111111 (use: secondary, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.177.2.2.1.1",
            "value" : "100001298"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "MAGMED005"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.2.2.1",
            "value" : "3486389"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "3503409"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.2.2.1",
            "value" : "3505915"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.128.4.1.4.2.3.2.1.1.1",
            "value" : "99146298"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.16.756.5.30.1.196.3.2.1",
            "value" : "3475203"
          },
          {
            "use" : "secondary",
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "urn:oid:2.999.1",
            "value" : "11111111"
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Behluli-Qazimi",
            "given" : ["Leandra Corina"]
          }
        ],
        "gender" : "female",
        "birthDate" : "2002-12-21"
      }
    },
    {
      "fullUrl" : "urn:uuid:a7082159-24c8-4991-97ae-ffee0c3e3ce8",
      "resource" : {
        "resourceType" : "Device",
        "id" : "Inline-Instance-for-pmlc1-3",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-device"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_Inline-Instance-for-pmlc1-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device Inline-Instance-for-pmlc1-3</b></p><a name=\"Inline-Instance-for-pmlc1-3\"> </a><a name=\"hcInline-Instance-for-pmlc1-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-device.html\">CH EMED EPR Device</a></p></div><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>PMP CARA v0.1</td><td>Model name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 701612004}\">Pharmaceutical information system application software (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>unkown</td></tr></table><p><b>owner</b>: <a href=\"Bundle-BundlePmlc1.html#urn-uuid-5f1b39a0-7cc3-4885-8263-8e39a6f71b22\">Organization Association CARA</a></p></div>"
        },
        "deviceName" : [
          {
            "name" : "PMP CARA v0.1",
            "type" : "model-name"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "701612004",
              "display" : "Pharmaceutical information system application software (physical object)"
            }
          ]
        },
        "version" : [
          {
            "value" : "unkown"
          }
        ],
        "owner" : {
          "reference" : "urn:uuid:5f1b39a0-7cc3-4885-8263-8e39a6f71b22"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:5f1b39a0-7cc3-4885-8263-8e39a6f71b22",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "Inline-Instance-for-pmlc1-4",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_Inline-Instance-for-pmlc1-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization Inline-Instance-for-pmlc1-4</b></p><a name=\"Inline-Instance-for-pmlc1-4\"> </a><a name=\"hcInline-Instance-for-pmlc1-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-organization.html\">CH EMED EPR Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601001407428</p><p><b>name</b>: Association CARA</p><p><b>address</b>: Route de la Corniche 3a Épalinges Vaud 1066 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601001407428"
          }
        ],
        "name" : "Association CARA",
        "address" : [
          {
            "line" : ["Route de la Corniche 3a"],
            "city" : "Épalinges",
            "state" : "Vaud",
            "postalCode" : "1066",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2",
      "resource" : {
        "resourceType" : "MedicationStatement",
        "id" : "Inline-Instance-for-pmlc1-5",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-emed-epr/StructureDefinition/ch-emed-epr-medicationstatement-card"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_Inline-Instance-for-pmlc1-5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement Inline-Instance-for-pmlc1-5</b></p><a name=\"Inline-Instance-for-pmlc1-5\"> </a><a name=\"hcInline-Instance-for-pmlc1-5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emed-epr-medicationstatement-card.html\">PMLC MedicationStatement</a></p></div><blockquote><p><b>CH EMED Extension Treatment Plan</b></p><ul><li>id: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2</li><li>externalDocumentId: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:24c84eef-f9db-4710-8f6c-2d342ad3ac2d</li></ul></blockquote><p><b>CH EMED Extension Last Considered Document</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:24c84eef-f9db-4710-8f6c-2d342ad3ac2d</p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2</p><p><b>status</b>: Active</p><p><b>medication</b>: <a href=\"#hcInline-Instance-for-pmlc1-5/medication-1\">Medication TRIATEC Tabl 2.5 mg 20 Stk</a></p><p><b>subject</b>: <a href=\"Bundle-BundlePmlc1.html#urn-uuid-574d95b5-6ee1-4726-b399-e16eaf225e60\">Leandra Corina Behluli-Qazimi  Female, DoB: 2002-12-21 ( Medical record number (use: official, ))</a></p><p><b>dateAsserted</b>: 2023-04-11</p><p><b>informationSource</b>: <a href=\"#hcInline-Instance-for-pmlc1-5/practitioner-role-1\">PractitionerRole</a></p><blockquote><p><b>dosage</b></p><blockquote><p><b>id</b></p>#dosage-1</blockquote><p><b>text</b>: À prendre avec de l'eau</p><p><b>patientInstruction</b>: À prendre avec de l'eau</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #medication-1</b></p><a name=\"Inline-Instance-for-pmlc1-5/medication-1\"> </a><a name=\"hcInline-Instance-for-pmlc1-5/medication-1\"> </a><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680538751228}\">TRIATEC Tabl 2.5 mg</span></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 10219000}\">Tablet</span></p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole #practitioner-role-1</b></p><a name=\"Inline-Instance-for-pmlc1-5/practitioner-role-1\"> </a><a name=\"hcInline-Instance-for-pmlc1-5/practitioner-role-1\"> </a><p><b>practitioner</b>: <a href=\"#hcInline-Instance-for-pmlc1-5/practitioner-1\">Practitioner Perry Cox </a></p><p><b>organization</b>: <a href=\"#hcInline-Instance-for-pmlc1-5/organization-1\">Organization Hôpitaux universitaires de Genève</a></p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Practitioner #practitioner-1</b></p><a name=\"Inline-Instance-for-pmlc1-5/practitioner-1\"> </a><a name=\"hcInline-Instance-for-pmlc1-5/practitioner-1\"> </a><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000234438</p><p><b>name</b>: Perry Cox </p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #organization-1</b></p><a name=\"Inline-Instance-for-pmlc1-5/organization-1\"> </a><a name=\"hcInline-Instance-for-pmlc1-5/organization-1\"> </a><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000234438</p><p><b>name</b>: Hôpitaux universitaires de Genève</p><p><b>address</b>: Rue Gabrielle-Perret-Gentil 4 Genève 1205 CH </p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Medication",
            "id" : "medication-1",
            "code" : {
              "coding" : [
                {
                  "system" : "urn:oid:2.51.1.1",
                  "code" : "7680538751228",
                  "display" : "TRIATEC Tabl 2.5 mg 20 Stk"
                }
              ],
              "text" : "TRIATEC Tabl 2.5 mg"
            },
            "form" : {
              "coding" : [
                {
                  "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
                  "code" : "10219000",
                  "display" : "Tablet"
                }
              ],
              "text" : "Tablet"
            }
          },
          {
            "resourceType" : "PractitionerRole",
            "id" : "practitioner-role-1",
            "practitioner" : {
              "reference" : "#practitioner-1"
            },
            "organization" : {
              "reference" : "#organization-1"
            }
          },
          {
            "resourceType" : "Practitioner",
            "id" : "practitioner-1",
            "identifier" : [
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601000234438"
              }
            ],
            "name" : [
              {
                "family" : "Cox",
                "given" : ["Perry"]
              }
            ]
          },
          {
            "resourceType" : "Organization",
            "id" : "organization-1",
            "identifier" : [
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601000234438"
              }
            ],
            "name" : "Hôpitaux universitaires de Genève",
            "address" : [
              {
                "line" : ["Rue Gabrielle-Perret-Gentil 4"],
                "city" : "Genève",
                "postalCode" : "1205",
                "country" : "CH"
              }
            ]
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "id",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2"
                }
              },
              {
                "url" : "externalDocumentId",
                "valueIdentifier" : {
                  "system" : "urn:ietf:rfc:3986",
                  "value" : "urn:uuid:24c84eef-f9db-4710-8f6c-2d342ad3ac2d"
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-treatmentplan"
          },
          {
            "url" : "http://fhir.ch/ig/ch-emed/StructureDefinition/ch-emed-ext-last-considered-document",
            "valueIdentifier" : {
              "system" : "urn:ietf:rfc:3986",
              "value" : "urn:uuid:24c84eef-f9db-4710-8f6c-2d342ad3ac2d"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:uuid:41b97645-e263-47c2-8d96-79da451a33f2"
          }
        ],
        "status" : "active",
        "medicationReference" : {
          "reference" : "#medication-1"
        },
        "subject" : {
          "reference" : "urn:uuid:574d95b5-6ee1-4726-b399-e16eaf225e60"
        },
        "dateAsserted" : "2023-04-11",
        "informationSource" : {
          "reference" : "#practitioner-role-1"
        },
        "dosage" : [
          {
            "id" : "#dosage-1",
            "text" : "À prendre avec de l'eau",
            "patientInstruction" : "À prendre avec de l'eau"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:8139d696-e83c-49ea-a94a-651edfaecd7b",
      "resource" : {
        "resourceType" : "Binary",
        "id" : "Inline-Instance-for-pmlc1-6",
        "language" : "fr",
        "contentType" : "application/pdf",
        "data" : "JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS40Ci9QYWdlcyAyIDAgUgovTWV0YWRhdGEgMyAwIFIKL01hcmtJbmZvIDQgMCBSCi9MYW5nIChmci1DSCkKL1ZpZXdlclByZWZlcmVuY2VzIDUgMCBSCi9PdXRwdXRJbnRlbnRzIFs2IDAgUl0KL1N0cnVjdFRyZWVSb290IDcgMCBSCj4+CmVuZG9iago4IDAgb2JqCjw8Ci9DcmVhdGlvbkRhdGUgKEQ6MjAyMzA0MjEwODQ3MjMrMDInMDAnKQovUHJvZHVjZXIgKFRoZSBIdXNreSBsaWJyYXJ5KQovU3ViamVjdCAoTGVhbmRyYSBDb3JpbmEgQmVobHVsaS1RYXppbWkpCi9BdXRob3IgKEF1dGhvcikKL2Rlc2NyaXB0aW9uIDw1NTZFNjUyMDYzNjE3Mjc0NjUyMDY0NjUyMDZERTk2NDY5NjM2MTc0Njk2RjZFMjA3MDZGNzU3MjIwNkM2NTIwNzM3NTZBNjU3NDJDMjA2N0U5NkVFOTcyRTk2NTIwRTAyMDZDNjEyMDY0NjU2RDYxNkU2NDY1Pgovdmlld3BvcnQgKHdpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xKQovVGl0bGUgPDQzNjE3Mjc0NjUyMDY0NjUyMDZERTk2NDY5NjM2MTc0Njk2RjZFPgo+PgplbmRvYmoKMiAwIG9iago8PAovVHlwZSAvUGFnZXMKL0tpZHMgWzkgMCBSXQovQ291bnQgMQo+PgplbmRvYmoKMyAwIG9iago8PAovTGVuZ3RoIDQ5NDAKL1R5cGUgL01ldGFkYXRhCi9TdWJ0eXBlIC9YTUwKPj4Kc3RyZWFtDQo8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHhtbG5zOnBkZmFpZD0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2lkLyIgcmRmOmFib3V0PSIiPgogICAgICAgICA8cGRmYWlkOmNvbmZvcm1hbmNlPkE8L3BkZmFpZDpjb25mb3JtYW5jZT4KICAgICAgICAgPHBkZmFpZDpwYXJ0PjE8L3BkZmFpZDpwYXJ0PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiB4bWxuczpwZGY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8iIHJkZjphYm91dD0iIj4KICAgICAgICAgPHBkZjpQREZWZXJzaW9uPjEuNDwvcGRmOlBERlZlcnNpb24+CiAgICAgICAgIDxwZGY6UHJvZHVjZXI+VGhlIEh1c2t5IGxpYnJhcnk8L3BkZjpQcm9kdWNlcj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDIzLTA0LTIxVDA4OjQ3OjIzKzAyOjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiByZGY6YWJvdXQ9IiI+CiAgICAgICAgIDxkYzpmb3JtYXQ+YXBwbGljYXRpb24vcGRmPC9kYzpmb3JtYXQ+CiAgICAgICAgIDxkYzpjcmVhdG9yPgogICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgPHJkZjpsaT5BdXRob3I8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICA8L2RjOmNyZWF0b3I+CiAgICAgICAgIDxkYzp0aXRsZT4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+Q2FydGUgZGUgbcOpZGljYXRpb248L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOnRpdGxlPgogICAgICAgICA8ZGM6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPkxlYW5kcmEgQ29yaW5hIEJlaGx1bGktUWF6aW1pPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkFsdD4KICAgICAgICAgPC9kYzpkZXNjcmlwdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24geG1sbnM6cGRmYUV4dGVuc2lvbj0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2V4dGVuc2lvbi8iCiAgICAgICAgICAgICAgICAgICAgICAgIHhtbG5zOnBkZmFQcm9wZXJ0eT0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL3Byb3BlcnR5IyIKICAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM6cGRmYVNjaGVtYT0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL3NjaGVtYSMiCiAgICAgICAgICAgICAgICAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICAgPHBkZmFFeHRlbnNpb246c2NoZW1hcz4KICAgICAgICAgICAgPHJkZjpCYWc+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpzY2hlbWE+QWRvYmUgUERGIFNjaGVtYTwvcGRmYVNjaGVtYTpzY2hlbWE+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOm5hbWVzcGFjZVVSST5odHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvPC9wZGZhU2NoZW1hOm5hbWVzcGFjZVVSST4KICAgICAgICAgICAgICAgICAgPHBkZmFTY2hlbWE6cHJlZml4PnBkZjwvcGRmYVNjaGVtYTpwcmVmaXg+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5QREZWZXJzaW9uPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+VGV4dDwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPlRoZSBQREYgZmlsZSB2ZXJzaW9uLjwvcGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6bmFtZT5LZXl3b3JkczwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPlRleHQ8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+ZXh0ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5LZXl3b3Jkcy48L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+UHJvZHVjZXI8L3BkZmFQcm9wZXJ0eTpuYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OnZhbHVlVHlwZT5BZ2VudE5hbWU8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5UaGUgbmFtZSBvZiB0aGUgdG9vbCB0aGF0IGNyZWF0ZWQgdGhlIFBERiBkb2N1bWVudC48L3BkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgICAgICAgIDwvcmRmOlNlcT4KICAgICAgICAgICAgICAgICAgPC9wZGZhU2NoZW1hOnByb3BlcnR5PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnNjaGVtYT5QREYvQSBJRCBTY2hlbWE8L3BkZmFTY2hlbWE6c2NoZW1hPgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+aHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2lkLzwvcGRmYVNjaGVtYTpuYW1lc3BhY2VVUkk+CiAgICAgICAgICAgICAgICAgIDxwZGZhU2NoZW1hOnByZWZpeD5wZGZhaWQ8L3BkZmFTY2hlbWE6cHJlZml4PgogICAgICAgICAgICAgICAgICA8cGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5Om5hbWU+cGFydDwvcGRmYVByb3BlcnR5Om5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6dmFsdWVUeXBlPkludGVnZXI8L3BkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwZGZhUHJvcGVydHk6Y2F0ZWdvcnk+aW50ZXJuYWw8L3BkZmFQcm9wZXJ0eTpjYXRlZ29yeT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpkZXNjcmlwdGlvbj5QYXJ0IG9mIFBERi9BIHN0YW5kYXJkPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpuYW1lPmNvbmZvcm1hbmNlPC9wZGZhUHJvcGVydHk6bmFtZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTp2YWx1ZVR5cGU+VGV4dDwvcGRmYVByb3BlcnR5OnZhbHVlVHlwZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBkZmFQcm9wZXJ0eTpjYXRlZ29yeT5pbnRlcm5hbDwvcGRmYVByb3BlcnR5OmNhdGVnb3J5PgogICAgICAgICAgICAgICAgICAgICAgICAgICA8cGRmYVByb3BlcnR5OmRlc2NyaXB0aW9uPkNvbmZvcm1hbmNlIGxldmVsIG9mIFBERi9BIHN0YW5kYXJkPC9wZGZhUHJvcGVydHk6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgICAgICAgICAgIDwvcGRmYVNjaGVtYTpwcm9wZXJ0eT4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkJhZz4KICAgICAgICAgPC9wZGZhRXh0ZW5zaW9uOnNjaGVtYXM+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJ3Ij8+Cg0KZW5kc3RyZWFtCmVuZG9iago0IDAgb2JqCjw8Ci9NYXJrZWQgdHJ1ZQo+PgplbmRvYmoKNSAwIG9iago8PAovRGlzcGxheURvY1RpdGxlIHRydWUKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1R5cGUgL091dHB1dEludGVudAovUyAvR1RTX1BERkExCi9EZXN0T3V0cHV0UHJvZmlsZSAxMCAwIFIKL0luZm8gKHNSR0IgSUVDNjE5NjYtMi4xKQovT3V0cHV0Q29uZGl0aW9uIChzUkdCIElFQzYxOTY2LTIuMSkKL091dHB1dENvbmRpdGlvbklkZW50aWZpZXIgKHNSR0IgSUVDNjE5NjYtMi4xKQovUmVnaXN0cnlOYW1lIChodHRwOi8vd3d3LmNvbG9yLm9yZykKPj4KZW5kb2JqCjcgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdFRyZWVSb290Ci9Sb2xlTWFwIDExIDAgUgovSyAxMiAwIFIKL1BhcmVudFRyZWVOZXh0S2V5IDEKL1BhcmVudFRyZWUgMTMgMCBSCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9UeXBlIC9QYWdlCi9NZWRpYUJveCBbMC4wIDAuMCA4NDEuODc1IDU5NS4yNzVdCi9QYXJlbnQgMiAwIFIKL0NvbnRlbnRzIDE0IDAgUgovUmVzb3VyY2VzIDE1IDAgUgovU3RydWN0UGFyZW50cyAwCi9UYWJzIC9TCj4+CmVuZG9iagoxMCAwIG9iago8PAovTGVuZ3RoIDI0NzIKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL04gMwo+PgpzdHJlYW0NCnic7ZlnUFRZFoDve50TDd1Nk6HJSaKEBiTnJDmKCnQ3mRaaDCqKDI7ACCIiSRFEFHDA0SHIKCqiGBAFBVTUaWQQUMbBUURFZWn8Mbs1P7a2amv/bJ8f73117ql3zn11q95X9QCQISawElNgfQASuak8X2c7RnBIKAPzAGABCRABBaAjWClJnn5O/mA1BLXgb/F+DECC+30dwXruOVJM0Qcdw2MzLo/fTjRv/nv9vwSRnchlAwDRVjmOzUlhrfKuVY5hJ7IF+VkBZ6QmpQIAe68yjbc64CqzBRz5jTMFHP2Ni9dq/H3tV/kYAFhi9BrjTws4co0p3QJmxfASAZDuX61XYSXxVp8vLeil+G2GtRAV7IcRzeFyeBGpHDbj32zlP49/6oVKWX35//UG/+M+grPzjd5arp0JiF75V25bOQDM1wAgSv/KqRwBgLwHgM7ev3KRJwDoKgVA8hkrjZf+LYdcmx3gARnQgBSQB8pAA+gAQ2AKLIANcARuwAv4gxCwBbBADEgEPJABtoPdoAAUgVJwCFSDOtAImkEbOAu6wAVwBVwHt8E9MAomAB9Mg1dgAbwHyxAEYSASRIWkIAVIFdKGDCEmZAU5Qh6QLxQChUPREBdKg7ZDe6AiqAyqhuqhZugn6Dx0BboJDUOPoEloDvoT+gQjYCJMg+VgNVgPZsK2sDvsD2+Go+FkOBvOh/fDlXADfBruhK/At+FRmA+/ghcRAEFA0BGKCB0EE2GP8EKEIqIQPMRORCGiAtGAaEP0IAYQ9xF8xDziIxKNpCIZSB2kBdIFGYBkIZORO5HFyGrkKWQnsh95HzmJXEB+RZFQsihtlDnKFRWMikZloApQFagmVAfqGmoUNY16j0aj6Wh1tCnaBR2CjkPnoIvRR9Dt6MvoYfQUehGDwUhhtDGWGC9MBCYVU4CpwpzGXMKMYKYxH7AErALWEOuEDcVysXnYCmwLthc7gp3BLuNEcao4c5wXjo3LwpXgGnE9uLu4adwyXgyvjrfE++Pj8Lvxlfg2/DX8E/xbAoGgRDAj+BBiCbsIlYQzhBuEScJHIoWoRbQnhhHTiPuJJ4mXiY+Ib0kkkhrJhhRKSiXtJzWTrpKekT6IUEV0RVxF2CK5IjUinSIjIq/JOLIq2Za8hZxNriCfI98lz4viRNVE7UUjRHeK1oieFx0XXRSjihmIeYklihWLtYjdFJulYChqFEcKm5JPOU65SpmiIqjKVHsqi7qH2ki9Rp2moWnqNFdaHK2I9iNtiLYgThE3Eg8UzxSvEb8ozqcj6Gp0V3oCvYR+lj5G/yQhJ2ErwZHYJ9EmMSKxJCkjaSPJkSyUbJcclfwkxZBylIqXOiDVJfVUGimtJe0jnSF9VPqa9LwMTcZChiVTKHNW5rEsLKsl6yubI3tcdlB2UU5ezlkuSa5K7qrcvDxd3kY+Tr5cvld+ToGqYKUQq1CucEnhJUOcYctIYFQy+hkLirKKLoppivWKQ4rLSupKAUp5Su1KT5XxykzlKOVy5T7lBRUFFU+V7SqtKo9VcapM1RjVw6oDqktq6mpBanvVutRm1SXVXdWz1VvVn2iQNKw1kjUaNB5oojWZmvGaRzTvacFaxloxWjVad7VhbRPtWO0j2sPrUOvM1nHXNawb1yHq2Oqk67TqTOrSdT1083S7dF/rqeiF6h3QG9D7qm+sn6DfqD9hQDFwM8gz6DH401DLkGVYY/hgPWm90/rc9d3r3xhpG3GMjho9NKYaexrvNe4z/mJiasIzaTOZM1UxDTetNR1n0pjezGLmDTOUmZ1ZrtkFs4/mJuap5mfN/7DQsYi3aLGY3aC+gbOhccOUpZJlhGW9Jd+KYRVudcyKb61oHWHdYP3cRtmGbdNkM2OraRtne9r2tZ2+Hc+uw27J3tx+h/1lB4SDs0Ohw5AjxTHAsdrxmZOSU7RTq9OCs7FzjvNlF5SLu8sBl3FXOVeWa7Prgpup2w63fneiu597tftzDy0PnkePJ+zp5nnQ88lG1Y3cjV1ewMvV66DXU29172TvX3zQPt4+NT4vfA18t/sO+FH9tvq1+L33t/Mv8Z8I0AhIC+gLJAeGBTYHLgU5BJUF8YP1gncE3w6RDokN6Q7FhAaGNoUubnLcdGjTdJhxWEHY2Gb1zZmbb26R3pKw5eJW8taIrefCUeFB4S3hnyO8IhoiFiNdI2sjF1j2rMOsV2wbdjl7jmPJKePMRFlGlUXNRltGH4yei7GOqYiZj7WPrY59E+cSVxe3FO8VfzJ+JSEooT0RmxieeJ5L4cZz+7fJb8vcNpyknVSQxE82Tz6UvMBz5zWlQCmbU7pTaasf6cE0jbTv0ibTrdJr0j9kBGacyxTL5GYOZmll7cuayXbKPpGDzGHl9G1X3L57++QO2x31O6GdkTv7cpVz83OndznvOrUbvzt+9508/byyvHd7gvb05Mvl78qf+s75u9YCkQJewfhei7113yO/j/1+aN/6fVX7vhayC28V6RdVFH0uZhXf+sHgh8ofVvZH7R8qMSk5Woou5ZaOHbA+cKpMrCy7bOqg58HOckZ5Yfm7Q1sP3awwqqg7jD+cdphf6VHZXaVSVVr1uTqmerTGrqa9VrZ2X+3SEfaRkaM2R9vq5OqK6j4diz32sN65vrNBraHiOPp4+vEXjYGNAyeYJ5qbpJuKmr6c5J7kn/I91d9s2tzcIttS0gq3prXOnQ47fe9Hhx+723Ta6tvp7UVnwJm0My9/Cv9p7Kz72b5zzHNtP6v+XNtB7SjshDqzOhe6Yrr43SHdw+fdzvf1WPR0/KL7y8kLihdqLopfLOnF9+b3rlzKvrR4Oeny/JXoK1N9W/smrgZffdDv0z90zf3ajetO168O2A5cumF548JN85vnbzFvdd02ud05aDzYccf4TseQyVDnXdO73ffM7vUMbxjuHbEeuXLf4f71B64Pbo9uHB0eCxh7OB42zn/Ifjj7KOHRm8fpj5cndj1BPSl8Kvq04pnss4ZfNX9t55vwL046TA4+93s+McWaevVbym+fp/NfkF5UzCjMNM8azl6Yc5q793LTy+lXSa+W5wt+F/u99rXG65//sPljcCF4YfoN783Kn8Vvpd6efGf0rm/Re/HZ+8T3y0uFH6Q+nPrI/DjwKejTzHLGZ8znyi+aX3q+un99spK4siJ0AaELCF1A6AJCFxC6gNAFhC4gdAGhCwhdQOgCQhcQuoDQBf6PXWDtP85qIASX4+MA+OcA4HEHgKpqANSiACCHpXIyUwWr3G0M1rakLF5sdEzqOkZaCocRxeNwErIEa/8ANSYTGw0KZW5kc3RyZWFtCmVuZG9iagoxMSAwIG9iago8PAovSW5saW5lU2hhcGUgL0ZpZ3VyZQovU3RyaWtlb3V0IC9TcGFuCi9Ecm9wQ2FwIC9GaWd1cmUKL0VuZE5vdGUgL05vdGUKL091dGxpbmUgL1NwYW4KL1N1YnNjcmlwdCAvU3BhbgovU3VwZXJzY3JpcHQgL1NwYW4KL0Fubm90YXRpb24gL1NwYW4KL0FydGlmYWN0IC9QCi9EaWFncmFtIC9GaWd1cmUKL0Zvb3ROb3RlIC9Ob3RlCi9VbmRlcmxpbmUgL1NwYW4KL0JpYmxpb2dyYXBoeSAvQmliRW50cnkKL0NoYXJ0IC9GaWd1cmUKPj4KZW5kb2JqCjEyIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Eb2N1bWVudAovTGFuZyAoZnItQ0gpCi9QIDcgMCBSCi9LIDE2IDAgUgo+PgplbmRvYmoKMTMgMCBvYmoKPDwKL051bXMgWzAgWzE3IDAgUiAxOCAwIFIgMTkgMCBSIDIwIDAgUiAyMSAwIFIgMjIgMCBSIDIzIDAgUiAyNCAwIFIgMjUgMCBSIDI2IDAgUgoyNyAwIFIgMjggMCBSIDI5IDAgUiAzMCAwIFIgMzEgMCBSIDMyIDAgUiAzMyAwIFIgMzQgMCBSIDM1IDAgUiAzNiAwIFIKMzcgMCBSIDM4IDAgUiAzOSAwIFIgNDAgMCBSIDQxIDAgUiA0MiAwIFIgNDMgMCBSIDQ0IDAgUl0KXQo+PgplbmRvYmoKMTQgMCBvYmoKPDwKL0xlbmd0aCAxOTkzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJylWltvFTcQNqQP1T5UbQGpD4juA+VSysbjuyWKFHICFIU2oQlpVfqAqGiLstyE1L/fsddnj88ej7O0ivbs7thjf56rPRvecWl1+08j2kcNb181wNvHzW+/t7z9o9neef/h75fPX3xotw/ev3kL7b3FbsM7ZZWGlnfaKRnuRnoh2vd/NveOmu370IJoj1422IJ/0ArXSd1qazvBOYf2qG/u4IPjoPY4Fz7dF8OdAz5bvPjwLB1e+O528W7w2knPLr2Hu099wzuOYdTQTy7utkevmr2jAZiYAJPOddpqhLQG7gaTbMEesYds62aNXYHvvBFaTNkv1tmEQYFZvTHrFntw9pwKmXHODeb1Oacq0F5FNasp26fnfmTPbuLPbbzOsVvsMruN9+usxd8Of28zYFfZlfjess/w+jq+X2bbeP8WmbHhE3aeXWDnlxD2Hu9OLUdEy6mYB/BORFUk60ANwm60Ci7ur6wBsudIX6R+atVPuHT3A23KxxfDc+TzqS2NE9vDWDtpbpX6LNtkGlsOVip5slbsZ5AHxNBX6sQbsKiZVpjL4OONcJ17rg2uc32cCRIzvhu7WmU7jV1b0TkUiGpf9Djgm/c9tIs3zWE0lHdNig/GdF5ortu+cSA7jc8io55m1MDhAvrTxLxByPn+ak6a11ODlNEgC5aqqAZNNRiqwVINjmrwVAMGZaoFyBZBtpCrB3L5QK4fSAEAKQEgRQCkDMQgAx4Sj9DK4916w11IPIPWpfIduiDaQb80DA+dR0OXwTLAJcMtU1fcwWZeFiEMwi7x9DlVhBwZPOO0Ce6iQpSgqDNmHRRZ4ukzar4qo1zncS5FUOfMOhhJiacnxs88tEidMytpgEJPZT/Ks6d062TnNmSzouYaofAMxl3i6YnxpUQsQhdpc2YcnGaToy+P7EWnYbryFXXOjIMzlnh6Yvyy1ZVtnZqVdHRJBjtJBjtJBjtJBjtJ2pokg500aQ/slcd1Tu9jKBJGJlGMoUiLjieROBCdtdFRytSRexCfwCzPY75eibvPqVn/4ArCVaiZwsLYQWlp1mzsjJqNEqhcVKiTsUtYegJLaY2nxBrD2AaDiYy7ihx3Rs36h3BleIVakMl0nT2xzpL8Tgn5hbFDOPQT1+lzatY/UEFXqBPcpXX2xDpL8jsl5BfGxv0e/qGBl6CuLWDNpEeoZepkkpLHkZsISW4iJBlbFBlbFJy1vQDv44Z35dOgRDpNoaVKZCyTRj5ykWoIXxsM/UiyCAd1FP3N2Q4jcpk2Y64hIG5y9CtatgiDS+UuzEJQZ8w4BNoST0+Mv9o0ENQZs5JBXJk1aY9i7EtKlFxG7yCImQ4oHCmhb7L0xOBGdzY+E9QZc6aUXuDpifHDmVDFRE9QZ8w6uF2Jp6fGL1hcyb6JGTXpzprcKmhxVgpfxbIVrDzCAT4Nu808lhHUbGHUIrIdys9vn79OVLWMR/i3rK3JFjfIm7U1gQp1obwTT+LX2IIds5Nwkh/O8+yAvcWnfXYfW07w/oQdVoo1mnQcbYpI7aq6I1s82uXVDdO5sGVVRiTtj8WNAOQhO2QnNShkiNe+BMXwFZSNQssSisAUh6FDDlC2EcQCYTxAmS1QVtdQOscI7TC+fcOe3WC3sJPD6zv2OVPsKvsenzheWxXkhrQ/Q25VDblVNaq4WromQZ7JjS2O5GbIDbenYEYVXmIX2Zd4XcLfS+wC/l2qiYPMyJZ0YUuK0JIitKQILbnbt6QYbdHebcXeFbqijxlKaTwcirE8dh3N7BiNap+9w/vglE+iU/4w2zEt6Q226A2u4g0ZUDyr2bgdj0AtEwhWVGA4Ui9OFGFIWl6pcGN8yusJQnDF/RjCDoYYwZ6ixBYop5Mosac1eKSinS7CG5Q87m+rTiDBpGptRAqosYMYZn+ZhNmDM2Obo+uDrojT09oUAlMm2rHE/cua0T1BwcU6cgWIJz3QQwmIFxWz0qrzQxFhXVLXoqSW2gzaPa6DIh3ZF2Oh1zQoo22HmwrcnkxAeQS1H53xIYLaYj/he1DeT0h9OsslPRlofTHQ+kqgHZXIRTofR5A8AanCqFSOeQkHcKgA8aKTYQe2gWQ/2HcFB3C66MyL2xzgqpJ6FEoknv4nSExU3HEVCV2w5sWwDtxW7JpDOvtPkAB6/n7Vz4HTxW5ejNsAY6k72/tRIUlY2aFJL/czlmncmlzF+7PgdVv4sGB7aNJbmKa/YF/FOPWohrfySQGKAR5A1iKCXlZ7cqB3ON+5N3xQ0+EKNQeHd7RXZVfvoV0pfPfDuzKJZrP28JFvJ7WHvu5ubXX0Jw4o5gdIHzgq+StUqWw8w1bzV3jawra3+BZ2A79WIyBUPp9AMUNA+ngyL5WBwQeZGfJ/T2Ug6O9TophDQFSSiJC+4xGig1gb+Kh0BoL+vCWKuQNEJXkor5ffStcF9rEZDQT9oUwUkwWISrYwqMehqjfB9f+TGtC1eZDldCJr6WRUpxadjqfi2YkN6MI+yHJCkbWEgmcYpWPpY4rlzNRGfxQAWU4ospJQpFWdQHv0UyQzUhtd+ARZTiiqdhKQKp0EJkhmpDZFpwpVThWp+hjKrNIKrUO51XDryH8fGsOVUOnjYQR3HlV2Ba/4Dyjb7Da7jDlvm7Uh67WBul3FvYoDh82/et9TZg0KZW5kc3RyZWFtCmVuZG9iagoxNSAwIG9iago8PAovUHJvcGVydGllcyA0NSAwIFIKL0ZvbnQgNDYgMCBSCi9YT2JqZWN0IDw8Ci9Gb3JtMSA0NyAwIFIKPj4KPj4KZW5kb2JqCjE2IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9EaXYKL1AgMTIgMCBSCi9QZyA5IDAgUgovSyBbMTcgMCBSIDQ4IDAgUiAyNCAwIFIgNDkgMCBSIDM1IDAgUiA1MCAwIFJdCj4+CmVuZG9iagoxNyAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvSDEKL1AgMTYgMCBSCi9QZyA5IDAgUgovSyAwCj4+CmVuZG9iagoxOCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvSDIKL1AgNTEgMCBSCi9QZyA5IDAgUgovSyAxCj4+CmVuZG9iagoxOSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvU3BhbgovUCA1MiAwIFIKL1BnIDkgMCBSCi9LIFsyIDUzIDAgUl0KPj4KZW5kb2JqCjIwIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9TcGFuCi9QIDUzIDAgUgovUGcgOSAwIFIKL0sgMwo+PgplbmRvYmoKMjEgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1NwYW4KL1AgNTIgMCBSCi9QZyA5IDAgUgovSyBbNTQgMCBSIDRdCj4+CmVuZG9iagoyMiAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvSDIKL1AgNTUgMCBSCi9QZyA5IDAgUgovSyA1Cj4+CmVuZG9iagoyMyAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvRGl2Ci9QIDU1IDAgUgovUGcgOSAwIFIKL0sgNgo+PgplbmRvYmoKMjQgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL0gyCi9QIDE2IDAgUgovUGcgOSAwIFIKL0sgNwo+PgplbmRvYmoKMjUgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDU2IDAgUgovUGcgOSAwIFIKL0EgNTcgMCBSCi9LIDgKPj4KZW5kb2JqCjI2IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA1NiAwIFIKL1BnIDkgMCBSCi9BIDU4IDAgUgovSyA5Cj4+CmVuZG9iagoyNyAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNTYgMCBSCi9QZyA5IDAgUgovQSA1OSAwIFIKL0sgMTAKPj4KZW5kb2JqCjI4IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA1NiAwIFIKL1BnIDkgMCBSCi9BIDYwIDAgUgovSyAxMQo+PgplbmRvYmoKMjkgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDYxIDAgUgovUGcgOSAwIFIKL0sgMTIKPj4KZW5kb2JqCjMwIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MSAwIFIKL1BnIDkgMCBSCi9LIDEzCj4+CmVuZG9iagozMSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNjEgMCBSCi9QZyA5IDAgUgovSyAxNAo+PgplbmRvYmoKMzIgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDYxIDAgUgovUGcgOSAwIFIKL0sgMTUKPj4KZW5kb2JqCjMzIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MiAwIFIKL1BnIDkgMCBSCi9LIDE2Cj4+CmVuZG9iagozNCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNjIgMCBSCi9QZyA5IDAgUgovSyAxNwo+PgplbmRvYmoKMzUgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL0gyCi9QIDE2IDAgUgovUGcgOSAwIFIKL0sgMTgKPj4KZW5kb2JqCjM2IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MyAwIFIKL1BnIDkgMCBSCi9BIDY0IDAgUgovSyAxOQo+PgplbmRvYmoKMzcgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDYzIDAgUgovUGcgOSAwIFIKL0EgNjUgMCBSCi9LIDIwCj4+CmVuZG9iagozOCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNjMgMCBSCi9QZyA5IDAgUgovQSA2NiAwIFIKL0sgMjEKPj4KZW5kb2JqCjM5IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MyAwIFIKL1BnIDkgMCBSCi9BIDY3IDAgUgovSyAyMgo+PgplbmRvYmoKNDAgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDY4IDAgUgovUGcgOSAwIFIKL0sgMjMKPj4KZW5kb2JqCjQxIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2OCAwIFIKL1BnIDkgMCBSCi9LIDI0Cj4+CmVuZG9iago0MiAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNjggMCBSCi9QZyA5IDAgUgovSyAyNQo+PgplbmRvYmoKNDMgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDY4IDAgUgovUGcgOSAwIFIKL0sgMjYKPj4KZW5kb2JqCjQ0IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2OSAwIFIKL1BnIDkgMCBSCi9BIDcwIDAgUgovSyAyNwo+PgplbmRvYmoKNDUgMCBvYmoKPDwKL1Byb3AxIDcxIDAgUgovUHJvcDIgNzIgMCBSCi9Qcm9wMyA3MyAwIFIKL1Byb3A0IDc0IDAgUgovUHJvcDUgNzUgMCBSCi9Qcm9wNiA3NiAwIFIKL1Byb3A3IDc3IDAgUgovUHJvcDggNzggMCBSCi9Qcm9wOSA3OSAwIFIKL1Byb3AxMCA4MCAwIFIKL1Byb3AxMSA4MSAwIFIKL1Byb3AxMiA4MiAwIFIKL1Byb3AxMyA4MyAwIFIKL1Byb3AxNCA4NCAwIFIKL1Byb3AxNSA4NSAwIFIKL1Byb3AxNiA4NiAwIFIKL1Byb3AxNyA4NyAwIFIKL1Byb3AxOCA4OCAwIFIKL1Byb3AxOSA4OSAwIFIKL1Byb3AyMCA5MCAwIFIKL1Byb3AyMSA5MSAwIFIKL1Byb3AyMiA5MiAwIFIKL1Byb3AyMyA5MyAwIFIKL1Byb3AyNCA5NCAwIFIKL1Byb3AyNSA5NSAwIFIKL1Byb3AyNiA5NiAwIFIKL1Byb3AyNyA5NyAwIFIKL1Byb3AyOCA5OCAwIFIKL1Byb3AyOSA5OSAwIFIKL1Byb3AzMCAxMDAgMCBSCi9Qcm9wMzEgMTAxIDAgUgovUHJvcDMyIDEwMiAwIFIKL1Byb3AzMyAxMDMgMCBSCi9Qcm9wMzQgMTA0IDAgUgovUHJvcDM1IDEwNSAwIFIKL1Byb3AzNiAxMDYgMCBSCi9Qcm9wMzcgMTA3IDAgUgovUHJvcDM4IDEwOCAwIFIKL1Byb3AzOSAxMDkgMCBSCi9Qcm9wNDAgMTEwIDAgUgovUHJvcDQxIDExMSAwIFIKL1Byb3A0MiAxMTIgMCBSCi9Qcm9wNDMgMTEzIDAgUgovUHJvcDQ0IDExNCAwIFIKL1Byb3A0NSAxMTUgMCBSCi9Qcm9wNDYgMTE2IDAgUgovUHJvcDQ3IDExNyAwIFIKL1Byb3A0OCAxMTggMCBSCi9Qcm9wNDkgMTE5IDAgUgovUHJvcDUwIDEyMCAwIFIKL1Byb3A1MSAxMjEgMCBSCi9Qcm9wNTIgMTIyIDAgUgovUHJvcDUzIDEyMyAwIFIKL1Byb3A1NCAxMjQgMCBSCi9Qcm9wNTUgMTI1IDAgUgovUHJvcDU2IDEyNiAwIFIKL1Byb3A1NyAxMjcgMCBSCi9Qcm9wNTggMTI4IDAgUgovUHJvcDU5IDEyOSAwIFIKL1Byb3A2MCAxMzAgMCBSCi9Qcm9wNjEgMTMxIDAgUgovUHJvcDYyIDEzMiAwIFIKL1Byb3A2MyAxMzMgMCBSCi9Qcm9wNjQgMTM0IDAgUgovUHJvcDY1IDEzNSAwIFIKL1Byb3A2NiAxMzYgMCBSCi9Qcm9wNjcgMTM3IDAgUgovUHJvcDY4IDEzOCAwIFIKL1Byb3A2OSAxMzkgMCBSCi9Qcm9wNzAgMTQwIDAgUgovUHJvcDcxIDE0MSAwIFIKL1Byb3A3MiAxNDIgMCBSCi9Qcm9wNzMgMTQzIDAgUgovUHJvcDc0IDE0NCAwIFIKL1Byb3A3NSAxNDUgMCBSCi9Qcm9wNzYgMTQ2IDAgUgovUHJvcDc3IDE0NyAwIFIKL1Byb3A3OCAxNDggMCBSCi9Qcm9wNzkgMTQ5IDAgUgovUHJvcDgwIDE1MCAwIFIKL1Byb3A4MSAxNTEgMCBSCi9Qcm9wODIgMTUyIDAgUgovUHJvcDgzIDE1MyAwIFIKL1Byb3A4NCAxNTQgMCBSCi9Qcm9wODUgMTU1IDAgUgovUHJvcDg2IDE1NiAwIFIKL1Byb3A4NyAxNTcgMCBSCi9Qcm9wODggMTU4IDAgUgovUHJvcDg5IDE1OSAwIFIKL1Byb3A5MCAxNjAgMCBSCi9Qcm9wOTEgMTYxIDAgUgovUHJvcDkyIDE2MiAwIFIKL1Byb3A5MyAxNjMgMCBSCi9Qcm9wOTQgMTY0IDAgUgovUHJvcDk1IDE2NSAwIFIKL1Byb3A5NiAxNjYgMCBSCi9Qcm9wOTcgMTY3IDAgUgovUHJvcDk4IDE2OCAwIFIKL1Byb3A5OSAxNjkgMCBSCi9Qcm9wMTAwIDE3MCAwIFIKL1Byb3AxMDEgMTcxIDAgUgovUHJvcDEwMiAxNzIgMCBSCi9Qcm9wMTAzIDE3MyAwIFIKL1Byb3AxMDQgMTc0IDAgUgovUHJvcDEwNSAxNzUgMCBSCi9Qcm9wMTA2IDE3NiAwIFIKL1Byb3AxMDcgMTc3IDAgUgovUHJvcDEwOCAxNzggMCBSCi9Qcm9wMTA5IDE3OSAwIFIKL1Byb3AxMTAgMTgwIDAgUgovUHJvcDExMSAxODEgMCBSCi9Qcm9wMTEyIDE4MiAwIFIKL1Byb3AxMTMgMTgzIDAgUgovUHJvcDExNCAxODQgMCBSCi9Qcm9wMTE1IDE4NSAwIFIKL1Byb3AxMTYgMTg2IDAgUgovUHJvcDExNyAxODcgMCBSCi9Qcm9wMTE4IDE4OCAwIFIKL1Byb3AxMTkgMTg5IDAgUgovUHJvcDEyMCAxOTAgMCBSCi9Qcm9wMTIxIDE5MSAwIFIKL1Byb3AxMjIgMTkyIDAgUgovUHJvcDEyMyAxOTMgMCBSCi9Qcm9wMTI0IDE5NCAwIFIKL1Byb3AxMjUgMTk1IDAgUgovUHJvcDEyNiAxOTYgMCBSCi9Qcm9wMTI3IDE5NyAwIFIKL1Byb3AxMjggMTk4IDAgUgovUHJvcDEyOSAxOTkgMCBSCi9Qcm9wMTMwIDIwMCAwIFIKL1Byb3AxMzEgMjAxIDAgUgovUHJvcDEzMiAyMDIgMCBSCi9Qcm9wMTMzIDIwMyAwIFIKL1Byb3AxMzQgMjA0IDAgUgovUHJvcDEzNSAyMDUgMCBSCi9Qcm9wMTM2IDIwNiAwIFIKL1Byb3AxMzcgMjA3IDAgUgovUHJvcDEzOCAyMDggMCBSCi9Qcm9wMTM5IDIwOSAwIFIKL1Byb3AxNDAgMjEwIDAgUgovUHJvcDE0MSAyMTEgMCBSCi9Qcm9wMTQyIDIxMiAwIFIKL1Byb3AxNDMgMjEzIDAgUgovUHJvcDE0NCAyMTQgMCBSCj4+CmVuZG9iago0NiAwIG9iago8PAovRjEgMjE1IDAgUgovRjIgMjE2IDAgUgovRjMgMjE3IDAgUgo+PgplbmRvYmoKNDcgMCBvYmoKPDwKL0xlbmd0aCA1NDg2Ci9UeXBlIC9YT2JqZWN0Ci9TdWJ0eXBlIC9Gb3JtCi9SZXNvdXJjZXMgPDwKL0V4dEdTdGF0ZSAyMTggMCBSCj4+Ci9CQm94IFswLjAgMC4wIDg1LjAgMzAuMF0KL0ZpbHRlciAvRmxhdGVEZWNvZGUKL01hdHJpeCBbMC43NSAwLjAgMC4wIDAuNzUgMC4wIDAuMF0KPj4Kc3RyZWFtDQp4nG1bS64lu3Gc9yruBnREMplJcmoZ8NjWwAtoyLKB2wKEBxjw7h0RSbJO920IT/dEFYufZDLyx/7nt39++3f8Vz6sfPz4Nv3VnD8/988/Ff7/J94/v/T6v7/957d/4MP+qrE+ysvwtb2m42eUiQb2itk738w2PuzV2wd7qIHftRcXio/v3xq+WoOw+/hoL1+NyMZsQN3q7pIt23B2M90c71qx+VHRm7Flw0ugbpZNS6uAo7XFl8PYd6noLjvFM89ONSAezjE/9mTaK9D5mSlQRUusoa4ltCAkrM/zu8X1Tc0oMLHvFIo3YneXKFaZnX1HZadulV8Uq3cIoFpd07G4ENNPIcQFZ4GJyquXzoFsVm1W7ewR88rfnLR3rJMw1PFqkBZgKa1/PLv3HTs6XpQrRsBe4vcc+D3d68d49T6Cw1RMeWAASsEXJxz44Rq1AftrjlUfZLO/tfVXWSv7gaz7a0XXGMPZttTybOB+WV5rFb3khwWLwap3t9CYEtntnFiMNBRT4Yyw9wdqurctlmJ9nZ6wyljzjAKEbs4MKA9u25FHbb4ASkCT8MYWex3NFgac0u7e55bI6pysFTe87GtoAtBvoLZ0EJqpZYFKCEIFuYypE0O99td479SxN2Ec0dS098Wplels+sgNb6DPVJZRKt/kxtUqNPpIbelbbsuo0M5JYTKrhtS7mCY6rurHy/Gs8RxyDaOUqs/G0OLfO4VoukYsixKt1qS6EAmlNpe/Cbji8EbqreHjH+cBVCIGTw4xfrI7kglgGYUnqS8QQQUTaKzReCJAE9YIVx16iY1ePEpNqPh6O2cLHy3T21o/Fo5240mbE0dzvaq0FN2pZaI1jLQIGfoviPMvlfPNtr9iLJ/qJRhDPFSg8evVLEROGHpRfktiLKFR3cRcbotvR+9iJesAKx5WwsrqCG0OlZd8G/u7IHQTO6LbvoU0tJzWcJQBB8hFM+r6etR+5qvWxM96sGU4mG28b1k+eLYMuKcGzAZ67q9pVSS2OGDHrEXeuWf9ZWtO7dkMvgXBTO0KmQis2urbpuGBetm7Blh5SPa2VfTi8+7bhblVgF6bf8HP4vYHXx7c7SM2Tb6MqeHLkCUx12StTkkeFJGTdVIY2Q9nkIsZfV6IpYKS3ppDFBH99Nb5/I7UYWXSBOyN2Q9+2pkJDZhs1GbuzH3QJy3ywdgKHF+gqp1fg23GK3VRCAPgxEtT821gGE1t+UXkRTUkoAmpJN7UFkgYPXbfUxxa4IAASr6flMCkVV6yRbVrQu6iarXG225EYGjP2Zdu8gwMfgN6A5mtJHYNtn2KOvb8p1wFYa7GbPsRG2wxfU/J1ckn0Si28x7oU6jtM5wdhU7IgrS44BYUKNyKPSpMGc9ir6ZZlZSq0yBQxn0cJIFAFerb62Vz3I+x3hjvnWOWppHpBmj3hqYFpdqbqTlzRQ2KowW3aVSFRkdIwtQZBcQyKB6TlkEWPIWUFmgakL7TMVKNNmfKQatkJJgkmhbSK1yDRnMVu2c1rq6PcXIb35bZKD0YoEnIP6k5eqc5wwrpFeeC9Q3OIbslTe1uYWR4eHrv6gf+HKEPnkdMuLof+P2bFiTaO+/hiLX7dQrj9p2yIh3EFs7YrmCrkkavVTwCx2bLJklE84JVP6RSFzeUw7QLKs6M1GzjwlP+cb7T4Zh+uj1QK+it5JPFgwh+LW0fFjAlJ53ede43yGN/n6y8H/D9J0FJh0nIoDMzEX4H3ULtqb/B4bQtB8vUfJ5Of0XLa3YL2+ZfMDxOEr4etBa/eXC/gMQtvsKoPzX+CcoDO53RqEIRC/cAEALTCaC5M/r8lEelMdLKfKbESoMpklC2Ka9cVWescPlVMsbxRc9dTjIkDIYpB34SNqdX72MmjJC/sTHPPiR8mqu7SY/w0vXzIOn64KRrjV79MDL6d/ozl7AbnLuki3zvL9FQO79vYERADjU+nydo4Hzpxp2wAcMVWiNipzUHwcYi3RYZuZGuZHak5hn5KUQEaunzgv009VKK2MgYW9E/TpfcZcwaTYgdzIXICw7YhA0qA4ZnF4aiFJE1G7QDPxOWutmayOvabM3l1vHwKfDqySnkW25gGz3ZWLN0kzwFNcuZvnS+Z0Cw2v16KJx8Osc0m8IZ0LXl7rV26Pps5uVrw4fBICoYRuNxZWzmUKhPwhI/weFyikJ6ZAwk59FcKtJ5grEnD/zBTebZ6B89TpWRWOLNx8IDeKKKTwOzM8RG4Vz2RORIOEqc0FatS8kAu3vOripk9cb11HRTMCRUg3DseLApoIZDYRcb2boeJ2OjSmfSs23icMtxInLfE2Oa9CkETZpIrYEqbFDyeHxnS20gPWNOkQ7xULRWmZuA4ZLhVFSe6+MGkie4QknnODkxtaTSnmibtqTucBunmCvMYLxQd7iIqYMBrcw1zfGzF/c0Wfzzgw+gDTTO8P2GunDFrzxDxlyGvKRuY4tpu03MhmB2a3UtZzHYqfT2ZdjnXlzz8POAa1XIaQybDhjjtCXG9rpW3UIC3t+NprjOdr97DfvB5/uilmmZnQt409nEN4jo3LQdREDagH3Kd+48PoDthn2dspXPpRDCECpFsRNCAPaYb9q9GMBnhAG32+ASzyJbbxTuhM8aOYxawwnlmeFrBF4GRl7Qbp4nkBOg17euwQhj7IATI9AD1amb1CiLJLQdnFyYwQhgXb+gRyt24y8PbmBCLN+MYZxrrDx2oBzOo+lIGqlUQ6/RM0SkaEbG1jqEg7DfhBcc1JoRVcvVNwUoCi0B11DiDKHlFlatq57QknBKmAotCTO7tEOY8+BtVZOb/rsn0Iue0Bn+QStos43Rt9ISMCsaYa3Szvy0101rIe0DeE8SHAnHnGJz0neqUZP3jfArqGLV11QABk0nbPOZ/MbvB7d35jreVTofHBbeMEm4m1zQrTsdG//oEVDnmSMBIzwCLBnuT47dIYvLvr3Jn77sC4ytzq2FznXaKsXewZhBwxzuxQwu83bmMkXqot4DL/c+D5Js0dGQa3thiXVeY4IMjcS9+ftSL+Fsl3o700J+qRdwyWXd1MvFeTzUK7nYQ72cxbrM25lyrJl7gYXiInpf+XWHndYa6mHejX7av9Ng8y63KCPbwQQvX2dg4xMOEKC3+ka8eGBWD/ECIe65xNtJIP0h3k4tO5DrtM265/cm3YTJufrGL6myyzreSHfP/3Lus55DuUs+Gh2jHwnQllqI3/JaECXBRnUespa+SSoZAtGlkSIj8Q7nr2ZWj/4eoHe9nzQmB/KQ5j7eB8oQ8uuZdMPWYFjzgzSYN3lZ0XGWAWdVcotLx0SL97dcIx6YrEQMOkN83xS5Lfgk+DboOZOPQascqcfbMRvbhO4zOJh6UlflDSmLqcZVOyEO6Uwiy/xhUymelN7OJ3AJJnm0LnbmInQ8Whm5iK5EMgzeBtKxvaDEfQtn9Jp+8xXVRpoTGGwnk2fKPaZietcc7XjkaAvO3x55biCCkbkzL01bstLJqcNSVNGeYICzKgdScxRJ0c++YKx0zx1qeY/Vj4SHAQWS/5xUY0f2znTEm5F21nTiMqAzyJuXAQG5zsOBfCuF2RwIDB9hp6c7+259amNjD5VhVNKgt5xqYk7L5uHBjS4NXpy0h666t4cVOZFLks48bJ5WJt43ukzIB8OSCWF0uCRX+sqYCQOMhwedLqk/PEjpeHt4kPOIhwidDn15iJArbPMhQq4iDg8meKdBPpEGLuYItIOW8Rh6Hfq6KfvjC3zFzqcKIadMQY9TDxqsqzNWydCOER6FnzF5arAzbzMPpvxUi0kJ5O99LjauKlfxs4z5TN8xyPALv58lbPz5YDgiuUZm8dq7muaD634ST7tlB8Ae45YdAOFjH/8TqLR1yw7OIkucsoOzHPMeXeFBleOZGWzvEOu6GWxAX3adxAvTLQSsynb/BJ/N282/PLhuInEo80UFAQrmROivmcYeWRkw5u01+mo6Zx26won3krzNA+wMbG4RAtCHnSIEZTDtFiEAl5X2eIoU2YhbhACsWZGVp0hYr3Or1sQ/Keli4czfd3A/SYLz+Zpvvz0yU4af5O2d7Looc10b7vzS6e8LzNzUbfwTvJkth2886xd8m9P0FP8Njvre+h3dRBdxnDSX0/gomFWay7fPfdNceGDMN540F4XRT9xVCUVI72muoNvFbAOo5ce3AJ1t8ElQTuIhyDrtorePPrMT5pd33ubHg+lCfR7I4LV/8Fu7/i/6tcw+5IGJIp4/b5VPPomtjU5qa8PMSYWqgZsVOVlGqIcjgwHFTOJTxZiXAVrP7FYj9Lae7FbocsGT3wIurd/8VjD+HTe/xcHqfMtvBQn8QK5HFpMB3AZv6S0KI06a48e32yBNjGDhiZ70cwhFCKVAmlEyWFIqaY87lOcDOUMHuHu1ZwQwBK35QZJJmNe316uq8pofM9/s752rppzhnSQGLuqa2Dw7mrPmqv78r3/73//5/rf/+Ld/+fjLX79R2bhNZelPpSP017+8N/r+x28b/fH925///kf9+Psf3/5Lt1ZujSRY9VTNi44aCZX5SpYawD3KKk5W51RJU9yNWDFLdNhHkBrdmMHyMgS2CCdNZqWTMwUrF0JWwT7rdeE9COe28eMBtWYCWN+WmfkA8GnXyNV6svBUmrEuRQaTtXTmnZsEKv1QYp+tdWC7yiKTFw7+VFhQsEHtvT8/v6kZQzH6gqKFxqCnwmAhuD6DQAhZ/IUM2imrcud4HaXCjtUMN9VW7kPOfxltLlwB0DOvYHTeqCl50YY2cLIuPckzg4adUEKeLPmyjF54hYSpsMVqd02JV3rSTMNQ4jQNWXhuum8CcmNhv2Vtsb9y9m2e0nJjNKNNhDPCCivrVqylKuHZaE33ArPoQvduZMu9w6YyOaJDUQfPTH7BUIFl98k8Lou5DEYZcOTHEPdM9w+dz7zoENE0mcpCwGBskgpWeRrxTdHkk8bwthIpe+r4lKuG2jK57rx9oGqh77seWI4KgpMpLecRGx8q31a7F2UWOU2t9ZolJQteDdHHrCjZ6rtv1rTWvoKDdS3VR+g9MBeEKJq1HB7WSeVzwmzNbcLaWDRonTcPJktbgH2maiiVTDx0nihe2kU+qNoQqEB+b6YK/RjK6pcs/xsvm2g81fNUA6fPgY2uIbzY3jLuUg1UV0h44KPfQsraal3QWIUUnH1V3Ks8MwhW1zCwZrcsQJS8XtDTY2TuH4f0Q/NhzorXmHoq0pyacLCOgGnd2gHUtqcmqn2TGlH4dBSB2R0+s57Nm8oSOPz0tfT5FMZEVZqQaaEKZNDNGfQsc/fCPBS+5N03lr2N+0ePVR+siFyB/G6WzWmrKAPeCgG2lTJQhXKyuKQBGKVWVY4zR4St1lli1MwOFnR0bHjy5i0rzwjKambCmemhS5Gp7pbjqTIKqDCMEyKnGvMnVRMstC/WmS/RepzllYM7D6Bn1QKMoCeq5aJDxCGmPelTtYWlQ492Oz+98ppF5c4YIxzPOyFJ0po8Ya6eN8YEqdCTVdkQnlnNuSrVbReeaPAYZtB0+66xNtFaIxUkw/2fut6IzlLJ7B2GX0WTboXMGDtPjoBCdqYMl4wGL4Pw2k1hRhPHgnRHt4nNnTZBnCs6ZEqTbtCXBzztB8tgkduZv6YQeBw7zd7MBKpOq42b77YmbbOxM9ylqF6lqgITy9RTySfrP57XWRoztawPMeRosqj0DrAieIlEfRsVRRsykwPsZQrWZVEX5Z5KJ5hKPXgbEngx8Gu8ZZk2tlreWzA5JcxTp1Yb78eJUKwqDYZf4G6tOQ8ylFIHDqRtXGinNePz3QOX7HnkdTNpqhin88hgifPOD3jnT8fCyn6f9bE5VtYtTRWXLkIl40eq6dJtLefWLBVwNkHS4+CpUXntEDAEaJ6MHHRJpSKm+nRNjZG07STrjMxZ6UXAHag6ZZ3ilvJqe6x2aYhlHQIbpMCm8qaXJgDztYgXk0us7TAR1m5BTMlJ9Wi8Z8q9siLc6aNR/RnlEdeUJ0K9mbiJe6UvvCu7tHBXc42nDVAUkSZLS7Gsf/FOhy7P0YbQ2sW+GLJYgKNHxHw9/i4l31iPzdsqfHscIL5tlne1spehvD5zm65FlLXyiGc6y+UYcpGecabYKH1A8OeH42it9CA7edbpVU15fVPUz3TUkMNZ6RoBFjo8LB/TTewrFbWF7poqe7ik8dUzjdt5m+R3T3gnUBEh+lD29MsDcO0c9wnvM1S6sk15xxG6ZYOzMTmrmpsQzU5+SkTIXW5KUE2pPfSTxS3ntZYh93XnnBjJ8nx28I2rRi6lrbw04LyM0XUodfHJebmCtIut7pmJwJmQUgd9lyN1wrGzJu/boAgTJ+Qx+UC955U8mXzgwjfH5Ac9xfpm8YPXRcq6Fj94ObvVa/EZofIgPiY/mP1LJ4AmnzHOGtfiK0Ss/ph8Pii0R9vk63OPa/IZY643gx+qMdZr8DHBGm1cg88VeHuz+Hiw5rgGnxJgYfMYfMqHhuex+EEhLrsWP3T72K7FD13f8zeTH4xwfFyTHzTu9Hq2yY+1r9cdox88Xx7X6A86iOva/FFT2a/Rvw+u1R+8SNbjWn30CI9xXquPKawWx+gH3UGv1+gHT1V7rD6W1OJ4ASmCWatfux/MYtFp33b/KtUx+r50NeWx+ZH3G2jq0Ti4I2n22bX3bfWDl6DnMfqYZeVx2FYfS+q6GbutPoW0bF6rP3hLovg1+6Nl7uOa+RG8qvYFH6tPqGtu2+oD4+jatfrDs1z/mP0h99Su2R+8XZq3VmT2B0/Pm9EfrM54vUZ/sHK01jH6g9ngJLFt9aUoZVt93onnVUc1mLz/fjSPWHFEKCqW3adNYQKFmSL2XzPNpbwGzH4ZJ9PRxC9FIggWFEwMMpimDlrZlmaf1iL4z1HyrlHfPWDJdLNxfFkWDjrksk4ybpjg2O0R2ebJaGu/r1rPZAqAZn9Qr5gPjDT7vhV1xUqzz+wwdSCtPu/GBv2dlVZfRmAws1TT6rP8Ncr+dywMdIckvES+qtTpHCmsIIlhfjxW5F2as5n7o8tnuha5sv+8C82CbNUEQvcpyeM8dXAMt9ewxYMFsjDVVGAWV0yP9AIoWMgr/RbikfIcyh7zgdgrtj1RkHroNQf0TD85ZdtUVRzKZvFKlMw+DhFO4pAjvw0/06C8oXwMvyMAao/dd945G0/qg6/rmtfy4/3gnbRj+U+C9zH9v+SsmHFtWcKhY/U1X/VLgy+5qrHo3IvYuu4H7AdL8z7/3upnhNlTWz5//fg3D74m2RbL4aymKC9U+M8IfpNl+02rX6bO//0/NS5lSw0KZW5kc3RyZWFtCmVuZG9iago0OCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVGFibGUKL1AgMTYgMCBSCi9QZyA5IDAgUgovSyAyMTkgMCBSCj4+CmVuZG9iago0OSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVGFibGUKL1AgMTYgMCBSCi9QZyA5IDAgUgovSyBbNTYgMCBSIDYxIDAgUiA2MiAwIFIgMjIwIDAgUl0KPj4KZW5kb2JqCjUwIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9UYWJsZQovUCAxNiAwIFIKL1BnIDkgMCBSCi9LIFs2MyAwIFIgNjggMCBSIDY5IDAgUl0KPj4KZW5kb2JqCjUxIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAyMTkgMCBSCi9QZyA5IDAgUgovSyBbMTggMCBSIDUyIDAgUl0KPj4KZW5kb2JqCjUyIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9EaXYKL1AgNTEgMCBSCi9QZyA5IDAgUgovSyBbMTkgMCBSIDIxIDAgUl0KPj4KZW5kb2JqCjUzIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9TcGFuCi9QIDE5IDAgUgovUGcgOSAwIFIKL0sgMjAgMCBSCj4+CmVuZG9iago1NCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvU3BhbgovUCAyMSAwIFIKL1BnIDkgMCBSCj4+CmVuZG9iago1NSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMjE5IDAgUgovUGcgOSAwIFIKL0sgWzIyIDAgUiAyMyAwIFJdCj4+CmVuZG9iago1NiAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDkgMCBSCi9QZyA5IDAgUgovSyBbMjUgMCBSIDI2IDAgUiAyNyAwIFIgMjggMCBSXQo+PgplbmRvYmoKNTcgMCBvYmoKPDwKL08gL1RhYmxlCi9Sb3dTcGFuIDIKPj4KZW5kb2JqCjU4IDAgb2JqCjw8Ci9PIC9UYWJsZQovQ29sU3BhbiA0Cj4+CmVuZG9iago1OSAwIG9iago8PAovTyAvVGFibGUKL1Jvd1NwYW4gMgo+PgplbmRvYmoKNjAgMCBvYmoKPDwKL08gL1RhYmxlCi9Sb3dTcGFuIDIKPj4KZW5kb2JqCjYxIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9UUgovUCA0OSAwIFIKL1BnIDkgMCBSCi9LIFsyOSAwIFIgMzAgMCBSIDMxIDAgUiAzMiAwIFJdCj4+CmVuZG9iago2MiAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDkgMCBSCi9QZyA5IDAgUgovSyBbMzMgMCBSIDIyMSAwIFIgMzQgMCBSIDIyMiAwIFJdCj4+CmVuZG9iago2MyAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNTAgMCBSCi9QZyA5IDAgUgovSyBbMzYgMCBSIDM3IDAgUiAzOCAwIFIgMzkgMCBSXQo+PgplbmRvYmoKNjQgMCBvYmoKPDwKL08gL1RhYmxlCi9Sb3dTcGFuIDIKPj4KZW5kb2JqCjY1IDAgb2JqCjw8Ci9PIC9UYWJsZQovQ29sU3BhbiA0Cj4+CmVuZG9iago2NiAwIG9iago8PAovTyAvVGFibGUKL1Jvd1NwYW4gMgo+PgplbmRvYmoKNjcgMCBvYmoKPDwKL08gL1RhYmxlCi9Sb3dTcGFuIDIKPj4KZW5kb2JqCjY4IDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9UUgovUCA1MCAwIFIKL1BnIDkgMCBSCi9LIFs0MCAwIFIgNDEgMCBSIDQyIDAgUiA0MyAwIFJdCj4+CmVuZG9iago2OSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNTAgMCBSCi9QZyA5IDAgUgovSyA0NCAwIFIKPj4KZW5kb2JqCjcwIDAgb2JqCjw8Ci9PIC9UYWJsZQovQ29sU3BhbiA3Cj4+CmVuZG9iago3MSAwIG9iago8PAovVHlwZSAvUGFnaW5hdGlvbgo+PgplbmRvYmoKNzIgMCBvYmoKPDwKL1R5cGUgL1BhZ2luYXRpb24KPj4KZW5kb2JqCjczIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAxMTMuNjYyNTA2IDgxMy41MjUgNTY2LjkyNTA1XQo+PgplbmRvYmoKNzQgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDExMy42NjI1MDYgODEzLjUyNSA1NjYuOTI1MDVdCj4+CmVuZG9iago3NSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMTEzLjY2MjUwNiA4MTMuNTI1IDU2Ni45MjUwNV0KPj4KZW5kb2JqCjc2IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSA1MTYuNDUgODEzLjUyNSA1NTAuODM3NV0KPj4KZW5kb2JqCjc3IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSA0MDEuODEyNSA4MTMuNTI1IDUwMC4zNjI1XQo+PgplbmRvYmoKNzggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDQwMS44MTI1IDgxMy41MjUgNTAwLjM2MjVdCj4+CmVuZG9iago3OSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgNDAxLjgxMjUgODEzLjUyNSA1MDAuMzYyNV0KPj4KZW5kb2JqCjgwIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQwNy40NzUwNCA0MDguOSA0OTQuNzAwMDRdCj4+CmVuZG9iago4MSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSA0NTUuNDAwMDIgNDA4LjkgNDgxLjJdCj4+CmVuZG9iago4MiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSA0MDcuNDc1MDQgNDA4LjkgNDQxLjkwMDAyXQo+PgplbmRvYmoKODMgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQyNS45MjUwMiA0MDcuNDc1MDQgODA1LjAxMjUgNDk0LjcwMDA0XQo+PgplbmRvYmoKODQgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQyNS45MjUwMiA0NDYuODEyNSA4MDUuMDEyNSA0NzIuNjEyNV0KPj4KZW5kb2JqCjg1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0MjUuOTI1MDIgNDE2LjEwMDA0IDgwNS4wMTI1IDQzMy4zMTI1M10KPj4KZW5kb2JqCjg2IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAzNjIuNTEyNSA4MTMuNTI1IDM4OC4zMTI1XQo+PgplbmRvYmoKODcgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDI1Mi4wNzUwMSA4MTMuNTI1IDM0OS4wMTI1XQo+PgplbmRvYmoKODggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDI5MS45Mzc1MyA4MTMuNTI1IDM0OS4wMTI1NF0KPj4KZW5kb2JqCjg5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAzMjAuNDc1IDgxMy41MjUgMzQ5LjAxMjVdCj4+CmVuZG9iago5MCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAyOTcuNiAyMTAuMTUwMDEgMzQzLjM1XQo+PgplbmRvYmoKOTEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIyNy4xNzUgMzI2LjEzNzUgNDM3Ljg4NzUgMzQzLjM1XQo+PgplbmRvYmoKOTIgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQ1NC45MTI1IDI5Ny42IDY0MC40NjI1IDM0My4zNV0KPj4KZW5kb2JqCjkzIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs2NTcuNDg3NSAyOTcuNiA4MDUuMDEyNSAzNDMuMzVdCj4+CmVuZG9iago5NCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMjkxLjkzNzUzIDgxMy41MjUgMzIwLjQ3NTA0XQo+PgplbmRvYmoKOTUgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIyNy4xNzUgMjk3LjYgMjc1LjI4NzUgMzE0LjgxMjVdCj4+CmVuZG9iago5NiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjkyLjMxMjUgMjk3LjYgMzMwLjExMjUgMzE0LjgxMjVdCj4+CmVuZG9iago5NyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzQ3LjEzNzUgMjk3LjYgMzg0LjAgMzE0LjgxMjVdCj4+CmVuZG9iago5OCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbNDAxLjAyNTAyIDI5Ny42IDQzNy44ODc1IDMxNC44MTI1XQo+PgplbmRvYmoKOTkgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDI1Mi4wNzUwMSA4MTMuNTI1IDI5MS45Mzc1XQo+PgplbmRvYmoKMTAwIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAyNjMuNDAwMDIgODEzLjUyNSAyOTEuOTM3NTNdCj4+CmVuZG9iagoxMDEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgMjY5LjA2MjUzIDIwOS43NzUwMSAyODYuMjc1MDJdCj4+CmVuZG9iagoxMDIgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIyNy41NSAyNjkuMDYyNTMgNDM3LjUxMjUgMjg2LjI3NTAyXQo+PgplbmRvYmoKMTAzIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0NTUuMjg3NSAyNjkuMDYyNTMgNjQwLjA4NzUgMjg2LjI3NTAyXQo+PgplbmRvYmoKMTA0IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs2NTcuODYyNSAyNjkuMDYyNTMgODA0LjYzNzUgMjg2LjI3NTAyXQo+PgplbmRvYmoKMTA1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAyNTIuMDc1MDEgODEzLjUyNSAyNjMuNDAwMDJdCj4+CmVuZG9iagoxMDYgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgMjU3LjczNzUyIDgwNC42Mzc1IDI1Ny43Mzc1Ml0KPj4KZW5kb2JqCjEwNyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMjEyLjc3NTAyIDgxMy41MjUgMjM4LjU3NTAzXQo+PgplbmRvYmoKMTA4IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAxMTMuNjYyNTA2IDgxMy41MjUgMTk5LjI3NTAxXQo+PgplbmRvYmoKMTA5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAxNDIuMjAwMDEgODEzLjUyNSAxOTkuMjc1MDFdCj4+CmVuZG9iagoxMTAgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDE3MC43Mzc1MiA4MTMuNTI1IDE5OS4yNzUwMl0KPj4KZW5kb2JqCjExMSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAxNDcuODYyNTIgMjIyLjAzNzUgMTkzLjYxMjUyXQo+PgplbmRvYmoKMTEyIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMzkuMDYyNSAxNzYuNDAwMDIgNDc4LjYxMjUgMTkzLjYxMjUyXQo+PgplbmRvYmoKMTEzIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0OTUuNjM3NSAxNDcuODYyNTIgNjE5LjU3NSAxOTMuNjEyNTJdCj4+CmVuZG9iagoxMTQgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzYzNi42MDAwNCAxNDcuODYyNTIgODA1LjAxMjYgMTkzLjYxMjUyXQo+PgplbmRvYmoKMTE1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyOC4zNSAxNDIuMjAwMDEgODEzLjUyNSAxNzAuNzM3NTJdCj4+CmVuZG9iagoxMTYgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIzOS4wNjI1IDE0Ny44NjI1MiAyOTUuNDI1IDE2NS4wNzUwMV0KPj4KZW5kb2JqCjExNyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzEyLjQ1IDE0Ny44NjI1MiAzNTcuMTg3NSAxNjUuMDc1MDFdCj4+CmVuZG9iagoxMTggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM3NC4yMTI1IDE0Ny44NjI1MiA0MTcuOSAxNjUuMDc1MDFdCj4+CmVuZG9iagoxMTkgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQzNC45MjUwMiAxNDcuODYyNTIgNDc4LjYxMjUyIDE2NS4wNzUwMV0KPj4KZW5kb2JqCjEyMCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMTEzLjY2MjUwNiA4MTMuNTI1IDE0Mi4yMDAwMV0KPj4KZW5kb2JqCjEyMSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMTEzLjY2MjUwNiA4MTMuNTI1IDE0Mi4yMDAwMV0KPj4KZW5kb2JqCjEyMiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAxMTkuMzI1MDEgODA0LjYzNzUgMTM2LjUzNzVdCj4+CmVuZG9iagoxMjMgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI4LjM1IDUxNi40NSAyNTcuNzc1IDU1MC44Mzc1XQo+PgplbmRvYmoKMTI0IDAgb2JqCjw8Ci9NQ0lEIDAKPj4KZW5kb2JqCjEyNSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgNTE2LjQ1IDI1Ny43NzUgNTUwLjgzNzVdCj4+CmVuZG9iagoxMjYgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgNDU1LjQwMDAyIDk2LjkgNDgxLjJdCj4+CmVuZG9iagoxMjcgMCBvYmoKPDwKL01DSUQgMQo+PgplbmRvYmoKMTI4IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQ1NS40MDAwMiA5Ni45IDQ4MS4yXQo+PgplbmRvYmoKMTI5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQyNC42ODc1IDIyMS43MDAwMSA0NDEuOV0KPj4KZW5kb2JqCjEzMCAwIG9iago8PAovTUNJRCAyCj4+CmVuZG9iagoxMzEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgNDI0LjY4NzUgMjIxLjcwMDAxIDQ0MS45XQo+PgplbmRvYmoKMTMyIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMjEuNzAwMDEgNDI0LjY4NzUgMjIxLjcwMDAxIDQ0MS45XQo+PgplbmRvYmoKMTMzIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMjEuNzAwMDEgNDI0LjY4NzUgMjIxLjcwMDAxIDQ0MS45XQo+PgplbmRvYmoKMTM0IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMjEuNzAwMDEgNDI0LjY4NzUgMjIxLjcwMDAxIDQ0MS45XQo+PgplbmRvYmoKMTM1IDAgb2JqCjw8Ci9NQ0lEIDMKPj4KZW5kb2JqCjEzNiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjIxLjcwMDAxIDQyNC42ODc1IDIyMS43MDAwMSA0NDEuOV0KPj4KZW5kb2JqCjEzNyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSA0MDcuNDc1MDQgOTYuOTM3NSA0MjQuNjg3NTNdCj4+CmVuZG9iagoxMzggMCBvYmoKPDwKL01DSUQgNAo+PgplbmRvYmoKMTM5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQwNy40NzUwNCA5Ni45Mzc1IDQyNC42ODc1M10KPj4KZW5kb2JqCjE0MCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSA0MDcuNDc1MDQgMzYuODYyNSA0MjQuNjg3NTNdCj4+CmVuZG9iagoxNDEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgNDA3LjQ3NTA0IDM2Ljg2MjUgNDI0LjY4NzUzXQo+PgplbmRvYmoKMTQyIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQwNy40NzUwNCAzNi44NjI1IDQyNC42ODc1M10KPj4KZW5kb2JqCjE0MyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSA0MDcuNDc1MDQgMzYuODYyNSA0MjQuNjg3NTNdCj4+CmVuZG9iagoxNDQgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgNDA3LjQ3NTA0IDM2Ljg2MjUgNDI0LjY4NzUzXQo+PgplbmRvYmoKMTQ1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDQwNy40NzUwNCAzNi44NjI1IDQyNC42ODc1M10KPj4KZW5kb2JqCjE0NiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbNDI1LjkyNTAyIDQ0Ni44MTI1IDYxMC45ODc1NSA0NzIuNjEyNV0KPj4KZW5kb2JqCjE0NyAwIG9iago8PAovTUNJRCA1Cj4+CmVuZG9iagoxNDggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQyNS45MjUwMiA0NDYuODEyNSA2MTAuOTg3NTUgNDcyLjYxMjVdCj4+CmVuZG9iagoxNDkgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQyNS45MjUwMiA0MTYuMTAwMDQgNDYwLjYxMjUyIDQzMy4zMTI1M10KPj4KZW5kb2JqCjE1MCAwIG9iago8PAovTUNJRCA2Cj4+CmVuZG9iagoxNTEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQyNS45MjUwMiA0MTYuMTAwMDQgNDYwLjYxMjUyIDQzMy4zMTI1M10KPj4KZW5kb2JqCjE1MiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMzYyLjUxMjUgMTgyLjQzNzUyIDM4OC4zMTI1XQo+PgplbmRvYmoKMTUzIDAgb2JqCjw8Ci9NQ0lEIDcKPj4KZW5kb2JqCjE1NCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMzYyLjUxMjUgMTgyLjQzNzUyIDM4OC4zMTI1XQo+PgplbmRvYmoKMTU1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDMxMS44ODc1IDE0Ny42IDMyOS4xXQo+PgplbmRvYmoKMTU2IDAgb2JqCjw8Ci9NQ0lEIDgKPj4KZW5kb2JqCjE1NyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAzMTEuODg3NSAxNDcuNiAzMjkuMV0KPj4KZW5kb2JqCjE1OCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjI3LjE3NSAzMjYuMTM3NSAyNjguNTM3NSAzNDMuMzVdCj4+CmVuZG9iagoxNTkgMCBvYmoKPDwKL01DSUQgOQo+PgplbmRvYmoKMTYwIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMjcuMTc1IDMyNi4xMzc1IDI2OC41Mzc1IDM0My4zNV0KPj4KZW5kb2JqCjE2MSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbNDU0LjkxMjUgMzExLjg4NzUgNTI2Ljk1IDMyOS4xXQo+PgplbmRvYmoKMTYyIDAgb2JqCjw8Ci9NQ0lEIDEwCj4+CmVuZG9iagoxNjMgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQ1NC45MTI1IDMxMS44ODc1IDUyNi45NSAzMjkuMV0KPj4KZW5kb2JqCjE2NCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbNjU3LjQ4NzUgMzExLjg4NzUgNzU3LjU3NSAzMjkuMV0KPj4KZW5kb2JqCjE2NSAwIG9iago8PAovTUNJRCAxMQo+PgplbmRvYmoKMTY2IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs2NTcuNDg3NSAzMTEuODg3NSA3NTcuNTc1IDMyOS4xXQo+PgplbmRvYmoKMTY3IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMjcuMTc1IDI5Ny42IDI1Ni41Mzc1IDMxNC44MTI1XQo+PgplbmRvYmoKMTY4IDAgb2JqCjw8Ci9NQ0lEIDEyCj4+CmVuZG9iagoxNjkgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIyNy4xNzUgMjk3LjYgMjU2LjUzNzUgMzE0LjgxMjVdCj4+CmVuZG9iagoxNzAgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzI5Mi4zMTI1IDI5Ny42IDMxNC4zMjUgMzE0LjgxMjVdCj4+CmVuZG9iagoxNzEgMCBvYmoKPDwKL01DSUQgMTMKPj4KZW5kb2JqCjE3MiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjkyLjMxMjUgMjk3LjYgMzE0LjMyNSAzMTQuODEyNV0KPj4KZW5kb2JqCjE3MyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzQ3LjEzNzUgMjk3LjYgMzY4LjQ3NSAzMTQuODEyNV0KPj4KZW5kb2JqCjE3NCAwIG9iago8PAovTUNJRCAxNAo+PgplbmRvYmoKMTc1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNDcuMTM3NSAyOTcuNiAzNjguNDc1IDMxNC44MTI1XQo+PgplbmRvYmoKMTc2IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0MDEuMDI1MDIgMjk3LjYgNDIyLjM2MjUyIDMxNC44MTI1XQo+PgplbmRvYmoKMTc3IDAgb2JqCjw8Ci9NQ0lEIDE1Cj4+CmVuZG9iagoxNzggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQwMS4wMjUwMiAyOTcuNiA0MjIuMzYyNTIgMzE0LjgxMjVdCj4+CmVuZG9iagoxNzkgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgMjY5LjA2MjUzIDE1NC45MTI1IDI4Ni4yNzUwMl0KPj4KZW5kb2JqCjE4MCAwIG9iago8PAovTUNJRCAxNgo+PgplbmRvYmoKMTgxIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDI2OS4wNjI1MyAxNTQuOTEyNSAyODYuMjc1MDJdCj4+CmVuZG9iagoxODIgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQ1NS4yODc1IDI2OS4wNjI1MyA1ODEuNjYyNSAyODYuMjc1MDJdCj4+CmVuZG9iagoxODMgMCBvYmoKPDwKL01DSUQgMTcKPj4KZW5kb2JqCjE4NCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbNDU1LjI4NzUgMjY5LjA2MjUzIDU4MS42NjI1IDI4Ni4yNzUwMl0KPj4KZW5kb2JqCjE4NSAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMjEyLjc3NTAyIDIyNS40ODc1MiAyMzguNTc1MDNdCj4+CmVuZG9iagoxODYgMCBvYmoKPDwKL01DSUQgMTgKPj4KZW5kb2JqCjE4NyAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMjguMzUgMjEyLjc3NTAyIDIyNS40ODc1MiAyMzguNTc1MDNdCj4+CmVuZG9iagoxODggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM2Ljg2MjUgMTYyLjE1MDAyIDE0Ny42IDE3OS4zNjI1Ml0KPj4KZW5kb2JqCjE4OSAwIG9iago8PAovTUNJRCAxOQo+PgplbmRvYmoKMTkwIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszNi44NjI1IDE2Mi4xNTAwMiAxNDcuNiAxNzkuMzYyNTJdCj4+CmVuZG9iagoxOTEgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIzOS4wNjI1IDE3Ni40MDAwMiAyODAuNDI1IDE5My42MTI1Ml0KPj4KZW5kb2JqCjE5MiAwIG9iago8PAovTUNJRCAyMAo+PgplbmRvYmoKMTkzIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMzkuMDYyNSAxNzYuNDAwMDIgMjgwLjQyNSAxOTMuNjEyNTJdCj4+CmVuZG9iagoxOTQgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzQ5NS42Mzc1IDE2Mi4xNTAwMiA1NjcuNjc1IDE3OS4zNjI1Ml0KPj4KZW5kb2JqCjE5NSAwIG9iago8PAovTUNJRCAyMQo+PgplbmRvYmoKMTk2IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0OTUuNjM3NSAxNjIuMTUwMDIgNTY3LjY3NSAxNzkuMzYyNTJdCj4+CmVuZG9iagoxOTcgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzYzNi42MDAwNCAxNjIuMTUwMDIgNzM2LjY4NzU2IDE3OS4zNjI1Ml0KPj4KZW5kb2JqCjE5OCAwIG9iago8PAovTUNJRCAyMgo+PgplbmRvYmoKMTk5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs2MzYuNjAwMDQgMTYyLjE1MDAyIDczNi42ODc1NiAxNzkuMzYyNTJdCj4+CmVuZG9iagoyMDAgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzIzOS4wNjI1IDE0Ny44NjI1MiAyNjguNDI1IDE2NS4wNzUwMV0KPj4KZW5kb2JqCjIwMSAwIG9iago8PAovTUNJRCAyMwo+PgplbmRvYmoKMjAyIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFsyMzkuMDYyNSAxNDcuODYyNTIgMjY4LjQyNSAxNjUuMDc1MDFdCj4+CmVuZG9iagoyMDMgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzMxMi40NSAxNDcuODYyNTIgMzM0LjQ2MjUyIDE2NS4wNzUwMV0KPj4KZW5kb2JqCjIwNCAwIG9iago8PAovTUNJRCAyNAo+PgplbmRvYmoKMjA1IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFszMTIuNDUgMTQ3Ljg2MjUyIDMzNC40NjI1MiAxNjUuMDc1MDFdCj4+CmVuZG9iagoyMDYgMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM3NC4yMTI1IDE0Ny44NjI1MiAzOTUuNTUgMTY1LjA3NTAxXQo+PgplbmRvYmoKMjA3IDAgb2JqCjw8Ci9NQ0lEIDI1Cj4+CmVuZG9iagoyMDggMCBvYmoKPDwKL1R5cGUgL0JhY2tncm91bmQKL0JCb3ggWzM3NC4yMTI1IDE0Ny44NjI1MiAzOTUuNTUgMTY1LjA3NTAxXQo+PgplbmRvYmoKMjA5IDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0MzQuOTI1MDIgMTQ3Ljg2MjUyIDQ1Ni4yNjI1IDE2NS4wNzUwMV0KPj4KZW5kb2JqCjIxMCAwIG9iago8PAovTUNJRCAyNgo+PgplbmRvYmoKMjExIDAgb2JqCjw8Ci9UeXBlIC9CYWNrZ3JvdW5kCi9CQm94IFs0MzQuOTI1MDIgMTQ3Ljg2MjUyIDQ1Ni4yNjI1IDE2NS4wNzUwMV0KPj4KZW5kb2JqCjIxMiAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAxMTkuMzI1MDEgMTI3LjYxMjUgMTM2LjUzNzVdCj4+CmVuZG9iagoyMTMgMCBvYmoKPDwKL01DSUQgMjcKPj4KZW5kb2JqCjIxNCAwIG9iago8PAovVHlwZSAvQmFja2dyb3VuZAovQkJveCBbMzYuODYyNSAxMTkuMzI1MDEgMTI3LjYxMjUgMTM2LjUzNzVdCj4+CmVuZG9iagoyMTUgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL0Jhc2VGb250IC9BQUFLT0UrQXJpbW8tSXRhbGljCi9TdWJ0eXBlIC9UeXBlMAovRW5jb2RpbmcgL0lkZW50aXR5LUgKL0Rlc2NlbmRhbnRGb250cyBbMjIzIDAgUl0KL1RvVW5pY29kZSAyMjQgMCBSCj4+CmVuZG9iagoyMTYgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL0Jhc2VGb250IC9BQUFFSEgrQXJpbW8tUmVndWxhcgovU3VidHlwZSAvVHlwZTAKL0VuY29kaW5nIC9JZGVudGl0eS1ICi9EZXNjZW5kYW50Rm9udHMgWzIyNSAwIFJdCi9Ub1VuaWNvZGUgMjI2IDAgUgo+PgplbmRvYmoKMjE3IDAgb2JqCjw8Ci9UeXBlIC9Gb250Ci9CYXNlRm9udCAvQUFBTU9EK0FyaW1vLUJvbGQKL1N1YnR5cGUgL1R5cGUwCi9FbmNvZGluZyAvSWRlbnRpdHktSAovRGVzY2VuZGFudEZvbnRzIFsyMjcgMCBSXQovVG9Vbmljb2RlIDIyOCAwIFIKPj4KZW5kb2JqCjIxOCAwIG9iago8PAovZ3MxIDIyOSAwIFIKPj4KZW5kb2JqCjIxOSAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDggMCBSCi9QZyA5IDAgUgovSyBbNTEgMCBSIDU1IDAgUl0KPj4KZW5kb2JqCjIyMCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDkgMCBSCi9QZyA5IDAgUgovSyAyMzAgMCBSCj4+CmVuZG9iagoyMjEgMCBvYmoKPDwKL1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDYyIDAgUgovUGcgOSAwIFIKL0EgMjMxIDAgUgo+PgplbmRvYmoKMjIyIDAgb2JqCjw8Ci9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MiAwIFIKL1BnIDkgMCBSCj4+CmVuZG9iagoyMjMgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL0NJREZvbnRUeXBlMgovQmFzZUZvbnQgL0FBQUtPRStBcmltby1JdGFsaWMKL0NJRFN5c3RlbUluZm8gMjMyIDAgUgovRm9udERlc2NyaXB0b3IgMjMzIDAgUgovVyBbMCBbNzUwIDI3OCA2NjcgNjY3IDcyMl0KIDggWzc3OF0KIDEzIFs1NTYgODMzXQogMTggWzc3OCA3MjJdCiAyOCBbNTU2XQozMCBbNTAwIDU1NiA1NTZdCiAzNSBbNTU2IDIyMl0KIDM5IFsyMjIgODMzIDU1NiA1NTYgNTU2XQogNDUgWzMzMyA1MDAgMjc4IDU1NiA1MDBdCiA1MyBbNTAwIDU1NiA1NTYgNTU2IDU1NiA1NTZdCjYxIFs1NTYgNTU2XQogMTAwIFsyNzhdCiAxMDYgWzMzM10KIDE0MCBbMjc4XQogMzM0IFs1NTZdCjQ0NiBbMzMzXQpdCi9DSURUb0dJRE1hcCAyMzQgMCBSCj4+CmVuZG9iagoyMjQgMCBvYmoKPDwKL0xlbmd0aCAzNDYKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nF2SXWuDMBSG7/MrcrldFE206kCE1rbgxT5Ytx9g9ViEGSXaC//94nltBxPkxcc8OQnneHlxKEw7Se/D9tWZJtm0prY09jdbkbzQtTVCaVm31bR+CY6qKwfhOfs8jxN1hWl6kabS+3Q/x8nO8mlX9xd6Ft67rcm25iqfvvOz+z7fhuGHOjKT9EWWyZoa4XZ6LYe3siPpsbcparegneaNk3gJr/iaB5IaisJ5qr6mcSgrsqW5kkh992QyPbknE2Tqf/+FSuBdmj9BOeER2s8YasCQI1SACSAijAEPgEfAnKGCrgKOLXSVAyKiFR7vZRkGDDU8jepRAhgD7gFRSKN6gMPHmmGwBUTEO8AIcIfANYNVxyEC3Chay4Z3gSG8NVzZBSa4yhr6tEAV8mZr+McXhntAhL8PuTn3JnCjlol6jEF1s9ZNAM8dt35pemvoMZpDPywWv78/YrhkDQplbmRzdHJlYW0KZW5kb2JqCjIyNSAwIG9iago8PAovVHlwZSAvRm9udAovU3VidHlwZSAvQ0lERm9udFR5cGUyCi9CYXNlRm9udCAvQUFBRUhIK0FyaW1vLVJlZ3VsYXIKL0NJRFN5c3RlbUluZm8gMjM1IDAgUgovRm9udERlc2NyaXB0b3IgMjM2IDAgUgovVyBbMCBbNzUwXQogMyBbMjc4XQogMTAgWzE5MV0KIDE2IFszMzMgMjc4IDI3OCA1NTYgNTU2IDU1Nl0KIDI0IFs1NTZdCjM2IFs2NjcgNjY3IDcyMiA3MjIgNjY3XQogNDMgWzcyMiAyNzhdCiA0NyBbNTU2IDgzMyA3MjIgNzc4IDY2NyA3NzggNzIyIDY2NyA2MTEgNzIyCjY2N10KIDYxIFs2MTFdCiA2OCBbNTU2IDU1NiA1MDAgNTU2IDU1Nl0KNzQgWzU1Nl0KIDc2IFsyMjJdCiA3OSBbMjIyIDgzMyA1NTYgNTU2IDU1Nl0KIDg1IFszMzMgNTAwIDI3OCA1NTYgNTAwXQogMTEyIFs1NTZdCjE0MSBbMzMzXQogMTcxIFs2NjddCiA2NjAgWzI5NF0KXQovQ0lEVG9HSURNYXAgMjM3IDAgUgo+PgplbmRvYmoKMjI2IDAgb2JqCjw8Ci9MZW5ndGggMzM3Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkstugzAQRff+Ci/bRcQjQBIJIRHSSCz6UGk/gOAhQirGMmTB39fMJalUS9aVj+faMx57RXkqdTdJ78MOTUWTbDutLI3DzTYkL3TttAhCqbpmWleCpelrIzznruZxor7U7SDSVHqfbnOc7CyfcjVc6Fl471aR7fRVPn0XlVtXN2N+qCc9SV9kmVTUCnfSa23e6p6kx75NqVxAN80bZ+IQjviaDckQlgD5NIOi0dQN2VpfSaS+G5lMz25kgrT6ty+CBL5L+2fYOsNDQj9jmANCwh3DwOdVEAOeAPeAkG3MMIwQAhgFgEfAAnAPeIbvAFgw3J4AIXHOMIruvkUSnBkhwVUS5BkV98MYHgBxUYwyE1wUo5QYt+9ChjuUucoL7HvkssoxYpijolUKn5/8/rT8/Ms/eTS3uVnr+sq/iRu6tLLT9PhwZjCLi+cv6+6wNw0KZW5kc3RyZWFtCmVuZG9iagoyMjcgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL0NJREZvbnRUeXBlMgovQmFzZUZvbnQgL0FBQU1PRCtBcmltby1Cb2xkCi9DSURTeXN0ZW1JbmZvIDIzOCAwIFIKL0ZvbnREZXNjcmlwdG9yIDIzOSAwIFIKL1cgWzAgWzc1MF0KIDMgWzI3OF0KIDM4IFs3MjIgNzIyXQogNTEgWzY2N10KIDU1IFs2MTFdCjY3IFszMzMgNTU2XQogNzAgWzU1NiA2MTEgNTU2IDMzM10KIDc2IFsyNzhdCiA4MCBbODg5IDYxMSA2MTFdCiA4NSBbMzg5IDU1NiAzMzNdCjg5IFs1NTZdCiAxMTIgWzU1NiA1NTZdCiAxNDEgWzMzM10KXQovQ0lEVG9HSURNYXAgMjQwIDAgUgo+PgplbmRvYmoKMjI4IDAgb2JqCjw8Ci9MZW5ndGggMzE2Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJxdkt1qhDAQhe/zFLncXiz+Rd0FEdrdLXjRH2r7AJqMS6DGELMXvn3jjN1CA3KYL+dMJJPo1Jwboz2P3t0kW/B80EY5mKebk8B7uGrDkpQrLf1WMRQ5dpZFId0us4exMcPEqopHH2Fz9m7hu0c19fDAojenwGlz5buvUxvq9mbtN4xgPI9ZXXMFAwudXjr72o3AI8ztGxUM2i/7EEILOj4XCzylSEL/IycFs+0kuM5cgVVxWDWvnsOqGRj1b58lGeX64S+QhcBd0rheYVpQVaKIDGFGlk1ycmZk2SQXCAVZhEApyCmopzgSpJ7iRJCkOCLMY2qWEjwTzAnSQWVKkJptUhYIS4pvcqGeZUKQ5HJAeDhjtcmTwDv7vRu8v3XQ9+nIm3NhMPgccCLrLLSB+4uxk11T+P0AjHujMA0KZW5kc3RyZWFtCmVuZG9iagoyMjkgMCBvYmoKPDwKL1R5cGUgL0V4dEdTdGF0ZQovQk0gL0NvbXBhdGlibGUKPj4KZW5kb2JqCjIzMCAwIG9iago8PAovVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMjIwIDAgUgovUGcgOSAwIFIKL0EgMjQxIDAgUgo+PgplbmRvYmoKMjMxIDAgb2JqCjw8Ci9PIC9UYWJsZQovQ29sU3BhbiA0Cj4+CmVuZG9iagoyMzIgMCBvYmoKPDwKL1JlZ2lzdHJ5IChBZG9iZSkKL09yZGVyaW5nIChJZGVudGl0eSkKL1N1cHBsZW1lbnQgMAo+PgplbmRvYmoKMjMzIDAgb2JqCjw8Ci9UeXBlIC9Gb250RGVzY3JpcHRvcgovRm9udE5hbWUgL0FBQUtPRStBcmltby1JdGFsaWMKL0ZsYWdzIDY4Ci9Gb250V2VpZ2h0IDQwMC4wCi9JdGFsaWNBbmdsZSAtMTIuMAovRm9udEJCb3ggWy02NjQuMDYyNSAtMzg5LjE2MDE2IDI3OTYuODc1IDEwNDIuOTY4OF0KL0FzY2VudCA5MDUuMjczNDQKL0Rlc2NlbnQgLTIxMS45MTQwNgovQ2FwSGVpZ2h0IDY4Ny45ODgzCi9YSGVpZ2h0IDUyOC4zMjAzCi9TdGVtViA0NDkuOTIxODQKL0ZvbnRGaWxlMiAyNDIgMCBSCi9DSURTZXQgMjQzIDAgUgo+PgplbmRvYmoKMjM0IDAgb2JqCjw8Ci9MZW5ndGggMTA3Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJztjskOgkAQBYtFEZRNNkUWZfv/T2QyDonRG0u8UEmn3zt0pQENHQOTNwcmjlgqnbD5xhFz5oIrm4cvd0DIlYhY5ISUjBt3dZHzoKCkopb9yevHOp/mI7cr+LoVHDvL6P/9wMYMIxDTAuYNCmVuZHN0cmVhbQplbmRvYmoKMjM1IDAgb2JqCjw8Ci9SZWdpc3RyeSAoQWRvYmUpCi9PcmRlcmluZyAoSWRlbnRpdHkpCi9TdXBwbGVtZW50IDAKPj4KZW5kb2JqCjIzNiAwIG9iago8PAovVHlwZSAvRm9udERlc2NyaXB0b3IKL0ZvbnROYW1lIC9BQUFFSEgrQXJpbW8tUmVndWxhcgovRmxhZ3MgNAovRm9udFdlaWdodCA0MDAuMAovSXRhbGljQW5nbGUgMC4wCi9Gb250QkJveCBbLTU0My45NDUzIC0zODkuMTYwMTYgMjc5Ni44NzUgMTA0Mi45Njg4XQovQXNjZW50IDkwNS4yNzM0NAovRGVzY2VudCAtMjExLjkxNDA2Ci9DYXBIZWlnaHQgNjg3Ljk4ODMKL1hIZWlnaHQgNTI4LjMyMDMKL1N0ZW1WIDQzNC4zMDY2Ci9Gb250RmlsZTIgMjQ0IDAgUgovQ0lEU2V0IDI0NSAwIFIKPj4KZW5kb2JqCjIzNyAwIG9iago8PAovTGVuZ3RoIDEyOQovRmlsdGVyIC9GbGF0ZURlY29kZQo+PgpzdHJlYW0NCnic7c7JDoIwFIXhX3EA5wEcUEQFBQGn9385mxsWNcGFumHRL2l6btOTXBANdE0tW7Ro06GLLbNDtR59BgwZyTRmIveUGXNcPBYsWbHGZ1M2tm/9gB0hew4qH9WJ5DXmxJmEVOULGTkF1w8bVLt99Vt3/7kJjz+6hmHUzfMFA0IEyg0KZW5kc3RyZWFtCmVuZG9iagoyMzggMCBvYmoKPDwKL1JlZ2lzdHJ5IChBZG9iZSkKL09yZGVyaW5nIChJZGVudGl0eSkKL1N1cHBsZW1lbnQgMAo+PgplbmRvYmoKMjM5IDAgb2JqCjw8Ci9UeXBlIC9Gb250RGVzY3JpcHRvcgovRm9udE5hbWUgL0FBQU1PRCtBcmltby1Cb2xkCi9GbGFncyA0Ci9Gb250V2VpZ2h0IDcwMC4wCi9JdGFsaWNBbmdsZSAwLjAKL0ZvbnRCQm94IFstNTQzLjk0NTMgLTM4OS4xNjAxNiAyNzk2Ljg3NSAxMDQyLjk2ODhdCi9Bc2NlbnQgOTA1LjI3MzQ0Ci9EZXNjZW50IC0yMTEuOTE0MDYKL0NhcEhlaWdodCA2ODcuOTg4MwovWEhlaWdodCA1MjguMzIwMwovU3RlbVYgNDM0LjMwNjYKL0ZvbnRGaWxlMiAyNDYgMCBSCi9DSURTZXQgMjQ3IDAgUgo+PgplbmRvYmoKMjQwIDAgb2JqCjw8Ci9MZW5ndGggNjcKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nGNgAANGBmoAJgZmHDIsUJoVhzwbAzuQ5GDgZOBi4AaL8EBleBn4GPjBLAEGQQYhIC1MkptEGERJUo8AYgBp6QD+DQplbmRzdHJlYW0KZW5kb2JqCjI0MSAwIG9iago8PAovTyAvVGFibGUKL0NvbFNwYW4gNwo+PgplbmRvYmoKMjQyIDAgb2JqCjw8Ci9MZW5ndGggMzI3MgovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoMSA0MTM2Cj4+CnN0cmVhbQ0KeJxtVwlYU8cWnrkrICAYSNglCSSAKEhIUrWAWFER1LohLqBBw6KoadGyb1VQWexTtlKwIlqtqEUQxH2pC2hVrEtbW7/aRau29LO12mcxubxzb2J5r99Lcr7MzJ17lv8scwZhhJAVKkIkQim6DAPMHIAq+NWU9OzkOQdnPIBxNUJ2t1L1umW+W7MPI2SfCmuaVFhwTRPpYd4Ec5/UlWuydrtYVcH8PMwb01cv1SEsXYbQ0CUwb1qpyzKgUnzBLAJ5G97WG1KZihKYe8OcRRjhgQE0FBHoKkJ0CF0MWrEIRTpKHUVSRykd8rIhlrxqVNHF/YVAn1GPESIGGhCiHsFelmcbScqxCstJkmFYLCUVCrzwt+vkm3ewz7mYRnaYLVdLDE1mbXEjt4znghvJuXYysamE8FfEgrQIkOsAvOyQGA0Hbk6UVIqlIWJnB1os9pWGaNShCrmUfDWg7nE93C+mA9gRc5//zh0oe994Ase0t5WWcp1fYsONc9truK246/YPdPGBGu7HcZKdpuLixMSXbVWbVwDUGL010EffoGsFWRKGksuUCkIdqtX4qEIoCatQyGUsQzg7iVUhPtTp9wq4M7c6S0oq0tLw2p/u4BHBHT69dUfLK2q/PlsN2LXMP7E3egq2Pfhnd/edzl1aw/r4eO7UjZ6H4BGQpQdZ34MsKUJR3sjx/0rRaLVSrZRkKOInrpc7CIKKX3yLPbRnfT+tOb1lywd9X5YZE1TcQm9i7rIK7pwTfg279p+/8MXHuzQZGXFx3LnrNx/OmMY1cY5Zq3iZgCd5H/CkEdKzUqwiyftexmzsePqPxka6+KW7ZQ/TAnuGW7wnEoslGo0WS7FcBP/2BAv+VCiUDIPbelqwY99JysHWLdSN8MeIe7K/Y5jU3ksdOMx0N+8o6exIDaUcXz6hi41BopTZ6hVq8lJ/Idm0qHZsROqs4cZYssO+Mt8rAeIG6bl8+k/AwwsFg+QQapgzw/JfMeCgZRm5TKEEqQoBKImMtTcjpA0HBynIpqPYdgu1YMbGPfcdly0NCx8Wk1jXLCnsjtq8PA3nPOiuSCh64/ZnF8oXvRt1h67dzBnbfj/+Ufp6r+zVdqXi/Ret42M/wOxvPT13Ppg/7vLT7M+/mTf23LOi3m9BLz4GNwIeQ5GLGRFpiEQsdnZieBy0r0IQr37rNHYkltWv1q346ia2vfbH6M4jNdXcXD0RbeqiizWjdq44cdfTtJuIrqvbZMgyveBtHjXQR42kpqORKAyiQKZQh2q0coa3VR3q46sVeMsYVqnRqCDonViSMRvNAvjCABzCT+BHbk+YS2FmdntBRSu2xrJHouWJmTnu7SPvndjXLZo6xN/Pc7i9dLwpSDdNN316soN7d+YGhW+gzbRYB2+HAv3H7x49RZGLvRfOmzvPs6qkacOEhVxpiMLXhzVYWWG/mMQA/9Jp+RTp4+kRj4T4fWOgj3wMuntALEGgSggpr7VWUNUcxbxazg74dsq/AhpzuKNnrkVPefLJ3gs2bUz6wqodfjY2ORkZo7mTX1+4tG//zpZqV11a1+nR+mDuOeKxiRr4hdpLX0HugI4ZGwtvFRgtUvEVRR7Ko6W0BIHcEhR4y7bW8PBvD+Q2eNOsPTur47m9iN7vTEc3Tzijkwa5Fr6VMzlosjLR+eRHl8+c7kpN9J/ph3e+FE0y+KtWLo4r36mpaRyfXz4l+NjNuNw8iy59lBJsdeWzNZJhzbkpsXhKyFzePb5SreAwjBiypFT3YWBZ9PdNl+5NnoyJHVfvu5isiXiqOLu0C/9bNqNk85LZEeuy7l3ubt7edu1Eqr5sSt76fYCrDOqnM9gNuEZa/M6wJOSeOhRY80MsGI8LZ+/JqK6xGVLYWTDs0Jz39OJ3DmHvjhhrF3uyOGP+1jLvWSGmDKJkftieedtXmZrpK1xBiD5EsAeswM9Bhrmes3KtCATg57IOWfLNQzfoK/v3c6teXqTG8n4e3IsisRzj59w9kENf6Q+FRbO+TAw1jfeSTvQqYnl9tSonUFPF2yD5O4Dlg1uI6jzX2Lg1B9zfObTbSdRiY0eT0VXJLzxn70jdsMW5sF14ut/jHSInJzRmxsUm0y5y9uKNbNRMj7cXPHo3eWtZhB7sEx6eazLtsOhCiUEXc+3iy9WgDv/AEce+07HbRmQjyP0HkkSiqZmcHbRmIi/sn1Dy+EHsUyEgx0GIByeCNUeCxhyhrIP87/rEL1Ehb06N+ars/H06atKLrhvfHnuxYaZmmn9RTkp+UNA4Yt+73KMkXVLfZ70NHzZ/0429okbtOBlf3TApeuqPcJ5e5eZRoyH2ZEgj5IFSDnYwBCuY908L+UIA2P5dHEkAmwjgM4GiqNCgQ3/R1hRtRe1hrEgqujlzW2tY2HeKpZWjvYMhLfKm+Izxc050Sk2kpe7u3B9PacYl2MU7fPiwyHCHxXEnP7py8tRR8suZMzW1DZH55bGKgrq6MMgQAXfiCejIV0iFJUpfqcdaQoC4FhA8KW+B06qOZsaOAT1a3K2oCUVzAlVki53+E4PpChkuj5J5jvHYG1qSbi/UGBpqzBdUDBrBoywcAVo4DrzVoUoF/+Xr5WC1AZMlwldMlr/4+ZOr/lXS8rVYrgrdVRwxfuKjm23d4p3inJS8kgA/v81F4yMn47Dm1rUFr8W/eSo8wF81Qum3YvKWbYVFrjMmzZgSMEYiGenn728Q9EgY6COK6EDIf0slEsm1KjBNxcoHSzIWzdUNLch3K0zLCupx68m3HTlSGSZa6pQ8RxtDvLfu6dN1ptzX5YGB9iUuPM+4gV+pqZBi0GvpLYXEUticnSBuBmscDIk+IUJpa9YSosnOr6LXnjrKR6g4ZJyUqDTlxofvmde0kkg0HoDwtZo4y13QH6ygkkDWUCGHSZXIi5BIeO9gKslUf/vwcT0JLqPcJKNccBE1lk9903jxmAlKtTpoYSDxKfAYeMb3DsDDWugdoB/QSllMznY1HpMQP5kuu5IOLia38vJNpKJ8k/FrJNSZ+ZAnSXCmOyIlf6ZD38byXRUhmKrRkBChlKUc2JOAI3G3q3f6dO6HK53X/GLVb/48s26JIlLlI8pMj80NCp72mmcmXfvn3QH05Le/MPFj1l8PFmys7H+8PKB4W8uemIZGtVp9oPeLhIZG3mY16HsRzm0bs75SEa31hYbnopex0gunXOfq5Dh797P6+npq1L2OBy9dLDZSc0FfpfkdUDKc0Aqq/s9JzCeaPZ/0LNnpaVzkot04NUS/LHgypLMmf/nKZt8WzYvjOUdSVLLVh8qqOkfV1xcmbH3dL2q818gFKlV2bFJ2ZqZvy6H521PTksZnlc5LeH+K+UwNBrx0ID+QR2tQpo+lerFic4rzfamQCeY9ci2h6erM1mfuk7WPxUOOH//qbCtet/X1sAf1hUsvqXZ5Hcyt3F5bnOdFum+tSEjPWW1/rPNIU/1ZCeW2LTcvSZceuPBe8JrKmgJDbqPZb3aAg0LATmSupOBvFalizW08ZDY5Pbwj3JThTqq6j5zwuO4x1pPzwDdTrexwBHcWR1SQh42xm8lJsgky0zVCpogB224Bz3bgCUDr5DyyJN/bmpsX8w8fOuEUERCg23Sh0tjvSZ71MNSPGBErk4W5qWckf7poUev5Zzvqt647ptWuCA1NUy+H6wacShrALIWugdz0RaPNUfYKKsqcVVo1Xyl8RK8Q5QuFzJy2/Apx5vSjA1V41Vru/l+3Hx9uXbgMU+2lNesKS2o3eTbuq15f3VVP13Q1VJwXU9IPVl1/drm9tldJKepS2npMte+VJK0sLUzJLN9dayjcX7U6n8dvJjjzIeTK4PkKhB/6n/N3BaLG9vYaa3p7zT5Pw9eJPMIgnK8Qc0TecM52OGFoaoJ4rIC683jw7CUemybuIE7D2etNf4fgbib0JfR9RsF7DGQpcLLAs5VqIzbS9/k+H96DSkKs48oSSdMdupv72QkP5/cAzcl162iNWDz09eeItOK1QXde3JDw/98YrH7tP2j8UbzEKh7sYYAwMuuL2HBuOnpD3N5/sD9OvIR8hG6j//4oGYSuEmOga44baKDjUATdjd5ixiA9lYEimBYgGMNaBMxHUQi9Af9RFpLhbiTlCfbJ+DkQPB+4SvBzYAl8E2AtDsYGCg08g/F8IDXs4cfBQHZAt4A0sHcmvJdGjBmo4PnDuNWiY6CFsoAe8UAA9QD1gfPgfkwYIbCgzaWcgNYgHkZEpwNdB4JnDPRmzMeABNxwWegQraCGWwEvKI3IGnhZn0HIBlS0eQ2oAwhkDIE7+pDfELKdCARpZge3HLtFQPCe3ftAB/k7vYCyEs9Cc6BmMxbMX30oRBzBAyUHqUr0H1fxhI0NCmVuZHN0cmVhbQplbmRvYmoKMjQzIDAgb2JqCjw8Ci9MZW5ndGggMTMKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtDQp4nPv/nyzwDwA2VTfIDQplbmRzdHJlYW0KZW5kb2JqCjI0NCAwIG9iago8PAovTGVuZ3RoIDMzMzUKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aDEgNDQ1Mgo+PgpzdHJlYW0NCnicdVgJXFTVGj/n3GVQEBxmAWQdhkVNwRgGwgWFnvuSkIJiKhjqaCSTmLIkQgIiSi5PMRLJBQ0RN0LTUnEFVEys3B5lrq9flkpmqTBzeN+5d0yz32PuN/es3/r/zncGhBFCdigHcQjNTEozQ68r0HI2OjMlY0afyXnN0F6DkOMB0/Sk5ICCjAMIOY2CsTATDLgVOe2Efh70/Uzvzkv/z2X1DehXQr8xJfXtJISnNwFLxrfp3aR0M1qFaxFS9oe+j3nudLNJXJ4P/begr0AY4Y4O5IQIOoeQECLkglYKhKKUOqVKp9QJIe3rR3HnLAYht20R0Fn+ZwR7TFw99pHWoihOz2EfbbFGyKWD8VfAFOYn4WbyBjFL8xqdkbxBHYh540ZpDpbgbNTC5qZr9EacfaKlpQXGUcevJEJokvZgPSYRdNZmvF5oavMRriPQb2zHr7xeKEH2qBus6Er0vkTZ1VkX4syFBgTofUVRo3bWGkKcef3T339/dA+jp/e+GFCQMqdoYFTh7E/XkGP0U7ocz8Vv43fwbLqaljZ1pM/v+LqxA2ViD5BfhhDvBDZ1ZnrpjDqlYPQ3KHknSzGeSY/j0dtKS0v5/req7rS7SnbMhPUOoI9eXh9JwsPC4DGGMmUUgWFhhhCtRi0qROnhHSyTDKsqxnYf6jPojcKMtLVdDqgfH794Z+QI/49MaYVepaWL3q9dGekNn8K4eTkL31Nubzx9MHZzTPfs8VPWDQF5sWC/J+jnBdarkd43IDBcC/Y+E6hX6TQ6jgnV8p708S+nHvrs91w9f1XF1uXDswfuCeZ01sXu7+9a1mTGZ3/sQNVbNKZZu0vzK4LCyZ+lNCohtR58zAMGYkGGgiESIosNGKIL6nM6LiAAp2yuJwOvkrATm2idMlj9OXHa5xiEy2gyQwcu48a/tjSUGvEFPcM24JG/C7wckQvyZjrzegCU7BOtFoPWrBumCtVJb/4uvf/IepKgJ0+W51Tup/fL1tA6HFW6LoZupmU4bfdGXHzogpC7Y8fCKk/1Qdw2dxqNTrN2PKX8h1I8TB2/ChkQD3eIh4/KReT1vn7EGOrsZwjhXRQMIkgJCOF8cPe1ZfH0VPMl2rS1AodeuoGDhu579erau9SSdWMp9h+z/0gNHn79Bo6u3rOzf9aH9FvaVk2tK8A/YJMwHWzqhFTMIiKZ5IO4rkg2IkyYvpOebbL+hr/BM3D+UXqDttLfcN8NP+WQ8z/SI7sgSUrpPixiVfveIirpzfxEgae9hCOlzkY8ba/ie1tWcyGWr8vKhNwy2v8TqpHXCz7y+iilXmmATDXAG8+sqyNtQMXWNCHXWk3GtS0ixbD+MAj5wJarbN0HdXIuP5MdDE1Blg1wD7Zk1DFx7e62eZHAvKdNFtZqXQDomAkMDQsHYECmchDN2Kp2vEDtL4oeHiI2/1Et8G6vqOmaArpiIhG4ass4IdcS3G+Jl/vUCY7chbZFXPWYkmETi0Msg7ij2HVkyQt2OT6TFWBkhmGJ+zXS5lD9X6sjseMqLRNAvWGn4rmytkX8nug8iEsSxP4yxN4Jedji8jz2zoquyBZ7QwgSLu+g9Zev0Ibtn+GI76/giO0n6NPWh/RJ+s3yR1ggDTfpgb178LBbN3FUdRWtu40VuBe9Qv/YQ63FuLeMAQnX9jIGRBEwoIfg84quz5A8/2oJnVZHYu5h/ig9QPPx4o0buav5J9+xtgi515qw0vpdMWJnWhJdKOndDQVKerPMMISEa0SW3gH/14QltKZH/oyIvpPi152IPENvlzBbruHXKl6ypZ5+fdg129ylQLujsfMBPOgiM2o3PXLtJaMkXZj/TWBXF6SVIwAmsVyFCP+VrAAysu4+5r7YhFd+T1fj2M820H743LqtZLj1CyH34pENlzysm8hwvCUr1/qkWML3ZDi3noCNBukM0Plwfx1bgQEBgUEEvo2hfnAwyEkKx7jWBT62h39Cz9NfrNbYgz7Nnx88PTAiojwxdW2ib4gRazBppYZD3rs+2V4zOGpAfUz5kB4jPQJewfknLuEZ/osWLMoaHOfhEaB162P0Csp8Y9/Jf+/VmaebU6PGe3r2UvXwVr7q03OupGMQxLRWOvdky406DWk+Qj34Av5Ouzt/p6xMrmvlgLMesA4iP9jXTwKoWjKGNUSetOyk9KO6kwePfHtkFX2szrm/jcu1rDjWeL6BS7as2vFnPvDoBH4eDTwc5Don5RRUDiyMth6rtx47jQtcAzXqXmqcJ+epxWdAdmRkoYG7LusQBbpukc4gqe5gpizmt7SXcwmWB9xdy7ayshV8XNmy9m1yXOPB/2n8GOTHIjDYF5wdFh7+rEo5swNZsgFAJ6FOL4oqBStZGmkUChou31Lxw5+/m9Mz5tgfCsJ5TV/37Ofh7TtEnzxJFAd/YTmVHR09ZOqE5FGjJ6qrSyprRb5f3tzYBCX2+2ovDRobozDb2c0yfzCT9OSxm2tyzITE3r03vCnplifVtCY4swNtNR0UgJRS6MNsPlUYWCFlNV6GBjib92xoyNpiIDxPdnFcLSF8yNbMc8cOpy/5eFlhaWEG8aV36J2Jb6tHRSncU8fz9+hEn9G9TAn0V3rz1snmmxfPnmZ+BL9wZ8Av3ZhX2FXC8CIEQU64iyMhPW49aL2+rcXjoOPcWStyCpcm5jrtd0zdq8beWIWV2Lt6nWPC7CM3rjSbUhxMn4wDm+KA7wOwyQ35I5QURIx65thnAgyBEmZcsPp57eZehzNSNgIsqwghpJbjrH7pS0qLitYVZtgPGOFhSsBq7IrdsXvCtAx8rF01PtWdeN06+d2PlxtPP4+zK9ijku5HNguIzibZWakJlGxTYPUna94vditPopWt7e0/P7j/pdPKJYtLRfz4yzNThvXuQNgLd8MO2Itepzdci3Zs2F0q8Y+j8dwDfiTcd4KB//Prx0v2hQKWDSJgSlS9EDPit/cbr33OWckFS4ihZkHDV6fPpW0PIrxIdog3gzctLMqevyJnE41fltNtZEz5hl2mWdgOrPXGyllJ6vGj+LAqy6nbt7n6U7car187/iPTZykEcYB0X2RZCzdJFatuA2pra4Wm6mo6p72e78viXARfkbZ7JVsRCfNtoTAAc4VQ3/Tgs57yHBxJBi+ikSAHpshXOGmcGfKsgaM+57gqwhOub0lK1goP7rVP36tYWxNnnr8YvtIKSJq1mHtzappGO2iwV1rCtHfeTaw5aw0muzak795kLWbvPbJs7r6Mv+eyXxaKo2uZLI5gLnJLRs3WfclZH5b8JUDVd0iAefL+BsZ8fWaNjIM4llPA1x7uXc/vyf/Iobb79x7+/vDJ3cP5G8qLl63dvIx40dv0LtYBql2xK31Ab1w/e/77S5ebWZ7SeOA5Wsa0xDNQb1Pyucf+kaRtcQIP6u/CAs/3Kc9trD+cmb9mRWFpQZacoocUW+hEQXwz1Z0fEqNKnkwf0R9uHj935+KZU7J/SCHY4faCfziQFM5kuWj+7h3ey0+fEO3v5xtpnk9CrU1cZET24KAR4f6dpoWFBHbe2vmYdHZGQG7uBwz3kir33+7QzypRmOHvlYg93P6fms+06D51WZmzdNGEafOWjtBGj/j2zOffemx2Wjwnc1705IU3X43oh18p3ZZf7B0fM27coLHdvLt7dgmYM3bN+uxl6mGjR4wMH+riNVTfI5Xp4d3RSnoKvZAGznCmhlGpNxrCDRqDRi8fxqTnhCkpKQvzjOmNjYaBvkPsXLMyyTeLHz5cbB0/ZqAj45EPtvwCEHdjPGQmL1YjrYseyisXJsNmeuaHJcxXcCs4aJ68t4lcsMZuTqspJ2mWnVPmaYRxiZJ/IJO4p8Czi602qeT7nop7SlMu0gVH7yt8Pbq4udn/yfdl6WUdpF4wLXD8WG9yHLbD70jpDBJuiwFIJ/26DMZmie8wfi9uFW6zeybwNaoMuJXun3L1vNBA78JRKu2VfnuIrbC3s7T3VTxG2jtbaCPOYqu0V6P3NxqI81x65rzoqL7qyeaBxmU9Xl/hPtWp/x+Is2NZgK4++caNvVvMdvfat1luaRPtJkBXBCxjJNdRpIikY9Dr2pr2bW2Z2kTb+PO/EBGhcyQCli5BJlKFJkH7K9bn09BYoDKgmUCxQhzigSqFBmQCqrS1K2HtYZivFKvkvhiBktic9JbXTeZvoSBol0O7E7SjYH08UB44g73jbP043ICWAhUBr0LoF9rm8gjrIxQBsryhnw9tBdsD48OYXiQBzbbZ08tG7P8IJqAcoI02B/YBgjaB7WQs0FHAgR9QOhDcC7krQI/AcjUQ7OMPQay6A81jLgUC34oWEA17FMBbAXsUsMcO5u1aEeo0DAh4dvYB2gMEc52Bnz2gw74RIQe4tTusBLqNUJcUIFjjCLo4/gvoLSCQ6fgx+3+IpG4IjkXjUCKI/nvMeIQP4I78PXwx+h8bB/wlDQplbmRzdHJlYW0KZW5kb2JqCjI0NSAwIG9iago8PAovTGVuZ3RoIDEzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJz7/5/a4AcAkXFSpw0KZW5kc3RyZWFtCmVuZG9iagoyNDYgMCBvYmoKPDwKL0xlbmd0aCAxNzA1Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGgxIDIxNjgKPj4Kc3RyZWFtDQp4nG1WC3CTVRY+9/73/5NCH0nTP5lUKPmbNgWpoHlSyUILOK08aykWxkdb+txS+qBLC9hCWNROXQRdXF1Fiq/hZYUuiJZVqsgoKq3gri5TqpUBV+gIizvDutg2t56bBFx3yOT8978n557znXO+e2+AAIAeAiABVBQ31OHMgLJZaCuq15ZHL1x9H74/A6C8VllWXOpoXdsFoJuGOm8lKqxPxP0R52JdSuXK361ZPqg7hHO0hwera0uKAXIDOP8B50Uri9fUQSN5E13n4txWt6qsrlLZ/BjOxXodECCjoxAHFHoBZKe8EVHpALKMmtGkGTXZObx9vtQ74pI3Dm1AOckGAdfkj16Wt8rPwm0AZTaTrDB7cgr1uONTXE5mkR0Oe7KiJpjN0m0kuoKQxfy9c+f5B7tfItPOXyfTZvIR7dimj08VHvmCRBf3nHiD5Hx3iWTuPnEsu6rl+tVXBhoQGYU2xFOPeKLAhHgSKLMjHhsQt8NuN7qcXq9cf4Cf/DT4EeGklDzOz1zu/3xow5FyevI8f3+vvJE/z/9y4epIdtNZuOnPgP7Ghv0pivBn1JxMdmti9MqGlu928ld4H10bJEZ+hg/xUyRj3aPS8ba/N3FcOnh2gPvWivwtAKwXfUUqpXk0VZJ5H89gb7EdwyVsx7ffgrCbxXbSmfIAyGin2olHozP38g5CWfcEkjA5jMs/epkF2EJIARfAPckOj9vr83ncooa61HjNaVaNCWaX06ci4mRHml1RTDpFp4gCo9br9ZC2HZ39pwfn5i+8N4r3+8gLvQOT7rQlued6q8rGKNMPnn6qZOKkydnTZ/m8MxJe375nP2O+qorsvFiS9elfeeMD9yh/jompLKtaQaOobIjP8S+Yl5KyIVvgz0VsPsSWKJCB0QAup/mX/mITfHIspXk/8msk9vp7Qzb+z+iipSura2tyq2NIYtym0wkklSgkmkx+f2/s4pLDb73zTllpzKrXCzFv5BB7UO4BK6QCFE+hHrtIkBoN8SKIKw3rmmC2kFCYcDmk+VQvsykdgaOf9Z1o2H0HpcTKWHB8bU3tutWr6mvGZM5PXL6cpJEoEkNSiwoPkj8M25yNc+i4rq7jbx44+nao3iKnOzAnk8gqK5IF1SLpxRvV1FB+OtK0unpuoYlENfCXrvEhMuba4I/8B33NQyUrJHKx/eWsTAs/SzSiYno2fpL/Q9+5adMTzaG+2zHQfsxNDfPD7nFhV11OixqqnOpSSR+/1N7+4s68oom350z/UmoeeVRq7q7ftsVwOCojZ0k34tyKjvagj/B+VDUPQU9kD79IrPyi3HPqFK8Z/ojdHYrXimdFO1sEt4fjuR1pWhJVXV5vqJShQQ3pRfgbL8KXLJFoqsjMvb26+blExfdCU/suPpiXl1cjnktW0DnBd6Wcgtr06GUPqc11jY3ra858EryPFm7dsnNz8IAY94fjs1KMn3iL+LeMl9HR1NHFLxUVl7f8X4gvesLuD9zo1Tbs1Vix47IMEO5S5BS4wUG2jX/FeZCfIzYiYe+xLevXBAItjb/fSJP4T/xLko4clMlk/g3/97H9b3cdPnokjJlyxGz9H8wSYvZ5b3bqJmLGJDZRsy2d5dVme367mpqCVyT/sqYpUTMWzImru2tqetz3cfvQZw7inYA+0wWzmNiuPnOEv2lTaJrDEaKB2aK7sYUsZvFlE/johW+upP1XrQg0VhdULmpZNm5xwdX+Y9+P/yn64fLS0gUPbPjQPz2b+HccevJPqQsy/Znu36iGpPExkwIPb3/j2S2Js7Jc/qm++ESfw9GEOKyj/6JPy9ME/8rEqeERFPS5kHj28GFCny5vbX687bmlnb29/plJmYbk1ja6vpvz7uBni+bFCk7psadVyK8YzAVprpkQ6gzqM7EqXs87eQuZdFRvH8esSWM/YXcLJgZftbaUxuaXJtNawDsltM/kAcUBY0I3jZnMg1vpFfg6xOECPCuXRM5KYveYNLqEd+wbIVQ+xC9PIDZhg5L/yNSe2ccL4/z/AUkvTlDou/43qxj76/RXhneNXDAX6ZeirYL8ISEDfOpm8IUw23xweNfQOnNRRP/Lx6IA9NIMvCFOQD5Km3w/tLELYKH78AxvAD9KLs7zxYg6O9pu1Y2HVtQJyZXEewPk4G9WHPUh+7BtQSRGekSeQjmHoNJFMihrkIcJKHgf00sA0nwUtJHexfr7UfBeZ3iXy3NQenCf438FBe9ypRIlIP4jhLKxkDzIhyLM+te5MSBdZPSxTvYk/AwK1kInDQplbmRzdHJlYW0KZW5kb2JqCjI0NyAwIG9iago8PAovTGVuZ3RoIDEzCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCj4+CnN0cmVhbQ0KeJz7/x8N/AEAqmQR7A0KZW5kc3RyZWFtCmVuZG9iagp4cmVmCjAgMjQ4CjAwMDAwMDAwMDAgNjU1MzUgZg0KMDAwMDAwMDAxNSAwMDAwMCBuDQowMDAwMDAwNTczIDAwMDAwIG4NCjAwMDAwMDA2MzAgMDAwMDAgbg0KMDAwMDAwNTY1NCAwMDAwMCBuDQowMDAwMDA1Njg4IDAwMDAwIG4NCjAwMDAwMDU3MzEgMDAwMDAgbg0KMDAwMDAwNTk1OSAwMDAwMCBuDQowMDAwMDAwMTk0IDAwMDAwIG4NCjAwMDAwMDYwNjggMDAwMDAgbg0KMDAwMDAwNjIxMiAwMDAwMCBuDQowMDAwMDA4NzY1IDAwMDAwIG4NCjAwMDAwMDkwMjggMDAwMDAgbg0KMDAwMDAwOTExNCAwMDAwMCBuDQowMDAwMDA5MzQ1IDAwMDAwIG4NCjAwMDAwMTE0MTQgMDAwMDAgbg0KMDAwMDAxMTQ5NyAwMDAwMCBuDQowMDAwMDExNjEyIDAwMDAwIG4NCjAwMDAwMTE2ODQgMDAwMDAgbg0KMDAwMDAxMTc1NiAwMDAwMCBuDQowMDAwMDExODM5IDAwMDAwIG4NCjAwMDAwMTE5MTMgMDAwMDAgbg0KMDAwMDAxMTk5NiAwMDAwMCBuDQowMDAwMDEyMDY4IDAwMDAwIG4NCjAwMDAwMTIxNDEgMDAwMDAgbg0KMDAwMDAxMjIxMyAwMDAwMCBuDQowMDAwMDEyMjk1IDAwMDAwIG4NCjAwMDAwMTIzNzcgMDAwMDAgbg0KMDAwMDAxMjQ2MCAwMDAwMCBuDQowMDAwMDEyNTQzIDAwMDAwIG4NCjAwMDAwMTI2MTYgMDAwMDAgbg0KMDAwMDAxMjY4OSAwMDAwMCBuDQowMDAwMDEyNzYyIDAwMDAwIG4NCjAwMDAwMTI4MzUgMDAwMDAgbg0KMDAwMDAxMjkwOCAwMDAwMCBuDQowMDAwMDEyOTgxIDAwMDAwIG4NCjAwMDAwMTMwNTQgMDAwMDAgbg0KMDAwMDAxMzEzNyAwMDAwMCBuDQowMDAwMDEzMjIwIDAwMDAwIG4NCjAwMDAwMTMzMDMgMDAwMDAgbg0KMDAwMDAxMzM4NiAwMDAwMCBuDQowMDAwMDEzNDU5IDAwMDAwIG4NCjAwMDAwMTM1MzIgMDAwMDAgbg0KMDAwMDAxMzYwNSAwMDAwMCBuDQowMDAwMDEzNjc4IDAwMDAwIG4NCjAwMDAwMTM3NjEgMDAwMDAgbg0KMDAwMDAxNjA5NCAwMDAwMCBuDQowMDAwMDE2MTUyIDAwMDAwIG4NCjAwMDAwMjE4NDIgMDAwMDAgbg0KMDAwMDAyMTkyMyAwMDAwMCBuDQowMDAwMDIyMDI3IDAwMDAwIG4NCjAwMDAwMjIxMjMgMDAwMDAgbg0KMDAwMDAyMjIxMCAwMDAwMCBuDQowMDAwMDIyMjk3IDAwMDAwIG4NCjAwMDAwMjIzNzYgMDAwMDAgbg0KMDAwMDAyMjQ0NSAwMDAwMCBuDQowMDAwMDIyNTMyIDAwMDAwIG4NCjAwMDAwMjI2MzIgMDAwMDAgbg0KMDAwMDAyMjY3NSAwMDAwMCBuDQowMDAwMDIyNzE4IDAwMDAwIG4NCjAwMDAwMjI3NjEgMDAwMDAgbg0KMDAwMDAyMjgwNCAwMDAwMCBuDQowMDAwMDIyOTA0IDAwMDAwIG4NCjAwMDAwMjMwMDYgMDAwMDAgbg0KMDAwMDAyMzEwNiAwMDAwMCBuDQowMDAwMDIzMTQ5IDAwMDAwIG4NCjAwMDAwMjMxOTIgMDAwMDAgbg0KMDAwMDAyMzIzNSAwMDAwMCBuDQowMDAwMDIzMjc4IDAwMDAwIG4NCjAwMDAwMjMzNzggMDAwMDAgbg0KMDAwMDAyMzQ1NSAwMDAwMCBuDQowMDAwMDIzNDk4IDAwMDAwIG4NCjAwMDAwMjM1MzggMDAwMDAgbg0KMDAwMDAyMzU3OCAwMDAwMCBuDQowMDAwMDIzNjYxIDAwMDAwIG4NCjAwMDAwMjM3NDQgMDAwMDAgbg0KMDAwMDAyMzgyNyAwMDAwMCBuDQowMDAwMDIzOTA1IDAwMDAwIG4NCjAwMDAwMjM5ODUgMDAwMDAgbg0KMDAwMDAyNDA2NSAwMDAwMCBuDQowMDAwMDI0MTQ1IDAwMDAwIG4NCjAwMDAwMjQyMjcgMDAwMDAgbg0KMDAwMDAyNDMwNSAwMDAwMCBuDQowMDAwMDI0Mzg3IDAwMDAwIG4NCjAwMDAwMjQ0NzQgMDAwMDAgbg0KMDAwMDAyNDU1OSAwMDAwMCBuDQowMDAwMDI0NjQ2IDAwMDAwIG4NCjAwMDAwMjQ3MjYgMDAwMDAgbg0KMDAwMDAyNDgwNyAwMDAwMCBuDQowMDAwMDI0ODg5IDAwMDAwIG4NCjAwMDAwMjQ5NjggMDAwMDAgbg0KMDAwMDAyNTA0NyAwMDAwMCBuDQowMDAwMDI1MTI4IDAwMDAwIG4NCjAwMDAwMjUyMDcgMDAwMDAgbg0KMDAwMDAyNTI4NiAwMDAwMCBuDQowMDAwMDI1MzY4IDAwMDAwIG4NCjAwMDAwMjU0NDggMDAwMDAgbg0KMDAwMDAyNTUyOSAwMDAwMCBuDQowMDAwMDI1NjA3IDAwMDAwIG4NCjAwMDAwMjU2ODkgMDAwMDAgbg0KMDAwMDAyNTc3MCAwMDAwMCBuDQowMDAwMDI1ODUzIDAwMDAwIG4NCjAwMDAwMjU5NDAgMDAwMDAgbg0KMDAwMDAyNjAyNSAwMDAwMCBuDQowMDAwMDI2MTEyIDAwMDAwIG4NCjAwMDAwMjYxOTkgMDAwMDAgbg0KMDAwMDAyNjI4MiAwMDAwMCBuDQowMDAwMDI2MzY4IDAwMDAwIG4NCjAwMDAwMjY0NTEgMDAwMDAgbg0KMDAwMDAyNjUzNSAwMDAwMCBuDQowMDAwMDI2NjE4IDAwMDAwIG4NCjAwMDAwMjY3MDEgMDAwMDAgbg0KMDAwMDAyNjc4NyAwMDAwMCBuDQowMDAwMDI2ODc0IDAwMDAwIG4NCjAwMDAwMjY5NjAgMDAwMDAgbg0KMDAwMDAyNzA0OCAwMDAwMCBuDQowMDAwMDI3MTMxIDAwMDAwIG4NCjAwMDAwMjcyMTcgMDAwMDAgbg0KMDAwMDAyNzMwMiAwMDAwMCBuDQowMDAwMDI3Mzg2IDAwMDAwIG4NCjAwMDAwMjc0NzUgMDAwMDAgbg0KMDAwMDAyNzU1OSAwMDAwMCBuDQowMDAwMDI3NjQzIDAwMDAwIG4NCjAwMDAwMjc3MjggMDAwMDAgbg0KMDAwMDAyNzgwNyAwMDAwMCBuDQowMDAwMDI3ODM4IDAwMDAwIG4NCjAwMDAwMjc5MTcgMDAwMDAgbg0KMDAwMDAyNzk5NSAwMDAwMCBuDQowMDAwMDI4MDI2IDAwMDAwIG4NCjAwMDAwMjgxMDQgMDAwMDAgbg0KMDAwMDAyODE4NiAwMDAwMCBuDQowMDAwMDI4MjE3IDAwMDAwIG4NCjAwMDAwMjgyOTkgMDAwMDAgbg0KMDAwMDAyODM4MyAwMDAwMCBuDQowMDAwMDI4NDY3IDAwMDAwIG4NCjAwMDAwMjg1NTEgMDAwMDAgbg0KMDAwMDAyODU4MiAwMDAwMCBuDQowMDAwMDI4NjY2IDAwMDAwIG4NCjAwMDAwMjg3NTEgMDAwMDAgbg0KMDAwMDAyODc4MiAwMDAwMCBuDQowMDAwMDI4ODY3IDAwMDAwIG4NCjAwMDAwMjg5NTIgMDAwMDAgbg0KMDAwMDAyOTAzNyAwMDAwMCBuDQowMDAwMDI5MTIyIDAwMDAwIG4NCjAwMDAwMjkyMDcgMDAwMDAgbg0KMDAwMDAyOTI5MiAwMDAwMCBuDQowMDAwMDI5Mzc3IDAwMDAwIG4NCjAwMDAwMjk0NjQgMDAwMDAgbg0KMDAwMDAyOTQ5NSAwMDAwMCBuDQowMDAwMDI5NTgyIDAwMDAwIG4NCjAwMDAwMjk2NzEgMDAwMDAgbg0KMDAwMDAyOTcwMiAwMDAwMCBuDQowMDAwMDI5NzkxIDAwMDAwIG4NCjAwMDAwMjk4NzQgMDAwMDAgbg0KMDAwMDAyOTkwNSAwMDAwMCBuDQowMDAwMDI5OTg4IDAwMDAwIG4NCjAwMDAwMzAwNjYgMDAwMDAgbg0KMDAwMDAzMDA5NyAwMDAwMCBuDQowMDAwMDMwMTc1IDAwMDAwIG4NCjAwMDAwMzAyNTcgMDAwMDAgbg0KMDAwMDAzMDI4OCAwMDAwMCBuDQowMDAwMDMwMzcwIDAwMDAwIG4NCjAwMDAwMzA0NTAgMDAwMDAgbg0KMDAwMDAzMDQ4MiAwMDAwMCBuDQowMDAwMDMwNTYyIDAwMDAwIG4NCjAwMDAwMzA2NDMgMDAwMDAgbg0KMDAwMDAzMDY3NSAwMDAwMCBuDQowMDAwMDMwNzU2IDAwMDAwIG4NCjAwMDAwMzA4MzcgMDAwMDAgbg0KMDAwMDAzMDg2OSAwMDAwMCBuDQowMDAwMDMwOTUwIDAwMDAwIG4NCjAwMDAwMzEwMzEgMDAwMDAgbg0KMDAwMDAzMTA2MyAwMDAwMCBuDQowMDAwMDMxMTQ0IDAwMDAwIG4NCjAwMDAwMzEyMjUgMDAwMDAgbg0KMDAwMDAzMTI1NyAwMDAwMCBuDQowMDAwMDMxMzM4IDAwMDAwIG4NCjAwMDAwMzE0MjIgMDAwMDAgbg0KMDAwMDAzMTQ1NCAwMDAwMCBuDQowMDAwMDMxNTM4IDAwMDAwIG4NCjAwMDAwMzE2MjQgMDAwMDAgbg0KMDAwMDAzMTY1NiAwMDAwMCBuDQowMDAwMDMxNzQyIDAwMDAwIG4NCjAwMDAwMzE4MjkgMDAwMDAgbg0KMDAwMDAzMTg2MSAwMDAwMCBuDQowMDAwMDMxOTQ4IDAwMDAwIG4NCjAwMDAwMzIwMzMgMDAwMDAgbg0KMDAwMDAzMjA2NSAwMDAwMCBuDQowMDAwMDMyMTUwIDAwMDAwIG4NCjAwMDAwMzIyMzMgMDAwMDAgbg0KMDAwMDAzMjI2NSAwMDAwMCBuDQowMDAwMDMyMzQ4IDAwMDAwIG4NCjAwMDAwMzI0MzQgMDAwMDAgbg0KMDAwMDAzMjQ2NiAwMDAwMCBuDQowMDAwMDMyNTUyIDAwMDAwIG4NCjAwMDAwMzI2MzggMDAwMDAgbg0KMDAwMDAzMjY3MCAwMDAwMCBuDQowMDAwMDMyNzU2IDAwMDAwIG4NCjAwMDAwMzI4NDUgMDAwMDAgbg0KMDAwMDAzMjg3NyAwMDAwMCBuDQowMDAwMDMyOTY2IDAwMDAwIG4NCjAwMDAwMzMwNTIgMDAwMDAgbg0KMDAwMDAzMzA4NCAwMDAwMCBuDQowMDAwMDMzMTcwIDAwMDAwIG4NCjAwMDAwMzMyNTYgMDAwMDAgbg0KMDAwMDAzMzI4OCAwMDAwMCBuDQowMDAwMDMzMzc0IDAwMDAwIG4NCjAwMDAwMzM0NTkgMDAwMDAgbg0KMDAwMDAzMzQ5MSAwMDAwMCBuDQowMDAwMDMzNTc2IDAwMDAwIG4NCjAwMDAwMzM2NjQgMDAwMDAgbg0KMDAwMDAzMzY5NiAwMDAwMCBuDQowMDAwMDMzNzg0IDAwMDAwIG4NCjAwMDAwMzM4NjkgMDAwMDAgbg0KMDAwMDAzMzkwMSAwMDAwMCBuDQowMDAwMDMzOTg2IDAwMDAwIG4NCjAwMDAwMzQxMzYgMDAwMDAgbg0KMDAwMDAzNDI4NyAwMDAwMCBuDQowMDAwMDM0NDM1IDAwMDAwIG4NCjAwMDAwMzQ0NzEgMDAwMDAgbg0KMDAwMDAzNDU1OCAwMDAwMCBuDQowMDAwMDM0NjM3IDAwMDAwIG4NCjAwMDAwMzQ3MTYgMDAwMDAgbg0KMDAwMDAzNDc4NCAwMDAwMCBuDQowMDAwMDM1MTk4IDAwMDAwIG4NCjAwMDAwMzU2MjAgMDAwMDAgbg0KMDAwMDAzNjA5MCAwMDAwMCBuDQowMDAwMDM2NTAzIDAwMDAwIG4NCjAwMDAwMzY4MzEgMDAwMDAgbg0KMDAwMDAzNzIyMyAwMDAwMCBuDQowMDAwMDM3Mjc5IDAwMDAwIG4NCjAwMDAwMzczNTkgMDAwMDAgbg0KMDAwMDAzNzQwMyAwMDAwMCBuDQowMDAwMDM3NDc5IDAwMDAwIG4NCjAwMDAwMzc3ODIgMDAwMDAgbg0KMDAwMDAzNzk2NSAwMDAwMCBuDQowMDAwMDM4MDQxIDAwMDAwIG4NCjAwMDAwMzgzNDEgMDAwMDAgbg0KMDAwMDAzODU0NiAwMDAwMCBuDQowMDAwMDM4NjIyIDAwMDAwIG4NCjAwMDAwMzg5MTkgMDAwMDAgbg0KMDAwMDAzOTA2MSAwMDAwMCBuDQowMDAwMDM5MTA1IDAwMDAwIG4NCjAwMDAwNDI0NjggMDAwMDAgbg0KMDAwMDA0MjU1NiAwMDAwMCBuDQowMDAwMDQ1OTgyIDAwMDAwIG4NCjAwMDAwNDYwNzAgMDAwMDAgbg0KMDAwMDA0Nzg2NiAwMDAwMCBuDQp0cmFpbGVyCjw8Ci9Sb290IDEgMCBSCi9JbmZvIDggMCBSCi9JRCBbPERCRDQ4RDA1RUNBNUQ2QzVERkYwRjM4QTc0MEM3NkU1PiA8REJENDhEMDVFQ0E1RDZDNURGRjBGMzhBNzQwQzc2RTU+XQovU2l6ZSAyNDgKPj4Kc3RhcnR4cmVmCjQ3OTU0CiUlRU9GCg=="
      }
    }
  ]
}

```
