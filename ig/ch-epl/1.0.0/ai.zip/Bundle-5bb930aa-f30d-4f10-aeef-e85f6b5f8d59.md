# ESTALIS Matrixpfl 50/250 24 Stk (Bundle) - CH EPL (R5) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ESTALIS Matrixpfl 50/250 24 Stk (Bundle)**

## Example Bundle: ESTALIS Matrixpfl 50/250 24 Stk (Bundle)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "5bb930aa-f30d-4f10-aeef-e85f6b5f8d59",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPMedicinalProductDefinition/Estalis-Transdermalpatch",
      "resource" : {
        "resourceType" : "MedicinalProductDefinition",
        "id" : "Estalis-Transdermalpatch",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-medicinalproductdefinition"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Estalis-Transdermalpatch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Estalis-Transdermalpatch</b></p><a name=\"Estalis-Transdermalpatch\"> </a><a name=\"hcEstalis-Transdermalpatch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-medicinalproductdefinition.html\">IDMP MedicinalProductDefinition</a></p></div><p><b>CH - SMC Authorized Dose Form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10519000}\">Transdermal patch</span></p><p><b>identifier</b>: <a href=\"NamingSystem-MPID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Medical Product Identifier</a>/CH-7601001029439-5470402</p><p><b>indication</b>: </p><div><p>Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.</p>\n</div><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply 756005022003}\">Medicinal product subject to medical or veterinary prescription (B)</span></p><p><b>additionalMonitoringIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-additional-monitoring-indicator 756005001003}\">No Warning</span></p><p><b>pediatricUseIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-pediatric-use-indicator 756005003002}\">Not authorised for the treatment in children</span></p><p><b>classification</b>: <span title=\"Codes:{http://www.whocc.no/atc G03FA01}\">norethisterone and estrogen</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-category 756005021001}\">NA KAS art. 12 para. 5 TPLO</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode 756005004001}\">Synthetic</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-product-type 756001003002}\">Originator product</span></p><p><b>attachedDocument</b>: </p><ul><li><a href=\"DocumentReference-DocRef-FI-Estalis.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-epl/sid/attno#Application / Assessment Tracking Number#123456789-initial submission-Example-hij-123; status = current; type = Fachinformation; date = 2021-10-01 00:00:00+0000</a></li><li><a href=\"DocumentReference-DocRef-PI-Estalis.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-epl/sid/attno#Application / Assessment Tracking Number#123456789-initial submission-Example-hij-321; status = current; type = Patienteninformation; date = 2021-10-01 00:00:00+0000</a></li></ul><blockquote><p><b>name</b></p><p><b>productName</b>: ESTALIS Matrixpfl 50/250 24 Stk</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-medicinal-product-name-type SMC}\">Zugelassener Arzneimittelname</span></p><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 de-CH}\">German (Switzerland)</span></td></tr></table></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/authorizedDoseForm",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "10519000",
                  "display" : "Transdermal patch"
                }
              ]
            }
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/mpid",
            "value" : "CH-7601001029439-5470402"
          }
        ],
        "indication" : "Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.",
        "legalStatusOfSupply" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply",
              "code" : "756005022003",
              "display" : "Medicinal product subject to medical or veterinary prescription (B)"
            }
          ]
        },
        "additionalMonitoringIndicator" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-additional-monitoring-indicator",
              "code" : "756005001003",
              "display" : "No Warning"
            }
          ]
        },
        "pediatricUseIndicator" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-pediatric-use-indicator",
              "code" : "756005003002",
              "display" : "Not authorised for the treatment in children"
            }
          ]
        },
        "classification" : [
          {
            "coding" : [
              {
                "system" : "http://www.whocc.no/atc",
                "code" : "G03FA01"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-category",
                "code" : "756005021001",
                "display" : "NA KAS art. 12 para. 5 TPLO"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode",
                "code" : "756005004001",
                "display" : "Synthetic"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-product-type",
                "code" : "756001003002",
                "display" : "Originator product"
              }
            ]
          }
        ],
        "attachedDocument" : [
          {
            "reference" : "DocumentReference/DocRef-FI-Estalis"
          },
          {
            "reference" : "DocumentReference/DocRef-PI-Estalis"
          }
        ],
        "name" : [
          {
            "productName" : "ESTALIS Matrixpfl 50/250 24 Stk",
            "type" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-medicinal-product-name-type",
                  "code" : "SMC",
                  "display" : "Zugelassener Arzneimittelname"
                }
              ]
            },
            "usage" : [
              {
                "country" : {
                  "coding" : [
                    {
                      "system" : "urn:iso:std:iso:3166",
                      "code" : "CH",
                      "display" : "Switzerland"
                    }
                  ]
                },
                "language" : {
                  "coding" : [
                    {
                      "system" : "urn:ietf:bcp:47",
                      "code" : "de-CH",
                      "display" : "German (Switzerland)"
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPDocumentReference/DocRef-FI-Estalis",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "DocRef-FI-Estalis",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"
          ]
        },
        "language" : "de-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"DocumentReference_DocRef-FI-Estalis\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-FI-Estalis</b></p><a name=\"DocRef-FI-Estalis\"> </a><a name=\"hcDocRef-FI-Estalis\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">CH IDMP DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456789-initial submission-Example-hij-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type 756005007001}\">Fachinformation</span></p><p><b>date</b>: 2021-10-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&amp;lang=DE&amp;authNr=54704&amp;supportMultipleResults=1\">https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&amp;lang=DE&amp;authNr=54704&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
            "value" : "123456789-initial submission-Example-hij-123"
          }
        ],
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
              "code" : "756005007001",
              "display" : "Fachinformation"
            }
          ]
        },
        "date" : "2021-10-01T00:00:00Z",
        "content" : [
          {
            "attachment" : {
              "url" : "https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&lang=DE&authNr=54704&supportMultipleResults=1"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPDocumentReference/DocRef-PI-Estalis",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "DocRef-PI-Estalis",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"
          ]
        },
        "language" : "de-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"DocumentReference_DocRef-PI-Estalis\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-PI-Estalis</b></p><a name=\"DocRef-PI-Estalis\"> </a><a name=\"hcDocRef-PI-Estalis\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">CH IDMP DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456789-initial submission-Example-hij-321</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type 756005007002}\">Patienteninformation</span></p><p><b>date</b>: 2021-10-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&amp;lang=DE&amp;authNr=54704&amp;supportMultipleResults=1\">https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&amp;lang=DE&amp;authNr=54704&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
            "value" : "123456789-initial submission-Example-hij-321"
          }
        ],
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
              "code" : "756005007002",
              "display" : "Patienteninformation"
            }
          ]
        },
        "date" : "2021-10-01T00:00:00Z",
        "content" : [
          {
            "attachment" : {
              "url" : "https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&lang=DE&authNr=54704&supportMultipleResults=1"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/MA-5470402",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "MA-5470402",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-regulatedauthorization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-5470402\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-5470402</b></p><a name=\"MA-5470402\"> </a><a name=\"hcMA-5470402\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">IDMP RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/5470402</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status 756005023007}\">valid</span></p><p><b>statusDate</b>: 1999-08-17</p><p><b>holder</b>: <a href=\"#hcMA-5470402/holder-Sandoz-Pharmaceuticals-AG\">Organization Sandoz Pharmaceuticals AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-5470402/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Sandoz-Pharmaceuticals-AG</b></p><a name=\"MA-5470402/holder-Sandoz-Pharmaceuticals-AG\"> </a><a name=\"hcMA-5470402/holder-Sandoz-Pharmaceuticals-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100054743, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001029439</p><p><b>name</b>: Sandoz Pharmaceuticals AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-5470402/regulator-SMC\"> </a><a name=\"hcMA-5470402/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Sandoz-Pharmaceuticals-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100054743"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001029439"
              }
            ],
            "name" : "Sandoz Pharmaceuticals AG"
          },
          {
            "resourceType" : "Organization",
            "id" : "regulator-SMC",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100010911"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001398511"
              }
            ],
            "name" : "SMC"
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/authno",
            "value" : "5470402"
          }
        ],
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002001",
              "display" : "Marketing Authorisation"
            }
          ]
        },
        "region" : [
          {
            "coding" : [
              {
                "system" : "urn:iso:std:iso:3166",
                "code" : "CH",
                "display" : "Switzerland"
              }
            ]
          }
        ],
        "status" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status",
              "code" : "756005023007",
              "display" : "valid"
            }
          ]
        },
        "statusDate" : "1999-08-17",
        "holder" : {
          "reference" : "#holder-Sandoz-Pharmaceuticals-AG"
        },
        "regulator" : {
          "reference" : "#regulator-SMC"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPPackagedProductDefinition/PMP-Estalis-Transdermalpatch",
      "resource" : {
        "resourceType" : "PackagedProductDefinition",
        "id" : "PMP-Estalis-Transdermalpatch",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-packagedproductdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_PMP-Estalis-Transdermalpatch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition PMP-Estalis-Transdermalpatch</b></p><a name=\"PMP-Estalis-Transdermalpatch\"> </a><a name=\"hcPMP-Estalis-Transdermalpatch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-packagedproductdefinition.html\">IDMP PackagedProductDefinition</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-PCID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Clinical Product Identifier</a>/CH-7601001029439-5470402-097</p><p><b>packageFor</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><p><b>containedItemQuantity</b>: 24 Patch<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15036000 = 'Patch')</span></p><p><b>description</b>: </p><div><p>ESTALIS Matrixpfl 50/250 24 Stk</p>\n</div><h3>LegalStatusOfSupplies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply 756005022003}\">Medicinal product subject to medical or veterinary prescription (B)</span></td></tr></table><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <a href=\"NamingSystem-GTIN.html\" title=\"GS1 defines trade items as products or services that are priced, ordered or invoiced at any point in the supply chain.\">Global Trade Item Number</a>/7680547040979</p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30009000}\">Box</span></p><p><b>quantity</b>: 1</p><h3>ShelfLifeStorages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period[x]</b></td><td><b>SpecialPrecautionsForStorage</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/100000073343 100000073403}\">Shelf life of the medicinal product as packaged for sale</span></td><td>No display for Duration  (value: 6; unit: month; system: http://unitsofmeasure.org; code: mo)</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-special-precautions-for-storage 756005042004}\">protect from light</span></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/pcid",
            "value" : "CH-7601001029439-5470402-097"
          }
        ],
        "packageFor" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "containedItemQuantity" : [
          {
            "value" : 24,
            "unit" : "Patch",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15036000"
          }
        ],
        "description" : "ESTALIS Matrixpfl 50/250 24 Stk",
        "legalStatusOfSupply" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply",
                  "code" : "756005022003",
                  "display" : "Medicinal product subject to medical or veterinary prescription (B)"
                }
              ]
            }
          }
        ],
        "packaging" : {
          "identifier" : [
            {
              "system" : "urn:oid:2.51.1.1",
              "value" : "7680547040979"
            }
          ],
          "type" : {
            "coding" : [
              {
                "system" : "http://standardterms.edqm.eu",
                "code" : "30009000",
                "display" : "Box"
              }
            ]
          },
          "quantity" : 1,
          "shelfLifeStorage" : [
            {
              "type" : {
                "coding" : [
                  {
                    "system" : "http://spor.ema.europa.eu/v1/lists/100000073343",
                    "code" : "100000073403",
                    "display" : "Shelf life of the medicinal product as packaged for sale"
                  }
                ]
              },
              "periodDuration" : {
                "value" : 6,
                "unit" : "month",
                "system" : "http://unitsofmeasure.org",
                "code" : "mo"
              },
              "specialPrecautionsForStorage" : [
                {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-special-precautions-for-storage",
                      "code" : "756005042004",
                      "display" : "protect from light"
                    }
                  ]
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/MA-54704089",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "MA-54704089",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-regulatedauthorization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-54704089\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-54704089</b></p><a name=\"MA-54704089\"> </a><a name=\"hcMA-54704089\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">IDMP RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/54704089</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status 756005023007}\">valid</span></p><p><b>statusDate</b>: 1999-08-17</p><p><b>holder</b>: <a href=\"#hcMA-54704089/holder-Sandoz-Pharmaceuticals-AG\">Organization Sandoz Pharmaceuticals AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-54704089/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Sandoz-Pharmaceuticals-AG</b></p><a name=\"MA-54704089/holder-Sandoz-Pharmaceuticals-AG\"> </a><a name=\"hcMA-54704089/holder-Sandoz-Pharmaceuticals-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100054743, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001029439</p><p><b>name</b>: Sandoz Pharmaceuticals AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-54704089/regulator-SMC\"> </a><a name=\"hcMA-54704089/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Sandoz-Pharmaceuticals-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100054743"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001029439"
              }
            ],
            "name" : "Sandoz Pharmaceuticals AG"
          },
          {
            "resourceType" : "Organization",
            "id" : "regulator-SMC",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100010911"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001398511"
              }
            ],
            "name" : "SMC"
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/authno",
            "value" : "54704089"
          }
        ],
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002001",
              "display" : "Marketing Authorisation"
            }
          ]
        },
        "region" : [
          {
            "coding" : [
              {
                "system" : "urn:iso:std:iso:3166",
                "code" : "CH",
                "display" : "Switzerland"
              }
            ]
          }
        ],
        "status" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status",
              "code" : "756005023007",
              "display" : "valid"
            }
          ]
        },
        "statusDate" : "1999-08-17",
        "holder" : {
          "reference" : "#holder-Sandoz-Pharmaceuticals-AG"
        },
        "regulator" : {
          "reference" : "#regulator-SMC"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/FOPH-17418",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "FOPH-17418",
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_FOPH-17418\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization FOPH-17418</b></p><a name=\"FOPH-17418\"> </a><a name=\"hcFOPH-17418\"> </a><blockquote><p><b>CH - EPL Reimbursement SL</b></p><ul><li>FOPHDossierNumber: <a href=\"NamingSystem-Dossier.html\" title=\"Identifier holding the Dossier number of FOPH\">FOPH Dossier Number</a>/17418</li><li>status: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-reimbursement-status 756001021001}\">Reimbursed</span></li><li>statusDate: 2000-04-15</li><li>listingStatus: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-listing-status 756001002001}\">Listed</span></li><li>listingPeriod: 2000-04-15 --&gt; (ongoing)</li><li>firstListingDate: 2000-04-15</li><li>costShare: 10</li><li>gamme: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-gamme 756002004011}\">Transdermal</span></li></ul></blockquote><blockquote><p><b>CH - EPL Product Price</b></p><ul><li>value: <span title=\"Swiss Franc\">CHF32.44</span> (CHF)</li><li>type: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type 756002005002}\">Ex-factory price</span></li><li>changeType: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change 756002006007}\">Price mutation after triennal review of pharmaceuticals</span></li><li>changeDate: 2014-11-01</li></ul></blockquote><blockquote><p><b>CH - EPL Product Price</b></p><ul><li>value: <span title=\"Swiss Franc\">CHF53.65</span> (CHF)</li><li>type: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type 756002005001}\">Retail price</span></li><li>changeType: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change 756002006005}\">VAT-change</span></li><li>changeDate: 2024-01-01</li></ul></blockquote><p><b>subject</b>: <a href=\"PackagedProductDefinition-PMP-Estalis-Transdermalpatch.html\">PackagedProductDefinition: identifier = http://fhir.ch/ig/ch-epl/sid/pcid#Clinical Product Identifier#CH-7601001029439-5470402-097; containedItemQuantity = 24 Patch; description = ESTALIS Matrixpfl 50/250 24 Stk</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002003}\">Reimbursement SL</span></p><h3>Indications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"ClinicalUseDefinition-IND-10031285.html\">ClinicalUseDefinition: type = indication</a></td></tr></table><p><b>holder</b>: <a href=\"#hcFOPH-17418/holder-Sandoz-Pharmaceuticals-AG\">Organization Sandoz Pharmaceuticals AG</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Sandoz-Pharmaceuticals-AG</b></p><a name=\"FOPH-17418/holder-Sandoz-Pharmaceuticals-AG\"> </a><a name=\"hcFOPH-17418/holder-Sandoz-Pharmaceuticals-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100054743, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001029439</p><p><b>name</b>: Sandoz Pharmaceuticals AG</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Sandoz-Pharmaceuticals-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100054743"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001029439"
              }
            ],
            "name" : "Sandoz Pharmaceuticals AG"
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "FOPHDossierNumber",
                "valueIdentifier" : {
                  "system" : "urn:oid:2.16.756.1",
                  "value" : "17418"
                }
              },
              {
                "url" : "status",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-reimbursement-status",
                      "code" : "756001021001",
                      "display" : "Reimbursed"
                    }
                  ]
                }
              },
              {
                "url" : "statusDate",
                "valueDate" : "2000-04-15"
              },
              {
                "url" : "listingStatus",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-listing-status",
                      "code" : "756001002001",
                      "display" : "Listed"
                    }
                  ]
                }
              },
              {
                "url" : "listingPeriod",
                "valuePeriod" : {
                  "start" : "2000-04-15"
                }
              },
              {
                "url" : "firstListingDate",
                "valueDate" : "2000-04-15"
              },
              {
                "url" : "costShare",
                "valueInteger" : 10
              },
              {
                "url" : "gamme",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-gamme",
                      "code" : "756002004011",
                      "display" : "Transdermal"
                    }
                  ]
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/reimbursementSL"
          },
          {
            "extension" : [
              {
                "url" : "value",
                "valueMoney" : {
                  "value" : 32.44,
                  "currency" : "CHF"
                }
              },
              {
                "url" : "type",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                      "code" : "756002005002",
                      "display" : "Ex-factory price"
                    }
                  ]
                }
              },
              {
                "url" : "changeType",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                      "code" : "756002006007",
                      "display" : "Price mutation after triennal review of pharmaceuticals"
                    }
                  ]
                }
              },
              {
                "url" : "changeDate",
                "valueDate" : "2014-11-01"
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
          },
          {
            "extension" : [
              {
                "url" : "value",
                "valueMoney" : {
                  "value" : 53.65,
                  "currency" : "CHF"
                }
              },
              {
                "url" : "type",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                      "code" : "756002005001",
                      "display" : "Retail price"
                    }
                  ]
                }
              },
              {
                "url" : "changeType",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                      "code" : "756002006005",
                      "display" : "VAT-change"
                    }
                  ]
                }
              },
              {
                "url" : "changeDate",
                "valueDate" : "2024-01-01"
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
          }
        ],
        "subject" : [
          {
            "reference" : "PackagedProductDefinition/PMP-Estalis-Transdermalpatch"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002003",
              "display" : "Reimbursement SL"
            }
          ]
        },
        "indication" : [
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "status",
                    "valueCodeableConcept" : {
                      "coding" : [
                        {
                          "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-limitationstatus",
                          "code" : "756002071001",
                          "display" : "Limitation Reimbursed"
                        }
                      ]
                    }
                  },
                  {
                    "url" : "statusDate",
                    "valueDate" : "2000-04-15"
                  },
                  {
                    "url" : "period",
                    "valuePeriod" : {
                      "start" : "2000-04-15"
                    }
                  },
                  {
                    "url" : "firstLimitationDate",
                    "valueDate" : "2000-04-15"
                  },
                  {
                    "extension" : [
                      {
                        "url" : "value",
                        "valueMoney" : {
                          "value" : 32.44,
                          "currency" : "CHF"
                        }
                      },
                      {
                        "url" : "type",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                              "code" : "756002005002",
                              "display" : "Ex-factory price"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeType",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                              "code" : "756002006007",
                              "display" : "Price mutation after triennal review of pharmaceuticals"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeDate",
                        "valueDate" : "2014-11-01"
                      }
                    ],
                    "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
                  },
                  {
                    "extension" : [
                      {
                        "url" : "value",
                        "valueMoney" : {
                          "value" : 53.65,
                          "currency" : "CHF"
                        }
                      },
                      {
                        "url" : "type",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                              "code" : "756002005001",
                              "display" : "Retail price"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeType",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                              "code" : "756002006005",
                              "display" : "VAT-change"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeDate",
                        "valueDate" : "2024-01-01"
                      }
                    ],
                    "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
                  }
                ],
                "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/regulatedAuthorization-limitation"
              }
            ],
            "reference" : {
              "reference" : "ClinicalUseDefinition/IND-10031285"
            }
          }
        ],
        "holder" : {
          "reference" : "#holder-Sandoz-Pharmaceuticals-AG"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPManufacturedItemDefinition/MI-Estradiolum-Norethisteroni-Transdermalpatch",
      "resource" : {
        "resourceType" : "ManufacturedItemDefinition",
        "id" : "MI-Estradiolum-Norethisteroni-Transdermalpatch",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-manufactureditemdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Estradiolum-Norethisteroni-Transdermalpatch</b></p><a name=\"MI-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><a name=\"hcMI-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">CH IDMP ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10519000}\">Transdermal patch</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15036000}\">Patch</span></p></div>"
        },
        "status" : "active",
        "manufacturedDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "10519000",
              "display" : "Transdermal patch"
            }
          ]
        },
        "unitOfPresentation" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "15036000",
              "display" : "Patch"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPAdministrableProductDefinition/PhP-Estradiolum-Norethisteroni-Transdermalpatch",
      "resource" : {
        "resourceType" : "AdministrableProductDefinition",
        "id" : "PhP-Estradiolum-Norethisteroni-Transdermalpatch",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-administrableproductdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_PhP-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition PhP-Estradiolum-Norethisteroni-Transdermalpatch</b></p><a name=\"PhP-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><a name=\"hcPhP-Estradiolum-Norethisteroni-Transdermalpatch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-administrableproductdefinition.html\">CH IDMP AdministrableProductDefinition</a></p></div><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 10519000}\">Transdermal patch</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15036000}\">Patch</span></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20070000}\">Transdermal use</span></td></tr></table></div>"
        },
        "status" : "active",
        "formOf" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "administrableDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "10519000",
              "display" : "Transdermal patch"
            }
          ]
        },
        "unitOfPresentation" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "15036000",
              "display" : "Patch"
            }
          ]
        },
        "routeOfAdministration" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20070000",
                  "display" : "Transdermal use"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPClinicalUseDefinition/IND-10030247",
      "resource" : {
        "resourceType" : "ClinicalUseDefinition",
        "id" : "IND-10030247",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-clinicalusedefinition-indication"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10030247\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10030247</b></p><a name=\"IND-10030247\"> </a><a name=\"hcIND-10030247\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">CH IDMP ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10030247}\">Oestrogenmangel</span></td></tr></table><h3>Comorbidities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10027308}\">Menopause</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 200000003192}\">preventive</span></td></tr></table></blockquote></div>"
        },
        "type" : "indication",
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "indication" : {
          "diseaseSymptomProcedure" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "https://www.meddra.org",
                  "code" : "10030247",
                  "display" : "Oestrogenmangel"
                }
              ]
            }
          },
          "comorbidity" : [
            {
              "concept" : {
                "coding" : [
                  {
                    "system" : "https://www.meddra.org",
                    "code" : "10027308",
                    "display" : "Menopause"
                  }
                ]
              }
            }
          ],
          "intendedEffect" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
                  "code" : "200000003192",
                  "display" : "preventive"
                }
              ]
            }
          }
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPClinicalUseDefinition/IND-10031285",
      "resource" : {
        "resourceType" : "ClinicalUseDefinition",
        "id" : "IND-10031285",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-clinicalusedefinition-indication"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10031285\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10031285</b></p><a name=\"IND-10031285\"> </a><a name=\"hcIND-10031285\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">CH IDMP ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Estalis-Transdermalpatch.html\">MedicinalProductDefinition: extension = Transdermal patch; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001029439-5470402; indication = Klimakterische Beschwerden: Behandlung der Symptome des Östrogenmangels infolge der natürlichen oder künstlichen Menopause bei nicht-hysterektomierten Frauen.\nOsteoporoseprophylaxe: Vorbeugung oder Verzögerung einer durch Östrogenmangel induzierten Osteoporose bei postmenopausalen Frauen mit hohem Frakturrisiko, für die eine Behandlung mit anderen zur Prävention der Osteoporose zugelassenen Arzneimitteln nicht in Frage kommt, oder bei Frauen die gleichzeitig an behandlungsbedürftigen Symptomen des Östrogenmangels leiden.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Not authorised for the treatment in children; classification = norethisterone and estrogen,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10031285}\">Osteoporose postmenopausal</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 200000003192}\">preventive</span></td></tr></table></blockquote></div>"
        },
        "type" : "indication",
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Estalis-Transdermalpatch"
          }
        ],
        "indication" : {
          "diseaseSymptomProcedure" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "https://www.meddra.org",
                  "code" : "10031285",
                  "display" : "Osteoporose postmenopausal"
                }
              ]
            }
          },
          "intendedEffect" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
                  "code" : "200000003192",
                  "display" : "preventive"
                }
              ]
            }
          }
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPIngredient/Estradiol-hemihydrate-0.512mg",
      "resource" : {
        "resourceType" : "Ingredient",
        "id" : "Estradiol-hemihydrate-0.512mg",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-ingredient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Estradiol-hemihydrate-0.512mg\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Estradiol-hemihydrate-0.512mg</b></p><a name=\"Estradiol-hemihydrate-0.512mg\"> </a><a name=\"hcEstradiol-hemihydrate-0.512mg\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">IDMP Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Estradiolum-Norethisteroni-Transdermalpatch.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Transdermal patch; unitOfPresentation = Patch</a></li><li><a href=\"ManufacturedItemDefinition-MI-Estradiolum-Norethisteroni-Transdermalpatch.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Transdermal patch; unitOfPresentation = Patch</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role 756005051001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance CXY7B3Q98Z}\">Estradiol-hemihydrate</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>0.512 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Patch<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15036000 = 'Patch')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "for" : [
          {
            "reference" : "AdministrableProductDefinition/PhP-Estradiolum-Norethisteroni-Transdermalpatch"
          },
          {
            "reference" : "ManufacturedItemDefinition/MI-Estradiolum-Norethisteroni-Transdermalpatch"
          }
        ],
        "role" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role",
              "code" : "756005051001",
              "display" : "Active"
            }
          ]
        },
        "substance" : {
          "code" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance",
                  "code" : "CXY7B3Q98Z",
                  "display" : "Estradiol-hemihydrate"
                }
              ]
            }
          },
          "strength" : [
            {
              "presentationRatio" : {
                "numerator" : {
                  "value" : 0.512,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                },
                "denominator" : {
                  "value" : 1,
                  "unit" : "Patch",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15036000"
                }
              }
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPIngredient/Norethisteroni-acetas-0.496mg",
      "resource" : {
        "resourceType" : "Ingredient",
        "id" : "Norethisteroni-acetas-0.496mg",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-ingredient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Norethisteroni-acetas-0.496mg\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Norethisteroni-acetas-0.496mg</b></p><a name=\"Norethisteroni-acetas-0.496mg\"> </a><a name=\"hcNorethisteroni-acetas-0.496mg\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">IDMP Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"AdministrableProductDefinition-PhP-Estradiolum-Norethisteroni-Transdermalpatch.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Transdermal patch; unitOfPresentation = Patch</a></li><li><a href=\"ManufacturedItemDefinition-MI-Estradiolum-Norethisteroni-Transdermalpatch.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Transdermal patch; unitOfPresentation = Patch</a></li></ul><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role 756005051001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance 9S44LIC7OJ}\">Norethisterone acetate</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>0.496 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Patch<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15036000 = 'Patch')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "for" : [
          {
            "reference" : "AdministrableProductDefinition/PhP-Estradiolum-Norethisteroni-Transdermalpatch"
          },
          {
            "reference" : "ManufacturedItemDefinition/MI-Estradiolum-Norethisteroni-Transdermalpatch"
          }
        ],
        "role" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role",
              "code" : "756005051001",
              "display" : "Active"
            }
          ]
        },
        "substance" : {
          "code" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance",
                  "code" : "9S44LIC7OJ",
                  "display" : "Norethisterone acetate"
                }
              ]
            }
          },
          "strength" : [
            {
              "presentationRatio" : {
                "numerator" : {
                  "value" : 0.496,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                },
                "denominator" : {
                  "value" : 1,
                  "unit" : "Patch",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15036000"
                }
              }
            }
          ]
        }
      }
    }
  ]
}

```
