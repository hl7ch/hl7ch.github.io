# EDQM - Packaging - CH EPL (R5) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EDQM - Packaging**

## ValueSet: EDQM - Packaging 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-epl/ValueSet/edqm-packaging | *Version*:1.0.0 |
| Active as of 2025-12-11 | *Computable Name*:EdqmPackagingVS |
| *Other Identifiers:*OID:0.4.0.127.0.16.1.1.2.7 (use: official, ) | |
| **Copyright/Legal**: CC0-1.0 | |

 
Value Set for the Packaging from EDQM used by SMC 

 **References** 

* [IDMP PackagedProductDefinition](StructureDefinition-ch-idmp-packagedproductdefinition.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "edqm-packaging",
  "url" : "http://fhir.ch/ig/ch-epl/ValueSet/edqm-packaging",
  "identifier" : [
    {
      "use" : "official",
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:0.4.0.127.0.16.1.1.2.7"
    }
  ],
  "version" : "1.0.0",
  "name" : "EdqmPackagingVS",
  "title" : "EDQM - Packaging",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-11T12:29:57+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [
    {
      "name" : "Federal Office of Public Health FOPH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
        }
      ]
    }
  ],
  "description" : "Value Set for the Packaging from EDQM used by SMC",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [
      {
        "system" : "http://standardterms.edqm.eu",
        "concept" : [
          {
            "code" : "30001000",
            "display" : "Ampoule"
          },
          {
            "code" : "30002000",
            "display" : "Applicator"
          },
          {
            "code" : "30003000",
            "display" : "Automatic injection device"
          },
          {
            "code" : "30004000",
            "display" : "Bag"
          },
          {
            "code" : "30005000",
            "display" : "Balling gun"
          },
          {
            "code" : "30006000",
            "display" : "Barrel"
          },
          {
            "code" : "30007000",
            "display" : "Blister"
          },
          {
            "code" : "30008000",
            "display" : "Bottle"
          },
          {
            "code" : "30009000",
            "display" : "Box"
          },
          {
            "code" : "30010000",
            "display" : "Brush"
          },
          {
            "code" : "30011000",
            "display" : "Brush applicator"
          },
          {
            "code" : "30012000",
            "display" : "Cannula"
          },
          {
            "code" : "30013000",
            "display" : "Cap"
          },
          {
            "code" : "30014000",
            "display" : "Cartridge"
          },
          {
            "code" : "30015000",
            "display" : "Child-resistant closure"
          },
          {
            "code" : "30016000",
            "display" : "Cup"
          },
          {
            "code" : "30017000",
            "display" : "Dabbing applicator"
          },
          {
            "code" : "30018000",
            "display" : "Dart"
          },
          {
            "code" : "30019000",
            "display" : "Dredging applicator"
          },
          {
            "code" : "30020000",
            "display" : "Dredging container"
          },
          {
            "code" : "30021000",
            "display" : "Drench gun"
          },
          {
            "code" : "30022000",
            "display" : "Dropper applicator"
          },
          {
            "code" : "30023000",
            "display" : "Dropper container"
          },
          {
            "code" : "30023005",
            "display" : "Fixed cryogenic vessel"
          },
          {
            "code" : "30024000",
            "display" : "Gas cylinder"
          },
          {
            "code" : "30025000",
            "display" : "High pressure transdermal delivery device"
          },
          {
            "code" : "30026000",
            "display" : "Implanter"
          },
          {
            "code" : "30026500",
            "display" : "Inhaler"
          },
          {
            "code" : "30027000",
            "display" : "In-ovo injection device"
          },
          {
            "code" : "30028000",
            "display" : "Injection needle"
          },
          {
            "code" : "30029000",
            "display" : "Injection syringe"
          },
          {
            "code" : "30030000",
            "display" : "Internal graduated calibration chamber"
          },
          {
            "code" : "30031000",
            "display" : "Intramammary syringe"
          },
          {
            "code" : "30032000",
            "display" : "Jar"
          },
          {
            "code" : "30033000",
            "display" : "Measuring device"
          },
          {
            "code" : "30034000",
            "display" : "Measuring spoon"
          },
          {
            "code" : "30035000",
            "display" : "Metering pump"
          },
          {
            "code" : "30036000",
            "display" : "Metering valve"
          },
          {
            "code" : "30036005",
            "display" : "Mobile cryogenic vessel"
          },
          {
            "code" : "30037000",
            "display" : "Mouthpiece"
          },
          {
            "code" : "30038000",
            "display" : "Multidose container"
          },
          {
            "code" : "30039000",
            "display" : "Multidose container with airless pump"
          },
          {
            "code" : "30040000",
            "display" : "Multipuncturer"
          },
          {
            "code" : "30041000",
            "display" : "Nasal applicator"
          },
          {
            "code" : "30042000",
            "display" : "Nebuliser"
          },
          {
            "code" : "30043000",
            "display" : "Needle applicator"
          },
          {
            "code" : "30044000",
            "display" : "Nozzle"
          },
          {
            "code" : "30045000",
            "display" : "Oral syringe"
          },
          {
            "code" : "30046000",
            "display" : "Pipette"
          },
          {
            "code" : "30047000",
            "display" : "Pipette applicator"
          },
          {
            "code" : "13142000",
            "display" : "Pouch"
          },
          {
            "code" : "30048000",
            "display" : "Pour-on container"
          },
          {
            "code" : "30049000",
            "display" : "Pre-filled gastroenteral tube"
          },
          {
            "code" : "30050000",
            "display" : "Pre-filled pen"
          },
          {
            "code" : "30051000",
            "display" : "Pre-filled syringe"
          },
          {
            "code" : "30052000",
            "display" : "Pressurised container"
          },
          {
            "code" : "30053000",
            "display" : "Prick test applicator"
          },
          {
            "code" : "30054000",
            "display" : "Sachet"
          },
          {
            "code" : "30055000",
            "display" : "Scarifier"
          },
          {
            "code" : "30056000",
            "display" : "Screw cap"
          },
          {
            "code" : "30057000",
            "display" : "Single-dose container"
          },
          {
            "code" : "30058000",
            "display" : "Spatula"
          },
          {
            "code" : "30059000",
            "display" : "Spot-on applicator"
          },
          {
            "code" : "30060000",
            "display" : "Spray container"
          },
          {
            "code" : "30061000",
            "display" : "Spray pump"
          },
          {
            "code" : "30062000",
            "display" : "Spray valve"
          },
          {
            "code" : "30063000",
            "display" : "Stab vaccinator"
          },
          {
            "code" : "30064000",
            "display" : "Stopper"
          },
          {
            "code" : "30064500",
            "display" : "Straw"
          },
          {
            "code" : "30065000",
            "display" : "Strip"
          },
          {
            "code" : "30066000",
            "display" : "Tablet container"
          },
          {
            "code" : "30067000",
            "display" : "Tube"
          },
          {
            "code" : "30068000",
            "display" : "Vaginal sponge applicator"
          },
          {
            "code" : "30069000",
            "display" : "Vial"
          },
          {
            "code" : "30000500",
            "display" : "Administration system"
          },
          {
            "code" : "30011500",
            "display" : "Calendar package"
          },
          {
            "code" : "30043500",
            "display" : "Needle-free injector"
          },
          {
            "code" : "30053500",
            "display" : "Roll-on container"
          },
          {
            "code" : "30039500",
            "display" : "Multidose container with pump"
          },
          {
            "code" : "30015500",
            "display" : "Container"
          },
          {
            "code" : "30039400",
            "display" : "Multidose container with metering pump"
          },
          {
            "code" : "30045500",
            "display" : "Pack"
          },
          {
            "code" : "13070000",
            "display" : "Valve"
          },
          {
            "code" : "13072000",
            "display" : "Oral applicator"
          },
          {
            "code" : "30018200",
            "display" : "Dose dispenser"
          },
          {
            "code" : "13059000",
            "display" : "Unit-dose blister"
          },
          {
            "code" : "13063000",
            "display" : "Pre-filled injector"
          },
          {
            "code" : "13073000",
            "display" : "Pre-filled oral syringe"
          },
          {
            "code" : "13074000",
            "display" : "Pre-filled oral applicator"
          },
          {
            "code" : "30018300",
            "display" : "Dose-dispenser cartridge"
          },
          {
            "code" : "13114000",
            "display" : "Pen"
          },
          {
            "code" : "13125000",
            "display" : "Wrapper"
          },
          {
            "code" : "13132000",
            "display" : "Lid"
          },
          {
            "code" : "13131000",
            "display" : "Capsule for opening"
          },
          {
            "code" : "13151000",
            "display" : "Tablet tube"
          },
          {
            "code" : "13156000",
            "display" : "Gas cylinder bundle"
          }
        ]
      }
    ]
  }
}

```
