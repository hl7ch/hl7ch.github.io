# ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk (Bundle) - CH EPL (R5) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk (Bundle)**

## Example Bundle: ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk (Bundle)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "6722a9ee-ae3b-4c20-bcf0-9b7cb6f062db",
  "meta" : {
    "profile" : [
      "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPMedicinalProductDefinition/Entocort-Solvent-and-Tablet",
      "resource" : {
        "resourceType" : "MedicinalProductDefinition",
        "id" : "Entocort-Solvent-and-Tablet",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-medicinalproductdefinition"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Entocort-Solvent-and-Tablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Entocort-Solvent-and-Tablet</b></p><a name=\"Entocort-Solvent-and-Tablet\"> </a><a name=\"hcEntocort-Solvent-and-Tablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-medicinalproductdefinition.html\">IDMP MedicinalProductDefinition</a></p></div><p><b>CH - SMC Authorized Dose Form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50064000}\">Tablet and solvent for rectal suspension</span></p><p><b>CH - EPL Full Limitation Text</b>: Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.</p><p><b>identifier</b>: <a href=\"NamingSystem-MPID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Medical Product Identifier</a>/CH-7601001346451-5204201</p><p><b>combinedPharmaceuticalDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50064000}\">Tablet and solvent for rectal suspension</span></p><p><b>indication</b>: </p><div><p>Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.</p>\n</div><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply 756005022003}\">Medicinal product subject to medical or veterinary prescription (B)</span></p><p><b>additionalMonitoringIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-additional-monitoring-indicator 756005001003}\">No Warning</span></p><p><b>pediatricUseIndicator</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-pediatric-use-indicator 756005003001}\">Authorised for the treatment in children</span></p><p><b>classification</b>: <span title=\"Codes:{http://www.whocc.no/atc A07EA06}\">budesonide</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-category 756005021001}\">NA KAS art. 12 para. 5 TPLO</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode 756005004001}\">Synthetic</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-product-type 756001003002}\">Originator product</span>, <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-index-therapeuticus 040000}, {http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-index-therapeuticus 049900}\">04. GASTROENTEROLOGICA</span></p><p><b>attachedDocument</b>: </p><ul><li><a href=\"DocumentReference-DocRef-FI-Entocort.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-epl/sid/attno#Application / Assessment Tracking Number#123456789-initial submission-Example-efg-123; status = current; type = Fachinformation; date = 2022-04-01 00:00:00+0000</a></li><li><a href=\"DocumentReference-DocRef-PI-Entocort.html\">DocumentReference: identifier = http://fhir.ch/ig/ch-epl/sid/attno#Application / Assessment Tracking Number#123456789-initial submission-Example-efg-321; status = current; type = Patienteninformation; date = 2022-04-01 00:00:00+0000</a></li></ul><blockquote><p><b>name</b></p><p><b>productName</b>: ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-medicinal-product-name-type SMC}\">Zugelassener Arzneimittelname</span></p><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 de-CH}\">German (Switzerland)</span></td></tr></table></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/authorizedDoseForm",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "50064000",
                  "display" : "Tablet and solvent for rectal suspension"
                }
              ]
            }
          },
          {
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/fullLimitationText",
            "valueString" : "Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin."
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/mpid",
            "value" : "CH-7601001346451-5204201"
          }
        ],
        "combinedPharmaceuticalDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "50064000",
              "display" : "Tablet and solvent for rectal suspension"
            }
          ]
        },
        "indication" : "Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.",
        "legalStatusOfSupply" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply",
              "code" : "756005022003",
              "display" : "Medicinal product subject to medical or veterinary prescription (B)"
            }
          ]
        },
        "additionalMonitoringIndicator" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-additional-monitoring-indicator",
              "code" : "756005001003",
              "display" : "No Warning"
            }
          ]
        },
        "pediatricUseIndicator" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-pediatric-use-indicator",
              "code" : "756005003001",
              "display" : "Authorised for the treatment in children"
            }
          ]
        },
        "classification" : [
          {
            "coding" : [
              {
                "system" : "http://www.whocc.no/atc",
                "code" : "A07EA06"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-category",
                "code" : "756005021001",
                "display" : "NA KAS art. 12 para. 5 TPLO"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode",
                "code" : "756005004001",
                "display" : "Synthetic"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-product-type",
                "code" : "756001003002",
                "display" : "Originator product"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-index-therapeuticus",
                "code" : "040000",
                "display" : "04. GASTROENTEROLOGICA"
              },
              {
                "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-index-therapeuticus",
                "code" : "049900",
                "display" : "04.99. Varia"
              }
            ]
          }
        ],
        "attachedDocument" : [
          {
            "reference" : "DocumentReference/DocRef-FI-Entocort"
          },
          {
            "reference" : "DocumentReference/DocRef-PI-Entocort"
          }
        ],
        "name" : [
          {
            "productName" : "ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk",
            "type" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-medicinal-product-name-type",
                  "code" : "SMC",
                  "display" : "Zugelassener Arzneimittelname"
                }
              ]
            },
            "usage" : [
              {
                "country" : {
                  "coding" : [
                    {
                      "system" : "urn:iso:std:iso:3166",
                      "code" : "CH",
                      "display" : "Switzerland"
                    }
                  ]
                },
                "language" : {
                  "coding" : [
                    {
                      "system" : "urn:ietf:bcp:47",
                      "code" : "de-CH",
                      "display" : "German (Switzerland)"
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPDocumentReference/DocRef-FI-Entocort",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "DocRef-FI-Entocort",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"
          ]
        },
        "language" : "de-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"DocumentReference_DocRef-FI-Entocort\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-FI-Entocort</b></p><a name=\"DocRef-FI-Entocort\"> </a><a name=\"hcDocRef-FI-Entocort\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">CH IDMP DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456789-initial submission-Example-efg-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type 756005007001}\">Fachinformation</span></p><p><b>date</b>: 2022-04-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&amp;lang=DE&amp;authNr=52042&amp;supportMultipleResults=1\">https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&amp;lang=DE&amp;authNr=52042&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
            "value" : "123456789-initial submission-Example-efg-123"
          }
        ],
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
              "code" : "756005007001",
              "display" : "Fachinformation"
            }
          ]
        },
        "date" : "2022-04-01T00:00:00Z",
        "content" : [
          {
            "attachment" : {
              "url" : "https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&lang=DE&authNr=52042&supportMultipleResults=1"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPDocumentReference/DocRef-PI-Entocort",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "DocRef-PI-Entocort",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"
          ]
        },
        "language" : "de-CH",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"DocumentReference_DocRef-PI-Entocort\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference DocRef-PI-Entocort</b></p><a name=\"DocRef-PI-Entocort\"> </a><a name=\"hcDocRef-PI-Entocort\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-documentreference.html\">CH IDMP DocumentReference</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AttNo.html\" title=\"Temporary Namingsystem in this implementation guide until officially released by Swissmedic\">Application / Assessment Tracking Number</a>/123456789-initial submission-Example-efg-321</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type 756005007002}\">Patienteninformation</span></p><p><b>date</b>: 2022-04-01 00:00:00+0000</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&amp;lang=DE&amp;authNr=52042&amp;supportMultipleResults=1\">https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&amp;lang=DE&amp;authNr=52042&amp;supportMultipleResults=1</a></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
            "value" : "123456789-initial submission-Example-efg-321"
          }
        ],
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
              "code" : "756005007002",
              "display" : "Patienteninformation"
            }
          ]
        },
        "date" : "2022-04-01T00:00:00Z",
        "content" : [
          {
            "attachment" : {
              "url" : "https://swissmedicinfo.ch/showTextAccepted.aspx?textType=PI&lang=DE&authNr=52042&supportMultipleResults=1"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/MA-5204201",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "MA-5204201",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-regulatedauthorization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-5204201\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-5204201</b></p><a name=\"MA-5204201\"> </a><a name=\"hcMA-5204201\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">IDMP RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/5204201</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Entocort-Solvent-and-Tablet.html\">MedicinalProductDefinition: extension = Tablet and solvent for rectal suspension,Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001346451-5204201; combinedPharmaceuticalDoseForm = Tablet and solvent for rectal suspension; indication = Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Authorised for the treatment in children; classification = budesonide,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product,04. GASTROENTEROLOGICA</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status 756005023007}\">valid</span></p><p><b>statusDate</b>: 1993-06-18</p><p><b>holder</b>: <a href=\"#hcMA-5204201/holder-Tillotts-Pharma-AG\">Organization Tillotts Pharma AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-5204201/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Tillotts-Pharma-AG</b></p><a name=\"MA-5204201/holder-Tillotts-Pharma-AG\"> </a><a name=\"hcMA-5204201/holder-Tillotts-Pharma-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100005174, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001346451</p><p><b>name</b>: Tillotts Pharma AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-5204201/regulator-SMC\"> </a><a name=\"hcMA-5204201/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Tillotts-Pharma-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100005174"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001346451"
              }
            ],
            "name" : "Tillotts Pharma AG"
          },
          {
            "resourceType" : "Organization",
            "id" : "regulator-SMC",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100010911"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001398511"
              }
            ],
            "name" : "SMC"
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/authno",
            "value" : "5204201"
          }
        ],
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Entocort-Solvent-and-Tablet"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002001",
              "display" : "Marketing Authorisation"
            }
          ]
        },
        "region" : [
          {
            "coding" : [
              {
                "system" : "urn:iso:std:iso:3166",
                "code" : "CH",
                "display" : "Switzerland"
              }
            ]
          }
        ],
        "status" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status",
              "code" : "756005023007",
              "display" : "valid"
            }
          ]
        },
        "statusDate" : "1993-06-18",
        "holder" : {
          "reference" : "#holder-Tillotts-Pharma-AG"
        },
        "regulator" : {
          "reference" : "#regulator-SMC"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPPackagedProductDefinition/PMP-Entocort-Solvent-and-Tablet",
      "resource" : {
        "resourceType" : "PackagedProductDefinition",
        "id" : "PMP-Entocort-Solvent-and-Tablet",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-packagedproductdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_PMP-Entocort-Solvent-and-Tablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition PMP-Entocort-Solvent-and-Tablet</b></p><a name=\"PMP-Entocort-Solvent-and-Tablet\"> </a><a name=\"hcPMP-Entocort-Solvent-and-Tablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-packagedproductdefinition.html\">IDMP PackagedProductDefinition</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-PCID.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Clinical Product Identifier</a>/CH-7601001346451-5204201-011</p><p><b>packageFor</b>: <a href=\"MedicinalProductDefinition-Entocort-Solvent-and-Tablet.html\">MedicinalProductDefinition: extension = Tablet and solvent for rectal suspension,Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001346451-5204201; combinedPharmaceuticalDoseForm = Tablet and solvent for rectal suspension; indication = Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Authorised for the treatment in children; classification = budesonide,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product,04. GASTROENTEROLOGICA</a></p><p><b>containedItemQuantity</b>: 7 Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span>, 7 Bottle<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code30008000 = 'Bottle')</span></p><p><b>description</b>: </p><div><p>ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk</p>\n</div><h3>LegalStatusOfSupplies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply 756005022003}\">Medicinal product subject to medical or veterinary prescription (B)</span></td></tr></table><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <a href=\"NamingSystem-GTIN.html\" title=\"GS1 defines trade items as products or services that are priced, ordered or invoiced at any point in the supply chain.\">Global Trade Item Number</a>/7680520420118</p><p><b>type</b>: <span title=\"Codes:{http://standardterms.edqm.eu 30009000}\">Box</span></p><p><b>quantity</b>: 1</p><h3>ShelfLifeStorages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period[x]</b></td><td><b>SpecialPrecautionsForStorage</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/100000073343 100000073403}\">Shelf life of the medicinal product as packaged for sale</span></td><td>No display for Duration  (value: 60; unit: month; system: http://unitsofmeasure.org; code: mo)</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-special-precautions-for-storage 756005042009}\">Do not store above 30°C</span></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/pcid",
            "value" : "CH-7601001346451-5204201-011"
          }
        ],
        "packageFor" : [
          {
            "reference" : "MedicinalProductDefinition/Entocort-Solvent-and-Tablet"
          }
        ],
        "containedItemQuantity" : [
          {
            "value" : 7,
            "unit" : "Tablet",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          },
          {
            "value" : 7,
            "unit" : "Bottle",
            "system" : "http://standardterms.edqm.eu",
            "code" : "30008000"
          }
        ],
        "description" : "ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk",
        "legalStatusOfSupply" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-legal-status-of-supply",
                  "code" : "756005022003",
                  "display" : "Medicinal product subject to medical or veterinary prescription (B)"
                }
              ]
            }
          }
        ],
        "packaging" : {
          "identifier" : [
            {
              "system" : "urn:oid:2.51.1.1",
              "value" : "7680520420118"
            }
          ],
          "type" : {
            "coding" : [
              {
                "system" : "http://standardterms.edqm.eu",
                "code" : "30009000",
                "display" : "Box"
              }
            ]
          },
          "quantity" : 1,
          "shelfLifeStorage" : [
            {
              "type" : {
                "coding" : [
                  {
                    "system" : "http://spor.ema.europa.eu/v1/lists/100000073343",
                    "code" : "100000073403",
                    "display" : "Shelf life of the medicinal product as packaged for sale"
                  }
                ]
              },
              "periodDuration" : {
                "value" : 60,
                "unit" : "month",
                "system" : "http://unitsofmeasure.org",
                "code" : "mo"
              },
              "specialPrecautionsForStorage" : [
                {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-special-precautions-for-storage",
                      "code" : "756005042009",
                      "display" : "Do not store above 30°C"
                    }
                  ]
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/MA-52042011",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "MA-52042011",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-regulatedauthorization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_MA-52042011\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization MA-52042011</b></p><a name=\"MA-52042011\"> </a><a name=\"hcMA-52042011\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-regulatedauthorization.html\">IDMP RegulatedAuthorization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-AuthNo.html\" title=\"Temporary Identifier in this implementation guide until officially released by Swissmedic\">Marketing Authorisation Number</a>/52042011</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Entocort-Solvent-and-Tablet.html\">MedicinalProductDefinition: extension = Tablet and solvent for rectal suspension,Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001346451-5204201; combinedPharmaceuticalDoseForm = Tablet and solvent for rectal suspension; indication = Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Authorised for the treatment in children; classification = budesonide,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product,04. GASTROENTEROLOGICA</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002001}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 CH}\">Switzerland</span></p><p><b>status</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status 756005023007}\">valid</span></p><p><b>statusDate</b>: 1993-06-18</p><p><b>holder</b>: <a href=\"#hcMA-52042011/holder-Tillotts-Pharma-AG\">Organization Tillotts Pharma AG</a></p><p><b>regulator</b>: <a href=\"#hcMA-52042011/regulator-SMC\">Organization SMC</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Tillotts-Pharma-AG</b></p><a name=\"MA-52042011/holder-Tillotts-Pharma-AG\"> </a><a name=\"hcMA-52042011/holder-Tillotts-Pharma-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100005174, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001346451</p><p><b>name</b>: Tillotts Pharma AG</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #regulator-SMC</b></p><a name=\"MA-52042011/regulator-SMC\"> </a><a name=\"hcMA-52042011/regulator-SMC\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100010911, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001398511</p><p><b>name</b>: SMC</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Tillotts-Pharma-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100005174"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001346451"
              }
            ],
            "name" : "Tillotts Pharma AG"
          },
          {
            "resourceType" : "Organization",
            "id" : "regulator-SMC",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100010911"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001398511"
              }
            ],
            "name" : "SMC"
          }
        ],
        "identifier" : [
          {
            "system" : "http://fhir.ch/ig/ch-epl/sid/authno",
            "value" : "52042011"
          }
        ],
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Entocort-Solvent-and-Tablet"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002001",
              "display" : "Marketing Authorisation"
            }
          ]
        },
        "region" : [
          {
            "coding" : [
              {
                "system" : "urn:iso:std:iso:3166",
                "code" : "CH",
                "display" : "Switzerland"
              }
            ]
          }
        ],
        "status" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-authorisation-status",
              "code" : "756005023007",
              "display" : "valid"
            }
          ]
        },
        "statusDate" : "1993-06-18",
        "holder" : {
          "reference" : "#holder-Tillotts-Pharma-AG"
        },
        "regulator" : {
          "reference" : "#regulator-SMC"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPRegulatedAuthorisation/FOPH-17973",
      "resource" : {
        "resourceType" : "RegulatedAuthorization",
        "id" : "FOPH-17973",
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_FOPH-17973\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization FOPH-17973</b></p><a name=\"FOPH-17973\"> </a><a name=\"hcFOPH-17973\"> </a><blockquote><p><b>CH - EPL Reimbursement SL</b></p><ul><li>FOPHDossierNumber: <a href=\"NamingSystem-Dossier.html\" title=\"Identifier holding the Dossier number of FOPH\">FOPH Dossier Number</a>/17973</li><li>status: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-reimbursement-status 756001021001}\">Reimbursed</span></li><li>statusDate: 2004-02-01</li><li>listingStatus: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-listing-status 756001002001}\">Listed</span></li><li>listingPeriod: 2004-02-01 --&gt; (ongoing)</li><li>firstListingDate: 2004-02-01</li><li>costShare: 10</li><li>gamme: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-gamme 756002004005}\">Rectal Vaginal</span></li></ul></blockquote><blockquote><p><b>CH - EPL Product Price</b></p><ul><li>value: <span title=\"Swiss Franc\">CHF40.89</span> (CHF)</li><li>type: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type 756002005002}\">Ex-factory price</span></li><li>changeType: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change 756002006007}\">Price mutation after triennal review of pharmaceuticals</span></li><li>changeDate: 2023-12-01</li></ul></blockquote><blockquote><p><b>CH - EPL Product Price</b></p><ul><li>value: <span title=\"Swiss Franc\">CHF63.40</span> (CHF)</li><li>type: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type 756002005001}\">Retail price</span></li><li>changeType: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change 756002006005}\">VAT-change</span></li><li>changeDate: 2024-01-01</li></ul></blockquote><p><b>subject</b>: <a href=\"PackagedProductDefinition-PMP-Entocort-Solvent-and-Tablet.html\">PackagedProductDefinition: identifier = http://fhir.ch/ig/ch-epl/sid/pcid#Clinical Product Identifier#CH-7601001346451-5204201-011; containedItemQuantity = 7 Tablet,7 Bottle; description = ENTOCORT Enema Klistier Lösung + Tabletten 7 Stk</a></p><p><b>type</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type 756000002003}\">Reimbursement SL</span></p><h3>Indications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"ClinicalUseDefinition-IND-10009900.html\">ClinicalUseDefinition: type = indication</a></td></tr></table><p><b>holder</b>: <a href=\"#hcFOPH-17973/holder-Tillotts-Pharma-AG\">Organization Tillotts Pharma AG</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #holder-Tillotts-Pharma-AG</b></p><a name=\"FOPH-17973/holder-Tillotts-Pharma-AG\"> </a><a name=\"hcFOPH-17973/holder-Tillotts-Pharma-AG\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-epl-organization.html\">CH EPL Organization</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-LOC.html\" title=\"Identifier holding a number for LocID (Location Identifier of the European Medicines Agency - Organisation Management System OMS)\">LOC Identifier</a>/100005174, <a href=\"NamingSystem-GLN.html\" title=\"Identifier holding a number for GLN (Global Location Number)\">GLN Identifier</a>/7601001346451</p><p><b>name</b>: Tillotts Pharma AG</p></blockquote></div>"
        },
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "holder-Tillotts-Pharma-AG",
            "meta" : {
              "profile" : [
                "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-epl-organization"
              ]
            },
            "identifier" : [
              {
                "system" : "urn:oid:1.2.276.0.76",
                "value" : "100005174"
              },
              {
                "system" : "urn:oid:2.51.1.3",
                "value" : "7601001346451"
              }
            ],
            "name" : "Tillotts Pharma AG"
          }
        ],
        "extension" : [
          {
            "extension" : [
              {
                "url" : "FOPHDossierNumber",
                "valueIdentifier" : {
                  "system" : "urn:oid:2.16.756.1",
                  "value" : "17973"
                }
              },
              {
                "url" : "status",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-reimbursement-status",
                      "code" : "756001021001",
                      "display" : "Reimbursed"
                    }
                  ]
                }
              },
              {
                "url" : "statusDate",
                "valueDate" : "2004-02-01"
              },
              {
                "url" : "listingStatus",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-listing-status",
                      "code" : "756001002001",
                      "display" : "Listed"
                    }
                  ]
                }
              },
              {
                "url" : "listingPeriod",
                "valuePeriod" : {
                  "start" : "2004-02-01"
                }
              },
              {
                "url" : "firstListingDate",
                "valueDate" : "2004-02-01"
              },
              {
                "url" : "costShare",
                "valueInteger" : 10
              },
              {
                "url" : "gamme",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-gamme",
                      "code" : "756002004005",
                      "display" : "Rectal Vaginal"
                    }
                  ]
                }
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/reimbursementSL"
          },
          {
            "extension" : [
              {
                "url" : "value",
                "valueMoney" : {
                  "value" : 40.89,
                  "currency" : "CHF"
                }
              },
              {
                "url" : "type",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                      "code" : "756002005002",
                      "display" : "Ex-factory price"
                    }
                  ]
                }
              },
              {
                "url" : "changeType",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                      "code" : "756002006007",
                      "display" : "Price mutation after triennal review of pharmaceuticals"
                    }
                  ]
                }
              },
              {
                "url" : "changeDate",
                "valueDate" : "2023-12-01"
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
          },
          {
            "extension" : [
              {
                "url" : "value",
                "valueMoney" : {
                  "value" : 63.4,
                  "currency" : "CHF"
                }
              },
              {
                "url" : "type",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                      "code" : "756002005001",
                      "display" : "Retail price"
                    }
                  ]
                }
              },
              {
                "url" : "changeType",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                      "code" : "756002006005",
                      "display" : "VAT-change"
                    }
                  ]
                }
              },
              {
                "url" : "changeDate",
                "valueDate" : "2024-01-01"
              }
            ],
            "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
          }
        ],
        "subject" : [
          {
            "reference" : "PackagedProductDefinition/PMP-Entocort-Solvent-and-Tablet"
          }
        ],
        "type" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-authorisation-type",
              "code" : "756000002003",
              "display" : "Reimbursement SL"
            }
          ]
        },
        "indication" : [
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "status",
                    "valueCodeableConcept" : {
                      "coding" : [
                        {
                          "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-limitationstatus",
                          "code" : "756002071001",
                          "display" : "Limitation Reimbursed"
                        }
                      ]
                    }
                  },
                  {
                    "url" : "statusDate",
                    "valueDate" : "2007-01-01"
                  },
                  {
                    "url" : "period",
                    "valuePeriod" : {
                      "start" : "2007-01-01"
                    }
                  },
                  {
                    "url" : "firstLimitationDate",
                    "valueDate" : "2007-01-01"
                  },
                  {
                    "extension" : [
                      {
                        "url" : "value",
                        "valueMoney" : {
                          "value" : 40.89,
                          "currency" : "CHF"
                        }
                      },
                      {
                        "url" : "type",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                              "code" : "756002005002",
                              "display" : "Ex-factory price"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeType",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                              "code" : "756002006007",
                              "display" : "Price mutation after triennal review of pharmaceuticals"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeDate",
                        "valueDate" : "2023-12-01"
                      }
                    ],
                    "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
                  },
                  {
                    "extension" : [
                      {
                        "url" : "value",
                        "valueMoney" : {
                          "value" : 63.4,
                          "currency" : "CHF"
                        }
                      },
                      {
                        "url" : "type",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-price-type",
                              "code" : "756002005001",
                              "display" : "Retail price"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeType",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change",
                              "code" : "756002006005",
                              "display" : "VAT-change"
                            }
                          ]
                        }
                      },
                      {
                        "url" : "changeDate",
                        "valueDate" : "2024-01-01"
                      }
                    ],
                    "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/productPrice"
                  }
                ],
                "url" : "http://fhir.ch/ig/ch-epl/StructureDefinition/regulatedAuthorization-limitation"
              }
            ],
            "reference" : {
              "reference" : "ClinicalUseDefinition/IND-10009900"
            }
          }
        ],
        "holder" : {
          "reference" : "#holder-Tillotts-Pharma-AG"
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPManufacturedItemDefinition/MI-Budesonidum-2.3mg-Tablet",
      "resource" : {
        "resourceType" : "ManufacturedItemDefinition",
        "id" : "MI-Budesonidum-2.3mg-Tablet",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-manufactureditemdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Budesonidum-2.3mg-Tablet\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Budesonidum-2.3mg-Tablet</b></p><a name=\"MI-Budesonidum-2.3mg-Tablet\"> </a><a name=\"hcMI-Budesonidum-2.3mg-Tablet\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">CH IDMP ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 11012000}\">Tablet for rectal suspension</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15054000}\">Tablet</span></p></div>"
        },
        "status" : "active",
        "manufacturedDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "11012000",
              "display" : "Tablet for rectal suspension"
            }
          ]
        },
        "unitOfPresentation" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "15054000",
              "display" : "Tablet"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPManufacturedItemDefinition/MI-Solvent",
      "resource" : {
        "resourceType" : "ManufacturedItemDefinition",
        "id" : "MI-Solvent",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-manufactureditemdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_MI-Solvent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition MI-Solvent</b></p><a name=\"MI-Solvent\"> </a><a name=\"hcMI-Solvent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-manufactureditemdefinition.html\">CH IDMP ManufacturedItemDefinition</a></p></div><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 13035000}\">Solvent for...</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15009000}\">Bottle</span></p></div>"
        },
        "status" : "active",
        "manufacturedDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "13035000",
              "display" : "Solvent for..."
            }
          ]
        },
        "unitOfPresentation" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "15009000",
              "display" : "Bottle"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPAdministrableProductDefinition/PhP-Budesonidum-Suspension",
      "resource" : {
        "resourceType" : "AdministrableProductDefinition",
        "id" : "PhP-Budesonidum-Suspension",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-administrableproductdefinition"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_PhP-Budesonidum-Suspension\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition PhP-Budesonidum-Suspension</b></p><a name=\"PhP-Budesonidum-Suspension\"> </a><a name=\"hcPhP-Budesonidum-Suspension\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-administrableproductdefinition.html\">CH IDMP AdministrableProductDefinition</a></p></div><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-Entocort-Solvent-and-Tablet.html\">MedicinalProductDefinition: extension = Tablet and solvent for rectal suspension,Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001346451-5204201; combinedPharmaceuticalDoseForm = Tablet and solvent for rectal suspension; indication = Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Authorised for the treatment in children; classification = budesonide,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product,04. GASTROENTEROLOGICA</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{http://standardterms.edqm.eu 11006000}\">Rectal suspension</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{http://standardterms.edqm.eu 15009000}\">Bottle</span></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20061000}\">Rectal use</span></td></tr></table></div>"
        },
        "status" : "active",
        "formOf" : [
          {
            "reference" : "MedicinalProductDefinition/Entocort-Solvent-and-Tablet"
          }
        ],
        "administrableDoseForm" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "11006000",
              "display" : "Rectal suspension"
            }
          ]
        },
        "unitOfPresentation" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "15009000",
              "display" : "Bottle"
            }
          ]
        },
        "routeOfAdministration" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20061000",
                  "display" : "Rectal use"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPClinicalUseDefinition/IND-10009900",
      "resource" : {
        "resourceType" : "ClinicalUseDefinition",
        "id" : "IND-10009900",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-clinicalusedefinition-indication"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_IND-10009900\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition IND-10009900</b></p><a name=\"IND-10009900\"> </a><a name=\"hcIND-10009900\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-clinicalusedefinition-indication.html\">CH IDMP ClinicalUseDefinition Indication</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-Entocort-Solvent-and-Tablet.html\">MedicinalProductDefinition: extension = Tablet and solvent for rectal suspension,Distale Form der Colitis ulcerosa bei ungenügendem Ansprechen auf oder Kontraindikation für Mesalazin.; identifier = http://fhir.ch/ig/ch-epl/sid/mpid#Medical Product Identifier#CH-7601001346451-5204201; combinedPharmaceuticalDoseForm = Tablet and solvent for rectal suspension; indication = Leichte bis mittelschwere Colitis ulcerosa des Rectums sowie des Colon sigmoideum.; legalStatusOfSupply = Medicinal product subject to medical or veterinary prescription (B); additionalMonitoringIndicator = No Warning; pediatricUseIndicator = Authorised for the treatment in children; classification = budesonide,NA KAS art. 12 para. 5 TPLO,Synthetic,Originator product,04. GASTROENTEROLOGICA</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.meddra.org 10009900}\">Colitis ulcerative</span></td></tr></table><h3>IntendedEffects</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://spor.ema.europa.eu/v1/lists/200000003186 200000003194}\">therapeutic</span></td></tr></table></blockquote></div>"
        },
        "type" : "indication",
        "subject" : [
          {
            "reference" : "MedicinalProductDefinition/Entocort-Solvent-and-Tablet"
          }
        ],
        "indication" : {
          "diseaseSymptomProcedure" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "https://www.meddra.org",
                  "code" : "10009900",
                  "display" : "Colitis ulcerative"
                }
              ]
            }
          },
          "intendedEffect" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000003186",
                  "code" : "200000003194",
                  "display" : "therapeutic"
                }
              ]
            }
          }
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPIngredient/Budesonidum2.3",
      "resource" : {
        "resourceType" : "Ingredient",
        "id" : "Budesonidum2.3",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-ingredient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Budesonidum2.3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Budesonidum2.3</b></p><a name=\"Budesonidum2.3\"> </a><a name=\"hcBudesonidum2.3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">IDMP Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-MI-Budesonidum-2.3mg-Tablet.html\">ManufacturedItemDefinition: status = active; manufacturedDoseForm = Tablet for rectal suspension; unitOfPresentation = Tablet</a></p><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role 756005051001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance Q3OKS62Q6X}\">Budesonide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2.3 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: EDQM - Standard Terms  code15054000 = 'Tablet')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "for" : [
          {
            "reference" : "ManufacturedItemDefinition/MI-Budesonidum-2.3mg-Tablet"
          }
        ],
        "role" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role",
              "code" : "756005051001",
              "display" : "Active"
            }
          ]
        },
        "substance" : {
          "code" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance",
                  "code" : "Q3OKS62Q6X",
                  "display" : "Budesonide"
                }
              ]
            }
          },
          "strength" : [
            {
              "presentationRatio" : {
                "numerator" : {
                  "value" : 2.3,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                },
                "denominator" : {
                  "value" : 1,
                  "unit" : "Tablet",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15054000"
                }
              }
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "http://fhir.epl.bag.admin.ch/CHIDMPIngredient/Budesonidum2.0",
      "resource" : {
        "resourceType" : "Ingredient",
        "id" : "Budesonidum2.0",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-ingredient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_Budesonidum2.0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient Budesonidum2.0</b></p><a name=\"Budesonidum2.0\"> </a><a name=\"hcBudesonidum2.0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-idmp-ingredient.html\">IDMP Ingredient</a></p></div><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"AdministrableProductDefinition-PhP-Budesonidum-Suspension.html\">AdministrableProductDefinition: status = active; administrableDoseForm = Rectal suspension; unitOfPresentation = Bottle</a></p><p><b>role</b>: <span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role 756005051001}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance Q3OKS62Q6X}\">Budesonide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concentration[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/100 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "for" : [
          {
            "reference" : "AdministrableProductDefinition/PhP-Budesonidum-Suspension"
          }
        ],
        "role" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-ingredient-role",
              "code" : "756005051001",
              "display" : "Active"
            }
          ]
        },
        "substance" : {
          "code" : {
            "concept" : {
              "coding" : [
                {
                  "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-substance",
                  "code" : "Q3OKS62Q6X",
                  "display" : "Budesonide"
                }
              ]
            }
          },
          "strength" : [
            {
              "concentrationRatio" : {
                "numerator" : {
                  "value" : 2,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                },
                "denominator" : {
                  "value" : 100,
                  "unit" : "ml",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "ml"
                }
              }
            }
          ]
        }
      }
    }
  ]
}

```
