# CH SMC - Attached Document Type - CH EPL (R5) v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH SMC - Attached Document Type**

## ValueSet: CH SMC - Attached Document Type 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-epl/ValueSet/ch-SMC-attached-document-type | *Version*:1.0.1 |
| Active as of 2026-04-07 | *Computable Name*:ChSMCAttachedDocumentTypeVS |
| **Copyright/Legal**: CC0-1.0 | |

 
Value Set for the Legal Status of Supply from SMC 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-SMC-attached-document-type",
  "url" : "http://fhir.ch/ig/ch-epl/ValueSet/ch-SMC-attached-document-type",
  "version" : "1.0.1",
  "name" : "ChSMCAttachedDocumentTypeVS",
  "title" : "CH SMC - Attached Document Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-07T14:09:25+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "Value Set for the Legal Status of Supply from SMC",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type"
    }]
  }
}

```
