# CH SMC - TherapeuticProductcode - CH EPL (R5) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH SMC - TherapeuticProductcode**

## CodeSystem: CH SMC - TherapeuticProductcode 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode | *Version*:1.0.0 |
| Active as of 2025-12-11 | *Computable Name*:ChSMCTherapeuticProductcodeCS |
| **Copyright/Legal**: CC0-1.0 | |

 
CH - Standard Terms used in Switzerland (aggregations of codes of ValueSets TherapeuticProductcode) 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ChSMCTherapeuticProductcodeVS](ValueSet-ch-SMC-therapeuticproductcode.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ch-SMC-therapeuticproductcode",
  "url" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-therapeuticproductcode",
  "version" : "1.0.0",
  "name" : "ChSMCTherapeuticProductcodeCS",
  "title" : "CH SMC - TherapeuticProductcode",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-11T12:35:50+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [
    {
      "name" : "Federal Office of Public Health FOPH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
        }
      ]
    }
  ],
  "description" : "CH - Standard Terms used in Switzerland (aggregations of codes of ValueSets TherapeuticProductcode)",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 36,
  "concept" : [
    {
      "code" : "756005004001",
      "display" : "Synthetic",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Synthetika"
        }
      ]
    },
    {
      "code" : "756005004002",
      "display" : "Antidotes",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Antidota"
        }
      ]
    },
    {
      "code" : "756005004003",
      "display" : "Biologics",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Biologika"
        }
      ]
    },
    {
      "code" : "756005004004",
      "display" : "Biotechnologics",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Biotechnologika"
        }
      ]
    },
    {
      "code" : "756005004005",
      "display" : "Blood products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Blutprodukte"
        }
      ]
    },
    {
      "code" : "756005004006",
      "display" : "Vaccines",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Impfstoffe"
        }
      ]
    },
    {
      "code" : "756005004007",
      "display" : "Other immunological medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Andere immunologische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004008",
      "display" : "Allergen diagnostics",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Allergen-Diagnostika"
        }
      ]
    },
    {
      "code" : "756005004009",
      "display" : "Allergen therapeutics",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Allergen-Therapeutika"
        }
      ]
    },
    {
      "code" : "756005004010",
      "display" : "Antivenoms",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Antivenine"
        }
      ]
    },
    {
      "code" : "756005004011",
      "display" : "Radiopharmaceuticals",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Radiopharmazeutika"
        }
      ]
    },
    {
      "code" : "756005004012",
      "display" : "Phytopharmaceuticals",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Phytoarzneimittel"
        }
      ]
    },
    {
      "code" : "756005004013",
      "display" : "Medicinal bonbons",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Arzneibonbons"
        }
      ]
    },
    {
      "code" : "756005004014",
      "display" : "Homeopathic medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Homöopathische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004015",
      "display" : "Homeopathic spagyric medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Homöopathisch-spagyrische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004016",
      "display" : "Spagyric medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Spagyrische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004017",
      "display" : "Schüssler therapy medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Arzneimittel der Schüsslertherapie"
        }
      ]
    },
    {
      "code" : "756005004018",
      "display" : "Anthroposophic medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Anthroposophische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004019",
      "display" : "Chinese medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Chinesische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004020",
      "display" : "Tibetan medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Tibetische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004021",
      "display" : "Ayurvedic medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Ayurvedische Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004022",
      "display" : "Gemmotherapy medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Arzneimittel der Gemmotherapie"
        }
      ]
    },
    {
      "code" : "756005004023",
      "display" : "Other complementary medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Andere Komplementärarzneimittel"
        }
      ]
    },
    {
      "code" : "756005004024",
      "display" : "Tissue engineered products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Gewebeprodukte"
        }
      ]
    },
    {
      "code" : "756005004025",
      "display" : "Cell therapy products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Zelltherapieprodukte"
        }
      ]
    },
    {
      "code" : "756005004026",
      "display" : "Gene therapy products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Gentherapieprodukte"
        }
      ]
    },
    {
      "code" : "756005004027",
      "display" : "Nucleic acid products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Nukleinsäureprodukte"
        }
      ]
    },
    {
      "code" : "756005004028",
      "display" : "Pathogenic organisms",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Pathogene Organismen"
        }
      ]
    },
    {
      "code" : "756005004029",
      "display" : "Products containing genetically modified organisms",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Produkte mit genetisch veränderten Organismen"
        }
      ]
    },
    {
      "code" : "756005004030",
      "display" : "Exosomes",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Exosomen"
        }
      ]
    },
    {
      "code" : "756005004031",
      "display" : "Wild-type viruses/bacteriophages",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Wild type Viren/Bakteriophagen"
        }
      ]
    },
    {
      "code" : "756005004032",
      "display" : "Devit",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Devit"
        }
      ]
    },
    {
      "code" : "756005004033",
      "display" : "Blood and labile blood products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Blut und labile Blutprodukte"
        }
      ]
    },
    {
      "code" : "756005004034",
      "display" : "Non-standardisable TpP/ATMP",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Nicht standardisierbare TpP/ATMP"
        }
      ]
    },
    {
      "code" : "756005004035",
      "display" : "Non-standardisable medicinal products",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Nicht standardisierbare Arzneimittel"
        }
      ]
    },
    {
      "code" : "756005004036",
      "display" : "Preparations-Monographs",
      "designation" : [
        {
          "language" : "de",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000003001",
            "display" : "Fully specified name"
          },
          "value" : "Präparate-Monografien"
        }
      ]
    }
  ]
}

```
