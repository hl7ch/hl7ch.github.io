# Cuprior, Filmtabletten Patienteninformation - CH EPL (R5) v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cuprior, Filmtabletten Patienteninformation**

## Example DocumentReference: Cuprior, Filmtabletten Patienteninformation

Language: de-CH

Profile: [DocumentReference](StructureDefinition-ch-idmp-documentreference.md)

**identifier**: [Application / Assessment Tracking Number](NamingSystem-AttNo.md)/123456789-initial submission-Example-abc-321

**status**: Current

**type**: Patient Information

**date**: 2020-09-01 00:00:00+0000

> **content**

### Attachments

| | |
| :--- | :--- |
| - | **Url** |
| * | [https://swissmedicinfo.ch/showText.aspx?textType=PI&lang=DE&authNr=67719&supportMultipleResults=1](https://swissmedicinfo.ch/showText.aspx?textType=PI&lang=DE&authNr=67719&supportMultipleResults=1) |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "DocRef-PI-Cuprior",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"]
  },
  "language" : "de-CH",
  "identifier" : [{
    "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
    "value" : "123456789-initial submission-Example-abc-321"
  }],
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
      "code" : "756005007002",
      "display" : "Patient Information"
    }]
  },
  "date" : "2020-09-01T00:00:00Z",
  "content" : [{
    "attachment" : {
      "url" : "https://swissmedicinfo.ch/showText.aspx?textType=PI&lang=DE&authNr=67719&supportMultipleResults=1"
    }
  }]
}

```
