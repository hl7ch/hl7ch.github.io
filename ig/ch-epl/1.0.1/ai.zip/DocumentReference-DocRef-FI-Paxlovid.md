# Professional Information Paxlovid, Filmtabletten Fachinformation - CH EPL (R5) v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Professional Information Paxlovid, Filmtabletten Fachinformation**

## Example DocumentReference: Professional Information Paxlovid, Filmtabletten Fachinformation

Language: de-CH

Profile: [DocumentReference](StructureDefinition-ch-idmp-documentreference.md)

**identifier**: [Application / Assessment Tracking Number](NamingSystem-AttNo.md)/123456789-initial submission-Example-nop-123

**status**: Current

**type**: Fachinformation

**date**: 2024-07-01 00:00:00+0000

> **content**

### Attachments

| | |
| :--- | :--- |
| - | **Url** |
| * | [https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&lang=DE&authNr=68793&supportMultipleResults=1](https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&lang=DE&authNr=68793&supportMultipleResults=1) |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "DocRef-FI-Paxlovid",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-epl/StructureDefinition/ch-idmp-documentreference"]
  },
  "language" : "de-CH",
  "identifier" : [{
    "system" : "http://fhir.ch/ig/ch-epl/sid/attno",
    "value" : "123456789-initial submission-Example-nop-123"
  }],
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-SMC-attached-document-type",
      "code" : "756005007001",
      "display" : "Fachinformation"
    }]
  },
  "date" : "2024-07-01T00:00:00Z",
  "content" : [{
    "attachment" : {
      "url" : "https://swissmedicinfo.ch/showTextAccepted.aspx?textType=FI&lang=DE&authNr=68793&supportMultipleResults=1"
    }
  }]
}

```
