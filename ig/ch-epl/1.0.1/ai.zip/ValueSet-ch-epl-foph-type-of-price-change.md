# CH EPL - Type of Price Change - CH EPL (R5) v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH EPL - Type of Price Change**

## ValueSet: CH EPL - Type of Price Change 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-epl/ValueSet/ch-epl-foph-type-of-price-change | *Version*:1.0.1 |
| Active as of 2026-04-07 | *Computable Name*:ChEplTypeofPriceChangeVS |
| **Copyright/Legal**: CC0-1.0 | |

 
Value Set for TypeofPriceChange from ePL used by FOPH 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-epl-foph-type-of-price-change",
  "url" : "http://fhir.ch/ig/ch-epl/ValueSet/ch-epl-foph-type-of-price-change",
  "version" : "1.0.1",
  "name" : "ChEplTypeofPriceChangeVS",
  "title" : "CH EPL - Type of Price Change",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-07T14:04:04+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "Value Set for TypeofPriceChange from ePL used by FOPH",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://fhir.ch/ig/ch-epl/CodeSystem/ch-epl-foph-type-of-price-change"
    }]
  }
}

```
