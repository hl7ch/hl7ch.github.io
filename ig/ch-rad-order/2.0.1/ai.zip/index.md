# Home - CH RAD-Order (R4) v2.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-rad-order/ImplementationGuide/ch.fhir.ig.ch-rad-order | *Version*:2.0.1 |
| Active as of 2025-12-16 | *Computable Name*:CH_RAD_Order |
| **Copyright/Legal**: CC0-1.0 | |

### Purpose

The CH RAD-Order Implementation Guide defines the content of a radiology order and covers the following use cases:

* Referral for imaging
* Referral for radiological intervention
* Request for second Opinion
* Request for remote reporting
* Request for previous imaging results

CH RAD-Order is intended for use in directional communication as well as for the use in the SWISS EPR.

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in [npm format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](package.tgz).

### Foundation

This Implementation Guide uses FHIR defined resources. For details on HL7 FHIR R4 see [http://hl7.org/fhir/r4](http://hl7.org/fhir/r4).

Because the Implementation Guide relies heavily on the FHIR Resources Questionnaire and QuestionnaireResponse, forms are addressed here as Questionnaires.

This Implementation Guide is derived from the [CH Order & Referral by Form (CH ORF) Implementation Guide (CH ORF)](https://fhir.ch/ig/ch-orf/3.0.0/index.html) which relies on HL7 Structured Data Capture Implementation Guide, see [SDC](https://hl7.org/fhir/uv/sdc/STU3/) and uses the Swiss Core Profiles, see [CH Core](https://fhir.ch/ig/ch-core/5.0.0/index.html).

There has been a discussion whether population of the resources such as Patient Resource, ServiceRequest Resource etc. with the content of the QuestionnaireResponse Resource should be done by the order placer application or rather by the order filler application. The argument for assigning the task to the order placer is a result of the following consideration: the authors of a particular implementation guide may decide to define a questionnaire and its rendering but to leave it open if in a particular implementation the questionnaire is implemented or if the representation towards the user is made (in accordance to the questionnaire definition) by other technical means. In such a case, there would be no QuestionnaireResponse Resource in the bundle because all content is already in concerning resources. In order to handle all FHIR exchange formats equal (as far as sensible), the authors decided to mandate the order placer application with the task.

Applications claiming for conformance with the ORF Implementation Guide shall:

* Render (and in case of the Questionnaire Filler allow for data entry) all elements of a questionnaire in the user interface (e.g. on screen, in print). Grouping of items and the order of items within shall be adequately reproduced according to the questionnaire.
* In case of an implementation without the resources Questionnaire and QuestionnaireResponse, the content of otherwise implemented user interfaces shall be in accordance to the questionnaire definition.
* Be able to process all codes related to the generic elements in a Questionnaire.

Actors, transactions and safety considerations are covered in the corresponding sections of [CH ORF](https://fhir.ch/ig/ch-orf/3.0.0/index.html).

### Terminology

CH RAD-Order allows coding of the requested imaging service by means of [LOINC/RSNA RADIOL0GY PLAYBOOK](https://loinc.org/collaboration/rsna/).

Systems such as PIS and KIS may not yet support RADIOLOGY PLAYBOOK. For this reason, CH RAD-Order allows coding of the relevant dimensions by means of [RADLEX](https://www.rsna.org/practice-tools/data-tools-and-standards/radlex-radiology-lexicon).

The relevant dimensions are defined by PLAYBOOK such as:

Modality Region Focus Laterality Maneuvre Guidance for action (used for interventions)

Coding of these dimensions is done by [RADLEX terms](https://www.rsna.org/practice-tools/data-tools-and-standards/radlex-radiology-lexicon).

IMPORTANT NOTICE: Value sets, in particular those containing Radlex terms, are still experimental. Definitive value sets will be defined when CH-Rad-Order becomes operational.All coding is preliminary and not yet approved by eHealth Suisse.

#### Previous Images

Results from earlier can be provided be means of attachments or - in case of DICOM SOP Instances - by means of a DICOM Service (e.g. WADO-RS). The ImagingStudy Resource allows for indicating DICOM tags such as SOP Instance UID, Series instance UID etc. DICOM Imaging data as well as other data (pdf, jpeg etc.) can be attached by means of a document reference.

The implementation of a DICOM service requires prerequisites in terms of infrastructure and policies (e.g. access rights). CH RAD-Order does not give guidance about that.

IMPORTANT NOTICE: Questionnaire items allowing entry for DICOM tags (such as study instance ID, series instance ID etc.) are for illustration / experimental use. A real world application shall hopefully provide other means for the selection of images / reports etc.

#### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [BFS Medizinische Statistik - 21 1.3.V02 - Klasse / Classe / Classe](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-21-encountertype.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md) and [QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md)
* [BFS Medizinische Statistik - 25 1.4.V02 - Hauptkostenträger für Grundversicherungsleistungen / Prise en charge des soins de base / Unità d’imputazione principale per le prestazioni dell’assicurazione di base](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-25-mainguarantor.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md) and [Coverage/CoverageKVG](Coverage-CoverageKVG.md)
* [eCH-011 MaritalStatus](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11-maritalstatus.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md)...Show 5 more,[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRequestPrevious](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRequestPrevious.md)and[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)
* [Consent Status](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-consentstatus.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md)...Show 5 more,[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRequestPrevious](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRequestPrevious.md)and[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)
* [Coverage Identifier Type](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-coverageidentifiertype.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md) and [Coverage/CoverageKVG](Coverage-CoverageKVG.md)
* [Contains Code for UNKNOWN in dicom context](CodeSystem-ch-rad-order-dicom-unknown.md): [ChRadOrderAcquisitionModality](ValueSet-ch-rad-order-acquisition-modality.md)
* [Type of Order Detail](CodeSystem-ch-rad-order-order-detail-type.md): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderOrderDetailType](ValueSet-ch-rad-order-order-detail-type.md) and [ServiceRequest/ServiceRequestRadiologyOrder](ServiceRequest-ServiceRequestRadiologyOrder.md)
* [Requested Service](CodeSystem-ch-rad-order-requested-service.md): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderRequestedService](ValueSet-ch-rad-order-requested-service.md)...Show 9 more,[ChRadOrderServiceRequest](StructureDefinition-ch-rad-order-servicerequest.md),[ModuleQuestionnaireRadiologyOrderInstruction](Questionnaire-ch-rad-order-module-medinfo.md),[QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRequestPrevious](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRequestPrevious.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)and[ServiceRequest/ServiceRequestRadiologyOrder](ServiceRequest-ServiceRequestRadiologyOrder.md)
* [ch-ehealth-codesystem-language](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.10.12.html): [QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md)


* Copyright 2014 – The Radiological Society of North America (RSNA), all rights reserved. Licensed under RadLex License Version 2.0. You may obtain a copy of the license at: [http://www.rsna.org/radlexdownloads/](http://www.rsna.org/radlexdownloads/)This work is distributed under the above noted license on an “AS IS” basis, WITHOUT WARRANTIES OF ANY KIND, either express or implied. Please see the license for complete terms and conditions.Subject to the terms and conditions of this Agreement, Licensor hereby grants to You a worldwide, non-exclusive, no-charge, royalty-free copyright license to reproduce, prepare Adaptations of, publicly display, publicly perform, sublicense, and distribute the Work and such Adaptations in any medium.RadLex is licensed freely for commercial and non-commercial users. Review and download the license: [http://www.rsna.org/uploadedFiles/RSNA/Content/Informatics/RadLex_License_Agreement_and_Terms_of_Use_V2_Final.pdf](http://www.rsna.org/uploadedFiles/RSNA/Content/Informatics/RadLex_License_Agreement_and_Terms_of_Use_V2_Final.pdf)

* [RadLex radiology lexicon](http://terminology.hl7.org/6.5.0/CodeSystem-RadLex.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderGuidanceForAction](ValueSet-ch-rad-order-guidance-for-action.md)...Show 14 more,[ChRadOrderImagingFocus](ValueSet-ch-rad-order-imaging-focus.md),[ChRadOrderImagingRegion](ValueSet-ch-rad-order-imaging-region.md),[ChRadOrderLaterality](ValueSet-ch-rad-order-laterality.md),[ChRadOrderManeuverType](ValueSet-ch-rad-order-maneuver-type.md),[ChRadOrderModalityType](ValueSet-ch-rad-order-modality-type.md),[ChRadOrderServiceRequest](StructureDefinition-ch-rad-order-servicerequest.md),[ChRadOrderViewType](ValueSet-ch-rad-order-view-type.md),[ModuleQuestionnaireRadiologyOrderInstruction](Questionnaire-ch-rad-order-module-medinfo.md),[QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)and[ServiceRequest/ServiceRequestRadiologyOrder](ServiceRequest-ServiceRequestRadiologyOrder.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [CH_RAD_Order](index.md)...Show 32 more,[ChRadOrderAcquisitionModality](ValueSet-ch-rad-order-acquisition-modality.md),[ChRadOrderBodyHeightObservation](StructureDefinition-ch-rad-order-bodyheight-observation.md),[ChRadOrderBodyWeightObservation](StructureDefinition-ch-rad-order-bodyweight-observation.md),[ChRadOrderCaveatCondition](ValueSet-ch-rad-order-caveat-condition.md),[ChRadOrderCaveatDevice](ValueSet-ch-rad-order-caveat-device.md),[ChRadOrderCaveatType](ValueSet-ch-rad-order-caveat-type.md),[ChRadOrderComposition](StructureDefinition-ch-rad-order-composition.md),[ChRadOrderCreatinineClearanceObservation](StructureDefinition-ch-rad-order-creatinineclearance-observation.md),[ChRadOrderCreatinineObservation](StructureDefinition-ch-rad-order-creatinine-observation.md),[ChRadOrderDiagnosisCondition](StructureDefinition-ch-rad-order-diagnosis-condition.md),[ChRadOrderDicomUnknown](CodeSystem-ch-rad-order-dicom-unknown.md),[ChRadOrderDocument](StructureDefinition-ch-rad-order-document.md),[ChRadOrderGuidanceForAction](ValueSet-ch-rad-order-guidance-for-action.md),[ChRadOrderINRObservation](StructureDefinition-ch-rad-order-INR-observation.md),[ChRadOrderImagingFocus](ValueSet-ch-rad-order-imaging-focus.md),[ChRadOrderImagingRegion](ValueSet-ch-rad-order-imaging-region.md),[ChRadOrderImagingStudy](StructureDefinition-ch-rad-order-imagingstudy.md),[ChRadOrderLaterality](ValueSet-ch-rad-order-laterality.md),[ChRadOrderManeuverType](ValueSet-ch-rad-order-maneuver-type.md),[ChRadOrderModalityType](ValueSet-ch-rad-order-modality-type.md),[ChRadOrderOrderDetailType](ValueSet-ch-rad-order-order-detail-type.md),[ChRadOrderPlateletsObservation](StructureDefinition-ch-rad-order-platelets-observation.md),[ChRadOrderQualifierValue](ValueSet-ch-rad-order-caveat-qualifier-value.md),[ChRadOrderRequestedService](ValueSet-ch-rad-order-requested-service.md),[ChRadOrderServiceRequest](StructureDefinition-ch-rad-order-servicerequest.md),[ChRadOrderViewType](ValueSet-ch-rad-order-view-type.md),[ModuleQuestionnaireRadiologyOrderCaveats](Questionnaire-ch-rad-order-module-caveats.md),[ModuleQuestionnaireRadiologyOrderDiagnosis](Questionnaire-ch-rad-order-module-diagnosis.md),[ModuleQuestionnaireRadiologyOrderInstruction](Questionnaire-ch-rad-order-module-medinfo.md),[ModuleQuestionnaireRadiologyOrderPreviousResults](Questionnaire-ch-rad-order-module-previousresults.md),[QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md)and[RadOrderQrToBundle](StructureMap-RadOrderQrToBundle.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [Observation/BodyHeight](Observation-BodyHeight.md)...Show 9 more,[Observation/BodyWeight](Observation-BodyWeight.md),[Observation/CaveatBloodCoagulationINR](Observation-CaveatBloodCoagulationINR.md),[Observation/CaveatBloodCoagulationPlatelets](Observation-CaveatBloodCoagulationPlatelets.md),[Observation/CaveatRenalInsufficiencyCreatinine](Observation-CaveatRenalInsufficiencyCreatinine.md),[Observation/CaveatRenalInsufficiencyCreatinineClearance](Observation-CaveatRenalInsufficiencyCreatinineClearance.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md)and[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderComposition](StructureDefinition-ch-rad-order-composition.md)...Show 12 more,[ChRadOrderCreatinineClearanceObservation](StructureDefinition-ch-rad-order-creatinineclearance-observation.md),[ChRadOrderCreatinineObservation](StructureDefinition-ch-rad-order-creatinine-observation.md),[ChRadOrderINRObservation](StructureDefinition-ch-rad-order-INR-observation.md),[ChRadOrderPlateletsObservation](StructureDefinition-ch-rad-order-platelets-observation.md),[ChRadOrderServiceRequest](StructureDefinition-ch-rad-order-servicerequest.md),[Composition/CompositionRadiologyOrderImagingRequest](Composition-CompositionRadiologyOrderImagingRequest.md),[Observation/BodyHeight](Observation-BodyHeight.md),[Observation/BodyWeight](Observation-BodyWeight.md),[Observation/CaveatBloodCoagulationINR](Observation-CaveatBloodCoagulationINR.md),[Observation/CaveatBloodCoagulationPlatelets](Observation-CaveatBloodCoagulationPlatelets.md),[Observation/CaveatRenalInsufficiencyCreatinine](Observation-CaveatRenalInsufficiencyCreatinine.md)and[Observation/CaveatRenalInsufficiencyCreatinineClearance](Observation-CaveatRenalInsufficiencyCreatinineClearance.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderCaveatCondition](ValueSet-ch-rad-order-caveat-condition.md)...Show 16 more,[ChRadOrderCaveatDevice](ValueSet-ch-rad-order-caveat-device.md),[ChRadOrderCaveatType](ValueSet-ch-rad-order-caveat-type.md),[ChRadOrderComposition](StructureDefinition-ch-rad-order-composition.md),[ChRadOrderQualifierValue](ValueSet-ch-rad-order-caveat-qualifier-value.md),[Composition/CompositionRadiologyOrderImagingRequest](Composition-CompositionRadiologyOrderImagingRequest.md),[Condition/CaveatBloodCoagulation](Condition-CaveatBloodCoagulation.md),[Condition/CaveatBodyPiercing](Condition-CaveatBodyPiercing.md),[Condition/CaveatDeviceCardiacPacemaker](Condition-CaveatDeviceCardiacPacemaker.md),[Condition/CaveatDrugPrescriptionMetformin](Condition-CaveatDrugPrescriptionMetformin.md),[Condition/CaveatRenalInsufficiency](Condition-CaveatRenalInsufficiency.md),[ModuleQuestionnaireRadiologyOrderCaveats](Questionnaire-ch-rad-order-module-caveats.md),[QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md),[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderRemoteReporting](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderRemoteReporting.md)and[QuestionnaireResponse/QuestionnaireResponseRadiologyOrderSecondOpinion](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderSecondOpinion.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-category.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderCaveatCondition](StructureDefinition-ch-rad-order-caveat-condition.md)...Show 9 more,[ChRadOrderDiagnosisCondition](StructureDefinition-ch-rad-order-diagnosis-condition.md),[Condition/CaveatBloodCoagulation](Condition-CaveatBloodCoagulation.md),[Condition/CaveatBodyPiercing](Condition-CaveatBodyPiercing.md),[Condition/CaveatDeviceCardiacPacemaker](Condition-CaveatDeviceCardiacPacemaker.md),[Condition/CaveatDrugPrescriptionMetformin](Condition-CaveatDrugPrescriptionMetformin.md),[Condition/CaveatRenalInsufficiency](Condition-CaveatRenalInsufficiency.md),[Condition/PrimaryDiagnosis](Condition-PrimaryDiagnosis.md),[Condition/SecondaryDiagnosis1](Condition-SecondaryDiagnosis1.md)and[Condition/SecondaryDiagnosis2](Condition-SecondaryDiagnosis2.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-clinical.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [Condition/CaveatBloodCoagulation](Condition-CaveatBloodCoagulation.md)...Show 7 more,[Condition/CaveatBodyPiercing](Condition-CaveatBodyPiercing.md),[Condition/CaveatDeviceCardiacPacemaker](Condition-CaveatDeviceCardiacPacemaker.md),[Condition/CaveatDrugPrescriptionMetformin](Condition-CaveatDrugPrescriptionMetformin.md),[Condition/CaveatRenalInsufficiency](Condition-CaveatRenalInsufficiency.md),[Condition/PrimaryDiagnosis](Condition-PrimaryDiagnosis.md),[Condition/SecondaryDiagnosis1](Condition-SecondaryDiagnosis1.md)and[Condition/SecondaryDiagnosis2](Condition-SecondaryDiagnosis2.md)
* [Observation Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-observation-category.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [Observation/BodyHeight](Observation-BodyHeight.md) and [Observation/BodyWeight](Observation-BodyWeight.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [ChRadOrderImagingStudy](StructureDefinition-ch-rad-order-imagingstudy.md), [ChRadOrderServiceRequest](StructureDefinition-ch-rad-order-servicerequest.md), [ImagingStudy/DicomSopInstanceConformant](ImagingStudy-DicomSopInstanceConformant.md) and [ServiceRequest/ServiceRequestRadiologyOrder](ServiceRequest-ServiceRequestRadiologyOrder.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [Bundle/DocumentRadiologyOrder](Bundle-DocumentRadiologyOrder.md), [QuestionnaireRadiologyOrder](Questionnaire-QuestionnaireRadiologyOrder.md), [QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagIntervent](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagIntervent.md) and [QuestionnaireResponse/QuestionnaireResponseRadiologyOrderImagingRequest](QuestionnaireResponse-QuestionnaireResponseRadiologyOrderImagingRequest.md)


#### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-rad-order.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-rad-order.r4b)](package.r4b.tgz) are available.

#### Dependency Table







#### Globals Table

*There are no Global profiles defined*

