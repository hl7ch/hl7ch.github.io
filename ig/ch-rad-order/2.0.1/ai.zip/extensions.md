# Extensions - CH RAD-Order (R4) v2.0.1

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

* [CH RAD-Order Caveat Type](StructureDefinition-ch-rad-order-caveat-type.md) 
Extension to define the type of caveat in the context CH RAD-Order. 

* [CH RAD-Order Order Detail Type](StructureDefinition-ch-rad-order-order-detail-type.md) 
Extension to define the Type of Order Detail in context of CH RAD-Order. 

* [CH RAD-Order Qualifier Value](StructureDefinition-ch-rad-order-qualifier-value.md) 
Extension to define the value of the qualifier in the context of CH RAD-Order. 

