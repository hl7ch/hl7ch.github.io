# 2-6 PDF as original representation of the Medication Prescription document - CH EMED (R4) v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **2-6 PDF as original representation of the Medication Prescription document**

## Example Binary: 2-6 PDF as original representation of the Medication Prescription document

[The Content Type 'application/pdf' is not rendered in this context]



## Resource Binary Content

application/pdf:

```
{snip}
```
