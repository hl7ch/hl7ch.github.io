# 2-7 PDF as original representation of the Medication Card document - CH EMED (R4) v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **2-7 PDF as original representation of the Medication Card document**

## Example Binary: 2-7 PDF as original representation of the Medication Card document

[The Content Type 'application/pdf' is not rendered in this context]



## Resource Binary Content

application/pdf:

```
{snip}
```
