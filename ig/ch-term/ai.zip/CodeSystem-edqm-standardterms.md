# EDQM - Standard Terms - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EDQM - Standard Terms**

## CodeSystem: EDQM - Standard Terms 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:0.4.0.127.0.16.1.1.2.1 | *Version*:3.3.0 |
| Active as of 2025-12-15 | *Computable Name*:EdqmStandardTerms |
| **Copyright/Legal**: CC0-1.0 | |

 
EDQM - Standard Terms used in Switzerland (aggregations of codes of ValueSets Route of Administration, Dose Form and Administration Method, see original codes system defined in https://standardterms.edqm.eu/#) 

 This Code system is referenced in the content logical definition of the following value sets: 

* [AdministrationMethodEDQM](ValueSet-edqm-administrationmethod.md)
* [PharmaceuticalDoseFormEDQM](ValueSet-edqm-pharmaceuticaldoseform.md)
* [RouteOfAdministrationEDQM](ValueSet-edqm-routeofadministration.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "edqm-standardterms",
  "meta" : {
    "source" : "https://art-decor.org/fhir/ValueSet/2.16.756.5.30.1.1.11.3--20230125080429"
  },
  "url" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
  "version" : "3.3.0",
  "name" : "EdqmStandardTerms",
  "title" : "EDQM - Standard Terms",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-15T10:47:47+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/"
        }
      ]
    },
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "EDQM - Standard Terms used in Switzerland (aggregations of codes of ValueSets Route of Administration, Dose Form and Administration Method, see original codes system defined in https://standardterms.edqm.eu/#)",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "caseSensitive" : false,
  "content" : "fragment",
  "concept" : [
    {
      "code" : "10100500",
      "display" : "Concentrate for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension à diluer pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10101000",
      "display" : "Oral drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tropfen zum Einnehmen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution buvable en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Tropfen zum Einnehmen, Lösung"
        }
      ]
    },
    {
      "code" : "10102000",
      "display" : "Oral drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tropfen zum Einnehmen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension buvable en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Tropfen zum Einnehmen, Suspension"
        }
      ]
    },
    {
      "code" : "10103000",
      "display" : "Oral drops, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tropfen zum Einnehmen, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion buvable en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Tropfen zum Einnehmen, Emulsion"
        }
      ]
    },
    {
      "code" : "10104000",
      "display" : "Oral liquid",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Flüssigkeit zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Liquide oral"
        },
        {
          "language" : "it-CH",
          "value" : "Liquido orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Flüssigkeit zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10105000",
      "display" : "Oral solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution  buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10106000",
      "display" : "Oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10107000",
      "display" : "Oral emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10108000",
      "display" : "Oral gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel oral"
        },
        {
          "language" : "it-CH",
          "value" : "Gel orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10109000",
      "display" : "Oral paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Paste zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte orale"
        },
        {
          "language" : "it-CH",
          "value" : "Pasta per uso orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Paste zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10110000",
      "display" : "Powder for oral solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10111000",
      "display" : "Powder for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10112000",
      "display" : "Granules for oral solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Lösung zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour solution buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per soluzione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Lösung zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10113000",
      "display" : "Granules for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10117000",
      "display" : "Syrup",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sirup"
        },
        {
          "language" : "fr-CH",
          "value" : "Sirop"
        },
        {
          "language" : "it-CH",
          "value" : "Sciroppo"
        },
        {
          "language" : "rm-CH",
          "value" : "Sirup"
        }
      ]
    },
    {
      "code" : "10118000",
      "display" : "Powder for syrup",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Sirups"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour sirop"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sciroppo"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Sirups"
        }
      ]
    },
    {
      "code" : "10119000",
      "display" : "Granules for syrup",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung eines Sirups"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour sirop"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per sciroppo"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung eines Sirups"
        }
      ]
    },
    {
      "code" : "10120000",
      "display" : "Soluble tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Lösung zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa solubile"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Lösung zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10121000",
      "display" : "Dispersible tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé dispersible"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa dispersibile"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10121500",
      "display" : "Dispersible tablets for dose dispenser",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen für ein Dosiergerät"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimés dispersibles pour dispensateur de dose"
        },
        {
          "language" : "it-CH",
          "value" : "Compresse dispersibili per dispensatore di dose"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen für ein Dosiergerät"
        }
      ]
    },
    {
      "code" : "10122000",
      "display" : "Herbal tea",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Arzneitee"
        },
        {
          "language" : "fr-CH",
          "value" : "Plante(s) pour tisane"
        },
        {
          "language" : "it-CH",
          "value" : "Tisana"
        },
        {
          "language" : "rm-CH",
          "value" : "Arzneitee"
        }
      ]
    },
    {
      "code" : "10201000",
      "display" : "Oral powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre orale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10202000",
      "display" : "Instant herbal tea",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Teeaufgusspulver"
        },
        {
          "language" : "fr-CH",
          "value" : "Préparation instantanée pour tisane"
        },
        {
          "language" : "it-CH",
          "value" : "Tisana, polvere solubile"
        },
        {
          "language" : "rm-CH",
          "value" : "Teeaufgusspulver"
        }
      ]
    },
    {
      "code" : "10203000",
      "display" : "Effervescent powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brausepulver"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre effervescente"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere effervescente"
        },
        {
          "language" : "rm-CH",
          "value" : "Brausepulver"
        }
      ]
    },
    {
      "code" : "10204000",
      "display" : "Granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat"
        }
      ]
    },
    {
      "code" : "10205000",
      "display" : "Effervescent granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brausegranulat"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés effervescents"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato effervescente"
        },
        {
          "language" : "rm-CH",
          "value" : "Brausegranulat"
        }
      ]
    },
    {
      "code" : "10206000",
      "display" : "Gastro-resistant granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "magensaftresistentes Granulat"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés gastrorésistants"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato gastroresistente"
        },
        {
          "language" : "rm-CH",
          "value" : "magensaftresistentes Granulat"
        }
      ]
    },
    {
      "code" : "10207000",
      "display" : "Prolonged-release granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Retardgranulat"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Retardgranulat"
        }
      ]
    },
    {
      "code" : "10208000",
      "display" : "Modified-release granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat mit veränderter Wirkstofffreisetzung"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés à libération modifiée"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato a rilascio modificato"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat mit veränderter Wirkstofffreisetzung"
        }
      ]
    },
    {
      "code" : "10209000",
      "display" : "Cachet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Oblatenkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Cachet"
        },
        {
          "language" : "it-CH",
          "value" : "Cachet"
        },
        {
          "language" : "rm-CH",
          "value" : "Oblatenkapsel"
        }
      ]
    },
    {
      "code" : "10210000",
      "display" : "Capsule, hard",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hartkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gélule"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rigida"
        },
        {
          "language" : "rm-CH",
          "value" : "Hartkapsel"
        }
      ]
    },
    {
      "code" : "10211000",
      "display" : "Capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Weichkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle"
        },
        {
          "language" : "rm-CH",
          "value" : "Weichkapsel"
        }
      ]
    },
    {
      "code" : "10212000",
      "display" : "Gastro-resistant capsule, hard",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "magensaftresistente Hartkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gélule gastrorésistante"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rigida gastroresistente"
        },
        {
          "language" : "rm-CH",
          "value" : "magensaftresistente Hartkapsel"
        }
      ]
    },
    {
      "code" : "10213000",
      "display" : "Gastro-resistant capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "magensaftresistente Weichkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle gastrorésistante"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle gastroresistente"
        },
        {
          "language" : "rm-CH",
          "value" : "magensaftresistente Weichkapsel"
        }
      ]
    },
    {
      "code" : "10214000",
      "display" : "Chewable capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Weichkapsel zum Zerbeißen"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle à mâcher"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle masticabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Weichkapsel zum Zerbeißen"
        }
      ]
    },
    {
      "code" : "10215000",
      "display" : "Prolonged-release capsule, hard",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hartkapsel, retardiert"
        },
        {
          "language" : "fr-CH",
          "value" : "Gélule à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rigida a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Hartkapsel, retardiert"
        }
      ]
    },
    {
      "code" : "10216000",
      "display" : "Prolonged-release capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Weichkapsel, retardiert"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Weichkapsel, retardiert"
        }
      ]
    },
    {
      "code" : "10217000",
      "display" : "Modified-release capsule, hard",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hartkapsel mit veränderter Wirkstofffreisetzung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gélule à libération modifiée"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rigida a rilascio modificato"
        },
        {
          "language" : "rm-CH",
          "value" : "Hartkapsel mit veränderter Wirkstofffreisetzung"
        }
      ]
    },
    {
      "code" : "10218000",
      "display" : "Modified-release capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Weichkapsel mit veränderter Wirkstofffreisetzung"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle à libération modifiée"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle a rilascio modificato"
        },
        {
          "language" : "rm-CH",
          "value" : "Weichkapsel mit veränderter Wirkstofffreisetzung"
        }
      ]
    },
    {
      "code" : "10219000",
      "display" : "Tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette"
        }
      ]
    },
    {
      "code" : "10220000",
      "display" : "Coated tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "überzogene Tablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé enrobé"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa rivestita"
        },
        {
          "language" : "rm-CH",
          "value" : "überzogene Tablette"
        }
      ]
    },
    {
      "code" : "10221000",
      "display" : "Film-coated tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Filmtablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pelliculé"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa rivestita con film"
        },
        {
          "language" : "rm-CH",
          "value" : "Filmtablette"
        }
      ]
    },
    {
      "code" : "10222000",
      "display" : "Effervescent tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brausetablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé effervescent"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa effervescente"
        },
        {
          "language" : "rm-CH",
          "value" : "Brausetablette"
        }
      ]
    },
    {
      "code" : "10223000",
      "display" : "Orodispersible tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schmelztablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé orodispersible"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa orodispersibile"
        },
        {
          "language" : "rm-CH",
          "value" : "Schmelztablette"
        }
      ]
    },
    {
      "code" : "10224000",
      "display" : "Oral lyophilisate",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lyophilisat zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Lyophilisat oral"
        },
        {
          "language" : "it-CH",
          "value" : "Liofilizzato orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lyophilisat zum Einnehmen"
        }
      ]
    },
    {
      "code" : "10225000",
      "display" : "Gastro-resistant tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "magensaftresistente Tablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé gastrorésistant"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa gastroresistente"
        },
        {
          "language" : "rm-CH",
          "value" : "magensaftresistente Tablette"
        }
      ]
    },
    {
      "code" : "10226000",
      "display" : "Prolonged-release tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Retardtablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Retardtablette"
        }
      ]
    },
    {
      "code" : "10227000",
      "display" : "Modified-release tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette mit veränderter Wirkstofffreisetzung"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé à libération modifiée"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa a rilascio modificato"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette mit veränderter Wirkstofffreisetzung"
        }
      ]
    },
    {
      "code" : "10228000",
      "display" : "Chewable tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kautablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé à croquer"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa masticabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Kautablette"
        }
      ]
    },
    {
      "code" : "10229000",
      "display" : "Medicated chewing-gum",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "wirkstoffhaltiges Kaugummi"
        },
        {
          "language" : "fr-CH",
          "value" : "Gomme à mâcher médicamenteuse"
        },
        {
          "language" : "it-CH",
          "value" : "Gomma da masticare medicata"
        },
        {
          "language" : "rm-CH",
          "value" : "wirkstoffhaltiges Kaugummi"
        }
      ]
    },
    {
      "code" : "10230000",
      "display" : "Oral gum",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lutschpastille"
        },
        {
          "language" : "fr-CH",
          "value" : "Gomme orale"
        },
        {
          "language" : "it-CH",
          "value" : "Pastiglia gommosa"
        },
        {
          "language" : "rm-CH",
          "value" : "Lutschpastille"
        }
      ]
    },
    {
      "code" : "10231000",
      "display" : "Pillules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Streukügelchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granules"
        },
        {
          "language" : "it-CH",
          "value" : "Granuli"
        },
        {
          "language" : "rm-CH",
          "value" : "Streukügelchen"
        }
      ]
    },
    {
      "code" : "10236100",
      "display" : "Orodispersible film",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schmelzfilm"
        },
        {
          "language" : "fr-CH",
          "value" : "Film orodispersible"
        },
        {
          "language" : "it-CH",
          "value" : "Film orodispersibile"
        },
        {
          "language" : "rm-CH",
          "value" : "Schmelzfilm"
        }
      ]
    },
    {
      "code" : "10301000",
      "display" : "Gargle",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gurgellösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour gargarisme"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per gargarismi"
        },
        {
          "language" : "rm-CH",
          "value" : "Gurgellösung"
        }
      ]
    },
    {
      "code" : "10302000",
      "display" : "Concentrate for gargle",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Gurgellösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour gargarisme"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per gargarismi"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Gurgellösung"
        }
      ]
    },
    {
      "code" : "10303000",
      "display" : "Gargle, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Gurgellösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour gargarisme"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per gargarismi"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Gurgellösung"
        }
      ]
    },
    {
      "code" : "10304000",
      "display" : "Gargle, tablet for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Gurgellösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution pour gargarisme"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per soluzione per gargarismi"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Gurgellösung"
        }
      ]
    },
    {
      "code" : "10305000",
      "display" : "Oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10306000",
      "display" : "Oromucosal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10307000",
      "display" : "Oromucosal drops",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tropfen zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution buccale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Tropfen zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10308100",
      "display" : "Oromucosal spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour pulvérisation buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray per mucosa orale, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Emulsion"
        }
      ]
    },
    {
      "code" : "10308200",
      "display" : "Oromucosal spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray per mucosa orale, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Lösung"
        }
      ]
    },
    {
      "code" : "10308300",
      "display" : "Oromucosal spray, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour pulvérisation buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray per mucosa orale, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung in der Mundhöhle, Suspension"
        }
      ]
    },
    {
      "code" : "10309100",
      "display" : "Sublingual spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sublingualspray, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour pulvérisation sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray sublinguale, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Sublingualspray, Emulsion"
        }
      ]
    },
    {
      "code" : "10309200",
      "display" : "Sublingual spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sublingualspray, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray sublinguale, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Sublingualspray, Lösung"
        }
      ]
    },
    {
      "code" : "10309300",
      "display" : "Sublingual spray, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sublingualspray, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour pulvérisation sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray sublinguale, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Sublingualspray, Suspension"
        }
      ]
    },
    {
      "code" : "10310000",
      "display" : "Mouthwash",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Mundspülung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour bain de bouche"
        },
        {
          "language" : "it-CH",
          "value" : "Collutorio"
        },
        {
          "language" : "rm-CH",
          "value" : "Mundspülung"
        }
      ]
    },
    {
      "code" : "10311000",
      "display" : "Mouthwash, tablet for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Mundspülung"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution pour bain de bouche"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per soluzione per collutorio"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Mundspülung"
        }
      ]
    },
    {
      "code" : "10312000",
      "display" : "Gingival solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung am Zahnfleisch"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution gingivale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung am Zahnfleisch"
        }
      ]
    },
    {
      "code" : "10313000",
      "display" : "Oromucosal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel buccal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10314000",
      "display" : "Oromucosal paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Paste zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Pasta per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Paste zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10314005",
      "display" : "Oromucosal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Salbe zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Salbe zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10314010",
      "display" : "Oromucosal cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Creme zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "crème buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Crema per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Creme zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10314011",
      "display" : "Buccal film",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Buccalfilm"
        },
        {
          "language" : "fr-CH",
          "value" : "Film buccogingival"
        },
        {
          "language" : "it-CH",
          "value" : "Film orosolubile"
        },
        {
          "language" : "rm-CH",
          "value" : "Buccalfilm"
        }
      ]
    },
    {
      "code" : "10315000",
      "display" : "Gingival gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur Anwendung am Zahnfleisch"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel gingival"
        },
        {
          "language" : "it-CH",
          "value" : "Gel gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur Anwendung am Zahnfleisch"
        }
      ]
    },
    {
      "code" : "10316000",
      "display" : "Gingival paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Paste zur Anwendung am Zahnfleisch"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte gingivale"
        },
        {
          "language" : "it-CH",
          "value" : "Pasta gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Paste zur Anwendung am Zahnfleisch"
        }
      ]
    },
    {
      "code" : "10317000",
      "display" : "Oromucosal capsule",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kapsel zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Kapsel zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "10317500",
      "display" : "Sublingual film",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schmelzfilm zur sublingualen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Film sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Film sublinguale"
        },
        {
          "language" : "rm-CH",
          "value" : "Schmelzfilm zur sublingualen Anwendung"
        }
      ]
    },
    {
      "code" : "10318000",
      "display" : "Sublingual tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sublingualtablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé sublingual"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa sublinguale"
        },
        {
          "language" : "rm-CH",
          "value" : "Sublingualtablette"
        }
      ]
    },
    {
      "code" : "10319000",
      "display" : "Muco-adhesive buccal tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "mucoadhäsive Buccaltablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé buccogingival muco-adhésif"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa buccale mucoadesiva"
        },
        {
          "language" : "rm-CH",
          "value" : "mucoadhäsive Buccaltablette"
        }
      ]
    },
    {
      "code" : "10320000",
      "display" : "Buccal tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Buccaltablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé buccogingival"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa orosolubile"
        },
        {
          "language" : "rm-CH",
          "value" : "Buccaltablette"
        }
      ]
    },
    {
      "code" : "10321000",
      "display" : "Lozenge",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lutschtablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Pastille"
        },
        {
          "language" : "it-CH",
          "value" : "Pastiglia"
        },
        {
          "language" : "rm-CH",
          "value" : "Lutschtablette"
        }
      ]
    },
    {
      "code" : "10322000",
      "display" : "Compressed lozenge",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lutschtablette, gepresst"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé à sucer"
        },
        {
          "language" : "it-CH",
          "value" : "Pastiglia"
        },
        {
          "language" : "rm-CH",
          "value" : "Lutschtablette, gepresst"
        }
      ]
    },
    {
      "code" : "10323000",
      "display" : "Pastille",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pastille"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte à sucer"
        },
        {
          "language" : "it-CH",
          "value" : "Pastiglia molle"
        },
        {
          "language" : "rm-CH",
          "value" : "Pastille"
        }
      ]
    },
    {
      "code" : "10401000",
      "display" : "Periodontal powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur periodontalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre péridontale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur periodontalen Anwendung"
        }
      ]
    },
    {
      "code" : "10401500",
      "display" : "Dental cement",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalzement"
        },
        {
          "language" : "fr-CH",
          "value" : "Ciment dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalzement"
        }
      ]
    },
    {
      "code" : "10402000",
      "display" : "Dental gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalgel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Gel dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalgel"
        }
      ]
    },
    {
      "code" : "10403000",
      "display" : "Dental stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalstift"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Bastoncino dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalstift"
        }
      ]
    },
    {
      "code" : "10405000",
      "display" : "Dental powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalpulver"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalpulver"
        }
      ]
    },
    {
      "code" : "10406000",
      "display" : "Dental solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentallösung"
        }
      ]
    },
    {
      "code" : "10407000",
      "display" : "Dental suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalsuspension"
        }
      ]
    },
    {
      "code" : "10408000",
      "display" : "Dental emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalemulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalemulsion"
        }
      ]
    },
    {
      "code" : "10409000",
      "display" : "Toothpaste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Zahnpaste"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte dentifrice"
        },
        {
          "language" : "it-CH",
          "value" : "Pasta dentifricia"
        },
        {
          "language" : "rm-CH",
          "value" : "Zahnpaste"
        }
      ]
    },
    {
      "code" : "10410000",
      "display" : "Periodontal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur periodontalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel périodontal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur periodontalen Anwendung"
        }
      ]
    },
    {
      "code" : "10411000",
      "display" : "Periodontal insert",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Insert zur periodontalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Insert périodontal"
        },
        {
          "language" : "it-CH",
          "value" : "Inserto periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Insert zur periodontalen Anwendung"
        }
      ]
    },
    {
      "code" : "10413000",
      "display" : "Powder for dental cement",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Dentalzements"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour ciment dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Inserto periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Dentalzements"
        }
      ]
    },
    {
      "code" : "10414000",
      "display" : "Solution for dental cement",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Herstellung eines Dentalzements"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour ciment dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Inserto periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Herstellung eines Dentalzements"
        }
      ]
    },
    {
      "code" : "10501000",
      "display" : "Bath additive",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Badezusatz"
        },
        {
          "language" : "fr-CH",
          "value" : "Adjuvant de bain"
        },
        {
          "language" : "it-CH",
          "value" : "Additivo per bagno"
        },
        {
          "language" : "rm-CH",
          "value" : "Badezusatz"
        }
      ]
    },
    {
      "code" : "10502000",
      "display" : "Cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Creme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème"
        },
        {
          "language" : "it-CH",
          "value" : "Crema"
        },
        {
          "language" : "rm-CH",
          "value" : "Creme"
        }
      ]
    },
    {
      "code" : "10503000",
      "display" : "Gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel"
        },
        {
          "language" : "it-CH",
          "value" : "Gel"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel"
        }
      ]
    },
    {
      "code" : "10504000",
      "display" : "Ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Salbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento"
        },
        {
          "language" : "rm-CH",
          "value" : "Salbe"
        }
      ]
    },
    {
      "code" : "10505000",
      "display" : "Cutaneous paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Paste zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Pasta cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Paste zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10506000",
      "display" : "Medicated plaster",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "wirkstoffhaltiges Pflaster"
        },
        {
          "language" : "fr-CH",
          "value" : "Emplâtre médicamenteux"
        },
        {
          "language" : "it-CH",
          "value" : "Cerotto medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "wirkstoffhaltiges Pflaster"
        }
      ]
    },
    {
      "code" : "10507000",
      "display" : "Cutaneous foam",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schaum zur  Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Mousse cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Schiuma cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Schaum zur  Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10508000",
      "display" : "Shampoo",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Shampoo"
        },
        {
          "language" : "fr-CH",
          "value" : "Shampoing"
        },
        {
          "language" : "it-CH",
          "value" : "Shampoo"
        },
        {
          "language" : "rm-CH",
          "value" : "Shampoo"
        }
      ]
    },
    {
      "code" : "10509000",
      "display" : "Cutaneous spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung auf der Haut, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung auf der Haut, Lösung"
        }
      ]
    },
    {
      "code" : "10510000",
      "display" : "Cutaneous spray, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung auf der Haut, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung auf der Haut, Suspension"
        }
      ]
    },
    {
      "code" : "10511000",
      "display" : "Cutaneous spray, powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver-Spray zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, polvere"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver-Spray zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10512000",
      "display" : "Cutaneous liquid",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Flüssigkeit zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Liquide cutané"
        },
        {
          "language" : "it-CH",
          "value" : "Liquido cutaneo"
        },
        {
          "language" : "rm-CH",
          "value" : "Flüssigkeit zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10513000",
      "display" : "Cutaneous solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour application cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10514000",
      "display" : "Concentrate for cutaneous solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10514500",
      "display" : "Powder for cutaneous solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10515000",
      "display" : "Cutaneous suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour application cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10516000",
      "display" : "Cutaneous emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10517000",
      "display" : "Cutaneous powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour application cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10517500",
      "display" : "Cutaneous patch",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kutanes Pflaster"
        },
        {
          "language" : "fr-CH",
          "value" : "Patch cutané"
        },
        {
          "language" : "it-CH",
          "value" : "Cerotto cutaneo"
        },
        {
          "language" : "rm-CH",
          "value" : "Kutanes Pflaster"
        }
      ]
    },
    {
      "code" : "10518000",
      "display" : "Solution for iontophoresis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Iontophorese"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour iontophorèse"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per iontoforesi"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Iontophorese"
        }
      ]
    },
    {
      "code" : "10518500",
      "display" : "Powder for solution for iontophoresis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Iontophorese"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour iontophérèse"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per ionoforesi"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Iontophorese"
        }
      ]
    },
    {
      "code" : "10519000",
      "display" : "Transdermal patch",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "transdermales Pflaster"
        },
        {
          "language" : "fr-CH",
          "value" : "Patch transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Cerotto transdermico"
        },
        {
          "language" : "rm-CH",
          "value" : "transdermales Pflaster"
        }
      ]
    },
    {
      "code" : "10520000",
      "display" : "Collodion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "filmbildende Flüssigkeit"
        },
        {
          "language" : "fr-CH",
          "value" : "Collodion"
        },
        {
          "language" : "it-CH",
          "value" : "Collodio"
        },
        {
          "language" : "rm-CH",
          "value" : "filmbildende Flüssigkeit"
        }
      ]
    },
    {
      "code" : "10521000",
      "display" : "Medicated nail lacquer",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "wirkstoffhaltiger Nagellack"
        },
        {
          "language" : "fr-CH",
          "value" : "Vernis à ongles médicamenteux"
        },
        {
          "language" : "it-CH",
          "value" : "Smalto medicato per unghie"
        },
        {
          "language" : "rm-CH",
          "value" : "wirkstoffhaltiger Nagellack"
        }
      ]
    },
    {
      "code" : "10522000",
      "display" : "Poultice",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Umschlagpaste"
        },
        {
          "language" : "fr-CH",
          "value" : "Cataplasme"
        },
        {
          "language" : "it-CH",
          "value" : "Cataplasma"
        },
        {
          "language" : "rm-CH",
          "value" : "Umschlagpaste"
        }
      ]
    },
    {
      "code" : "10523000",
      "display" : "Cutaneous stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Stift zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton pour application cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Matita cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Stift zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "10525000",
      "display" : "Impregnated dressing",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "imprägnierter Verband"
        },
        {
          "language" : "fr-CH",
          "value" : "Compresse imprégnée"
        },
        {
          "language" : "it-CH",
          "value" : "Garza impregnata"
        },
        {
          "language" : "rm-CH",
          "value" : "imprägnierter Verband"
        }
      ]
    },
    {
      "code" : "10546250",
      "display" : "Transdermal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Transdermales Gel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Gel transdermico"
        },
        {
          "language" : "rm-CH",
          "value" : "Transdermales Gel"
        }
      ]
    },
    {
      "code" : "10546400",
      "display" : "Transdermal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "transdermale Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione transdermica"
        },
        {
          "language" : "rm-CH",
          "value" : "transdermale Lösung"
        }
      ]
    },
    {
      "code" : "10546500",
      "display" : "Transdermal spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "transdermales Spray, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Spray transdermico, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "transdermales Spray, Lösung"
        }
      ]
    },
    {
      "code" : "10547000",
      "display" : "Transdermal system",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "transdermales System"
        },
        {
          "language" : "fr-CH",
          "value" : "système transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Sistema transdermico"
        },
        {
          "language" : "rm-CH",
          "value" : "transdermales System"
        }
      ]
    },
    {
      "code" : "10548000",
      "display" : "Solution for skin-prick test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pricktestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "solution pour prick-test"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per skin-prick test"
        },
        {
          "language" : "rm-CH",
          "value" : "Pricktestlösung"
        }
      ]
    },
    {
      "code" : "10549000",
      "display" : "Solution for skin-scratch test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Scratchtestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "solution pour test intradermique"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per scarificazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Scratchtestlösung"
        }
      ]
    },
    {
      "code" : "10550000",
      "display" : "Plaster for provocation test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pflaster für Provokationstest"
        },
        {
          "language" : "fr-CH",
          "value" : "patch pour test épicutané"
        },
        {
          "language" : "it-CH",
          "value" : "Cerotto per test di provocazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pflaster für Provokationstest"
        }
      ]
    },
    {
      "code" : "10600500",
      "display" : "Concentrate for solution for intraocular irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur intraokularen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution pour irrigation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per irrigazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur intraokularen Anwendung"
        }
      ]
    },
    {
      "code" : "10601000",
      "display" : "Eye cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augencreme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Crema oftalmica"
        },
        {
          "language" : "rm-CH",
          "value" : "Augencreme"
        }
      ]
    },
    {
      "code" : "10602000",
      "display" : "Eye gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augengel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Gel oftalmico"
        },
        {
          "language" : "rm-CH",
          "value" : "Augengel"
        }
      ]
    },
    {
      "code" : "10603000",
      "display" : "Eye ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augensalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento oftalmico"
        },
        {
          "language" : "rm-CH",
          "value" : "Augensalbe"
        }
      ]
    },
    {
      "code" : "10604000",
      "display" : "Eye drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Collyre en solution"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "10604500",
      "display" : "Eye drops, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augentropfen, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Collyre en émulsion"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augentropfen, Emulsion"
        }
      ]
    },
    {
      "code" : "10605000",
      "display" : "Eye drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augentropfensuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Collyre en suspension"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augentropfensuspension"
        }
      ]
    },
    {
      "code" : "10608000",
      "display" : "Eye drops, solvent for reconstitution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung von Augentropfen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour collyre"
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per collirio"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung von Augentropfen"
        }
      ]
    },
    {
      "code" : "10609000",
      "display" : "Eye drops, prolonged-release",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augentropfen mit verlängerter Wirkungsdauer"
        },
        {
          "language" : "fr-CH",
          "value" : "Collyre à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Augentropfen mit verlängerter Wirkungsdauer"
        }
      ]
    },
    {
      "code" : "10610000",
      "display" : "Eye lotion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augenbad"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour lavage ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Bagno oculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Augenbad"
        }
      ]
    },
    {
      "code" : "10611000",
      "display" : "Eye lotion, solvent for reconstitution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung eines Augenbades"
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour solution pour lavage ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per bagno oculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung eines Augenbades"
        }
      ]
    },
    {
      "code" : "10612000",
      "display" : "Ophthalmic insert",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augeninsert"
        },
        {
          "language" : "fr-CH",
          "value" : "Insert ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Inserto oftalmico"
        },
        {
          "language" : "rm-CH",
          "value" : "Augeninsert"
        }
      ]
    },
    {
      "code" : "10613000",
      "display" : "Ophthalmic strip",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Teststreifen zur Anwendung am Auge"
        },
        {
          "language" : "fr-CH",
          "value" : "Bandelette ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Striscia oftalmica"
        },
        {
          "language" : "rm-CH",
          "value" : "Teststreifen zur Anwendung am Auge"
        }
      ]
    },
    {
      "code" : "10701000",
      "display" : "Ear cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrencreme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Crema auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrencreme"
        }
      ]
    },
    {
      "code" : "10702000",
      "display" : "Ear gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrengel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Gel auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrengel"
        }
      ]
    },
    {
      "code" : "10703000",
      "display" : "Ear ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrensalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrensalbe"
        }
      ]
    },
    {
      "code" : "10704000",
      "display" : "Ear drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution auriculaire en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "10705000",
      "display" : "Ear drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrentropfen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension auriculaire en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrentropfen, Suspension"
        }
      ]
    },
    {
      "code" : "10706000",
      "display" : "Ear drops, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrentropfen, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion auriculaire en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrentropfen, Emulsion"
        }
      ]
    },
    {
      "code" : "10708000",
      "display" : "Ear powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenpulver"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenpulver"
        }
      ]
    },
    {
      "code" : "10709000",
      "display" : "Ear spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenspray, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Spray auricolare, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenspray, Lösung"
        }
      ]
    },
    {
      "code" : "10710000",
      "display" : "Ear spray, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenspray, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour pulvérisation auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Spray auricolare, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenspray, Suspension"
        }
      ]
    },
    {
      "code" : "10711000",
      "display" : "Ear spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenspray, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour pulvérisation auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Spray auricolare, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenspray, Emulsion"
        }
      ]
    },
    {
      "code" : "10712000",
      "display" : "Ear wash, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenspüllösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour lavage auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Lavaggio auricolare, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenspüllösung"
        }
      ]
    },
    {
      "code" : "10713000",
      "display" : "Ear wash, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenspülung, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour lavage auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Lavaggio auricolare, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenspülung, Emulsion"
        }
      ]
    },
    {
      "code" : "10714000",
      "display" : "Ear tampon",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrentampon"
        },
        {
          "language" : "fr-CH",
          "value" : "Tampon auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Tampone auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrentampon"
        }
      ]
    },
    {
      "code" : "10715000",
      "display" : "Ear stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Ohrenstäbchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton pour usage auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Bastoncino auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Ohrenstäbchen"
        }
      ]
    },
    {
      "code" : "10801000",
      "display" : "Nasal cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasencreme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Crema nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasencreme"
        }
      ]
    },
    {
      "code" : "10802000",
      "display" : "Nasal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasengel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel nasal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasengel"
        }
      ]
    },
    {
      "code" : "10803000",
      "display" : "Nasal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasensalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasensalbe"
        }
      ]
    },
    {
      "code" : "10804000",
      "display" : "Nasal drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce nasali, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "10805000",
      "display" : "Nasal drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasentropfen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce nasali, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasentropfen, Suspension"
        }
      ]
    },
    {
      "code" : "10806000",
      "display" : "Nasal drops, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasentropfen, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce nasali, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasentropfen, Emulsion"
        }
      ]
    },
    {
      "code" : "10807000",
      "display" : "Nasal powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenpulver"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenpulver"
        }
      ]
    },
    {
      "code" : "10808000",
      "display" : "Nasal spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray, Lösung"
        }
      ]
    },
    {
      "code" : "10809000",
      "display" : "Nasal spray, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour pulvérisation nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray, Suspension"
        }
      ]
    },
    {
      "code" : "10810000",
      "display" : "Nasal spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour pulvérisation nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray, Emulsion"
        }
      ]
    },
    {
      "code" : "10811000",
      "display" : "Nasal wash",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspülung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour lavage nasal"
        },
        {
          "language" : "it-CH",
          "value" : "Lavaggio nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspülung"
        }
      ]
    },
    {
      "code" : "10812000",
      "display" : "Nasal stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenstift"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton pour usage nasal"
        },
        {
          "language" : "it-CH",
          "value" : "Bastoncino nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenstift"
        }
      ]
    },
    {
      "code" : "10901000",
      "display" : "Vaginal cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalcreme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Crema vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalcreme"
        }
      ]
    },
    {
      "code" : "10902000",
      "display" : "Vaginal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalgel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel vaginal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalgel"
        }
      ]
    },
    {
      "code" : "10903000",
      "display" : "Vaginal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalsalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalsalbe"
        }
      ]
    },
    {
      "code" : "10904000",
      "display" : "Vaginal foam",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalschaum"
        },
        {
          "language" : "fr-CH",
          "value" : "Mousse vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Schiuma vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalschaum"
        }
      ]
    },
    {
      "code" : "10905000",
      "display" : "Vaginal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginallösung"
        }
      ]
    },
    {
      "code" : "10906000",
      "display" : "Vaginal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalsuspension"
        }
      ]
    },
    {
      "code" : "10907000",
      "display" : "Vaginal emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalemulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalemulsion"
        }
      ]
    },
    {
      "code" : "10908000",
      "display" : "Tablet for vaginal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Vaginallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per soluzione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Vaginallösung"
        }
      ]
    },
    {
      "code" : "10909000",
      "display" : "Pessary",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginalzäpfchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Ovule"
        },
        {
          "language" : "it-CH",
          "value" : "Ovulo"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginalzäpfchen"
        }
      ]
    },
    {
      "code" : "10910000",
      "display" : "Vaginal capsule, hard",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hartkapsel zur vaginalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gélule vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rigida vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Hartkapsel zur vaginalen Anwendung"
        }
      ]
    },
    {
      "code" : "10911000",
      "display" : "Vaginal capsule, soft",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Weichkapsel zur vaginalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule molle vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula molle vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Weichkapsel zur vaginalen Anwendung"
        }
      ]
    },
    {
      "code" : "10912000",
      "display" : "Vaginal tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Vaginaltablette"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé vaginal"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Vaginaltablette"
        }
      ]
    },
    {
      "code" : "10913000",
      "display" : "Effervescent vaginal tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schaumovula"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé vaginal effervescent"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa effervescente vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Schaumovula"
        }
      ]
    },
    {
      "code" : "10914000",
      "display" : "Medicated vaginal tampon",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Wirkstoffhaltiger Vaginaltampon"
        },
        {
          "language" : "fr-CH",
          "value" : "Tampon vaginal médicamenteux"
        },
        {
          "language" : "it-CH",
          "value" : "Tampone vaginale medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "Wirkstoffhaltiger Vaginaltampon"
        }
      ]
    },
    {
      "code" : "10915000",
      "display" : "Vaginal delivery system",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "vaginales Wirkstofffreisetzungssystem"
        },
        {
          "language" : "fr-CH",
          "value" : "Système de diffusion vaginal"
        },
        {
          "language" : "it-CH",
          "value" : "Dispositivo vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "vaginales Wirkstofffreisetzungssystem"
        }
      ]
    },
    {
      "code" : "11001000",
      "display" : "Rectal cream",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalcreme"
        },
        {
          "language" : "fr-CH",
          "value" : "Crème rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Crema rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalcreme"
        }
      ]
    },
    {
      "code" : "11002000",
      "display" : "Rectal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalgel"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel rectal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalgel"
        }
      ]
    },
    {
      "code" : "11003000",
      "display" : "Rectal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalsalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalsalbe"
        }
      ]
    },
    {
      "code" : "11004000",
      "display" : "Rectal foam",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalschaum"
        },
        {
          "language" : "fr-CH",
          "value" : "Mousse rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Schiuma rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalschaum"
        }
      ]
    },
    {
      "code" : "11005000",
      "display" : "Rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektallösung"
        }
      ]
    },
    {
      "code" : "11006000",
      "display" : "Rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalsuspension"
        }
      ]
    },
    {
      "code" : "11007000",
      "display" : "Rectal emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalemulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalemulsion"
        }
      ]
    },
    {
      "code" : "11008000",
      "display" : "Concentrate for rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution rectale à diluer"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Rektallösung"
        }
      ]
    },
    {
      "code" : "11009000",
      "display" : "Powder for rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Rektallösung"
        }
      ]
    },
    {
      "code" : "11010000",
      "display" : "Powder for rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Rektalsuspension"
        }
      ]
    },
    {
      "code" : "11011000",
      "display" : "Tablet for rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per soluzione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Rektallösung"
        }
      ]
    },
    {
      "code" : "11012000",
      "display" : "Tablet for rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour suspension rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per sospensione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Rektalsuspension"
        }
      ]
    },
    {
      "code" : "11013000",
      "display" : "Suppository",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Zäpfchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Suppositoire"
        },
        {
          "language" : "it-CH",
          "value" : "Supposta"
        },
        {
          "language" : "rm-CH",
          "value" : "Zäpfchen"
        }
      ]
    },
    {
      "code" : "11014000",
      "display" : "Rectal capsule",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektalkapsel"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule  rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektalkapsel"
        }
      ]
    },
    {
      "code" : "11015000",
      "display" : "Rectal tampon",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Rektaltampon"
        },
        {
          "language" : "fr-CH",
          "value" : "Tampon rectal"
        },
        {
          "language" : "it-CH",
          "value" : "Tampone rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Rektaltampon"
        }
      ]
    },
    {
      "code" : "11101000",
      "display" : "Nebuliser solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung für einen Vernebler"
        }
      ]
    },
    {
      "code" : "11102000",
      "display" : "Nebuliser suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension für einen Vernebler"
        }
      ]
    },
    {
      "code" : "11103000",
      "display" : "Powder for nebuliser suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Suspension für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Suspension für einen Vernebler"
        }
      ]
    },
    {
      "code" : "11104000",
      "display" : "Powder for nebuliser solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung für einen Vernebler"
        }
      ]
    },
    {
      "code" : "11105000",
      "display" : "Nebuliser emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion für einen Vernebler"
        }
      ]
    },
    {
      "code" : "11106000",
      "display" : "Pressurised inhalation, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Druckgasinhalation, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour inhalation en flacon pressurisé"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione pressurizzata per inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Druckgasinhalation, Lösung"
        }
      ]
    },
    {
      "code" : "11107000",
      "display" : "Pressurised inhalation, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Druckgasinhalation, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour inhalation en flacon pressurisé"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione pressurizzata per inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Druckgasinhalation, Suspension"
        }
      ]
    },
    {
      "code" : "11108000",
      "display" : "Pressurised inhalation, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Druckgasinhalation, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour inhalation en flacon pressurisé"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione pressurizzata per inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Druckgasinhalation, Emulsion"
        }
      ]
    },
    {
      "code" : "11109000",
      "display" : "Inhalation powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour inhalation"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Inhalation"
        }
      ]
    },
    {
      "code" : "11110000",
      "display" : "Inhalation powder, hard capsule",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hartkapsel mit Pulver zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour inhalation en gélule"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per inalazione, capsula rigida"
        },
        {
          "language" : "rm-CH",
          "value" : "Hartkapsel mit Pulver zur Inhalation"
        }
      ]
    },
    {
      "code" : "11111000",
      "display" : "Inhalation powder, pre-dispensed",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "einzeldosiertes Pulver zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour inhalation en récipient unidose"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per inalazione, pre-dosata"
        },
        {
          "language" : "rm-CH",
          "value" : "einzeldosiertes Pulver zur Inhalation"
        }
      ]
    },
    {
      "code" : "11112000",
      "display" : "Inhalation vapour, powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11113000",
      "display" : "Inhalation vapour, capsule",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kapsel zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Capsule pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Capsula per suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Kapsel zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11114000",
      "display" : "Inhalation vapour, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per  suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11115000",
      "display" : "Inhalation vapour, tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per  suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11116000",
      "display" : "Inhalation vapour, ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Salbe zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento per suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Salbe zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11117000",
      "display" : "Inhalation vapour, liquid",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Flüssigkeit zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Liquide pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Liquido per  suffumigi"
        },
        {
          "language" : "rm-CH",
          "value" : "Flüssigkeit zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "11201000",
      "display" : "Solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Injektionslösung"
        }
      ]
    },
    {
      "code" : "11202000",
      "display" : "Suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Injektionssuspension"
        }
      ]
    },
    {
      "code" : "11203000",
      "display" : "Emulsion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Emuslione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Injektion"
        }
      ]
    },
    {
      "code" : "11204000",
      "display" : "Gel for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Gel iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur Injektion"
        }
      ]
    },
    {
      "code" : "11205000",
      "display" : "Powder for solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Injektionslösung"
        }
      ]
    },
    {
      "code" : "11206000",
      "display" : "Powder for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "11208400",
      "display" : "Powder for prolonged-release suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Depot-Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension injectable à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione iniettabile a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Depot-Injektionssuspension"
        }
      ]
    },
    {
      "code" : "11208500",
      "display" : "Prolonged-release suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Depot-Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension injectable à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione iniettabile a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Depot-Injektionssuspension"
        }
      ]
    },
    {
      "code" : "11209000",
      "display" : "Concentrate for solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Injektionslösung"
        }
      ]
    },
    {
      "code" : "11209500",
      "display" : "Solution for cardioplegia",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kardioplege Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution de cardioplégie"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per cardioplegia"
        },
        {
          "language" : "rm-CH",
          "value" : "Kardioplege Lösung"
        }
      ]
    },
    {
      "code" : "11210000",
      "display" : "Solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Infusionslösung"
        }
      ]
    },
    {
      "code" : "11211000",
      "display" : "Emulsion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Infusion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Infusion"
        }
      ]
    },
    {
      "code" : "11211500",
      "display" : "Powder for dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour dispersion pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "11212000",
      "display" : "Powder for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "11213000",
      "display" : "Concentrate for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "11216000",
      "display" : "Solvent for parenteral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung von Parenteralia"
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour préparation parentérale"
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per uso parenterale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung von Parenteralia"
        }
      ]
    },
    {
      "code" : "11301000",
      "display" : "Implant",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Implantat"
        },
        {
          "language" : "fr-CH",
          "value" : "Implant"
        },
        {
          "language" : "it-CH",
          "value" : "Impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Implantat"
        }
      ]
    },
    {
      "code" : "11302000",
      "display" : "Implantation tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Implantation"
        }
      ]
    },
    {
      "code" : "11303000",
      "display" : "Implantation chain",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kette zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Implant en chaîne"
        },
        {
          "language" : "it-CH",
          "value" : "Catenella per impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Kette zur Implantation"
        }
      ]
    },
    {
      "code" : "11303300",
      "display" : "Implantation matrix",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Matrix zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Matrice pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Catenella per impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Matrix zur Implantation"
        }
      ]
    },
    {
      "code" : "11303500",
      "display" : "Implantation suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Catenella per impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Implantation"
        }
      ]
    },
    {
      "code" : "11401000",
      "display" : "Solution for peritoneal dialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Peritonealdialyselösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour dialyse péritonéale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per dialisi peritoneale"
        },
        {
          "language" : "rm-CH",
          "value" : "Peritonealdialyselösung"
        }
      ]
    },
    {
      "code" : "11402000",
      "display" : "Solution for haemofiltration",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hämofiltrationslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour hémofiltration"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per emofiltrazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Hämofiltrationslösung"
        }
      ]
    },
    {
      "code" : "11403000",
      "display" : "Solution for haemodiafiltration",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hämodiafiltrationslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour hémodiafiltration"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per emofiltrazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Hämodiafiltrationslösung"
        }
      ]
    },
    {
      "code" : "11404000",
      "display" : "Solution for haemodialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hämodialyselösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour hémodialyse"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per emodialisi"
        },
        {
          "language" : "rm-CH",
          "value" : "Hämodialyselösung"
        }
      ]
    },
    {
      "code" : "11405000",
      "display" : "Concentrate for solution for haemodialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Hämodialyselösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour hémodialyse"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione concentrata per emodialisi"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Hämodialyselösung"
        }
      ]
    },
    {
      "code" : "11502000",
      "display" : "Bladder irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Blasenspüllösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour irrigation vésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Irrigazione vescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Blasenspüllösung"
        }
      ]
    },
    {
      "code" : "11502500",
      "display" : "Intravesical solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "11503000",
      "display" : "Powder for bladder irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Blasenspüllösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour irrigation vésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per irrigazione vescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Blasenspüllösung"
        }
      ]
    },
    {
      "code" : "11504000",
      "display" : "Urethral gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur Anwendung in der Harnröhre"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel urétral"
        },
        {
          "language" : "it-CH",
          "value" : "Gel uretrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur Anwendung in der Harnröhre"
        }
      ]
    },
    {
      "code" : "11505000",
      "display" : "Urethral stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Stäbchen zur Anwendung in der Harnröhre"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton pour usage urétral"
        },
        {
          "language" : "it-CH",
          "value" : "Bastoncino uretrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Stäbchen zur Anwendung in der Harnröhre"
        }
      ]
    },
    {
      "code" : "11601000",
      "display" : "Endotracheopulmonary instillation, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur endotracheopulmonalen Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour instillation endotrachéobronchique"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per instillazione endotracheobronchiale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur endotracheopulmonalen Instillation"
        }
      ]
    },
    {
      "code" : "11602000",
      "display" : "Endotracheopulmonary instillation, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur endotracheopulmonalen Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour instillation endotrachéobronchique"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per instillazione endotracheobronchiale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur endotracheopulmonalen Instillation"
        }
      ]
    },
    {
      "code" : "11603000",
      "display" : "Endotracheopulmonary instillation, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur endotracheopulmonalen Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour instillation endotrachéobronchique"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per instillazione endotracheobronchiale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur endotracheopulmonalen Instillation"
        }
      ]
    },
    {
      "code" : "11701000",
      "display" : "Endocervical gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur endozervikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel endocervical"
        },
        {
          "language" : "it-CH",
          "value" : "Gel endocervicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur endozervikalen Anwendung"
        }
      ]
    },
    {
      "code" : "11901000",
      "display" : "Intrauterine delivery system",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Intrauterines Wirkstofffreisetzungssystem"
        },
        {
          "language" : "fr-CH",
          "value" : "Système de diffusion intra-utérin"
        },
        {
          "language" : "it-CH",
          "value" : "Sistema a rilascio intrauterino"
        },
        {
          "language" : "rm-CH",
          "value" : "Intrauterines Wirkstofffreisetzungssystem"
        }
      ]
    },
    {
      "code" : "12101000",
      "display" : "Denture lacquer",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lack für die Gebisskontaktfläche"
        },
        {
          "language" : "fr-CH",
          "value" : "Laque dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Smalto dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lack für die Gebisskontaktfläche"
        }
      ]
    },
    {
      "code" : "12102000",
      "display" : "Anticoagulant and preservative solution for blood",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Stabilisatorlösung für Blutkonserven"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution anticoagulante et de conservation du sang humain"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione anticoagulante e conservante per il sangue"
        },
        {
          "language" : "rm-CH",
          "value" : "Stabilisatorlösung für Blutkonserven"
        }
      ]
    },
    {
      "code" : "12103000",
      "display" : "Solution for blood fraction modification",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Modifikation einer Blutfraktion"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour la préparation ex vivo de fractions sanguines"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per la modifica di frazione ematica"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Modifikation einer Blutfraktion"
        }
      ]
    },
    {
      "code" : "12104000",
      "display" : "Wound stick",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Wundstäbchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Bâton intralésionnel"
        },
        {
          "language" : "it-CH",
          "value" : "Matita emostatica"
        },
        {
          "language" : "rm-CH",
          "value" : "Wundstäbchen"
        }
      ]
    },
    {
      "code" : "12105000",
      "display" : "Radiopharmaceutical precursor",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Markerzubereitung"
        },
        {
          "language" : "fr-CH",
          "value" : "Précurseur radiopharmaceutique"
        },
        {
          "language" : "it-CH",
          "value" : "Precursore radiofarmaceutico"
        },
        {
          "language" : "rm-CH",
          "value" : "Markerzubereitung"
        }
      ]
    },
    {
      "code" : "12106000",
      "display" : "Radionuclide generator",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Radionuklidgenerator"
        },
        {
          "language" : "fr-CH",
          "value" : "Générateur radiopharmaceutique"
        },
        {
          "language" : "it-CH",
          "value" : "Generatore di radionuclidi"
        },
        {
          "language" : "rm-CH",
          "value" : "Radionuklidgenerator"
        }
      ]
    },
    {
      "code" : "12107000",
      "display" : "Kit for radiopharmaceutical preparation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kit für ein radioaktives Arzneimittel"
        },
        {
          "language" : "fr-CH",
          "value" : "Trousse pour préparation radiopharmaceutique"
        },
        {
          "language" : "it-CH",
          "value" : "Kit per preparazione radiofarmaceutica"
        },
        {
          "language" : "rm-CH",
          "value" : "Kit für ein radioaktives Arzneimittel"
        }
      ]
    },
    {
      "code" : "12108000",
      "display" : "Gastroenteral solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur gastrointestinalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution gastroentérale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione gastroenterica"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur gastrointestinalen Anwendung"
        }
      ]
    },
    {
      "code" : "12110000",
      "display" : "Gastroenteral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur gastrointestinalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension gastroentérale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione gastroenterica"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur gastrointestinalen Anwendung"
        }
      ]
    },
    {
      "code" : "12111000",
      "display" : "Gastroenteral emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur gastrointestinalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion gastroentérale"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione gastroenterica"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur gastrointestinalen Anwendung"
        }
      ]
    },
    {
      "code" : "12111500",
      "display" : "Intraperitoneal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur intraperitonealen Awendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution intrapéritonéale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione intraperitoneale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur intraperitonealen Awendung"
        }
      ]
    },
    {
      "code" : "12112000",
      "display" : "Solution for organ preservation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Organkonservierungslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour conservation d'organe"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per conservazione di organi"
        },
        {
          "language" : "rm-CH",
          "value" : "Organkonservierungslösung"
        }
      ]
    },
    {
      "code" : "12113000",
      "display" : "Irrigation solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spüllösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour irrigation"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per irrigazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spüllösung"
        }
      ]
    },
    {
      "code" : "12114000",
      "display" : "Stomach irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magenspülflüssigkeit"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour irrigation stomacale"
        },
        {
          "language" : "it-CH",
          "value" : "Liquido per lavanda gastrica"
        },
        {
          "language" : "rm-CH",
          "value" : "Magenspülflüssigkeit"
        }
      ]
    },
    {
      "code" : "12115000",
      "display" : "Sealant",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gewebekleber"
        },
        {
          "language" : "fr-CH",
          "value" : "Colle"
        },
        {
          "language" : "it-CH",
          "value" : "Adesivo tissutale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gewebekleber"
        }
      ]
    },
    {
      "code" : "12115100",
      "display" : "Sealant matrix",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Versiegelungsmatrix"
        },
        {
          "language" : "fr-CH",
          "value" : "Matrice pour colle"
        },
        {
          "language" : "it-CH",
          "value" : "Matrice per adesivo tissutale"
        },
        {
          "language" : "rm-CH",
          "value" : "Versiegelungsmatrix"
        }
      ]
    },
    {
      "code" : "12115200",
      "display" : "Sealant powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gewebekleber"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour colle"
        },
        {
          "language" : "it-CH",
          "value" : "Adesivo tissutale, polvere"
        },
        {
          "language" : "rm-CH",
          "value" : "Gewebekleber"
        }
      ]
    },
    {
      "code" : "12117000",
      "display" : "Impregnated pad",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Imprägnierter Tampon"
        },
        {
          "language" : "fr-CH",
          "value" : "Tampon imprégné"
        },
        {
          "language" : "it-CH",
          "value" : "Tampone medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "Imprägnierter Tampon"
        }
      ]
    },
    {
      "code" : "12117500",
      "display" : "Impregnated plug",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Imprägnierter Einsatz"
        },
        {
          "language" : "fr-CH",
          "value" : "Support poreux imprégné"
        },
        {
          "language" : "it-CH",
          "value" : "Supporto medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "Imprägnierter Einsatz"
        }
      ]
    },
    {
      "code" : "12118000",
      "display" : "Living tissue equivalent",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "lebendes Gewebeäquivalent"
        },
        {
          "language" : "fr-CH",
          "value" : "Substitut de tissu vivant"
        },
        {
          "language" : "it-CH",
          "value" : "Tessuto vivente da coltura di cellule"
        },
        {
          "language" : "rm-CH",
          "value" : "lebendes Gewebeäquivalent"
        }
      ]
    },
    {
      "code" : "12119000",
      "display" : "Medicated sponge",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "wirkstoffhaltiges Schwämmchen"
        },
        {
          "language" : "fr-CH",
          "value" : "Eponge médicamenteuse"
        },
        {
          "language" : "it-CH",
          "value" : "Spugna medicata"
        },
        {
          "language" : "rm-CH",
          "value" : "wirkstoffhaltiges Schwämmchen"
        }
      ]
    },
    {
      "code" : "12120000",
      "display" : "Intestinal gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur intestinalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel intestinal"
        },
        {
          "language" : "it-CH",
          "value" : "Gel intestinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur intestinalen Anwendung"
        }
      ]
    },
    {
      "code" : "12130000",
      "display" : "Medicated thread",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "wirkstoffhaltiger Faden"
        },
        {
          "language" : "fr-CH",
          "value" : "Fils médicamenteux"
        },
        {
          "language" : "it-CH",
          "value" : "Filo medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "wirkstoffhaltiger Faden"
        }
      ]
    },
    {
      "code" : "12131000",
      "display" : "Solution for provocation test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Provokationstestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "solution pour test de provocation"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per saggio di provocazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Provokationstestlösung"
        }
      ]
    },
    {
      "code" : "12301000",
      "display" : "Medicinal gas, compressed",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur medizinischen Anwendung, druckverdichtet"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz médicinal comprimé"
        },
        {
          "language" : "it-CH",
          "value" : "Gas medicinale compresso"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur medizinischen Anwendung, druckverdichtet"
        }
      ]
    },
    {
      "code" : "12302000",
      "display" : "Medicinal gas, cryogenic",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur medizinischen Anwendung, kälteverflüssigt"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz médicinal cryogénique"
        },
        {
          "language" : "it-CH",
          "value" : "Gas medicinale criogenico"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur medizinischen Anwendung, kälteverflüssigt"
        }
      ]
    },
    {
      "code" : "12303000",
      "display" : "Medicinal gas, liquefied",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur medizinischen Anwendung, verflüssigt"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz médicinal liquéfié"
        },
        {
          "language" : "it-CH",
          "value" : "Gas medicinale liquefatto"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur medizinischen Anwendung, verflüssigt"
        }
      ]
    },
    {
      "code" : "13001000",
      "display" : "Concentrate for concentrate for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat für ein Konzentrat zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz médicinal liquéfié"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per concentrato per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat für ein Konzentrat zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "13002000",
      "display" : "Concentrate for nebuliser solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung für einen Vernebler"
        }
      ]
    },
    {
      "code" : "13003000",
      "display" : "Concentrate for oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "13004000",
      "display" : "Concentrate for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension à diluer injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "13005000",
      "display" : "Dispersion for concentrate for dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dispersion für ein Konzentrat zur Herstellung einer Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion pour dispersion à diluer pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Dispersione per concentrato per dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Dispersion für ein Konzentrat zur Herstellung einer Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "13006000",
      "display" : "Ear drops, powder for suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Ohrentropfensuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension auriculaire en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari, polvere per sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Ohrentropfensuspension"
        }
      ]
    },
    {
      "code" : "13007000",
      "display" : "Effervescent granules for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brausegranulat zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés effervescents pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato effervescente per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Brausegranulat zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13008000",
      "display" : "Emulsion for emulsion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Herstellung einer Emulsion zur Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour émulsion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione per emulsione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Herstellung einer Emulsion zur Injektion"
        }
      ]
    },
    {
      "code" : "13009000",
      "display" : "Endotracheopulmonary instillation, powder for suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zu Herstellung einer Suspension zur endotracheopulmonalen Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension pour instillation endotrachéobronchique"
        },
        {
          "language" : "it-CH",
          "value" : "Instillazione endotracheobronchiale, polvere per sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zu Herstellung einer Suspension zur endotracheopulmonalen Instillation"
        }
      ]
    },
    {
      "code" : "13010000",
      "display" : "Eye drops, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung von Augentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution ophtalmique en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio, polvere per soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung von Augentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "13011000",
      "display" : "Eye drops, powder for suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Augentropfensuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension ophtalmique en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Collirio, polvere per sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Augentropfensuspension"
        }
      ]
    },
    {
      "code" : "13012000",
      "display" : "Gas for dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur Herstellung einer Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz pour dispersion pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Gas per dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur Herstellung einer Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "13013000",
      "display" : "Gas for dispersion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur Herstellung einer Injektionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz pour dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Gas per dispersione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur Herstellung einer Injektionsdispersion"
        }
      ]
    },
    {
      "code" : "13014000",
      "display" : "Gel for gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur Herstellung eines Gels"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel pour gel"
        },
        {
          "language" : "it-CH",
          "value" : "Gel per gel"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur Herstellung eines Gels"
        }
      ]
    },
    {
      "code" : "13015000",
      "display" : "Granules for rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour suspension rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per sospensione rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Rektalsuspension"
        }
      ]
    },
    {
      "code" : "13016000",
      "display" : "Laryngopharyngeal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung im Rachenraum und am Kehlkopf"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution laryngopharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione laringofaringea"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung im Rachenraum und am Kehlkopf"
        }
      ]
    },
    {
      "code" : "13017000",
      "display" : "Laryngopharyngeal spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung im Rachenraum und am Kehlkopf, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation laryngopharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray laringofaringeo, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung im Rachenraum und am Kehlkopf, Lösung"
        }
      ]
    },
    {
      "code" : "13018000",
      "display" : "Matrix for implantation matrix",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Matrix für Matrix zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Matrice pour matrice pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Spray laringofaringeo, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Matrix für Matrix zur Implantation"
        }
      ]
    },
    {
      "code" : "13020000",
      "display" : "Nasal drops, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung von Nasentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce nasali, polvere per soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung von Nasentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "13021000",
      "display" : "Powder for gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Gels"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour gel"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Gels"
        }
      ]
    },
    {
      "code" : "13022000",
      "display" : "Powder for dental gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Dentalgels"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour gel dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Dentalgels"
        }
      ]
    },
    {
      "code" : "13023000",
      "display" : "Powder for dispersion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Injektionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per dispersione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Injektionsdispersion"
        }
      ]
    },
    {
      "code" : "13024000",
      "display" : "Powder for endocervical gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Gels zur endozervikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour gel endocervical"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel endocervicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Gels zur endozervikalen Anwendung"
        }
      ]
    },
    {
      "code" : "13025000",
      "display" : "Powder for endosinusial solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Anwendung in den Nasennebenhöhlen"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution endosinusale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione endosinusale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur Anwendung in den Nasennebenhöhlen"
        }
      ]
    },
    {
      "code" : "13026000",
      "display" : "Powder for gingival gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung eines Gels zur Anwendung am Zahnfleisch"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour gel gingival"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung eines Gels zur Anwendung am Zahnfleisch"
        }
      ]
    },
    {
      "code" : "13027000",
      "display" : "Powder for implantation matrix",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für Matrix zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour matrice pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für Matrix zur Implantation"
        }
      ]
    },
    {
      "code" : "13028000",
      "display" : "Powder for implantation paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Paste für ein Implantat"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour pâte pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per gel gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Paste für ein Implantat"
        }
      ]
    },
    {
      "code" : "13029000",
      "display" : "Powder for intraocular instillation solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Instillationslösung zur intraokularen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour instillation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per instillazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Instillationslösung zur intraokularen Anwendung"
        }
      ]
    },
    {
      "code" : "13031000",
      "display" : "Powder for sealant",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für einen Gewebekleber"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour colle"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per adesivo tissutale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für einen Gewebekleber"
        }
      ]
    },
    {
      "code" : "13032000",
      "display" : "Powder for solution for skin-prick test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Pricktestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour prick-test"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per skin-prick test"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Pricktestlösung"
        }
      ]
    },
    {
      "code" : "13033000",
      "display" : "Solution for solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Herstellung einer Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour solution injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Herstellung einer Injektionslösung"
        }
      ]
    },
    {
      "code" : "13035000",
      "display" : "Solvent for...",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung..."
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour..."
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per…"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung..."
        }
      ]
    },
    {
      "code" : "13036000",
      "display" : "Suspension for emulsion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Herstellung einer Emulsion zur Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour émulsion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per emulsione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Herstellung einer Emulsion zur Injektion"
        }
      ]
    },
    {
      "code" : "13037000",
      "display" : "Suspension for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13039000",
      "display" : "Suspension for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "13040000",
      "display" : "Powder for emulsion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Emulsion zur Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour émulsion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per emulsione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Emulsion zur Injektion"
        }
      ]
    },
    {
      "code" : "13041000",
      "display" : "Endosinusial solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung in den Nebenhöhlen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution endosinusale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione endosinusale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung in den Nebenhöhlen"
        }
      ]
    },
    {
      "code" : "13042000",
      "display" : "Epilesional solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zum Auftragen auf die Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution épilésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione epilesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zum Auftragen auf die Haut"
        }
      ]
    },
    {
      "code" : "13043000",
      "display" : "Implantation paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Paste für Implantate"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione epilesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "Paste für Implantate"
        }
      ]
    },
    {
      "code" : "13044000",
      "display" : "Intraocular instillation solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur intraokularen Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour instillation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per instillazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur intraokularen Instillation"
        }
      ]
    },
    {
      "code" : "13045000",
      "display" : "Intravesical suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "13046000",
      "display" : "Coated granules",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Überzogenes Granulat"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés enrobés"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato rivestito"
        },
        {
          "language" : "rm-CH",
          "value" : "Überzogenes Granulat"
        }
      ]
    },
    {
      "code" : "13047000",
      "display" : "Solution for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "13048000",
      "display" : "Granules for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "13049000",
      "display" : "Dispersion for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dispersion zur Injektion /Infusion"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion injectable/ pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Dispersione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Dispersion zur Injektion /Infusion"
        }
      ]
    },
    {
      "code" : "13050000",
      "display" : "Gas for dispersion for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gas zur Herstellung einer Injektions-/Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Gaz pour dispersion injectable/ pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Gas per dispersione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Gas zur Herstellung einer Injektions-/Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "13051000",
      "display" : "Solution for injection/skin-prick test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektionslösung/ Pricktestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution injectable/ pour prick-test"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione iniettabile/per skin-prick test"
        },
        {
          "language" : "rm-CH",
          "value" : "Injektionslösung/ Pricktestlösung"
        }
      ]
    },
    {
      "code" : "13052000",
      "display" : "Powder for solution for injection/skin-prick test",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Injektionslösung/Pricktestlösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution injectable/ pour prick-test"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione iniettabile/per skin-prick test"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Injektionslösung/Pricktestlösung"
        }
      ]
    },
    {
      "code" : "13061000",
      "display" : "Solution for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour solution pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "13066000",
      "display" : "Tablet for cutaneous solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette zur Herstellung einer Lösung zur Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour solution cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa per soluzione cutanea"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette zur Herstellung einer Lösung zur Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "13076000",
      "display" : "Prolonged-release solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Depot-Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution injectable à libération prolongée"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione iniettabile a rilascio prolungato"
        },
        {
          "language" : "rm-CH",
          "value" : "Depot-Injektionslösung"
        }
      ]
    },
    {
      "code" : "13077000",
      "display" : "Urethral emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Anwendung in der Harnröhre"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion urétrale"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione uretrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Anwendung in der Harnröhre"
        }
      ]
    },
    {
      "code" : "13091000",
      "display" : "Emulsion for suspension for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Herstellung einer Injektionssuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour suspension injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione per sospensione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Herstellung einer Injektionssuspension"
        }
      ]
    },
    {
      "code" : "13102000",
      "display" : "Transdermal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Transdermale Salbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento transdermico"
        },
        {
          "language" : "rm-CH",
          "value" : "Transdermale Salbe"
        }
      ]
    },
    {
      "code" : "13105000",
      "display" : "Sublingual powder",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur sublingualen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere sublinguale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur sublingualen Anwendung"
        }
      ]
    },
    {
      "code" : "13106000",
      "display" : "Oral herbal material",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pflanzenteile zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "-"
        },
        {
          "language" : "it-CH",
          "value" : "Sostanza di origine vegetale  per uso orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pflanzenteile zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13107000",
      "display" : "Solution for cardioplegia/organ preservation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kardioplege Lösung/Organkonservierungslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour cardioplégie/préservation d'organe"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per cardioplegia/conservazione di organi"
        },
        {
          "language" : "rm-CH",
          "value" : "Kardioplege Lösung/Organkonservierungslösung"
        }
      ]
    },
    {
      "code" : "50001000",
      "display" : "Chewable/dispersible tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kautablette/Tablette zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé dispersible / à croquer"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa masticabile/dispersibile"
        },
        {
          "language" : "rm-CH",
          "value" : "Kautablette/Tablette zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "50009000",
      "display" : "Concentrate for cutaneous spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung eines Sprays zur Anwendung auf der Haut, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour émulsion pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per spray cutaneo, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung eines Sprays zur Anwendung auf der Haut, Emulsion"
        }
      ]
    },
    {
      "code" : "50009300",
      "display" : "Concentrate for dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion à diluer pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "50009500",
      "display" : "Concentrate for emulsion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Emulsion zur Infusion"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion à diluer pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per emulsione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Emulsion zur Infusion"
        }
      ]
    },
    {
      "code" : "50009750",
      "display" : "Concentrate for intravesical solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "50010000",
      "display" : "Concentrate for oral solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung  zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung  zum Einnehmen"
        }
      ]
    },
    {
      "code" : "50011000",
      "display" : "Concentrate for oral/rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zum Einnehmen /Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution orale/rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione orale/rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Lösung zum Einnehmen /Rektallösung"
        }
      ]
    },
    {
      "code" : "50013250",
      "display" : "Concentrate for solution for peritoneal dialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Peritonealdialyselösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution pour dialyse péritonéale"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione per dialisi peritoneale"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Peritonealdialyselösung"
        }
      ]
    },
    {
      "code" : "50015200",
      "display" : "Cutaneous/nasal ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Salbe zur Anwendung auf der Haut/Nasensalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade cutanée/ nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento cutaneo/nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Salbe zur Anwendung auf der Haut/Nasensalbe"
        }
      ]
    },
    {
      "code" : "50015450",
      "display" : "Cutaneous solution/concentrate for oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung auf der Haut/Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution cutanée/ solution à diluer buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione cutanea/concentrato per soluzione per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung auf der Haut/Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "50015500",
      "display" : "Cutaneous spray, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung auf der Haut, Emulsion"
        },
        {
          "language" : "fr-CH",
          "value" : "Émulsion pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung auf der Haut, Emulsion"
        }
      ]
    },
    {
      "code" : "50016000",
      "display" : "Cutaneous spray, ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spray zur Anwendung auf der Haut, Salbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade pour pulvérisation cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, unguento"
        },
        {
          "language" : "rm-CH",
          "value" : "Spray zur Anwendung auf der Haut, Salbe"
        }
      ]
    },
    {
      "code" : "50017000",
      "display" : "Dental paste",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dentalpaste"
        },
        {
          "language" : "fr-CH",
          "value" : "Pâte dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Spray cutaneo, unguento"
        },
        {
          "language" : "rm-CH",
          "value" : "Dentalpaste"
        }
      ]
    },
    {
      "code" : "50017500",
      "display" : "Dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "50018000",
      "display" : "Ear/eye drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augen-/Ohrentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution auriculaire/ophtalmique en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari/collirio, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augen-/Ohrentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "50018500",
      "display" : "Ear/eye drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augen-/Ohrentropfen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "-"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari/collirio, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augen-/Ohrentropfen, Suspension"
        }
      ]
    },
    {
      "code" : "50019000",
      "display" : "Ear/eye ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augen-/Ohrensalbe"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade auriculaire/ ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento auricolare/oftalmico"
        },
        {
          "language" : "rm-CH",
          "value" : "Augen-/Ohrensalbe"
        }
      ]
    },
    {
      "code" : "50019500",
      "display" : "Ear/eye/nasal drops, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augen-/Ohren-/Nasentropfen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution auriculaire/ ophtalmique/ nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari/collirio/gocce nasali, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augen-/Ohren-/Nasentropfen, Lösung"
        }
      ]
    },
    {
      "code" : "50020200",
      "display" : "Ear/nasal drops, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Augen-/Nasentropfen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension auriculaire/nasale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce auricolari/nasali, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Augen-/Nasentropfen, Suspension"
        }
      ]
    },
    {
      "code" : "50021000",
      "display" : "Emulsion for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Injektion/Infusion"
        },
        {
          "language" : "fr-CH",
          "value" : "Émulsion injectable/pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Emulsione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Injektion/Infusion"
        }
      ]
    },
    {
      "code" : "50022000",
      "display" : "Endosinusial wash, suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nebenhöhlenspülung, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension pour lavage endosinusal"
        },
        {
          "language" : "it-CH",
          "value" : "Lavaggio endosinusale, sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nebenhöhlenspülung, Suspension"
        }
      ]
    },
    {
      "code" : "50024000",
      "display" : "Gargle/mouthwash",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gurgellösung/Mundspülung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour gargarisme/bain de bouche"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per gargarismi/collutorio"
        },
        {
          "language" : "rm-CH",
          "value" : "Gurgellösung/Mundspülung"
        }
      ]
    },
    {
      "code" : "50024500",
      "display" : "Gargle/nasal wash",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gurgellösung/Nasenspülung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour gargarisme/ nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per gargarismi/lavaggio nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "Gurgellösung/Nasenspülung"
        }
      ]
    },
    {
      "code" : "50026000",
      "display" : "Gastro-resistant granules for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "magensaftresistentes Granulat zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés gastrorésistants pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato gastroresistente per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "magensaftresistentes Granulat zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "50029150",
      "display" : "Granules for oral/rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour suspension buvable/rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per sospensione orale/rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
        }
      ]
    },
    {
      "code" : "50029500",
      "display" : "Granules for vaginal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung einer Vaginallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour solution vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato per soluzione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung einer Vaginallösung"
        }
      ]
    },
    {
      "code" : "50030000",
      "display" : "Inhalation powder, tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette mit Pulver zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé pour inhalation par poudre"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per inalazione, compressa"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette mit Pulver zur Inhalation"
        }
      ]
    },
    {
      "code" : "50031000",
      "display" : "Inhalation vapour, effervescent tablet",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brausetablette zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé effervescent pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Vapore  per inalazione, compressa effervescente"
        },
        {
          "language" : "rm-CH",
          "value" : "Brausetablette zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "50032000",
      "display" : "Inhalation vapour, emulsion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Emulsion zur Herstellung eines Dampfs zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Emulsion pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Vapore per inalazione, emulsione"
        },
        {
          "language" : "rm-CH",
          "value" : "Emulsion zur Herstellung eines Dampfs zur Inhalation"
        }
      ]
    },
    {
      "code" : "50033000",
      "display" : "Inhalation vapour, impregnated pad",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
        },
        {
          "language" : "fr-CH",
          "value" : "Tampon imprégné pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Vapore per inalazione, tampone medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
        }
      ]
    },
    {
      "code" : "50033100",
      "display" : "Inhalation vapour, impregnated plug",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
        },
        {
          "language" : "fr-CH",
          "value" : "Support poreux imprégné pour inhalation par vapeur"
        },
        {
          "language" : "it-CH",
          "value" : "Vapore per inalazione, supporto medicato"
        },
        {
          "language" : "rm-CH",
          "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
        }
      ]
    },
    {
      "code" : "50033400",
      "display" : "Intravesical solution/solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur intravesikalen Anwendung/Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution intravésicale/solution injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione endovescicale/soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur intravesikalen Anwendung/Injektionslösung"
        }
      ]
    },
    {
      "code" : "50036000",
      "display" : "Modified-release granules for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat mit veränderter Wirkstofffreisetzung zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés à libération modifiée pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato a rilascio modificato per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat mit veränderter Wirkstofffreisetzung zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "50036050",
      "display" : "Mouthwash, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Mundspülung, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour bain de bouche"
        },
        {
          "language" : "it-CH",
          "value" : "Collutorio, polvere per soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Mundspülung, Lösung"
        }
      ]
    },
    {
      "code" : "50036500",
      "display" : "Nasal/oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur nasalen Anwendung/Lösung zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution nasale/buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione nasale/per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur nasalen Anwendung/Lösung zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "50036700",
      "display" : "Nasal/oromucosal spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray und Spray zur Anwendung in der Mundhöhle, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation nasale/ buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale/per mucosa orale, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray und Spray zur Anwendung in der Mundhöhle, Lösung"
        }
      ]
    },
    {
      "code" : "50037100",
      "display" : "Nasal spray, powder for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray, Pulver zur Herstellung einer Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour pulvérisation nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale, polvere per soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray, Pulver zur Herstellung einer Lösung"
        }
      ]
    },
    {
      "code" : "50037400",
      "display" : "Nasal spray, solution/oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Nasenspray, Lösung/Lösung zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour pulvérisation nasale/ solution buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Spray nasale, soluzione/soluzione per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Nasenspray, Lösung/Lösung zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "50037500",
      "display" : "Oral drops, granules for solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Granulat zur Herstellung von Tropfen zum Einnehmen, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés pour solution buvale en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, granulato per soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Granulat zur Herstellung von Tropfen zum Einnehmen, Lösung"
        }
      ]
    },
    {
      "code" : "50037750",
      "display" : "Oral drops, liquid",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tropfen zum Einnehmen, Flüssigkeit"
        },
        {
          "language" : "fr-CH",
          "value" : "Liquide oral en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, liquido"
        },
        {
          "language" : "rm-CH",
          "value" : "Tropfen zum Einnehmen, Flüssigkeit"
        }
      ]
    },
    {
      "code" : "50037900",
      "display" : "Oral/rectal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zum Einnehmen/Rektallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution buvable/rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione orale/rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zum Einnehmen/Rektallösung"
        }
      ]
    },
    {
      "code" : "50038000",
      "display" : "Oral/rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zum Einnehmen/Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Suspension buvable/rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Sospensione orale/rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zum Einnehmen/Rektalsuspension"
        }
      ]
    },
    {
      "code" : "50038500",
      "display" : "Oral solution/concentrate for nebuliser solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zum Einnehmen/ Konzentrat zur Herstellung einer Lösung für einen Vernebler"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution orale/solution à diluer pour inhalation par nébuliseur"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione orale/concentrato per soluzione per nebulizzatore"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zum Einnehmen/ Konzentrat zur Herstellung einer Lösung für einen Vernebler"
        }
      ]
    },
    {
      "code" : "50039000",
      "display" : "Oromucosal patch",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pflaster zur Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Patch buccal"
        },
        {
          "language" : "it-CH",
          "value" : "Cerotto per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pflaster zur Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "50039500",
      "display" : "Oromucosal/laryngopharyngeal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Anwendung in der Mundhöhle/im Rachenraum und am Kehlkopf"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution buccale/laryngopharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per mucosa orale/laringofaringea"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Anwendung in der Mundhöhle/im Rachenraum und am Kehlkopf"
        }
      ]
    },
    {
      "code" : "50040500",
      "display" : "Oromucosal/laryngopharyngeal solution/spray, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung/Spray zur Anwendung in der Mundhöhle/im Rachenraum oder am Kehlkopf, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution/ solution pour pulvérisation buccale/ laryngopharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per mucosa orale/laringofaringea  o spray per mucosa orale/laringofaringeo, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung/Spray zur Anwendung in der Mundhöhle/im Rachenraum oder am Kehlkopf, Lösung"
        }
      ]
    },
    {
      "code" : "50043000",
      "display" : "Powder for concentrate for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution à diluer pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "50048750",
      "display" : "Powder for concentrate for dispersion for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour dispersion à diluer pour dispersion pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per dispersione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionsdispersion"
        }
      ]
    },
    {
      "code" : "50049100",
      "display" : "Powder for concentrate for intravesical suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Suspension zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension à diluer pour suspension intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per sospensione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Suspension zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "50049200",
      "display" : "Powder for concentrate for solution for haemodialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Hämodialyselösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution à diluer pour solution pour hémodialyse"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per soluzione per emodialisi"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Hämodialyselösung"
        }
      ]
    },
    {
      "code" : "50049250",
      "display" : "Powder for concentrate for solution for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Injektions-/Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution à diluer pour solution injectable/pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per soluzione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver für ein Konzentrat zur Herstellung einer Injektions-/Infusionslösung"
        }
      ]
    },
    {
      "code" : "50049270",
      "display" : "Powder for dental solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Dentallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per concentrato per soluzione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Dentallösung"
        }
      ]
    },
    {
      "code" : "50049300",
      "display" : "Powder for epilesional solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zum Auftragen auf die Wunde"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution épilésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione epilesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zum Auftragen auf die Wunde"
        }
      ]
    },
    {
      "code" : "50049500",
      "display" : "Powder for implantation suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Suspension zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension pour implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione epilesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Suspension zur Implantation"
        }
      ]
    },
    {
      "code" : "50050000",
      "display" : "Powder for intravesical solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "50050500",
      "display" : "Powder for intravesical solution/solution for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung / Injektionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution intravésicale/injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione endovescicale/soluzione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung / Injektionslösung"
        }
      ]
    },
    {
      "code" : "50051000",
      "display" : "Powder for intravesical suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Suspensionen zur intravesikalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Suspensionen zur intravesikalen Anwendung"
        }
      ]
    },
    {
      "code" : "50052000",
      "display" : "Powder for oral/rectal suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension oral/rectal"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per sospensione orale/rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
        }
      ]
    },
    {
      "code" : "50053500",
      "display" : "Powder for solution for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Injektions-/Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution injectable/pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione iniettabile/per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Injektions-/Infusionslösung"
        }
      ]
    },
    {
      "code" : "50056000",
      "display" : "Prolonged-release granules for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Retardgranulat zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Granulés à libération prolongée pour suspension buvable"
        },
        {
          "language" : "it-CH",
          "value" : "Granulato a rilascio prolungato per sospensione orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Retardgranulat zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "50056500",
      "display" : "Radiopharmaceutical precursor, solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Markerzubereitung, Lösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution de précurseur radiopharmaceutique"
        },
        {
          "language" : "it-CH",
          "value" : "Precursore di radionuclidi, soluzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Markerzubereitung, Lösung"
        }
      ]
    },
    {
      "code" : "50057000",
      "display" : "Solution for haemodialysis/haemofiltration",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hämodialyselösung/Hämofiltrationslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour hémodialyse/hémofiltration"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per emodialisi/emofiltrazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Hämodialyselösung/Hämofiltrationslösung"
        }
      ]
    },
    {
      "code" : "50060000",
      "display" : "Solution for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektions-/Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution injectable/pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione iniettabile o per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Injektions-/Infusionslösung"
        }
      ]
    },
    {
      "code" : "50061500",
      "display" : "Solution for sealant",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung für Gewebekleber"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour colle"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per adesivo tissutale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung für Gewebekleber"
        }
      ]
    },
    {
      "code" : "50073000",
      "display" : "Powder for solution for intraocular irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intraokularen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution pour irrigation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione per irrigazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Lösung zur intraokularen Anwendung"
        }
      ]
    },
    {
      "code" : "50073500",
      "display" : "Solution for intraocular irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur intraokularen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution pour irrigation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per irrigazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur intraokularen Anwendung"
        }
      ]
    },
    {
      "code" : "50074000",
      "display" : "Solvent for solution for intraocular irrigation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung einer Lösung zur intraokularen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour solution pour irrigation intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per soluzione per irrigazione intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung einer Lösung zur intraokularen Anwendung"
        }
      ]
    },
    {
      "code" : "50076000",
      "display" : "Solvent for solution for infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösungsmittel zur Herstellung einer Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solvant pour solution pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Solvente per soluzione per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösungsmittel zur Herstellung einer Infusionslösung"
        }
      ]
    },
    {
      "code" : "50077000",
      "display" : "Dispersion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Dispersione per preparazione iniettabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Injektionsdispersion"
        }
      ]
    },
    {
      "code" : "50079000",
      "display" : "Concentrate for solution for injection/infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Konzentrat zur Herstellung einer Injektions- /Infusionslösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à diluer pour solution injectable/pour perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Concentrato per soluzione iniettabile/ per infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Konzentrat zur Herstellung einer Injektions- /Infusionslösung"
        }
      ]
    },
    {
      "code" : "50081000",
      "display" : "Inhalation solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lösung zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à inhaler"
        },
        {
          "language" : "it-CH",
          "value" : "Soluzione per inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Lösung zur Inhalation"
        }
      ]
    },
    {
      "code" : "50082000",
      "display" : "Oral drops, powder for suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung von Tropfen zum Einnehmen, Suspension"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour suspension oral en gouttes"
        },
        {
          "language" : "it-CH",
          "value" : "Gocce orali, polvere per sospensione"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung von Tropfen zum Einnehmen, Suspension"
        }
      ]
    },
    {
      "code" : "13111000",
      "display" : "Powder for vaginal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Pulver zur Herstellung einer Vaginallösung"
        },
        {
          "language" : "fr-CH",
          "value" : "Poudre pour solution vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Polvere per soluzione vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "Pulver zur Herstellung einer Vaginallösung"
        }
      ]
    },
    {
      "code" : "13113000",
      "display" : "Intrauterine gel",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gel zur intrauterinen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Gel intra-utérin"
        },
        {
          "language" : "it-CH",
          "value" : "Gel intrauterino"
        },
        {
          "language" : "rm-CH",
          "value" : "Gel zur intrauterinen Anwendung"
        }
      ]
    },
    {
      "code" : "13115000",
      "display" : "Medicinal leech",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Blutegel zur medizinischen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Sangsue médicinale"
        },
        {
          "language" : "it-CH",
          "value" : "Sanguisuga medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Blutegel zur medizinischen Anwendung"
        }
      ]
    },
    {
      "code" : "13118000",
      "display" : "Tablet with sensor",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Tablette mit Sensor"
        },
        {
          "language" : "fr-CH",
          "value" : "Comprimé avec capteur"
        },
        {
          "language" : "it-CH",
          "value" : "Compressa con sensore"
        },
        {
          "language" : "rm-CH",
          "value" : "Tablette mit Sensor"
        }
      ]
    },
    {
      "code" : "13123000",
      "display" : "Urethral ointment",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Salbe zur Anwendung in der Harnröhre"
        },
        {
          "language" : "fr-CH",
          "value" : "Pommade urétrale"
        },
        {
          "language" : "it-CH",
          "value" : "Unguento uretrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Salbe zur Anwendung in der Harnröhre"
        }
      ]
    },
    {
      "code" : "13124000",
      "display" : "Medicinal larvae",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Larven zur medizinischen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Larves médicinales"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Larven zur medizinischen Anwendung"
        }
      ]
    },
    {
      "code" : "13126000",
      "display" : "Prolonged-release dispersion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Depot-Injektionsdispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Larves médicinales"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Depot-Injektionsdispersion"
        }
      ]
    },
    {
      "code" : "13127000",
      "display" : "Sublingual lyophilisate",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Larves médicinales"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        }
      ]
    },
    {
      "code" : "13128000",
      "display" : "Prolonged-release wound solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        }
      ]
    },
    {
      "code" : "13129000",
      "display" : "Nebuliser dispersion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Lyophilisat zur sublingualen Anwendung"
        }
      ]
    },
    {
      "code" : "13133000",
      "display" : "Gastro-resistant oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magensaftresistente Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Magensaftresistente Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13134000",
      "display" : "Prolonged-release oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Retardsuspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Retardsuspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13135000",
      "display" : "Modified-release oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Suspension zum Einnehmen mit veränderter Wirkstofffreisetzung"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Suspension zum Einnehmen mit veränderter Wirkstofffreisetzung"
        }
      ]
    },
    {
      "code" : "13136000",
      "display" : "Gastro-resistant powder for oral suspension",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Solution à libération prolongée intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13139000",
      "display" : "Concentrate for dispersion for injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion à diluer pour dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13140000",
      "display" : "Cutaneous/oromucosal solution",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion à diluer pour dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "13141000",
      "display" : "Oromucosal pouch",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Dispersion à diluer pour dispersion injectable"
        },
        {
          "language" : "it-CH",
          "value" : "Larva medicinale"
        },
        {
          "language" : "rm-CH",
          "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
        }
      ]
    },
    {
      "code" : "20001000",
      "display" : "Auricular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung am Ohr"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie auriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso auricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung am Ohr"
        }
      ]
    },
    {
      "code" : "20002500",
      "display" : "Buccal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Buccale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie buccogingivale"
        },
        {
          "language" : "it-CH",
          "value" : "Somministrazione buccale"
        },
        {
          "language" : "rm-CH",
          "value" : "Buccale Anwendung"
        }
      ]
    },
    {
      "code" : "20003000",
      "display" : "Cutaneous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung auf der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Uso cutaneo"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung auf der Haut"
        }
      ]
    },
    {
      "code" : "20004000",
      "display" : "Dental use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "dentale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie dentaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso dentale"
        },
        {
          "language" : "rm-CH",
          "value" : "dentale Anwendung"
        }
      ]
    },
    {
      "code" : "20006000",
      "display" : "Endocervical use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "endozervikale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie endocervicale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endocervicale"
        },
        {
          "language" : "rm-CH",
          "value" : "endozervikale Anwendung"
        }
      ]
    },
    {
      "code" : "20007000",
      "display" : "Endosinusial use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung in den Nebenhöhlen"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie endosinusale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endosinusiale"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung in den Nebenhöhlen"
        }
      ]
    },
    {
      "code" : "20008000",
      "display" : "Endotracheopulmonary use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "endotracheopulmonale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie endotrachéobronchique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endotracheobronchiale"
        },
        {
          "language" : "rm-CH",
          "value" : "endotracheopulmonale Anwendung"
        }
      ]
    },
    {
      "code" : "20009000",
      "display" : "Epidural use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "epidurale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie péridurale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso epidurale"
        },
        {
          "language" : "rm-CH",
          "value" : "epidurale Anwendung"
        }
      ]
    },
    {
      "code" : "20010000",
      "display" : "Epilesional use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zum Auftragen auf die Wunde"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie épilésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Uso epilesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "zum Auftragen auf die Wunde"
        }
      ]
    },
    {
      "code" : "20011000",
      "display" : "Extraamniotic use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "extraamniotische Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie extra-amniotique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso extra-amniotico"
        },
        {
          "language" : "rm-CH",
          "value" : "extraamniotische Anwendung"
        }
      ]
    },
    {
      "code" : "20011500",
      "display" : "Extracorporeal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "extrakorporale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie extracorporelle"
        },
        {
          "language" : "it-CH",
          "value" : "Uso extracorporeo"
        },
        {
          "language" : "rm-CH",
          "value" : "extrakorporale Anwendung"
        }
      ]
    },
    {
      "code" : "20087000",
      "display" : "Extrapleural use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "extrapleurale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "voie extrapleural"
        },
        {
          "language" : "it-CH",
          "value" : "uso extrapleurico"
        },
        {
          "language" : "rm-CH",
          "value" : "extrapleurale Anwendung"
        }
      ]
    },
    {
      "code" : "20013000",
      "display" : "Gastroenteral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "gastrointestinale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie gastro-entérale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso gastrointestinale"
        },
        {
          "language" : "rm-CH",
          "value" : "gastrointestinale Anwendung"
        }
      ]
    },
    {
      "code" : "20013500",
      "display" : "Gastric use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Anwendung mittels Magensonde"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie gastrique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso gastrico"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Anwendung mittels Magensonde"
        }
      ]
    },
    {
      "code" : "20014000",
      "display" : "Gingival use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung am Zahnfleisch"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie gingivale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso gengivale"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung am Zahnfleisch"
        }
      ]
    },
    {
      "code" : "20015000",
      "display" : "Haemodialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Hämodialyse"
        },
        {
          "language" : "fr-CH",
          "value" : "Hémodialyse"
        },
        {
          "language" : "it-CH",
          "value" : "Emodialisi"
        },
        {
          "language" : "rm-CH",
          "value" : "Hämodialyse"
        }
      ]
    },
    {
      "code" : "20015500",
      "display" : "Implantation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Implantation"
        }
      ]
    },
    {
      "code" : "20019500",
      "display" : "Infiltration",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Infiltration"
        },
        {
          "language" : "fr-CH",
          "value" : "Infiltration"
        },
        {
          "language" : "it-CH",
          "value" : "Infiltrazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Infiltration"
        }
      ]
    },
    {
      "code" : "20020000",
      "display" : "Inhalation use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie inhalée"
        },
        {
          "language" : "it-CH",
          "value" : "Uso inalatorio"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Inhalation"
        }
      ]
    },
    {
      "code" : "20021000",
      "display" : "Intestinal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intestinale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intestinale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intestinale"
        },
        {
          "language" : "rm-CH",
          "value" : "intestinale Anwendung"
        }
      ]
    },
    {
      "code" : "20022000",
      "display" : "Intraamniotic use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraamniotische Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraamniotique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intra-amniotico"
        },
        {
          "language" : "rm-CH",
          "value" : "intraamniotische Anwendung"
        }
      ]
    },
    {
      "code" : "20023000",
      "display" : "Intraarterial use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraarterielle Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraartérielle"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endoarterioso"
        },
        {
          "language" : "rm-CH",
          "value" : "intraarterielle Anwendung"
        }
      ]
    },
    {
      "code" : "20024000",
      "display" : "Intraarticular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraartikuläre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraarticulaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intra-articolare"
        },
        {
          "language" : "rm-CH",
          "value" : "intraartikuläre Anwendung"
        }
      ]
    },
    {
      "code" : "20025000",
      "display" : "Intrabursal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrabursale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrabursale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intrabursale"
        },
        {
          "language" : "rm-CH",
          "value" : "intrabursale Anwendung"
        }
      ]
    },
    {
      "code" : "20025500",
      "display" : "Intracameral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrakamerale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracamérulaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracamerale"
        },
        {
          "language" : "rm-CH",
          "value" : "intrakamerale Anwendung"
        }
      ]
    },
    {
      "code" : "20026000",
      "display" : "Intracardiac use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intracardiale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracardiaque"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracardiaco"
        },
        {
          "language" : "rm-CH",
          "value" : "intracardiale Anwendung"
        }
      ]
    },
    {
      "code" : "20026500",
      "display" : "Intracartilaginous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrakartilaginäre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracartilagineuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracartilagineo"
        },
        {
          "language" : "rm-CH",
          "value" : "intrakartilaginäre Anwendung"
        }
      ]
    },
    {
      "code" : "20027000",
      "display" : "Intracavernous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrakavernöse Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracaverneuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracavernoso"
        },
        {
          "language" : "rm-CH",
          "value" : "intrakavernöse Anwendung"
        }
      ]
    },
    {
      "code" : "20027010",
      "display" : "Intracerebral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Intrazerebrale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracérébrale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracerebrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Intrazerebrale Anwendung"
        }
      ]
    },
    {
      "code" : "20028000",
      "display" : "Intracervical use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrazervikale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracervicale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracervicale"
        },
        {
          "language" : "rm-CH",
          "value" : "intrazervikale Anwendung"
        }
      ]
    },
    {
      "code" : "20028300",
      "display" : "Intracholangiopancreatic use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Anwendung in der Cholangiopankreatikographie"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracholangiopancréatique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracolangiopancreatico"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Anwendung in der Cholangiopankreatikographie"
        }
      ]
    },
    {
      "code" : "20028500",
      "display" : "Intracisternal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intracisternale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracisternale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracisternale"
        },
        {
          "language" : "rm-CH",
          "value" : "intracisternale Anwendung"
        }
      ]
    },
    {
      "code" : "20029000",
      "display" : "Intracoronary use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrakoronare Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracoronaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracoronarico"
        },
        {
          "language" : "rm-CH",
          "value" : "intrakoronare Anwendung"
        }
      ]
    },
    {
      "code" : "20030000",
      "display" : "Intradermal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intradermale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intradermique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intradermico"
        },
        {
          "language" : "rm-CH",
          "value" : "intradermale Anwendung"
        }
      ]
    },
    {
      "code" : "20031000",
      "display" : "Intradiscal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intradiskale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intradiscale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intradiscale"
        },
        {
          "language" : "rm-CH",
          "value" : "intradiskale Anwendung"
        }
      ]
    },
    {
      "code" : "20031500",
      "display" : "Intraepidermal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraepidermale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraépidermique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraepidermico"
        },
        {
          "language" : "rm-CH",
          "value" : "intraepidermale Anwendung"
        }
      ]
    },
    {
      "code" : "20031700",
      "display" : "Intraglandular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraglanduläre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraglandulaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraghiandolare"
        },
        {
          "language" : "rm-CH",
          "value" : "intraglanduläre Anwendung"
        }
      ]
    },
    {
      "code" : "20032000",
      "display" : "Intralesional use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraläsionale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intralésionnelle"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intralesionale"
        },
        {
          "language" : "rm-CH",
          "value" : "intraläsionale Anwendung"
        }
      ]
    },
    {
      "code" : "20033000",
      "display" : "Intralymphatic use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intralymphatische Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intralymphatique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intralinfatico"
        },
        {
          "language" : "rm-CH",
          "value" : "intralymphatische Anwendung"
        }
      ]
    },
    {
      "code" : "20035000",
      "display" : "Intramuscular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intramuskuläre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intramusculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intramuscolare"
        },
        {
          "language" : "rm-CH",
          "value" : "intramuskuläre Anwendung"
        }
      ]
    },
    {
      "code" : "20036000",
      "display" : "Intraocular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraokulare Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraoculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraoculare"
        },
        {
          "language" : "rm-CH",
          "value" : "intraokulare Anwendung"
        }
      ]
    },
    {
      "code" : "20036500",
      "display" : "Intraosseous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraossäre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraosseuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraosseo"
        },
        {
          "language" : "rm-CH",
          "value" : "intraossäre Anwendung"
        }
      ]
    },
    {
      "code" : "20037000",
      "display" : "Intrapericardial use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Intraperikardial"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrapéricardiaque"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intrapericardico"
        },
        {
          "language" : "rm-CH",
          "value" : "Intraperikardial"
        }
      ]
    },
    {
      "code" : "20038000",
      "display" : "Intraperitoneal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraperitoneale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrapéritonéale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraperitoneale"
        },
        {
          "language" : "rm-CH",
          "value" : "intraperitoneale Anwendung"
        }
      ]
    },
    {
      "code" : "20039000",
      "display" : "Intrapleural use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrapleurale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrapleurale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intrapleurico"
        },
        {
          "language" : "rm-CH",
          "value" : "intrapleurale Anwendung"
        }
      ]
    },
    {
      "code" : "20039200",
      "display" : "Intraportal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraportale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraportale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraportale"
        },
        {
          "language" : "rm-CH",
          "value" : "intraportale Anwendung"
        }
      ]
    },
    {
      "code" : "20039500",
      "display" : "Intraprostatic use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intraprostatische Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraprostatique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intraprostatico"
        },
        {
          "language" : "rm-CH",
          "value" : "intraprostatische Anwendung"
        }
      ]
    },
    {
      "code" : "20041000",
      "display" : "Intrasternal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrasternale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrasternale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intrasternale"
        },
        {
          "language" : "rm-CH",
          "value" : "intrasternale Anwendung"
        }
      ]
    },
    {
      "code" : "20042000",
      "display" : "Intrathecal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrathekale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intrathécale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intratecale"
        },
        {
          "language" : "rm-CH",
          "value" : "intrathekale Anwendung"
        }
      ]
    },
    {
      "code" : "20043000",
      "display" : "Intratumoral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intratumorale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intratumorale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intratumorale"
        },
        {
          "language" : "rm-CH",
          "value" : "intratumorale Anwendung"
        }
      ]
    },
    {
      "code" : "20044000",
      "display" : "Intrauterine use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intrauterine Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intra-utérine"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intrauterino"
        },
        {
          "language" : "rm-CH",
          "value" : "intrauterine Anwendung"
        }
      ]
    },
    {
      "code" : "20045000",
      "display" : "Intravenous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intravenöse Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intraveineuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endovenoso"
        },
        {
          "language" : "rm-CH",
          "value" : "intravenöse Anwendung"
        }
      ]
    },
    {
      "code" : "20046000",
      "display" : "Intravesical use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intravesikale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intravésicale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso endovescicale"
        },
        {
          "language" : "rm-CH",
          "value" : "intravesikale Anwendung"
        }
      ]
    },
    {
      "code" : "20047000",
      "display" : "Intravitreal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Intravitreal"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intravitréenne"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intravitreo"
        },
        {
          "language" : "rm-CH",
          "value" : "Intravitreal"
        }
      ]
    },
    {
      "code" : "20047500",
      "display" : "Iontophoresis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Iontophorese"
        },
        {
          "language" : "fr-CH",
          "value" : "Iontophorèse"
        },
        {
          "language" : "it-CH",
          "value" : "Iontoforesi"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Iontophorese"
        }
      ]
    },
    {
      "code" : "20048000",
      "display" : "Laryngopharyngeal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Anwendung im Rachen und am Kehlkopf"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie laryngopharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Uso laringofaringeo"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Anwendung im Rachen und am Kehlkopf"
        }
      ]
    },
    {
      "code" : "20049000",
      "display" : "Nasal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "nasale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie nasale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso nasale"
        },
        {
          "language" : "rm-CH",
          "value" : "nasale Anwendung"
        }
      ]
    },
    {
      "code" : "20051000",
      "display" : "Ocular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung am Auge"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie ophtalmique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso oftalmico"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung am Auge"
        }
      ]
    },
    {
      "code" : "20053000",
      "display" : "Oral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zum Einnehmen"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie orale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso orale"
        },
        {
          "language" : "rm-CH",
          "value" : "zum Einnehmen"
        }
      ]
    },
    {
      "code" : "20054000",
      "display" : "Oromucosal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung in der Mundhöhle"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie buccale"
        },
        {
          "language" : "it-CH",
          "value" : "Per mucosa orale"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung in der Mundhöhle"
        }
      ]
    },
    {
      "code" : "20055000",
      "display" : "Oropharyngeal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur Anwendung im Mund- und Rachenraum"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie oropharyngée"
        },
        {
          "language" : "it-CH",
          "value" : "Uso orofaringeo"
        },
        {
          "language" : "rm-CH",
          "value" : "zur Anwendung im Mund- und Rachenraum"
        }
      ]
    },
    {
      "code" : "20057000",
      "display" : "Periarticular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "periartikuläre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie périarticulaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso periarticolare"
        },
        {
          "language" : "rm-CH",
          "value" : "periartikuläre Anwendung"
        }
      ]
    },
    {
      "code" : "20058000",
      "display" : "Perineural use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "perineurale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie périneurale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso perineurale"
        },
        {
          "language" : "rm-CH",
          "value" : "perineurale Anwendung"
        }
      ]
    },
    {
      "code" : "20059000",
      "display" : "Periodontal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "zur periodontalen Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie périodontale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso periodontale"
        },
        {
          "language" : "rm-CH",
          "value" : "zur periodontalen Anwendung"
        }
      ]
    },
    {
      "code" : "20059300",
      "display" : "Periosseous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "periossäre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie périosseuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso periosseo"
        },
        {
          "language" : "rm-CH",
          "value" : "periossäre Anwendung"
        }
      ]
    },
    {
      "code" : "20059400",
      "display" : "Peritumoral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "peritumorale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie péritumorale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso peritumorale"
        },
        {
          "language" : "rm-CH",
          "value" : "peritumorale Anwendung"
        }
      ]
    },
    {
      "code" : "20059500",
      "display" : "Posterior juxtascleral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "posteriore juxtasclerale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie juxta-sclérale postérieure"
        },
        {
          "language" : "it-CH",
          "value" : "Uso iuxtasclerale posteriore"
        },
        {
          "language" : "rm-CH",
          "value" : "posteriore juxtasclerale Anwendung"
        }
      ]
    },
    {
      "code" : "20061000",
      "display" : "Rectal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "rektale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie rectale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso rettale"
        },
        {
          "language" : "rm-CH",
          "value" : "rektale Anwendung"
        }
      ]
    },
    {
      "code" : "20061500",
      "display" : "Retrobulbar use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "retrobulbäre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie rétrobulbaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso retrobulbare"
        },
        {
          "language" : "rm-CH",
          "value" : "retrobulbäre Anwendung"
        }
      ]
    },
    {
      "code" : "20062000",
      "display" : "Route of administration not applicable",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Art der Anwendung nicht spezifizierbar"
        },
        {
          "language" : "fr-CH",
          "value" : "Autre(s)"
        },
        {
          "language" : "it-CH",
          "value" : "Via di somministrazione non specificabile"
        },
        {
          "language" : "rm-CH",
          "value" : "Art der Anwendung nicht spezifizierbar"
        }
      ]
    },
    {
      "code" : "20063000",
      "display" : "Skin scarification",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Einritzen der Haut"
        },
        {
          "language" : "fr-CH",
          "value" : "Scarification"
        },
        {
          "language" : "it-CH",
          "value" : "Scarificazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Einritzen der Haut"
        }
      ]
    },
    {
      "code" : "20065000",
      "display" : "Subconjunctival use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "subkonjunktivale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie sous-conjonctivale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso subcongiuntivale"
        },
        {
          "language" : "rm-CH",
          "value" : "subkonjunktivale Anwendung"
        }
      ]
    },
    {
      "code" : "20066000",
      "display" : "Subcutaneous use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "subkutane Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie sous-cutanée"
        },
        {
          "language" : "it-CH",
          "value" : "Uso sottocutaneo"
        },
        {
          "language" : "rm-CH",
          "value" : "subkutane Anwendung"
        }
      ]
    },
    {
      "code" : "20067000",
      "display" : "Sublingual use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sublingual"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie sublinguale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso sublinguale"
        },
        {
          "language" : "rm-CH",
          "value" : "Sublingual"
        }
      ]
    },
    {
      "code" : "20067500",
      "display" : "Submucosal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "submuköse Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie sous-muqueuse"
        },
        {
          "language" : "it-CH",
          "value" : "Uso sottomucosale"
        },
        {
          "language" : "rm-CH",
          "value" : "submuköse Anwendung"
        }
      ]
    },
    {
      "code" : "20070000",
      "display" : "Transdermal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "transdermale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie transdermique"
        },
        {
          "language" : "it-CH",
          "value" : "Uso transdermico"
        },
        {
          "language" : "rm-CH",
          "value" : "transdermale Anwendung"
        }
      ]
    },
    {
      "code" : "20071000",
      "display" : "Urethral use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Anwendung in der Harnröhre"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie urétrale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso uretrale"
        },
        {
          "language" : "rm-CH",
          "value" : "Anwendung in der Harnröhre"
        }
      ]
    },
    {
      "code" : "20072000",
      "display" : "Vaginal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "vaginale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie vaginale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso vaginale"
        },
        {
          "language" : "rm-CH",
          "value" : "vaginale Anwendung"
        }
      ]
    },
    {
      "code" : "20080000",
      "display" : "Intracerebroventricular use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intracerebroventrikuläre Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracérébroventriculaire"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracerebroventricolare"
        },
        {
          "language" : "rm-CH",
          "value" : "intracerebroventrikuläre Anwendung"
        }
      ]
    },
    {
      "code" : "20081000",
      "display" : "Subretinal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "subretinale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie subrétinale"
        },
        {
          "language" : "it-CH",
          "value" : "Uso sottoretinico"
        },
        {
          "language" : "rm-CH",
          "value" : "subretinale Anwendung"
        }
      ]
    },
    {
      "code" : "20084000",
      "display" : "Intracorneal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "intracorneale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "Voie intracornéenne"
        },
        {
          "language" : "it-CH",
          "value" : "Uso intracorneale"
        },
        {
          "language" : "rm-CH",
          "value" : "intracorneale Anwendung"
        }
      ]
    },
    {
      "code" : "20086000",
      "display" : "Intraputaminal use",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Intraputaminale Anwendung"
        },
        {
          "language" : "fr-CH",
          "value" : "null"
        },
        {
          "language" : "it-CH",
          "value" : "Intraputaminale"
        },
        {
          "language" : "rm-CH",
          "value" : "Intraputaminale Anwendung"
        }
      ]
    },
    {
      "code" : "0004",
      "display" : "Administration",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Administration"
        },
        {
          "language" : "fr-CH",
          "value" : "Administration"
        },
        {
          "language" : "it-CH",
          "value" : "Somministrazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Administraziun"
        }
      ]
    },
    {
      "code" : "0005",
      "display" : "Application",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Applikation"
        },
        {
          "language" : "fr-CH",
          "value" : "Application"
        },
        {
          "language" : "it-CH",
          "value" : "Applicazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Applicaziun"
        }
      ]
    },
    {
      "code" : "0006",
      "display" : "Bathing",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Baden"
        },
        {
          "language" : "fr-CH",
          "value" : "Baigner"
        },
        {
          "language" : "it-CH",
          "value" : "Bagnare"
        },
        {
          "language" : "rm-CH",
          "value" : "Bogn"
        }
      ]
    },
    {
      "code" : "0007",
      "display" : "Chewing",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Kauen"
        },
        {
          "language" : "fr-CH",
          "value" : "Mâcher"
        },
        {
          "language" : "it-CH",
          "value" : "Masticare"
        },
        {
          "language" : "rm-CH",
          "value" : "Tschavera"
        }
      ]
    },
    {
      "code" : "0008",
      "display" : "Gargling",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Gurgeln"
        },
        {
          "language" : "fr-CH",
          "value" : "Se gargariser"
        },
        {
          "language" : "it-CH",
          "value" : "Gargarizzare"
        },
        {
          "language" : "rm-CH",
          "value" : "Sgarguglias"
        }
      ]
    },
    {
      "code" : "0009",
      "display" : "Infusion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Infusion"
        },
        {
          "language" : "fr-CH",
          "value" : "Perfusion"
        },
        {
          "language" : "it-CH",
          "value" : "Infusione"
        },
        {
          "language" : "rm-CH",
          "value" : "Infusiun"
        }
      ]
    },
    {
      "code" : "0010",
      "display" : "Inhalation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Inhalation"
        },
        {
          "language" : "fr-CH",
          "value" : "Inhalation"
        },
        {
          "language" : "it-CH",
          "value" : "Inalazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Inhalaziun"
        }
      ]
    },
    {
      "code" : "0011",
      "display" : "Injection",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Injektion"
        },
        {
          "language" : "fr-CH",
          "value" : "Injection"
        },
        {
          "language" : "it-CH",
          "value" : "Iniezione"
        },
        {
          "language" : "rm-CH",
          "value" : "Injecziun"
        }
      ]
    },
    {
      "code" : "0012",
      "display" : "Insertion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Insertion"
        },
        {
          "language" : "fr-CH",
          "value" : "Insertion"
        },
        {
          "language" : "it-CH",
          "value" : "Inserzione"
        },
        {
          "language" : "rm-CH",
          "value" : "Inserziun"
        }
      ]
    },
    {
      "code" : "0013",
      "display" : "Instillation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Instillation"
        },
        {
          "language" : "fr-CH",
          "value" : "Instillation"
        },
        {
          "language" : "it-CH",
          "value" : "Instillazione"
        },
        {
          "language" : "rm-CH",
          "value" : "Installaziun"
        }
      ]
    },
    {
      "code" : "0014",
      "display" : "Orodispersion",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Orodispersion"
        },
        {
          "language" : "fr-CH",
          "value" : "Orodispersion"
        },
        {
          "language" : "it-CH",
          "value" : "Orodispersione"
        },
        {
          "language" : "rm-CH",
          "value" : "Dispersiun d'odi"
        }
      ]
    },
    {
      "code" : "0015",
      "display" : "Rinsing/washing",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Spülen/Waschen"
        },
        {
          "language" : "fr-CH",
          "value" : "Rincer/Laver"
        },
        {
          "language" : "it-CH",
          "value" : "Sciacquare/Lavare"
        },
        {
          "language" : "rm-CH",
          "value" : "Derschentar/Lavar"
        }
      ]
    },
    {
      "code" : "0017",
      "display" : "Spraying",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Sprühen"
        },
        {
          "language" : "fr-CH",
          "value" : "Pulvériser"
        },
        {
          "language" : "it-CH",
          "value" : "Spray"
        },
        {
          "language" : "rm-CH",
          "value" : "Squitta"
        }
      ]
    },
    {
      "code" : "0018",
      "display" : "Sucking",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Lutschen"
        },
        {
          "language" : "fr-CH",
          "value" : "Sucer"
        },
        {
          "language" : "it-CH",
          "value" : "Succhiare"
        },
        {
          "language" : "rm-CH",
          "value" : "Luschezza"
        }
      ]
    },
    {
      "code" : "0019",
      "display" : "Swallowing",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Schlucken"
        },
        {
          "language" : "fr-CH",
          "value" : "Avaler"
        },
        {
          "language" : "it-CH",
          "value" : "Per deglutizione"
        },
        {
          "language" : "rm-CH",
          "value" : "Tragutter"
        }
      ]
    },
    {
      "code" : "0020",
      "display" : "Not specified",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Keine Angaben"
        },
        {
          "language" : "fr-CH",
          "value" : "Non spécifié"
        },
        {
          "language" : "it-CH",
          "value" : "Non specificato"
        },
        {
          "language" : "rm-CH",
          "value" : "Naginas indicaziuns"
        }
      ]
    },
    {
      "code" : "0111",
      "display" : "Burning",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Brennen"
        },
        {
          "language" : "fr-CH",
          "value" : "Brûler"
        },
        {
          "language" : "it-CH",
          "value" : "Bruciare"
        },
        {
          "language" : "rm-CH",
          "value" : "Arder"
        }
      ]
    },
    {
      "code" : "0112",
      "display" : "Dialysis",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Dialyse"
        },
        {
          "language" : "fr-CH",
          "value" : "Dialyse"
        },
        {
          "language" : "it-CH",
          "value" : "Dialisi"
        },
        {
          "language" : "rm-CH",
          "value" : "Dialisa"
        }
      ]
    },
    {
      "code" : "0113",
      "display" : "Implantation",
      "designation" : [
        {
          "language" : "de-CH",
          "value" : "Implantation"
        },
        {
          "language" : "fr-CH",
          "value" : "Implantation"
        },
        {
          "language" : "it-CH",
          "value" : "Impianto"
        },
        {
          "language" : "rm-CH",
          "value" : "Implantaziun"
        }
      ]
    }
  ]
}

```
