# Home - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-term/ImplementationGuide/ch.fhir.ig.ch-term | *Version*:3.3.0 |
| Active as of 2025-12-15 | *Computable Name*:CH_TERM |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

This FHIR® implementation guide contains terminology that is used in Switzerland for the core profiles, various exchange formats and also in the context of the Swiss electronic patient record (EPR). See also [fhir.ch](https://fhir.ch/).

The EPR metadata is specified in the Annexes of the Swiss EPR [FDHA Ordinance](https://www.bag.admin.ch/bag/de/home/gesetze-und-bewilligungen/gesetzgebung/gesetzgebung-mensch-gesundheit/gesetzgebung-elektronisches-patientendossier.html) on the electronic patient record in Switzerland. 
 The EPR artifacts are based on the [CH-EPR](http://ehealthsuisse.art-decor.org/index.php?prefix=ch-epr-) [ART-DECOR](https://www.art-decor.org/mediawiki/index.php/Main_Page) project which has been [published by eHealth Suisse](http://ehealthsuisse.art-decor.org/).

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in [npm format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](package.tgz).

### Scope

This implementation guide contains the Swiss terminology defined via FHIR processable artifacts:

* [Code Systems](codesystems.md)
* [Value Sets](valuesets.md)
* [Concept Maps](conceptmaps.md)
* [Naming Systems](namingsystems.md)

#### Finding Usage Context

Since this implementation guide focuses only on terminology artifacts, it does not indicate where these individual instances are used. The terminology resources defined here are referenced and used by other Swiss FHIR implementation guides. 
 To find the usage context of these terminology artifacts, the [dependent IGs analysis](https://fhir.ch/ig/ch-term/qa-dep.html) can be used. It shows which other implementation guides refer to the terminology resources defined in this guide and are dependent on them.

### Collaboration & Governance

This implementation guide is the result of collaborative work undertaken with participants from [HL7 Switzerland](https://www.hl7.ch) and [eHealth Suisse](https://www.e-health-suisse.ch/startseite.html).

* A yearly major release is foreseen to support the Swiss balloted IGs, with an interim version published to support the HL7 Switzerland ballot phase.
* Additions or changes can only be made through pull requests (PRs) reviewed by the leader of the working group or the HL7 Switzerland technical manager. In addition, PRs must be reviewed and accepted by the leader of the respective HL7 Switzerland working groups, if the terminology resources are used within their implementation guides.
* Patch releases can be made upon request to the FHIR working group. Dependent IGs on CH Term should allow patched versions.
* For terminology resources where CH Term is not the authority or master, the conformance resource needs to indicate the authority in `meta.source` (see [example](https://fhir.ch/ig/ch-term/ValueSet-DocumentEntry.authorRole.json.html) for ART-DECOR).
* Only stable versions of ValueSets are published when there are multiple versions of ValueSets (e.g. DocumentEntry.typeCode), due to the fact that the tooling currently supports only one version ([background](https://github.com/hl7ch/ch-term/issues/5)).

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [BFS Medizinische Statistik - 17 1.2.V02 - Aufenthaltsort vor dem Eintritt / Séjour avant l’admission / Luogo di soggiorno prima dell’ammissione](CodeSystem-bfs-medstats-17-admitsource.md): [BfsMedstats17Admitsource](ValueSet-bfs-medstats-17-admitsource.md)
* [BFS Medizinische Statistik - 18 1.2.V03 - Eintrittsart / Mode d’admission / Genere di ricovero](CodeSystem-bfs-medstats-18-admittype.md): [BfsMedstats18Admittype](ValueSet-bfs-medstats-18-admittype.md)
* [BFS Medizinische Statistik - 19 1.2.V04 - Einweisende Instanz / Décision d’envoi / Istanza ricoverante](CodeSystem-bfs-medstats-19-admitrole.md): [BfsMedstats19Admitrole](ValueSet-bfs-medstats-19-admitrole.md)
* [BFS Medizinische Statistik - 20 1.3.V01 - Behandlungsart / Type de prise en charge / Genere di trattamento](CodeSystem-bfs-medstats-20-encounterclass.md): [BfsMedstats20Encounterclass](ValueSet-bfs-medstats-20-encounterclass.md)
* [BFS Medizinische Statistik - 21 1.3.V02 - Klasse / Classe / Classe](CodeSystem-bfs-medstats-21-encountertype.md): [BfsMedstats21Encountertype](ValueSet-bfs-medstats-21-encountertype.md)
* [BFS Medizinische Statistik - 25 1.4.V02 - Hauptkostenträger für Grundversicherungsleistungen / Prise en charge des soins de base / Unità d’imputazione principale per le prestazioni dell’assicurazione di base](CodeSystem-bfs-medstats-25-mainguarantor.md): [MainGuarantor](ValueSet-mainguarantor.md)
* [BFS Medizinische Statistik - 27 1.5.V02 - Entscheid für Austritt / Décision de sortie / Décisione dell’uscita](CodeSystem-bfs-medstats-27-dischargedecision.md): [BfsMedstats27Dischargedecision](ValueSet-bfs-medstats-27-dischargedecision.md)
* [BFS Medizinische Statistik - 28 1.5.V03 - Aufenthalt nach Austritt / Séjour après la sortie / Destinazione dopo l’uscita](CodeSystem-bfs-medstats-28-dischargedestination.md): [BfsMedstats28Dischargedestination](ValueSet-bfs-medstats-28-dischargedestination.md)
* [BFS Medizinische Statistik - 29 1.5.V04 - Behandlung nach Austritt / Prise en charge après la sortie / Trattamento dopo l’uscita](CodeSystem-bfs-medstats-29-dischargeencounter.md): [BfsMedstats29Dischargeencounter](ValueSet-bfs-medstats-29-dischargeencounter.md)
* [eCH-010 Types](CodeSystem-ech-10.md): [ECH10AddressLine](ValueSet-ech-10-linetype.md)
* [eCH-011 Types](CodeSystem-ech-11.md): [ECH11FirstNameDataTypes](ValueSet-ech-11-firstnamedatatype.md) and [ECH11NameDataTypes](ValueSet-ech-11-namedatatype.md)
* [eCH-011 MaritalData Separation](CodeSystem-ech-11-maritaldata-separation.md): [ECH11MaritaldataSeparation](ValueSet-ech-11-maritaldata-separation.md)
* [eCH-011 MaritalStatus](CodeSystem-ech-11-maritalstatus.md): [ChCoreMaritalStatus](ValueSet-ch-core-maritalstatus.md) and [ECH11MaritalStatus](ValueSet-ech-11-maritalstatus.md)
* [eCH-011 Religion](CodeSystem-ech-11-religion.md): [ChCoreReligion](ValueSet-ch-core-religion.md)
* [eCH-011 Sex](CodeSystem-ech-11-sex.md): [ECH11Sex](ValueSet-ech-11-sex.md)
* [eCH-0046 Email Category](CodeSystem-ech-46-emailcategory.md): [ECH46EmailCategory](ValueSet-ech-46-emailcategory.md)
* [eCH-0046 Internet Category](CodeSystem-ech-46-internetcategory.md): [ECH46InternetCategory](ValueSet-ech-46-internetcategory.md)
* [eCH-0046 Phone Category](CodeSystem-ech-46-phonecategory.md): [ECH46PhoneCategory](ValueSet-ech-46-phonecategory.md)
* [eCH-0007 Canton Abbreviation incl. FL (Fürstentum Liechtenstein)](CodeSystem-ech-7-cantonflabbreviation.md): [ECH007CantonAbbreviation](ValueSet-ech-7-cantonabbreviation.md) and [VSECH007CantonFLAbbreviation](ValueSet-ech-7-cantonflabbreviation.md)
* [Main guarantor](CodeSystem-mainguarantor.md): [MainGuarantor](ValueSet-mainguarantor.md)
* [Condition Category](CodeSystem-ch-etoc-conditioncategory.md): [ConditionCategoryCodes](ValueSet-condition-category.md)
* [ServiceRequest Category](CodeSystem-servicerequest-category.md): [VSServiceRequestCategory](ValueSet-servicerequest-category.md)
* [CH VACD Old Swiss Vaccines](CodeSystem-ch-vacd-myvaccines-cs.md): [OldSwissVaccines](ValueSet-ch-vacd-oldswiss-vaccines-vs.md)
* [CH VACD Swiss Immunization Recommendation Categories](CodeSystem-ch-vacd-recommendation-categories-cs.md): [SwissImmunizationRecommendationCategories](ValueSet-ch-vacd-recommendation-categories-vs.md)
* [CH VACD Swiss Recommendation Forecast Status](CodeSystem-ch-vacd-recommendation-forecast-status-cs.md): [SwissRecommendationForecastStatus](ValueSet-ch-vacd-recommendation-forecast-status-vs.md)
* [CH VACD Swissmedic Authorized Vaccines](CodeSystem-ch-vacd-swissmedic-cs.md): [SwissMedicVaccines](ValueSet-ch-vacd-swissmedic-vaccines-vs.md)
* [CH VACD Swissmedic Authorized Immunsera Codes](CodeSystem-ch-vacd-swissmedic-immunesera-cs.md): [SwissImmunsera](ValueSet-ch-vacd-swissmedic-immunesera-vs.md)
* [CH VACD Swissmedic Authorized Immunoglobulin Codes](CodeSystem-ch-vacd-swissmedic-immunoglobulin-cs.md): [SwissImunoglobulin](ValueSet-ch-vacd-swissmedic-immunoglobulin-vs.md)
* [EDQM - Standard Terms](CodeSystem-edqm-standardterms.md): [AdministrationMethodEDQM](ValueSet-edqm-administrationmethod.md), [PharmaceuticalDoseFormEDQM](ValueSet-edqm-pharmaceuticaldoseform.md) and [RouteOfAdministrationEDQM](ValueSet-edqm-routeofadministration.md)
* [DICOM Unique Identifiers (UIDs)](CodeSystem-dcmuid.md): [DocumentEntryFormatCode](ValueSet-DocumentEntry.formatCode.md)
* [IHE Pharmaceutical Advice Status List](CodeSystem-ihe-pharmaceuticaladvicestatuslist.md): [IHEPharmaceuticalAdviceStatusList](ValueSet-ihe-pharmaceuticaladvicestatuslist.md)
* [ch-ehealth-codesystem-language](CodeSystem-2.16.756.5.30.1.127.3.10.12.md): [DocumentEntryLanguageCode](ValueSet-DocumentEntry.languageCode.md)
* [ch-ehealth-codesystem-agentRole](CodeSystem-2.16.756.5.30.1.127.3.10.14.md): [EprAgentRole](ValueSet-EprAgentRole.md)
* [ch-ehealth-codesystem-eprdeletionstatus](CodeSystem-2.16.756.5.30.1.127.3.10.18.md): [DocumentEntryExtEprDeletionStauts](ValueSet-DocumentEntry.Ext.EprDeletionStatus.md)
* [ch-ehealth-codesystem-purposeOfUse](CodeSystem-2.16.756.5.30.1.127.3.10.5.md): [EprPurposeOfUse](ValueSet-EprPurposeOfUse.md)
* [ch-ehealth-codesystem-role](CodeSystem-2.16.756.5.30.1.127.3.10.6.md): [DocumentEntryAuthorRole](ValueSet-DocumentEntry.authorRole.md), [DocumentEntryOriginalProviderRole](ValueSet-DocumentEntry.originalProviderRole.md), [EprRole](ValueSet-EprRole.md) and [SubmissionSetAuthorAuthorRole](ValueSet-SubmissionSet.Author.AuthorRole.md)
* [ch-ehealth-codesystem-atc](CodeSystem-2.16.756.5.30.1.127.3.10.7.md): [EprAuditTrailConsumptionEventType](ValueSet-EprAuditTrailConsumptionEventType.md)
* [ch-ehealth-codesystem-medreg](CodeSystem-2.16.756.5.30.1.127.3.5.md): [DocumentEntryAuthorSpeciality](ValueSet-DocumentEntry.authorSpeciality.md) and [HCProfessionalHcSpecialisation](ValueSet-HCProfessional.hcSpecialisation.md)
* [ch-ehealth-codesystem-nareg](CodeSystem-2.16.756.5.30.1.127.3.6.md): [DocumentEntryAuthorSpeciality](ValueSet-DocumentEntry.authorSpeciality.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.3.0/CodeSystem-ISO3166Part1.html): [AHVN13](NamingSystem-ahvn13.md), [ActSubstanceAdminSubstitutionCode](ValueSet-ActSubstanceAdminSubstitutionCode.md)...Show 131 more,[ActivePharmaceuticalIngredient](ValueSet-ActivePharmaceuticalIngredient.md),[AdministrationMethodEDQM](ValueSet-edqm-administrationmethod.md),[AllergyIntoleranceCategory](CodeSystem-allergyintolerance-category-supplement.md),[AllergyIntoleranceClinicalStatus](CodeSystem-allergyintolerance-clinical-supplement.md),[AllergyIntoleranceCriticalityStatus](CodeSystem-allergyintolerance-criticality-supplement.md),[AllergyIntoleranceSeverityStatus](CodeSystem-allergyintolerance-severity-supplement.md),[AllergyIntoleranceType](CodeSystem-allergyintolerance-type-supplement.md),[AllergyIntoleranceVerificationStatus](CodeSystem-allergyintolerance-verification-supplement.md),[BER](NamingSystem-ber.md),[BfsCountryCodes](ValueSet-bfs-country-codes.md),[BfsEncounterClassToFhir](ConceptMap-bfs-encounter-class-to-fhir.md),[BfsMedstats17Admitsource](ValueSet-bfs-medstats-17-admitsource.md),[BfsMedstats17Admittype](CodeSystem-bfs-medstats-18-admittype.md),[BfsMedstats18Admittype](ValueSet-bfs-medstats-18-admittype.md),[BfsMedstats19Admitrole](ValueSet-bfs-medstats-19-admitrole.md),[BfsMedstats20Encounterclass](ValueSet-bfs-medstats-20-encounterclass.md),[BfsMedstats21Encountertype](ValueSet-bfs-medstats-21-encountertype.md),[BfsMedstats25Mainguarantor](CodeSystem-bfs-medstats-25-mainguarantor.md),[BfsMedstats27Dischargedecision](ValueSet-bfs-medstats-27-dischargedecision.md),[BfsMedstats28Dischargedestination](ValueSet-bfs-medstats-28-dischargedestination.md),[BfsMedstats29Dischargeencounter](ValueSet-bfs-medstats-29-dischargeencounter.md),[CHAllergyIntoleranceConditionValueSet](ValueSet-CHAllergyIntoleranceConditionValueSet.md),[CHAllergyIntoleranceReactionManifestationValueSet](ValueSet-CHAllergyIntoleranceReactionManifestationValueSet.md),[CHAllergyIntoleranceReactionSubstanceValueSet](ValueSet-CHAllergyIntoleranceReactionSubstanceValueSet.md),[CHAllergyIntoleranceValueSet](ValueSet-CHAllergyIntoleranceValueSet.md),[CH_TERM](index.md),[CSECH007CantonFLAbbreviation](CodeSystem-ech-7-cantonflabbreviation.md),[CSServiceRequestCategory](CodeSystem-servicerequest-category.md),[ChCoreEncounterParticipationType](ValueSet-ch-core-encounter-participation-type.md),[ChCoreMaritalStatus](ValueSet-ch-core-maritalstatus.md),[ChCoreReligion](ValueSet-ch-core-religion.md),[ChEhealthCodesystemAgentRole](CodeSystem-2.16.756.5.30.1.127.3.10.14.md),[ChEhealthCodesystemAtc](CodeSystem-2.16.756.5.30.1.127.3.10.7.md),[ChEhealthCodesystemEprDeletionStatus](CodeSystem-2.16.756.5.30.1.127.3.10.18.md),[ChEhealthCodesystemFormat](CodeSystem-2.16.756.5.30.1.127.3.10.10.md),[ChEhealthCodesystemHpd](CodeSystem-2.16.756.5.30.1.127.3.10.9.md),[ChEhealthCodesystemLanguage](CodeSystem-2.16.756.5.30.1.127.3.10.12.md),[ChEhealthCodesystemMedreg](CodeSystem-2.16.756.5.30.1.127.3.5.md),[ChEhealthCodesystemNareg](CodeSystem-2.16.756.5.30.1.127.3.6.md),[ChEhealthCodesystemPurposeOfUse](CodeSystem-2.16.756.5.30.1.127.3.10.5.md),[ChEhealthCodesystemRole](CodeSystem-2.16.756.5.30.1.127.3.10.6.md),[ChEtocConditionCategory](CodeSystem-ch-etoc-conditioncategory.md),[ChVacdTargetDiseasesAndIllnessesUndergoneForImmunization](ValueSet-ch-vacd-targetdiseasesandillnessesundergoneforimmunization-vs.md),[ConditionCategoryCodes](ValueSet-condition-category.md),[DCMUID](CodeSystem-dcmuid.md),[DocumentEntryAuthorRole](ValueSet-DocumentEntry.authorRole.md),[DocumentEntryAuthorSpeciality](ValueSet-DocumentEntry.authorSpeciality.md),[DocumentEntryClassCode](ValueSet-DocumentEntry.classCode.md),[DocumentEntryClassCodeToDocumentEntryTypeCode](ConceptMap-DocumentEntryClassCodeToDocumentEntryTypeCode.md),[DocumentEntryConfidentialityCode](ValueSet-DocumentEntry.confidentialityCode.md),[DocumentEntryConfidentialityCodeToFHIRMapping](ConceptMap-documententry-confidentialitycode-to-fhir.md),[DocumentEntryEventCodeList](ValueSet-DocumentEntry.eventCodeList.md),[DocumentEntryExtEprDeletionStauts](ValueSet-DocumentEntry.Ext.EprDeletionStatus.md),[DocumentEntryFormatCode](ValueSet-DocumentEntry.formatCode.md),[DocumentEntryHealthcareFacilityTypeCode](ValueSet-DocumentEntry.healthcareFacilityTypeCode.md),[DocumentEntryLanguageCode](ValueSet-DocumentEntry.languageCode.md),[DocumentEntryMimeType](ValueSet-DocumentEntry.mimeType.md),[DocumentEntryOriginalProviderRole](ValueSet-DocumentEntry.originalProviderRole.md),[DocumentEntryPracticeSettingCode](ValueSet-DocumentEntry.practiceSettingCode.md),[DocumentEntrySourcePatientInfoPID8](ValueSet-DocumentEntry.sourcePatientInfo.PID-8.md),[DocumentEntryTypeCode](ValueSet-DocumentEntry.typeCode.md),[ECH007CantonAbbreviation](ValueSet-ech-7-cantonabbreviation.md),[ECH10AddressLine](ValueSet-ech-10-linetype.md),[ECH11CodeSystem](CodeSystem-ech-11.md),[ECH11FirstNameDataTypes](ValueSet-ech-11-firstnamedatatype.md),[ECH11MaritalStatus](ValueSet-ech-11-maritalstatus.md),[ECH11MaritaldataSeparation](ValueSet-ech-11-maritaldata-separation.md),[ECH11NameDataTypes](ValueSet-ech-11-namedatatype.md),[ECH11Religion](CodeSystem-ech-11-religion.md),[ECH11Sex](ValueSet-ech-11-sex.md),[ECH11maritalstatus](CodeSystem-ech-11-maritalstatus.md),[ECH11sex](CodeSystem-ech-11-sex.md),[ECH46EmailCategory](ValueSet-ech-46-emailcategory.md),[ECH46EmailCategoryToFHIRMapping](ConceptMap-ech-46-emailcategory-to-fhir.md),[ECH46InternetCategory](ValueSet-ech-46-internetcategory.md),[ECH46InternetCategoryToFHIRMapping](ConceptMap-ech-46-internetcategory-to-fhir.md),[ECH46PhoneCategory](ValueSet-ech-46-phonecategory.md),[ECH46PhoneCategoryToFHIRMapping](ConceptMap-ech-46-phonecategory-to-fhir.md),[EPR_SPID](NamingSystem-epr-spid.md),[EdqmStandardTerms](CodeSystem-edqm-standardterms.md),[EprAgentRole](ValueSet-EprAgentRole.md),[EprAuditTrailConsumptionEventType](ValueSet-EprAuditTrailConsumptionEventType.md),[EprPurposeOfUse](ValueSet-EprPurposeOfUse.md),[EprRole](ValueSet-EprRole.md),[EventTiming](CodeSystem-event-timing.md),[ForumDatenaustauschTariffType](NamingSystem-forum-datenaustausch-tariff.md),[GLN](NamingSystem-gln.md),[GTIN](NamingSystem-gtin.md),[HCProfessionalHCProfessionSpecialisationMap](ConceptMap-HCProfessionalHCProfessionSpecialisationMap.md),[HCProfessionalHcProfession](ValueSet-HCProfessional.hcProfession.md),[HCProfessionalHcSpecialisation](ValueSet-HCProfessional.hcSpecialisation.md),[IHEPharmaceuticalAdviceStatusList](ValueSet-ihe-pharmaceuticaladvicestatuslist.md),[ImmunGlobulineToTargetDiseaseMapping](ConceptMap-ch-vacd-immunoglobulin-targetdiseases-cm.md),[InsuranceCardNumber](NamingSystem-veka.md),[MainGuarantor](ValueSet-mainguarantor.md),[Mainguarantor](CodeSystem-mainguarantor.md),[MaritalStatusECH011ToFHIRMapping](ConceptMap-maritalstatus-ech11-to-fhir.md),[OldSwissVaccines](ValueSet-ch-vacd-oldswiss-vaccines-vs.md),[OldSwissVaccinesCodesystem](CodeSystem-ch-vacd-myvaccines-cs.md),[PharmaceuticalDoseFormEDQM](ValueSet-edqm-pharmaceuticaldoseform.md),[RouteOfAdministrationEDQM](ValueSet-edqm-routeofadministration.md),[RouteOfAdministrationImmunization](ValueSet-ch-vacd-route-of-administration-vs.md),[SexECH011ToFHIRMapping](ConceptMap-sex-ech11-to-fhir.md),[SnomedCTConceptViralDiseases](ValueSet-snomedct-concept-viraldiseases-vs.md),[SnomedCTForVaccineCode](ValueSet-ch-vacd-vaccines-snomedct-vs.md),[SnomedCTVaccineCodeToTargetDiseaseMapping](ConceptMap-ch-vacd-vaccines-sct-targetdiseases-cm.md),[SubmissionSetAuthorAuthorRole](ValueSet-SubmissionSet.Author.AuthorRole.md),[SubmissionSetContentTypeCode](ValueSet-SubmissionSet.contentTypeCode.md),[SwissImmunizationRecommendationCategories](ValueSet-ch-vacd-recommendation-categories-vs.md),[SwissImmunizationRecommendationCategoriesCodesystem](CodeSystem-ch-vacd-recommendation-categories-cs.md),[SwissImmunsera](ValueSet-ch-vacd-swissmedic-immunesera-vs.md),[SwissImunoglobulin](ValueSet-ch-vacd-swissmedic-immunoglobulin-vs.md),[SwissMedicAuthorizedImmuneseraCodesystem](CodeSystem-ch-vacd-swissmedic-immunesera-cs.md),[SwissMedicAuthorizedImmunoGlobulinCodesystem](CodeSystem-ch-vacd-swissmedic-immunoglobulin-cs.md),[SwissMedicAuthorizedVaccinesCodesystem](CodeSystem-ch-vacd-swissmedic-cs.md),[SwissMedicVaccines](ValueSet-ch-vacd-swissmedic-vaccines-vs.md),[SwissRecommendationForecastStatus](ValueSet-ch-vacd-recommendation-forecast-status-vs.md),[SwissRecommendationForecastStatusCodesystem](CodeSystem-ch-vacd-recommendation-forecast-status-cs.md),[SwissVaccinationPlanImmunizations](ValueSet-ch-vacd-ch-vaccination-plan-immunizations-vs.md),[SwissVaccines](ValueSet-ch-vacd-vaccines-vs.md),[TargetDiseaseToVaccineCodeMapping](ConceptMap-ch-vacd-targetdiseases-vaccines-cm.md),[TimingEvent](CodeSystem-v3-TimingEvent.md),[TreatmentReason](ValueSet-treatmentreason.md),[UIDB](NamingSystem-uidb.md),[UnitCode](ValueSet-UnitCode.md),[VSECH007CantonFLAbbreviation](ValueSet-ech-7-cantonflabbreviation.md),[VSServiceRequestCategory](ValueSet-servicerequest-category.md),[VaccineCodeSCTToVaccineCodeSM](ConceptMap-ch-vacd-vaccines-sct-sm-cm.md),[VaccineCodeSMToVaccineCodeSCT](ConceptMap-ch-vacd-vaccines-sm-sct-cm.md),[VaccineCodeToTargetDiseaseMapping](ConceptMap-ch-vacd-vaccines-targetdiseases-cm.md)and[ZSR](NamingSystem-zsr.md)


* Some content from IHE® Copyright © 2015 [IHE International, Inc](http://www.ihe.net/Governance/#Intellectual_Property) .

* [IHE Format Code set for use with Document Sharing](https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.4.0/CodeSystem-formatcode.html): [DocumentEntryFormatCode](ValueSet-DocumentEntry.formatCode.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.3.0/CodeSystem-v3-ucum.html): [UnitCode](ValueSet-UnitCode.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [DICOM Controlled Terminology Definitions](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html): [DocumentEntryEventCodeList](ValueSet-DocumentEntry.eventCodeList.md)


* This artefact includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license - for more information contact [http://www.snomed.org/snomed-ct/getsnomed-ct](http://www.snomed.org/snomed-ct/getsnomed-ct) or info@snomed.org.

* [ch-ehealth-codesystem-format](CodeSystem-2.16.756.5.30.1.127.3.10.10.md): [DocumentEntryFormatCode](ValueSet-DocumentEntry.formatCode.md)
* [ch-ehealth-codesystem-hpd](CodeSystem-2.16.756.5.30.1.127.3.10.9.md): [HCProfessionalHcProfession](ValueSet-HCProfessional.hcProfession.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [ActivePharmaceuticalIngredient](ValueSet-ActivePharmaceuticalIngredient.md), [CHAllergyIntoleranceConditionValueSet](ValueSet-CHAllergyIntoleranceConditionValueSet.md)...Show 18 more,[CHAllergyIntoleranceReactionManifestationValueSet](ValueSet-CHAllergyIntoleranceReactionManifestationValueSet.md),[CHAllergyIntoleranceReactionSubstanceValueSet](ValueSet-CHAllergyIntoleranceReactionSubstanceValueSet.md),[CHAllergyIntoleranceValueSet](ValueSet-CHAllergyIntoleranceValueSet.md),[ChVacdTargetDiseasesAndIllnessesUndergoneForImmunization](ValueSet-ch-vacd-targetdiseasesandillnessesundergoneforimmunization-vs.md),[DocumentEntryClassCode](ValueSet-DocumentEntry.classCode.md),[DocumentEntryConfidentialityCode](ValueSet-DocumentEntry.confidentialityCode.md),[DocumentEntryHealthcareFacilityTypeCode](ValueSet-DocumentEntry.healthcareFacilityTypeCode.md),[DocumentEntryPracticeSettingCode](ValueSet-DocumentEntry.practiceSettingCode.md),[DocumentEntryTypeCode](ValueSet-DocumentEntry.typeCode.md),[HCProfessionalHcProfession](ValueSet-HCProfessional.hcProfession.md),[SnomedCTConceptViralDiseases](ValueSet-snomedct-concept-viraldiseases-vs.md),[SnomedCTForVaccineCode](ValueSet-ch-vacd-vaccines-snomedct-vs.md),[SubmissionSetContentTypeCode](ValueSet-SubmissionSet.contentTypeCode.md),[SwissImmunizationRecommendationCategories](ValueSet-ch-vacd-recommendation-categories-vs.md),[SwissVaccinationPlanImmunizations](ValueSet-ch-vacd-ch-vaccination-plan-immunizations-vs.md),[SwissVaccines](ValueSet-ch-vacd-vaccines-vs.md),[TreatmentReason](ValueSet-treatmentreason.md)and[UnitCode](ValueSet-UnitCode.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html): [AllergyIntoleranceClinicalStatus](CodeSystem-allergyintolerance-clinical-supplement.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-verification.html): [AllergyIntoleranceVerificationStatus](CodeSystem-allergyintolerance-verification-supplement.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [AHVN13](NamingSystem-ahvn13.md) and [EPR_SPID](NamingSystem-epr-spid.md)
* [ParticipationFunction](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ParticipationFunction.html): [ChCoreEncounterParticipationType](ValueSet-ch-core-encounter-participation-type.md)
* [TimingEvent](http://terminology.hl7.org/7.0.1/CodeSystem-v3-TimingEvent.html): [TimingEvent](CodeSystem-v3-TimingEvent.md)
* [Substance Admin Substitution](http://terminology.hl7.org/7.0.1/CodeSystem-v3-substanceAdminSubstitution.html): [ActSubstanceAdminSubstitutionCode](ValueSet-ActSubstanceAdminSubstitutionCode.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r4/ValueSet/edqm): [RouteOfAdministrationImmunization](ValueSet-ch-vacd-route-of-administration-vs.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-term.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-term.r4b)](package.r4b.tgz) are available.

### Dependency Table




### Globals Table

*There are no Global profiles defined*

### Disclaimer

HL7 SWITZERLAND PROVIDES THE DATA HEREUNDER AS IS WITHOUT WARRANTY WHATSOEVER. HL7 SWITZERLAND DOES NOT WARRANT OR REPRESENT THAT ANY DATA PROVIDED IN THIS IMPLEMENTATION GUIDE IS CORRECT. IT IS PROVIDED WITHOUT ANY WARRANTY WHATSOEVER, WHETHER EXPRESS, IMPLIED OR OTHERWISE, REGARDING ITS ACCURACY, COMPLETENESS NONINFRINGEMENT OF INTELLECTUAL PROPERTY. USE AT YOUR OWN RISK!

