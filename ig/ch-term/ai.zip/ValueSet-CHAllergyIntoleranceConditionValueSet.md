# CH AllergyIntolerance Condition - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH AllergyIntolerance Condition**

## ValueSet: CH AllergyIntolerance Condition 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-allergyintolerance/ValueSet/CHAllergyIntoleranceConditionValueSet | *Version*:3.3.0 |
| Active as of 2025-12-15 | *Computable Name*:CHAllergyIntoleranceConditionValueSet |
| **Copyright/Legal**: CC0-1.0 | |

 
CH AllergyIntolerance condition value set. This value set includes codes from SNOMED Clinical Terms® values for values from the manifestation of reactions value set PLUS findings for the documentation of allergy or intolerances in conditions as problem-list or as encounter-diagnosis as well as its absence (no know allergies) 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/CHAllergyIntoleranceConditionValueSet) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CHAllergyIntoleranceConditionValueSet",
  "url" : "http://fhir.ch/ig/ch-allergyintolerance/ValueSet/CHAllergyIntoleranceConditionValueSet",
  "version" : "3.3.0",
  "name" : "CHAllergyIntoleranceConditionValueSet",
  "title" : "CH AllergyIntolerance Condition",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-15T10:47:47+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/"
        }
      ]
    },
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "CH AllergyIntolerance condition value set. This value set includes codes from SNOMED Clinical Terms®  values  for values from the manifestation of reactions value set PLUS findings for the documentation of allergy or intolerances in conditions as problem-list or as encounter-diagnosis as well as its absence (no know allergies)",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [
      {
        "system" : "http://snomed.info/sct",
        "concept" : [
          {
            "code" : "716186003",
            "display" : "No known allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie connue"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Allergie"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia nota"
              }
            ]
          },
          {
            "code" : "716220001",
            "display" : "No known animal allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known animal allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie connue aux animaux"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Allergie gegen Tiere"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia agli animali nota"
              }
            ]
          },
          {
            "code" : "428197003",
            "display" : "No known insect allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known insect allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie connue aux insectes"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Allergie gegen Insekten"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia agli insetti nota"
              }
            ]
          },
          {
            "code" : "409137002",
            "display" : "No known drug allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known drug allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie médicamenteuse connue"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Arzneimittelallergie"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia a farmaci nota"
              }
            ]
          },
          {
            "code" : "428607008",
            "display" : "No known environmental allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known environmental allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie environnementale connue"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Umweltallergie"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia ambientale nota"
              }
            ]
          },
          {
            "code" : "429625007",
            "display" : "No known food allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known food allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie alimentaire connue"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Lebensmittelallergie"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia alimentare nota"
              }
            ]
          },
          {
            "code" : "1003774007",
            "display" : "No known Hevea brasiliensis latex allergy (situation)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "No known Hevea brasiliensis latex allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "pas d'allergie connue au latex d'Hevea brasiliensis"
              },
              {
                "language" : "de-CH",
                "value" : "Keine bekannte Allergie gegen Hevea brasiliensis-Latex"
              },
              {
                "language" : "it-CH",
                "value" : "nessuna allergia nota al lattice di Hevea brasiliensis"
              }
            ]
          },
          {
            "code" : "11861000122107",
            "display" : "Allergy to pantoprazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pantoprazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pantoprazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pantoprazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al pantoprazolo"
              }
            ]
          },
          {
            "code" : "13181000122107",
            "display" : "Allergy to levofloxacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to levofloxacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lévofloxacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Levofloxacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla levofloxacina"
              }
            ]
          },
          {
            "code" : "13221000122100",
            "display" : "Allergy to atorvastatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to atorvastatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'atorvastatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Atorvastatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'atorvastatina"
              }
            ]
          },
          {
            "code" : "13511000122108",
            "display" : "Allergy to pineapple (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pineapple"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'ananas"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ananas"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'ananas"
              }
            ]
          },
          {
            "code" : "151201000119107",
            "display" : "Allergy to insect venom (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to insect venom"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au venin d'insectes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Insektengift"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al veleno di insetti"
              }
            ]
          },
          {
            "code" : "190749000",
            "display" : "Glucose-galactose malabsorption (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Glucose-galactose malabsorption"
              },
              {
                "language" : "fr-CH",
                "value" : "malabsorption du glucose-galactose"
              },
              {
                "language" : "de-CH",
                "value" : "Glukose-Galaktose-Malabsorption"
              },
              {
                "language" : "it-CH",
                "value" : "malassorbimento di glucosio-galattosio"
              }
            ]
          },
          {
            "code" : "20052008",
            "display" : "Fructose-1,6-bisphosphate aldolase B deficiency (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Fructose-1,6-bisphosphate aldolase B deficiency"
              },
              {
                "language" : "fr-CH",
                "value" : "intolérance héréditaire au fructose"
              },
              {
                "language" : "de-CH",
                "value" : "Fructose-1,6-Bisphosphat-Aldolase-B-Mangel"
              },
              {
                "language" : "it-CH",
                "value" : "deficit di fruttosio-1,6-bisfosfato aldolasi B"
              }
            ]
          },
          {
            "code" : "21191000122102",
            "display" : "Allergy to mustard seasoning (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mustard seasoning"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la moutarde"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Senfgewürz"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla senape"
              }
            ]
          },
          {
            "code" : "213020009",
            "display" : "Allergy to egg protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to egg protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux protéines de l'œuf"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Eiprotein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine dell'uovo"
              }
            ]
          },
          {
            "code" : "23181000122104",
            "display" : "Allergy to mango fruit (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mango fruit"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mangue"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mangofrucht"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mango"
              }
            ]
          },
          {
            "code" : "232349006",
            "display" : "Allergy to house dust (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to house dust"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la poussière de maison"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hausstaubmilben"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla polvere"
              }
            ]
          },
          {
            "code" : "232350006",
            "display" : "Allergy to dust mite protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dust mite protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux acariens"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hausstaubmilbenprotein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine degli acari della polvere"
              }
            ]
          },
          {
            "code" : "293584003",
            "display" : "Allergy to paracetamol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to paracetamol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au paracétamol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Paracetamol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al paracetamolo"
              }
            ]
          },
          {
            "code" : "293585002",
            "display" : "Allergy to salicylate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to salicylate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au salicylate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Salicylat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai salicilati"
              }
            ]
          },
          {
            "code" : "293588000",
            "display" : "Allergy to pentazocine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pentazocine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pentazocine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pentazocin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pentazocina"
              }
            ]
          },
          {
            "code" : "293594008",
            "display" : "Allergy to methadone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methadone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la méthadone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methadon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metadone"
              }
            ]
          },
          {
            "code" : "293596005",
            "display" : "Allergy to buprenorphine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to buprenorphine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la buprénorphine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Buprenorphin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla buprenorfina"
              }
            ]
          },
          {
            "code" : "293597001",
            "display" : "Allergy to codeine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to codeine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la codéine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kodein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla codeina"
              }
            ]
          },
          {
            "code" : "293598006",
            "display" : "Allergy to diamorphine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diamorphine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la diamorphine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diamorphin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla diamorfina"
              }
            ]
          },
          {
            "code" : "293600000",
            "display" : "Allergy to nalbuphine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nalbuphine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nalbuphine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nalbuphin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nalbufina"
              }
            ]
          },
          {
            "code" : "293601001",
            "display" : "Allergy to morphine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to morphine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la morphine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Morphin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla morfina"
              }
            ]
          },
          {
            "code" : "293604009",
            "display" : "Allergy to alfentanil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to alfentanil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'alfentanil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Alfentanil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alfentanil"
              }
            ]
          },
          {
            "code" : "293605005",
            "display" : "Allergy to fentanyl (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fentanyl"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fentanyl"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fentanyl"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fentanyl"
              }
            ]
          },
          {
            "code" : "293606006",
            "display" : "Allergy to pethidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pethidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la péthidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pethidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla petidina"
              }
            ]
          },
          {
            "code" : "293608007",
            "display" : "Allergy to meptazinol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to meptazinol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au meptazinol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Meptazinol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al meptazinolo"
              }
            ]
          },
          {
            "code" : "293611008",
            "display" : "Allergy to acemetacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acemetacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acémétacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acemetacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acemetacina"
              }
            ]
          },
          {
            "code" : "293612001",
            "display" : "Allergy to azapropazone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to azapropazone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'azapropazone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Azapropazon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’azapropazone"
              }
            ]
          },
          {
            "code" : "293613006",
            "display" : "Allergy to diclofenac (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diclofenac"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au diclofénac"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diclofenac"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al diclofenac"
              }
            ]
          },
          {
            "code" : "293618002",
            "display" : "Allergy to flurbiprofen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flurbiprofen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flurbiprofène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flurbiprofen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flurbiprofene"
              }
            ]
          },
          {
            "code" : "293619005",
            "display" : "Allergy to ibuprofen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ibuprofen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'ibuprofène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ibuprofen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ibuprofene"
              }
            ]
          },
          {
            "code" : "293620004",
            "display" : "Allergy to indometacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to indometacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'indométacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Indometacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’indometacina"
              }
            ]
          },
          {
            "code" : "293621000",
            "display" : "Allergy to ketoprofen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ketoprofen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au kétoprofène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ketoprofen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al ketoprofene"
              }
            ]
          },
          {
            "code" : "293623002",
            "display" : "Allergy to mefenamic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mefenamic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide méfénamique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mefenaminsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido mefenamico"
              }
            ]
          },
          {
            "code" : "293625009",
            "display" : "Allergy to naproxen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to naproxen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au naproxène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Naproxen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al naproxene"
              }
            ]
          },
          {
            "code" : "293629003",
            "display" : "Allergy to piroxicam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piroxicam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au piroxicam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piroxicam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al piroxicam"
              }
            ]
          },
          {
            "code" : "293631007",
            "display" : "Allergy to tenoxicam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tenoxicam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au ténoxicam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tenoxicam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tenoxicam"
              }
            ]
          },
          {
            "code" : "293635003",
            "display" : "Allergy to tuberculin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tuberculin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie tuberculinique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tuberculin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tubercolina"
              }
            ]
          },
          {
            "code" : "293648004",
            "display" : "Allergy to misoprostol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to misoprostol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au misoprostol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Misoprostol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al misoprostolo"
              }
            ]
          },
          {
            "code" : "293650007",
            "display" : "Allergy to cimetidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cimetidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cimétidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cimetidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cimetidina"
              }
            ]
          },
          {
            "code" : "293653009",
            "display" : "Allergy to ranitidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ranitidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la ranitidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ranitidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ranitidina"
              }
            ]
          },
          {
            "code" : "293655002",
            "display" : "Allergy to omeprazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to omeprazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oméprazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Omeprazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’omeprazolo"
              }
            ]
          },
          {
            "code" : "293656001",
            "display" : "Allergy to lansoprazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lansoprazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lansoprazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lansoprazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lansoprazolo"
              }
            ]
          },
          {
            "code" : "293658000",
            "display" : "Allergy to pirenzepine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pirenzepine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pirenzépine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pirenzepin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pirenzepina"
              }
            ]
          },
          {
            "code" : "293660003",
            "display" : "Allergy to mesalazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mesalazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mésalazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mesalazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mesalazina"
              }
            ]
          },
          {
            "code" : "293663001",
            "display" : "Allergy to sulfasalazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulfasalazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la sulfasalazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfasalazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sulfasalazina"
              }
            ]
          },
          {
            "code" : "293678008",
            "display" : "Allergy to bisacodyl (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bisacodyl"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bisacodyl"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bisacodyl"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al bisacodile"
              }
            ]
          },
          {
            "code" : "293680002",
            "display" : "Allergy to sodium picosulfate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sodium picosulfate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au picosulfate de sodium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Picosulfat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sodio picosolfato"
              }
            ]
          },
          {
            "code" : "293692002",
            "display" : "Allergy to mebeverine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mebeverine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mébévérine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mebeverin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mebeverina"
              }
            ]
          },
          {
            "code" : "293706001",
            "display" : "Allergy to etomidate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to etomidate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'étomidate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Etomidat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’etomidato"
              }
            ]
          },
          {
            "code" : "293707005",
            "display" : "Allergy to ketamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ketamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la kétamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ketamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ketamina"
              }
            ]
          },
          {
            "code" : "293708000",
            "display" : "Allergy to propofol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to propofol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au propofol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Propofol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al propofol"
              }
            ]
          },
          {
            "code" : "293709008",
            "display" : "Allergy to thiopental (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiopental"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au thiopental"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiopental"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tiopentale"
              }
            ]
          },
          {
            "code" : "293714007",
            "display" : "Allergy to halothane (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to halothane"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'halothane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Halothan"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alotano"
              }
            ]
          },
          {
            "code" : "293715008",
            "display" : "Allergy to isoflurane (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to isoflurane"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'isoflurane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Isofluran"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’isoflurano"
              }
            ]
          },
          {
            "code" : "293717000",
            "display" : "Allergy to desflurane (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to desflurane"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au desflurane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Desfluran"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al desflurano"
              }
            ]
          },
          {
            "code" : "293719002",
            "display" : "Allergy to bupivacaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bupivacaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la bupivacaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bupivacain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla bupivacaina"
              }
            ]
          },
          {
            "code" : "293720008",
            "display" : "Allergy to cinchocaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cinchocaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cinchocaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cinchocain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cincocaina"
              }
            ]
          },
          {
            "code" : "293722000",
            "display" : "Allergy to lidocaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lidocaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lidocaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lidocain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla lidocaina"
              }
            ]
          },
          {
            "code" : "293724004",
            "display" : "Allergy to benzocaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to benzocaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la benzocaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Benzocain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla benzocaina"
              }
            ]
          },
          {
            "code" : "293725003",
            "display" : "Allergy to tetracaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tetracaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tétracaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tetracain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tetracaina"
              }
            ]
          },
          {
            "code" : "293726002",
            "display" : "Allergy to oxybuprocaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oxybuprocaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oxybuprocaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Oxybuprocain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ossibuprocaina"
              }
            ]
          },
          {
            "code" : "293727006",
            "display" : "Allergy to procaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to procaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la procaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Procain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla procaina"
              }
            ]
          },
          {
            "code" : "293728001",
            "display" : "Allergy to proxymetacaine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to proxymetacaine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la proxymétacaïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Proxymetacain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla prossimetacaina"
              }
            ]
          },
          {
            "code" : "293733002",
            "display" : "Allergy to aldesleukin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aldesleukin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aldesleukine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aldesleukin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'aldesleuchina"
              }
            ]
          },
          {
            "code" : "293735009",
            "display" : "Allergy to molgramostim (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to molgramostim"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au molgramostim"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Molgramostim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al molgramostim"
              }
            ]
          },
          {
            "code" : "293736005",
            "display" : "Allergy to lenograstim (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lenograstim"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lénograstim"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lenograstim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lenograstim"
              }
            ]
          },
          {
            "code" : "293737001",
            "display" : "Allergy to filgrastim (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to filgrastim"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au filgrastim"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Filgrastim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al filgrastim"
              }
            ]
          },
          {
            "code" : "293738006",
            "display" : "Allergy to levamisole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to levamisole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lévamisole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Levamisol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al levamisolo"
              }
            ]
          },
          {
            "code" : "293742009",
            "display" : "Allergy to busulfan (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to busulfan"
              },
              {
                "language" : "fr-CH",
                "value" : "allergieau busulfan"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Busulfan"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al busulfano"
              }
            ]
          },
          {
            "code" : "293743004",
            "display" : "Allergy to treosulfan (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to treosulfan"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tréosulfan"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Treosulfan"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al treosulfano"
              }
            ]
          },
          {
            "code" : "293745006",
            "display" : "Allergy to thiotepa (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiotepa"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au thiotépa"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiotepa"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tiotepa"
              }
            ]
          },
          {
            "code" : "293747003",
            "display" : "Allergy to chlorambucil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlorambucil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au chlorambucil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlorambucil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clorambucile"
              }
            ]
          },
          {
            "code" : "293748008",
            "display" : "Allergy to cyclophosphamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cyclophosphamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au cyclophosphamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cyclophosphamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ciclofosfamide"
              }
            ]
          },
          {
            "code" : "293750000",
            "display" : "Allergy to ifosfamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ifosfamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'ifosfamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ifosfamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ifosfamide"
              }
            ]
          },
          {
            "code" : "293751001",
            "display" : "Allergy to melphalan (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to melphalan"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au melphalan"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Melphalan"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al melfalan"
              }
            ]
          },
          {
            "code" : "293752008",
            "display" : "Allergy to estramustine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to estramustine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'estramustine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Estramustin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’estramustina"
              }
            ]
          },
          {
            "code" : "293755005",
            "display" : "Allergy to carmustine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carmustine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la carmustine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carmustin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carmustina"
              }
            ]
          },
          {
            "code" : "293756006",
            "display" : "Allergy to lomustine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lomustine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lomustine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lomustin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla lomustina"
              }
            ]
          },
          {
            "code" : "293758007",
            "display" : "Allergy to dacarbazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dacarbazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dacarbazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dacarbazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla dacarbazina"
              }
            ]
          },
          {
            "code" : "293760009",
            "display" : "Allergy to dactinomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dactinomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dactinomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dactinomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla dactinomicina"
              }
            ]
          },
          {
            "code" : "293761008",
            "display" : "Allergy to bleomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bleomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la bléomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bleomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla bleomicina"
              }
            ]
          },
          {
            "code" : "293762001",
            "display" : "Allergy to mitomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mitomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mitomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mitomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mitomicina"
              }
            ]
          },
          {
            "code" : "293765004",
            "display" : "Allergy to mitoxantrone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mitoxantrone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mitoxantrone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mitoxantron"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mitoxantrone"
              }
            ]
          },
          {
            "code" : "293767007",
            "display" : "Allergy to epirubicin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to epirubicin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'épirubicine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Epirubicin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’epirubicina"
              }
            ]
          },
          {
            "code" : "293768002",
            "display" : "Allergy to idarubicin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to idarubicin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'idarubicine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Idarubicin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idarubicina"
              }
            ]
          },
          {
            "code" : "293771005",
            "display" : "Allergy to methotrexate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methotrexate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au méthotrexate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methotrexat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metotrexato"
              }
            ]
          },
          {
            "code" : "293772003",
            "display" : "Allergy to mercaptopurine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mercaptopurine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mercaptopurine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mercaptopurin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mercaptopurina"
              }
            ]
          },
          {
            "code" : "293774002",
            "display" : "Allergy to pentostatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pentostatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pentostatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pentostatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pentostatina"
              }
            ]
          },
          {
            "code" : "293775001",
            "display" : "Allergy to cytarabine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cytarabine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cytarabine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cytarabin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla citarabina"
              }
            ]
          },
          {
            "code" : "293776000",
            "display" : "Allergy to fluorouracil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluorouracil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fluorouracil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluorouracil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluorouracile"
              }
            ]
          },
          {
            "code" : "293777009",
            "display" : "Allergy to etoposide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to etoposide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'étoposide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Etoposid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’etoposide"
              }
            ]
          },
          {
            "code" : "293778004",
            "display" : "Allergy to amsacrine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amsacrine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amsacrine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amsacrin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amsacrina"
              }
            ]
          },
          {
            "code" : "293779007",
            "display" : "Allergy to carboplatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carboplatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au carboplatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carboplatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al carboplatino"
              }
            ]
          },
          {
            "code" : "293780005",
            "display" : "Allergy to cisplatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cisplatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au cisplatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cisplatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cisplatino"
              }
            ]
          },
          {
            "code" : "293781009",
            "display" : "Allergy to hydroxycarbamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hydroxycarbamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydroxycarbamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hydroxycarbamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idrossicarbamide"
              }
            ]
          },
          {
            "code" : "293782002",
            "display" : "Allergy to procarbazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to procarbazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la procarbazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Procarbazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla procarbazina"
              }
            ]
          },
          {
            "code" : "293785000",
            "display" : "Allergy to paclitaxel (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to paclitaxel"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au paclitaxel"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Paclitaxel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al paclitaxel"
              }
            ]
          },
          {
            "code" : "293787008",
            "display" : "Allergy to aminoglutethimide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aminoglutethimide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aminoglutéthimide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aminoglutethimid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amminoglutetimide"
              }
            ]
          },
          {
            "code" : "293790002",
            "display" : "Allergy to tamoxifen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tamoxifen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tamoxifène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tamoxifen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tamoxifene"
              }
            ]
          },
          {
            "code" : "293795007",
            "display" : "Allergy to vindesine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vindesine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la vindésine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Vindesin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla vindesina"
              }
            ]
          },
          {
            "code" : "293798009",
            "display" : "Allergy to ciclosporin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ciclosporin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cyclosporine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ciclosporin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ciclosporina"
              }
            ]
          },
          {
            "code" : "293799001",
            "display" : "Allergy to azathioprine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to azathioprine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'azathioprine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Azathioprin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’azatioprina"
              }
            ]
          },
          {
            "code" : "293812003",
            "display" : "Allergy to apomorphine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to apomorphine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'apomorphine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Apomorphin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’apomorfina"
              }
            ]
          },
          {
            "code" : "293814002",
            "display" : "Allergy to pergolide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pergolide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pergolide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pergolid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pergolide"
              }
            ]
          },
          {
            "code" : "293815001",
            "display" : "Allergy to bromocriptine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bromocriptine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la bromocriptine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bromocriptin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla bromocriptina"
              }
            ]
          },
          {
            "code" : "293823004",
            "display" : "Allergy to doxepin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to doxepin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la doxépine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Doxepin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla doxepina"
              }
            ]
          },
          {
            "code" : "293826007",
            "display" : "Allergy to nortriptyline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nortriptyline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nortriptyline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nortriptylin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nortriptilina"
              }
            ]
          },
          {
            "code" : "293827003",
            "display" : "Allergy to trimipramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to trimipramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la trimipramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Trimipramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla trimipramina"
              }
            ]
          },
          {
            "code" : "293829000",
            "display" : "Allergy to amitriptyline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amitriptyline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amitriptyline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amitriptylin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amitriptilina"
              }
            ]
          },
          {
            "code" : "293830005",
            "display" : "Allergy to clomipramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clomipramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la clomipramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clomipramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clomipramina"
              }
            ]
          },
          {
            "code" : "293833007",
            "display" : "Allergy to imipramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to imipramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'imipramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Imipramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’imipramina"
              }
            ]
          },
          {
            "code" : "293840008",
            "display" : "Allergy to moclobemide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to moclobemide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au moclobémide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Moclobemid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla moclobemide"
              }
            ]
          },
          {
            "code" : "293843005",
            "display" : "Allergy to venlafaxine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to venlafaxine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la venlafaxine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Venlafaxin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla venlafaxina"
              }
            ]
          },
          {
            "code" : "293845003",
            "display" : "Allergy to sertraline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sertraline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la sertraline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sertralin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sertralina"
              }
            ]
          },
          {
            "code" : "293847006",
            "display" : "Allergy to paroxetine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to paroxetine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la paroxétine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Paroxetin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla paroxetina"
              }
            ]
          },
          {
            "code" : "293849009",
            "display" : "Allergy to citalopram (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to citalopram"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au citalopram"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Citalopram"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al citalopram"
              }
            ]
          },
          {
            "code" : "293850009",
            "display" : "Allergy to fluoxetine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluoxetine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluoxétine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluoxetin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fluoxetina"
              }
            ]
          },
          {
            "code" : "293851008",
            "display" : "Allergy to fluvoxamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluvoxamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluvoxamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluvoxamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fluvoxamina"
              }
            ]
          },
          {
            "code" : "293853006",
            "display" : "Allergy to maprotiline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to maprotiline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la maprotiline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Maprotilin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla maprotilina"
              }
            ]
          },
          {
            "code" : "293854000",
            "display" : "Allergy to mianserin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mianserin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la miansérine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mianserin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mianserina"
              }
            ]
          },
          {
            "code" : "293855004",
            "display" : "Allergy to trazodone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to trazodone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la trazodone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Trazodon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al trazodone"
              }
            ]
          },
          {
            "code" : "293859005",
            "display" : "Allergy to lamotrigine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lamotrigine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lamotrigine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lamotrigin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla lamotrigina"
              }
            ]
          },
          {
            "code" : "293860000",
            "display" : "Allergy to piracetam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piracetam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au piracétam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piracetam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al piracetam"
              }
            ]
          },
          {
            "code" : "293861001",
            "display" : "Allergy to gabapentin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gabapentin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la gabapentine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gabapentin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al gabapentin"
              }
            ]
          },
          {
            "code" : "293865005",
            "display" : "Allergy to phenobarbital (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenobarbital"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au phénobarbital"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenobarbital"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fenobarbital"
              }
            ]
          },
          {
            "code" : "293866006",
            "display" : "Allergy to primidone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to primidone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la primidone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Primidon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al primidone"
              }
            ]
          },
          {
            "code" : "293867002",
            "display" : "Allergy to carbamazepine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carbamazepine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la carbamazépine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carbamazepin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carbamazepina"
              }
            ]
          },
          {
            "code" : "293868007",
            "display" : "Allergy to vigabatrin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vigabatrin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la vigabatrine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Vigabatrin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vigabatrin"
              }
            ]
          },
          {
            "code" : "293869004",
            "display" : "Allergy to phenytoin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenytoin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la phénytoïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenytoin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fenitoina"
              }
            ]
          },
          {
            "code" : "293870003",
            "display" : "Allergy to ethosuximide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ethosuximide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'éthosuximide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ethosuximid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’etosuccimide"
              }
            ]
          },
          {
            "code" : "293871004",
            "display" : "Allergy to clonazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clonazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clonazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clonazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clonazepam"
              }
            ]
          },
          {
            "code" : "293874007",
            "display" : "Allergy to zopiclone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to zopiclone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la zopiclone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Zopiclon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia allo zopiclone"
              }
            ]
          },
          {
            "code" : "293880004",
            "display" : "Allergy to amobarbital (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amobarbital"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amobarbital"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amobarbital"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amobarbital"
              }
            ]
          },
          {
            "code" : "293886005",
            "display" : "Allergy to flunitrazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flunitrazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flunitrazépamam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flunitrazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flunitrazepam"
              }
            ]
          },
          {
            "code" : "293887001",
            "display" : "Allergy to flurazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flurazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flurazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flurazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flurazepam"
              }
            ]
          },
          {
            "code" : "293889003",
            "display" : "Allergy to lormetazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lormetazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lormétazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lormetazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lormetazepam"
              }
            ]
          },
          {
            "code" : "293890007",
            "display" : "Allergy to nitrazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nitrazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nitrazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nitrazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al nitrazepam"
              }
            ]
          },
          {
            "code" : "293891006",
            "display" : "Allergy to triazolam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to triazolam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au triazolam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Triazolam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al triazolam"
              }
            ]
          },
          {
            "code" : "293892004",
            "display" : "Allergy to alprazolam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to alprazolam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'alprazolam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Alprazolam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alprazolam"
              }
            ]
          },
          {
            "code" : "293893009",
            "display" : "Allergy to bromazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bromazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bromazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bromazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al bromazepam"
              }
            ]
          },
          {
            "code" : "293894003",
            "display" : "Allergy to chlordiazepoxide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlordiazepoxide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au chlordiazépoxide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlordiazepoxid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clordiazepossido"
              }
            ]
          },
          {
            "code" : "293895002",
            "display" : "Allergy to clobazam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clobazam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clobazam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clobazam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clobazam"
              }
            ]
          },
          {
            "code" : "293897005",
            "display" : "Allergy to ketazolam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ketazolam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au kétazolam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ketazolam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al ketazolam"
              }
            ]
          },
          {
            "code" : "293899008",
            "display" : "Allergy to oxazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oxazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oxazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Oxazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’oxazepam"
              }
            ]
          },
          {
            "code" : "293900003",
            "display" : "Allergy to prazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to prazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au prazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Prazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al prazepam"
              }
            ]
          },
          {
            "code" : "293901004",
            "display" : "Allergy to midazolam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to midazolam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au midazolam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Midazolam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al midazolam"
              }
            ]
          },
          {
            "code" : "293902006",
            "display" : "Allergy to diazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au diazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al diazepam"
              }
            ]
          },
          {
            "code" : "293903001",
            "display" : "Allergy to lorazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lorazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lorazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lorazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lorazepam"
              }
            ]
          },
          {
            "code" : "293904007",
            "display" : "Allergy to temazepam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to temazepam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au témazépam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Temazepam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al temazepam"
              }
            ]
          },
          {
            "code" : "293906009",
            "display" : "Allergy to meprobamate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to meprobamate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au méprobamate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Meprobamat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al meprobamato"
              }
            ]
          },
          {
            "code" : "293908005",
            "display" : "Allergy to chloral hydrate (finding",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chloral hydrate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydrate de chloral"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chloralhydrat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cloralio idrato"
              }
            ]
          },
          {
            "code" : "293911006",
            "display" : "Allergy to buspirone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to buspirone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la buspirone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Buspiron"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al buspirone"
              }
            ]
          },
          {
            "code" : "293912004",
            "display" : "Allergy to clomethiazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clomethiazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clométhiazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clomethiazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clometiazolo"
              }
            ]
          },
          {
            "code" : "293914003",
            "display" : "Allergy to sulpiride (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulpiride"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au sulpiride"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulpirid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sulpiride"
              }
            ]
          },
          {
            "code" : "293916001",
            "display" : "Allergy to clozapine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clozapine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la clozapine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clozapin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clozapina"
              }
            ]
          },
          {
            "code" : "293917005",
            "display" : "Allergy to risperidone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to risperidone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la rispéridone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Risperidon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al risperidone"
              }
            ]
          },
          {
            "code" : "293918000",
            "display" : "Allergy to tetrabenazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tetrabenazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tétrabénazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tetrabenazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tetrabenazina"
              }
            ]
          },
          {
            "code" : "293920002",
            "display" : "Allergy to benperidol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to benperidol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au benpéridol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Benperidol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al benperidolo"
              }
            ]
          },
          {
            "code" : "293923000",
            "display" : "Allergy to droperidol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to droperidol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au dropéridol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Droperidol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al droperidolo"
              }
            ]
          },
          {
            "code" : "293924006",
            "display" : "Allergy to haloperidol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to haloperidol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'halopéridol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Haloperidol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’aloperidolo"
              }
            ]
          },
          {
            "code" : "293927004",
            "display" : "Allergy to fluspirilene (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluspirilene"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fluspirilène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluspirilen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluspirilene"
              }
            ]
          },
          {
            "code" : "293928009",
            "display" : "Allergy to phenothiazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenothiazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la phénothiazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenothiazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fenotiazina"
              }
            ]
          },
          {
            "code" : "293929001",
            "display" : "Allergy to levomepromazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to levomepromazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lévomépromazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Levomepromazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla levomepromazina"
              }
            ]
          },
          {
            "code" : "293933008",
            "display" : "Allergy to thiethylperazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiethylperazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la thiéthylpérazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiethylperazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tietilperazina"
              }
            ]
          },
          {
            "code" : "293934002",
            "display" : "Allergy to fluphenazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluphenazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluphénazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluphenazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla flufenazina"
              }
            ]
          },
          {
            "code" : "293935001",
            "display" : "Allergy to chlorpromazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlorpromazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la chlorpromazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlorpromazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clorpromazina"
              }
            ]
          },
          {
            "code" : "293943006",
            "display" : "Allergy to chlorprothixene (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlorprothixene"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au chlorprothixène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlorprothixen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clorprotixene"
              }
            ]
          },
          {
            "code" : "293946003",
            "display" : "Allergy to zuclopenthixol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to zuclopenthixol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au zuclopenthixol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Zuclopenthixol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia allo zuclopentixolo"
              }
            ]
          },
          {
            "code" : "293948002",
            "display" : "Allergy to flupentixol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flupentixol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flupentixol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flupentixol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flupentixolo"
              }
            ]
          },
          {
            "code" : "293955000",
            "display" : "Allergy to methylphenidate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methylphenidate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au méthylphénidate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methylphenidat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metilfenidato"
              }
            ]
          },
          {
            "code" : "293960001",
            "display" : "Allergy to disulfiram (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to disulfiram"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au disulfirame"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Disulfiram"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al disulfiram"
              }
            ]
          },
          {
            "code" : "293965006",
            "display" : "Allergy to atenolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to atenolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aténolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Atenolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’atenololo"
              }
            ]
          },
          {
            "code" : "293966007",
            "display" : "Allergy to betaxolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to betaxolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bétaxolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Betaxolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al betaxololo"
              }
            ]
          },
          {
            "code" : "293967003",
            "display" : "Allergy to bisoprolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bisoprolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bisoprolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bisoprolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al bisoprololo"
              }
            ]
          },
          {
            "code" : "293972007",
            "display" : "Allergy to nadolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nadolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nadolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nadolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al nadololo"
              }
            ]
          },
          {
            "code" : "293974008",
            "display" : "Allergy to carvedilol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carvedilol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au carvédilol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carvedilol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al carvedilolo"
              }
            ]
          },
          {
            "code" : "293982008",
            "display" : "Allergy to propranolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to propranolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au propranolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Propranolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al propanololo"
              }
            ]
          },
          {
            "code" : "293983003",
            "display" : "Allergy to sotalol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sotalol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au sotalol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sotalol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sotalolo"
              }
            ]
          },
          {
            "code" : "293984009",
            "display" : "Allergy to timolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to timolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au timolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Timolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al timololo"
              }
            ]
          },
          {
            "code" : "293986006",
            "display" : "Allergy to alfuzosin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to alfuzosin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'alfuzosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Alfuzosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alfuzosina"
              }
            ]
          },
          {
            "code" : "293987002",
            "display" : "Allergy to doxazosin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to doxazosin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la doxazosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Doxazosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla doxazosina"
              }
            ]
          },
          {
            "code" : "293991007",
            "display" : "Allergy to prazosin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to prazosin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la prazosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Prazosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla prazosina"
              }
            ]
          },
          {
            "code" : "293992000",
            "display" : "Allergy to terazosin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to terazosin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la térazosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Terazosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla terazosina"
              }
            ]
          },
          {
            "code" : "293993005",
            "display" : "Allergy to nicotine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nicotine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nicotine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nikotin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nicotina"
              }
            ]
          },
          {
            "code" : "293996002",
            "display" : "Allergy to nifedipine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nifedipine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nifédipine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nifedipin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nifedipina"
              }
            ]
          },
          {
            "code" : "293998001",
            "display" : "Allergy to isradipine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to isradipine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'isradipine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Isradipin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’isradipina"
              }
            ]
          },
          {
            "code" : "293999009",
            "display" : "Allergy to felodipine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to felodipine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la félodipine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Felodipin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla felodipina"
              }
            ]
          },
          {
            "code" : "294001005",
            "display" : "Allergy to nimodipine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nimodipine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nimodipine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nimodipin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nimodipina"
              }
            ]
          },
          {
            "code" : "294002003",
            "display" : "Allergy to amlodipine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amlodipine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amlodipine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amlodipin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amlodipina"
              }
            ]
          },
          {
            "code" : "294003008",
            "display" : "Allergy to diltiazem (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diltiazem"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au diltiazem"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diltiazem"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al diltiazem"
              }
            ]
          },
          {
            "code" : "294005001",
            "display" : "Allergy to verapamil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to verapamil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vérapamil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Verapamil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al verapamil"
              }
            ]
          },
          {
            "code" : "294007009",
            "display" : "Allergy to pilocarpine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pilocarpine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pilocarpine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pilocarpin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pilocarpina"
              }
            ]
          },
          {
            "code" : "294017004",
            "display" : "Allergy to neostigmine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to neostigmine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la néostigmine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Neostigmin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla neostigmina"
              }
            ]
          },
          {
            "code" : "294028000",
            "display" : "Allergy to naphazoline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to naphazoline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la naphazoline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Naphazolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nafazolina"
              }
            ]
          },
          {
            "code" : "294030003",
            "display" : "Allergy to phenylephrine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenylephrine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la phenylephrine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenylephrin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fenilefrina"
              }
            ]
          },
          {
            "code" : "294036009",
            "display" : "Allergy to salmeterol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to salmeterol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au salmétérol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Salmeterol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al salmeterolo"
              }
            ]
          },
          {
            "code" : "294039002",
            "display" : "Allergy to fenoterol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fenoterol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fénotérol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fenoterol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fenoterolo"
              }
            ]
          },
          {
            "code" : "294047002",
            "display" : "Allergy to dobutamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dobutamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dobutamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dobutamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla dobutamina"
              }
            ]
          },
          {
            "code" : "294050004",
            "display" : "Allergy to isoprenaline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to isoprenaline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'isoprénaline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Isoprenalin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’isoprenalina"
              }
            ]
          },
          {
            "code" : "294055009",
            "display" : "Allergy to methyldopa (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methyldopa"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la méthyldopa"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methyldopa"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla metildopa"
              }
            ]
          },
          {
            "code" : "294057001",
            "display" : "Allergy to apraclonidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to apraclonidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'apraclonidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Apraclonidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’apraclonidina"
              }
            ]
          },
          {
            "code" : "294058006",
            "display" : "Allergy to clonidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clonidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la clonidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clonidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clonidina"
              }
            ]
          },
          {
            "code" : "294062000",
            "display" : "Allergy to ephedrine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ephedrine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'éphédrine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ephedrin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’efedrina"
              }
            ]
          },
          {
            "code" : "294069009",
            "display" : "Allergy to biperiden (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to biperiden"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bipéridène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Biperiden"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al biperidene"
              }
            ]
          },
          {
            "code" : "294073007",
            "display" : "Allergy to tropicamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tropicamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tropicamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tropicamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tropicamide"
              }
            ]
          },
          {
            "code" : "294074001",
            "display" : "Allergy to scopolamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to scopolamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la scopolamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Scopolamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla scopolamina"
              }
            ]
          },
          {
            "code" : "294076004",
            "display" : "Allergy to atropine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to atropine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'atropine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Atropin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’atropina"
              }
            ]
          },
          {
            "code" : "294080009",
            "display" : "Allergy to glycopyrronium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to glycopyrronium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au glycopyrronium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Glycopyrronium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al glicopirronio"
              }
            ]
          },
          {
            "code" : "294088002",
            "display" : "Allergy to oxybutynin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oxybutynin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oxybutynine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Oxybutynin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ossibutinina"
              }
            ]
          },
          {
            "code" : "294097003",
            "display" : "Allergy to acetylcysteine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acetylcysteine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acétylcystéine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acetylcystein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acetilcisteina"
              }
            ]
          },
          {
            "code" : "294101007",
            "display" : "Allergy to doxapram (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to doxapram"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au doxapram"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Doxapram"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al doxapram"
              }
            ]
          },
          {
            "code" : "294112007",
            "display" : "Allergy to terfenadine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to terfenadine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la terfénadine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Terfenadin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla terfenadina"
              }
            ]
          },
          {
            "code" : "294114008",
            "display" : "Allergy to loratadine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to loratadine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la loratadine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Loratadin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla loratadina"
              }
            ]
          },
          {
            "code" : "294115009",
            "display" : "Allergy to azelastine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to azelastine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'azélastine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Azelastin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’azelastina"
              }
            ]
          },
          {
            "code" : "294116005",
            "display" : "Allergy to cetirizine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cetirizine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cétirizine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cetirizin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cetirizina"
              }
            ]
          },
          {
            "code" : "294118006",
            "display" : "Allergy to clemastine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clemastine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la clémastine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clemastin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clemastina"
              }
            ]
          },
          {
            "code" : "294119003",
            "display" : "Allergy to mebhydrolin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mebhydrolin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mébhydroline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mebhydrolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mebidrolina"
              }
            ]
          },
          {
            "code" : "294125004",
            "display" : "Allergy to antazoline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to antazoline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'antazoline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Antazolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’antazolina"
              }
            ]
          },
          {
            "code" : "294126003",
            "display" : "Allergy to promethazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to promethazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la prométhazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Promethazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla prometazina"
              }
            ]
          },
          {
            "code" : "294130000",
            "display" : "Allergy to cinnarizine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cinnarizine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cinnarizine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cinnarizin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cinnarizina"
              }
            ]
          },
          {
            "code" : "294131001",
            "display" : "Allergy to cyproheptadine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cyproheptadine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cyproheptadine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cyproheptadin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ciproeptadina"
              }
            ]
          },
          {
            "code" : "294132008",
            "display" : "Allergy to dimetindene (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dimetindene"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au dimétindène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dimetinden"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al dimetindene"
              }
            ]
          },
          {
            "code" : "294133003",
            "display" : "Allergy to diphenhydramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diphenhydramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la diphénhydramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diphenhydramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla difenidramina"
              }
            ]
          },
          {
            "code" : "294135005",
            "display" : "Allergy to hydroxyzine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hydroxyzine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydroxyzine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hydroxyzin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idrossizina"
              }
            ]
          },
          {
            "code" : "294136006",
            "display" : "Allergy to mepyramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mepyramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mépyramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mepyramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mepiramina"
              }
            ]
          },
          {
            "code" : "294138007",
            "display" : "Allergy to pheniramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pheniramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la phéniramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pheniramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla feniramina"
              }
            ]
          },
          {
            "code" : "294144006",
            "display" : "Allergy to ketotifen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ketotifen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la kétotifène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ketotifen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al ketotifene"
              }
            ]
          },
          {
            "code" : "294152009",
            "display" : "Allergy to noscapine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to noscapine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la noscapine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Noscapin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla noscapina"
              }
            ]
          },
          {
            "code" : "294153004",
            "display" : "Allergy to pholcodine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pholcodine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pholcodine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pholcodin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla folcodina"
              }
            ]
          },
          {
            "code" : "294157003",
            "display" : "Allergy to xanthine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to xanthine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la xanthine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Xanthin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla xantina"
              }
            ]
          },
          {
            "code" : "294158008",
            "display" : "Allergy to aminophylline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aminophylline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aminophylline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aminophyllin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’aminofillina"
              }
            ]
          },
          {
            "code" : "294169006",
            "display" : "Allergy to coal tar (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to coal tar"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au goudron de houille"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kohleteer"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al catrame di carbone"
              }
            ]
          },
          {
            "code" : "294172004",
            "display" : "Allergy to bufexamac (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bufexamac"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bufexamac"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bufexamac"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al bufexamac"
              }
            ]
          },
          {
            "code" : "294179008",
            "display" : "Sulfur allergy (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Sulfur allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au soufre"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Schwefel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia allo zolfo"
              }
            ]
          },
          {
            "code" : "294183008",
            "display" : "Allergy to podophyllotoxin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to podophyllotoxin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la podophyllotoxine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Podophyllotoxin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla podofillotossina"
              }
            ]
          },
          {
            "code" : "294200004",
            "display" : "Allergy to crotamiton (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to crotamiton"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au crotamiton"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Crotamiton"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al crotamitone"
              }
            ]
          },
          {
            "code" : "294207001",
            "display" : "Allergy to retinoid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to retinoid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux rétinoïdes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Retinoid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai retinoidi"
              }
            ]
          },
          {
            "code" : "294209003",
            "display" : "Allergy to acitretin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acitretin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acitrétine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acitretin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acitretina"
              }
            ]
          },
          {
            "code" : "294210008",
            "display" : "Allergy to tretinoin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tretinoin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la trétinoïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tretinoin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tretinoina"
              }
            ]
          },
          {
            "code" : "294211007",
            "display" : "Allergy to isotretinoin (finding",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to isotretinoin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'isotrétinoïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Isotretinoin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’isotretinoina"
              }
            ]
          },
          {
            "code" : "294217006",
            "display" : "Allergy to probenecid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to probenecid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au probénécide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Probenecid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al probenecid"
              }
            ]
          },
          {
            "code" : "294220003",
            "display" : "Allergy to allopurinol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to allopurinol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'allopurinol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Allopurinol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’allopurinolo"
              }
            ]
          },
          {
            "code" : "294224007",
            "display" : "Allergy to succinylcholine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to succinylcholine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la succinylcholine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Succinylcholin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla succinilcolina"
              }
            ]
          },
          {
            "code" : "294226009",
            "display" : "Allergy to mivacurium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mivacurium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au mivacurium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mivacurium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mivacurio"
              }
            ]
          },
          {
            "code" : "294228005",
            "display" : "Allergy to atracurium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to atracurium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'atracurium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Atracurium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’atracurio"
              }
            ]
          },
          {
            "code" : "294230007",
            "display" : "Allergy to pancuronium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pancuronium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pancuronium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pancuronium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al pancuronio"
              }
            ]
          },
          {
            "code" : "294232004",
            "display" : "Allergy to vecuronium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vecuronium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vécuronium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Vecuronium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vecuronio"
              }
            ]
          },
          {
            "code" : "294233009",
            "display" : "Allergy to rocuronium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to rocuronium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au rocuronium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Rocuronium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al rocuronio"
              }
            ]
          },
          {
            "code" : "294234003",
            "display" : "Allergy to baclofen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to baclofen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au baclofène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Baclofen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al baclofene"
              }
            ]
          },
          {
            "code" : "294236001",
            "display" : "Allergy to methocarbamol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methocarbamol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au méthocarbamol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methocarbamol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metocarbamolo"
              }
            ]
          },
          {
            "code" : "294237005",
            "display" : "Allergy to dantrolene (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dantrolene"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au dantrolène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dantrolen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al dantrolene"
              }
            ]
          },
          {
            "code" : "294238000",
            "display" : "Allergy to gold (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gold"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'or"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gold"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’oro"
              }
            ]
          },
          {
            "code" : "294242002",
            "display" : "Allergy to papaverine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to papaverine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la papavérine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Papaverin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla papaverina"
              }
            ]
          },
          {
            "code" : "294243007",
            "display" : "Allergy to flavoxate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flavoxate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flavoxate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flavoxat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flavoxato"
              }
            ]
          },
          {
            "code" : "294245000",
            "display" : "Allergy to mifepristone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mifepristone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mifepristone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mifepriston"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mifepristone"
              }
            ]
          },
          {
            "code" : "294253008",
            "display" : "Allergy to dinoprostone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dinoprostone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dinoprostone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dinoproston"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al dinoprostone"
              }
            ]
          },
          {
            "code" : "294255001",
            "display" : "Allergy to alprostadil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to alprostadil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'alprostadil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Alprostadil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alprostadil"
              }
            ]
          },
          {
            "code" : "294269001",
            "display" : "Allergy to mesna (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mesna"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au mesna"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mesna"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mesna"
              }
            ]
          },
          {
            "code" : "294271001",
            "display" : "Allergy to flumazenil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flumazenil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au flumazénil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flumazenil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al flumazenil"
              }
            ]
          },
          {
            "code" : "294276006",
            "display" : "Allergy to naltrexone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to naltrexone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la naltrexone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Naltrexon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al naltrexone"
              }
            ]
          },
          {
            "code" : "294277002",
            "display" : "Allergy to naloxone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to naloxone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la naloxone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Naloxon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al naloxone"
              }
            ]
          },
          {
            "code" : "294278007",
            "display" : "Allergy to protamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to protamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la protamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Protamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla protamina"
              }
            ]
          },
          {
            "code" : "294282009",
            "display" : "Allergy to chelating agent (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chelating agent"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'agent chélateur"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chelator"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ad agente chelante"
              }
            ]
          },
          {
            "code" : "294291008",
            "display" : "Allergy to penicillamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to penicillamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pénicillamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Penicillamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla penicillamina"
              }
            ]
          },
          {
            "code" : "294324005",
            "display" : "Allergy to paraffin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to paraffin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la paraffine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Paraffin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla paraffina"
              }
            ]
          },
          {
            "code" : "294330005",
            "display" : "Allergy to wool alcohol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to wool alcohol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'alcool de laine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Wollwachsalkohol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli alcoli della lanolina"
              }
            ]
          },
          {
            "code" : "294339006",
            "display" : "Allergy to carmellose (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carmellose"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la carboxyméthylcellulose"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carmellose"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al carmellosio"
              }
            ]
          },
          {
            "code" : "294341007",
            "display" : "Allergy to flucytosine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flucytosine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la flucytosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flucytosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla flucitosina"
              }
            ]
          },
          {
            "code" : "294342000",
            "display" : "Allergy to terbinafine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to terbinafine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la terbinafine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Terbinafin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla terbinafina"
              }
            ]
          },
          {
            "code" : "294346002",
            "display" : "Allergy to amorolfine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amorolfine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amorolfine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amorolfin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amorolfina"
              }
            ]
          },
          {
            "code" : "294348001",
            "display" : "Allergy to griseofulvin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to griseofulvin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la griséofulvine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Griseofulvin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla griseofulvina"
              }
            ]
          },
          {
            "code" : "294349009",
            "display" : "Allergy to amphotericin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amphotericin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amphotéricine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amphotericin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amfotericina"
              }
            ]
          },
          {
            "code" : "294350009",
            "display" : "Allergy to natamycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to natamycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la natamycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Natamycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla natamicina"
              }
            ]
          },
          {
            "code" : "294351008",
            "display" : "Allergy to nystatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nystatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nystatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nystatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nistatina"
              }
            ]
          },
          {
            "code" : "294354000",
            "display" : "Allergy to undecenoate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to undecenoate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'undécénoate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Undecenoat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’undecanoato"
              }
            ]
          },
          {
            "code" : "294356003",
            "display" : "Allergy to clotrimazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clotrimazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clotrimazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clotrimazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clotrimazolo"
              }
            ]
          },
          {
            "code" : "294359005",
            "display" : "Allergy to econazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to econazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'éconazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Econazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’econazolo"
              }
            ]
          },
          {
            "code" : "294362008",
            "display" : "Allergy to ketoconazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ketoconazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au kétoconazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ketoconazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al ketoconazolo"
              }
            ]
          },
          {
            "code" : "294363003",
            "display" : "Allergy to miconazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to miconazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au miconazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Miconazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al miconazolo"
              }
            ]
          },
          {
            "code" : "294365005",
            "display" : "Allergy to fluconazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluconazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fluconazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluconazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluconazolo"
              }
            ]
          },
          {
            "code" : "294366006",
            "display" : "Allergy to itraconazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to itraconazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'itraconazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Itraconazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’itraconazolo"
              }
            ]
          },
          {
            "code" : "294369004",
            "display" : "Allergy to zidovudine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to zidovudine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la zidovudine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Zidovudin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla zidovudina"
              }
            ]
          },
          {
            "code" : "294371004",
            "display" : "Allergy to famciclovir (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to famciclovir"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au famciclovir"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Famciclovir"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al famciclovir"
              }
            ]
          },
          {
            "code" : "294372006",
            "display" : "Allergy to didanosine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to didanosine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la didanosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Didanosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla didanosina"
              }
            ]
          },
          {
            "code" : "294374007",
            "display" : "Allergy to valaciclovir (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to valaciclovir"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au valaciclovir"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Valaciclovir"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al valaciclovir"
              }
            ]
          },
          {
            "code" : "294380004",
            "display" : "Allergy to ribavirin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ribavirin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la ribavirine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ribavirin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ribavirina"
              }
            ]
          },
          {
            "code" : "294381000",
            "display" : "Allergy to trifluridine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to trifluridine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la trifluridine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Trifluridin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla trifluridina"
              }
            ]
          },
          {
            "code" : "294382007",
            "display" : "Allergy to foscarnet (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to foscarnet"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au foscarnet"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Foscarnet"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al foscarnet"
              }
            ]
          },
          {
            "code" : "294384008",
            "display" : "Allergy to aciclovir (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aciclovir"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aciclovir"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aciclovir"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'aciclovir"
              }
            ]
          },
          {
            "code" : "294388006",
            "display" : "Allergy to pyrimethamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pyrimethamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pyriméthamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pyrimethamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pirimetamina"
              }
            ]
          },
          {
            "code" : "294391006",
            "display" : "Allergy to primaquine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to primaquine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la primaquine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Primaquin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla primachina"
              }
            ]
          },
          {
            "code" : "294392004",
            "display" : "Allergy to mefloquine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mefloquine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la méfloquine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mefloquin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla meflochina"
              }
            ]
          },
          {
            "code" : "294394003",
            "display" : "Allergy to chloroquine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chloroquine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la chloroquine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chloroquin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clorochina"
              }
            ]
          },
          {
            "code" : "294396001",
            "display" : "Allergy to proguanil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to proguanil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au proguanil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Proguanil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al proguanil"
              }
            ]
          },
          {
            "code" : "294398000",
            "display" : "Allergy to quinine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to quinine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la quinine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chinin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla chinina"
              }
            ]
          },
          {
            "code" : "294407003",
            "display" : "Allergy to hexetidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hexetidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hexétidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hexetidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’esetidina"
              }
            ]
          },
          {
            "code" : "294418003",
            "display" : "Allergy to phenol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au phénol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fenolo"
              }
            ]
          },
          {
            "code" : "294426006",
            "display" : "Allergy to formaldehyde (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to formaldehyde"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au formaldéhyde"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Formaldehyd"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla formaldeide"
              }
            ]
          },
          {
            "code" : "294431008",
            "display" : "Allergy to chlorhexidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlorhexidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la chlorhexidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlorhexidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clorexidina"
              }
            ]
          },
          {
            "code" : "294438002",
            "display" : "Allergy to benzalkonium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to benzalkonium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au benzalkonium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Benzalkonium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al benzalconio"
              }
            ]
          },
          {
            "code" : "294451007",
            "display" : "Allergy to piperazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piperazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pipérazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piperazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla piperazina"
              }
            ]
          },
          {
            "code" : "294458001",
            "display" : "Allergy to mebendazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mebendazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au mébendazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mebendazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mebendazolo"
              }
            ]
          },
          {
            "code" : "294459009",
            "display" : "Allergy to albendazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to albendazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'albendazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Albendazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’albendazolo"
              }
            ]
          },
          {
            "code" : "294460004",
            "display" : "Allergy to tiabendazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tiabendazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au thiabendazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tiabendazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tiabendazolo"
              }
            ]
          },
          {
            "code" : "294463002",
            "display" : "Allergy to amikacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amikacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amikacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amikacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amikacina"
              }
            ]
          },
          {
            "code" : "294466005",
            "display" : "Allergy to streptomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to streptomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la streptomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Streptomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla streptomicina"
              }
            ]
          },
          {
            "code" : "294468006",
            "display" : "Allergy to neomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to neomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la néomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Neomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla neomicina"
              }
            ]
          },
          {
            "code" : "294469003",
            "display" : "Allergy to gentamicin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gentamicin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la gentamicine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gentamicin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla gentamicina"
              }
            ]
          },
          {
            "code" : "294470002",
            "display" : "Allergy to tobramycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tobramycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tobramycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tobramycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tobramicina"
              }
            ]
          },
          {
            "code" : "294472005",
            "display" : "Allergy to azithromycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to azithromycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'azithromycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Azithromycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’azitromicina"
              }
            ]
          },
          {
            "code" : "294475007",
            "display" : "Allergy to vancomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vancomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la vancomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Vancomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla vancomicina"
              }
            ]
          },
          {
            "code" : "294476008",
            "display" : "Allergy to teicoplanin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to teicoplanin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la teicoplanine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Teicoplanin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla teicoplanina"
              }
            ]
          },
          {
            "code" : "294477004",
            "display" : "Allergy to trimethoprim (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to trimethoprim"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au triméthoprime"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Trimethoprim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al trimetoprim"
              }
            ]
          },
          {
            "code" : "294478009",
            "display" : "Allergy to nitrofurantoin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nitrofurantoin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nitrofurantoïne"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nitrofurantoin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nitrofurantoina"
              }
            ]
          },
          {
            "code" : "294480003",
            "display" : "Allergy to mupirocin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mupirocin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mupirocine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mupirocin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mupirocina"
              }
            ]
          },
          {
            "code" : "294481004",
            "display" : "Allergy to nitrofural (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nitrofural"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nitrofural"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nitrofural"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al nitrofurazone"
              }
            ]
          },
          {
            "code" : "294482006",
            "display" : "Allergy to fusidic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fusidic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide fusidique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fusidinsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido fusidico"
              }
            ]
          },
          {
            "code" : "294485008",
            "display" : "Allergy to cinoxacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cinoxacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cinoxacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cinoxacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cinoxacina"
              }
            ]
          },
          {
            "code" : "294487000",
            "display" : "Allergy to ciprofloxacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ciprofloxacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la ciprofloxacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ciprofloxacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ciprofloxacina"
              }
            ]
          },
          {
            "code" : "294489002",
            "display" : "Allergy to ofloxacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ofloxacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'ofloxacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ofloxacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ofloxacina"
              }
            ]
          },
          {
            "code" : "294490006",
            "display" : "Allergy to norfloxacin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to norfloxacin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la norfloxacine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Norfloxacin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla norfloxacina"
              }
            ]
          },
          {
            "code" : "294497009",
            "display" : "Allergy to phenoxymethylpenicillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phenoxymethylpenicillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la phénoxyméthylpénicilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phenoxymethylpenicillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fenossimetilpenicillina"
              }
            ]
          },
          {
            "code" : "294499007",
            "display" : "Allergy to benzylpenicillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to benzylpenicillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la benzylpénicilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Benzylpenicillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla benzilpenicillina"
              }
            ]
          },
          {
            "code" : "294502006",
            "display" : "Allergy to flucloxacillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to flucloxacillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la flucloxacilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Flucloxacillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla flucloxacillina"
              }
            ]
          },
          {
            "code" : "294505008",
            "display" : "Allergy to amoxicillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amoxicillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amoxicilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amoxicillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amoxicillina"
              }
            ]
          },
          {
            "code" : "294506009",
            "display" : "Allergy to ampicillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ampicillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'ampicilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ampicillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ampicillina"
              }
            ]
          },
          {
            "code" : "294514003",
            "display" : "Allergy to temocillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to temocillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la témocilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Temocillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla temocillina"
              }
            ]
          },
          {
            "code" : "294515002",
            "display" : "Allergy to piperacillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piperacillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pipéracilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piperacillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla piperacillina"
              }
            ]
          },
          {
            "code" : "294517005",
            "display" : "Allergy to ticarcillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ticarcillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la ticarcilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ticarcillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ticarcillina"
              }
            ]
          },
          {
            "code" : "294529001",
            "display" : "Allergy to colistin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to colistin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la colistine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Colistin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla colistina"
              }
            ]
          },
          {
            "code" : "294531005",
            "display" : "Allergy to carbapenem (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carbapenem"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au carbapénème"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carbapenem"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai carbapenemi"
              }
            ]
          },
          {
            "code" : "294532003",
            "display" : "Allergy to cephalosporin antibacterial (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cephalosporin antibacterial"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la céphalosporine (antibiotique)"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cephalosporine"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle cefalosporine antibatteriche"
              }
            ]
          },
          {
            "code" : "294537009",
            "display" : "Allergy to cefazolin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefazolin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la céfazoline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefazolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cefazolina"
              }
            ]
          },
          {
            "code" : "294541008",
            "display" : "Allergy to cefaclor (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefaclor"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au céfaclor"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefaclor"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cefaclor"
              }
            ]
          },
          {
            "code" : "294542001",
            "display" : "Allergy to cefuroxime (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefuroxime"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au céfuroxime"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefuroxim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cefuroxima"
              }
            ]
          },
          {
            "code" : "294543006",
            "display" : "Allergy to cefamandole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefamandole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au céfamandole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefamandol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cefamandolo"
              }
            ]
          },
          {
            "code" : "294546003",
            "display" : "Allergy to ceftazidime (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ceftazidime"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la ceftazidime"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ceftazidim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla ceftazidima"
              }
            ]
          },
          {
            "code" : "294548002",
            "display" : "Allergy to cefixime (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefixime"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au céfixime"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefixim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cefixima"
              }
            ]
          },
          {
            "code" : "294550005",
            "display" : "Allergy to cefpodoxime (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cefpodoxime"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au cefpodoxime"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cefpodoxim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cefpodoxima"
              }
            ]
          },
          {
            "code" : "294551009",
            "display" : "Allergy to ceftriaxone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ceftriaxone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie to ceftriaxone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ceftriaxon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al ceftriaxone"
              }
            ]
          },
          {
            "code" : "294559006",
            "display" : "Allergy to fosfomycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fosfomycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fosfomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fosfomycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fosfomicina"
              }
            ]
          },
          {
            "code" : "294561002",
            "display" : "Allergy to clindamycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clindamycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la clindamycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clindamycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clindamicina"
              }
            ]
          },
          {
            "code" : "294564005",
            "display" : "Allergy to monobactam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to monobactam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au monobactam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Monobactam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai monobattami"
              }
            ]
          },
          {
            "code" : "294565006",
            "display" : "Allergy to aztreonam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aztreonam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aztréonam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aztreonam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’aztreonam"
              }
            ]
          },
          {
            "code" : "294566007",
            "display" : "Allergy to nitroimidazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nitroimidazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nitro-imidazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nitroimidazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai nitroimidazoli"
              }
            ]
          },
          {
            "code" : "294567003",
            "display" : "Allergy to metronidazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to metronidazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au métronidazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Metronidazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metronidazolo"
              }
            ]
          },
          {
            "code" : "294568008",
            "display" : "Allergy to tinidazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tinidazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tinidazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tinidazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tinidazolo"
              }
            ]
          },
          {
            "code" : "294573002",
            "display" : "Allergy to sulfadiazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulfadiazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la sulfadiazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfadiazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sulfadiazina"
              }
            ]
          },
          {
            "code" : "294580000",
            "display" : "Silver sulfadiazine allergy (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Silver sulfadiazine allergy"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la sulfadiazine argentique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Silbersulfadiazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sulfadiazina argentica"
              }
            ]
          },
          {
            "code" : "294582008",
            "display" : "Allergy to sulfacetamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulfacetamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au sulfacétamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfacetamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla sulfacetamide"
              }
            ]
          },
          {
            "code" : "294585005",
            "display" : "Allergy to doxycycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to doxycycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la doxycycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Doxycyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla doxiciclina"
              }
            ]
          },
          {
            "code" : "294586006",
            "display" : "Allergy to lymecycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lymecycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la lymécycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lymecyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla limeciclina"
              }
            ]
          },
          {
            "code" : "294587002",
            "display" : "Allergy to minocycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to minocycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la minocycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Minocyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla minociclina"
              }
            ]
          },
          {
            "code" : "294588007",
            "display" : "Allergy to oxytetracycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oxytetracycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oxytétracycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Oxytetracyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ossitetraciclina"
              }
            ]
          },
          {
            "code" : "294590008",
            "display" : "Allergy to chlortetracycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlortetracycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la chlortétracycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlortetracyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla clortetraciclina"
              }
            ]
          },
          {
            "code" : "294591007",
            "display" : "Allergy to demeclocycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to demeclocycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la déméclocycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Demeclocyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla demeclociclina"
              }
            ]
          },
          {
            "code" : "294592000",
            "display" : "Allergy to tetracycline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tetracycline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tétracycline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tetracyclin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle tetracicline"
              }
            ]
          },
          {
            "code" : "294593005",
            "display" : "Allergy to chloramphenicol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chloramphenicol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au chloramphénicol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chloramphenicol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cloramfenicolo"
              }
            ]
          },
          {
            "code" : "294596002",
            "display" : "Allergy to atovaquone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to atovaquone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'atovaquone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Atovaquon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’atovaquone"
              }
            ]
          },
          {
            "code" : "294600007",
            "display" : "Allergy to pentamidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pentamidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pentamidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pentamidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pentamidina"
              }
            ]
          },
          {
            "code" : "294604003",
            "display" : "Allergy to clioquinol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clioquinol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clioquinol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clioquinol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cliochinolo"
              }
            ]
          },
          {
            "code" : "294607005",
            "display" : "Allergy to pyrazinamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pyrazinamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pyrazinamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pyrazinamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pirazinamide"
              }
            ]
          },
          {
            "code" : "294610003",
            "display" : "Allergy to cycloserine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cycloserine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cyclosérine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cycloserin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cicloserina"
              }
            ]
          },
          {
            "code" : "294611004",
            "display" : "Allergy to rifampicin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to rifampicin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la rifampicine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Rifampicin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla rifampicina"
              }
            ]
          },
          {
            "code" : "294612006",
            "display" : "Allergy to rifabutin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to rifabutin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la rifabutine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Rifabutin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla rifabutina"
              }
            ]
          },
          {
            "code" : "294614007",
            "display" : "Allergy to isoniazid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to isoniazid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'isoniazide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Isoniazid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’isoniazide"
              }
            ]
          },
          {
            "code" : "294615008",
            "display" : "Allergy to ethambutol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ethambutol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'éthambutol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ethambutol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’etambutolo"
              }
            ]
          },
          {
            "code" : "294617000",
            "display" : "Allergy to dapsone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dapsone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dapsone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dapson"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al dapsone"
              }
            ]
          },
          {
            "code" : "294621007",
            "display" : "Allergy to sulfiram (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulfiram"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au sulfiram"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfiram"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sulfiram"
              }
            ]
          },
          {
            "code" : "294625003",
            "display" : "Allergy to lindane (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lindane"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lindane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lindan"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lindano"
              }
            ]
          },
          {
            "code" : "294630004",
            "display" : "Allergy to permethrin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to permethrin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la perméthrine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Permethrin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla permetrina"
              }
            ]
          },
          {
            "code" : "294639003",
            "display" : "Allergy to Varicella-zoster virus antibody (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Varicella-zoster virus antibody"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'immunoglobuline antivirus varicella-zoster"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Varizella-Zoster-Virus-Antikörper"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli anticorpi contro il virus varicella-zoster"
              }
            ]
          },
          {
            "code" : "294642009",
            "display" : "Allergy to vaccine product containing Corynebacterium diphtheriae antigen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vaccine product containing Corynebacterium diphtheriae antigen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin antidiphtérique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Impfstoffprodukt mit Corynebacterium diphtheriae-Antigen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia a vaccini contenenti antigeni di Corynebacterium diphtheriae"
              }
            ]
          },
          {
            "code" : "294646007",
            "display" : "Allergy to Hepatitis B virus vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Hepatitis B virus vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre l'hépatite B"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Hepatitis-B-Virus-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro il virus dell’epatite B"
              }
            ]
          },
          {
            "code" : "294651001",
            "display" : "Allergy to pertussis vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pertussis vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre la coqueluche"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Keuchhusten-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro la pertosse"
              }
            ]
          },
          {
            "code" : "294652008",
            "display" : "Allergy to pneumococcal vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pneumococcal vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre les pneumocoques"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Pneumokokken-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro gli pneumococchi"
              }
            ]
          },
          {
            "code" : "294654009",
            "display" : "Allergy to Poliovirus vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Poliovirus vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre la poliomyélite"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Poliovirus-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro la poliomielite"
              }
            ]
          },
          {
            "code" : "294655005",
            "display" : "Allergy to Rabies vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Rabies vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre la rage"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Tollwut-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro la rabbia"
              }
            ]
          },
          {
            "code" : "294656006",
            "display" : "Allergy to rubella vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to rubella vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre la rubéole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Röteln-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro la rosolia"
              }
            ]
          },
          {
            "code" : "294658007",
            "display" : "Allergy to tetanus vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tetanus vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre le tétanos"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Tetanus-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro il tetano"
              }
            ]
          },
          {
            "code" : "294663006",
            "display" : "Allergy to Hepatitis A virus vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Hepatitis A virus vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre l'hépatite A"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den Hepatitis-A-Virus-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro il virus dell’epatite A"
              }
            ]
          },
          {
            "code" : "294664000",
            "display" : "Allergy to Haemophilus influenzae type b vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Haemophilus influenzae type b vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre Haemophilus influenzae de type B"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen den  Haemophilus influenzae B-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro l’Haemophilus influenzae di tipo B"
              }
            ]
          },
          {
            "code" : "294671005",
            "display" : "Allergy to glucagon (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to glucagon"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au glucagon"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Glucagon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al glucagone"
              }
            ]
          },
          {
            "code" : "294674002",
            "display" : "Allergy to carbimazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carbimazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au carbimazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carbimazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al carbimazolo"
              }
            ]
          },
          {
            "code" : "294676000",
            "display" : "Allergy to propylthiouracil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to propylthiouracil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au propylthiouracile"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Propylthiouracil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al propiltiouracile"
              }
            ]
          },
          {
            "code" : "294678004",
            "display" : "Allergy to betamethasone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to betamethasone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la bétaméthasone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Betamethason"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al betametasone"
              }
            ]
          },
          {
            "code" : "294679007",
            "display" : "Allergy to methylprednisolone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to methylprednisolone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la méthylprednisolone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Methylprednisolon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metilprednisolone"
              }
            ]
          },
          {
            "code" : "294682002",
            "display" : "Allergy to prednisone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to prednisone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la prednisone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Prednison"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al prednisone"
              }
            ]
          },
          {
            "code" : "294683007",
            "display" : "Allergy to fluorometholone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluorometholone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluorométholone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluorometholon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluorometolone"
              }
            ]
          },
          {
            "code" : "294685000",
            "display" : "Allergy to desonide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to desonide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au désonide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Desonid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla desonide"
              }
            ]
          },
          {
            "code" : "294687008",
            "display" : "Allergy to fluocinonide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluocinonide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fluocinonide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluocinonid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluocinonide"
              }
            ]
          },
          {
            "code" : "294690002",
            "display" : "Allergy to halcinonide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to halcinonide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'halcinonide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Halcinonid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alcinonide"
              }
            ]
          },
          {
            "code" : "294692005",
            "display" : "Allergy to beclometasone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to beclometasone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la béclométasone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Beclometason"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al beclometasone"
              }
            ]
          },
          {
            "code" : "294693000",
            "display" : "Allergy to clobetasol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clobetasol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clobétasol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clobetasol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clobetasolo"
              }
            ]
          },
          {
            "code" : "294698009",
            "display" : "Allergy to fludrocortisone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fludrocortisone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fludrocortisone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fludrocortison"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fludrocortisone"
              }
            ]
          },
          {
            "code" : "294700000",
            "display" : "Allergy to fluticasone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluticasone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluticasone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluticason"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluticasone"
              }
            ]
          },
          {
            "code" : "294701001",
            "display" : "Allergy to mometasone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mometasone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mométasone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mometason"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mometasone"
              }
            ]
          },
          {
            "code" : "294702008",
            "display" : "Allergy to dexamethasone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dexamethasone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dexaméthasone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dexamethason"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al desametasone"
              }
            ]
          },
          {
            "code" : "294707002",
            "display" : "Allergy to prednisolone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to prednisolone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la prednisolone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Prednisolon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al prednisolone"
              }
            ]
          },
          {
            "code" : "294711008",
            "display" : "Allergy to triamcinolone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to triamcinolone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la triamcinolone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Triamcinolon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al triamcinolone"
              }
            ]
          },
          {
            "code" : "294712001",
            "display" : "Allergy to budesonide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to budesonide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la budésonide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Budesonid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla budesonide"
              }
            ]
          },
          {
            "code" : "294714000",
            "display" : "Allergy to insulin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to insulin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'insuline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Insulin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’insulina"
              }
            ]
          },
          {
            "code" : "294731007",
            "display" : "Allergy to glibenclamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to glibenclamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au glibenclamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Glibenclamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla glibenclamide"
              }
            ]
          },
          {
            "code" : "294732000",
            "display" : "Allergy to glibornuride (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to glibornuride"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au glibornuride"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Glibornurid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla glibornuride"
              }
            ]
          },
          {
            "code" : "294733005",
            "display" : "Allergy to gliclazide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gliclazide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au gliclazide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gliclazid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla gliclazide"
              }
            ]
          },
          {
            "code" : "294740006",
            "display" : "Allergy to metformin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to metformin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la metformine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Metformin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla metformina"
              }
            ]
          },
          {
            "code" : "294747009",
            "display" : "Allergy to dydrogesterone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dydrogesterone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dydrogestérone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dydrogesteron"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al didrogesterone"
              }
            ]
          },
          {
            "code" : "294752004",
            "display" : "Allergy to norethisterone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to norethisterone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la noréthistérone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Norethisteron"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al noretisterone"
              }
            ]
          },
          {
            "code" : "294754003",
            "display" : "Allergy to levonorgestrel (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to levonorgestrel"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au lévonorgestrel"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Levonorgestrel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al levonorgestrel"
              }
            ]
          },
          {
            "code" : "294758000",
            "display" : "Allergy to tibolone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tibolone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tibolone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tibolon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tibolone"
              }
            ]
          },
          {
            "code" : "294764007",
            "display" : "Allergy to danazol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to danazol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au danazol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Danazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al danazolo"
              }
            ]
          },
          {
            "code" : "294767000",
            "display" : "Allergy to finasteride (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to finasteride"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au finastéride"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Finasterid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla finasteride"
              }
            ]
          },
          {
            "code" : "294769002",
            "display" : "Allergy to bicalutamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bicalutamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bicalutamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bicalutamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla bicalutamide"
              }
            ]
          },
          {
            "code" : "294773004",
            "display" : "Allergy to androgen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to androgen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au traitement antiandrogène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Androgen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli androgeni"
              }
            ]
          },
          {
            "code" : "294776007",
            "display" : "Allergy to testosterone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to testosterone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la testostérone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Testosteron"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al testosterone"
              }
            ]
          },
          {
            "code" : "294781003",
            "display" : "Allergy to estrogen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to estrogen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux œstrogènes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Östrogen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli estrogeni"
              }
            ]
          },
          {
            "code" : "294782005",
            "display" : "Allergy to estradiol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to estradiol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'estradiol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Östradiol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’estradiolo"
              }
            ]
          },
          {
            "code" : "294794001",
            "display" : "Allergy to estriol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to estriol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'estriol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Östriol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’estriolo"
              }
            ]
          },
          {
            "code" : "294798003",
            "display" : "Allergy to clomifene (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clomifene"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clomifène"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clomifen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clomifene"
              }
            ]
          },
          {
            "code" : "294800005",
            "display" : "Allergy to cabergoline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cabergoline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cabergoline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cabergolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cabergolina"
              }
            ]
          },
          {
            "code" : "294807008",
            "display" : "Allergy to desmopressin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to desmopressin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la desmopressine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Desmopressin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla desmopressina"
              }
            ]
          },
          {
            "code" : "294809006",
            "display" : "Allergy to terlipressin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to terlipressin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la terlipressine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Terlipressin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla terlipressina"
              }
            ]
          },
          {
            "code" : "294810001",
            "display" : "Allergy to antidiuretic hormone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to antidiuretic hormone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hormone antidiurétique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen das antidiuretische Hormon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ormone antidiuretico"
              }
            ]
          },
          {
            "code" : "294815006",
            "display" : "Allergy to gonadorelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gonadorelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la gonadoréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gonadorelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla gonadorelina"
              }
            ]
          },
          {
            "code" : "294816007",
            "display" : "Allergy to nafarelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nafarelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nafaréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nafarelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nafarelina"
              }
            ]
          },
          {
            "code" : "294817003",
            "display" : "Allergy to buserelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to buserelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la buséréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Buserelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla buserelina"
              }
            ]
          },
          {
            "code" : "294819000",
            "display" : "Allergy to triptorelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to triptorelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la triptoréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Triptorelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla triptorelina"
              }
            ]
          },
          {
            "code" : "294821005",
            "display" : "Allergy to leuprorelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to leuprorelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la leuproréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Leuprorelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla leuprorelina"
              }
            ]
          },
          {
            "code" : "294823008",
            "display" : "Allergy to oxytocin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oxytocin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'oxytocine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Oxytocin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’ossitocina"
              }
            ]
          },
          {
            "code" : "294825001",
            "display" : "Allergy to somatropin hormone (finding)|",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to somatropin hormone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la somatropine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Somatotropin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla somatropina"
              }
            ]
          },
          {
            "code" : "294826000",
            "display" : "Allergy to octreotide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to octreotide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'octréotide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Octreotid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’octreotide"
              }
            ]
          },
          {
            "code" : "294829007",
            "display" : "Allergy to protirelin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to protirelin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la protiréline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Protirelin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla protirelina"
              }
            ]
          },
          {
            "code" : "294833000",
            "display" : "Allergy to bisphosphonate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bisphosphonate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux bisphosphonates"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bisphosphonat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai bifosfonati"
              }
            ]
          },
          {
            "code" : "294839001",
            "display" : "Allergy to calcitonin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to calcitonin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la calcitonine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Calcitonin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla calcitonina"
              }
            ]
          },
          {
            "code" : "294840004",
            "display" : "Allergy to salmon calcitonin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to salmon calcitonin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la calcitonine de saumon"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Calcitonin vom Lachs"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla calcitonina di salmone"
              }
            ]
          },
          {
            "code" : "294844008",
            "display" : "Allergy to epoetin alfa (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to epoetin alfa"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'époétine alpha"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Epoetin alfa"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’epoetina alfa"
              }
            ]
          },
          {
            "code" : "294845009",
            "display" : "Allergy to epoetin beta (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to epoetin beta"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'époétine bêta"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Epoetin beta"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’epoetina beta"
              }
            ]
          },
          {
            "code" : "294872001",
            "display" : "Allergy to heparin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to heparin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'héparine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Heparin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’eparina"
              }
            ]
          },
          {
            "code" : "294873006",
            "display" : "Allergy to enoxaparin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to enoxaparin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'énoxaparine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Enoxaparin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’enoxaparina"
              }
            ]
          },
          {
            "code" : "294874000",
            "display" : "Allergy to dalteparin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dalteparin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la daltéparine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dalteparin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla dalteparina"
              }
            ]
          },
          {
            "code" : "294876003",
            "display" : "Allergy to heparinoid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to heparinoid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'héparinoïde"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Heparinoid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’eparinoide"
              }
            ]
          },
          {
            "code" : "294881007",
            "display" : "Allergy to warfarin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to warfarin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la warfarine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Warfarin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al warfarin"
              }
            ]
          },
          {
            "code" : "294887006",
            "display" : "Allergy to tranexamic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tranexamic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide tranexamique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tranexamsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido tranexamico"
              }
            ]
          },
          {
            "code" : "294889009",
            "display" : "Allergy to aprotinin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aprotinin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'aprotinine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aprotinin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’aprotinina"
              }
            ]
          },
          {
            "code" : "294913003",
            "display" : "Allergy to iodine compound (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to iodine compound"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux composés de l'iode"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Jodverbindungen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai composti dello iodio"
              }
            ]
          },
          {
            "code" : "294923007",
            "display" : "Allergy to retinol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to retinol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la vitamine A"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Retinol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al retinolo"
              }
            ]
          },
          {
            "code" : "294933004",
            "display" : "Allergy to hydroxocobalamin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hydroxocobalamin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydroxocobalamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hydroxocobalamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idrossicobalamina"
              }
            ]
          },
          {
            "code" : "294934005",
            "display" : "Allergy to cyanocobalamin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cyanocobalamin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cyanocobalamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cyanocobalamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla cianocobalamina"
              }
            ]
          },
          {
            "code" : "294940003",
            "display" : "Allergy to ascorbic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to ascorbic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide ascorbique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Ascorbinsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido ascorbico"
              }
            ]
          },
          {
            "code" : "294951003",
            "display" : "Allergy to fluoride (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluoride"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fluoride"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluorid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fluoruro"
              }
            ]
          },
          {
            "code" : "294956008",
            "display" : "Allergy to gemfibrozil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to gemfibrozil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au gemfibrozil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gemfibrozil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al gemfibrozil"
              }
            ]
          },
          {
            "code" : "294958009",
            "display" : "Allergy to acipimox (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acipimox"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acipimox"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acipimox"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acipimox"
              }
            ]
          },
          {
            "code" : "294962003",
            "display" : "Allergy to colestyramine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to colestyramine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la cholestyramine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Colestyramin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla colestiramina"
              }
            ]
          },
          {
            "code" : "294964002",
            "display" : "Allergy to bezafibrate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bezafibrate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bézafibrate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bezafibrat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al bezafibrato"
              }
            ]
          },
          {
            "code" : "294965001",
            "display" : "Allergy to clofibrate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clofibrate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au clofibrate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Clofibrat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clofibrato"
              }
            ]
          },
          {
            "code" : "294966000",
            "display" : "Allergy to fenofibrate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fenofibrate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fénofibrate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fenofibrat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fenofibrato"
              }
            ]
          },
          {
            "code" : "294971007",
            "display" : "Allergy to simvastatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to simvastatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la simvastatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Simvastatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla simvastatina"
              }
            ]
          },
          {
            "code" : "294972000",
            "display" : "Allergy to fluvastatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fluvastatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la fluvastatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fluvastatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla fluvastatina"
              }
            ]
          },
          {
            "code" : "294973005",
            "display" : "Allergy to pravastatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pravastatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pravastatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pravastatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pravastatina"
              }
            ]
          },
          {
            "code" : "294975003",
            "display" : "Allergy to adenosine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to adenosine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'adénosine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Adenosin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’adenosina"
              }
            ]
          },
          {
            "code" : "294977006",
            "display" : "Allergy to disopyramide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to disopyramide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au disopyramide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Disopyramid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla disopiramide"
              }
            ]
          },
          {
            "code" : "294980007",
            "display" : "Allergy to mexiletine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mexiletine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la mexilétine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mexiletin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mexiletina"
              }
            ]
          },
          {
            "code" : "294982004",
            "display" : "Allergy to procainamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to procainamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au procaïnamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Procainamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla procainamide"
              }
            ]
          },
          {
            "code" : "294995009",
            "display" : "Allergy to hydrochlorothiazide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hydrochlorothiazide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydrochlorothiazide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hydrochlorothiazid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idroclorotiazide"
              }
            ]
          },
          {
            "code" : "295000003",
            "display" : "Allergy to furosemide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to furosemide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au furosémide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Furosemid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla furosemide"
              }
            ]
          },
          {
            "code" : "295003001",
            "display" : "Allergy to piretanide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piretanide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pirétanide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piretanid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al piretanide"
              }
            ]
          },
          {
            "code" : "295004007",
            "display" : "Allergy to torasemide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to torasemide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la torasémide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Torasemid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla torasemide"
              }
            ]
          },
          {
            "code" : "295008005",
            "display" : "Allergy to potassium canrenoate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to potassium canrenoate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au canrénoate de potassium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kaliumcanrenoat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al potassio canrenoato"
              }
            ]
          },
          {
            "code" : "295009002",
            "display" : "Allergy to spironolactone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to spironolactone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la spironolactone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Spironolacton"
              },
              {
                "language" : "it-CH",
                "value" : "allergia allo spironolattone"
              }
            ]
          },
          {
            "code" : "295010007",
            "display" : "Allergy to amiloride (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amiloride"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amiloride"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amilorid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amiloride"
              }
            ]
          },
          {
            "code" : "295019008",
            "display" : "Allergy to mannitol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mannitol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au mannitol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mannitol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mannitolo"
              }
            ]
          },
          {
            "code" : "295023000",
            "display" : "Allergy to chlortalidone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chlortalidone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la chlortalidone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Chlortalidon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al clortalidone"
              }
            ]
          },
          {
            "code" : "295024006",
            "display" : "Allergy to indapamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to indapamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allerge à l'indapamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Indapamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’indapamide"
              }
            ]
          },
          {
            "code" : "295026008",
            "display" : "Allergy to metolazone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to metolazone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la métolazone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Metolazon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metolazone"
              }
            ]
          },
          {
            "code" : "295030006",
            "display" : "Allergy to acetazolamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acetazolamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acétazolamide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acetazolamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acetazolamide"
              }
            ]
          },
          {
            "code" : "295054001",
            "display" : "Allergy to digoxin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to digoxin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la digoxine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Digoxin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla digossina"
              }
            ]
          },
          {
            "code" : "295055000",
            "display" : "Allergy to digitoxin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to digitoxin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la digitoxine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Digitoxin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla digitossina"
              }
            ]
          },
          {
            "code" : "295059006",
            "display" : "Allergy to phosphodiesterase inhibitor (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to phosphodiesterase inhibitor"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux inhibiteurs de phosphodiestérase"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Phosphodiesterasehemmer"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli inibitori della fosfodiesterasi"
              }
            ]
          },
          {
            "code" : "295062009",
            "display" : "Allergy to milrinone (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to milrinone"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la milrinone"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Milrinon"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al milrinone"
              }
            ]
          },
          {
            "code" : "295071000",
            "display" : "Allergy to minoxidil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to minoxidil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au minoxidil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Minoxidil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al minoxidil"
              }
            ]
          },
          {
            "code" : "295074008",
            "display" : "Allergy to diazoxide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to diazoxide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au diazoxide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Diazoxid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al diazossido"
              }
            ]
          },
          {
            "code" : "295075009",
            "display" : "Allergy to hydralazine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hydralazine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'hydralazine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hydralazin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’idralazina"
              }
            ]
          },
          {
            "code" : "295079003",
            "display" : "Allergy to glyceryl trinitrate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to glyceryl trinitrate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la nitroglycérine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Glycerintrinitrat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nitroglicerina"
              }
            ]
          },
          {
            "code" : "295108008",
            "display" : "Allergy to streptokinase (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to streptokinase"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la streptokinase"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Streptokinase"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla streptochinasi"
              }
            ]
          },
          {
            "code" : "295109000",
            "display" : "Allergy to urokinase (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to urokinase"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'urokinase"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Urokinase"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’urochinasi"
              }
            ]
          },
          {
            "code" : "295110005",
            "display" : "Allergy to alteplase (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to alteplase"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'altéplase"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Alteplase"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’alteplase"
              }
            ]
          },
          {
            "code" : "295111009",
            "display" : "Allergy to anistreplase (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to anistreplase"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'anistreplase"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Anistreplase"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’anistreplase"
              }
            ]
          },
          {
            "code" : "295112002",
            "display" : "Allergy to bromelains (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bromelains"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux bromélaïnes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bromelain"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla bromelina"
              }
            ]
          },
          {
            "code" : "300910009",
            "display" : "Allergy to pollen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pollen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pollen"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pollen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai pollini"
              }
            ]
          },
          {
            "code" : "300912001",
            "display" : "Allergy to chocolate (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chocolate"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au chocolat"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Schokolade"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cioccolato"
              }
            ]
          },
          {
            "code" : "417532002",
            "display" : "Allergy to fish (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fish"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au poisson"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Fisch"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al pesce"
              }
            ]
          },
          {
            "code" : "417918006",
            "display" : "Allergy to pork (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pork"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au porc"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Schweinefleisch"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carne di maiale"
              }
            ]
          },
          {
            "code" : "418085001",
            "display" : "Allergy to citrus fruit (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to citrus fruit"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au citron"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Zitrusfrüchte"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli agrumi"
              }
            ]
          },
          {
            "code" : "418689008",
            "display" : "Allergy to grass pollen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to grass pollen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pollen de graminées"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gräserpollen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai pollini di graminacee"
              }
            ]
          },
          {
            "code" : "418779002",
            "display" : "Allergy to tomato (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tomato"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la tomate"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tomate"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al pomodoro"
              }
            ]
          },
          {
            "code" : "419263009",
            "display" : "Allergy to tree pollen (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tree pollen"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au pollen d' arbres"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Baumpollen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai pollini di alberi"
              }
            ]
          },
          {
            "code" : "419412007",
            "display" : "Allergy to rubber (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to rubber"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au caoutchouc"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gummi"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al lattice"
              }
            ]
          },
          {
            "code" : "419573007",
            "display" : "Allergy to corn (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to corn"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au maïs"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mais"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al mais"
              }
            ]
          },
          {
            "code" : "419619007",
            "display" : "Allergy to potato (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to potato"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pomme de terre"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kartoffeln"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla patata"
              }
            ]
          },
          {
            "code" : "419788000",
            "display" : "Allergy to nickel (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nickel"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nickel"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nickel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al nichel"
              }
            ]
          },
          {
            "code" : "419972009",
            "display" : "Allergy to shrimp (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to shrimp"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux crevettes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Shrimps"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai gamberetti"
              }
            ]
          },
          {
            "code" : "420080006",
            "display" : "Allergy to carrot (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carrot"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la carotte"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Karotten"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carota"
              }
            ]
          },
          {
            "code" : "420174000",
            "display" : "Allergy to wheat (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to wheat"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au blé"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Weizen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al grano"
              }
            ]
          },
          {
            "code" : "423058007",
            "display" : "Allergy to wasp venom (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to wasp venom"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au venin de guêpe"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Wespengift"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al veleno di vespa"
              }
            ]
          },
          {
            "code" : "424213003",
            "display" : "Allergy to bee venom (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bee venom"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au venin d'abeille"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bienengift"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al veleno di ape"
              }
            ]
          },
          {
            "code" : "441954006",
            "display" : "Allergy to sevoflurane (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sevoflurane"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la sévoflurane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sevofluran"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sevoflurano"
              }
            ]
          },
          {
            "code" : "441955007",
            "display" : "Allergy to sufentanil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sufentanil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au sufentanil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sufentanil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sufentanil"
              }
            ]
          },
          {
            "code" : "441992007",
            "display" : "Allergy to remifentanil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to remifentanil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au rémifentanil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Remifentanil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al remifentanil"
              }
            ]
          },
          {
            "code" : "448438007",
            "display" : "Allergy to cisatracurium (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cisatracurium"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au cisatracurium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cisatracurium"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al cisatracurio"
              }
            ]
          },
          {
            "code" : "450767000",
            "display" : "Allergy to tramadol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tramadol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tramadol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Tramadol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tramadolo"
              }
            ]
          },
          {
            "code" : "473077006",
            "display" : "Allergy to teriparatide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to teriparatide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au tériparatide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Teriparatid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al teriparatide"
              }
            ]
          },
          {
            "code" : "609409007",
            "display" : "Pseudoallergic reaction caused by sulfite (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Pseudoallergic reaction caused by sulfite"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction pseudo-allergique aux sulfites"
              },
              {
                "language" : "de-CH",
                "value" : "Pseudoallergische Reaktion, verursacht durch Sulfit"
              },
              {
                "language" : "it-CH",
                "value" : "reazione pseudoallergica causata da solfiti"
              }
            ]
          },
          {
            "code" : "609534005",
            "display" : "Non-allergic hypersensitivity to losartan (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "hypersensibilité non allergique au losartan"
              },
              {
                "language" : "fr-CH",
                "value" : "Non-allergic hypersensitivity to losartan"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Losartan"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al losartan"
              }
            ]
          },
          {
            "code" : "609536007",
            "display" : "Non-allergic hypersensitivity to dextran (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to dextran"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au dextran"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Dextran"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al destrano"
              }
            ]
          },
          {
            "code" : "609538008",
            "display" : "Non-allergic hypersensitivity to captopril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to captopril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au captopril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Captopril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al captopril"
              }
            ]
          },
          {
            "code" : "609539000",
            "display" : "Non-allergic hypersensitivity to cilazapril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to cilazapril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au cilazapril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Cilazapril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al cilazapril"
              }
            ]
          },
          {
            "code" : "609540003",
            "display" : "Non-allergic hypersensitivity to enalapril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to enalapril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique à l'enalapril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Enalapril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica all’enalapril"
              }
            ]
          },
          {
            "code" : "609541004",
            "display" : "Non-allergic hypersensitivity to fosinopril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to fosinopril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au forsinopril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Fosinopril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al fosinopril"
              }
            ]
          },
          {
            "code" : "609542006",
            "display" : "Non-allergic hypersensitivity to lisinopril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to lisinopril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au lisinopril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Lisinopril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al lisinopril"
              }
            ]
          },
          {
            "code" : "609543001",
            "display" : "Non-allergic hypersensitivity to perindopril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to perindopril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au perindopril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Perindopril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al perindopril"
              }
            ]
          },
          {
            "code" : "609544007",
            "display" : "Non-allergic hypersensitivity to quinapril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to quinapril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au quinapril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Quinapril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al quinapril"
              }
            ]
          },
          {
            "code" : "609545008",
            "display" : "Non-allergic hypersensitivity to ramipril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to ramipril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au ramipril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Ramipril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al ramipril"
              }
            ]
          },
          {
            "code" : "609546009",
            "display" : "Non-allergic hypersensitivity to trandolapril (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to trandolapril"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique au trandolapril"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Trandolapril"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al trandolapril"
              }
            ]
          },
          {
            "code" : "609548005",
            "display" : "Non-allergic hypersensitivity to aspartame (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to aspartame"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique à l'aspartame"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Aspartam"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica all’aspartame"
              }
            ]
          },
          {
            "code" : "700468006",
            "display" : "Allergy to Rotavirus vaccine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Rotavirus vaccine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au vaccin contre le rotavirus"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Rotavirus-Impfstoff"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al vaccino contro i rotavirus"
              }
            ]
          },
          {
            "code" : "703076003",
            "display" : "Non-allergic hypersensitivity to benzoic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to benzoic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensibilité non allergique à l'acide benzoïque"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Benzoesäure"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica all’acido benzoico"
              }
            ]
          },
          {
            "code" : "703930000",
            "display" : "Allergy to beef (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to beef"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au bœuf"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Rindfleisch"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carne di manzo"
              }
            ]
          },
          {
            "code" : "703932008",
            "display" : "Allergy to chicken meat (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to chicken meat"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la viande de poulet"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pouletfleisch"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carne di pollo"
              }
            ]
          },
          {
            "code" : "712840004",
            "display" : "Allergy to hazelnut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to hazelnut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux noisettes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Haselnüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle nocciole"
              }
            ]
          },
          {
            "code" : "712843002",
            "display" : "Allergy to celery (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to celery"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au céleri"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sellerie"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sedano"
              }
            ]
          },
          {
            "code" : "713018004",
            "display" : "Allergy to darunavir (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to darunavir"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au darunavir"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Darunavir"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al darunavir"
              }
            ]
          },
          {
            "code" : "713296005",
            "display" : "Allergy to protease inhibitor (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to protease inhibitor"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux inhibiteurs de la protéase rétrovirale"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Proteasehemmer"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli inibitori della proteasi"
              }
            ]
          },
          {
            "code" : "713707006",
            "display" : "Allergy to abacavir (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to abacavir"
              },
              {
                "language" : "fr-CH",
                "value" : "allerge à l'abacavir"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Abacavir"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'abacavir"
              }
            ]
          },
          {
            "code" : "713725004",
            "display" : "Allergy to nevirapine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nevirapine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la névirapine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nevirapin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla nevirapina"
              }
            ]
          },
          {
            "code" : "714332003",
            "display" : "Allergy to banana (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to banana"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la banane"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bananen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla banana"
              }
            ]
          },
          {
            "code" : "718535005",
            "display" : "Allergy to pitavastatin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pitavastatin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pitavastatine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pitavastatin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla pitavastatina"
              }
            ]
          },
          {
            "code" : "737493007",
            "display" : "Allergy to denosumab (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to denosumab"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au dénosumab"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Denosumab"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al denosumab"
              }
            ]
          },
          {
            "code" : "767203005",
            "display" : "Allergy to cromoglicic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cromoglicic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide cromoglicide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cromoglicinsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido cromoglicico"
              }
            ]
          },
          {
            "code" : "767468001",
            "display" : "Allergy to pea (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pea"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux pois"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Erbsen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai piselli"
              }
            ]
          },
          {
            "code" : "767475000",
            "display" : "Allergy to vitamin B12 and vitamin B12 derivative (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to vitamin B12 and vitamin B12 derivative"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la vitamine B12 et aux substances apparentées"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Vitamin B12 und Vitamin B12-Derivate"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla vitamina B12 e ai derivati della vitamina B12"
              }
            ]
          },
          {
            "code" : "767478003",
            "display" : "Allergy to thiamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la thiamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla tiamina"
              }
            ]
          },
          {
            "code" : "767479006",
            "display" : "Allergy to pyridoxine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pyridoxine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pyridoxine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pyridoxin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla piridossina"
              }
            ]
          },
          {
            "code" : "772021008",
            "display" : "Allergy to nebivolol (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to nebivolol"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au nébivolol"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nebivolol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al nebivololo"
              }
            ]
          },
          {
            "code" : "773399002",
            "display" : "Allergy to acetylcholine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to acetylcholine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acétylcholine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Acetylcholin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acetilcolina"
              }
            ]
          },
          {
            "code" : "773427008",
            "display" : "Allergy to danaparoid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to danaparoid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au danaparoïde"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Danaparoid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al danaparoid"
              }
            ]
          },
          {
            "code" : "773485002",
            "display" : "Allergy to valproic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to valproic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide valproïque"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Valproinsäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido valproico"
              }
            ]
          },
          {
            "code" : "773490004",
            "display" : "Allergy to dihydroergotamine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to dihydroergotamine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la dihydroergotamine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dihydroergotamin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla diidroergotamina"
              }
            ]
          },
          {
            "code" : "773491000",
            "display" : "Allergy to pamidronic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pamidronic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'acide pamidronique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Pamidronat"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’acido pamidronico"
              }
            ]
          },
          {
            "code" : "773505002",
            "display" : "Allergy to propamidine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to propamidine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la propamidine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Propamidin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla propamidina"
              }
            ]
          },
          {
            "code" : "77560002",
            "display" : "Contact dermatitis caused by adhesive plaster (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Contact dermatitis caused by adhesive plaster"
              },
              {
                "language" : "fr-CH",
                "value" : "dermatite de contact due aux pansements adhésifs"
              },
              {
                "language" : "de-CH",
                "value" : "Kontaktdermatitis, verursacht durch Heftpflaster"
              },
              {
                "language" : "it-CH",
                "value" : "dermatite da contatto causata da cerotto adesivo"
              }
            ]
          },
          {
            "code" : "782415009",
            "display" : "Intolerance to lactose (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Intolerance to lactose"
              },
              {
                "language" : "fr-CH",
                "value" : "intolérance au lactose"
              },
              {
                "language" : "de-CH",
                "value" : "Laktoseintoleranz"
              },
              {
                "language" : "it-CH",
                "value" : "intolleranza al lattosio"
              }
            ]
          },
          {
            "code" : "782529008",
            "display" : "Allergy to digitalis glycoside (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to digitalis glycoside"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au glucoside digitalique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Digitalisglykosid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai glicosidi digitalici"
              }
            ]
          },
          {
            "code" : "782563005",
            "display" : "Allergy to lithium compound (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lithium compound"
              },
              {
                "language" : "fr-CH",
                "value" : "Allergie au composé de lithium"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lithiumverbindungen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai composti del litio"
              }
            ]
          },
          {
            "code" : "782575000",
            "display" : "Allergy to lupine seed (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lupine seed"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux graines de lupin"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Lupinensamen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai semi di lupino"
              }
            ]
          },
          {
            "code" : "782595006",
            "display" : "Allergy to thiouracil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiouracil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au thiouracil"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiouracil"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al tiouracile"
              }
            ]
          },
          {
            "code" : "78373000",
            "display" : "Sucrase-isomaltase deficiency (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Sucrase-isomaltase deficiency"
              },
              {
                "language" : "fr-CH",
                "value" : "déficit en sucrase-isomaltase"
              },
              {
                "language" : "de-CH",
                "value" : "Sucrase-Isomaltase-Mangel"
              },
              {
                "language" : "it-CH",
                "value" : "deficit di sucrasi-isomaltasi"
              }
            ]
          },
          {
            "code" : "830080006",
            "display" : "Allergy to zinc and zinc compound (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to zinc and zinc compound"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au zinc et à ses composés"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Zink und Zinkverbindungen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia allo zinco e ai composti dello zinco"
              }
            ]
          },
          {
            "code" : "830171008",
            "display" : "Allergy to meclozine (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to meclozine"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la méclozine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Meclozin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla meclozina"
              }
            ]
          },
          {
            "code" : "830172001",
            "display" : "Allergy to metamizole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to metamizole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au métamizole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Metamizol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al metamizolo"
              }
            ]
          },
          {
            "code" : "860604008",
            "display" : "Allergy to apple (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to apple"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux pommes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Äpfel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla mela"
              }
            ]
          },
          {
            "code" : "860764004",
            "display" : "Allergy to triazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to triazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au triazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Triazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai triazoli"
              }
            ]
          },
          {
            "code" : "860775000",
            "display" : "Allergy to imidazole (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to imidazole"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'imidazole"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Imidazol"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'imidazolo"
              }
            ]
          },
          {
            "code" : "870712009",
            "display" : "Allergy to piperacillin and/or tazobactam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to piperacillin and/or tazobactam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pipéracilline et/ou au tazobactam"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Piperacillin und/oder Tazobactam"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla piperacillina e/o al tazobactam"
              }
            ]
          },
          {
            "code" : "870714005",
            "display" : "Allergy to sulfamethoxazole and/or trimethoprim (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "allergie au sulfaméthoxazole et/ou au triméthoprime"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie to sulfamethoxazole and/or trimethoprim"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfamethoxazol und/oder Trimethoprim"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al sulfametossazolo e/o al trimetoprim"
              }
            ]
          },
          {
            "code" : "870731003",
            "display" : "Allergy to carbidopa and/or levodopa (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to carbidopa and/or levodopa"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la carbidopa et/ou à la levodopa"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Carbidopa und/oder Levodopa"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla carbidopa e/o alla levodopa"
              }
            ]
          },
          {
            "code" : "870749003",
            "display" : "Allergic contact dermatitis caused by usnic acid (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergic contact dermatitis caused by usnic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "dermatite de contact allergique due à l'acide usnique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergische Kontaktdermatitis, verursacht durch Usninsäure"
              },
              {
                "language" : "it-CH",
                "value" : "dermatite allergica da contatto causata da acido usnico"
              }
            ]
          },
          {
            "code" : "871508005",
            "display" : "Allergy to amoxicillin and/or clavulanic acid (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to amoxicillin and/or clavulanic acid"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'amoxicilline et/ou à l'acide clavulanique"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Amoxicillin und/oder Clavulansäure"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’amoxicillina e/o all'acido clavulanico"
              }
            ]
          },
          {
            "code" : "91931000",
            "display" : "Allergy to erythromycin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to erythromycin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'érythromycine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Erythromycin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'eritromicina"
              }
            ]
          },
          {
            "code" : "91935009",
            "display" : "Allergy to peanut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to peanut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux arachides"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Erdnüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle arachidi"
              }
            ]
          },
          {
            "code" : "91936005",
            "display" : "Allergy to penicillin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to penicillin"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la pénicilline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Penicillin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla penicillina"
              }
            ]
          },
          {
            "code" : "91938006",
            "display" : "Allergy to strawberry (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to strawberry"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux fraises"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Erdbeeren"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle fragole"
              }
            ]
          },
          {
            "code" : "91939003",
            "display" : "Allergy to sulfonamide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to sulfonamide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux sulfamides"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Sulfonamid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai sulfamidici"
              }
            ]
          },
          {
            "code" : "91940001",
            "display" : "Allergy to walnut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to walnut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux noix"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Walnüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle noci"
              }
            ]
          },
          {
            "code" : "294031004",
            "display" : "Allergy to xylometazoline (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to xylometazoline"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à la xylométazoline"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Xylometazolin"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla xilometazolina"
              }
            ]
          },
          {
            "code" : "860765003",
            "display" : "Allergy to thiazide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to thiazide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux thiazidiques"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Thiazid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai tiazidici"
              }
            ]
          },
          {
            "code" : "860907004",
            "display" : "Allergy to macrolide (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to macrolide"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux macrolides"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Makrolid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai macrolidi"
              }
            ]
          },
          {
            "code" : "294462007",
            "display" : "Allergy to aminoglycoside (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to aminoglycoside"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux aminosides"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Aminoglykosid"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli aminoglicosidi"
              }
            ]
          },
          {
            "code" : "292937002",
            "display" : "Vancomycin adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Vancomycin adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la vancomycine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Vancomycin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla vancomicina"
              }
            ]
          },
          {
            "code" : "292691002",
            "display" : "Vecuronium adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Vecuronium adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable au vécuronium"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Vecuronium"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al vecuronio"
              }
            ]
          },
          {
            "code" : "269722001",
            "display" : "Adverse reaction caused by salicylate (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Adverse reaction caused by salicylate"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable au salicylate"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Salicylat"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa causata da salicilati"
              }
            ]
          },
          {
            "code" : "292044008",
            "display" : "Aspirin adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Aspirin adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à l'aspirine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Aspirin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa all’aspirina"
              }
            ]
          },
          {
            "code" : "292118005",
            "display" : "Mesalazine adverse reaction",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Mesalazine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la mésalazine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Mesalazin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla mesalazina"
              }
            ]
          },
          {
            "code" : "292054007",
            "display" : "Buprenorphine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Buprenorphine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la buprénorphine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Buprenorphin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla buprenorfina"
              }
            ]
          },
          {
            "code" : "292066001",
            "display" : "Meptazinol adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Meptazinol adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable au meptazinol"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Meptazinol"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al meptazinolo"
              }
            ]
          },
          {
            "code" : "292052006",
            "display" : "Methadone adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Methadone adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la méthadone"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Methadon"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al metadone"
              }
            ]
          },
          {
            "code" : "292046005",
            "display" : "Pentazocine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Pentazocine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la pentazocine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Pentazocin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla pentazocina"
              }
            ]
          },
          {
            "code" : "292055008",
            "display" : "Codeine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Codeine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la codéine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Kodein"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla codeina"
              }
            ]
          },
          {
            "code" : "292056009",
            "display" : "Diamorphine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Diamorphine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la diamorphine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Diamorphin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla diamorfina"
              }
            ]
          },
          {
            "code" : "292059002",
            "display" : "Morphine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Morphine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la morphine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Morphin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla morfina"
              }
            ]
          },
          {
            "code" : "292058005",
            "display" : "Nalbuphine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Nalbuphine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la nalbuphine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Nalbuphin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla nalbufina"
              }
            ]
          },
          {
            "code" : "292738000",
            "display" : "Naloxone adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Naloxone adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la naloxone"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Naloxon"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al naloxone"
              }
            ]
          },
          {
            "code" : "292737005",
            "display" : "Naltrexone adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Naltrexone adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable au naltrexone"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Naltrexon"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al naltrexone"
              }
            ]
          },
          {
            "code" : "292610002",
            "display" : "Pholcodine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Pholcodine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la pholcodine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Pholcodin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla folcodina"
              }
            ]
          },
          {
            "code" : "292062004",
            "display" : "Alfentanil adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Alfentanil adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à l'alfentanil"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Alfentanil"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa all’alfentanil"
              }
            ]
          },
          {
            "code" : "292063009",
            "display" : "Fentanyl adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Fentanyl adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable au fentanyl"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Fentanyl"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa al fentanyl"
              }
            ]
          },
          {
            "code" : "292064003",
            "display" : "Pethidine adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Pethidine adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable à la péthidine"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von Pethidin"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa alla petidina"
              }
            ]
          },
          {
            "code" : "703933003",
            "display" : "Allergy to Dermatophagoides pteronyssinus protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Dermatophagoides pteronyssinus protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux protéines de Dermatophagoïdes pteronyssinus"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dermatophagoides pteronyssinus-Protein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine di Dermatophagoides pteronyssinus"
              }
            ]
          },
          {
            "code" : "703902000",
            "display" : "Allergy to Dermatophagoides farinae protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Dermatophagoides farinae protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux protéines de Dermatophagoïdes farinae"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Dermatophagoides farinae-Protein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine di Dermatophagoides farinae"
              }
            ]
          },
          {
            "code" : "1003755004",
            "display" : "Allergy to Hevea brasiliensis latex protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Hevea brasiliensis latex protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux protéines du latex de l'Hevea brasiliensis"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hevea brasiliensis-Latexprotein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine del lattice di Hevea brasiliensis"
              }
            ]
          },
          {
            "code" : "232346004",
            "display" : "Allergy to cat dander (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cat dander"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux phanères de chat"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hautschuppen der Katze"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al pelo di gatto"
              }
            ]
          },
          {
            "code" : "712841000",
            "display" : "Allergy to barley (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to barley"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'orge"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Gerste"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’orzo"
              }
            ]
          },
          {
            "code" : "419342009",
            "display" : "Allergy to oat (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oat"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'avoine"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hafer"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’avena"
              }
            ]
          },
          {
            "code" : "418626004",
            "display" : "Allergy to lobster (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to lobster"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au homard"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hummer"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all'astice"
              }
            ]
          },
          {
            "code" : "409136006",
            "display" : "Allergy to pulse vegetable (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to pulse vegetable"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux légumineuses"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Hülsenfrüchte"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle leguminose"
              }
            ]
          },
          {
            "code" : "294317009",
            "display" : "Allergy to Arachis oil (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to Arachis oil"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie à l'huile d'arachide"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Arachisöl"
              },
              {
                "language" : "it-CH",
                "value" : "allergia all’olio di semi di arachide"
              }
            ]
          },
          {
            "code" : "767470005",
            "display" : "Allergy to fenugreek (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to fenugreek"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au fenugrec"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bockshornklee"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al fieno greco"
              }
            ]
          },
          {
            "code" : "703925004",
            "display" : "Allergy to bean (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to bean"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux fèves"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Bohnen"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai fagioli"
              }
            ]
          },
          {
            "code" : "48821000119104",
            "display" : "Allergy to tree nut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to tree nut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux fruits à coque"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Baumnüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alla frutta a guscio"
              }
            ]
          },
          {
            "code" : "712839001",
            "display" : "Allergy to almond (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to almond"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux amandes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Mandeln"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle mandorle"
              }
            ]
          },
          {
            "code" : "712838009",
            "display" : "Allergy to cashew nut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cashew nut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux noix de cajou"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Cashewnüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia agli anacardi"
              }
            ]
          },
          {
            "code" : "712844008",
            "display" : "Allergy to macadamia nut (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to macadamia nut"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux noix de macadamia"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Nacadamianüsse"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle noci di macadamia"
              }
            ]
          },
          {
            "code" : "712842007",
            "display" : "Allergy to mollusk (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mollusk"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux mollusques"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Weichtiere"
              },
              {
                "language" : "it-CH",
                "value" : "allergia ai molluschi"
              }
            ]
          },
          {
            "code" : "703911000",
            "display" : "Allergy to clam (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to clam"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux palourdes"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Venusmuscheln"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle vongole"
              }
            ]
          },
          {
            "code" : "12921000122102",
            "display" : "Allergy to mussel (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to mussel"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux moules"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Muscheln"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle cozze"
              }
            ]
          },
          {
            "code" : "419967000",
            "display" : "Allergy to oyster (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to oyster"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux huîtres"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Austern"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle ostriche"
              }
            ]
          },
          {
            "code" : "23171000122102",
            "display" : "Allergy to kiwi fruit (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to kiwi fruit"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au kiwi"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kiwifrucht"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al kiwi"
              }
            ]
          },
          {
            "code" : "293637006",
            "display" : "Allergy to contrast media (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to contrast media"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux produits de contraste"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kontrastmittel"
              },
              {
                "language" : "it-CH",
                "value" : "allergia a mezzo di contrasto"
              }
            ]
          },
          {
            "code" : "609551003",
            "display" : "Non-allergic hypersensitivity to contrast media (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to contrast media"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensitivité non allergique aux produits de contraste"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Kontrastmittel"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica a mezzo di contrasto"
              }
            ]
          },
          {
            "code" : "860936004",
            "display" : "Non-allergic hypersensitivity to gadolinium and gadolinium compound (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Non-allergic hypersensitivity to gadolinium and gadolinium compound"
              },
              {
                "language" : "fr-CH",
                "value" : "hypersensitivité non allergique au gadolinium et à ses composés"
              },
              {
                "language" : "de-CH",
                "value" : "Nicht-allergische Überempfindlichkeit gegenüber Gadolinium und Gadoliniumverbindungen"
              },
              {
                "language" : "it-CH",
                "value" : "ipersensibilità non allergica al gadolinio e ai composti del gadolinio"
              }
            ]
          },
          {
            "code" : "292097002",
            "display" : "Magnetic resonance imaging contrast media adverse reaction (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Magnetic resonance imaging contrast media adverse reaction"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction indésirable aux produits de contraste de l'imagerie par résonance magnétique"
              },
              {
                "language" : "de-CH",
                "value" : "Nebenwirkung von MRT-Kontrastmittel"
              },
              {
                "language" : "it-CH",
                "value" : "reazione avversa a mezzo di contrasto della tomografia a risonanza magnetica"
              }
            ]
          },
          {
            "code" : "16224591000119103",
            "display" : "Allergy to honey bee venom (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to honey bee venom"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie au venin d'abeilles domestiques"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Honigbienengift"
              },
              {
                "language" : "it-CH",
                "value" : "allergia al veleno di ape"
              }
            ]
          },
          {
            "code" : "782555009",
            "display" : "Allergy to cow's milk protein (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Allergy to cow's milk protein"
              },
              {
                "language" : "fr-CH",
                "value" : "allergie aux protéines de lait de vache"
              },
              {
                "language" : "de-CH",
                "value" : "Allergie gegen Kuhmilchprotein"
              },
              {
                "language" : "it-CH",
                "value" : "allergia alle proteine del latte vaccino"
              }
            ]
          },
          {
            "code" : "422400008",
            "display" : "Vomiting (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Vomiting"
              },
              {
                "language" : "fr-CH",
                "value" : "vomissement"
              },
              {
                "language" : "de-CH",
                "value" : "Erbrechen"
              },
              {
                "language" : "it-CH",
                "value" : "vomito"
              }
            ]
          },
          {
            "code" : "4386001",
            "display" : "Bronchospasm (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Bronchospasm"
              },
              {
                "language" : "fr-CH",
                "value" : "bronchospasme"
              },
              {
                "language" : "de-CH",
                "value" : "Bronchospasmus"
              },
              {
                "language" : "it-CH",
                "value" : "broncospasmo"
              }
            ]
          },
          {
            "code" : "9826008",
            "display" : "Conjunctivitis (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Conjunctivitis"
              },
              {
                "language" : "fr-CH",
                "value" : "conjonctivite"
              },
              {
                "language" : "de-CH",
                "value" : "Konjunktivitis"
              },
              {
                "language" : "it-CH",
                "value" : "congiuntivite"
              }
            ]
          },
          {
            "code" : "23924001",
            "display" : "Tight chest (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Tight chest"
              },
              {
                "language" : "fr-CH",
                "value" : "oppression thoracique"
              },
              {
                "language" : "de-CH",
                "value" : "Engegefühl im Brustkorb"
              },
              {
                "language" : "it-CH",
                "value" : "oppressione toracica"
              }
            ]
          },
          {
            "code" : "24079001",
            "display" : "Atopic dermatitis (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Atopic dermatitis"
              },
              {
                "language" : "fr-CH",
                "value" : "dermite atopique"
              },
              {
                "language" : "de-CH",
                "value" : "Atopische Dermatitis"
              },
              {
                "language" : "it-CH",
                "value" : "dermatite atopica"
              }
            ]
          },
          {
            "code" : "31996006",
            "display" : "Vasculitis (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Vasculitis"
              },
              {
                "language" : "fr-CH",
                "value" : "vasculite"
              },
              {
                "language" : "de-CH",
                "value" : "Vaskulitis"
              },
              {
                "language" : "it-CH",
                "value" : "vasculite"
              }
            ]
          },
          {
            "code" : "39579001",
            "display" : "Anaphylaxis (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Anaphylaxis"
              },
              {
                "language" : "fr-CH",
                "value" : "anaphylaxie"
              },
              {
                "language" : "de-CH",
                "value" : "Anaphylaxie"
              },
              {
                "language" : "it-CH",
                "value" : "anafilassi"
              }
            ]
          },
          {
            "code" : "41291007",
            "display" : "Angioedema (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Angioedema"
              },
              {
                "language" : "fr-CH",
                "value" : "angio-œdème"
              },
              {
                "language" : "de-CH",
                "value" : "Angioödem"
              },
              {
                "language" : "it-CH",
                "value" : "angioedema"
              }
            ]
          },
          {
            "code" : "43116000",
            "display" : "Eczema (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Eczema"
              },
              {
                "language" : "fr-CH",
                "value" : "eczéma"
              },
              {
                "language" : "de-CH",
                "value" : "Ekzem"
              },
              {
                "language" : "it-CH",
                "value" : "eczema"
              }
            ]
          },
          {
            "code" : "49727002",
            "display" : "Cough (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Cough"
              },
              {
                "language" : "fr-CH",
                "value" : "toux"
              },
              {
                "language" : "de-CH",
                "value" : "Husten"
              },
              {
                "language" : "it-CH",
                "value" : "tosse"
              }
            ]
          },
          {
            "code" : "51599000",
            "display" : "Edema of larynx (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Edema of larynx"
              },
              {
                "language" : "fr-CH",
                "value" : "œdème du larynx"
              },
              {
                "language" : "de-CH",
                "value" : "Kehlkopfödem"
              },
              {
                "language" : "it-CH",
                "value" : "edema della laringe"
              }
            ]
          },
          {
            "code" : "62315008",
            "display" : "Diarrhea (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Diarrhea"
              },
              {
                "language" : "fr-CH",
                "value" : "diarrhée"
              },
              {
                "language" : "de-CH",
                "value" : "Diarrhöe"
              },
              {
                "language" : "it-CH",
                "value" : "diarrea"
              }
            ]
          },
          {
            "code" : "70076002",
            "display" : "Rhinitis (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Rhinitis"
              },
              {
                "language" : "fr-CH",
                "value" : "rhinite"
              },
              {
                "language" : "de-CH",
                "value" : "Rhinitis"
              },
              {
                "language" : "it-CH",
                "value" : "rinite"
              }
            ]
          },
          {
            "code" : "73442001",
            "display" : "Stevens-Johnson syndrome (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Stevens-Johnson syndrome"
              },
              {
                "language" : "fr-CH",
                "value" : "syndrome de Stevens-Johnson"
              },
              {
                "language" : "de-CH",
                "value" : "Stevens-Johnson-Syndrom"
              },
              {
                "language" : "it-CH",
                "value" : "sindrome di Stevens-Johnson"
              }
            ]
          },
          {
            "code" : "76067001",
            "display" : "Sneezing (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Sneezing"
              },
              {
                "language" : "fr-CH",
                "value" : "éternuement"
              },
              {
                "language" : "de-CH",
                "value" : "Niesen"
              },
              {
                "language" : "it-CH",
                "value" : "starnuto"
              }
            ]
          },
          {
            "code" : "91175000",
            "display" : "Seizure (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Seizure"
              },
              {
                "language" : "fr-CH",
                "value" : "convulsion"
              },
              {
                "language" : "de-CH",
                "value" : "Konvulsion"
              },
              {
                "language" : "it-CH",
                "value" : "convulsione"
              }
            ]
          },
          {
            "code" : "126485001",
            "display" : "Urticaria (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Urticaria"
              },
              {
                "language" : "fr-CH",
                "value" : "urticaire"
              },
              {
                "language" : "de-CH",
                "value" : "Urtikaria"
              },
              {
                "language" : "it-CH",
                "value" : "orticaria"
              }
            ]
          },
          {
            "code" : "162290004",
            "display" : "Dry eyes (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Dry eyes"
              },
              {
                "language" : "fr-CH",
                "value" : "sècheresse oculaire"
              },
              {
                "language" : "de-CH",
                "value" : "Trockene Augen"
              },
              {
                "language" : "it-CH",
                "value" : "secchezza oculare"
              }
            ]
          },
          {
            "code" : "195967001",
            "display" : "Asthma (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Asthma"
              },
              {
                "language" : "fr-CH",
                "value" : "asthme"
              },
              {
                "language" : "de-CH",
                "value" : "Asthma"
              },
              {
                "language" : "it-CH",
                "value" : "asma"
              }
            ]
          },
          {
            "code" : "247472004",
            "display" : "Wheal (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Wheal"
              },
              {
                "language" : "fr-CH",
                "value" : "éruption urticaire"
              },
              {
                "language" : "de-CH",
                "value" : "Urtikarielles Exanthem"
              },
              {
                "language" : "it-CH",
                "value" : "eruzione orticaria"
              }
            ]
          },
          {
            "code" : "267036007",
            "display" : "Dyspnea (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Dyspnea"
              },
              {
                "language" : "fr-CH",
                "value" : "dyspnée"
              },
              {
                "language" : "de-CH",
                "value" : "Dyspnoe"
              },
              {
                "language" : "it-CH",
                "value" : "dispnea"
              }
            ]
          },
          {
            "code" : "271757001",
            "display" : "Papular eruption (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Papular eruption"
              },
              {
                "language" : "fr-CH",
                "value" : "éruption papuleuse"
              },
              {
                "language" : "de-CH",
                "value" : "Papulöses Exanthem"
              },
              {
                "language" : "it-CH",
                "value" : "eruzione papulare"
              }
            ]
          },
          {
            "code" : "271759003",
            "display" : "Bullous eruption (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Bullous eruption"
              },
              {
                "language" : "fr-CH",
                "value" : "éruption bulleuse"
              },
              {
                "language" : "de-CH",
                "value" : "Bullöses Exanthem"
              },
              {
                "language" : "it-CH",
                "value" : "eruzione bollosa"
              }
            ]
          },
          {
            "code" : "271807003",
            "display" : "Eruption of skin (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Eruption of skin"
              },
              {
                "language" : "fr-CH",
                "value" : "éruption cutanée"
              },
              {
                "language" : "de-CH",
                "value" : "Hautausschlag"
              },
              {
                "language" : "it-CH",
                "value" : "eruzione cutanea"
              }
            ]
          },
          {
            "code" : "359610006",
            "display" : "Ocular hyperemia (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Ocular hyperemia"
              },
              {
                "language" : "fr-CH",
                "value" : "hyperémie oculaire"
              },
              {
                "language" : "de-CH",
                "value" : "Okuläre Hyperämie"
              },
              {
                "language" : "it-CH",
                "value" : "iperemia oculare"
              }
            ]
          },
          {
            "code" : "410430005",
            "display" : "Cardiorespiratory arrest (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Cardiorespiratory arrest"
              },
              {
                "language" : "fr-CH",
                "value" : "arrêt cardiorespiratoire"
              },
              {
                "language" : "de-CH",
                "value" : "Kardiorespiratorischer Stillstand"
              },
              {
                "language" : "it-CH",
                "value" : "arresto cardiorespiratorio"
              }
            ]
          },
          {
            "code" : "418363000",
            "display" : "Itching of skin (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Itching of skin"
              },
              {
                "language" : "fr-CH",
                "value" : "prurit de la peau"
              },
              {
                "language" : "de-CH",
                "value" : "Pruritus"
              },
              {
                "language" : "it-CH",
                "value" : "prurito cutaneo"
              }
            ]
          },
          {
            "code" : "422587007",
            "display" : "Nausea (finding)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Nausea"
              },
              {
                "language" : "fr-CH",
                "value" : "nausées"
              },
              {
                "language" : "de-CH",
                "value" : "Nausea"
              },
              {
                "language" : "it-CH",
                "value" : "nausea"
              }
            ]
          },
          {
            "code" : "698247007",
            "display" : "Cardiac arrhythmia (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Cardiac arrhythmia"
              },
              {
                "language" : "fr-CH",
                "value" : "arythmie cardiaque"
              },
              {
                "language" : "de-CH",
                "value" : "Herzrhythmusstörung"
              },
              {
                "language" : "it-CH",
                "value" : "aritmia cardiaca"
              }
            ]
          },
          {
            "code" : "702809001",
            "display" : "Drug reaction with eosinophilia and systemic symptoms (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Drug reaction with eosinophilia and systemic symptoms"
              },
              {
                "language" : "fr-CH",
                "value" : "réaction médicamenteuse avec éosinophilie et symptômes systémiques"
              },
              {
                "language" : "de-CH",
                "value" : "Medikamentenreaktion mit Eosinophilie und systemischen Symptomen"
              },
              {
                "language" : "it-CH",
                "value" : "reazione al medicamento con eosinofilia e sintomi sistemici"
              }
            ]
          },
          {
            "code" : "768962006",
            "display" : "Lyell syndrome (disorder)",
            "designation" : [
              {
                "language" : "en-US",
                "value" : "Lyell syndrome"
              },
              {
                "language" : "fr-CH",
                "value" : "syndrome de Lyell"
              },
              {
                "language" : "de-CH",
                "value" : "Lyell-Syndrom"
              },
              {
                "language" : "it-CH",
                "value" : "sindrome di Lyell"
              }
            ]
          }
        ]
      }
    ]
  }
}

```
