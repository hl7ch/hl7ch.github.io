# ChCoreReligion - CH Term (R4) v3.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ChCoreReligion**

## ValueSet: ChCoreReligion 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-core/ValueSet/ch-core-religion | *Version*:3.4.0 |
| Active as of 2018-11-26 | *Computable Name*:ChCoreReligion |
| **Copyright/Legal**: CC0-1.0 | |

 
Religion combined by fhir and eCH-11 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/ch-core-religion) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-core-religion",
  "url" : "http://fhir.ch/ig/ch-core/ValueSet/ch-core-religion",
  "version" : "3.4.0",
  "name" : "ChCoreReligion",
  "title" : "ChCoreReligion",
  "status" : "active",
  "experimental" : false,
  "date" : "2018-11-26",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "Religion combined by fhir and eCH-11",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "valueSet" : ["http://terminology.hl7.org/ValueSet/v3-ReligiousAffiliation"]
    },
    {
      "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-religion",
      "concept" : [{
        "code" : "111",
        "display" : "evangelisch-reformierte (protestantische) Kirche",
        "designation" : [{
          "language" : "de-CH",
          "value" : "evangelisch-reformierte (protestantische) Kirche"
        },
        {
          "language" : "fr-CH",
          "value" : "Eglise réformée évangélique/Eglise protestante"
        },
        {
          "language" : "it-CH",
          "value" : "Chiesa evangelico-riformata / Chiesa protestante"
        }]
      },
      {
        "code" : "121",
        "display" : "römisch-katholische Kirche",
        "designation" : [{
          "language" : "de-CH",
          "value" : "römisch-katholische Kirche"
        },
        {
          "language" : "fr-CH",
          "value" : "Eglise catholique romaine"
        },
        {
          "language" : "it-CH",
          "value" : "Chiesa cattolica romana"
        }]
      },
      {
        "code" : "122",
        "display" : "christkatholische / altkatholische Kirche",
        "designation" : [{
          "language" : "de-CH",
          "value" : "christkatholische / altkatholische Kirche"
        },
        {
          "language" : "fr-CH",
          "value" : "Eglise catholique-chrétienne/Eglise vieille-catholique"
        },
        {
          "language" : "it-CH",
          "value" : "Chiesa cattolico-cristiana / Chiesa vecchio-cattolica"
        }]
      },
      {
        "code" : "211",
        "display" : "israelitische Gemeinschaft / jüdische Glaubensgemeinschaft",
        "designation" : [{
          "language" : "de-CH",
          "value" : "israelitische Gemeinschaft / jüdische Glaubensgemeinschaft"
        },
        {
          "language" : "fr-CH",
          "value" : "Communauté israélite/Communauté juive"
        },
        {
          "language" : "it-CH",
          "value" : "Comunità israelita / Comunità di confessione ebraica"
        }]
      },
      {
        "code" : "211201",
        "display" : "Israelitische Cultusgemeinde",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Israelitische Cultusgemeinde"
        },
        {
          "language" : "fr-CH",
          "value" : "«Israelitische Cultusgemeinde»"
        },
        {
          "language" : "it-CH",
          "value" : "Comunità di culto israelita"
        }]
      },
      {
        "code" : "211301",
        "display" : "Jüdisch Liberale Gemeinde",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Jüdisch Liberale Gemeinde"
        },
        {
          "language" : "fr-CH",
          "value" : "«Jüdische Liberale Gemeinde»"
        },
        {
          "language" : "it-CH",
          "value" : "Comunità giudaica liberale"
        }]
      },
      {
        "code" : "000",
        "display" : "Unbekannt",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Unbekannt"
        },
        {
          "language" : "fr-CH",
          "value" : "Inconnue"
        },
        {
          "language" : "it-CH",
          "value" : "Sconosciuto"
        }]
      }]
    }]
  }
}

```
