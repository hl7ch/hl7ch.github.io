# EDQM - Pharmaceutical Dose Form - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EDQM - Pharmaceutical Dose Form**

## ValueSet: EDQM - Pharmaceutical Dose Form 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-term/ValueSet/edqm-pharmaceuticaldoseform | *Version*:3.3.0 |
| Active as of 2025-12-15 | *Computable Name*:PharmaceuticalDoseFormEDQM |
| *Other Identifiers:*OID:2.16.756.5.30.1.1.11.3 (use: official, ) | |
| **Copyright/Legal**: CC0-1.0 | |

 
Valueset Pharmaceutical Dose Form from EDQM, PDF, export20.5.2021, see https://standardterms.edqm.eu/# 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/edqm-pharmaceuticaldoseform) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "edqm-pharmaceuticaldoseform",
  "meta" : {
    "lastUpdated" : "2023-01-25T14:36:51Z",
    "source" : "https://art-decor.org/fhir/4.0/ch-pharm-",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
      "valuePeriod" : {
        "start" : "2023-01-25T08:04:29+01:00"
      }
    }
  ],
  "url" : "http://fhir.ch/ig/ch-term/ValueSet/edqm-pharmaceuticaldoseform",
  "identifier" : [
    {
      "use" : "official",
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:2.16.756.5.30.1.1.11.3"
    }
  ],
  "version" : "3.3.0",
  "name" : "PharmaceuticalDoseFormEDQM",
  "title" : "EDQM - Pharmaceutical Dose Form",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-15T10:47:47+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/"
        }
      ]
    },
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "Valueset Pharmaceutical Dose Form from EDQM, PDF, export20.5.2021, see https://standardterms.edqm.eu/#",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "immutable" : false,
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [
      {
        "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
        "concept" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain an oral suspension."
              }
            ],
            "code" : "10100500",
            "display" : "Concentrate for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension à diluer pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for oral use. The preparation is administered in small volumes by means of a suitable measuring device such as a dropper, pipette or oral syringe capable of accurate dosing of the solution. The measured dose may be diluted in water or another suitable liquid before swallowing."
              }
            ],
            "code" : "10101000",
            "display" : "Oral drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tropfen zum Einnehmen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution buvable en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Tropfen zum Einnehmen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for oral use. The preparation is administered in small volumes by means of a suitable measuring device such as a dropper, pipette or oral syringe capable of accurate dosing of the suspension. The measured dose may be diluted in water or another suitable liquid before swallowing."
              }
            ],
            "code" : "10102000",
            "display" : "Oral drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tropfen zum Einnehmen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension buvable en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Tropfen zum Einnehmen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for oral use. The preparation is administered in small volumes by means of a suitable measuring device such as a dropper, pipette or oral syringe capable of accurate dosing of the emulsion. The measured dose may be diluted in water or another suitable liquid before swallowing."
              }
            ],
            "code" : "10103000",
            "display" : "Oral drops, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tropfen zum Einnehmen, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion buvable en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Tropfen zum Einnehmen, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a liquid active substance per se, intended for oral use. Each dose from a multidose container is administered by means of a suitable device such as a measuring spoon."
              }
            ],
            "code" : "10104000",
            "display" : "Oral liquid",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Flüssigkeit zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Liquide oral"
              },
              {
                "language" : "it-CH",
                "value" : "Liquido orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Flüssigkeit zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a solution intended for oral use. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "10105000",
            "display" : "Oral solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution  buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension intended for oral use. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "10106000",
            "display" : "Oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an emulsion intended for oral use. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "10107000",
            "display" : "Oral emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation intended for oral use, consisting of a gel, usually hydrophilic, to be swallowed after administration to the oral cavity."
              }
            ],
            "code" : "10108000",
            "display" : "Oral gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel oral"
              },
              {
                "language" : "it-CH",
                "value" : "Gel orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation intended for oral use, consisting of a paste to be swallowed after administration to the oral cavity."
              }
            ],
            "code" : "10109000",
            "display" : "Oral paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Paste zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte orale"
              },
              {
                "language" : "it-CH",
                "value" : "Pasta per uso orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Paste zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of (a) solid active substance(s) which may also include excipients to facilitate dissolution in the prescribed liquid. Powders for oral solution include freeze-dried powders. The oral solution is usually prepared just before administration to the patient."
              }
            ],
            "code" : "10110000",
            "display" : "Powder for oral solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of (a) solid active substance(s) which may also include excipients to facilitate dispersion in the prescribed liquid and to prevent sedimentation during storage of the oral suspension. Powders for oral suspension include freeze-dried powders. The oral suspension is usually prepared just before administration to the patient."
              }
            ],
            "code" : "10111000",
            "display" : "Powder for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of aggregated particles that may include excipients to facilitate wetting and dissolution, intended to be dissolved in the specified liquid to obtain an oral solution, which is usually prepared just before administration to the patient."
              }
            ],
            "code" : "10112000",
            "display" : "Granules for oral solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Lösung zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour solution buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per soluzione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Lösung zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of aggregated particles that may include excipients to facilitate wetting and dispersion, intended to be dispersed in the specified liquid to obtain an oral suspension, which is usually prepared just before administration to the patient."
              }
            ],
            "code" : "10113000",
            "display" : "Granules for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose aqueous preparation characterised by a sweet taste and a viscous consistency and usually containing aromatic or other flavouring agents, intended for oral use. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "10117000",
            "display" : "Syrup",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Sirup"
              },
              {
                "language" : "fr-CH",
                "value" : "Sirop"
              },
              {
                "language" : "it-CH",
                "value" : "Sciroppo"
              },
              {
                "language" : "rm-CH",
                "value" : "Sirup"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, that may include excipients to facilitate dissolution in water and to obtain the characteristics of a syrup, intended to be dissolved in water to obtain a syrup."
              }
            ],
            "code" : "10118000",
            "display" : "Powder for syrup",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Sirups"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour sirop"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sciroppo"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Sirups"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of aggregated particles that may include excipients to facilitate wetting and dissolution and to obtain the characteristics of a syrup, intended to be dissolved in water to obtain a syrup."
              }
            ],
            "code" : "10119000",
            "display" : "Granules for syrup",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung eines Sirups"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour sirop"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per sciroppo"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung eines Sirups"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet, usually uncoated, intended to be dissolved in the specified liquid before being swallowed."
              }
            ],
            "code" : "10120000",
            "display" : "Soluble tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Lösung zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa solubile"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Lösung zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet intended to be dispersed in the specified liquid before being swallowed."
              }
            ],
            "code" : "10121000",
            "display" : "Dispersible tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé dispersible"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa dispersibile"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of small, dispersible tablets that are designed to be used in a dose dispenser, each tablet usually consisting of a small fraction of a dose, with multiple tablets being automatically counted and administered as a single dose."
              }
            ],
            "code" : "10121500",
            "display" : "Dispersible tablets for dose dispenser",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen für ein Dosiergerät"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimés dispersibles pour dispensateur de dose"
              },
              {
                "language" : "it-CH",
                "value" : "Compresse dispersibili per dispensatore di dose"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Suspension zum Einnehmen für ein Dosiergerät"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting exclusively of one or more herbal drugs intended for the preparation of an oral aqueous preparation by means of decoction, infusion or maceration. Herbal teas are usually presented in bulk form or in bags. The tea is prepared immediately before oral intake."
              }
            ],
            "code" : "10122000",
            "display" : "Herbal tea",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Arzneitee"
              },
              {
                "language" : "fr-CH",
                "value" : "Plante(s) pour tisane"
              },
              {
                "language" : "it-CH",
                "value" : "Tisana"
              },
              {
                "language" : "rm-CH",
                "value" : "Arzneitee"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Single-dose or multidose preparation consisting of one or more particulate solids of varying degrees of fineness. Oral powders are intended for oral administration. They are generally administered in or with water or another suitable liquid, but may also be swallowed directly."
              }
            ],
            "code" : "10201000",
            "display" : "Oral powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre orale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a lyophilised herbal drug extract intended to be dissolved in water before oral use. Instant herbal teas are supplied in bulk form (multidose) or in sachets (single-dose)."
              }
            ],
            "code" : "10202000",
            "display" : "Instant herbal tea",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Teeaufgusspulver"
              },
              {
                "language" : "fr-CH",
                "value" : "Préparation instantanée pour tisane"
              },
              {
                "language" : "it-CH",
                "value" : "Tisana, polvere solubile"
              },
              {
                "language" : "rm-CH",
                "value" : "Teeaufgusspulver"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose or multidose preparation consisting of one or more powders generally containing acid substances and carbonates or hydrogen carbonates that react rapidly in the presence of water to release carbon dioxide. Effervescent powders are intended to be dissolved or dispersed in water before administration."
              }
            ],
            "code" : "10203000",
            "display" : "Effervescent powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Brausepulver"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre effervescente"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere effervescente"
              },
              {
                "language" : "rm-CH",
                "value" : "Brausepulver"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose or multidose preparation consisting of solid, dry aggregates of powder particles that are sufficiently resistant to withstand handling. Granules are intended for oral use to release active substance(s) in the gastrointestinal fluids by a rate depending essentially on the intrinsic properties of the active substance(s) (conventional release). They may be swallowed as such and/or chewed before swallowing, and some may also be dissolved or dispersed in water or another suitable liquid before oral administration. Granules for oral solution and Granules for oral suspension are excluded."
              }
            ],
            "code" : "10204000",
            "display" : "Granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose or multidose preparation consisting of uncoated granules generally containing acidic substances and carbonates or hydrogen carbonates that rapidly react in the presence of water to release carbon dioxide. Effervescent granules are intended to be dissolved or dispersed in water before oral use."
              }
            ],
            "code" : "10205000",
            "display" : "Effervescent granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Brausegranulat"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés effervescents"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato effervescente"
              },
              {
                "language" : "rm-CH",
                "value" : "Brausegranulat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of delayed-release granules intended to resist the gastric fluid and release the active substance(s) in the intestinal fluid. This deliberate modification is achieved by coating the granules with a gastro-resistant material or by embedding the solid particles in the gastro-resistant material. Gastro-resistant granules are usually single-dose preparations intended for oral use."
              }
            ],
            "code" : "10206000",
            "display" : "Gastro-resistant granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "magensaftresistentes Granulat"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés gastrorésistants"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato gastroresistente"
              },
              {
                "language" : "rm-CH",
                "value" : "magensaftresistentes Granulat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of granules showing a slower release than that of conventional-release granules. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Prolonged-release granules are usually single-dose preparations intended for oral use."
              }
            ],
            "code" : "10207000",
            "display" : "Prolonged-release granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Retardgranulat"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Retardgranulat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of granules showing a rate and/or place of release different from that of conventional-release granules. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Modified-release granules are usually single-dose preparations intended for oral use, and include prolonged-release, delayed release and pulsatile-release granules. The generic term 'modified-release granules' is used only when the more specific terms 'gastro-resistant granules' or 'prolonged-release granules' do not apply."
              }
            ],
            "code" : "10208000",
            "display" : "Modified-release granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat mit veränderter Wirkstofffreisetzung"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés à libération modifiée"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato a rilascio modificato"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat mit veränderter Wirkstofffreisetzung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid discoid preparation consisting of a wafer enclosing a unit dose intended for oral use."
              }
            ],
            "code" : "10209000",
            "display" : "Cachet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Oblatenkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Cachet"
              },
              {
                "language" : "it-CH",
                "value" : "Cachet"
              },
              {
                "language" : "rm-CH",
                "value" : "Oblatenkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation contained in a hard shell, the capacity of which can be varied. The shell is made of gelatin or other substances. It consists of two prefabricated cylindrical sections one end of which is rounded and closed, the other being open. The contents of the shell may be a solid or semi-solid preparation, which is filled into one of the sections and closed by slipping the other section over it. Hard capsules are intended for oral use."
              }
            ],
            "code" : "10210000",
            "display" : "Capsule, hard",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hartkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gélule"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rigida"
              },
              {
                "language" : "rm-CH",
                "value" : "Hartkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation contained in a soft shell, the capacity and shape of which can be varied. The shell is made of gelatin or other substances and may contain (a) solid active substance(s). The shell is thicker than that of hard capsules and consists of one part as soft capsules usually are formed, filled and sealed in one operation. The contents of the shell may be a semi-solid or liquid preparation. Soft capsules are intended for oral use."
              }
            ],
            "code" : "10211000",
            "display" : "Capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Weichkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle"
              },
              {
                "language" : "rm-CH",
                "value" : "Weichkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose, delayed-release preparation contained in a hard shell. The preparation is intended to resist the gastric fluid and to release the active substance(s) in the intestinal fluid. Hard gastro-resistant capsules are usually made by filling hard capsules with gastro-resistant granules or solid particles made gastro-resistant by coating or, in certain cases, by providing hard capsules with a gastro-resistant shell. They are intended for oral use."
              }
            ],
            "code" : "10212000",
            "display" : "Gastro-resistant capsule, hard",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "magensaftresistente Hartkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gélule gastrorésistante"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rigida gastroresistente"
              },
              {
                "language" : "rm-CH",
                "value" : "magensaftresistente Hartkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose, delayed-release preparation contained in a soft shell. The preparation is intended to resist the gastric fluid and to release the active substance(s) in the intestinal fluid. Soft gastro-resistant capsules are usually formed, filled and sealed in one operation. They may contain a liquid or semi-solid preparation in the gastro-resistant shell. Soft gastro-resistant capsules are intended for oral use."
              }
            ],
            "code" : "10213000",
            "display" : "Gastro-resistant capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "magensaftresistente Weichkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle gastrorésistante"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle gastroresistente"
              },
              {
                "language" : "rm-CH",
                "value" : "magensaftresistente Weichkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation contained in a soft shell. The soft capsule is intended to be chewed to release its contents into the mouth. The contents of the soft shell may be a semi-solid or liquid preparation intended for local action or systemic delivery after absorption through the oral mucosa or, when swallowed, in the gastrointestinal tract."
              }
            ],
            "code" : "10214000",
            "display" : "Chewable capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Weichkapsel zum Zerbeißen"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle à mâcher"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle masticabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Weichkapsel zum Zerbeißen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a hard shell containing a solid or semi-solid formulation, showing a slower release of the active substance(s) than that of a conventional-release capsule. Prolonged release is achieved by a special formulation design and/or manufacturing method. Hard prolonged-release capsules are intended for oral use."
              }
            ],
            "code" : "10215000",
            "display" : "Prolonged-release capsule, hard",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hartkapsel, retardiert"
              },
              {
                "language" : "fr-CH",
                "value" : "Gélule à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rigida a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Hartkapsel, retardiert"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a soft shell containing a semi-solid or liquid formulation, showing a slower release of the active substance(s) than that of a conventional-release capsule. Prolonged release is achieved by a special formulation design and/or manufacturing method. Soft prolonged-release capsules are intended for oral use."
              }
            ],
            "code" : "10216000",
            "display" : "Prolonged-release capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Weichkapsel, retardiert"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Weichkapsel, retardiert"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a hard shell containing a solid or semi-solid formulation, showing a rate, a place and/or a time of release different from that of a conventional-release capsule. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Hard modified-release capsules are intended for oral use, and include prolonged-release, delayed-release and pulsatile-release preparations. The generic term 'modified-release capsule, hard' is used only when the more specific terms 'gastro-resistant capsule, hard' or 'prolonged-release capsule, hard' do not apply."
              }
            ],
            "code" : "10217000",
            "display" : "Modified-release capsule, hard",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hartkapsel mit veränderter Wirkstofffreisetzung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gélule à libération modifiée"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rigida a rilascio modificato"
              },
              {
                "language" : "rm-CH",
                "value" : "Hartkapsel mit veränderter Wirkstofffreisetzung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a soft shell containing a semi-solid or liquid formulation, showing a rate, a place and/or a time of release different from that of a conventional-release capsule. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Soft modified-release capsules are intended for oral use, and include prolonged-release, delayed-release and pulsatile-release preparations. The generic term 'modified-release capsule, soft' is used only when the more specific terms 'gastro-resistant capsule, soft' or 'prolonged-release capsule, soft' do not apply."
              }
            ],
            "code" : "10218000",
            "display" : "Modified-release capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Weichkapsel mit veränderter Wirkstofffreisetzung"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle à libération modifiée"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle a rilascio modificato"
              },
              {
                "language" : "rm-CH",
                "value" : "Weichkapsel mit veränderter Wirkstofffreisetzung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose uncoated preparation obtained by compressing uniform volumes of particulate solids or by other means such as extrusion or moulding. Tablets include single-layer tablets resulting from a single compression of particles and multi-layer tablets consisting of concentric or parallel layers obtained by successive compressions of particles of different composition. Tablets are intended for oral use to release active substance(s) in the gastrointestinal fluids by a rate depending essentially on the intrinsic properties of active substance(s) (conventional release)."
              }
            ],
            "code" : "10219000",
            "display" : "Tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet coated with one or more layers of mixtures of various substances such as sugars and waxes. To the coating colouring matter, flavouring substances and active substance(s) may be added. The thickness of the coating is greater than that of a film-coated tablet. Coated tablets have a smooth surface. They are intended for oral use. When the coating dissolves or disintegrates the active substance(s) is (are) released into the gastrointestinal fluid at a rate depending essentially on its intrinsic properties (conventional release)."
              }
            ],
            "code" : "10220000",
            "display" : "Coated tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "überzogene Tablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé enrobé"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa rivestita"
              },
              {
                "language" : "rm-CH",
                "value" : "überzogene Tablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet coated with a thin polymeric film that dissolves within a few minutes in the gastrointestinal fluid. Film-coated tablets are intended for oral use to release active substance(s) at a rate which is not significantly delayed compared to that of the uncoated tablet."
              }
            ],
            "code" : "10221000",
            "display" : "Film-coated tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Filmtablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pelliculé"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa rivestita con film"
              },
              {
                "language" : "rm-CH",
                "value" : "Filmtablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of an uncoated tablet generally containing acid substances and carbonates or hydrogen carbonates, which react rapidly in the presence of water to release carbon dioxide. Effervescent tablets are intended to be dissolved or dispersed in water before oral use."
              }
            ],
            "code" : "10222000",
            "display" : "Effervescent tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Brausetablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé effervescent"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa effervescente"
              },
              {
                "language" : "rm-CH",
                "value" : "Brausetablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of an uncoated tablet intended to be placed in the mouth where it disperses rapidly in saliva before being swallowed."
              }
            ],
            "code" : "10223000",
            "display" : "Orodispersible tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Schmelztablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé orodispersible"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa orodispersibile"
              },
              {
                "language" : "rm-CH",
                "value" : "Schmelztablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation made by freeze-drying of a liquid or semi-solid preparation. This fast-releasing preparation is intended to be placed in the mouth where its contents are released in saliva and swallowed or, alternatively, to be dissolved in water before oral administration."
              }
            ],
            "code" : "10224000",
            "display" : "Oral lyophilisate",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lyophilisat zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Lyophilisat oral"
              },
              {
                "language" : "it-CH",
                "value" : "Liofilizzato orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lyophilisat zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose, delayed-release tablet intended to resist the gastric fluid and to release the active substance(s) in the intestinal fluid. These properties are achieved by coating the tablet with a gastro-resistant material or by embedding solid particles in the gastro-resistant material before compression. Gastro-resistant tablets are intended for oral administration."
              }
            ],
            "code" : "10225000",
            "display" : "Gastro-resistant tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "magensaftresistente Tablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé gastrorésistant"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa gastroresistente"
              },
              {
                "language" : "rm-CH",
                "value" : "magensaftresistente Tablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet showing a slower release of the active substance(s) than that of a conventional-release tablet. Prolonged release is achieved by a special formulation design and/or manufacturing method. Prolonged-release tablets are intended for oral use."
              }
            ],
            "code" : "10226000",
            "display" : "Prolonged-release tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Retardtablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Retardtablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet showing a rate, a place and/or a time of release different from that of a conventional-release tablet. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Modified-release tablets are intended for oral use, and include prolonged-release, delayed-release and pulsatile-release preparations. The generic term 'modified-release tablet' is used only when the more specific terms 'gastro-resistant tablet' or 'prolonged-release tablet' do not apply."
              }
            ],
            "code" : "10227000",
            "display" : "Modified-release tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette mit veränderter Wirkstofffreisetzung"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé à libération modifiée"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa a rilascio modificato"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette mit veränderter Wirkstofffreisetzung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of an uncoated tablet intended to be chewed before being swallowed. Chewable tablets are intended for oral administration."
              }
            ],
            "code" : "10228000",
            "display" : "Chewable tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kautablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé à croquer"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa masticabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Kautablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a basis, mainly composed of gums, intended to be chewed but not swallowed. The active substance(s) is (are) released in saliva by chewing. Medicated chewing gum is intended for local treatment of mouth diseases or systemic delivery after absorption through the oral mucosa or from the gastrointestinal tract."
              }
            ],
            "code" : "10229000",
            "display" : "Medicated chewing-gum",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "wirkstoffhaltiges Kaugummi"
              },
              {
                "language" : "fr-CH",
                "value" : "Gomme à mâcher médicamenteuse"
              },
              {
                "language" : "it-CH",
                "value" : "Gomma da masticare medicata"
              },
              {
                "language" : "rm-CH",
                "value" : "wirkstoffhaltiges Kaugummi"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation with a gum-like consistency, intended to be sucked or chewed before being swallowed. Medicated chewing gum is excluded."
              }
            ],
            "code" : "10230000",
            "display" : "Oral gum",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lutschpastille"
              },
              {
                "language" : "fr-CH",
                "value" : "Gomme orale"
              },
              {
                "language" : "it-CH",
                "value" : "Pastiglia gommosa"
              },
              {
                "language" : "rm-CH",
                "value" : "Lutschpastille"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation for homoeopathic use, obtained from sucrose, lactose or other suitable excipients. Pillules may be prepared by impregnation of preformed pillules with a dilution or dilutions of homoeopathic stocks or by progressive addition of these excipients and the addition of a dilution or dilutions of homoeopathic stocks. Pillules are intended for oral or sublingual use."
              }
            ],
            "code" : "10231000",
            "display" : "Pillules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Streukügelchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granules"
              },
              {
                "language" : "it-CH",
                "value" : "Granuli"
              },
              {
                "language" : "rm-CH",
                "value" : "Streukügelchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a single- or multilayer sheet of suitable material(s) intended to be placed in the mouth where it disperses rapidly before being swallowed."
              }
            ],
            "code" : "10236100",
            "display" : "Orodispersible film",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Schmelzfilm"
              },
              {
                "language" : "fr-CH",
                "value" : "Film orodispersible"
              },
              {
                "language" : "it-CH",
                "value" : "Film orodispersibile"
              },
              {
                "language" : "rm-CH",
                "value" : "Schmelzfilm"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended for gargling to obtain a local effect in the oral cavity and the throat. Gargles are not to be swallowed."
              }
            ],
            "code" : "10301000",
            "display" : "Gargle",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gurgellösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour gargarisme"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per gargarismi"
              },
              {
                "language" : "rm-CH",
                "value" : "Gurgellösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended to be diluted in water to obtain a gargle."
              }
            ],
            "code" : "10302000",
            "display" : "Concentrate for gargle",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Gurgellösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour gargarisme"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per gargarismi"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Gurgellösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended to be dissolved in water to obtain a gargle."
              }
            ],
            "code" : "10303000",
            "display" : "Gargle, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Gurgellösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour gargarisme"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per gargarismi"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Gurgellösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a tablet intended to be dissolved in water to obtain a gargle."
              }
            ],
            "code" : "10304000",
            "display" : "Gargle, tablet for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Gurgellösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution pour gargarisme"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per soluzione per gargarismi"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Gurgellösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a solution intended for oromucosal use."
              }
            ],
            "code" : "10305000",
            "display" : "Oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension intended for oromucosal use."
              }
            ],
            "code" : "10306000",
            "display" : "Oromucosal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution, suspension or emulsion intended for oromucosal use. Oromucosal drops are administered by instillation into the oral cavity or onto a specific part of the oral cavity."
              }
            ],
            "code" : "10307000",
            "display" : "Oromucosal drops",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tropfen zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution buccale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Tropfen zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for oromucosal use. It is administered by spraying into the oral cavity or onto a specific part of the oral cavity or the throat. It is presented in a container with a spray pump or in a pressurised container with or without a metering valve. Sublingual sprays are excluded."
              }
            ],
            "code" : "10308100",
            "display" : "Oromucosal spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour pulvérisation buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray per mucosa orale, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for oromucosal use. It is administered by spraying into the oral cavity or onto a specific part of the oral cavity or the throat. It is presented in a container with a spray pump or in a pressurised container with or without a metering valve. Sublingual sprays are excluded."
              }
            ],
            "code" : "10308200",
            "display" : "Oromucosal spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray per mucosa orale, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for oromucosal use. It is administered by spraying into the oral cavity or onto a specific part of the oral cavity or the throat. It is presented in a container with a spray pump or in a pressurised container with or without a metering valve. Sublingual sprays are excluded."
              }
            ],
            "code" : "10308300",
            "display" : "Oromucosal spray, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour pulvérisation buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray per mucosa orale, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung in der Mundhöhle, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for sublingual use. Sublingual sprays are usually presented in pressurised containers with a metering valve."
              }
            ],
            "code" : "10309100",
            "display" : "Sublingual spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Sublingualspray, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour pulvérisation sublinguale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray sublinguale, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Sublingualspray, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for sublingual use. Sublingual sprays are usually presented in pressurised containers with a metering valve."
              }
            ],
            "code" : "10309200",
            "display" : "Sublingual spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Sublingualspray, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation sublinguale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray sublinguale, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Sublingualspray, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for sublingual use. Sublingual sprays are usually presented in pressurised containers with a metering valve."
              }
            ],
            "code" : "10309300",
            "display" : "Sublingual spray, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Sublingualspray, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour pulvérisation sublinguale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray sublinguale, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Sublingualspray, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended for use in contact with the oral mucosa. It is not to be swallowed. Mouthwashes may contain excipients to adjust the pH which as far as possible is neutral."
              }
            ],
            "code" : "10310000",
            "display" : "Mouthwash",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Mundspülung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour bain de bouche"
              },
              {
                "language" : "it-CH",
                "value" : "Collutorio"
              },
              {
                "language" : "rm-CH",
                "value" : "Mundspülung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of an uncoated tablet intended to be dissolved in water to obtain a mouthwash."
              }
            ],
            "code" : "10311000",
            "display" : "Mouthwash, tablet for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Mundspülung"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution pour bain de bouche"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per soluzione per collutorio"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Mundspülung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for gingival use."
              }
            ],
            "code" : "10312000",
            "display" : "Gingival solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung am Zahnfleisch"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution gingivale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung am Zahnfleisch"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a hydrophilic gel intended for oromucosal use. It is applied to the oral cavity or onto a specific part of the oral cavity, to obtain a local effect. Gingival gel is excluded."
              }
            ],
            "code" : "10313000",
            "display" : "Oromucosal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel buccal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a paste of solid particles finely dispersed in a hydrophilic basis intended for oromucosal use. Oromucosal pastes are applied to the oral cavity or onto a specific part of the oral cavity, to obtain a local effect. Gingival paste is excluded."
              }
            ],
            "code" : "10314000",
            "display" : "Oromucosal paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Paste zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Pasta per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Paste zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid multidose preparation consisting of an ointment intended for oromucosal use. It is applied to the oral cavity or onto a specific part of the oral cavity, to obtain a local effect"
              }
            ],
            "code" : "10314005",
            "display" : "Oromucosal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Salbe zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Salbe zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid, usually multidose preparation consisting of an oil-in-water emulsion intended for oromucosal use. Oromucosal creams are applied to the oral cavity or onto a specific part of the oral cavity, other than the gingivae, to obtain a local effect."
              }
            ],
            "code" : "10314010",
            "display" : "Oromucosal cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Creme zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "crème buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Crema per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Creme zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a single- or multilayer sheet of suitable material(s) intended to be applied to the buccal cavity (pouch) to obtain a systemic effect."
              }
            ],
            "code" : "10314011",
            "display" : "Buccal film",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Buccalfilm"
              },
              {
                "language" : "fr-CH",
                "value" : "Film buccogingival"
              },
              {
                "language" : "it-CH",
                "value" : "Film orosolubile"
              },
              {
                "language" : "rm-CH",
                "value" : "Buccalfilm"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a gel intended for gingival use to obtain a local effect."
              }
            ],
            "code" : "10315000",
            "display" : "Gingival gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur Anwendung am Zahnfleisch"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel gingival"
              },
              {
                "language" : "it-CH",
                "value" : "Gel gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur Anwendung am Zahnfleisch"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a paste of solid particles finely dispersed in a hydrophilic basis intended for gingival use to obtain a local effect."
              }
            ],
            "code" : "10316000",
            "display" : "Gingival paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Paste zur Anwendung am Zahnfleisch"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte gingivale"
              },
              {
                "language" : "it-CH",
                "value" : "Pasta gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Paste zur Anwendung am Zahnfleisch"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation contained in a soft shell to be chewed or sucked to obtain a local effect in the oral cavity."
              }
            ],
            "code" : "10317000",
            "display" : "Oromucosal capsule",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kapsel zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Kapsel zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a single- or multilayer sheet of suitable material(s) intended for sublingual use to obtain a systemic effect."
              }
            ],
            "code" : "10317500",
            "display" : "Sublingual film",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Schmelzfilm zur sublingualen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Film sublinguale"
              },
              {
                "language" : "it-CH",
                "value" : "Film sublinguale"
              },
              {
                "language" : "rm-CH",
                "value" : "Schmelzfilm zur sublingualen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of an uncoated tablet intended for sublingual use. Sublingual tablets are usually prepared by compression of mixtures of powders or granulations into tablets with a shape suited for the intended use. Other technologies such as moulding may be used."
              }
            ],
            "code" : "10318000",
            "display" : "Sublingual tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Sublingualtablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé sublingual"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa sublinguale"
              },
              {
                "language" : "rm-CH",
                "value" : "Sublingualtablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation to be applied to the buccal mucosa to obtain a systemic delivery over an extended period of time. Mucoadhesive buccal tablets are usually prepared by compression of mixtures of powders or granulations into tablets with a shape suited for the intended use. They usually contain hydrophilic polymers, which on wetting with saliva produce a flexible hydrogel that adheres to the buccal mucosa."
              }
            ],
            "code" : "10319000",
            "display" : "Muco-adhesive buccal tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "mucoadhäsive Buccaltablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé buccogingival muco-adhésif"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa buccale mucoadesiva"
              },
              {
                "language" : "rm-CH",
                "value" : "mucoadhäsive Buccaltablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation to be applied to the buccal cavity (pouch) to obtain systemic delivery. Buccal tablets are prepared by compression of mixtures of powders or granulations into tablets with a shape suited for the intended use."
              }
            ],
            "code" : "10320000",
            "display" : "Buccal tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Buccaltablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé buccogingival"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa orosolubile"
              },
              {
                "language" : "rm-CH",
                "value" : "Buccaltablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation intended to be sucked to obtain, usually, a local effect in the oral cavity and the throat. Lozenges are hard preparations prepared by moulding. They usually contain flavouring and sweetening agents. Lozenges dissolve or disintegrate slowly when sucked."
              }
            ],
            "code" : "10321000",
            "display" : "Lozenge",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lutschtablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Pastille"
              },
              {
                "language" : "it-CH",
                "value" : "Pastiglia"
              },
              {
                "language" : "rm-CH",
                "value" : "Lutschtablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation intended to be sucked to obtain a local or systemic effect. It is prepared by compression and is often rhomboid in shape. Compressed lozenges usually contain flavouring and sweetening agents. They dissolve or disintegrate slowly when sucked."
              }
            ],
            "code" : "10322000",
            "display" : "Compressed lozenge",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lutschtablette, gepresst"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé à sucer"
              },
              {
                "language" : "it-CH",
                "value" : "Pastiglia"
              },
              {
                "language" : "rm-CH",
                "value" : "Lutschtablette, gepresst"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation intended to be sucked to obtain, usually, a local effect in the oral cavity and the throat. Pastilles are soft, flexible preparations prepared by moulding of mixtures containing natural or synthetic polymers or gums and sweeteners. They dissolve or disintegrate slowly when sucked."
              }
            ],
            "code" : "10323000",
            "display" : "Pastille",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pastille"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte à sucer"
              },
              {
                "language" : "it-CH",
                "value" : "Pastiglia molle"
              },
              {
                "language" : "rm-CH",
                "value" : "Pastille"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended for administration within the tooth socket/periodontal membrane."
              }
            ],
            "code" : "10401000",
            "display" : "Periodontal powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur periodontalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre péridontale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur periodontalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation intended for application in or on teeth, which subsequently hardens to form a seal or bond."
              }
            ],
            "code" : "10401500",
            "display" : "Dental cement",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalzement"
              },
              {
                "language" : "fr-CH",
                "value" : "Ciment dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalzement"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid, usually multidose preparation consisting of a hydrophilic gel intended for administration on teeth and gums by rubbing."
              }
            ],
            "code" : "10402000",
            "display" : "Dental gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalgel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Gel dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalgel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation, rod-shaped and usually prepared by compression or moulding, intended for dental use."
              }
            ],
            "code" : "10403000",
            "display" : "Dental stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalstift"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Bastoncino dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalstift"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended for administration on teeth and gums."
              }
            ],
            "code" : "10405000",
            "display" : "Dental powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalpulver"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalpulver"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for administration on teeth and gums."
              }
            ],
            "code" : "10406000",
            "display" : "Dental solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for administration on teeth and gums."
              }
            ],
            "code" : "10407000",
            "display" : "Dental suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for administration on to the teeth and the gums."
              }
            ],
            "code" : "10408000",
            "display" : "Dental emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalemulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalemulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid, usually multidose preparation consisting of a hydrophilic paste intended to be rubbed onto the teeth."
              }
            ],
            "code" : "10409000",
            "display" : "Toothpaste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Zahnpaste"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte dentifrice"
              },
              {
                "language" : "it-CH",
                "value" : "Pasta dentifricia"
              },
              {
                "language" : "rm-CH",
                "value" : "Zahnpaste"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended to be placed in the pouch between the tooth and the gingiva."
              }
            ],
            "code" : "10410000",
            "display" : "Periodontal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur periodontalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel périodontal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur periodontalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a medicated insert to be placed within the tooth socket/periodontal membrane. The biodegradable insert is a sheet which slowly releases active substance(s)."
              }
            ],
            "code" : "10411000",
            "display" : "Periodontal insert",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Insert zur periodontalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Insert périodontal"
              },
              {
                "language" : "it-CH",
                "value" : "Inserto periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Insert zur periodontalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended for use in the preparation of a dental cement."
              }
            ],
            "code" : "10413000",
            "display" : "Powder for dental cement",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Dentalzements"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour ciment dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Inserto periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Dentalzements"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for use in the preparation of a dental cement."
              }
            ],
            "code" : "10414000",
            "display" : "Solution for dental cement",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Herstellung eines Dentalzements"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour ciment dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Inserto periodontale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Herstellung eines Dentalzements"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, semi-solid or liquid preparation to be added to the bath water."
              }
            ],
            "code" : "10501000",
            "display" : "Bath additive",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Badezusatz"
              },
              {
                "language" : "fr-CH",
                "value" : "Adjuvant de bain"
              },
              {
                "language" : "it-CH",
                "value" : "Additivo per bagno"
              },
              {
                "language" : "rm-CH",
                "value" : "Badezusatz"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation of homogeneous appearance consisting of a lipophilic phase and an aqueous phase, one of which is finely dispersed in the other. Active substance(s) are dissolved or dispersed in the basis, which may be hydrophilic or hydrophobic. Creams are intended for cutaneous use. In certain cases, transdermal delivery may be obtained."
              }
            ],
            "code" : "10502000",
            "display" : "Cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Creme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème"
              },
              {
                "language" : "it-CH",
                "value" : "Crema"
              },
              {
                "language" : "rm-CH",
                "value" : "Creme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a single-phase basis of liquids gelled by a suitable gelling agent, intended for cutaneous use. Active substance(s) are dissolved or dispersed in the basis, which may be hydrophilic or hydrophobic."
              }
            ],
            "code" : "10503000",
            "display" : "Gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel"
              },
              {
                "language" : "it-CH",
                "value" : "Gel"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a single-phase basis in which solids or liquids may be dispersed. Active substance(s) are dissolved or dispersed in the basis, which may be hydrophilic, hydrophobic or water-emulsifying. Ointments are intended for cutaneous use. In certain cases, transdermal delivery may be obtained."
              }
            ],
            "code" : "10504000",
            "display" : "Ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Salbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento"
              },
              {
                "language" : "rm-CH",
                "value" : "Salbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation containing a large proportion of finely divided solids dispersed in the basis, intended for cutaneous use."
              }
            ],
            "code" : "10505000",
            "display" : "Cutaneous paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Paste zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Pasta cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Paste zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Flexible single-dose preparation intended to be applied to the skin to obtain, usually, a local effect. Medicated plasters consist of an adhesive basis containing the active substance and spread as a uniform layer on an appropriate support made of natural or synthetic material. The adhesive layer is covered by a suitable protective liner, which is removed before applying the plaster to the skin. Medicated plasters are presented in a range of sizes or as larger sheets to be cut before use."
              }
            ],
            "code" : "10506000",
            "display" : "Medicated plaster",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "wirkstoffhaltiges Pflaster"
              },
              {
                "language" : "fr-CH",
                "value" : "Emplâtre médicamenteux"
              },
              {
                "language" : "it-CH",
                "value" : "Cerotto medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "wirkstoffhaltiges Pflaster"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation, usually presented in a pressurised container equipped with an applicator suitable for delivery of a foam consisting of large volumes of gas dispersed in a liquid containing active substance(s). Cutaneous foams are intended for cutaneous use."
              }
            ],
            "code" : "10507000",
            "display" : "Cutaneous foam",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Schaum zur  Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Mousse cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Schiuma cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Schaum zur  Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid or, occasionally, semi-solid, usually multidose preparation intended for application to the scalp by rubbing and subsequent washing away with water. Upon rubbing with water, shampoos usually form foam. Shampoos are solutions, suspensions or emulsions containing surface-active agents."
              }
            ],
            "code" : "10508000",
            "display" : "Shampoo",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Shampoo"
              },
              {
                "language" : "fr-CH",
                "value" : "Shampoing"
              },
              {
                "language" : "it-CH",
                "value" : "Shampoo"
              },
              {
                "language" : "rm-CH",
                "value" : "Shampoo"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation, usually multidose, consisting of a solution in a pressurised container with a spray valve or in a container equipped with a spray pump, intended for cutaneous use."
              }
            ],
            "code" : "10509000",
            "display" : "Cutaneous spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung auf der Haut, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung auf der Haut, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension in a pressurised container with a spray valve or in a container equipped with a spray pump, intended for cutaneous use."
              }
            ],
            "code" : "10510000",
            "display" : "Cutaneous spray, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung auf der Haut, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung auf der Haut, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually multidose preparation presented in a pressurised container with a spray valve or in a container equipped with a spray pump. The spray is intended for cutaneous use."
              }
            ],
            "code" : "10511000",
            "display" : "Cutaneous spray, powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver-Spray zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, polvere"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver-Spray zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a liquid active substance per se, intended for cutaneous use."
              }
            ],
            "code" : "10512000",
            "display" : "Cutaneous liquid",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Flüssigkeit zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Liquide cutané"
              },
              {
                "language" : "it-CH",
                "value" : "Liquido cutaneo"
              },
              {
                "language" : "rm-CH",
                "value" : "Flüssigkeit zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution of the active substance in a suitable vehicle intended for cutaneous use."
              }
            ],
            "code" : "10513000",
            "display" : "Cutaneous solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour application cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain a cutaneous solution."
              }
            ],
            "code" : "10514000",
            "display" : "Concentrate for cutaneous solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a cutaneous solution."
              }
            ],
            "code" : "10514500",
            "display" : "Powder for cutaneous solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension of fine particles in a suitable vehicle intended for cutaneous use."
              }
            ],
            "code" : "10515000",
            "display" : "Cutaneous suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour application cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for cutaneous use."
              }
            ],
            "code" : "10516000",
            "display" : "Cutaneous emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually multidose preparation consisting of a powder intended for cutaneous use. Cutaneous spray, powder is excluded."
              }
            ],
            "code" : "10517000",
            "display" : "Cutaneous powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour application cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Flexible single-dose preparation intended to be applied to the unbroken skin to obtain a local effect by penetration of the active substance(s) into the skin."
              }
            ],
            "code" : "10517500",
            "display" : "Cutaneous patch",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kutanes Pflaster"
              },
              {
                "language" : "fr-CH",
                "value" : "Patch cutané"
              },
              {
                "language" : "it-CH",
                "value" : "Cerotto cutaneo"
              },
              {
                "language" : "rm-CH",
                "value" : "Kutanes Pflaster"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended for transdermal delivery by means of iontophoresis."
              }
            ],
            "code" : "10518000",
            "display" : "Solution for iontophoresis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Iontophorese"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour iontophorèse"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per iontoforesi"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Iontophorese"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for iontophoresis."
              }
            ],
            "code" : "10518500",
            "display" : "Powder for solution for iontophoresis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Iontophorese"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour iontophérèse"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per ionoforesi"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Iontophorese"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Flexible single-dose preparation intended to be applied to the unbroken skin to obtain a systemic delivery over an extended period of time. Transdermal patches consist of a backing sheet supporting a reservoir or a matrix containing the active substance(s) and on the top a pressure-sensitive adhesive, which assures the adhesion of the preparation to the skin. The backing sheet is impermeable to the active substance(s) and normally impermeable to water. In reservoir systems the active substance may be dissolved or dispersed in a semi-solid basis or in a solid polymer matrix, which is separated from the skin by a rate-controlling membrane. The pressure-sensitive adhesive may, in this case, be applied to some or all parts of the membrane, or only around the border of the membrane and the backing sheet. Matrix systems contain the active substance in a solid or semi-solid matrix, the properties of which control the diffusion pattern to the skin. The matrix system may also be a solution or dispersion of the active substance in the pressure-sensitive adhesive. The releasing surface of the patch is covered by a protective liner to be removed before applying the patch to the skin."
              }
            ],
            "code" : "10519000",
            "display" : "Transdermal patch",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "transdermales Pflaster"
              },
              {
                "language" : "fr-CH",
                "value" : "Patch transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Cerotto transdermico"
              },
              {
                "language" : "rm-CH",
                "value" : "transdermales Pflaster"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation usually containing pyroxylin in a mixture of ether and ethanol. When applied to the skin, the preparation forms a flexible film on the site of application."
              }
            ],
            "code" : "10520000",
            "display" : "Collodion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "filmbildende Flüssigkeit"
              },
              {
                "language" : "fr-CH",
                "value" : "Collodion"
              },
              {
                "language" : "it-CH",
                "value" : "Collodio"
              },
              {
                "language" : "rm-CH",
                "value" : "filmbildende Flüssigkeit"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation to be applied to the nails to form a lacquer by evaporation of the volatile solvent."
              }
            ],
            "code" : "10521000",
            "display" : "Medicated nail lacquer",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "wirkstoffhaltiger Nagellack"
              },
              {
                "language" : "fr-CH",
                "value" : "Vernis à ongles médicamenteux"
              },
              {
                "language" : "it-CH",
                "value" : "Smalto medicato per unghie"
              },
              {
                "language" : "rm-CH",
                "value" : "wirkstoffhaltiger Nagellack"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a hydrophilic heat-retentive basis in which solid or liquid active substance(s) are dispersed, usually intended to be spread thickly on a suitable dressing and heated before application to the skin."
              }
            ],
            "code" : "10522000",
            "display" : "Poultice",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Umschlagpaste"
              },
              {
                "language" : "fr-CH",
                "value" : "Cataplasme"
              },
              {
                "language" : "it-CH",
                "value" : "Cataplasma"
              },
              {
                "language" : "rm-CH",
                "value" : "Umschlagpaste"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation, usually rod-shaped or conical, intended for application to the skin to obtain a local effect. Cutaneous sticks may consist of the active substance(s) alone or dissolved or dispersed in a suitable basis."
              }
            ],
            "code" : "10523000",
            "display" : "Cutaneous stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Stift zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton pour application cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Matita cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Stift zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a piece or strip of gauze or other suitable fabric impregnated with a liquid or semi-solid preparation intended for cutaneous use."
              }
            ],
            "code" : "10525000",
            "display" : "Impregnated dressing",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "imprägnierter Verband"
              },
              {
                "language" : "fr-CH",
                "value" : "Compresse imprégnée"
              },
              {
                "language" : "it-CH",
                "value" : "Garza impregnata"
              },
              {
                "language" : "rm-CH",
                "value" : "imprägnierter Verband"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a single-phase basis of liquids gelled by a suitable gelling agent. Active substance(s) is (are) dissolved or dispersed in the basis, which may be hydrophilic or hydrophobic. Transdermal gels are intended for transdermal use."
              }
            ],
            "code" : "10546250",
            "display" : "Transdermal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Transdermales Gel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Gel transdermico"
              },
              {
                "language" : "rm-CH",
                "value" : "Transdermales Gel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a solution intended for transdermal use. The term 'Transdermal solution' is used only when more-specific terms such as 'Pour-on solution', 'Solution for iontophoresis', 'Spot-on solution' and 'Transdermal spray, solution' do not apply."
              }
            ],
            "code" : "10546400",
            "display" : "Transdermal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "transdermale Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione transdermica"
              },
              {
                "language" : "rm-CH",
                "value" : "transdermale Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution in a pressurised container with a spray valve or a container equipped with a spray pump, intended for transdermal use."
              }
            ],
            "code" : "10546500",
            "display" : "Transdermal spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "transdermales Spray, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Spray transdermico, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "transdermales Spray, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Assembly of components intended for transdermal delivery driven by external forces (e.g. electric current, chemical reaction,...). Transdermal patch is excluded."
              }
            ],
            "code" : "10547000",
            "display" : "Transdermal system",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "transdermales System"
              },
              {
                "language" : "fr-CH",
                "value" : "système transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Sistema transdermico"
              },
              {
                "language" : "rm-CH",
                "value" : "transdermales System"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution containing an allergen product intended for diagnostic use in a skin-prick test."
              }
            ],
            "code" : "10548000",
            "display" : "Solution for skin-prick test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pricktestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "solution pour prick-test"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per skin-prick test"
              },
              {
                "language" : "rm-CH",
                "value" : "Pricktestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution containing an allergen product intended for diagnostic use in a skin-scratch test."
              }
            ],
            "code" : "10549000",
            "display" : "Solution for skin-scratch test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Scratchtestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "solution pour test intradermique"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per scarificazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Scratchtestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid flexible preparation containing an allergen product intended for provocation testing by application to the skin."
              }
            ],
            "code" : "10550000",
            "display" : "Plaster for provocation test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pflaster für Provokationstest"
              },
              {
                "language" : "fr-CH",
                "value" : "patch pour test épicutané"
              },
              {
                "language" : "it-CH",
                "value" : "Cerotto per test di provocazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pflaster für Provokationstest"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a solution for intraocular irrigation."
              }
            ],
            "code" : "10600500",
            "display" : "Concentrate for solution for intraocular irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur intraokularen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution pour irrigation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per irrigazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur intraokularen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid sterile single-dose or multidose preparation consisting of a cream intended for ocular use. Eye creams may be presented in collapsible tubes fitted with a cannula and having a content of not more than 5 g of the preparation. Eye creams may also be presented in suitably designed single-dose containers. The containers or nozzles of tubes are of a shape that facilitates administration without contamination."
              }
            ],
            "code" : "10601000",
            "display" : "Eye cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augencreme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Crema oftalmica"
              },
              {
                "language" : "rm-CH",
                "value" : "Augencreme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid sterile single-dose or multidose preparation consisting of a gel intended for ocular use. Eye gels may be presented in collapsible tubes fitted with a cannula and having a content of not more than 5 g of the preparation. Eye gels may also be presented in suitably designed single-dose containers. The containers or nozzles of tubes are of a shape that facilitates administration without contamination."
              }
            ],
            "code" : "10602000",
            "display" : "Eye gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augengel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Gel oftalmico"
              },
              {
                "language" : "rm-CH",
                "value" : "Augengel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid sterile single-dose or multidose preparation consisting of an ointment intended for ocular use. Eye ointments may be presented in collapsible tubes fitted with a cannula and having a content of not more than 5 g of the preparation. Eye ointments may also be presented in suitably designed single-dose containers. The containers or nozzles of tubes are of a shape that facilitates administration without contamination."
              }
            ],
            "code" : "10603000",
            "display" : "Eye ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augensalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento oftalmico"
              },
              {
                "language" : "rm-CH",
                "value" : "Augensalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an aqueous or oily solution intended for ocular use. Multidose preparations are presented in containers that allow successive drops to be administered. The containers contain usually at most 10 mL of the preparation."
              }
            ],
            "code" : "10604000",
            "display" : "Eye drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Collyre en solution"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an emulsion intended for ocular use. Multidose preparations are presented in containers that allow successive drops to be administered. The containers contain usually at most 10 mL of the preparation."
              }
            ],
            "code" : "10604500",
            "display" : "Eye drops, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augentropfen, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Collyre en émulsion"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augentropfen, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an aqueous or oily suspension intended for ocular use. Multidose preparations are presented in containers that allow successive drops to be administered. The containers contain usually at most 10 mL of the preparation."
              }
            ],
            "code" : "10605000",
            "display" : "Eye drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augentropfensuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Collyre en suspension"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augentropfensuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a sterile solvent containing no active substances, intended for reconstitution of a usually freeze-dried powder for eye drops."
              }
            ],
            "code" : "10608000",
            "display" : "Eye drops, solvent for reconstitution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung von Augentropfen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour collyre"
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per collirio"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung von Augentropfen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation intended for ocular use. The active substance is released over an extended period of time."
              }
            ],
            "code" : "10609000",
            "display" : "Eye drops, prolonged-release",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augentropfen mit verlängerter Wirkungsdauer"
              },
              {
                "language" : "fr-CH",
                "value" : "Collyre à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Augentropfen mit verlängerter Wirkungsdauer"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an aqueous solution intended for washing or bathing the eye."
              }
            ],
            "code" : "10610000",
            "display" : "Eye lotion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augenbad"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour lavage ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Bagno oculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Augenbad"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a sterile solvent containing no active substances, intended for reconstitution of a usually freeze-dried powder for eye lotion."
              }
            ],
            "code" : "10611000",
            "display" : "Eye lotion, solvent for reconstitution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung eines Augenbades"
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour solution pour lavage ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per bagno oculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung eines Augenbades"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation of suitable size and shape, designed to be inserted in the conjunctival sac to produce a local or ocular effect by the release of active substance(s) over a determined period of time. Ophthalmic inserts generally consist of a reservoir of active substance(s) embedded in a matrix or bounded by a rate-controlling membrane. They are presented individually in sterile containers.."
              }
            ],
            "code" : "10612000",
            "display" : "Ophthalmic insert",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augeninsert"
              },
              {
                "language" : "fr-CH",
                "value" : "Insert ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Inserto oftalmico"
              },
              {
                "language" : "rm-CH",
                "value" : "Augeninsert"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile single-dose preparation consisting of a strip made of a suitable material usually impregnated with active substance(s) intended for use on the eyeball."
              }
            ],
            "code" : "10613000",
            "display" : "Ophthalmic strip",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Teststreifen zur Anwendung am Auge"
              },
              {
                "language" : "fr-CH",
                "value" : "Bandelette ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Striscia oftalmica"
              },
              {
                "language" : "rm-CH",
                "value" : "Teststreifen zur Anwendung am Auge"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a cream intended for application to the external auditory meatus, if necessary by means of a tampon impregnated with the preparation."
              }
            ],
            "code" : "10701000",
            "display" : "Ear cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrencreme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Crema auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrencreme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a gel intended for application to the external auditory meatus, if necessary by means of a tampon impregnated with the preparation."
              }
            ],
            "code" : "10702000",
            "display" : "Ear gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrengel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Gel auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrengel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of an ointment intended for application to the external auditory meatus, if necessary by means of a tampon impregnated with the preparation."
              }
            ],
            "code" : "10703000",
            "display" : "Ear ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrensalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrensalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an aqueous or oily solution intended for application to the external auditory meatus. Multidose containers may be dropper containers or containers provided with a dropper applicator, or the dropper may be supplied separately. Drops are not necessarily administered dropwise, but may also be administered as a small volume."
              }
            ],
            "code" : "10704000",
            "display" : "Ear drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution auriculaire en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an aqueous or oily suspension intended for application to the external auditory meatus. Multidose containers may be dropper containers or containers provided with a dropper applicator, or the dropper may be supplied separately. Drops are not necessarily administered dropwise, but may also be administered as a small volume."
              }
            ],
            "code" : "10705000",
            "display" : "Ear drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrentropfen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension auriculaire en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrentropfen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an emulsion intended for application to the external auditory meatus. Multidose containers may be dropper containers or containers provided with a dropper applicator, or the dropper may be supplied separately. Drops are not necessarily administered dropwise, but may also be administered as a small volume."
              }
            ],
            "code" : "10706000",
            "display" : "Ear drops, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrentropfen, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion auriculaire en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrentropfen, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually multidose preparation consisting of one or more powders consisting of (a) solid active substance(s) intended for application to the external auditory meatus. Ear powders are presented in containers fitted with a suitable applicator or device for insufflation."
              }
            ],
            "code" : "10708000",
            "display" : "Ear powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenpulver"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenpulver"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for application to the external auditory meatus by spraying to obtain a local effect. Ear sprays are presented in containers with a spray pump or in pressurised containers fitted with a spray valve."
              }
            ],
            "code" : "10709000",
            "display" : "Ear spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenspray, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Spray auricolare, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenspray, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for application to the external auditory meatus by spraying to obtain a local effect. Ear sprays are presented in containers with a spray pump or in pressurised containers fitted with a spray valve."
              }
            ],
            "code" : "10710000",
            "display" : "Ear spray, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenspray, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour pulvérisation auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Spray auricolare, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenspray, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for application to the external auditory meatus by spraying to obtain local effect. Ear sprays are presented in containers with a spray pump or in pressurised containers fitted with a spray valve."
              }
            ],
            "code" : "10711000",
            "display" : "Ear spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenspray, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour pulvérisation auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Spray auricolare, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenspray, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting usually of an aqueous solution with a pH within physiological limits. Ear washes are intended to clean the external auditory meatus."
              }
            ],
            "code" : "10712000",
            "display" : "Ear wash, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenspüllösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour lavage auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Lavaggio auricolare, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenspüllösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting usually of an oil-in-water emulsion with a pH within physiological limits. Ear washes are intended to clean the external auditory meatus."
              }
            ],
            "code" : "10713000",
            "display" : "Ear wash, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenspülung, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour lavage auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Lavaggio auricolare, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenspülung, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation intended to be inserted into the external auditory meatus for a limited period of time, consisting of a suitable material impregnated with active substance(s)."
              }
            ],
            "code" : "10714000",
            "display" : "Ear tampon",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrentampon"
              },
              {
                "language" : "fr-CH",
                "value" : "Tampon auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Tampone auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrentampon"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation of usually conical shape intended to be inserted in the external auditory meatus where it melts or dissolves."
              }
            ],
            "code" : "10715000",
            "display" : "Ear stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Ohrenstäbchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton pour usage auriculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Bastoncino auricolare"
              },
              {
                "language" : "rm-CH",
                "value" : "Ohrenstäbchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a cream, usually of oil-in-water type, intended for nasal use, usually to obtain a local effect. Nasal creams are usually presented in tubes fitted with a nasal applicator."
              }
            ],
            "code" : "10801000",
            "display" : "Nasal cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasencreme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Crema nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasencreme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of usually a hydrophilic gel, intended for nasal use, usually to obtain a local effect. Nasal gels are usually presented in tubes fitted with a nasal applicator."
              }
            ],
            "code" : "10802000",
            "display" : "Nasal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasengel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel nasal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasengel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of an ointment, intended for nasal use, usually to obtain a local effect. Nasal ointments are usually presented in tubes fitted with a nasal applicator."
              }
            ],
            "code" : "10803000",
            "display" : "Nasal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasensalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasensalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a solution intended for nasal use by means of a suitable applicator."
              }
            ],
            "code" : "10804000",
            "display" : "Nasal drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce nasali, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension intended for nasal use by means of a suitable applicator."
              }
            ],
            "code" : "10805000",
            "display" : "Nasal drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasentropfen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce nasali, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasentropfen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an emulsion intended for nasal use by means of a suitable applicator."
              }
            ],
            "code" : "10806000",
            "display" : "Nasal drops, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasentropfen, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce nasali, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasentropfen, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually multidose preparation consisting of one or more powders of solid active substance(s) intended for nasal use by insufflation into the nasal cavity."
              }
            ],
            "code" : "10807000",
            "display" : "Nasal powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenpulver"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenpulver"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a solution in a container with or without a metering dose valve or in a container with a spray pump or equivalent device to create a spray, intended for nasal use."
              }
            ],
            "code" : "10808000",
            "display" : "Nasal spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension in a container with or without a metering dose valve or in a container with a spray pump or equivalent device to create a spray, intended for nasal use."
              }
            ],
            "code" : "10809000",
            "display" : "Nasal spray, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour pulvérisation nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of an emulsion in a container with or without a metering dose valve or in a container with a spray pump or equivalent device to create a spray, intended for nasal use."
              }
            ],
            "code" : "10810000",
            "display" : "Nasal spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour pulvérisation nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of usually an aqueous isotonic solution intended for cleansing the nasal cavities."
              }
            ],
            "code" : "10811000",
            "display" : "Nasal wash",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspülung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour lavage nasal"
              },
              {
                "language" : "it-CH",
                "value" : "Lavaggio nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspülung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation, usually rod-shaped or conical, intended for nasal use, usually to obtain a local effect."
              }
            ],
            "code" : "10812000",
            "display" : "Nasal stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenstift"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton pour usage nasal"
              },
              {
                "language" : "it-CH",
                "value" : "Bastoncino nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenstift"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a cream usually presented in a single-dose container provided with a suitable applicator, intended for vaginal use to obtain a local effect."
              }
            ],
            "code" : "10901000",
            "display" : "Vaginal cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalcreme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Crema vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalcreme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel usually presented in a single-dose container provided with a suitable applicator, intended for vaginal use to obtain a local effect."
              }
            ],
            "code" : "10902000",
            "display" : "Vaginal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalgel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel vaginal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalgel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment usually presented in a single-dose container provided with a suitable applicator, intended for vaginal use to obtain a local effect."
              }
            ],
            "code" : "10903000",
            "display" : "Vaginal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalsalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalsalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation, usually presented in a pressurised container provided with an applicator suitable for delivery to the vagina of foam containing large volumes of gas dispersed in a liquid containing active substance(s). Vaginal foams are intended for vaginal use, for example for contraception."
              }
            ],
            "code" : "10904000",
            "display" : "Vaginal foam",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalschaum"
              },
              {
                "language" : "fr-CH",
                "value" : "Mousse vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Schiuma vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalschaum"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for vaginal use by means of a suitable applicator in order to obtain a local effect."
              }
            ],
            "code" : "10905000",
            "display" : "Vaginal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for vaginal use by means of a suitable applicator in order to obtain a local effect."
              }
            ],
            "code" : "10906000",
            "display" : "Vaginal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for vaginal use by means of a suitable applicator in order to obtain a local effect."
              }
            ],
            "code" : "10907000",
            "display" : "Vaginal emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalemulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalemulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually single-dose preparation consisting of a tablet, usually uncoated, intended to be dissolved in the specified liquid to obtain a vaginal solution."
              }
            ],
            "code" : "10908000",
            "display" : "Tablet for vaginal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Vaginallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per soluzione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Vaginallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, single-dose preparation usually prepared by moulding, of various shapes, usually ovoid, with a volume and consistency suitable for insertion into the vagina to obtain a local effect. It contains one or more active substances dispersed or dissolved in a suitable basis that may be soluble or dispersible in water or may melt at body temperature."
              }
            ],
            "code" : "10909000",
            "display" : "Pessary",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginalzäpfchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Ovule"
              },
              {
                "language" : "it-CH",
                "value" : "Ovulo"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginalzäpfchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a hard capsule of a size and shape suited for vaginal use, containing a liquid or semi-solid formulation, intended for a local effect."
              }
            ],
            "code" : "10910000",
            "display" : "Vaginal capsule, hard",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hartkapsel zur vaginalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gélule vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rigida vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Hartkapsel zur vaginalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a soft capsule of a size and shape suited for vaginal use, containing a liquid or semi-solid formulation, intended for a local effect."
              }
            ],
            "code" : "10911000",
            "display" : "Vaginal capsule, soft",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Weichkapsel zur vaginalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule molle vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula molle vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Weichkapsel zur vaginalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet, usually uncoated or film-coated, intended for administration to the vagina to obtain a local effect. Vaginal tablets are usually of larger size and a different shape from tablets intended for oral administration."
              }
            ],
            "code" : "10912000",
            "display" : "Vaginal tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Vaginaltablette"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé vaginal"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Vaginaltablette"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a vaginal tablet usually containing acid substances and carbonates or hydrogen carbonates that react rapidly in the presence of aqueous liquid to release carbon dioxide."
              }
            ],
            "code" : "10913000",
            "display" : "Effervescent vaginal tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Schaumovula"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé vaginal effervescent"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa effervescente vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Schaumovula"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a suitable material impregnated with active substance(s) intended to be inserted in the vagina for a limited period of time."
              }
            ],
            "code" : "10914000",
            "display" : "Medicated vaginal tampon",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Wirkstoffhaltiger Vaginaltampon"
              },
              {
                "language" : "fr-CH",
                "value" : "Tampon vaginal médicamenteux"
              },
              {
                "language" : "it-CH",
                "value" : "Tampone vaginale medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "Wirkstoffhaltiger Vaginaltampon"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Drug delivery system intended to be inserted in the vagina where it releases its contents over an extended period of time. Medicated sponge and medicated vaginal tampon are excluded."
              }
            ],
            "code" : "10915000",
            "display" : "Vaginal delivery system",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "vaginales Wirkstofffreisetzungssystem"
              },
              {
                "language" : "fr-CH",
                "value" : "Système de diffusion vaginal"
              },
              {
                "language" : "it-CH",
                "value" : "Dispositivo vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "vaginales Wirkstofffreisetzungssystem"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a cream usually presented in a single-dose container provided with a suitable applicator, intended for rectal use to obtain a local effect."
              }
            ],
            "code" : "11001000",
            "display" : "Rectal cream",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalcreme"
              },
              {
                "language" : "fr-CH",
                "value" : "Crème rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Crema rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalcreme"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel usually presented in a single-dose container provided with a suitable applicator, intended for rectal use to obtain a local effect."
              }
            ],
            "code" : "11002000",
            "display" : "Rectal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalgel"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel rectal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalgel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment usually presented in a single-dose container provided with a suitable applicator, intended for rectal use to obtain a local effect."
              }
            ],
            "code" : "11003000",
            "display" : "Rectal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalsalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalsalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation, usually presented in a pressurised container provided with an applicator suitable for delivery to the rectum of foam containing large volumes of gas dispersed in a liquid containing the active substance. Rectal foams are intended for a local effect."
              }
            ],
            "code" : "11004000",
            "display" : "Rectal foam",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalschaum"
              },
              {
                "language" : "fr-CH",
                "value" : "Mousse rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Schiuma rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalschaum"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for rectal use or for diagnostic purposes. Rectal solutions are usually presented in containers with a volume in the range of 2.5 mL to 2000 mL. The container is fitted with an applicator or an applicator is provided separately."
              }
            ],
            "code" : "11005000",
            "display" : "Rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for rectal use or for diagnostic purposes. Rectal suspension are usually presented in containers with a volume in the range of 2.5 mL to 2000 mL. The container is fitted with an applicator or an applicator is provided separately."
              }
            ],
            "code" : "11006000",
            "display" : "Rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for rectal use or for diagnostic purposes. Rectal emulsions are usually presented in containers with a volume in the range of 2.5 mL to 2000 mL. The container is fitted with an applicator or an applicator is provided separately."
              }
            ],
            "code" : "11007000",
            "display" : "Rectal emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalemulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalemulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain a rectal solution."
              }
            ],
            "code" : "11008000",
            "display" : "Concentrate for rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution rectale à diluer"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a rectal solution."
              }
            ],
            "code" : "11009000",
            "display" : "Powder for rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a rectal suspension."
              }
            ],
            "code" : "11010000",
            "display" : "Powder for rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually single-dose preparation consisting of a tablet, usually uncoated, intended to be dissolved in the specified liquid to obtain a rectal solution."
              }
            ],
            "code" : "11011000",
            "display" : "Tablet for rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per soluzione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually single-dose preparation consisting of a tablet, usually uncoated, intended to be dispersed in the specified liquid to obtain a rectal suspension."
              }
            ],
            "code" : "11012000",
            "display" : "Tablet for rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour suspension rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per sospensione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation of a shape, size and consistency suitable for rectal use, containing active substance(s) dispersed or dissolved in a suitable basis that may be soluble or dispersible in water or may melt at body temperature."
              }
            ],
            "code" : "11013000",
            "display" : "Suppository",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Zäpfchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Suppositoire"
              },
              {
                "language" : "it-CH",
                "value" : "Supposta"
              },
              {
                "language" : "rm-CH",
                "value" : "Zäpfchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a soft capsule of elongated shape suitable for rectal use, containing a liquid or semi-solid formulation, and which may have a lubricating coating."
              }
            ],
            "code" : "11014000",
            "display" : "Rectal capsule",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektalkapsel"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule  rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektalkapsel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a suitable material impregnated with active substance(s) intended to be inserted in the rectum for a limited period of time usually for a local effect."
              }
            ],
            "code" : "11015000",
            "display" : "Rectal tampon",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Rektaltampon"
              },
              {
                "language" : "fr-CH",
                "value" : "Tampon rectal"
              },
              {
                "language" : "it-CH",
                "value" : "Tampone rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Rektaltampon"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for inhalation use. The solution is converted into an aerosol by a continuously operating nebuliser or a metered-dose nebuliser."
              }
            ],
            "code" : "11101000",
            "display" : "Nebuliser solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for inhalation use. The suspension is converted into an aerosol by a continuously operating nebuliser or a metered-dose nebuliser."
              }
            ],
            "code" : "11102000",
            "display" : "Nebuliser suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a nebuliser suspension."
              }
            ],
            "code" : "11103000",
            "display" : "Powder for nebuliser suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Suspension für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Suspension für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a nebuliser solution."
              }
            ],
            "code" : "11104000",
            "display" : "Powder for nebuliser solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for inhalation to obtain local effect or systemic delivery. The emulsion is converted into an aerosol by a continuously operating nebuliser or a metered-dose nebuliser."
              }
            ],
            "code" : "11105000",
            "display" : "Nebuliser emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for inhalation use. The preparation is presented in a pressurised container usually fitted with a metering dose valve."
              }
            ],
            "code" : "11106000",
            "display" : "Pressurised inhalation, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Druckgasinhalation, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour inhalation en flacon pressurisé"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione pressurizzata per inalazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Druckgasinhalation, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a suspension intended for inhalation use. The preparation is presented in a pressurised container fitted with a metering dose valve."
              }
            ],
            "code" : "11107000",
            "display" : "Pressurised inhalation, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Druckgasinhalation, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour inhalation en flacon pressurisé"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione pressurizzata per inalazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Druckgasinhalation, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of an emulsion intended for inhalation use. The preparation is presented in a pressurised container fitted with a metering dose valve."
              }
            ],
            "code" : "11108000",
            "display" : "Pressurised inhalation, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Druckgasinhalation, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour inhalation en flacon pressurisé"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione pressurizzata per inalazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Druckgasinhalation, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually multidose preparation intended for inhalation use, consisting of one or more powders of solid active substance(s) to be administered by a dry-powder inhaler containing a metering dose mechanism within the inhaler. 'Inhalation powder, hard capsule' and 'Inhalation powder, pre-dispensed' are excluded."
              }
            ],
            "code" : "11109000",
            "display" : "Inhalation powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour inhalation"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per inalazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation intended for inhalation use, consisting of one or more powders of solid active substance(s) enclosed in a hard capsule. The capsule is loaded into a dry-powder inhaler to generate an aerosol."
              }
            ],
            "code" : "11110000",
            "display" : "Inhalation powder, hard capsule",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hartkapsel mit Pulver zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour inhalation en gélule"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per inalazione, capsula rigida"
              },
              {
                "language" : "rm-CH",
                "value" : "Hartkapsel mit Pulver zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation intended for inhalation use, consisting of one or more powders of solid active substance(s) presented in a suitable pharmaceutical form other than a hard capsule, either in the form of a single dose or divided into multiple single doses. The preparation is loaded into a dry-powder inhaler to generate an aerosol."
              }
            ],
            "code" : "11111000",
            "display" : "Inhalation powder, pre-dispensed",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "einzeldosiertes Pulver zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour inhalation en récipient unidose"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per inalazione, pre-dosata"
              },
              {
                "language" : "rm-CH",
                "value" : "einzeldosiertes Pulver zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders of solid active substance(s) intended for generation of vapour to be inhaled to obtain a local effect. The vapour is usually generated by adding the powder to hot water."
              }
            ],
            "code" : "11112000",
            "display" : "Inhalation vapour, powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a capsule formulation intended for generation of vapour to be inhaled to obtain a local effect. The vapour is usually generated by adding the whole capsule or the capsule contents to hot water."
              }
            ],
            "code" : "11113000",
            "display" : "Inhalation vapour, capsule",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kapsel zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Capsule pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Capsula per suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Kapsel zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for generation of vapour to be inhaled to obtain a local effect. The vapour is usually generated by adding the solution to hot water."
              }
            ],
            "code" : "11114000",
            "display" : "Inhalation vapour, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per  suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a tablet intended for generation of vapour to be inhaled to obtain a local effect. The vapour is usually generated by adding the tablet to hot water."
              }
            ],
            "code" : "11115000",
            "display" : "Inhalation vapour, tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per  suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment intended for generation of vapour to be inhaled to obtain a local effect. The vapour may be generated by adding the ointment to hot water."
              }
            ],
            "code" : "11116000",
            "display" : "Inhalation vapour, ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Salbe zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento per suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Salbe zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a liquid active substance per se, such as an essential oil or a volatile anaesthetic, intended for generation of vapour to be inhaled. The vapour may be generated by adding the liquid to hot water or by the use of a vaporising device."
              }
            ],
            "code" : "11117000",
            "display" : "Inhalation vapour, liquid",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Flüssigkeit zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Liquide pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Liquido per  suffumigi"
              },
              {
                "language" : "rm-CH",
                "value" : "Flüssigkeit zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of a solution intended for administration by injection."
              }
            ],
            "code" : "11201000",
            "display" : "Solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of a suspension intended for administration by injection."
              }
            ],
            "code" : "11202000",
            "display" : "Suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an emulsion intended for administration by injection."
              }
            ],
            "code" : "11203000",
            "display" : "Emulsion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Injektion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Emuslione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Injektion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile single-dose preparation consisting of a hydrophilic gel intended for injection into a specific tissue or organ."
              }
            ],
            "code" : "11204000",
            "display" : "Gel for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur Injektion"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Gel iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur Injektion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for injection."
              }
            ],
            "code" : "11205000",
            "display" : "Powder for solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a suspension for injection."
              }
            ],
            "code" : "11206000",
            "display" : "Powder for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a prolonged-release suspension for injection."
              }
            ],
            "code" : "11208400",
            "display" : "Powder for prolonged-release suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Depot-Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension injectable à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione iniettabile a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Depot-Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a suspension intended for administration by injection"
              }
            ],
            "code" : "11208500",
            "display" : "Prolonged-release suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Depot-Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension injectable à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione iniettabile a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Depot-Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a solution for injection."
              }
            ],
            "code" : "11209000",
            "display" : "Concentrate for solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution intended for use in inducing cardiac arrest during heart surgery. Some preparations may require mixing with other preparations prior to administration, for example to adjust the pH."
              }
            ],
            "code" : "11209500",
            "display" : "Solution for cardioplegia",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kardioplege Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution de cardioplégie"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per cardioplegia"
              },
              {
                "language" : "rm-CH",
                "value" : "Kardioplege Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution intended to be introduced, usually in large volumes, usually into the circulating blood stream."
              }
            ],
            "code" : "11210000",
            "display" : "Solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an oil-in-water emulsion intended to be introduced, usually in large volumes, usually into the circulating blood stream."
              }
            ],
            "code" : "11211000",
            "display" : "Emulsion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Infusion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Infusion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a dispersion for infusion."
              }
            ],
            "code" : "11211500",
            "display" : "Powder for dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour dispersion pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified aqueous liquid to obtain a solution for infusion."
              }
            ],
            "code" : "11212000",
            "display" : "Powder for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution intended to be diluted in the specified aqueous liquid to obtain a solution for infusion. It may be added to a solution for infusion during the administration."
              }
            ],
            "code" : "11213000",
            "display" : "Concentrate for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solvent containing no active substances, intended for use in the preparation of a product for parenteral use."
              }
            ],
            "code" : "11216000",
            "display" : "Solvent for parenteral use",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung von Parenteralia"
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour préparation parentérale"
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per uso parenterale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung von Parenteralia"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation of a size and shape suitable for implantation. It may be prepared by moulding or other means other than compression. Each implant is presented in a sterile container that may be provided with an administration device. Implants are intended for release over an extended period of time in order to obtain local or systemic effect. 'Implantation tablet', 'Implantation chain' and 'Implantation matrix' are excluded."
              }
            ],
            "code" : "11301000",
            "display" : "Implant",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Implantat"
              },
              {
                "language" : "fr-CH",
                "value" : "Implant"
              },
              {
                "language" : "it-CH",
                "value" : "Impianto"
              },
              {
                "language" : "rm-CH",
                "value" : "Implantat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation prepared by compression of a solid active substance as such or of a formulation thereof into an implant of a size and shape suitable for implantation, usually subcutaneously. Each implantation tablet is presented in a sterile container. Implantation tablets are intended for release over an extended period of time in order to obtain local or systemic effect."
              }
            ],
            "code" : "11302000",
            "display" : "Implantation tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per impianto"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of small spheres mounted on a non-degradable thread to form a chain that allows withdrawal of the remainder of the chain after a certain period of action. Each implantation chain is presented in a sterile container. The implantation chain is intended for release over an extended period of time in order to obtain local or systemic effect."
              }
            ],
            "code" : "11303000",
            "display" : "Implantation chain",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kette zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Implant en chaîne"
              },
              {
                "language" : "it-CH",
                "value" : "Catenella per impianto"
              },
              {
                "language" : "rm-CH",
                "value" : "Kette zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of a usually pliable, absorbent piece of material (e.g. collagen), usually impregnated with a liquid preparation, intended for implantation in the body. The material may be cut into smaller pieces before implantation, and may be shaped around a tissue (e.g. a bone) or inserted into a medical device that is then implanted. Implantation matrices are intended for release over an extended period of time, usually in order to obtain a local effect. Usually the matrix disappears with time. When the product is packaged as a separate matrix, powder and solvent (or matrix and solution), which are used to prepare the implantation matrix immediately before use, the appropriate combined term should be used."
              }
            ],
            "code" : "11303300",
            "display" : "Implantation matrix",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Matrix zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Matrice pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Catenella per impianto"
              },
              {
                "language" : "rm-CH",
                "value" : "Matrix zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a suspension intended for implantation in the body"
              }
            ],
            "code" : "11303500",
            "display" : "Implantation suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Catenella per impianto"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution containing electrolytes with a concentration close to the electrolytic composition of plasma and glucose in varying concentrations or other suitable osmotic agents, intended for intraperitoneal use as a dialysis solution."
              }
            ],
            "code" : "11401000",
            "display" : "Solution for peritoneal dialysis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Peritonealdialyselösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour dialyse péritonéale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per dialisi peritoneale"
              },
              {
                "language" : "rm-CH",
                "value" : "Peritonealdialyselösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution containing electrolytes with a concentration close to the electrolytic composition of plasma, intended for parenteral use in haemofiltration. Glucose may be included."
              }
            ],
            "code" : "11402000",
            "display" : "Solution for haemofiltration",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hämofiltrationslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour hémofiltration"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per emofiltrazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Hämofiltrationslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution containing electrolytes with a concentration close to the electrolytic composition of plasma, intended for parenteral use in haemodiafiltration. Glucose may be included."
              }
            ],
            "code" : "11403000",
            "display" : "Solution for haemodiafiltration",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hämodiafiltrationslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour hémodiafiltration"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per emofiltrazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Hämodiafiltrationslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution containing electrolytes with a concentration close to the electrolytic composition of plasma, intended for use in haemodialysis. Glucose may be included."
              }
            ],
            "code" : "11404000",
            "display" : "Solution for haemodialysis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hämodialyselösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour hémodialyse"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per emodialisi"
              },
              {
                "language" : "rm-CH",
                "value" : "Hämodialyselösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution of electrolytes intended to be diluted with water of a suitable quality to obtain a solution for haemodialysis. Glucose may be included."
              }
            ],
            "code" : "11405000",
            "display" : "Concentrate for solution for haemodialysis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Hämodialyselösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour hémodialyse"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione concentrata per emodialisi"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Hämodialyselösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile liquid preparation consisting of sterilised water or an aqueous solution intended for irrigation of the urinary bladder."
              }
            ],
            "code" : "11502000",
            "display" : "Bladder irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Blasenspüllösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour irrigation vésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Irrigazione vescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Blasenspüllösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended for intravesical use by means of a suitable applicator. 'Bladder irrigation' is excluded."
              }
            ],
            "code" : "11502500",
            "display" : "Intravesical solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in sterile water to obtain a bladder irrigation."
              }
            ],
            "code" : "11503000",
            "display" : "Powder for bladder irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Blasenspüllösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour irrigation vésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per irrigazione vescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Blasenspüllösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended for urethral use by means of a suitable applicator."
              }
            ],
            "code" : "11504000",
            "display" : "Urethral gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur Anwendung in der Harnröhre"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel urétral"
              },
              {
                "language" : "it-CH",
                "value" : "Gel uretrale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur Anwendung in der Harnröhre"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile single-dose preparation, usually rod-shaped and of a size adapted to the dimensions of the urethra, intended for insertion into the urethra. They may be prepared by compression or moulding."
              }
            ],
            "code" : "11505000",
            "display" : "Urethral stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Stäbchen zur Anwendung in der Harnröhre"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton pour usage urétral"
              },
              {
                "language" : "it-CH",
                "value" : "Bastoncino uretrale"
              },
              {
                "language" : "rm-CH",
                "value" : "Stäbchen zur Anwendung in der Harnröhre"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous solution intended for instillation to the trachea and/or bronchi. Preparations for inhalation use are excluded."
              }
            ],
            "code" : "11601000",
            "display" : "Endotracheopulmonary instillation, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur endotracheopulmonalen Instillation"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour instillation endotrachéobronchique"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per instillazione endotracheobronchiale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur endotracheopulmonalen Instillation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an endotracheopulmonary instillation solution."
              }
            ],
            "code" : "11602000",
            "display" : "Endotracheopulmonary instillation, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur endotracheopulmonalen Instillation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour instillation endotrachéobronchique"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per instillazione endotracheobronchiale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur endotracheopulmonalen Instillation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an aqueous suspension intended for instillation to the trachea and/or bronchi. Preparations for inhalation use are excluded."
              }
            ],
            "code" : "11603000",
            "display" : "Endotracheopulmonary instillation, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur endotracheopulmonalen Instillation"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour instillation endotrachéobronchique"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per instillazione endotracheobronchiale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur endotracheopulmonalen Instillation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended for endocervical use by means of a suitable applicator."
              }
            ],
            "code" : "11701000",
            "display" : "Endocervical gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur endozervikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel endocervical"
              },
              {
                "language" : "it-CH",
                "value" : "Gel endocervicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur endozervikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose delivery system intended for intrauterine use that releases its contents of active substance(s) over an extended period of time."
              }
            ],
            "code" : "11901000",
            "display" : "Intrauterine delivery system",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Intrauterines Wirkstofffreisetzungssystem"
              },
              {
                "language" : "fr-CH",
                "value" : "Système de diffusion intra-utérin"
              },
              {
                "language" : "it-CH",
                "value" : "Sistema a rilascio intrauterino"
              },
              {
                "language" : "rm-CH",
                "value" : "Intrauterines Wirkstofffreisetzungssystem"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation to be applied to dentures to form a lacquer by evaporation of the volatile solvent."
              }
            ],
            "code" : "12101000",
            "display" : "Denture lacquer",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lack für die Gebisskontaktfläche"
              },
              {
                "language" : "fr-CH",
                "value" : "Laque dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Smalto dentale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lack für die Gebisskontaktfläche"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution to be mixed with extracorporeal blood."
              }
            ],
            "code" : "12102000",
            "display" : "Anticoagulant and preservative solution for blood",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Stabilisatorlösung für Blutkonserven"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution anticoagulante et de conservation du sang humain"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione anticoagulante e conservante per il sangue"
              },
              {
                "language" : "rm-CH",
                "value" : "Stabilisatorlösung für Blutkonserven"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use in extracorporeal modification of a blood fraction that is returned to the patient following modification."
              }
            ],
            "code" : "12103000",
            "display" : "Solution for blood fraction modification",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Modifikation einer Blutfraktion"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour la préparation ex vivo de fractions sanguines"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per la modifica di frazione ematica"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Modifikation einer Blutfraktion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile single-dose preparation, usually rod-shaped or conical, consisting of active substance(s) dissolved or dispersed in a suitable basis that may dissolve or melt at body temperature, intended to be inserted into wounds."
              }
            ],
            "code" : "12104000",
            "display" : "Wound stick",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Wundstäbchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Bâton intralésionnel"
              },
              {
                "language" : "it-CH",
                "value" : "Matita emostatica"
              },
              {
                "language" : "rm-CH",
                "value" : "Wundstäbchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A radionuclide produced for the radio-labelling of another substance prior to administration."
              }
            ],
            "code" : "12105000",
            "display" : "Radiopharmaceutical precursor",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Markerzubereitung"
              },
              {
                "language" : "fr-CH",
                "value" : "Précurseur radiopharmaceutique"
              },
              {
                "language" : "it-CH",
                "value" : "Precursore radiofarmaceutico"
              },
              {
                "language" : "rm-CH",
                "value" : "Markerzubereitung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A system incorporating a fixed parent radionuclide from which is produced a daughter radionuclide which is to be removed by elution or by any other method and used in a radiopharmaceutical."
              }
            ],
            "code" : "12106000",
            "display" : "Radionuclide generator",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Radionuklidgenerator"
              },
              {
                "language" : "fr-CH",
                "value" : "Générateur radiopharmaceutique"
              },
              {
                "language" : "it-CH",
                "value" : "Generatore di radionuclidi"
              },
              {
                "language" : "rm-CH",
                "value" : "Radionuklidgenerator"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A preparation to be reconstituted or combined with radionuclides in the final radiopharmaceutical, usually prior to its administration. The word radiopharmaceutical may be omitted if there is no ambiguity on the radiopharmaceutical nature of the product. Combinations with other standard terms are not recommended."
              }
            ],
            "code" : "12107000",
            "display" : "Kit for radiopharmaceutical preparation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kit für ein radioaktives Arzneimittel"
              },
              {
                "language" : "fr-CH",
                "value" : "Trousse pour préparation radiopharmaceutique"
              },
              {
                "language" : "it-CH",
                "value" : "Kit per preparazione radiofarmaceutica"
              },
              {
                "language" : "rm-CH",
                "value" : "Kit für ein radioaktives Arzneimittel"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for administration to the stomach or duodenum by means of a suitable applicator."
              }
            ],
            "code" : "12108000",
            "display" : "Gastroenteral solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur gastrointestinalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution gastroentérale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione gastroenterica"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur gastrointestinalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for administration to the stomach or duodenum by means of a suitable applicator."
              }
            ],
            "code" : "12110000",
            "display" : "Gastroenteral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur gastrointestinalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension gastroentérale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione gastroenterica"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur gastrointestinalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for administration to the stomach or duodenum by means of a suitable applicator."
              }
            ],
            "code" : "12111000",
            "display" : "Gastroenteral emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur gastrointestinalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion gastroentérale"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione gastroenterica"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur gastrointestinalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for intraperitoneal use. 'Solution for peritoneal dialysis' is excluded."
              }
            ],
            "code" : "12111500",
            "display" : "Intraperitoneal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur intraperitonealen Awendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution intrapéritonéale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione intraperitoneale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur intraperitonealen Awendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution of electrolytes typically at a concentration close to the intracellular electrolyte composition, intended for storage, protection and/or perfusion of mammalian body organs that are in particular destined for transplantation."
              }
            ],
            "code" : "12112000",
            "display" : "Solution for organ preservation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Organkonservierungslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour conservation d'organe"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per conservazione di organi"
              },
              {
                "language" : "rm-CH",
                "value" : "Organkonservierungslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a large-volume aqueous solution intended for irrigation of body cavities, wounds and surfaces, for example during surgical procedures. Irrigation solutions are either solutions of active substance(s), electrolytes or osmotically active substances in water for injections, or they consist of water for injections as such."
              }
            ],
            "code" : "12113000",
            "display" : "Irrigation solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spüllösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour irrigation"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per irrigazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spüllösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution intended for irrigation of the stomach."
              }
            ],
            "code" : "12114000",
            "display" : "Stomach irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magenspülflüssigkeit"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour irrigation stomacale"
              },
              {
                "language" : "it-CH",
                "value" : "Liquido per lavanda gastrica"
              },
              {
                "language" : "rm-CH",
                "value" : "Magenspülflüssigkeit"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, more or less viscous, sterile preparation intended for use as tissue glue."
              }
            ],
            "code" : "12115000",
            "display" : "Sealant",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gewebekleber"
              },
              {
                "language" : "fr-CH",
                "value" : "Colle"
              },
              {
                "language" : "it-CH",
                "value" : "Adesivo tissutale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gewebekleber"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of a pliable piece of material impregnated or coated with a sealant or with a powder that forms a sealant after contact with an appropriate fluid (e.g. blood). It may act as a haemostatic agent and/or tissue glue. The matrix may itself form part of the seal, and is usually absorbed by the body over time."
              }
            ],
            "code" : "12115100",
            "display" : "Sealant matrix",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Versiegelungsmatrix"
              },
              {
                "language" : "fr-CH",
                "value" : "Matrice pour colle"
              },
              {
                "language" : "it-CH",
                "value" : "Matrice per adesivo tissutale"
              },
              {
                "language" : "rm-CH",
                "value" : "Versiegelungsmatrix"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be applied directly onto the intended site (e.g. a lesion) to form a haemostatic agent and/or tissue glue after contact with an appropriate fluid (e.g. blood)."
              }
            ],
            "code" : "12115200",
            "display" : "Sealant powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gewebekleber"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour colle"
              },
              {
                "language" : "it-CH",
                "value" : "Adesivo tissutale, polvere"
              },
              {
                "language" : "rm-CH",
                "value" : "Gewebekleber"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a piece of absorbent material impregnated with a liquid preparation."
              }
            ],
            "code" : "12117000",
            "display" : "Impregnated pad",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Imprägnierter Tampon"
              },
              {
                "language" : "fr-CH",
                "value" : "Tampon imprégné"
              },
              {
                "language" : "it-CH",
                "value" : "Tampone medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "Imprägnierter Tampon"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a piece of material (e.g. polyethylene), usually porous, in which a liquid, semi-solid or solid preparation is impregnated. Implants, pads, sponges and tampons are excluded."
              }
            ],
            "code" : "12117500",
            "display" : "Impregnated plug",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Imprägnierter Einsatz"
              },
              {
                "language" : "fr-CH",
                "value" : "Support poreux imprégné"
              },
              {
                "language" : "it-CH",
                "value" : "Supporto medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "Imprägnierter Einsatz"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Cultured, living tissue used for the reconstruction of parts of the body. The tissue may consist of ex vivo expanded cells with an extracellular matrix. Where appropriate, the tissue of origin, such as epidermis, dermis, cartilage or muscle, will need to be stated elsewhere in the product information."
              }
            ],
            "code" : "12118000",
            "display" : "Living tissue equivalent",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "lebendes Gewebeäquivalent"
              },
              {
                "language" : "fr-CH",
                "value" : "Substitut de tissu vivant"
              },
              {
                "language" : "it-CH",
                "value" : "Tessuto vivente da coltura di cellule"
              },
              {
                "language" : "rm-CH",
                "value" : "lebendes Gewebeäquivalent"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a sponge impregnated with active substance(s)"
              }
            ],
            "code" : "12119000",
            "display" : "Medicated sponge",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "wirkstoffhaltiges Schwämmchen"
              },
              {
                "language" : "fr-CH",
                "value" : "Eponge médicamenteuse"
              },
              {
                "language" : "it-CH",
                "value" : "Spugna medicata"
              },
              {
                "language" : "rm-CH",
                "value" : "wirkstoffhaltiges Schwämmchen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended for intestinal use."
              }
            ],
            "code" : "12120000",
            "display" : "Intestinal gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur intestinalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel intestinal"
              },
              {
                "language" : "it-CH",
                "value" : "Gel intestinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur intestinalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a biodegradable or non-degradable thread impregnated with active substance(s)."
              }
            ],
            "code" : "12130000",
            "display" : "Medicated thread",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "wirkstoffhaltiger Faden"
              },
              {
                "language" : "fr-CH",
                "value" : "Fils médicamenteux"
              },
              {
                "language" : "it-CH",
                "value" : "Filo medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "wirkstoffhaltiger Faden"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution containing an allergen intended for provocation testing by the nasal, ocular or bronchial routes."
              }
            ],
            "code" : "12131000",
            "display" : "Solution for provocation test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Provokationstestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "solution pour test de provocation"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per saggio di provocazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Provokationstestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A gas packaged under pressure which is entirely gaseous at - 50 °C."
              }
            ],
            "code" : "12301000",
            "display" : "Medicinal gas, compressed",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur medizinischen Anwendung, druckverdichtet"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz médicinal comprimé"
              },
              {
                "language" : "it-CH",
                "value" : "Gas medicinale compresso"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur medizinischen Anwendung, druckverdichtet"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A gas which liquifies at 1.013 bar at a temperature below -150 °C."
              }
            ],
            "code" : "12302000",
            "display" : "Medicinal gas, cryogenic",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur medizinischen Anwendung, kälteverflüssigt"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz médicinal cryogénique"
              },
              {
                "language" : "it-CH",
                "value" : "Gas medicinale criogenico"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur medizinischen Anwendung, kälteverflüssigt"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "A gas packaged under pressure, which is partially liquid (gas over liquid) at -50 °C."
              }
            ],
            "code" : "12303000",
            "display" : "Medicinal gas, liquefied",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur medizinischen Anwendung, verflüssigt"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz médicinal liquéfié"
              },
              {
                "language" : "it-CH",
                "value" : "Gas medicinale liquefatto"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur medizinischen Anwendung, verflüssigt"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a concentrate for solution for infusion, which in turn is intended to be diluted in the specified liquid to obtain a solution for infusion."
              }
            ],
            "code" : "13001000",
            "display" : "Concentrate for concentrate for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat für ein Konzentrat zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz médicinal liquéfié"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per concentrato per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat für ein Konzentrat zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain a nebuliser solution."
              }
            ],
            "code" : "13002000",
            "display" : "Concentrate for nebuliser solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain an oromucosal solution."
              }
            ],
            "code" : "13003000",
            "display" : "Concentrate for oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a suspension for injection."
              }
            ],
            "code" : "13004000",
            "display" : "Concentrate for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension à diluer injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a dispersion intended for use in the preparation of a concentrate for dispersion for infusion, which in turn is intended to be diluted in the specified liquid to obtain a dispersion for infusion."
              }
            ],
            "code" : "13005000",
            "display" : "Dispersion for concentrate for dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dispersion für ein Konzentrat zur Herstellung einer Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion pour dispersion à diluer pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Dispersione per concentrato per dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Dispersion für ein Konzentrat zur Herstellung einer Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an ear drops suspension."
              }
            ],
            "code" : "13006000",
            "display" : "Ear drops, powder for suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Ohrentropfensuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension auriculaire en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari, polvere per sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Ohrentropfensuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of effervescent granules intended to be dispersed or dissolved in the specified liquid, which is supplied in the same packaging, to obtain an oral suspension. Where the granules are intended to be dispersed in water, the term 'Effervescent granules' is used instead."
              }
            ],
            "code" : "13007000",
            "display" : "Effervescent granules for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Brausegranulat zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés effervescents pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato effervescente per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Brausegranulat zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an emulsion intended for use in the preparation of an emulsion for injection."
              }
            ],
            "code" : "13008000",
            "display" : "Emulsion for emulsion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Herstellung einer Emulsion zur Injektion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour émulsion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione per emulsione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Herstellung einer Emulsion zur Injektion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an endotracheopulmonary instillation suspension."
              }
            ],
            "code" : "13009000",
            "display" : "Endotracheopulmonary instillation, powder for suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zu Herstellung einer Suspension zur endotracheopulmonalen Instillation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension pour instillation endotrachéobronchique"
              },
              {
                "language" : "it-CH",
                "value" : "Instillazione endotracheobronchiale, polvere per sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zu Herstellung einer Suspension zur endotracheopulmonalen Instillation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an eye drops solution."
              }
            ],
            "code" : "13010000",
            "display" : "Eye drops, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung von Augentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution ophtalmique en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio, polvere per soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung von Augentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an eye drops suspension."
              }
            ],
            "code" : "13011000",
            "display" : "Eye drops, powder for suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Augentropfensuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension ophtalmique en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Collirio, polvere per sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Augentropfensuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile preparation consisting of a gas that is intended to be mixed with the specified liquid to obtain a dispersion of the gas in the liquid, which is intended for administration by infusion."
              }
            ],
            "code" : "13012000",
            "display" : "Gas for dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur Herstellung einer Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz pour dispersion pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Gas per dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur Herstellung einer Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile preparation consisting of a gas that is intended to be mixed with the specified liquid to obtain a dispersion of the gas in the liquid, which is intended for administration by injection."
              }
            ],
            "code" : "13013000",
            "display" : "Gas for dispersion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur Herstellung einer Injektionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz pour dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Gas per dispersione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur Herstellung einer Injektionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended for use in the preparation of a gel for cutaneous use."
              }
            ],
            "code" : "13014000",
            "display" : "Gel for gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur Herstellung eines Gels"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel pour gel"
              },
              {
                "language" : "it-CH",
                "value" : "Gel per gel"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur Herstellung eines Gels"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of aggregated particles that may include excipients to facilitate wetting and dispersion, intended to be dispersed in the specified liquid to obtain a rectal suspension, which is usually prepared just before administration to the patient."
              }
            ],
            "code" : "13015000",
            "display" : "Granules for rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour suspension rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per sospensione rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for administration to the laryngopharynx for a local effect, other than by spraying."
              }
            ],
            "code" : "13016000",
            "display" : "Laryngopharyngeal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung im Rachenraum und am Kehlkopf"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution laryngopharyngée"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione laringofaringea"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung im Rachenraum und am Kehlkopf"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for spraying onto the laryngopharynx for a local effect."
              }
            ],
            "code" : "13017000",
            "display" : "Laryngopharyngeal spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung im Rachenraum und am Kehlkopf, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation laryngopharyngée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray laringofaringeo, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung im Rachenraum und am Kehlkopf, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of a usually pliable, absorbent piece of material (e.g. collagen) intended to be used in the preparation of an implantation matrix."
              }
            ],
            "code" : "13018000",
            "display" : "Matrix for implantation matrix",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Matrix für Matrix zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Matrice pour matrice pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Spray laringofaringeo, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Matrix für Matrix zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a nasal drops solution."
              }
            ],
            "code" : "13020000",
            "display" : "Nasal drops, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung von Nasentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce nasali, polvere per soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung von Nasentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended to be mixed with the specified liquid or gel to obtain a gel (for cutaneous use)."
              }
            ],
            "code" : "13021000",
            "display" : "Powder for gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Gels"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour gel"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Gels"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended to be mixed with the specified liquid or gel to obtain a dental gel."
              }
            ],
            "code" : "13022000",
            "display" : "Powder for dental gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Dentalgels"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour gel dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Dentalgels"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a dispersion for injection."
              }
            ],
            "code" : "13023000",
            "display" : "Powder for dispersion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Injektionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per dispersione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Injektionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended to be mixed with the specified liquid or gel to obtain an endocervical gel."
              }
            ],
            "code" : "13024000",
            "display" : "Powder for endocervical gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Gels zur endozervikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour gel endocervical"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel endocervicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Gels zur endozervikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an endosinusial solution."
              }
            ],
            "code" : "13025000",
            "display" : "Powder for endosinusial solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Anwendung in den Nasennebenhöhlen"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution endosinusale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione endosinusale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur Anwendung in den Nasennebenhöhlen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders intended to be mixed with the specified liquid or gel to obtain a gingival gel."
              }
            ],
            "code" : "13026000",
            "display" : "Powder for gingival gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung eines Gels zur Anwendung am Zahnfleisch"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour gel gingival"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung eines Gels zur Anwendung am Zahnfleisch"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be used in the preparation of an implantation matrix, e.g. by dissolving in the specified liquid to prepare the solution used to impregnate the matrix."
              }
            ],
            "code" : "13027000",
            "display" : "Powder for implantation matrix",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für Matrix zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour matrice pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für Matrix zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders intended to be mixed with the specified liquid or paste to obtain an implantation paste."
              }
            ],
            "code" : "13028000",
            "display" : "Powder for implantation paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Paste für ein Implantat"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour pâte pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per gel gengivale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Paste für ein Implantat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an intraocular instillation solution."
              }
            ],
            "code" : "13029000",
            "display" : "Powder for intraocular instillation solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Instillationslösung zur intraokularen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour instillation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per instillazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Instillationslösung zur intraokularen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a sealant."
              }
            ],
            "code" : "13031000",
            "display" : "Powder for sealant",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für einen Gewebekleber"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour colle"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per adesivo tissutale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für einen Gewebekleber"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for skin-prick test."
              }
            ],
            "code" : "13032000",
            "display" : "Powder for solution for skin-prick test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Pricktestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour prick-test"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per skin-prick test"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Pricktestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use in the preparation of a solution for injection."
              }
            ],
            "code" : "13033000",
            "display" : "Solution for solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Herstellung einer Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour solution injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Herstellung einer Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an excipient that contains no active substances itself but is intended to be used in the preparation of a pharmaceutical product, e.g. for diluting/dissolving/dispersing the item(s) containing the active substance(s). The term is intended to cover all such excipients, with the particular specifications (e.g. sterility requirements) depending on the final product and its intended use."
              }
            ],
            "code" : "13035000",
            "display" : "Solvent for...",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung..."
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour..."
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per…"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung..."
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a suspension intended for use in the preparation of an emulsion for injection."
              }
            ],
            "code" : "13036000",
            "display" : "Suspension for emulsion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Herstellung einer Emulsion zur Injektion"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour émulsion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per emulsione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Herstellung einer Emulsion zur Injektion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for use in the preparation of an oral suspension."
              }
            ],
            "code" : "13037000",
            "display" : "Suspension for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a suspension intended for use in the preparation of a suspension for injection."
              }
            ],
            "code" : "13039000",
            "display" : "Suspension for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be mixed with the specified liquid to obtain an emulsion for injection."
              }
            ],
            "code" : "13040000",
            "display" : "Powder for emulsion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Emulsion zur Injektion"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour émulsion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per emulsione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Emulsion zur Injektion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended to be administered to the sinuses to obtain a local effect."
              }
            ],
            "code" : "13041000",
            "display" : "Endosinusial solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung in den Nebenhöhlen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution endosinusale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione endosinusale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung in den Nebenhöhlen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended to be administered onto a lesion."
              }
            ],
            "code" : "13042000",
            "display" : "Epilesional solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zum Auftragen auf die Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution épilésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione epilesionale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zum Auftragen auf die Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid sterile preparation containing large proportions of solids finely dispersed in the basis, intended to be implanted in the body for release of the active substance(s) over an extended period of time, usually to obtain a systemic effect."
              }
            ],
            "code" : "13043000",
            "display" : "Implantation paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Paste für Implantate"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione epilesionale"
              },
              {
                "language" : "rm-CH",
                "value" : "Paste für Implantate"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended to be instilled as drops into an internal part of the eye."
              }
            ],
            "code" : "13044000",
            "display" : "Intraocular instillation solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur intraokularen Instillation"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour instillation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per instillazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur intraokularen Instillation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a small-volume suspension intended for intravesical use by means of a suitable applicator."
              }
            ],
            "code" : "13045000",
            "display" : "Intravesical suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation intended for oral use, consisting of granules coated with one or more layers of mixtures of various substances that are usually applied as a solution or suspension in conditions in which evaporation of the vehicle occurs. When the coating dissolves or disintegrates any active substance is released into the gastrointestinal fluid at a rate depending essentially on its intrinsic properties (conventional release)."
              }
            ],
            "code" : "13046000",
            "display" : "Coated granules",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Überzogenes Granulat"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés enrobés"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato rivestito"
              },
              {
                "language" : "rm-CH",
                "value" : "Überzogenes Granulat"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use in the preparation of a suspension for injection."
              }
            ],
            "code" : "13047000",
            "display" : "Solution for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of granules intended to be dispersed in the specified liquid to obtain a suspension for injection."
              }
            ],
            "code" : "13048000",
            "display" : "Granules for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile liquid preparation consisting of two or more phases of which at least one is dispersed in the liquid phase, intended for administration by injection or infusion. To be used only when emulsion for injection/infusion is not appropriate. Solid suspension preparations are excluded."
              }
            ],
            "code" : "13049000",
            "display" : "Dispersion for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dispersion zur Injektion /Infusion"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion injectable/ pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Dispersione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Dispersion zur Injektion /Infusion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Sterile preparation consisting of a gas that is intended to be mixed with the specified liquid to obtain a dispersion of the gas in the liquid, which is intended for administration by injection or infusion."
              }
            ],
            "code" : "13050000",
            "display" : "Gas for dispersion for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gas zur Herstellung einer Injektions-/Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Gaz pour dispersion injectable/ pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Gas per dispersione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Gas zur Herstellung einer Injektions-/Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution containing an allergen product intended for diagnostic use in a skin-prick test or as an injection (usually intraepidermal)"
              }
            ],
            "code" : "13051000",
            "display" : "Solution for injection/skin-prick test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Injektionslösung/ Pricktestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution injectable/ pour prick-test"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione iniettabile/per skin-prick test"
              },
              {
                "language" : "rm-CH",
                "value" : "Injektionslösung/ Pricktestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for injection/skin-prick test."
              }
            ],
            "code" : "13052000",
            "display" : "Powder for solution for injection/skin-prick test",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Injektionslösung/Pricktestlösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution injectable/ pour prick-test"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione iniettabile/per skin-prick test"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Injektionslösung/Pricktestlösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use in the preparation of a solution for infusion."
              }
            ],
            "code" : "13061000",
            "display" : "Solution for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour solution pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid, usually single-dose preparation consisting of a tablet, usually uncoated, intended to be dissolved in the specified liquid to obtain a cutaneous solution."
              }
            ],
            "code" : "13066000",
            "display" : "Tablet for cutaneous solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette zur Herstellung einer Lösung zur Anwendung auf der Haut"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour solution cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa per soluzione cutanea"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette zur Herstellung einer Lösung zur Anwendung auf der Haut"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for administration by injection"
              }
            ],
            "code" : "13076000",
            "display" : "Prolonged-release solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Depot-Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution injectable à libération prolongée"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione iniettabile a rilascio prolungato"
              },
              {
                "language" : "rm-CH",
                "value" : "Depot-Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for urethral use by means of a suitable applicator."
              }
            ],
            "code" : "13077000",
            "display" : "Urethral emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Anwendung in der Harnröhre"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion urétrale"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione uretrale"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Anwendung in der Harnröhre"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an emulsion intended for use in the preparation of a suspension for injection."
              }
            ],
            "code" : "13091000",
            "display" : "Emulsion for suspension for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Herstellung einer Injektionssuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour suspension injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione per sospensione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Herstellung einer Injektionssuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of a single-phase basis in which solids or liquids may be dispersed. Active substance(s) are dissolved or dispersed in the basis, which may be hydrophilic, hydrophobic or water-emulsifying. Transdermal ointments are intended for transdermal use."
              }
            ],
            "code" : "13102000",
            "display" : "Transdermal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Transdermale Salbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade transdermique"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento transdermico"
              },
              {
                "language" : "rm-CH",
                "value" : "Transdermale Salbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a powder intended for sublingual use."
              }
            ],
            "code" : "13105000",
            "display" : "Sublingual powder",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur sublingualen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre sublinguale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere sublinguale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur sublingualen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of whole, broken or fragmented plants or parts of plants in an unprocessed state (herbal drug), intended for oral use without requiring transformation (e.g. dissolution or dispersion in water)"
              }
            ],
            "code" : "13106000",
            "display" : "Oral herbal material",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pflanzenteile zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "-"
              },
              {
                "language" : "it-CH",
                "value" : "Sostanza di origine vegetale  per uso orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pflanzenteile zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of an aqueous solution of electrolytes typically at a concentration close to the intracellular electrolyte composition, intended for inducing cardiac arrest during heart surgery, and for storage, protection and/or perfusion of mammalian body organs that are in particular destined for transplantation."
              }
            ],
            "code" : "13107000",
            "display" : "Solution for cardioplegia/organ preservation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kardioplege Lösung/Organkonservierungslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour cardioplégie/préservation d'organe"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per cardioplegia/conservazione di organi"
              },
              {
                "language" : "rm-CH",
                "value" : "Kardioplege Lösung/Organkonservierungslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of an uncoated tablet intended either to be chewed before being swallowed, or to be dispersed in the specified liquid before being swallowed."
              }
            ],
            "code" : "50001000",
            "display" : "Chewable/dispersible tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Kautablette/Tablette zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé dispersible / à croquer"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa masticabile/dispersibile"
              },
              {
                "language" : "rm-CH",
                "value" : "Kautablette/Tablette zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain a cutaneous spray emulsion."
              }
            ],
            "code" : "50009000",
            "display" : "Concentrate for cutaneous spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung eines Sprays zur Anwendung auf der Haut, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour émulsion pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per spray cutaneo, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung eines Sprays zur Anwendung auf der Haut, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a dispersion for infusion."
              }
            ],
            "code" : "50009300",
            "display" : "Concentrate for dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion à diluer pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain an emulsion for infusion."
              }
            ],
            "code" : "50009500",
            "display" : "Concentrate for emulsion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Emulsion zur Infusion"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion à diluer pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per emulsione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Emulsion zur Infusion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain an intravesical solution."
              }
            ],
            "code" : "50009750",
            "display" : "Concentrate for intravesical solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain an oral solution."
              }
            ],
            "code" : "50010000",
            "display" : "Concentrate for oral solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung  zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung  zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation intended to be diluted in the specified liquid to obtain an oral/rectal solution."
              }
            ],
            "code" : "50011000",
            "display" : "Concentrate for oral/rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zum Einnehmen /Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution orale/rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione orale/rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Lösung zum Einnehmen /Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a solution for peritoneal dialysis."
              }
            ],
            "code" : "50013250",
            "display" : "Concentrate for solution for peritoneal dialysis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Peritonealdialyselösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution pour dialyse péritonéale"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione per dialisi peritoneale"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Peritonealdialyselösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment intended for cutaneous or nasal use."
              }
            ],
            "code" : "50015200",
            "display" : "Cutaneous/nasal ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Salbe zur Anwendung auf der Haut/Nasensalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade cutanée/ nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento cutaneo/nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Salbe zur Anwendung auf der Haut/Nasensalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for cutaneous use or intended to be diluted in the specified liquid to obtain an oromucosal solution."
              }
            ],
            "code" : "50015450",
            "display" : "Cutaneous solution/concentrate for oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung auf der Haut/Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution cutanée/ solution à diluer buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione cutanea/concentrato per soluzione per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung auf der Haut/Konzentrat zur Herstellung einer Lösung zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation, usually multidose, consisting of an emulsion in a pressurised container with a spray valve or in a container equipped with a spray pump, intended for cutaneous use."
              }
            ],
            "code" : "50015500",
            "display" : "Cutaneous spray, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung auf der Haut, Emulsion"
              },
              {
                "language" : "fr-CH",
                "value" : "Émulsion pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung auf der Haut, Emulsion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Ointment formed at the time of administration from a liquid preparation in a pressurised container with a spray valve or in a container equipped with a spray pump."
              }
            ],
            "code" : "50016000",
            "display" : "Cutaneous spray, ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Spray zur Anwendung auf der Haut, Salbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade pour pulvérisation cutanée"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, unguento"
              },
              {
                "language" : "rm-CH",
                "value" : "Spray zur Anwendung auf der Haut, Salbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid single-dose or multidose preparation consisting of solid particles finely dispersed in a suitable basis, intended for administration on or inside the tooth or on and/or around the nerves supplying the teeth. Toothpaste is excluded."
              }
            ],
            "code" : "50017000",
            "display" : "Dental paste",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dentalpaste"
              },
              {
                "language" : "fr-CH",
                "value" : "Pâte dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Spray cutaneo, unguento"
              },
              {
                "language" : "rm-CH",
                "value" : "Dentalpaste"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of two or more phases of which at least one is dispersed in the liquid phase, intended to be introduced, usually in large volumes, usually into the circulating blood stream. To be used only when emulsion for infusion is not appropriate. Solid suspension preparations are excluded."
              }
            ],
            "code" : "50017500",
            "display" : "Dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use as ear drops or eye drops."
              }
            ],
            "code" : "50018000",
            "display" : "Ear/eye drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augen-/Ohrentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution auriculaire/ophtalmique en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari/collirio, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augen-/Ohrentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a suspension intended for use as ear drops or eye drops."
              }
            ],
            "code" : "50018500",
            "display" : "Ear/eye drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augen-/Ohrentropfen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "-"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari/collirio, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augen-/Ohrentropfen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment intended for auricular or ocular use."
              }
            ],
            "code" : "50019000",
            "display" : "Ear/eye ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augen-/Ohrensalbe"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade auriculaire/ ophtalmique"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento auricolare/oftalmico"
              },
              {
                "language" : "rm-CH",
                "value" : "Augen-/Ohrensalbe"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use as ear drops, eye drops or nasal drops."
              }
            ],
            "code" : "50019500",
            "display" : "Ear/eye/nasal drops, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augen-/Ohren-/Nasentropfen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution auriculaire/ ophtalmique/ nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari/collirio/gocce nasali, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augen-/Ohren-/Nasentropfen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for use as ear drops or nasal drops."
              }
            ],
            "code" : "50020200",
            "display" : "Ear/nasal drops, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Augen-/Nasentropfen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension auriculaire/nasale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce auricolari/nasali, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Augen-/Nasentropfen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of an emulsion intended for administration by injection or infusion."
              }
            ],
            "code" : "50021000",
            "display" : "Emulsion for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Injektion/Infusion"
              },
              {
                "language" : "fr-CH",
                "value" : "Émulsion injectable/pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Emulsione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Injektion/Infusion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for cleaning the sinuses."
              }
            ],
            "code" : "50022000",
            "display" : "Endosinusial wash, suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nebenhöhlenspülung, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension pour lavage endosinusal"
              },
              {
                "language" : "it-CH",
                "value" : "Lavaggio endosinusale, sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nebenhöhlenspülung, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for use as a gargle or a mouthwash."
              }
            ],
            "code" : "50024000",
            "display" : "Gargle/mouthwash",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gurgellösung/Mundspülung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour gargarisme/bain de bouche"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per gargarismi/collutorio"
              },
              {
                "language" : "rm-CH",
                "value" : "Gurgellösung/Mundspülung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for use as a gargle or a nasal wash."
              }
            ],
            "code" : "50024500",
            "display" : "Gargle/nasal wash",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gurgellösung/Nasenspülung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour gargarisme/ nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per gargarismi/lavaggio nasale"
              },
              {
                "language" : "rm-CH",
                "value" : "Gurgellösung/Nasenspülung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of gastro-resistant granules intended to be dispersed in the specified liquid to obtain a gastro-resistant oral suspension."
              }
            ],
            "code" : "50026000",
            "display" : "Gastro-resistant granules for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "magensaftresistentes Granulat zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés gastrorésistants pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato gastroresistente per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "magensaftresistentes Granulat zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of granules intended to be dispersed in the specified liquid to obtain an oral/rectal suspension."
              }
            ],
            "code" : "50029150",
            "display" : "Granules for oral/rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour suspension buvable/rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per sospensione orale/rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of aggregated particles that may include excipients to facilitate wetting and dissolution, intended to be dissolved in the specified liquid to obtain a vaginal solution, which is usually prepared just before administration to the patient."
              }
            ],
            "code" : "50029500",
            "display" : "Granules for vaginal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung einer Vaginallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour solution vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato per soluzione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung einer Vaginallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid multidose preparation intended for inhalation use. The dose of inhalation powder is generated from the tablet by a metering mechanism within the inhaler, for example by scraping off a small amount of powder from the tablet."
              }
            ],
            "code" : "50030000",
            "display" : "Inhalation powder, tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette mit Pulver zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé pour inhalation par poudre"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per inalazione, compressa"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette mit Pulver zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a tablet usually containing acid substances and carbonates or hydrogen carbonates that react rapidly in the presence of aqueous liquid to release carbon dioxide, intended for generation of vapour to be inhaled to obtain a local effect. The vapour may be generated by adding the tablet to hot water."
              }
            ],
            "code" : "50031000",
            "display" : "Inhalation vapour, effervescent tablet",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Brausetablette zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé effervescent pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Vapore  per inalazione, compressa effervescente"
              },
              {
                "language" : "rm-CH",
                "value" : "Brausetablette zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of an emulsion intended for generation of vapour to be inhaled to obtain a local effect. The vapour may be generated by adding the emulsion to hot water."
              }
            ],
            "code" : "50032000",
            "display" : "Inhalation vapour, emulsion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Emulsion zur Herstellung eines Dampfs zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Emulsion pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Vapore per inalazione, emulsione"
              },
              {
                "language" : "rm-CH",
                "value" : "Emulsion zur Herstellung eines Dampfs zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a piece of absorbent material impregnated usually with a liquid or semi-solid preparation, intended for generation of vapour to be inhaled to obtain a local effect."
              }
            ],
            "code" : "50033000",
            "display" : "Inhalation vapour, impregnated pad",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
              },
              {
                "language" : "fr-CH",
                "value" : "Tampon imprégné pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Vapore per inalazione, tampone medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of an impregnated plug that generates a vapour to be inhaled, for example by the patient inhaling through a device containing the plug, thereby drawing air through or over it and vaporising the active ingredient(s) impregnated therein."
              }
            ],
            "code" : "50033100",
            "display" : "Inhalation vapour, impregnated plug",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
              },
              {
                "language" : "fr-CH",
                "value" : "Support poreux imprégné pour inhalation par vapeur"
              },
              {
                "language" : "it-CH",
                "value" : "Vapore per inalazione, supporto medicato"
              },
              {
                "language" : "rm-CH",
                "value" : "Dampf zur Inhalation, imprägnierter Einsatz"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for intravesical use or for administration by injection."
              }
            ],
            "code" : "50033400",
            "display" : "Intravesical solution/solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur intravesikalen Anwendung/Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution intravésicale/solution injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione endovescicale/soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur intravesikalen Anwendung/Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of modified-release granules intended to be dispersed in the specified liquid to obtain a modified-release oral suspension. The generic term 'Modified-release granules for oral suspension' is used only when the more-specific terms 'Gastro-resistant granules for oral suspension' or 'Prolonged-release granules for oral suspension' do not apply."
              }
            ],
            "code" : "50036000",
            "display" : "Modified-release granules for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat mit veränderter Wirkstofffreisetzung zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés à libération modifiée pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato a rilascio modificato per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat mit veränderter Wirkstofffreisetzung zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a mouthwash."
              }
            ],
            "code" : "50036050",
            "display" : "Mouthwash, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Mundspülung, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour bain de bouche"
              },
              {
                "language" : "it-CH",
                "value" : "Collutorio, polvere per soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Mundspülung, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for nasal or oromucosal application. 'Nasal/oromucosal spray, solution' and 'Nasal spray, solution/oromucosal solution' are excluded."
              }
            ],
            "code" : "50036500",
            "display" : "Nasal/oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur nasalen Anwendung/Lösung zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution nasale/buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione nasale/per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur nasalen Anwendung/Lösung zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution in a container with or without a metering dose valve or in a container with a spray pump, intended for nasal or oromucosal use."
              }
            ],
            "code" : "50036700",
            "display" : "Nasal/oromucosal spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray und Spray zur Anwendung in der Mundhöhle, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation nasale/ buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale/per mucosa orale, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray und Spray zur Anwendung in der Mundhöhle, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a nasal spray solution."
              }
            ],
            "code" : "50037100",
            "display" : "Nasal spray, powder for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray, Pulver zur Herstellung einer Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour pulvérisation nasale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale, polvere per soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray, Pulver zur Herstellung einer Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for use as a nasal spray or an oromucosal solution."
              }
            ],
            "code" : "50037400",
            "display" : "Nasal spray, solution/oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nasenspray, Lösung/Lösung zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour pulvérisation nasale/ solution buccale"
              },
              {
                "language" : "it-CH",
                "value" : "Spray nasale, soluzione/soluzione per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Nasenspray, Lösung/Lösung zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of granules intended to be dissolved in the specified liquid to obtain an oral drops solution."
              }
            ],
            "code" : "50037500",
            "display" : "Oral drops, granules for solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Granulat zur Herstellung von Tropfen zum Einnehmen, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés pour solution buvale en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, granulato per soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Granulat zur Herstellung von Tropfen zum Einnehmen, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a liquid active substance per se, intended for oral use. The preparation is administered in small volumes by means of a suitable measuring device such as a dropper, pipette or oral syringe capable of accurate dosing of the liquid. The measured dose may be diluted in water or another suitable liquid before swallowing."
              }
            ],
            "code" : "50037750",
            "display" : "Oral drops, liquid",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tropfen zum Einnehmen, Flüssigkeit"
              },
              {
                "language" : "fr-CH",
                "value" : "Liquide oral en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, liquido"
              },
              {
                "language" : "rm-CH",
                "value" : "Tropfen zum Einnehmen, Flüssigkeit"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for oral or rectal use."
              }
            ],
            "code" : "50037900",
            "display" : "Oral/rectal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zum Einnehmen/Rektallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution buvable/rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione orale/rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zum Einnehmen/Rektallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a suspension intended for oral or rectal use."
              }
            ],
            "code" : "50038000",
            "display" : "Oral/rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zum Einnehmen/Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Suspension buvable/rectale"
              },
              {
                "language" : "it-CH",
                "value" : "Sospensione orale/rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zum Einnehmen/Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for oral use or intended to be diluted in the specified liquid to obtain a nebuliser solution."
              }
            ],
            "code" : "50038500",
            "display" : "Oral solution/concentrate for nebuliser solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zum Einnehmen/ Konzentrat zur Herstellung einer Lösung für einen Vernebler"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution orale/solution à diluer pour inhalation par nébuliseur"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione orale/concentrato per soluzione per nebulizzatore"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zum Einnehmen/ Konzentrat zur Herstellung einer Lösung für einen Vernebler"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Flexible single-dose preparation intended to be applied to the oral cavity to obtain either a systemic or a local effect by delivering the active substance(s) over a certain period of time, after which it is then removed."
              }
            ],
            "code" : "50039000",
            "display" : "Oromucosal patch",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pflaster zur Anwendung in der Mundhöhle"
              },
              {
                "language" : "fr-CH",
                "value" : "Patch buccal"
              },
              {
                "language" : "it-CH",
                "value" : "Cerotto per mucosa orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pflaster zur Anwendung in der Mundhöhle"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for oromucosal or laryngopharyngeal use. 'Oromucosal/laryngopharyngeal solution/spray, solution' is excluded."
              }
            ],
            "code" : "50039500",
            "display" : "Oromucosal/laryngopharyngeal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Anwendung in der Mundhöhle/im Rachenraum und am Kehlkopf"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution buccale/laryngopharyngée"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per mucosa orale/laringofaringea"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Anwendung in der Mundhöhle/im Rachenraum und am Kehlkopf"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution intended for oromucosal or laryngopharyngeal use, presented in a container with an optional spray device to allow administration as a spray."
              }
            ],
            "code" : "50040500",
            "display" : "Oromucosal/laryngopharyngeal solution/spray, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung/Spray zur Anwendung in der Mundhöhle/im Rachenraum oder am Kehlkopf, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution/ solution pour pulvérisation buccale/ laryngopharyngée"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per mucosa orale/laringofaringea  o spray per mucosa orale/laringofaringeo, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung/Spray zur Anwendung in der Mundhöhle/im Rachenraum oder am Kehlkopf, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a concentrate for solution for infusion, which must subsequently be diluted before administration as a solution for infusion."
              }
            ],
            "code" : "50043000",
            "display" : "Powder for concentrate for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution à diluer pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a concentrate for dispersion for infusion, which must subsequently be diluted before administration as a dispersion for infusion."
              }
            ],
            "code" : "50048750",
            "display" : "Powder for concentrate for dispersion for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour dispersion à diluer pour dispersion pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per dispersione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Infusionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain a concentrate for intravesical suspension, which must subsequently be diluted before administration as an intravesical suspension."
              }
            ],
            "code" : "50049100",
            "display" : "Powder for concentrate for intravesical suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Suspension zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension à diluer pour suspension intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per sospensione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Suspension zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a concentrate for solution for haemodialysis, which must subsequently be diluted before use as a solution for haemodialysis."
              }
            ],
            "code" : "50049200",
            "display" : "Powder for concentrate for solution for haemodialysis",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Hämodialyselösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution à diluer pour solution pour hémodialyse"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per soluzione per emodialisi"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Hämodialyselösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a concentrate for solution for injection/infusion, which must subsequently be diluted before administration as a solution for injection/infusion."
              }
            ],
            "code" : "50049250",
            "display" : "Powder for concentrate for solution for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Injektions-/Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution à diluer pour solution injectable/pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per soluzione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver für ein Konzentrat zur Herstellung einer Injektions-/Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a dental solution."
              }
            ],
            "code" : "50049270",
            "display" : "Powder for dental solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Dentallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution dentaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per concentrato per soluzione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Dentallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an epilesional solution."
              }
            ],
            "code" : "50049300",
            "display" : "Powder for epilesional solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zum Auftragen auf die Wunde"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution épilésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione epilesionale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zum Auftragen auf die Wunde"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an implantation suspension."
              }
            ],
            "code" : "50049500",
            "display" : "Powder for implantation suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Suspension zur Implantation"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension pour implantation"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione epilesionale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Suspension zur Implantation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an intravesical solution."
              }
            ],
            "code" : "50050000",
            "display" : "Powder for intravesical solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an intravesical solution/solution for injection."
              }
            ],
            "code" : "50050500",
            "display" : "Powder for intravesical solution/solution for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung / Injektionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution intravésicale/injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione endovescicale/soluzione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intravesikalen Anwendung / Injektionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an intravesical suspension."
              }
            ],
            "code" : "50051000",
            "display" : "Powder for intravesical suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Suspensionen zur intravesikalen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension intravésicale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione endovescicale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Suspensionen zur intravesikalen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain an oral/rectal solution."
              }
            ],
            "code" : "50052000",
            "display" : "Powder for oral/rectal suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension oral/rectal"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per sospensione orale/rettale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Suspension zum Einnehmen/Rektalsuspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for injection/infusion."
              }
            ],
            "code" : "50053500",
            "display" : "Powder for solution for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Injektions-/Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution injectable/pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione iniettabile/per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Injektions-/Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of prolonged-release granules intended to be dispersed in the specified liquid to obtain a prolonged-release oral suspension."
              }
            ],
            "code" : "50056000",
            "display" : "Prolonged-release granules for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Retardgranulat zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Granulés à libération prolongée pour suspension buvable"
              },
              {
                "language" : "it-CH",
                "value" : "Granulato a rilascio prolungato per sospensione orale"
              },
              {
                "language" : "rm-CH",
                "value" : "Retardgranulat zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a solution containing a radionuclide produced for the radio-labelling of another substance prior to administration."
              }
            ],
            "code" : "50056500",
            "display" : "Radiopharmaceutical precursor, solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Markerzubereitung, Lösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution de précurseur radiopharmaceutique"
              },
              {
                "language" : "it-CH",
                "value" : "Precursore di radionuclidi, soluzione"
              },
              {
                "language" : "rm-CH",
                "value" : "Markerzubereitung, Lösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for use as a solution for haemodialysis or a solution for haemofiltration."
              }
            ],
            "code" : "50057000",
            "display" : "Solution for haemodialysis/haemofiltration",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hämodialyselösung/Hämofiltrationslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour hémodialyse/hémofiltration"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per emodialisi/emofiltrazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Hämodialyselösung/Hämofiltrationslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile single-dose or multidose preparation consisting of a solution intended for administration by injection or infusion."
              }
            ],
            "code" : "50060000",
            "display" : "Solution for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Injektions-/Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution injectable/pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione iniettabile o per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Injektions-/Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for the preparation of a sealant."
              }
            ],
            "code" : "50061500",
            "display" : "Solution for sealant",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung für Gewebekleber"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour colle"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per adesivo tissutale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung für Gewebekleber"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid sterile preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a solution for intraocular irrigation."
              }
            ],
            "code" : "50073000",
            "display" : "Powder for solution for intraocular irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intraokularen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution pour irrigation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione per irrigazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Lösung zur intraokularen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended for irrigation of one or more internal structures of the eye, for example during surgical procedures."
              }
            ],
            "code" : "50073500",
            "display" : "Solution for intraocular irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur intraokularen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution pour irrigation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per irrigazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur intraokularen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solvent containing no active substances, intended for use in the preparation of a solution for intraocular irrigation."
              }
            ],
            "code" : "50074000",
            "display" : "Solvent for solution for intraocular irrigation",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung einer Lösung zur intraokularen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour solution pour irrigation intraoculaire"
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per soluzione per irrigazione intraoculare"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung einer Lösung zur intraokularen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solvent containing no active substances, intended for use in the preparation of a solution for infusion."
              }
            ],
            "code" : "50076000",
            "display" : "Solvent for solution for infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösungsmittel zur Herstellung einer Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solvant pour solution pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Solvente per soluzione per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösungsmittel zur Herstellung einer Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of two or more phases of which at least one is dispersed in the liquid phase, intended for administration by injection. To be used only when emulsion for injection is not appropriate. Solid suspension preparations are excluded."
              }
            ],
            "code" : "50077000",
            "display" : "Dispersion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Injektionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Dispersione per preparazione iniettabile"
              },
              {
                "language" : "rm-CH",
                "value" : "Injektionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a solution for injection/infusion."
              }
            ],
            "code" : "50079000",
            "display" : "Concentrate for solution for injection/infusion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Konzentrat zur Herstellung einer Injektions- /Infusionslösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à diluer pour solution injectable/pour perfusion"
              },
              {
                "language" : "it-CH",
                "value" : "Concentrato per soluzione iniettabile/ per infusione"
              },
              {
                "language" : "rm-CH",
                "value" : "Konzentrat zur Herstellung einer Injektions- /Infusionslösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid, usually multidose preparation consisting of a solution intended for inhalation use. The preparation is presented in a non-pressurised container fitted with a metering dose mechanism. 'Nebuliser solution' and 'Pressurised inhalation, solution' are excluded."
              }
            ],
            "code" : "50081000",
            "display" : "Inhalation solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lösung zur Inhalation"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à inhaler"
              },
              {
                "language" : "it-CH",
                "value" : "Soluzione per inalazione"
              },
              {
                "language" : "rm-CH",
                "value" : "Lösung zur Inhalation"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dispersed in the specified liquid to obtain an oral drops suspension."
              }
            ],
            "code" : "50082000",
            "display" : "Oral drops, powder for suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung von Tropfen zum Einnehmen, Suspension"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour suspension oral en gouttes"
              },
              {
                "language" : "it-CH",
                "value" : "Gocce orali, polvere per sospensione"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung von Tropfen zum Einnehmen, Suspension"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of one or more powders, including freeze-dried powders, intended to be dissolved in the specified liquid to obtain a vaginal solution."
              }
            ],
            "code" : "13111000",
            "display" : "Powder for vaginal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pulver zur Herstellung einer Vaginallösung"
              },
              {
                "language" : "fr-CH",
                "value" : "Poudre pour solution vaginale"
              },
              {
                "language" : "it-CH",
                "value" : "Polvere per soluzione vaginale"
              },
              {
                "language" : "rm-CH",
                "value" : "Pulver zur Herstellung einer Vaginallösung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of a gel intended for intrauterine use."
              }
            ],
            "code" : "13113000",
            "display" : "Intrauterine gel",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gel zur intrauterinen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Gel intra-utérin"
              },
              {
                "language" : "it-CH",
                "value" : "Gel intrauterino"
              },
              {
                "language" : "rm-CH",
                "value" : "Gel zur intrauterinen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Whole, live, medicinal leech, usually of the Hirudo genus (e.g. Hirudo medicinalis, Hirudo verbana), usually intended to be applied to the skin in order to restore or improve local blood flow or to provide other local effects. After attaching itself to the host, the leech creates an incision in the skin and secretes saliva containing a variety of active substances (e.g. anaesthetics, anticoagulants, anti-inflammatories, vasodilators) that allow it to feed on the blood of the host."
              }
            ],
            "code" : "13115000",
            "display" : "Medicinal leech",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Blutegel zur medizinischen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Sangsue médicinale"
              },
              {
                "language" : "it-CH",
                "value" : "Sanguisuga medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Blutegel zur medizinischen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a tablet intended for oral use, in which one or more ingestible sensors are embedded. The sensor is usually not digested, and is usually intended for use with external diagnostic equipment to which it can transmit data such as physiological and behavioural measurements."
              }
            ],
            "code" : "13118000",
            "display" : "Tablet with sensor",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tablette mit Sensor"
              },
              {
                "language" : "fr-CH",
                "value" : "Comprimé avec capteur"
              },
              {
                "language" : "it-CH",
                "value" : "Compressa con sensore"
              },
              {
                "language" : "rm-CH",
                "value" : "Tablette mit Sensor"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Semi-solid preparation consisting of an ointment intended for urethral use by means of a suitable applicator."
              }
            ],
            "code" : "13123000",
            "display" : "Urethral ointment",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Salbe zur Anwendung in der Harnröhre"
              },
              {
                "language" : "fr-CH",
                "value" : "Pommade urétrale"
              },
              {
                "language" : "it-CH",
                "value" : "Unguento uretrale"
              },
              {
                "language" : "rm-CH",
                "value" : "Salbe zur Anwendung in der Harnröhre"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Whole, live, medicinal larvae, usually of a species of fly such as Lucilla sericata (common greenbottle fly), provided in an appropriate container such as a mesh bag, intended to be applied to a wound and covered with an appropriate dressing in order to allow debridement of necrotic tissue over a specified period of time (usually a few days). The larvae secrete enzymes into the wound, liquefying the necrotic tissue, and ingest the resulting material."
              }
            ],
            "code" : "13124000",
            "display" : "Medicinal larvae",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Larven zur medizinischen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Larves médicinales"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Larven zur medizinischen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of two or more phases of which at least one is dispersed in the liquid phase, intended for administration by injection"
              }
            ],
            "code" : "13126000",
            "display" : "Prolonged-release dispersion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Depot-Injektionsdispersion"
              },
              {
                "language" : "fr-CH",
                "value" : "Larves médicinales"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Depot-Injektionsdispersion"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation made by freeze-drying of a liquid or semi-solid preparation, intended for sublingual use."
              }
            ],
            "code" : "13127000",
            "display" : "Sublingual lyophilisate",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Larves médicinales"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation consisting of a solution intended to be administered onto a wound, including surgical wounds"
              }
            ],
            "code" : "13128000",
            "display" : "Prolonged-release wound solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid preparation consisting of a dispersion intended for inhalation use. The dispersion is converted into an aerosol by a continuously operating nebuliser or a metered-dose nebuliser."
              }
            ],
            "code" : "13129000",
            "display" : "Nebuliser dispersion",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Lyophilisat zur sublingualen Anwendung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose, delayed-release preparation consisting of a suspension intended for oral use. The preparation is intended to resist the gastric fluid and release the active substance(s) in the intestinal fluid. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "13133000",
            "display" : "Gastro-resistant oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magensaftresistente Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Magensaftresistente Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension intended for oral use, showing a slower release of the active substance(s) than that of a conventional-release oral suspension. This deliberate modification is achieved by a special formulation design and/or manufacturing method. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "13134000",
            "display" : "Prolonged-release oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Retardsuspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Retardsuspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid single-dose or multidose preparation consisting of a suspension intended for oral use, showing a rate, a place and/or a time of release of the active substance(s) that is different from that of a conventional-release oral suspension. This deliberate modification is achieved by a special formulation design and/or manufacturing method. The generic term 'Modified-release oral suspension' is used only when the more-specific terms 'Gastro-resistant oral suspension' or 'Prolonged-release oral suspension' do not apply. Each dose from a multidose container is administered by means of a device suitable for measuring the prescribed volume, generally 5 mL or multiples thereof."
              }
            ],
            "code" : "13135000",
            "display" : "Modified-release oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Suspension zum Einnehmen mit veränderter Wirkstofffreisetzung"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Suspension zum Einnehmen mit veränderter Wirkstofffreisetzung"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid preparation consisting of a gastro-resistant powder intended to be dispersed in the specified liquid to obtain a gastro-resistant oral suspension."
              }
            ],
            "code" : "13136000",
            "display" : "Gastro-resistant powder for oral suspension",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Solution à libération prolongée intralésionnelle"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Liquid sterile preparation intended to be diluted in the specified liquid to obtain a dispersion for injection."
              }
            ],
            "code" : "13139000",
            "display" : "Concentrate for dispersion for injection",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion à diluer pour dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Non-sterile, liquid preparation consisting of a solution intended for cutaneous or oromucosal use"
              }
            ],
            "code" : "13140000",
            "display" : "Cutaneous/oromucosal solution",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion à diluer pour dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/valueset-concept-comments",
                "valueString" : "Solid single-dose preparation consisting of a small bag made of a suitable material containing a preparation such as a powder"
              }
            ],
            "code" : "13141000",
            "display" : "Oromucosal pouch",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              },
              {
                "language" : "fr-CH",
                "value" : "Dispersion à diluer pour dispersion injectable"
              },
              {
                "language" : "it-CH",
                "value" : "Larva medicinale"
              },
              {
                "language" : "rm-CH",
                "value" : "Magensaftresistentes Pulver zur Herstellung einer Suspension zum Einnehmen"
              }
            ]
          }
        ]
      }
    ]
  }
}

```
