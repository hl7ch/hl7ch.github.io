# ch-ehealth-codesystem-nareg - CH Term (R4) v3.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ch-ehealth-codesystem-nareg**

## CodeSystem: ch-ehealth-codesystem-nareg 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:2.16.756.5.30.1.127.3.6 | *Version*:3.4.0 |
| Active as of 2026-06-10 | *Computable Name*:ChEhealthCodesystemNareg |
| **Copyright/Legal**: CC0-1.0 | |

 
Speciality of the author as per Annex 3. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [DocumentEntryAuthorSpeciality](ValueSet-DocumentEntry.authorSpeciality.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "2.16.756.5.30.1.127.3.6",
  "meta" : {
    "source" : "https://art-decor.org/fhir/ValueSet/2.16.756.5.30.1.127.3.10.1.1.4--20220624110129"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2022-06-24T11:01:29+02:00"
    }
  }],
  "url" : "urn:oid:2.16.756.5.30.1.127.3.6",
  "version" : "3.4.0",
  "name" : "ChEhealthCodesystemNareg",
  "title" : "ch-ehealth-codesystem-nareg",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-10T10:00:23+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "Speciality of the author as per Annex 3.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "5001",
    "display" : "Optics",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Augenoptik"
    },
    {
      "language" : "rm-CH",
      "value" : "Optica"
    },
    {
      "language" : "fr-CH",
      "value" : "Optique"
    },
    {
      "language" : "it-CH",
      "value" : "Ottica"
    },
    {
      "language" : "en-US",
      "value" : "Optics"
    }]
  },
  {
    "code" : "5002",
    "display" : "Activation",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Aktivierung"
    },
    {
      "language" : "rm-CH",
      "value" : "Activaziun"
    },
    {
      "language" : "fr-CH",
      "value" : "Activation"
    },
    {
      "language" : "it-CH",
      "value" : "Attivazione"
    },
    {
      "language" : "en-US",
      "value" : "Activation"
    }]
  },
  {
    "code" : "5003",
    "display" : "Biomedical analysis",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Biomedizinische Analytik"
    },
    {
      "language" : "rm-CH",
      "value" : "Analitica biomedicinala"
    },
    {
      "language" : "fr-CH",
      "value" : "Analyses biomédicales"
    },
    {
      "language" : "it-CH",
      "value" : "Analisi biomediche"
    },
    {
      "language" : "en-US",
      "value" : "Biomedical analysis"
    }]
  },
  {
    "code" : "5004",
    "display" : "Dental hygiene",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Dentalhygiene"
    },
    {
      "language" : "rm-CH",
      "value" : "Igienica dentala"
    },
    {
      "language" : "fr-CH",
      "value" : "Hygiène dentaire"
    },
    {
      "language" : "it-CH",
      "value" : "Igiene dentale"
    },
    {
      "language" : "en-US",
      "value" : "Dental hygiene"
    }]
  },
  {
    "code" : "5005",
    "display" : "Pharmaceutical",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Drogist/Drogistin"
    },
    {
      "language" : "rm-CH",
      "value" : "Droghista/droghist"
    },
    {
      "language" : "fr-CH",
      "value" : "Droguiste"
    },
    {
      "language" : "it-CH",
      "value" : "Droghiere/Droghiera"
    },
    {
      "language" : "en-US",
      "value" : "Pharmaceutical"
    }]
  },
  {
    "code" : "5006",
    "display" : "Occupational Therapy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ergotherapie"
    },
    {
      "language" : "rm-CH",
      "value" : "Ergoterapia"
    },
    {
      "language" : "fr-CH",
      "value" : "Ergothérapie"
    },
    {
      "language" : "it-CH",
      "value" : "Ergoterapia"
    },
    {
      "language" : "en-US",
      "value" : "Occupational therapy"
    }]
  },
  {
    "code" : "5007",
    "display" : "Nutrition and Dietetics",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ernährungsberatung"
    },
    {
      "language" : "rm-CH",
      "value" : "Cussegliaziun da nutriment"
    },
    {
      "language" : "fr-CH",
      "value" : "Diététique"
    },
    {
      "language" : "it-CH",
      "value" : "Consulenza alimentare"
    },
    {
      "language" : "en-US",
      "value" : "Nutrition and dietetics"
    }]
  },
  {
    "code" : "5008",
    "display" : "Radiologic Technology",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Medizinisch-technische Radiologie"
    },
    {
      "language" : "rm-CH",
      "value" : "Tecnica da radiologia (medicinala)"
    },
    {
      "language" : "fr-CH",
      "value" : "Technique en radiologie médicale"
    },
    {
      "language" : "it-CH",
      "value" : "Tecniche di radiologia medica"
    },
    {
      "language" : "en-US",
      "value" : "Radiologic technology"
    }]
  },
  {
    "code" : "5009",
    "display" : "Surgical Technology",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Operationstechnik"
    },
    {
      "language" : "rm-CH",
      "value" : "Tecnica d'operaziun"
    },
    {
      "language" : "fr-CH",
      "value" : "Technique opératoire"
    },
    {
      "language" : "it-CH",
      "value" : "Tecnica operatoria"
    },
    {
      "language" : "en-US",
      "value" : "Surgical technology"
    }]
  },
  {
    "code" : "5010",
    "display" : "Midwifery",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Geburtshilfe"
    },
    {
      "language" : "rm-CH",
      "value" : "Assistenza al part – spendrera"
    },
    {
      "language" : "fr-CH",
      "value" : "Obstétrique"
    },
    {
      "language" : "it-CH",
      "value" : "Ostetricia"
    },
    {
      "language" : "en-US",
      "value" : "Midwifery"
    }]
  },
  {
    "code" : "5011",
    "display" : "Speech and Language Therapy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Logopädie"
    },
    {
      "language" : "rm-CH",
      "value" : "Logopedia"
    },
    {
      "language" : "fr-CH",
      "value" : "Logopédie"
    },
    {
      "language" : "it-CH",
      "value" : "Logopedia"
    },
    {
      "language" : "en-US",
      "value" : "Speech and language therapy"
    }]
  },
  {
    "code" : "5012",
    "display" : "Massage Therapy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Medizinische Massage"
    },
    {
      "language" : "rm-CH",
      "value" : "Massascha medicinala"
    },
    {
      "language" : "fr-CH",
      "value" : "Massage médical"
    },
    {
      "language" : "it-CH",
      "value" : "Massaggio medico"
    },
    {
      "language" : "en-US",
      "value" : "Massage Therapy"
    }]
  },
  {
    "code" : "5013",
    "display" : "Orthoptics",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Orthoptik"
    },
    {
      "language" : "rm-CH",
      "value" : "Ortoptica"
    },
    {
      "language" : "fr-CH",
      "value" : "Orthoptique"
    },
    {
      "language" : "it-CH",
      "value" : "Ortottica"
    },
    {
      "language" : "en-US",
      "value" : "Orthoptics"
    }]
  },
  {
    "code" : "5014",
    "display" : "Osteopathy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Osteopathie"
    },
    {
      "language" : "rm-CH",
      "value" : "Osteopatia"
    },
    {
      "language" : "fr-CH",
      "value" : "Ostéopathie"
    },
    {
      "language" : "it-CH",
      "value" : "Osteopatia"
    },
    {
      "language" : "en-US",
      "value" : "Osteopathy"
    }]
  },
  {
    "code" : "5015",
    "display" : "Nursing",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Pflege"
    },
    {
      "language" : "rm-CH",
      "value" : "Tgira"
    },
    {
      "language" : "fr-CH",
      "value" : "Soins infirmiers"
    },
    {
      "language" : "it-CH",
      "value" : "Cure infermieristiche"
    },
    {
      "language" : "en-US",
      "value" : "Nursing"
    }]
  },
  {
    "code" : "5016",
    "display" : "Physiotherapy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Physiotherapie"
    },
    {
      "language" : "rm-CH",
      "value" : "Fisioterapia"
    },
    {
      "language" : "fr-CH",
      "value" : "Physiothérapie"
    },
    {
      "language" : "it-CH",
      "value" : "Fisioterapia"
    },
    {
      "language" : "en-US",
      "value" : "Physiotherapy"
    }]
  },
  {
    "code" : "5017",
    "display" : "Podiatry",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Podologie"
    },
    {
      "language" : "rm-CH",
      "value" : "Podologia"
    },
    {
      "language" : "fr-CH",
      "value" : "Podologie"
    },
    {
      "language" : "it-CH",
      "value" : "Podologia"
    },
    {
      "language" : "en-US",
      "value" : "Podiatry"
    }]
  },
  {
    "code" : "5018",
    "display" : "Paramedics",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Rettungssanität"
    },
    {
      "language" : "rm-CH",
      "value" : "Sanitad da salvament"
    },
    {
      "language" : "fr-CH",
      "value" : "Sauvetage"
    },
    {
      "language" : "it-CH",
      "value" : "Soccorso sanitario"
    },
    {
      "language" : "en-US",
      "value" : "Paramedics"
    }]
  },
  {
    "code" : "5019",
    "display" : "Optometry",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Optometrie"
    },
    {
      "language" : "rm-CH",
      "value" : "Optometria"
    },
    {
      "language" : "fr-CH",
      "value" : "Optométrie"
    },
    {
      "language" : "it-CH",
      "value" : "Optometria"
    },
    {
      "language" : "en-US",
      "value" : "Optometry"
    }]
  },
  {
    "code" : "5021",
    "display" : "Naturopathy Ayurveda Medicine",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Naturheilpraktiker/-in Ayurveda-Medizin"
    },
    {
      "language" : "rm-CH",
      "value" : "Naturopatia/medischina ayurvedica"
    },
    {
      "language" : "fr-CH",
      "value" : "Naturopathe médecine ayurvédique"
    },
    {
      "language" : "it-CH",
      "value" : "Naturopata medicina ayurvedica"
    },
    {
      "language" : "en-US",
      "value" : "Naturopathy ayurveda medicine"
    }]
  },
  {
    "code" : "5022",
    "display" : "Naturopathy Homeopathy",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Naturheilpraktiker/-in Homöopathie"
    },
    {
      "language" : "rm-CH",
      "value" : "Naturopatia/omeopatia"
    },
    {
      "language" : "fr-CH",
      "value" : "Naturopathe homéopathie"
    },
    {
      "language" : "it-CH",
      "value" : "Naturopata omeopatia"
    },
    {
      "language" : "en-US",
      "value" : "Naturopathy homeopathy"
    }]
  },
  {
    "code" : "5023",
    "display" : "Naturopathy Traditional Chinese Medicine",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Naturheilpraktiker/-in Trad. Chinesische Medizin"
    },
    {
      "language" : "rm-CH",
      "value" : "Naturopatia/medischina tradiziunala chinaisa"
    },
    {
      "language" : "fr-CH",
      "value" : "Naturopathe médecine trad. chinoise"
    },
    {
      "language" : "it-CH",
      "value" : "Naturopata medicina trad. cinese"
    },
    {
      "language" : "en-US",
      "value" : "Naturopathy traditional chinese medicine"
    }]
  },
  {
    "code" : "5024",
    "display" : "Naturopathy European Traditional Medicine",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Naturheilpraktiker/-in Trad. Europäische Naturheilkunde"
    },
    {
      "language" : "rm-CH",
      "value" : "Naturopatia/medischina tradiziunala europeica"
    },
    {
      "language" : "fr-CH",
      "value" : "Naturopathe médecine naturelle trad. européenne"
    },
    {
      "language" : "it-CH",
      "value" : "Naturopata medicina naturale trad. europea"
    },
    {
      "language" : "en-US",
      "value" : "Naturopathy traditional european medicine"
    }]
  }]
}

```
