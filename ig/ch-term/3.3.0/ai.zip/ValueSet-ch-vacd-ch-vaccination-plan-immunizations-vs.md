# CH VACD Swiss Vaccination Plan Immunizations - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH VACD Swiss Vaccination Plan Immunizations**

## ValueSet: CH VACD Swiss Vaccination Plan Immunizations 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-vacd/ValueSet/ch-vacd-ch-vaccination-plan-immunizations-vs | *Version*:3.3.0 |
| Active as of 2025-12-15 | *Computable Name*:SwissVaccinationPlanImmunizations |
| **Copyright/Legal**: CC0-1.0 | |

 
Immunization procedures for recommendations according to the vaccination plan. 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/ch-vacd-ch-vaccination-plan-immunizations-vs) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-vacd-ch-vaccination-plan-immunizations-vs",
  "url" : "http://fhir.ch/ig/ch-vacd/ValueSet/ch-vacd-ch-vaccination-plan-immunizations-vs",
  "version" : "3.3.0",
  "name" : "SwissVaccinationPlanImmunizations",
  "title" : "CH VACD Swiss Vaccination Plan Immunizations",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-15T10:36:18+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/"
        }
      ]
    },
    {
      "name" : "HL7 Switzerland",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.hl7.ch/",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "Immunization procedures for recommendations according to the vaccination plan.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [
      {
        "system" : "http://snomed.info/sct",
        "concept" : [
          {
            "code" : "42284007",
            "display" : "Administration of vaccine product containing only live attenuated Mycobacterium bovis antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "BCG-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination par le BCG"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la tubercolosi"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter tuberculosa"
              },
              {
                "language" : "en-US",
                "value" : "BCG vaccination"
              }
            ]
          },
          {
            "code" : "76668005",
            "display" : "Administration of vaccine product containing only Corynebacterium diphtheriae antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Diphterie-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la diphtérie"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la difterite"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter difteria"
              },
              {
                "language" : "en-US",
                "value" : "Diphtheria vaccination"
              }
            ]
          },
          {
            "code" : "127787002",
            "display" : "Administration of vaccine product containing only Haemophilus influenzae type B antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Impfung gegen Haemophilus influenzae Typ B"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'Haemophilus influenzae de type B"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro l'Haemophilus influenzae di tipo b"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter hemofilus influenza tip B"
              },
              {
                "language" : "en-US",
                "value" : "Haemophilus influenzae type b vaccination"
              }
            ]
          },
          {
            "code" : "243789007",
            "display" : "Administration of vaccine product containing only Hepatitis A virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hepatitis-A-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'hépatite A"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro l'epatite A"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter hepatitis A"
              },
              {
                "language" : "en-US",
                "value" : "Hepatitis A vaccination"
              }
            ]
          },
          {
            "code" : "16584000",
            "display" : "Administration of vaccine product containing only Hepatitis B virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Hepatitis-B-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'hépatite B"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro l'epatite B"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter hepatitis B"
              },
              {
                "language" : "en-US",
                "value" : "Hepatitis B vaccination"
              }
            ]
          },
          {
            "code" : "86198006",
            "display" : "Administration of vaccine product containing only Influenza virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Grippeimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'influenza"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro l'influenza"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la grippa"
              },
              {
                "language" : "en-US",
                "value" : "Influenza vaccination"
              }
            ]
          },
          {
            "code" : "314759000",
            "display" : "Administration of vaccine product containing only Japanese encephalitis virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Impfung gegen Japanische Enzephalitis"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'encéphalite japonaise"
              },
              {
                "language" : "it-CH",
                "value" : "Jvaccinazione contro l'encefalite giapponese"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter l'encefalitis giapunaisa"
              },
              {
                "language" : "en-US",
                "value" : "Japanese encephalitis vaccination"
              }
            ]
          },
          {
            "code" : "47435007",
            "display" : "Administration of vaccine product containing only Measles morbillivirus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Masernimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antirougeoleuse"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro il morbillo"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter il virustgel"
              },
              {
                "language" : "en-US",
                "value" : "Measles vaccination"
              }
            ]
          },
          {
            "code" : "719596001",
            "display" : "Administration of vaccine product containing only Neisseria meningitidis serogroup C antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Meningitis-C-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la méningite C"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la meningite C"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter meninghitis C"
              },
              {
                "language" : "en-US",
                "value" : "Meningitis C vaccination"
              }
            ]
          },
          {
            "code" : "314417000",
            "display" : "Administration of vaccine product containing only Neisseria meningitidis serogroup A and C antigens (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Meningitis-A-und-C-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre les méningites A et C"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la meningite A e C"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter meninghitis A e C"
              },
              {
                "language" : "en-US",
                "value" : "Meningitis A and C vaccination"
              }
            ]
          },
          {
            "code" : "871874000",
            "display" : "Administration of vaccine product containing only Neisseria meningitidis serogroup A, C, W135 and Y antigens (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Meningitis-A, C-, W135- und Y-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre les méningites A, C, W135 et Y"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la meningite A, C, W135 e Y"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter meninghitis A, C, W135 ed Y"
              },
              {
                "language" : "en-US",
                "value" : "Meningitis A, C, W135 and Y vaccination"
              }
            ]
          },
          {
            "code" : "50583002",
            "display" : "Administration of vaccine product containing only Mumps orthorubulavirus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Mumpsimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre les oreillons"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la parotite"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter il glandun"
              },
              {
                "language" : "en-US",
                "value" : "Mumps vaccination"
              }
            ]
          },
          {
            "code" : "761841000",
            "display" : "Administration of vaccine product containing only Human papillomavirus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Impfung gegen humane Papillomaviren"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre le papillomavirus humain"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro il virus del papilloma umano"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter ils papillomavirus umans"
              },
              {
                "language" : "en-US",
                "value" : "Human papillomavirus vaccination"
              }
            ]
          },
          {
            "code" : "39343008",
            "display" : "Administration of vaccine product containing only Bordetella pertussis antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Pertussis-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la coqueluche"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la pertosse"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la tuss chanina"
              },
              {
                "language" : "en-US",
                "value" : "Pertussis vaccination"
              }
            ]
          },
          {
            "code" : "1119368005",
            "display" : "Administration of vaccine product containing only Streptococcus pneumoniae Danish serotype 4, 6B, 9V, 14, 18C, 19F, and 23F capsular polysaccharide antigens conjugated (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "7-valente Pneumokokken-Konjugatimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antipneumococcique conjugué 7-valent"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino coniugato eptavalente contro gli pneumococchi"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter pneumococcus cun vaccin fusiunà valenza 7"
              },
              {
                "language" : "en-US",
                "value" : "Pneumococcal 7-valent conjugate vaccination"
              }
            ]
          },
          {
            "code" : "1119366009",
            "display" : "Administration of vaccine product containing only Streptococcus pneumoniae Danish serotype 1, 3, 4, 5, 6A, 6B, 7F, 9V, 14, 18C, 19A, 19F, and 23F capsular polysaccharide antigens (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "13-valente Pneumokokken-Konjugatimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antipneumococcique conjugué 13-valent"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino coniugato 13-valente contro gli pneumococchi"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter pneumococcus cun vaccin fusiunà valenza 13"
              },
              {
                "language" : "en-US",
                "value" : "Pneumococcal 13-valent conjugate vaccination"
              }
            ]
          },
          {
            "code" : "1119367000",
            "display" : "Administration of vaccine product containing only Streptococcus pneumoniae Danish serotype 1, 2, 3, 4, 5, 6B, 7F, 8, 9N, 9V, 10A, 11A, 12F, 14, 15B, 17F, 18C, 19A, 19F, 20, 22F, 23F, and 33F capsular polysaccharide antigens (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "23-valente Pneumokokken-Konjugatimpfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antipneumococcique conjugué 23- valent"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino coniugato 23-valente contro gli pneumococchi"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter pneumococcus cun vaccin fusiunà valenza 23"
              },
              {
                "language" : "en-US",
                "value" : "Pneumococcal 23-valent conjugate vaccination"
              }
            ]
          },
          {
            "code" : "72093006",
            "display" : "Administration of vaccine product containing only Human poliovirus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Polio-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la poliomyélite"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la poliomielite"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter poliomielitica"
              },
              {
                "language" : "en-US",
                "value" : "Poliomyelitis vaccination"
              }
            ]
          },
          {
            "code" : "34631000",
            "display" : "Administration of vaccine product containing only Rabies lyssavirus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tollwut-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la rage"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la rabbia"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la frenesia"
              },
              {
                "language" : "en-US",
                "value" : "Rabies vaccination"
              }
            ]
          },
          {
            "code" : "82314000",
            "display" : "Administration of vaccine product containing only Rubella virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Röteln-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la rubéole"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la rosolia"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la rubella"
              },
              {
                "language" : "en-US",
                "value" : "Rubella vaccination"
              }
            ]
          },
          {
            "code" : "127786006",
            "display" : "Administration of vaccine product containing only Clostridium tetani antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Tetanus-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre le tétanos"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro il tetano"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter tetanus"
              },
              {
                "language" : "en-US",
                "value" : "Tetanus vaccination"
              }
            ]
          },
          {
            "code" : "281658005",
            "display" : "Administration of vaccine product containing only Tick-borne encephalitis virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "FSME-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre l'encéphalite à tiques"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la meningoencefalite da zecche"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la meningoencefalitis da zeccas"
              },
              {
                "language" : "en-US",
                "value" : "Tick-borne encephalitis vaccination"
              }
            ]
          },
          {
            "code" : "15483003",
            "display" : "Administration of vaccine product containing only Salmonella enterica subspecies enterica serovar Typhi antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Typhus-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antityphoïdique"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la febbre tifoidea"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter tifus"
              },
              {
                "language" : "en-US",
                "value" : "Typhoid vaccination"
              }
            ]
          },
          {
            "code" : "737081007",
            "display" : "Administration of vaccine product containing only Human alphaherpesvirus 3 antigen for chickenpox (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Varizellen-Zoster-Impfung gegen Windpocken"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination varicelle-zona contre la varicelle"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro il virus varicella-zoster: solo varicella"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la virola selvadia"
              },
              {
                "language" : "en-US",
                "value" : "Varicella-zoster vaccination for chickenpox"
              }
            ]
          },
          {
            "code" : "722215002",
            "display" : "Administration of vaccine product containing only Human alphaherpesvirus 3 antigen for shingles (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Varizellen-Zoster-Impfung gegen Gürtelrose"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination varicelle-zona contre le zona"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro il virus varicella-zoster: solo herpes zoster"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter herpes zoster"
              },
              {
                "language" : "en-US",
                "value" : "Varicella-zoster vaccination for shingles"
              }
            ]
          },
          {
            "code" : "67308009",
            "display" : "Administration of vaccine product containing only Yellow fever virus antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Gelbfieber-Impfung"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre la fièvre jaune"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro la febbre gialla"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter la fevra melna"
              },
              {
                "language" : "en-US",
                "value" : "Yellow fever vaccination"
              }
            ]
          },
          {
            "code" : "1157107003",
            "display" : "Administration of vaccine product containing only recombinant non-replicating viral vector encoding Severe acute respiratory syndrome coronavirus 2 spike protein (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Nicht replizierende virale Vektorimpfung gegen COVID-19"
              },
              {
                "language" : "fr-CH",
                "value" : "administration d'un vaccin à vecteur viral recombinant non réplicatif contre le COVID-19"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino a vettore virale non replicante anti-COVID-19"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter COVID-19 cun vaccin vectorial viral betg replitgant"
              },
              {
                "language" : "en-US",
                "value" : "COVID-19 non-replicating viral vector vaccination"
              }
            ]
          },
          {
            "code" : "1119350007",
            "display" : "Administration of vaccine product containing only Severe acute respiratory syndrome coronavirus 2 messenger ribonucleic acid (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "mRNA-Impfung gegen COVID-19"
              },
              {
                "language" : "fr-CH",
                "value" : "administration d'un vaccin à ARNm du SARS-CoV-2"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino a mRNA anti-COVID-19"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter COVID-19 cun vaccin mRNA"
              },
              {
                "language" : "en-US",
                "value" : "COVID-19 mRNA vaccination"
              }
            ]
          },
          {
            "code" : "1209198003",
            "display" : "Administration of vaccine product containing only Human papillomavirus 6, 11, 16, 18, 31, 33, 45, 52 and 58 antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Impfung gegen die humanen Papillomaviren 6, 11, 16, 18, 31, 33, 45, 52 und 58"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination contre le papillomavirus humain 6, 11, 16, 18, 31, 33, 45, 52 and 58"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione contro i papillomavirus umani 6, 11, 16, 18, 31, 33, 45, 52 e 58"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter ils papillomavirus umans 6, 11, 16, 18, 31, 33, 45, 52 e 58"
              },
              {
                "language" : "en-US",
                "value" : "Human papillomavirus 6, 11, 16, 18, 31, 33, 45, 52 and 58 vaccination"
              }
            ]
          },
          {
            "code" : "1162645008",
            "display" : "Administration of vaccine product containing only severe acute respiratory syndrome coronavirus 2 recombinant spike protein antigen (procedure)",
            "designation" : [
              {
                "language" : "de-CH",
                "value" : "Impfung gegen Covid-19 mit rekombinanten Spike-Protein-Antigenen"
              },
              {
                "language" : "fr-CH",
                "value" : "vaccination antigénique à protéine Spike recombinante contre le COVID-19"
              },
              {
                "language" : "it-CH",
                "value" : "vaccinazione con vaccino antigenico anti-COVID-19 con proteina spike ricombinante"
              },
              {
                "language" : "rm-CH",
                "value" : "vaccinaziun cunter COVID-19 cun antigens dal protein spike recumbinant"
              },
              {
                "language" : "en-US",
                "value" : "COVID-19 recombinant spike protein antigen vaccination"
              }
            ]
          }
        ]
      }
    ]
  }
}

```
