# Naming Systems - CH Term (R4) v3.3.0

* [**Table of Contents**](toc.md)
* **Naming Systems**

## Naming Systems

* [ForumDatenaustauschTariffType](NamingSystem-forum-datenaustausch-tariff.md)

* [GTIN](NamingSystem-gtin.md)

* [InsuranceCardNumber](NamingSystem-veka.md)

* [AHVN13](NamingSystem-ahvn13.md)

* [BER](NamingSystem-ber.md)

* [EPR_SPID](NamingSystem-epr-spid.md)

* [GLN](NamingSystem-gln.md)

* [UIDB](NamingSystem-uidb.md)

* [ZSR](NamingSystem-zsr.md)

