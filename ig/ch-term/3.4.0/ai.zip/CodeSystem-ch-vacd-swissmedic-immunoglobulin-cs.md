# CH VACD Swissmedic Authorized Immunoglobulin Codes - CH Term (R4) v3.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH VACD Swissmedic Authorized Immunoglobulin Codes**

## CodeSystem: CH VACD Swissmedic Authorized Immunoglobulin Codes 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-immunoglobulin-cs | *Version*:3.4.0 |
| Active as of 2026-06-10 | *Computable Name*:SwissMedicAuthorizedImmunoGlobulinCodesystem |
| **Copyright/Legal**: CC0-1.0 | |

 
The ATC J06B – Immunoglobulin codes Swissmedic has given an autorization. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [SwissImunoglobulin](ValueSet-ch-vacd-swissmedic-immunoglobulin-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ch-vacd-swissmedic-immunoglobulin-cs",
  "url" : "http://fhir.ch/ig/ch-vacd/CodeSystem/ch-vacd-swissmedic-immunoglobulin-cs",
  "version" : "3.4.0",
  "name" : "SwissMedicAuthorizedImmunoGlobulinCodesystem",
  "title" : "CH VACD Swissmedic Authorized Immunoglobulin Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-10T09:49:50+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "The ATC J06B – Immunoglobulin codes Swissmedic has given an autorization.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 36,
  "concept" : [{
    "code" : "00687-01",
    "display" : "Berirab 2 ml, Injektionslösung",
    "definition" : "Berirab 2 ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Berirab 2 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Berirab 2 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Berirab 2 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Berirab 2 ml"
    },
    {
      "language" : "en",
      "value" : "Berirab 2 ml"
    }]
  },
  {
    "code" : "00687-02",
    "display" : "Berirab 5 ml, Injektionslösung",
    "definition" : "Berirab 5 ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Berirab 5 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Berirab 5 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Berirab 5 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Berirab 5 ml"
    },
    {
      "language" : "en",
      "value" : "Berirab 5 ml"
    }]
  },
  {
    "code" : "69039-02",
    "display" : "Beyfortus 100 mg/1 ml, solution injectable en seringue préremplie",
    "definition" : "Beyfortus 100 mg/1 ml, solution injectable en seringue préremplie",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Beyfortus 100 mg/1 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Beyfortus 100 mg/1 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Beyfortus 100 mg/1 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Beyfortus 100 mg/1 ml"
    },
    {
      "language" : "en",
      "value" : "Beyfortus 100 mg/1 ml"
    }]
  },
  {
    "code" : "69039-01",
    "display" : "Beyfortus 50 mg/0.5 ml, solution injectable en seringue préremplie",
    "definition" : "Beyfortus 50 mg/0.5 ml, solution injectable en seringue préremplie",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Beyfortus 50 mg/0.5 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Beyfortus 50 mg/0.5 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Beyfortus 50 mg/0.5 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Beyfortus 50 mg/0.5 ml"
    },
    {
      "language" : "en",
      "value" : "Beyfortus 50 mg/0.5 ml"
    }]
  },
  {
    "code" : "68222-01",
    "display" : "Cutaquig 165 mg/ml, Injektionslösung",
    "definition" : "Cutaquig 165 mg/ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Cutaquig 165 mg/ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Cutaquig 165 mg/ml"
    },
    {
      "language" : "it-CH",
      "value" : "Cutaquig 165 mg/ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Cutaquig 165 mg/ml"
    },
    {
      "language" : "en",
      "value" : "Cutaquig 165 mg/ml"
    }]
  },
  {
    "code" : "65992-01",
    "display" : "Cuvitru 200 mg/ml, Injektionslösung",
    "definition" : "Cuvitru 200 mg/ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Cuvitru 200 mg/ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Cuvitru 200 mg/ml"
    },
    {
      "language" : "it-CH",
      "value" : "Cuvitru 200 mg/ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Cuvitru 200 mg/ml"
    },
    {
      "language" : "en",
      "value" : "Cuvitru 200 mg/ml"
    }]
  },
  {
    "code" : "00506-02",
    "display" : "Cytotect CP Biotest, Infusionslösung",
    "definition" : "Cytotect CP Biotest, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Cytotect CP Biotest"
    },
    {
      "language" : "fr-CH",
      "value" : "Cytotect CP Biotest"
    },
    {
      "language" : "it-CH",
      "value" : "Cytotect CP Biotest"
    },
    {
      "language" : "rm-CH",
      "value" : "Cytotect CP Biotest"
    },
    {
      "language" : "en",
      "value" : "Cytotect CP Biotest"
    }]
  },
  {
    "code" : "00701-02",
    "display" : "Gammanorm, Injektionslösung",
    "definition" : "Gammanorm, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Gammanorm"
    },
    {
      "language" : "fr-CH",
      "value" : "Gammanorm"
    },
    {
      "language" : "it-CH",
      "value" : "Gammanorm"
    },
    {
      "language" : "rm-CH",
      "value" : "Gammanorm"
    },
    {
      "language" : "en",
      "value" : "Gammanorm"
    }]
  },
  {
    "code" : "00668-01",
    "display" : "Gamunex 10%, solution pour injection intraveineuse",
    "definition" : "Gamunex 10%, solution pour injection intraveineuse",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Gamunex 10%"
    },
    {
      "language" : "fr-CH",
      "value" : "Gamunex 10%"
    },
    {
      "language" : "it-CH",
      "value" : "Gamunex 10%"
    },
    {
      "language" : "rm-CH",
      "value" : "Gamunex 10%"
    },
    {
      "language" : "en",
      "value" : "Gamunex 10%"
    }]
  },
  {
    "code" : "00488-02",
    "display" : "Hepatect CP, Infusionslösung",
    "definition" : "Hepatect CP, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Hepatect CP"
    },
    {
      "language" : "fr-CH",
      "value" : "Hepatect CP"
    },
    {
      "language" : "it-CH",
      "value" : "Hepatect CP"
    },
    {
      "language" : "rm-CH",
      "value" : "Hepatect CP"
    },
    {
      "language" : "en",
      "value" : "Hepatect CP"
    }]
  },
  {
    "code" : "00674-01",
    "display" : "Hepatitis-B-Immunglobulin Behring, Injektionslösung",
    "definition" : "Hepatitis-B-Immunglobulin Behring, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Hepatitis-B-Immunglobulin Behring"
    },
    {
      "language" : "fr-CH",
      "value" : "Hepatitis-B-Immunglobulin Behring"
    },
    {
      "language" : "it-CH",
      "value" : "Hepatitis-B-Immunglobulin Behring"
    },
    {
      "language" : "rm-CH",
      "value" : "Hepatitis-B-Immunglobulin Behring"
    },
    {
      "language" : "en",
      "value" : "Hepatitis-B-Immunglobulin Behring"
    }]
  },
  {
    "code" : "66410-01",
    "display" : "Hizentra 200mg/ml, Injektionslösung zur s.c. Anwendung, Fertigspritze",
    "definition" : "Hizentra 200mg/ml, Injektionslösung zur s.c. Anwendung, Fertigspritze",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Hizentra 200mg/ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Hizentra 200mg/ml"
    },
    {
      "language" : "it-CH",
      "value" : "Hizentra 200mg/ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Hizentra 200mg/ml"
    },
    {
      "language" : "en",
      "value" : "Hizentra 200mg/ml"
    }]
  },
  {
    "code" : "61547-01",
    "display" : "Hizentra, Injektionslösung zur s.c. Anwendung",
    "definition" : "Hizentra, Injektionslösung zur s.c. Anwendung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Hizentra"
    },
    {
      "language" : "fr-CH",
      "value" : "Hizentra"
    },
    {
      "language" : "it-CH",
      "value" : "Hizentra"
    },
    {
      "language" : "rm-CH",
      "value" : "Hizentra"
    },
    {
      "language" : "en",
      "value" : "Hizentra"
    }]
  },
  {
    "code" : "66684-01",
    "display" : "HyQvia 100 mg/ml, Infusionslösung zur subkutanen Anwendung",
    "definition" : "HyQvia 100 mg/ml, Infusionslösung zur subkutanen Anwendung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "HyQvia 100 mg/ml"
    },
    {
      "language" : "fr-CH",
      "value" : "HyQvia 100 mg/ml"
    },
    {
      "language" : "it-CH",
      "value" : "HyQvia 100 mg/ml"
    },
    {
      "language" : "rm-CH",
      "value" : "HyQvia 100 mg/ml"
    },
    {
      "language" : "en",
      "value" : "HyQvia 100 mg/ml"
    }]
  },
  {
    "code" : "58157-01",
    "display" : "Ig Vena Kedrion 50 g/I, solution pour infusion",
    "definition" : "Ig Vena Kedrion 50 g/I, solution pour infusion",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ig Vena Kedrion 50 g/I"
    },
    {
      "language" : "fr-CH",
      "value" : "Ig Vena Kedrion 50 g/I"
    },
    {
      "language" : "it-CH",
      "value" : "Ig Vena Kedrion 50 g/I"
    },
    {
      "language" : "rm-CH",
      "value" : "Ig Vena Kedrion 50 g/I"
    },
    {
      "language" : "en",
      "value" : "Ig Vena Kedrion 50 g/I"
    }]
  },
  {
    "code" : "62913-01",
    "display" : "Intratect 10%, Infusionslösung",
    "definition" : "Intratect 10%, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Intratect 10%"
    },
    {
      "language" : "fr-CH",
      "value" : "Intratect 10%"
    },
    {
      "language" : "it-CH",
      "value" : "Intratect 10%"
    },
    {
      "language" : "rm-CH",
      "value" : "Intratect 10%"
    },
    {
      "language" : "en",
      "value" : "Intratect 10%"
    }]
  },
  {
    "code" : "57676-01",
    "display" : "Intratect 5%, Infusionslösung",
    "definition" : "Intratect 5%, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Intratect 5%"
    },
    {
      "language" : "fr-CH",
      "value" : "Intratect 5%"
    },
    {
      "language" : "it-CH",
      "value" : "Intratect 5%"
    },
    {
      "language" : "rm-CH",
      "value" : "Intratect 5%"
    },
    {
      "language" : "en",
      "value" : "Intratect 5%"
    }]
  },
  {
    "code" : "66332-03",
    "display" : "Iqymune 10g/100ml, Infusionslösung",
    "definition" : "Iqymune 10g/100ml, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Iqymune 10g/100ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Iqymune 10g/100ml"
    },
    {
      "language" : "it-CH",
      "value" : "Iqymune 10g/100ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Iqymune 10g/100ml"
    },
    {
      "language" : "en",
      "value" : "Iqymune 10g/100ml"
    }]
  },
  {
    "code" : "66332-04",
    "display" : "Iqymune 20g/200ml, Infusionslösung",
    "definition" : "Iqymune 20g/200ml, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Iqymune 20g/200ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Iqymune 20g/200ml"
    },
    {
      "language" : "it-CH",
      "value" : "Iqymune 20g/200ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Iqymune 20g/200ml"
    },
    {
      "language" : "en",
      "value" : "Iqymune 20g/200ml"
    }]
  },
  {
    "code" : "66332-01",
    "display" : "Iqymune 2g/20ml, Infusionslösung",
    "definition" : "Iqymune 2g/20ml, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Iqymune 2g/20ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Iqymune 2g/20ml"
    },
    {
      "language" : "it-CH",
      "value" : "Iqymune 2g/20ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Iqymune 2g/20ml"
    },
    {
      "language" : "en",
      "value" : "Iqymune 2g/20ml"
    }]
  },
  {
    "code" : "66332-02",
    "display" : "Iqymune 5g/50ml, Infusionslösung",
    "definition" : "Iqymune 5g/50ml, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Iqymune 5g/50ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Iqymune 5g/50ml"
    },
    {
      "language" : "it-CH",
      "value" : "Iqymune 5g/50ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Iqymune 5g/50ml"
    },
    {
      "language" : "en",
      "value" : "Iqymune 5g/50ml"
    }]
  },
  {
    "code" : "60323-01",
    "display" : "Octagam 10 %, Lösung zur intravenösen Anwendung",
    "definition" : "Octagam 10 %, Lösung zur intravenösen Anwendung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Octagam 10 %"
    },
    {
      "language" : "fr-CH",
      "value" : "Octagam 10 %"
    },
    {
      "language" : "it-CH",
      "value" : "Octagam 10 %"
    },
    {
      "language" : "rm-CH",
      "value" : "Octagam 10 %"
    },
    {
      "language" : "en",
      "value" : "Octagam 10 %"
    }]
  },
  {
    "code" : "57469-01",
    "display" : "Kiovig, Infusionslösung",
    "definition" : "Kiovig, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Kiovig"
    },
    {
      "language" : "fr-CH",
      "value" : "Kiovig"
    },
    {
      "language" : "it-CH",
      "value" : "Kiovig"
    },
    {
      "language" : "rm-CH",
      "value" : "Kiovig"
    },
    {
      "language" : "en",
      "value" : "Kiovig"
    }]
  },
  {
    "code" : "58314-01",
    "display" : "Privigen, Infusionslösung",
    "definition" : "Privigen, Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Privigen"
    },
    {
      "language" : "fr-CH",
      "value" : "Privigen"
    },
    {
      "language" : "it-CH",
      "value" : "Privigen"
    },
    {
      "language" : "rm-CH",
      "value" : "Privigen"
    },
    {
      "language" : "en",
      "value" : "Privigen"
    }]
  },
  {
    "code" : "53609-02",
    "display" : "Rhophylac 300, Injektionslösung",
    "definition" : "Rhophylac 300, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Rhophylac 300"
    },
    {
      "language" : "fr-CH",
      "value" : "Rhophylac 300"
    },
    {
      "language" : "it-CH",
      "value" : "Rhophylac 300"
    },
    {
      "language" : "rm-CH",
      "value" : "Rhophylac 300"
    },
    {
      "language" : "en",
      "value" : "Rhophylac 300"
    }]
  },
  {
    "code" : "65695-02",
    "display" : "Synagis 100 mg/1 ml, Injektionslösung",
    "definition" : "Synagis 100 mg/1 ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Synagis 100 mg/1 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Synagis 100 mg/1 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Synagis 100 mg/1 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Synagis 100 mg/1 ml"
    },
    {
      "language" : "en",
      "value" : "Synagis 100 mg/1 ml"
    }]
  },
  {
    "code" : "65695-01",
    "display" : "Synagis 50 mg/0.5 ml, Injektionslösung",
    "definition" : "Synagis 50 mg/0.5 ml, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Synagis 50 mg/0.5 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Synagis 50 mg/0.5 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Synagis 50 mg/0.5 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Synagis 50 mg/0.5 ml"
    },
    {
      "language" : "en",
      "value" : "Synagis 50 mg/0.5 ml"
    }]
  },
  {
    "code" : "00673-02",
    "display" : "Tetagam P, Injektionslösung",
    "definition" : "Tetagam P, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Tetagam P"
    },
    {
      "language" : "fr-CH",
      "value" : "Tetagam P"
    },
    {
      "language" : "it-CH",
      "value" : "Tetagam P"
    },
    {
      "language" : "rm-CH",
      "value" : "Tetagam P"
    },
    {
      "language" : "en",
      "value" : "Tetagam P"
    }]
  },
  {
    "code" : "59374-01",
    "display" : "Uman Big 180 UI/1 ml, solution pour injection intramusculaire",
    "definition" : "Uman Big 180 UI/1 ml, solution pour injection intramusculaire",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Uman Big 180 UI/1 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Uman Big 180 UI/1 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Uman Big 180 UI/1 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Uman Big 180 UI/1 ml"
    },
    {
      "language" : "en",
      "value" : "Uman Big 180 UI/1 ml"
    }]
  },
  {
    "code" : "59374-02",
    "display" : "Uman Big 540 UI/3 ml, solution pour injection intramusculaire",
    "definition" : "Uman Big 540 UI/3 ml, solution pour injection intramusculaire",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Uman Big 540 UI/3 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Uman Big 540 UI/3 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Uman Big 540 UI/3 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Uman Big 540 UI/3 ml"
    },
    {
      "language" : "en",
      "value" : "Uman Big 540 UI/3 ml"
    }]
  },
  {
    "code" : "59451-01",
    "display" : "Varitect CP, Lösung zur intravenösen Injektion",
    "definition" : "Varitect CP, Lösung zur intravenösen Injektion",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Varitect CP"
    },
    {
      "language" : "fr-CH",
      "value" : "Varitect CP"
    },
    {
      "language" : "it-CH",
      "value" : "Varitect CP"
    },
    {
      "language" : "rm-CH",
      "value" : "Varitect CP"
    },
    {
      "language" : "en",
      "value" : "Varitect CP"
    }]
  },
  {
    "code" : "59373-02",
    "display" : "Venbig 2500 U.I/50 ml, poudre et solution pour injection intraveineuse",
    "definition" : "Venbig 2500 U.I/50 ml, poudre et solution pour injection intraveineuse",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Venbig 2500 U.I/50 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Venbig 2500 U.I/50 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Venbig 2500 U.I/50 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Venbig 2500 U.I/50 ml"
    },
    {
      "language" : "en",
      "value" : "Venbig 2500 U.I/50 ml"
    }]
  },
  {
    "code" : "59373-01",
    "display" : "Venbig 500 U.I/10 ml, poudre et solution pour injection intraveineuse",
    "definition" : "Venbig 500 U.I/10 ml, poudre et solution pour injection intraveineuse",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Venbig 500 U.I/10 ml"
    },
    {
      "language" : "fr-CH",
      "value" : "Venbig 500 U.I/10 ml"
    },
    {
      "language" : "it-CH",
      "value" : "Venbig 500 U.I/10 ml"
    },
    {
      "language" : "rm-CH",
      "value" : "Venbig 500 U.I/10 ml"
    },
    {
      "language" : "en",
      "value" : "Venbig 500 U.I/10 ml"
    }]
  },
  {
    "code" : "68471-01",
    "display" : "Xevudy, Konzentrat zur Herstellung einer Infusionslösung",
    "definition" : "Xevudy, Konzentrat zur Herstellung einer Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Xevudy"
    },
    {
      "language" : "fr-CH",
      "value" : "Xevudy"
    },
    {
      "language" : "it-CH",
      "value" : "Xevudy"
    },
    {
      "language" : "rm-CH",
      "value" : "Xevudy"
    },
    {
      "language" : "en",
      "value" : "Xevudy"
    }]
  },
  {
    "code" : "66344-01",
    "display" : "Zinplava, Konzentrat zur Herstellung einer Infusionslösung",
    "definition" : "Zinplava, Konzentrat zur Herstellung einer Infusionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Zinplava"
    },
    {
      "language" : "fr-CH",
      "value" : "Zinplava"
    },
    {
      "language" : "it-CH",
      "value" : "Zinplava"
    },
    {
      "language" : "rm-CH",
      "value" : "Zinplava"
    },
    {
      "language" : "en",
      "value" : "Zinplava"
    }]
  },
  {
    "code" : "61639-01",
    "display" : "Zutectra, Injektionslösung",
    "definition" : "Zutectra, Injektionslösung",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Zutectra"
    },
    {
      "language" : "fr-CH",
      "value" : "Zutectra"
    },
    {
      "language" : "it-CH",
      "value" : "Zutectra"
    },
    {
      "language" : "rm-CH",
      "value" : "Zutectra"
    },
    {
      "language" : "en",
      "value" : "Zutectra"
    }]
  }]
}

```
