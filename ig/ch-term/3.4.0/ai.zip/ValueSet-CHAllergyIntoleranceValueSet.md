# CH AllergyIntolerance - CH Term (R4) v3.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH AllergyIntolerance**

## ValueSet: CH AllergyIntolerance 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-allergyintolerance/ValueSet/CHAllergyIntoleranceValueSet | *Version*:3.4.0 |
| Active as of 2026-06-10 | *Computable Name*:CHAllergyIntoleranceValueSet |
| **Copyright/Legal**: CC0-1.0 | |

 
CH AllergyIntolerance coding value set. This value set includes codes values from SNOMED Clinical Terms® for no known [xy] allergies AND findings AND substances for the documentation of allergy or intolerance 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/CHAllergyIntoleranceValueSet) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CHAllergyIntoleranceValueSet",
  "url" : "http://fhir.ch/ig/ch-allergyintolerance/ValueSet/CHAllergyIntoleranceValueSet",
  "version" : "3.4.0",
  "name" : "CHAllergyIntoleranceValueSet",
  "title" : "CH AllergyIntolerance",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-10T09:49:50+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "CH AllergyIntolerance coding value set. This value set includes codes values  from SNOMED Clinical Terms® for no known [xy] allergies AND findings AND substances for the documentation of allergy or intolerance",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "716186003",
        "display" : "No known allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie connue"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Allergie"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia nota"
        }]
      },
      {
        "code" : "716220001",
        "display" : "No known animal allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known animal allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie connue aux animaux"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Allergie gegen Tiere"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia agli animali nota"
        }]
      },
      {
        "code" : "428197003",
        "display" : "No known insect allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known insect allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie connue aux insectes"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Allergie gegen Insekten"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia agli insetti nota"
        }]
      },
      {
        "code" : "409137002",
        "display" : "No known drug allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known drug allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie médicamenteuse connue"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Arzneimittelallergie"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia a farmaci nota"
        }]
      },
      {
        "code" : "428607008",
        "display" : "No known environmental allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known environmental allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie environnementale connue"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Umweltallergie"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia ambientale nota"
        }]
      },
      {
        "code" : "429625007",
        "display" : "No known food allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known food allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie alimentaire connue"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Lebensmittelallergie"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia alimentare nota"
        }]
      },
      {
        "code" : "1003774007",
        "display" : "No known Hevea brasiliensis latex allergy (situation)",
        "designation" : [{
          "language" : "en-US",
          "value" : "No known Hevea brasiliensis latex allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "pas d'allergie connue au latex d'Hevea brasiliensis"
        },
        {
          "language" : "de-CH",
          "value" : "Keine bekannte Allergie gegen Hevea brasiliensis-Latex"
        },
        {
          "language" : "it-CH",
          "value" : "nessuna allergia nota al lattice di Hevea brasiliensis"
        }]
      },
      {
        "code" : "11861000122107",
        "display" : "Allergy to pantoprazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pantoprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pantoprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pantoprazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al pantoprazolo"
        }]
      },
      {
        "code" : "13181000122107",
        "display" : "Allergy to levofloxacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to levofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lévofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Levofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla levofloxacina"
        }]
      },
      {
        "code" : "13221000122100",
        "display" : "Allergy to atorvastatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to atorvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'atorvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Atorvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'atorvastatina"
        }]
      },
      {
        "code" : "13511000122108",
        "display" : "Allergy to pineapple (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pineapple"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'ananas"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ananas"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'ananas"
        }]
      },
      {
        "code" : "151201000119107",
        "display" : "Allergy to insect venom (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to insect venom"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au venin d'insectes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Insektengift"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al veleno di insetti"
        }]
      },
      {
        "code" : "190749000",
        "display" : "Glucose-galactose malabsorption (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glucose-galactose malabsorption"
        },
        {
          "language" : "fr-CH",
          "value" : "malabsorption du glucose-galactose"
        },
        {
          "language" : "de-CH",
          "value" : "Glukose-Galaktose-Malabsorption"
        },
        {
          "language" : "it-CH",
          "value" : "malassorbimento di glucosio-galattosio"
        }]
      },
      {
        "code" : "20052008",
        "display" : "Fructose-1,6-bisphosphate aldolase B deficiency (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fructose-1,6-bisphosphate aldolase B deficiency"
        },
        {
          "language" : "fr-CH",
          "value" : "intolérance héréditaire au fructose"
        },
        {
          "language" : "de-CH",
          "value" : "Fructose-1,6-Bisphosphat-Aldolase-B-Mangel"
        },
        {
          "language" : "it-CH",
          "value" : "deficit di fruttosio-1,6-bisfosfato aldolasi B"
        }]
      },
      {
        "code" : "21191000122102",
        "display" : "Allergy to mustard seasoning (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mustard seasoning"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la moutarde"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Senfgewürz"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla senape"
        }]
      },
      {
        "code" : "213020009",
        "display" : "Allergy to egg protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to egg protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux protéines de l'œuf"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Eiprotein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine dell'uovo"
        }]
      },
      {
        "code" : "23181000122104",
        "display" : "Allergy to mango fruit (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mango fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mangue"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mangofrucht"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mango"
        }]
      },
      {
        "code" : "232349006",
        "display" : "Allergy to house dust (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to house dust"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la poussière de maison"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hausstaubmilben"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla polvere"
        }]
      },
      {
        "code" : "232350006",
        "display" : "Allergy to dust mite protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dust mite protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux acariens"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hausstaubmilbenprotein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine degli acari della polvere"
        }]
      },
      {
        "code" : "293584003",
        "display" : "Allergy to paracetamol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to paracetamol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au paracétamol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Paracetamol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al paracetamolo"
        }]
      },
      {
        "code" : "293585002",
        "display" : "Allergy to salicylate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to salicylate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au salicylate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Salicylat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai salicilati"
        }]
      },
      {
        "code" : "293588000",
        "display" : "Allergy to pentazocine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pentazocine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pentazocine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pentazocin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pentazocina"
        }]
      },
      {
        "code" : "293594008",
        "display" : "Allergy to methadone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methadone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la méthadone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methadon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metadone"
        }]
      },
      {
        "code" : "293596005",
        "display" : "Allergy to buprenorphine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to buprenorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la buprénorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Buprenorphin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla buprenorfina"
        }]
      },
      {
        "code" : "293597001",
        "display" : "Allergy to codeine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to codeine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la codéine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kodein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla codeina"
        }]
      },
      {
        "code" : "293598006",
        "display" : "Allergy to diamorphine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diamorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la diamorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diamorphin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla diamorfina"
        }]
      },
      {
        "code" : "293600000",
        "display" : "Allergy to nalbuphine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nalbuphine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nalbuphine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nalbuphin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nalbufina"
        }]
      },
      {
        "code" : "293601001",
        "display" : "Allergy to morphine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to morphine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la morphine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Morphin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla morfina"
        }]
      },
      {
        "code" : "293604009",
        "display" : "Allergy to alfentanil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to alfentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'alfentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Alfentanil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alfentanil"
        }]
      },
      {
        "code" : "293605005",
        "display" : "Allergy to fentanyl (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fentanyl"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fentanyl"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fentanyl"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fentanyl"
        }]
      },
      {
        "code" : "293606006",
        "display" : "Allergy to pethidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pethidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la péthidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pethidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla petidina"
        }]
      },
      {
        "code" : "293608007",
        "display" : "Allergy to meptazinol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to meptazinol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au meptazinol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Meptazinol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al meptazinolo"
        }]
      },
      {
        "code" : "293611008",
        "display" : "Allergy to acemetacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acemetacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acémétacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acemetacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acemetacina"
        }]
      },
      {
        "code" : "293612001",
        "display" : "Allergy to azapropazone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to azapropazone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'azapropazone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Azapropazon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’azapropazone"
        }]
      },
      {
        "code" : "293613006",
        "display" : "Allergy to diclofenac (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diclofenac"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au diclofénac"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diclofenac"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al diclofenac"
        }]
      },
      {
        "code" : "293618002",
        "display" : "Allergy to flurbiprofen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flurbiprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flurbiprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flurbiprofen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flurbiprofene"
        }]
      },
      {
        "code" : "293619005",
        "display" : "Allergy to ibuprofen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ibuprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'ibuprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ibuprofen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ibuprofene"
        }]
      },
      {
        "code" : "293620004",
        "display" : "Allergy to indometacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to indometacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'indométacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Indometacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’indometacina"
        }]
      },
      {
        "code" : "293621000",
        "display" : "Allergy to ketoprofen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ketoprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au kétoprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ketoprofen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al ketoprofene"
        }]
      },
      {
        "code" : "293623002",
        "display" : "Allergy to mefenamic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mefenamic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide méfénamique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mefenaminsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido mefenamico"
        }]
      },
      {
        "code" : "293625009",
        "display" : "Allergy to naproxen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to naproxen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au naproxène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Naproxen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al naproxene"
        }]
      },
      {
        "code" : "293629003",
        "display" : "Allergy to piroxicam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piroxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au piroxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piroxicam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al piroxicam"
        }]
      },
      {
        "code" : "293631007",
        "display" : "Allergy to tenoxicam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tenoxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au ténoxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tenoxicam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tenoxicam"
        }]
      },
      {
        "code" : "293635003",
        "display" : "Allergy to tuberculin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tuberculin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie tuberculinique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tuberculin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tubercolina"
        }]
      },
      {
        "code" : "293648004",
        "display" : "Allergy to misoprostol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to misoprostol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au misoprostol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Misoprostol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al misoprostolo"
        }]
      },
      {
        "code" : "293650007",
        "display" : "Allergy to cimetidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cimetidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cimétidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cimetidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cimetidina"
        }]
      },
      {
        "code" : "293653009",
        "display" : "Allergy to ranitidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ranitidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la ranitidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ranitidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ranitidina"
        }]
      },
      {
        "code" : "293655002",
        "display" : "Allergy to omeprazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to omeprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oméprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Omeprazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’omeprazolo"
        }]
      },
      {
        "code" : "293656001",
        "display" : "Allergy to lansoprazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lansoprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lansoprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lansoprazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lansoprazolo"
        }]
      },
      {
        "code" : "293658000",
        "display" : "Allergy to pirenzepine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pirenzepine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pirenzépine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pirenzepin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pirenzepina"
        }]
      },
      {
        "code" : "293660003",
        "display" : "Allergy to mesalazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mesalazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mésalazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mesalazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mesalazina"
        }]
      },
      {
        "code" : "293663001",
        "display" : "Allergy to sulfasalazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulfasalazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la sulfasalazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfasalazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sulfasalazina"
        }]
      },
      {
        "code" : "293678008",
        "display" : "Allergy to bisacodyl (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bisacodyl"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bisacodyl"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bisacodyl"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al bisacodile"
        }]
      },
      {
        "code" : "293680002",
        "display" : "Allergy to sodium picosulfate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sodium picosulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au picosulfate de sodium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Picosulfat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sodio picosolfato"
        }]
      },
      {
        "code" : "293692002",
        "display" : "Allergy to mebeverine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mebeverine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mébévérine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mebeverin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mebeverina"
        }]
      },
      {
        "code" : "293706001",
        "display" : "Allergy to etomidate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to etomidate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'étomidate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Etomidat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’etomidato"
        }]
      },
      {
        "code" : "293707005",
        "display" : "Allergy to ketamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ketamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la kétamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ketamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ketamina"
        }]
      },
      {
        "code" : "293708000",
        "display" : "Allergy to propofol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to propofol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au propofol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Propofol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al propofol"
        }]
      },
      {
        "code" : "293709008",
        "display" : "Allergy to thiopental (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiopental"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au thiopental"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiopental"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tiopentale"
        }]
      },
      {
        "code" : "293714007",
        "display" : "Allergy to halothane (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to halothane"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'halothane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Halothan"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alotano"
        }]
      },
      {
        "code" : "293715008",
        "display" : "Allergy to isoflurane (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to isoflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'isoflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Isofluran"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’isoflurano"
        }]
      },
      {
        "code" : "293717000",
        "display" : "Allergy to desflurane (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to desflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au desflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Desfluran"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al desflurano"
        }]
      },
      {
        "code" : "293719002",
        "display" : "Allergy to bupivacaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bupivacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la bupivacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bupivacain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla bupivacaina"
        }]
      },
      {
        "code" : "293720008",
        "display" : "Allergy to cinchocaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cinchocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cinchocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cinchocain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cincocaina"
        }]
      },
      {
        "code" : "293722000",
        "display" : "Allergy to lidocaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lidocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lidocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lidocain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla lidocaina"
        }]
      },
      {
        "code" : "293724004",
        "display" : "Allergy to benzocaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to benzocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la benzocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Benzocain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla benzocaina"
        }]
      },
      {
        "code" : "293725003",
        "display" : "Allergy to tetracaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tetracaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tétracaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tetracain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tetracaina"
        }]
      },
      {
        "code" : "293726002",
        "display" : "Allergy to oxybuprocaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oxybuprocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oxybuprocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Oxybuprocain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ossibuprocaina"
        }]
      },
      {
        "code" : "293727006",
        "display" : "Allergy to procaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to procaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la procaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Procain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla procaina"
        }]
      },
      {
        "code" : "293728001",
        "display" : "Allergy to proxymetacaine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to proxymetacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la proxymétacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Proxymetacain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla prossimetacaina"
        }]
      },
      {
        "code" : "293733002",
        "display" : "Allergy to aldesleukin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aldesleukin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aldesleukine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aldesleukin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'aldesleuchina"
        }]
      },
      {
        "code" : "293735009",
        "display" : "Allergy to molgramostim (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to molgramostim"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au molgramostim"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Molgramostim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al molgramostim"
        }]
      },
      {
        "code" : "293736005",
        "display" : "Allergy to lenograstim (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lenograstim"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lénograstim"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lenograstim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lenograstim"
        }]
      },
      {
        "code" : "293737001",
        "display" : "Allergy to filgrastim (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to filgrastim"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au filgrastim"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Filgrastim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al filgrastim"
        }]
      },
      {
        "code" : "293738006",
        "display" : "Allergy to levamisole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to levamisole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lévamisole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Levamisol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al levamisolo"
        }]
      },
      {
        "code" : "293742009",
        "display" : "Allergy to busulfan (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to busulfan"
        },
        {
          "language" : "fr-CH",
          "value" : "allergieau busulfan"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Busulfan"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al busulfano"
        }]
      },
      {
        "code" : "293743004",
        "display" : "Allergy to treosulfan (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to treosulfan"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tréosulfan"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Treosulfan"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al treosulfano"
        }]
      },
      {
        "code" : "293745006",
        "display" : "Allergy to thiotepa (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiotepa"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au thiotépa"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiotepa"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tiotepa"
        }]
      },
      {
        "code" : "293747003",
        "display" : "Allergy to chlorambucil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlorambucil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au chlorambucil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlorambucil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clorambucile"
        }]
      },
      {
        "code" : "293748008",
        "display" : "Allergy to cyclophosphamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cyclophosphamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au cyclophosphamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cyclophosphamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ciclofosfamide"
        }]
      },
      {
        "code" : "293750000",
        "display" : "Allergy to ifosfamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ifosfamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'ifosfamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ifosfamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ifosfamide"
        }]
      },
      {
        "code" : "293751001",
        "display" : "Allergy to melphalan (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to melphalan"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au melphalan"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Melphalan"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al melfalan"
        }]
      },
      {
        "code" : "293752008",
        "display" : "Allergy to estramustine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to estramustine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'estramustine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Estramustin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’estramustina"
        }]
      },
      {
        "code" : "293755005",
        "display" : "Allergy to carmustine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carmustine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la carmustine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carmustin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carmustina"
        }]
      },
      {
        "code" : "293756006",
        "display" : "Allergy to lomustine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lomustine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lomustine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lomustin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla lomustina"
        }]
      },
      {
        "code" : "293758007",
        "display" : "Allergy to dacarbazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dacarbazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dacarbazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dacarbazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla dacarbazina"
        }]
      },
      {
        "code" : "293760009",
        "display" : "Allergy to dactinomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dactinomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dactinomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dactinomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla dactinomicina"
        }]
      },
      {
        "code" : "293761008",
        "display" : "Allergy to bleomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bleomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la bléomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bleomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla bleomicina"
        }]
      },
      {
        "code" : "293762001",
        "display" : "Allergy to mitomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mitomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mitomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mitomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mitomicina"
        }]
      },
      {
        "code" : "293765004",
        "display" : "Allergy to mitoxantrone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mitoxantrone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mitoxantrone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mitoxantron"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mitoxantrone"
        }]
      },
      {
        "code" : "293767007",
        "display" : "Allergy to epirubicin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to epirubicin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'épirubicine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Epirubicin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’epirubicina"
        }]
      },
      {
        "code" : "293768002",
        "display" : "Allergy to idarubicin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to idarubicin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'idarubicine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Idarubicin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idarubicina"
        }]
      },
      {
        "code" : "293771005",
        "display" : "Allergy to methotrexate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methotrexate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au méthotrexate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methotrexat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metotrexato"
        }]
      },
      {
        "code" : "293772003",
        "display" : "Allergy to mercaptopurine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mercaptopurine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mercaptopurine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mercaptopurin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mercaptopurina"
        }]
      },
      {
        "code" : "293774002",
        "display" : "Allergy to pentostatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pentostatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pentostatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pentostatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pentostatina"
        }]
      },
      {
        "code" : "293775001",
        "display" : "Allergy to cytarabine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cytarabine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cytarabine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cytarabin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla citarabina"
        }]
      },
      {
        "code" : "293776000",
        "display" : "Allergy to fluorouracil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluorouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fluorouracil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluorouracil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluorouracile"
        }]
      },
      {
        "code" : "293777009",
        "display" : "Allergy to etoposide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to etoposide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'étoposide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Etoposid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’etoposide"
        }]
      },
      {
        "code" : "293778004",
        "display" : "Allergy to amsacrine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amsacrine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amsacrine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amsacrin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amsacrina"
        }]
      },
      {
        "code" : "293779007",
        "display" : "Allergy to carboplatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carboplatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au carboplatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carboplatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al carboplatino"
        }]
      },
      {
        "code" : "293780005",
        "display" : "Allergy to cisplatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cisplatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au cisplatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cisplatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cisplatino"
        }]
      },
      {
        "code" : "293781009",
        "display" : "Allergy to hydroxycarbamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hydroxycarbamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydroxycarbamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hydroxycarbamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idrossicarbamide"
        }]
      },
      {
        "code" : "293782002",
        "display" : "Allergy to procarbazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to procarbazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la procarbazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Procarbazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla procarbazina"
        }]
      },
      {
        "code" : "293785000",
        "display" : "Allergy to paclitaxel (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to paclitaxel"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au paclitaxel"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Paclitaxel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al paclitaxel"
        }]
      },
      {
        "code" : "293787008",
        "display" : "Allergy to aminoglutethimide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aminoglutethimide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aminoglutéthimide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aminoglutethimid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amminoglutetimide"
        }]
      },
      {
        "code" : "293790002",
        "display" : "Allergy to tamoxifen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tamoxifen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tamoxifène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tamoxifen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tamoxifene"
        }]
      },
      {
        "code" : "293795007",
        "display" : "Allergy to vindesine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vindesine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la vindésine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Vindesin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla vindesina"
        }]
      },
      {
        "code" : "293798009",
        "display" : "Allergy to ciclosporin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ciclosporin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cyclosporine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ciclosporin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ciclosporina"
        }]
      },
      {
        "code" : "293799001",
        "display" : "Allergy to azathioprine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to azathioprine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'azathioprine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Azathioprin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’azatioprina"
        }]
      },
      {
        "code" : "293812003",
        "display" : "Allergy to apomorphine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to apomorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'apomorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Apomorphin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’apomorfina"
        }]
      },
      {
        "code" : "293814002",
        "display" : "Allergy to pergolide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pergolide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pergolide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pergolid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pergolide"
        }]
      },
      {
        "code" : "293815001",
        "display" : "Allergy to bromocriptine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bromocriptine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la bromocriptine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bromocriptin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla bromocriptina"
        }]
      },
      {
        "code" : "293823004",
        "display" : "Allergy to doxepin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to doxepin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la doxépine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Doxepin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla doxepina"
        }]
      },
      {
        "code" : "293826007",
        "display" : "Allergy to nortriptyline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nortriptyline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nortriptyline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nortriptylin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nortriptilina"
        }]
      },
      {
        "code" : "293827003",
        "display" : "Allergy to trimipramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to trimipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la trimipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Trimipramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla trimipramina"
        }]
      },
      {
        "code" : "293829000",
        "display" : "Allergy to amitriptyline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amitriptyline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amitriptyline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amitriptylin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amitriptilina"
        }]
      },
      {
        "code" : "293830005",
        "display" : "Allergy to clomipramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clomipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la clomipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clomipramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clomipramina"
        }]
      },
      {
        "code" : "293833007",
        "display" : "Allergy to imipramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to imipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'imipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Imipramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’imipramina"
        }]
      },
      {
        "code" : "293840008",
        "display" : "Allergy to moclobemide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to moclobemide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au moclobémide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Moclobemid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla moclobemide"
        }]
      },
      {
        "code" : "293843005",
        "display" : "Allergy to venlafaxine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to venlafaxine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la venlafaxine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Venlafaxin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla venlafaxina"
        }]
      },
      {
        "code" : "293845003",
        "display" : "Allergy to sertraline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sertraline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la sertraline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sertralin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sertralina"
        }]
      },
      {
        "code" : "293847006",
        "display" : "Allergy to paroxetine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to paroxetine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la paroxétine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Paroxetin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla paroxetina"
        }]
      },
      {
        "code" : "293849009",
        "display" : "Allergy to citalopram (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to citalopram"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au citalopram"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Citalopram"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al citalopram"
        }]
      },
      {
        "code" : "293850009",
        "display" : "Allergy to fluoxetine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluoxetine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluoxétine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluoxetin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fluoxetina"
        }]
      },
      {
        "code" : "293851008",
        "display" : "Allergy to fluvoxamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluvoxamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluvoxamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluvoxamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fluvoxamina"
        }]
      },
      {
        "code" : "293853006",
        "display" : "Allergy to maprotiline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to maprotiline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la maprotiline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Maprotilin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla maprotilina"
        }]
      },
      {
        "code" : "293854000",
        "display" : "Allergy to mianserin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mianserin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la miansérine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mianserin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mianserina"
        }]
      },
      {
        "code" : "293855004",
        "display" : "Allergy to trazodone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to trazodone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la trazodone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Trazodon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al trazodone"
        }]
      },
      {
        "code" : "293859005",
        "display" : "Allergy to lamotrigine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lamotrigine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lamotrigine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lamotrigin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla lamotrigina"
        }]
      },
      {
        "code" : "293860000",
        "display" : "Allergy to piracetam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piracetam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au piracétam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piracetam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al piracetam"
        }]
      },
      {
        "code" : "293861001",
        "display" : "Allergy to gabapentin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gabapentin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la gabapentine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gabapentin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al gabapentin"
        }]
      },
      {
        "code" : "293865005",
        "display" : "Allergy to phenobarbital (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenobarbital"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au phénobarbital"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenobarbital"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fenobarbital"
        }]
      },
      {
        "code" : "293866006",
        "display" : "Allergy to primidone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to primidone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la primidone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Primidon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al primidone"
        }]
      },
      {
        "code" : "293867002",
        "display" : "Allergy to carbamazepine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carbamazepine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la carbamazépine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carbamazepin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carbamazepina"
        }]
      },
      {
        "code" : "293868007",
        "display" : "Allergy to vigabatrin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vigabatrin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la vigabatrine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Vigabatrin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vigabatrin"
        }]
      },
      {
        "code" : "293869004",
        "display" : "Allergy to phenytoin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenytoin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la phénytoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenytoin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fenitoina"
        }]
      },
      {
        "code" : "293870003",
        "display" : "Allergy to ethosuximide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ethosuximide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'éthosuximide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ethosuximid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’etosuccimide"
        }]
      },
      {
        "code" : "293871004",
        "display" : "Allergy to clonazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clonazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clonazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clonazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clonazepam"
        }]
      },
      {
        "code" : "293874007",
        "display" : "Allergy to zopiclone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to zopiclone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la zopiclone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Zopiclon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia allo zopiclone"
        }]
      },
      {
        "code" : "293880004",
        "display" : "Allergy to amobarbital (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amobarbital"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amobarbital"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amobarbital"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amobarbital"
        }]
      },
      {
        "code" : "293886005",
        "display" : "Allergy to flunitrazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flunitrazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flunitrazépamam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flunitrazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flunitrazepam"
        }]
      },
      {
        "code" : "293887001",
        "display" : "Allergy to flurazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flurazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flurazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flurazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flurazepam"
        }]
      },
      {
        "code" : "293889003",
        "display" : "Allergy to lormetazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lormetazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lormétazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lormetazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lormetazepam"
        }]
      },
      {
        "code" : "293890007",
        "display" : "Allergy to nitrazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nitrazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nitrazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nitrazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al nitrazepam"
        }]
      },
      {
        "code" : "293891006",
        "display" : "Allergy to triazolam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to triazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au triazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Triazolam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al triazolam"
        }]
      },
      {
        "code" : "293892004",
        "display" : "Allergy to alprazolam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to alprazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'alprazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Alprazolam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alprazolam"
        }]
      },
      {
        "code" : "293893009",
        "display" : "Allergy to bromazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bromazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bromazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bromazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al bromazepam"
        }]
      },
      {
        "code" : "293894003",
        "display" : "Allergy to chlordiazepoxide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlordiazepoxide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au chlordiazépoxide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlordiazepoxid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clordiazepossido"
        }]
      },
      {
        "code" : "293895002",
        "display" : "Allergy to clobazam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clobazam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clobazam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clobazam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clobazam"
        }]
      },
      {
        "code" : "293897005",
        "display" : "Allergy to ketazolam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ketazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au kétazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ketazolam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al ketazolam"
        }]
      },
      {
        "code" : "293899008",
        "display" : "Allergy to oxazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oxazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oxazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Oxazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’oxazepam"
        }]
      },
      {
        "code" : "293900003",
        "display" : "Allergy to prazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to prazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au prazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Prazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al prazepam"
        }]
      },
      {
        "code" : "293901004",
        "display" : "Allergy to midazolam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to midazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au midazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Midazolam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al midazolam"
        }]
      },
      {
        "code" : "293902006",
        "display" : "Allergy to diazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au diazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al diazepam"
        }]
      },
      {
        "code" : "293903001",
        "display" : "Allergy to lorazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lorazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lorazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lorazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lorazepam"
        }]
      },
      {
        "code" : "293904007",
        "display" : "Allergy to temazepam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to temazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au témazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Temazepam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al temazepam"
        }]
      },
      {
        "code" : "293906009",
        "display" : "Allergy to meprobamate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to meprobamate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au méprobamate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Meprobamat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al meprobamato"
        }]
      },
      {
        "code" : "293908005",
        "display" : "Chloral hydrate allergy",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chloral hydrate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydrate de chloral"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chloralhydrat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cloralio idrato"
        }]
      },
      {
        "code" : "293911006",
        "display" : "Allergy to buspirone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to buspirone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la buspirone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Buspiron"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al buspirone"
        }]
      },
      {
        "code" : "293912004",
        "display" : "Allergy to clomethiazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clomethiazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clométhiazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clomethiazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clometiazolo"
        }]
      },
      {
        "code" : "293914003",
        "display" : "Allergy to sulpiride (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulpiride"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au sulpiride"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulpirid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sulpiride"
        }]
      },
      {
        "code" : "293916001",
        "display" : "Allergy to clozapine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clozapine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la clozapine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clozapin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clozapina"
        }]
      },
      {
        "code" : "293917005",
        "display" : "Allergy to risperidone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to risperidone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la rispéridone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Risperidon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al risperidone"
        }]
      },
      {
        "code" : "293918000",
        "display" : "Allergy to tetrabenazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tetrabenazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tétrabénazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tetrabenazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tetrabenazina"
        }]
      },
      {
        "code" : "293920002",
        "display" : "Allergy to benperidol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to benperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au benpéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Benperidol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al benperidolo"
        }]
      },
      {
        "code" : "293923000",
        "display" : "Allergy to droperidol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to droperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au dropéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Droperidol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al droperidolo"
        }]
      },
      {
        "code" : "293924006",
        "display" : "Allergy to haloperidol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to haloperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'halopéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Haloperidol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’aloperidolo"
        }]
      },
      {
        "code" : "293927004",
        "display" : "Allergy to fluspirilene (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluspirilene"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fluspirilène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluspirilen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluspirilene"
        }]
      },
      {
        "code" : "293928009",
        "display" : "Allergy to phenothiazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenothiazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la phénothiazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenothiazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fenotiazina"
        }]
      },
      {
        "code" : "293929001",
        "display" : "Allergy to levomepromazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to levomepromazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lévomépromazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Levomepromazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla levomepromazina"
        }]
      },
      {
        "code" : "293933008",
        "display" : "Allergy to thiethylperazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiethylperazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la thiéthylpérazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiethylperazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tietilperazina"
        }]
      },
      {
        "code" : "293934002",
        "display" : "Allergy to fluphenazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluphenazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluphénazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluphenazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla flufenazina"
        }]
      },
      {
        "code" : "293935001",
        "display" : "Allergy to chlorpromazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlorpromazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la chlorpromazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlorpromazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clorpromazina"
        }]
      },
      {
        "code" : "293943006",
        "display" : "Allergy to chlorprothixene (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlorprothixene"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au chlorprothixène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlorprothixen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clorprotixene"
        }]
      },
      {
        "code" : "293946003",
        "display" : "Allergy to zuclopenthixol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to zuclopenthixol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au zuclopenthixol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Zuclopenthixol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia allo zuclopentixolo"
        }]
      },
      {
        "code" : "293948002",
        "display" : "Allergy to flupentixol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flupentixol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flupentixol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flupentixol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flupentixolo"
        }]
      },
      {
        "code" : "293955000",
        "display" : "Allergy to methylphenidate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methylphenidate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au méthylphénidate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methylphenidat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metilfenidato"
        }]
      },
      {
        "code" : "293960001",
        "display" : "Allergy to disulfiram (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to disulfiram"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au disulfirame"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Disulfiram"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al disulfiram"
        }]
      },
      {
        "code" : "293965006",
        "display" : "Allergy to atenolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to atenolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aténolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Atenolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’atenololo"
        }]
      },
      {
        "code" : "293966007",
        "display" : "Allergy to betaxolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to betaxolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bétaxolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Betaxolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al betaxololo"
        }]
      },
      {
        "code" : "293967003",
        "display" : "Allergy to bisoprolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bisoprolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bisoprolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bisoprolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al bisoprololo"
        }]
      },
      {
        "code" : "293972007",
        "display" : "Allergy to nadolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nadolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nadolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nadolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al nadololo"
        }]
      },
      {
        "code" : "293974008",
        "display" : "Allergy to carvedilol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carvedilol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au carvédilol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carvedilol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al carvedilolo"
        }]
      },
      {
        "code" : "293982008",
        "display" : "Allergy to propranolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to propranolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au propranolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Propranolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al propanololo"
        }]
      },
      {
        "code" : "293983003",
        "display" : "Allergy to sotalol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sotalol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au sotalol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sotalol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sotalolo"
        }]
      },
      {
        "code" : "293984009",
        "display" : "Allergy to timolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to timolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au timolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Timolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al timololo"
        }]
      },
      {
        "code" : "293986006",
        "display" : "Allergy to alfuzosin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to alfuzosin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'alfuzosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Alfuzosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alfuzosina"
        }]
      },
      {
        "code" : "293987002",
        "display" : "Allergy to doxazosin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to doxazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la doxazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Doxazosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla doxazosina"
        }]
      },
      {
        "code" : "293991007",
        "display" : "Allergy to prazosin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to prazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la prazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Prazosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla prazosina"
        }]
      },
      {
        "code" : "293992000",
        "display" : "Allergy to terazosin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to terazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la térazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Terazosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla terazosina"
        }]
      },
      {
        "code" : "293993005",
        "display" : "Allergy to nicotine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nicotine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nicotine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nikotin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nicotina"
        }]
      },
      {
        "code" : "293996002",
        "display" : "Allergy to nifedipine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nifedipine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nifédipine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nifedipin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nifedipina"
        }]
      },
      {
        "code" : "293998001",
        "display" : "Allergy to isradipine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to isradipine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'isradipine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Isradipin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’isradipina"
        }]
      },
      {
        "code" : "293999009",
        "display" : "Allergy to felodipine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to felodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la félodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Felodipin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla felodipina"
        }]
      },
      {
        "code" : "294001005",
        "display" : "Allergy to nimodipine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nimodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nimodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nimodipin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nimodipina"
        }]
      },
      {
        "code" : "294002003",
        "display" : "Allergy to amlodipine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amlodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amlodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amlodipin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amlodipina"
        }]
      },
      {
        "code" : "294003008",
        "display" : "Allergy to diltiazem (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diltiazem"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au diltiazem"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diltiazem"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al diltiazem"
        }]
      },
      {
        "code" : "294005001",
        "display" : "Allergy to verapamil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to verapamil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vérapamil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Verapamil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al verapamil"
        }]
      },
      {
        "code" : "294007009",
        "display" : "Allergy to pilocarpine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pilocarpine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pilocarpine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pilocarpin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pilocarpina"
        }]
      },
      {
        "code" : "294017004",
        "display" : "Allergy to neostigmine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to neostigmine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la néostigmine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Neostigmin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla neostigmina"
        }]
      },
      {
        "code" : "294028000",
        "display" : "Allergy to naphazoline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to naphazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la naphazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Naphazolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nafazolina"
        }]
      },
      {
        "code" : "294030003",
        "display" : "Allergy to phenylephrine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenylephrine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la phenylephrine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenylephrin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fenilefrina"
        }]
      },
      {
        "code" : "294036009",
        "display" : "Allergy to salmeterol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to salmeterol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au salmétérol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Salmeterol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al salmeterolo"
        }]
      },
      {
        "code" : "294039002",
        "display" : "Allergy to fenoterol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fenoterol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fénotérol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fenoterol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fenoterolo"
        }]
      },
      {
        "code" : "294047002",
        "display" : "Allergy to dobutamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dobutamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dobutamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dobutamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla dobutamina"
        }]
      },
      {
        "code" : "294050004",
        "display" : "Allergy to isoprenaline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to isoprenaline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'isoprénaline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Isoprenalin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’isoprenalina"
        }]
      },
      {
        "code" : "294055009",
        "display" : "Allergy to methyldopa (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methyldopa"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la méthyldopa"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methyldopa"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla metildopa"
        }]
      },
      {
        "code" : "294057001",
        "display" : "Allergy to apraclonidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to apraclonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'apraclonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Apraclonidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’apraclonidina"
        }]
      },
      {
        "code" : "294058006",
        "display" : "Allergy to clonidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la clonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clonidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clonidina"
        }]
      },
      {
        "code" : "294062000",
        "display" : "Allergy to ephedrine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ephedrine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'éphédrine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ephedrin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’efedrina"
        }]
      },
      {
        "code" : "294069009",
        "display" : "Allergy to biperiden (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to biperiden"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bipéridène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Biperiden"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al biperidene"
        }]
      },
      {
        "code" : "294073007",
        "display" : "Allergy to tropicamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tropicamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tropicamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tropicamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tropicamide"
        }]
      },
      {
        "code" : "294074001",
        "display" : "Allergy to scopolamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to scopolamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la scopolamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Scopolamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla scopolamina"
        }]
      },
      {
        "code" : "294076004",
        "display" : "Allergy to atropine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to atropine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'atropine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Atropin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’atropina"
        }]
      },
      {
        "code" : "294080009",
        "display" : "Allergy to glycopyrronium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to glycopyrronium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au glycopyrronium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Glycopyrronium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al glicopirronio"
        }]
      },
      {
        "code" : "294088002",
        "display" : "Allergy to oxybutynin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oxybutynin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oxybutynine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Oxybutynin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ossibutinina"
        }]
      },
      {
        "code" : "294097003",
        "display" : "Allergy to acetylcysteine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acetylcysteine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acétylcystéine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acetylcystein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acetilcisteina"
        }]
      },
      {
        "code" : "294101007",
        "display" : "Allergy to doxapram (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to doxapram"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au doxapram"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Doxapram"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al doxapram"
        }]
      },
      {
        "code" : "294112007",
        "display" : "Allergy to terfenadine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to terfenadine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la terfénadine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Terfenadin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla terfenadina"
        }]
      },
      {
        "code" : "294114008",
        "display" : "Allergy to loratadine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to loratadine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la loratadine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Loratadin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla loratadina"
        }]
      },
      {
        "code" : "294115009",
        "display" : "Allergy to azelastine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to azelastine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'azélastine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Azelastin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’azelastina"
        }]
      },
      {
        "code" : "294116005",
        "display" : "Allergy to cetirizine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cetirizine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cétirizine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cetirizin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cetirizina"
        }]
      },
      {
        "code" : "294118006",
        "display" : "Allergy to clemastine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clemastine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la clémastine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clemastin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clemastina"
        }]
      },
      {
        "code" : "294119003",
        "display" : "Allergy to mebhydrolin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mebhydrolin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mébhydroline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mebhydrolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mebidrolina"
        }]
      },
      {
        "code" : "294125004",
        "display" : "Allergy to antazoline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to antazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'antazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Antazolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’antazolina"
        }]
      },
      {
        "code" : "294126003",
        "display" : "Allergy to promethazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to promethazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la prométhazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Promethazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla prometazina"
        }]
      },
      {
        "code" : "294130000",
        "display" : "Allergy to cinnarizine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cinnarizine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cinnarizine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cinnarizin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cinnarizina"
        }]
      },
      {
        "code" : "294131001",
        "display" : "Allergy to cyproheptadine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cyproheptadine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cyproheptadine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cyproheptadin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ciproeptadina"
        }]
      },
      {
        "code" : "294132008",
        "display" : "Allergy to dimetindene (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dimetindene"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au dimétindène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dimetinden"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al dimetindene"
        }]
      },
      {
        "code" : "294133003",
        "display" : "Allergy to diphenhydramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diphenhydramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la diphénhydramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diphenhydramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla difenidramina"
        }]
      },
      {
        "code" : "294135005",
        "display" : "Allergy to hydroxyzine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hydroxyzine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydroxyzine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hydroxyzin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idrossizina"
        }]
      },
      {
        "code" : "294136006",
        "display" : "Allergy to mepyramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mepyramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mépyramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mepyramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mepiramina"
        }]
      },
      {
        "code" : "294138007",
        "display" : "Allergy to pheniramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pheniramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la phéniramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pheniramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla feniramina"
        }]
      },
      {
        "code" : "294144006",
        "display" : "Allergy to ketotifen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ketotifen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la kétotifène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ketotifen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al ketotifene"
        }]
      },
      {
        "code" : "294152009",
        "display" : "Allergy to noscapine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to noscapine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la noscapine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Noscapin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla noscapina"
        }]
      },
      {
        "code" : "294153004",
        "display" : "Allergy to pholcodine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pholcodine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pholcodine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pholcodin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla folcodina"
        }]
      },
      {
        "code" : "294157003",
        "display" : "Allergy to xanthine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to xanthine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la xanthine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Xanthin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla xantina"
        }]
      },
      {
        "code" : "294158008",
        "display" : "Allergy to aminophylline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aminophylline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aminophylline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aminophyllin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’aminofillina"
        }]
      },
      {
        "code" : "294169006",
        "display" : "Allergy to coal tar (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to coal tar"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au goudron de houille"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kohleteer"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al catrame di carbone"
        }]
      },
      {
        "code" : "294172004",
        "display" : "Allergy to bufexamac (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bufexamac"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bufexamac"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bufexamac"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al bufexamac"
        }]
      },
      {
        "code" : "294179008",
        "display" : "Sulfur allergy (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfur allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au soufre"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Schwefel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia allo zolfo"
        }]
      },
      {
        "code" : "294183008",
        "display" : "Allergy to podophyllotoxin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to podophyllotoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la podophyllotoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Podophyllotoxin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla podofillotossina"
        }]
      },
      {
        "code" : "294200004",
        "display" : "Allergy to crotamiton (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to crotamiton"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au crotamiton"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Crotamiton"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al crotamitone"
        }]
      },
      {
        "code" : "294207001",
        "display" : "Allergy to retinoid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to retinoid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux rétinoïdes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Retinoid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai retinoidi"
        }]
      },
      {
        "code" : "294209003",
        "display" : "Allergy to acitretin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acitretin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acitrétine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acitretin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acitretina"
        }]
      },
      {
        "code" : "294210008",
        "display" : "Allergy to tretinoin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tretinoin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la trétinoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tretinoin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tretinoina"
        }]
      },
      {
        "code" : "294211007",
        "display" : "Isotretinoin allergy",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to isotretinoin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'isotrétinoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Isotretinoin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’isotretinoina"
        }]
      },
      {
        "code" : "294217006",
        "display" : "Allergy to probenecid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to probenecid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au probénécide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Probenecid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al probenecid"
        }]
      },
      {
        "code" : "294220003",
        "display" : "Allergy to allopurinol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to allopurinol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'allopurinol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Allopurinol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’allopurinolo"
        }]
      },
      {
        "code" : "294224007",
        "display" : "Allergy to succinylcholine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to succinylcholine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la succinylcholine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Succinylcholin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla succinilcolina"
        }]
      },
      {
        "code" : "294226009",
        "display" : "Allergy to mivacurium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mivacurium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au mivacurium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mivacurium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mivacurio"
        }]
      },
      {
        "code" : "294228005",
        "display" : "Allergy to atracurium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to atracurium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'atracurium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Atracurium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’atracurio"
        }]
      },
      {
        "code" : "294230007",
        "display" : "Allergy to pancuronium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pancuronium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pancuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pancuronium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al pancuronio"
        }]
      },
      {
        "code" : "294232004",
        "display" : "Allergy to vecuronium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vecuronium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vécuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Vecuronium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vecuronio"
        }]
      },
      {
        "code" : "294233009",
        "display" : "Allergy to rocuronium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to rocuronium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au rocuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Rocuronium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al rocuronio"
        }]
      },
      {
        "code" : "294234003",
        "display" : "Allergy to baclofen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to baclofen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au baclofène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Baclofen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al baclofene"
        }]
      },
      {
        "code" : "294236001",
        "display" : "Allergy to methocarbamol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methocarbamol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au méthocarbamol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methocarbamol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metocarbamolo"
        }]
      },
      {
        "code" : "294237005",
        "display" : "Allergy to dantrolene (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dantrolene"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au dantrolène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dantrolen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al dantrolene"
        }]
      },
      {
        "code" : "294238000",
        "display" : "Allergy to gold (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gold"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'or"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gold"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’oro"
        }]
      },
      {
        "code" : "294242002",
        "display" : "Allergy to papaverine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to papaverine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la papavérine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Papaverin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla papaverina"
        }]
      },
      {
        "code" : "294243007",
        "display" : "Allergy to flavoxate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flavoxate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flavoxate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flavoxat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flavoxato"
        }]
      },
      {
        "code" : "294245000",
        "display" : "Allergy to mifepristone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mifepristone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mifepristone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mifepriston"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mifepristone"
        }]
      },
      {
        "code" : "294253008",
        "display" : "Allergy to dinoprostone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dinoprostone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dinoprostone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dinoproston"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al dinoprostone"
        }]
      },
      {
        "code" : "294255001",
        "display" : "Allergy to alprostadil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to alprostadil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'alprostadil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Alprostadil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alprostadil"
        }]
      },
      {
        "code" : "294269001",
        "display" : "Allergy to mesna (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mesna"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au mesna"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mesna"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mesna"
        }]
      },
      {
        "code" : "294271001",
        "display" : "Allergy to flumazenil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flumazenil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au flumazénil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flumazenil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al flumazenil"
        }]
      },
      {
        "code" : "294276006",
        "display" : "Allergy to naltrexone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to naltrexone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la naltrexone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Naltrexon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al naltrexone"
        }]
      },
      {
        "code" : "294277002",
        "display" : "Allergy to naloxone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to naloxone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la naloxone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Naloxon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al naloxone"
        }]
      },
      {
        "code" : "294278007",
        "display" : "Allergy to protamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to protamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la protamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Protamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla protamina"
        }]
      },
      {
        "code" : "294282009",
        "display" : "Allergy to chelating agent (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chelating agent"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'agent chélateur"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chelator"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ad agente chelante"
        }]
      },
      {
        "code" : "294291008",
        "display" : "Allergy to penicillamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to penicillamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pénicillamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Penicillamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla penicillamina"
        }]
      },
      {
        "code" : "294324005",
        "display" : "Allergy to paraffin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to paraffin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la paraffine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Paraffin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla paraffina"
        }]
      },
      {
        "code" : "294330005",
        "display" : "Allergy to wool alcohol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to wool alcohol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'alcool de laine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Wollwachsalkohol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli alcoli della lanolina"
        }]
      },
      {
        "code" : "294339006",
        "display" : "Allergy to carmellose (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carmellose"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la carboxyméthylcellulose"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carmellose"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al carmellosio"
        }]
      },
      {
        "code" : "294341007",
        "display" : "Allergy to flucytosine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flucytosine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la flucytosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flucytosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla flucitosina"
        }]
      },
      {
        "code" : "294342000",
        "display" : "Allergy to terbinafine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to terbinafine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la terbinafine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Terbinafin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla terbinafina"
        }]
      },
      {
        "code" : "294346002",
        "display" : "Allergy to amorolfine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amorolfine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amorolfine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amorolfin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amorolfina"
        }]
      },
      {
        "code" : "294348001",
        "display" : "Allergy to griseofulvin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to griseofulvin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la griséofulvine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Griseofulvin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla griseofulvina"
        }]
      },
      {
        "code" : "294349009",
        "display" : "Allergy to amphotericin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amphotericin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amphotéricine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amphotericin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amfotericina"
        }]
      },
      {
        "code" : "294350009",
        "display" : "Allergy to natamycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to natamycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la natamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Natamycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla natamicina"
        }]
      },
      {
        "code" : "294351008",
        "display" : "Allergy to nystatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nystatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nystatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nystatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nistatina"
        }]
      },
      {
        "code" : "294354000",
        "display" : "Allergy to undecenoate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to undecenoate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'undécénoate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Undecenoat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’undecanoato"
        }]
      },
      {
        "code" : "294356003",
        "display" : "Allergy to clotrimazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clotrimazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clotrimazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clotrimazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clotrimazolo"
        }]
      },
      {
        "code" : "294359005",
        "display" : "Allergy to econazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to econazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'éconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Econazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’econazolo"
        }]
      },
      {
        "code" : "294362008",
        "display" : "Allergy to ketoconazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ketoconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au kétoconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ketoconazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al ketoconazolo"
        }]
      },
      {
        "code" : "294363003",
        "display" : "Allergy to miconazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to miconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au miconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Miconazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al miconazolo"
        }]
      },
      {
        "code" : "294365005",
        "display" : "Allergy to fluconazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fluconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluconazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluconazolo"
        }]
      },
      {
        "code" : "294366006",
        "display" : "Allergy to itraconazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to itraconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'itraconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Itraconazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’itraconazolo"
        }]
      },
      {
        "code" : "294369004",
        "display" : "Allergy to zidovudine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to zidovudine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la zidovudine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Zidovudin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla zidovudina"
        }]
      },
      {
        "code" : "294371004",
        "display" : "Allergy to famciclovir (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to famciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au famciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Famciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al famciclovir"
        }]
      },
      {
        "code" : "294372006",
        "display" : "Allergy to didanosine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to didanosine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la didanosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Didanosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla didanosina"
        }]
      },
      {
        "code" : "294374007",
        "display" : "Allergy to valaciclovir (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to valaciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au valaciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Valaciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al valaciclovir"
        }]
      },
      {
        "code" : "294380004",
        "display" : "Allergy to ribavirin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ribavirin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la ribavirine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ribavirin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ribavirina"
        }]
      },
      {
        "code" : "294381000",
        "display" : "Allergy to trifluridine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to trifluridine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la trifluridine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Trifluridin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla trifluridina"
        }]
      },
      {
        "code" : "294382007",
        "display" : "Allergy to foscarnet (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to foscarnet"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au foscarnet"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Foscarnet"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al foscarnet"
        }]
      },
      {
        "code" : "294384008",
        "display" : "Allergy to aciclovir (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'aciclovir"
        }]
      },
      {
        "code" : "294388006",
        "display" : "Allergy to pyrimethamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pyrimethamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pyriméthamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pyrimethamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pirimetamina"
        }]
      },
      {
        "code" : "294391006",
        "display" : "Allergy to primaquine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to primaquine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la primaquine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Primaquin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla primachina"
        }]
      },
      {
        "code" : "294392004",
        "display" : "Allergy to mefloquine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mefloquine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la méfloquine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mefloquin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla meflochina"
        }]
      },
      {
        "code" : "294394003",
        "display" : "Allergy to chloroquine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chloroquine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la chloroquine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chloroquin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clorochina"
        }]
      },
      {
        "code" : "294396001",
        "display" : "Allergy to proguanil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to proguanil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au proguanil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Proguanil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al proguanil"
        }]
      },
      {
        "code" : "294398000",
        "display" : "Allergy to quinine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to quinine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la quinine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chinin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla chinina"
        }]
      },
      {
        "code" : "294407003",
        "display" : "Allergy to hexetidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hexetidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hexétidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hexetidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’esetidina"
        }]
      },
      {
        "code" : "294418003",
        "display" : "Allergy to phenol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au phénol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fenolo"
        }]
      },
      {
        "code" : "294426006",
        "display" : "Allergy to formaldehyde (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to formaldehyde"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au formaldéhyde"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Formaldehyd"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla formaldeide"
        }]
      },
      {
        "code" : "294431008",
        "display" : "Allergy to chlorhexidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlorhexidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la chlorhexidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlorhexidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clorexidina"
        }]
      },
      {
        "code" : "294438002",
        "display" : "Allergy to benzalkonium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to benzalkonium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au benzalkonium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Benzalkonium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al benzalconio"
        }]
      },
      {
        "code" : "294451007",
        "display" : "Allergy to piperazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piperazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pipérazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piperazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla piperazina"
        }]
      },
      {
        "code" : "294458001",
        "display" : "Allergy to mebendazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mebendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au mébendazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mebendazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mebendazolo"
        }]
      },
      {
        "code" : "294459009",
        "display" : "Allergy to albendazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to albendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'albendazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Albendazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’albendazolo"
        }]
      },
      {
        "code" : "294460004",
        "display" : "Allergy to tiabendazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tiabendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au thiabendazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tiabendazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tiabendazolo"
        }]
      },
      {
        "code" : "294463002",
        "display" : "Allergy to amikacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amikacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amikacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amikacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amikacina"
        }]
      },
      {
        "code" : "294466005",
        "display" : "Allergy to streptomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to streptomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la streptomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Streptomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla streptomicina"
        }]
      },
      {
        "code" : "294468006",
        "display" : "Allergy to neomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to neomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la néomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Neomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla neomicina"
        }]
      },
      {
        "code" : "294469003",
        "display" : "Allergy to gentamicin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gentamicin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la gentamicine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gentamicin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla gentamicina"
        }]
      },
      {
        "code" : "294470002",
        "display" : "Allergy to tobramycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tobramycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tobramycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tobramycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tobramicina"
        }]
      },
      {
        "code" : "294472005",
        "display" : "Allergy to azithromycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to azithromycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'azithromycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Azithromycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’azitromicina"
        }]
      },
      {
        "code" : "294475007",
        "display" : "Allergy to vancomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vancomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la vancomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Vancomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla vancomicina"
        }]
      },
      {
        "code" : "294476008",
        "display" : "Allergy to teicoplanin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to teicoplanin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la teicoplanine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Teicoplanin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla teicoplanina"
        }]
      },
      {
        "code" : "294477004",
        "display" : "Allergy to trimethoprim (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to trimethoprim"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au triméthoprime"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Trimethoprim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al trimetoprim"
        }]
      },
      {
        "code" : "294478009",
        "display" : "Allergy to nitrofurantoin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nitrofurantoin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nitrofurantoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nitrofurantoin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nitrofurantoina"
        }]
      },
      {
        "code" : "294480003",
        "display" : "Allergy to mupirocin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mupirocin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mupirocine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mupirocin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mupirocina"
        }]
      },
      {
        "code" : "294481004",
        "display" : "Allergy to nitrofural (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nitrofural"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nitrofural"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nitrofural"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al nitrofurazone"
        }]
      },
      {
        "code" : "294482006",
        "display" : "Allergy to fusidic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fusidic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide fusidique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fusidinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido fusidico"
        }]
      },
      {
        "code" : "294485008",
        "display" : "Allergy to cinoxacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cinoxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cinoxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cinoxacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cinoxacina"
        }]
      },
      {
        "code" : "294487000",
        "display" : "Allergy to ciprofloxacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ciprofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la ciprofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ciprofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ciprofloxacina"
        }]
      },
      {
        "code" : "294489002",
        "display" : "Allergy to ofloxacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'ofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ofloxacina"
        }]
      },
      {
        "code" : "294490006",
        "display" : "Allergy to norfloxacin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to norfloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la norfloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Norfloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla norfloxacina"
        }]
      },
      {
        "code" : "294497009",
        "display" : "Allergy to phenoxymethylpenicillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phenoxymethylpenicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la phénoxyméthylpénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phenoxymethylpenicillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fenossimetilpenicillina"
        }]
      },
      {
        "code" : "294499007",
        "display" : "Allergy to benzylpenicillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to benzylpenicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la benzylpénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Benzylpenicillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla benzilpenicillina"
        }]
      },
      {
        "code" : "294502006",
        "display" : "Allergy to flucloxacillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to flucloxacillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la flucloxacilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Flucloxacillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla flucloxacillina"
        }]
      },
      {
        "code" : "294505008",
        "display" : "Allergy to amoxicillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amoxicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amoxicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amoxicillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amoxicillina"
        }]
      },
      {
        "code" : "294506009",
        "display" : "Allergy to ampicillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ampicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'ampicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ampicillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ampicillina"
        }]
      },
      {
        "code" : "294514003",
        "display" : "Allergy to temocillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to temocillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la témocilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Temocillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla temocillina"
        }]
      },
      {
        "code" : "294515002",
        "display" : "Allergy to piperacillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piperacillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pipéracilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piperacillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla piperacillina"
        }]
      },
      {
        "code" : "294517005",
        "display" : "Allergy to ticarcillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ticarcillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la ticarcilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ticarcillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ticarcillina"
        }]
      },
      {
        "code" : "294529001",
        "display" : "Allergy to colistin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to colistin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la colistine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Colistin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla colistina"
        }]
      },
      {
        "code" : "294531005",
        "display" : "Allergy to carbapenem (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carbapenem"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au carbapénème"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carbapenem"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai carbapenemi"
        }]
      },
      {
        "code" : "294532003",
        "display" : "Allergy to cephalosporin antibacterial (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cephalosporin antibacterial"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la céphalosporine (antibiotique)"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cephalosporine"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle cefalosporine antibatteriche"
        }]
      },
      {
        "code" : "294537009",
        "display" : "Allergy to cefazolin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefazolin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la céfazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefazolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cefazolina"
        }]
      },
      {
        "code" : "294541008",
        "display" : "Allergy to cefaclor (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefaclor"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au céfaclor"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefaclor"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cefaclor"
        }]
      },
      {
        "code" : "294542001",
        "display" : "Allergy to cefuroxime (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefuroxime"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au céfuroxime"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefuroxim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cefuroxima"
        }]
      },
      {
        "code" : "294543006",
        "display" : "Allergy to cefamandole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefamandole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au céfamandole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefamandol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cefamandolo"
        }]
      },
      {
        "code" : "294546003",
        "display" : "Allergy to ceftazidime (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ceftazidime"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la ceftazidime"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ceftazidim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla ceftazidima"
        }]
      },
      {
        "code" : "294548002",
        "display" : "Allergy to cefixime (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefixime"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au céfixime"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefixim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cefixima"
        }]
      },
      {
        "code" : "294550005",
        "display" : "Allergy to cefpodoxime (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cefpodoxime"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au cefpodoxime"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cefpodoxim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cefpodoxima"
        }]
      },
      {
        "code" : "294551009",
        "display" : "Allergy to ceftriaxone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ceftriaxone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au ceftriaxone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ceftriaxon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al ceftriaxone"
        }]
      },
      {
        "code" : "294559006",
        "display" : "Allergy to fosfomycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fosfomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fosfomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fosfomycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fosfomicina"
        }]
      },
      {
        "code" : "294561002",
        "display" : "Allergy to clindamycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clindamycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la clindamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clindamycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clindamicina"
        }]
      },
      {
        "code" : "294564005",
        "display" : "Allergy to monobactam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to monobactam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au monobactam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Monobactam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai monobattami"
        }]
      },
      {
        "code" : "294565006",
        "display" : "Allergy to aztreonam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aztreonam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aztréonam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aztreonam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’aztreonam"
        }]
      },
      {
        "code" : "294566007",
        "display" : "Allergy to nitroimidazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nitroimidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nitro-imidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nitroimidazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai nitroimidazoli"
        }]
      },
      {
        "code" : "294567003",
        "display" : "Allergy to metronidazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to metronidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au métronidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Metronidazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metronidazolo"
        }]
      },
      {
        "code" : "294568008",
        "display" : "Allergy to tinidazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tinidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tinidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tinidazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tinidazolo"
        }]
      },
      {
        "code" : "294573002",
        "display" : "Allergy to sulfadiazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulfadiazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la sulfadiazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfadiazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sulfadiazina"
        }]
      },
      {
        "code" : "294580000",
        "display" : "Silver sulfadiazine allergy (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Silver sulfadiazine allergy"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la sulfadiazine argentique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Silbersulfadiazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sulfadiazina argentica"
        }]
      },
      {
        "code" : "294582008",
        "display" : "Allergy to sulfacetamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulfacetamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au sulfacétamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfacetamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla sulfacetamide"
        }]
      },
      {
        "code" : "294585005",
        "display" : "Allergy to doxycycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to doxycycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la doxycycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Doxycyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla doxiciclina"
        }]
      },
      {
        "code" : "294586006",
        "display" : "Allergy to lymecycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lymecycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la lymécycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lymecyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla limeciclina"
        }]
      },
      {
        "code" : "294587002",
        "display" : "Allergy to minocycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to minocycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la minocycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Minocyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla minociclina"
        }]
      },
      {
        "code" : "294588007",
        "display" : "Allergy to oxytetracycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oxytetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oxytétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Oxytetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ossitetraciclina"
        }]
      },
      {
        "code" : "294590008",
        "display" : "Allergy to chlortetracycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlortetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la chlortétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlortetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla clortetraciclina"
        }]
      },
      {
        "code" : "294591007",
        "display" : "Allergy to demeclocycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to demeclocycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la déméclocycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Demeclocyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla demeclociclina"
        }]
      },
      {
        "code" : "294592000",
        "display" : "Allergy to tetracycline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle tetracicline"
        }]
      },
      {
        "code" : "294593005",
        "display" : "Allergy to chloramphenicol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chloramphenicol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au chloramphénicol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chloramphenicol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cloramfenicolo"
        }]
      },
      {
        "code" : "294596002",
        "display" : "Allergy to atovaquone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to atovaquone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'atovaquone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Atovaquon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’atovaquone"
        }]
      },
      {
        "code" : "294600007",
        "display" : "Allergy to pentamidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pentamidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pentamidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pentamidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pentamidina"
        }]
      },
      {
        "code" : "294604003",
        "display" : "Allergy to clioquinol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clioquinol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clioquinol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clioquinol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cliochinolo"
        }]
      },
      {
        "code" : "294607005",
        "display" : "Allergy to pyrazinamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pyrazinamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pyrazinamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pyrazinamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pirazinamide"
        }]
      },
      {
        "code" : "294610003",
        "display" : "Allergy to cycloserine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cycloserine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cyclosérine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cycloserin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cicloserina"
        }]
      },
      {
        "code" : "294611004",
        "display" : "Allergy to rifampicin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to rifampicin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la rifampicine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Rifampicin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla rifampicina"
        }]
      },
      {
        "code" : "294612006",
        "display" : "Allergy to rifabutin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to rifabutin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la rifabutine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Rifabutin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla rifabutina"
        }]
      },
      {
        "code" : "294614007",
        "display" : "Allergy to isoniazid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to isoniazid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'isoniazide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Isoniazid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’isoniazide"
        }]
      },
      {
        "code" : "294615008",
        "display" : "Allergy to ethambutol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ethambutol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'éthambutol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ethambutol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’etambutolo"
        }]
      },
      {
        "code" : "294617000",
        "display" : "Allergy to dapsone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dapsone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dapsone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dapson"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al dapsone"
        }]
      },
      {
        "code" : "294621007",
        "display" : "Allergy to sulfiram (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulfiram"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au sulfiram"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfiram"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sulfiram"
        }]
      },
      {
        "code" : "294625003",
        "display" : "Allergy to lindane (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lindane"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lindane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lindan"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lindano"
        }]
      },
      {
        "code" : "294630004",
        "display" : "Allergy to permethrin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to permethrin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la perméthrine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Permethrin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla permetrina"
        }]
      },
      {
        "code" : "294639003",
        "display" : "Allergy to Varicella-zoster virus antibody (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Varicella-zoster virus antibody"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'immunoglobuline antivirus varicella-zoster"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Varizella-Zoster-Virus-Antikörper"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli anticorpi contro il virus varicella-zoster"
        }]
      },
      {
        "code" : "294642009",
        "display" : "Allergy to vaccine product containing Corynebacterium diphtheriae antigen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vaccine product containing Corynebacterium diphtheriae antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin antidiphtérique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Impfstoffprodukt mit Corynebacterium diphtheriae-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia a vaccini contenenti antigeni di Corynebacterium diphtheriae"
        }]
      },
      {
        "code" : "294646007",
        "display" : "Allergy to Hepatitis B virus vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Hepatitis B virus vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre l'hépatite B"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Hepatitis-B-Virus-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro il virus dell’epatite B"
        }]
      },
      {
        "code" : "294651001",
        "display" : "Allergy to pertussis vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pertussis vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre la coqueluche"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Keuchhusten-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro la pertosse"
        }]
      },
      {
        "code" : "294652008",
        "display" : "Allergy to pneumococcal vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pneumococcal vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre les pneumocoques"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Pneumokokken-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro gli pneumococchi"
        }]
      },
      {
        "code" : "294654009",
        "display" : "Allergy to Poliovirus vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Poliovirus vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre la poliomyélite"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Poliovirus-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro la poliomielite"
        }]
      },
      {
        "code" : "294655005",
        "display" : "Allergy to Rabies vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Rabies vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre la rage"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Tollwut-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro la rabbia"
        }]
      },
      {
        "code" : "294656006",
        "display" : "Allergy to rubella vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to rubella vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre la rubéole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Röteln-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro la rosolia"
        }]
      },
      {
        "code" : "294658007",
        "display" : "Allergy to tetanus vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tetanus vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre le tétanos"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Tetanus-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro il tetano"
        }]
      },
      {
        "code" : "294663006",
        "display" : "Allergy to Hepatitis A virus vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Hepatitis A virus vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre l'hépatite A"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den Hepatitis-A-Virus-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro il virus dell’epatite A"
        }]
      },
      {
        "code" : "294664000",
        "display" : "Allergy to Haemophilus influenzae type b vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Haemophilus influenzae type b vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre Haemophilus influenzae de type B"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen den  Haemophilus influenzae B-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro l’Haemophilus influenzae di tipo B"
        }]
      },
      {
        "code" : "294671005",
        "display" : "Allergy to glucagon (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to glucagon"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au glucagon"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Glucagon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al glucagone"
        }]
      },
      {
        "code" : "294674002",
        "display" : "Allergy to carbimazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carbimazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au carbimazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carbimazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al carbimazolo"
        }]
      },
      {
        "code" : "294676000",
        "display" : "Allergy to propylthiouracil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to propylthiouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au propylthiouracile"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Propylthiouracil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al propiltiouracile"
        }]
      },
      {
        "code" : "294678004",
        "display" : "Allergy to betamethasone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to betamethasone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la bétaméthasone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Betamethason"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al betametasone"
        }]
      },
      {
        "code" : "294679007",
        "display" : "Hydrocortisone allergy",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to methylprednisolone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la méthylprednisolone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Methylprednisolon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metilprednisolone"
        }]
      },
      {
        "code" : "294682002",
        "display" : "Allergy to prednisone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to prednisone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la prednisone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Prednison"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al prednisone"
        }]
      },
      {
        "code" : "294683007",
        "display" : "Allergy to fluorometholone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluorometholone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluorométholone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluorometholon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluorometolone"
        }]
      },
      {
        "code" : "294685000",
        "display" : "Allergy to desonide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to desonide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au désonide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Desonid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla desonide"
        }]
      },
      {
        "code" : "294687008",
        "display" : "Allergy to fluocinonide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluocinonide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fluocinonide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluocinonid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluocinonide"
        }]
      },
      {
        "code" : "294690002",
        "display" : "Allergy to halcinonide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to halcinonide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'halcinonide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Halcinonid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alcinonide"
        }]
      },
      {
        "code" : "294692005",
        "display" : "Allergy to beclometasone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to beclometasone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la béclométasone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Beclometason"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al beclometasone"
        }]
      },
      {
        "code" : "294693000",
        "display" : "Allergy to clobetasol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clobetasol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clobétasol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clobetasol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clobetasolo"
        }]
      },
      {
        "code" : "294698009",
        "display" : "Allergy to fludrocortisone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fludrocortisone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fludrocortisone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fludrocortison"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fludrocortisone"
        }]
      },
      {
        "code" : "294700000",
        "display" : "Allergy to fluticasone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluticasone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluticasone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluticason"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluticasone"
        }]
      },
      {
        "code" : "294701001",
        "display" : "Allergy to mometasone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mometasone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mométasone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mometason"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mometasone"
        }]
      },
      {
        "code" : "294702008",
        "display" : "Allergy to dexamethasone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dexamethasone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dexaméthasone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dexamethason"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al desametasone"
        }]
      },
      {
        "code" : "294707002",
        "display" : "Allergy to prednisolone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to prednisolone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la prednisolone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Prednisolon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al prednisolone"
        }]
      },
      {
        "code" : "294711008",
        "display" : "Allergy to triamcinolone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to triamcinolone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la triamcinolone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Triamcinolon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al triamcinolone"
        }]
      },
      {
        "code" : "294712001",
        "display" : "Allergy to budesonide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to budesonide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la budésonide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Budesonid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla budesonide"
        }]
      },
      {
        "code" : "294714000",
        "display" : "Allergy to insulin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to insulin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'insuline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Insulin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’insulina"
        }]
      },
      {
        "code" : "294731007",
        "display" : "Allergy to glibenclamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to glibenclamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au glibenclamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Glibenclamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla glibenclamide"
        }]
      },
      {
        "code" : "294732000",
        "display" : "Allergy to glibornuride (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to glibornuride"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au glibornuride"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Glibornurid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla glibornuride"
        }]
      },
      {
        "code" : "294733005",
        "display" : "Allergy to gliclazide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gliclazide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au gliclazide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gliclazid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla gliclazide"
        }]
      },
      {
        "code" : "294740006",
        "display" : "Allergy to metformin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to metformin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la metformine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Metformin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla metformina"
        }]
      },
      {
        "code" : "294747009",
        "display" : "Allergy to dydrogesterone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dydrogesterone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dydrogestérone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dydrogesteron"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al didrogesterone"
        }]
      },
      {
        "code" : "294752004",
        "display" : "Allergy to norethisterone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to norethisterone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la noréthistérone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Norethisteron"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al noretisterone"
        }]
      },
      {
        "code" : "294754003",
        "display" : "Allergy to levonorgestrel (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to levonorgestrel"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au lévonorgestrel"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Levonorgestrel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al levonorgestrel"
        }]
      },
      {
        "code" : "294758000",
        "display" : "Allergy to tibolone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tibolone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tibolone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tibolon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tibolone"
        }]
      },
      {
        "code" : "294764007",
        "display" : "Allergy to danazol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to danazol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au danazol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Danazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al danazolo"
        }]
      },
      {
        "code" : "294767000",
        "display" : "Allergy to finasteride (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to finasteride"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au finastéride"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Finasterid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla finasteride"
        }]
      },
      {
        "code" : "294769002",
        "display" : "Allergy to bicalutamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bicalutamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bicalutamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bicalutamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla bicalutamide"
        }]
      },
      {
        "code" : "294773004",
        "display" : "Allergy to androgen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to androgen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au traitement antiandrogène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Androgen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli androgeni"
        }]
      },
      {
        "code" : "294776007",
        "display" : "Allergy to testosterone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to testosterone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la testostérone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Testosteron"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al testosterone"
        }]
      },
      {
        "code" : "294781003",
        "display" : "Allergy to estrogen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to estrogen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux œstrogènes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Östrogen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli estrogeni"
        }]
      },
      {
        "code" : "294782005",
        "display" : "Allergy to estradiol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to estradiol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'estradiol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Östradiol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’estradiolo"
        }]
      },
      {
        "code" : "294794001",
        "display" : "Allergy to estriol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to estriol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'estriol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Östriol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’estriolo"
        }]
      },
      {
        "code" : "294798003",
        "display" : "Allergy to clomifene (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clomifene"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clomifène"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clomifen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clomifene"
        }]
      },
      {
        "code" : "294800005",
        "display" : "Allergy to cabergoline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cabergoline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cabergoline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cabergolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cabergolina"
        }]
      },
      {
        "code" : "294807008",
        "display" : "Allergy to desmopressin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to desmopressin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la desmopressine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Desmopressin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla desmopressina"
        }]
      },
      {
        "code" : "294809006",
        "display" : "Allergy to terlipressin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to terlipressin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la terlipressine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Terlipressin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla terlipressina"
        }]
      },
      {
        "code" : "294810001",
        "display" : "Allergy to antidiuretic hormone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to antidiuretic hormone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hormone antidiurétique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen das antidiuretische Hormon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ormone antidiuretico"
        }]
      },
      {
        "code" : "294815006",
        "display" : "Allergy to gonadorelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gonadorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la gonadoréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gonadorelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla gonadorelina"
        }]
      },
      {
        "code" : "294816007",
        "display" : "Allergy to nafarelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nafarelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nafaréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nafarelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nafarelina"
        }]
      },
      {
        "code" : "294817003",
        "display" : "Allergy to buserelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to buserelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la buséréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Buserelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla buserelina"
        }]
      },
      {
        "code" : "294819000",
        "display" : "Allergy to triptorelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to triptorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la triptoréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Triptorelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla triptorelina"
        }]
      },
      {
        "code" : "294821005",
        "display" : "Allergy to leuprorelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to leuprorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la leuproréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Leuprorelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla leuprorelina"
        }]
      },
      {
        "code" : "294823008",
        "display" : "Allergy to oxytocin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oxytocin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'oxytocine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Oxytocin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’ossitocina"
        }]
      },
      {
        "code" : "294825001",
        "display" : "Somatrophic hormone allergy",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to somatropin hormone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la somatropine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Somatotropin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla somatropina"
        }]
      },
      {
        "code" : "294826000",
        "display" : "Allergy to octreotide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to octreotide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'octréotide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Octreotid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’octreotide"
        }]
      },
      {
        "code" : "294829007",
        "display" : "Allergy to protirelin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to protirelin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la protiréline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Protirelin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla protirelina"
        }]
      },
      {
        "code" : "294833000",
        "display" : "Allergy to bisphosphonate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bisphosphonate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux bisphosphonates"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bisphosphonat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai bifosfonati"
        }]
      },
      {
        "code" : "294839001",
        "display" : "Allergy to calcitonin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to calcitonin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la calcitonine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Calcitonin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla calcitonina"
        }]
      },
      {
        "code" : "294840004",
        "display" : "Allergy to salmon calcitonin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to salmon calcitonin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la calcitonine de saumon"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Calcitonin vom Lachs"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla calcitonina di salmone"
        }]
      },
      {
        "code" : "294844008",
        "display" : "Allergy to epoetin alfa (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to epoetin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'époétine alpha"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Epoetin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’epoetina alfa"
        }]
      },
      {
        "code" : "294845009",
        "display" : "Allergy to epoetin beta (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to epoetin beta"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'époétine bêta"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Epoetin beta"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’epoetina beta"
        }]
      },
      {
        "code" : "294872001",
        "display" : "Allergy to heparin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to heparin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'héparine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Heparin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’eparina"
        }]
      },
      {
        "code" : "294873006",
        "display" : "Allergy to enoxaparin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to enoxaparin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'énoxaparine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Enoxaparin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’enoxaparina"
        }]
      },
      {
        "code" : "294874000",
        "display" : "Allergy to dalteparin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dalteparin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la daltéparine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dalteparin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla dalteparina"
        }]
      },
      {
        "code" : "294876003",
        "display" : "Allergy to heparinoid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to heparinoid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'héparinoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Heparinoid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’eparinoide"
        }]
      },
      {
        "code" : "294881007",
        "display" : "Allergy to warfarin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to warfarin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la warfarine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Warfarin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al warfarin"
        }]
      },
      {
        "code" : "294887006",
        "display" : "Allergy to tranexamic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tranexamic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide tranexamique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tranexamsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido tranexamico"
        }]
      },
      {
        "code" : "294889009",
        "display" : "Allergy to aprotinin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aprotinin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'aprotinine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aprotinin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’aprotinina"
        }]
      },
      {
        "code" : "294913003",
        "display" : "Allergy to iodine compound (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to iodine compound"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux composés de l'iode"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Jodverbindungen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai composti dello iodio"
        }]
      },
      {
        "code" : "294923007",
        "display" : "Allergy to retinol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to retinol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la vitamine A"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Retinol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al retinolo"
        }]
      },
      {
        "code" : "294933004",
        "display" : "Allergy to hydroxocobalamin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hydroxocobalamin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydroxocobalamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hydroxocobalamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idrossicobalamina"
        }]
      },
      {
        "code" : "294934005",
        "display" : "Allergy to cyanocobalamin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cyanocobalamin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cyanocobalamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cyanocobalamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla cianocobalamina"
        }]
      },
      {
        "code" : "294940003",
        "display" : "Allergy to ascorbic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to ascorbic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide ascorbique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Ascorbinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido ascorbico"
        }]
      },
      {
        "code" : "294951003",
        "display" : "Allergy to fluoride (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluoride"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fluoride"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluorid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fluoruro"
        }]
      },
      {
        "code" : "294956008",
        "display" : "Allergy to gemfibrozil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to gemfibrozil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au gemfibrozil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gemfibrozil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al gemfibrozil"
        }]
      },
      {
        "code" : "294958009",
        "display" : "Allergy to acipimox (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acipimox"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acipimox"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acipimox"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acipimox"
        }]
      },
      {
        "code" : "294962003",
        "display" : "Allergy to colestyramine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to colestyramine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la cholestyramine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Colestyramin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla colestiramina"
        }]
      },
      {
        "code" : "294964002",
        "display" : "Allergy to bezafibrate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bezafibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bézafibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bezafibrat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al bezafibrato"
        }]
      },
      {
        "code" : "294965001",
        "display" : "Allergy to clofibrate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clofibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au clofibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Clofibrat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clofibrato"
        }]
      },
      {
        "code" : "294966000",
        "display" : "Allergy to fenofibrate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fenofibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fénofibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fenofibrat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fenofibrato"
        }]
      },
      {
        "code" : "294971007",
        "display" : "Allergy to simvastatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to simvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la simvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Simvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla simvastatina"
        }]
      },
      {
        "code" : "294972000",
        "display" : "Allergy to fluvastatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fluvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la fluvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fluvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla fluvastatina"
        }]
      },
      {
        "code" : "294973005",
        "display" : "Allergy to pravastatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pravastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pravastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pravastatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pravastatina"
        }]
      },
      {
        "code" : "294975003",
        "display" : "Allergy to adenosine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to adenosine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'adénosine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Adenosin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’adenosina"
        }]
      },
      {
        "code" : "294977006",
        "display" : "Allergy to disopyramide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to disopyramide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au disopyramide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Disopyramid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla disopiramide"
        }]
      },
      {
        "code" : "294980007",
        "display" : "Allergy to mexiletine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mexiletine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la mexilétine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mexiletin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mexiletina"
        }]
      },
      {
        "code" : "294982004",
        "display" : "Allergy to procainamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to procainamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au procaïnamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Procainamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla procainamide"
        }]
      },
      {
        "code" : "294995009",
        "display" : "Allergy to hydrochlorothiazide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hydrochlorothiazide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydrochlorothiazide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hydrochlorothiazid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idroclorotiazide"
        }]
      },
      {
        "code" : "295000003",
        "display" : "Allergy to furosemide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to furosemide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au furosémide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Furosemid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla furosemide"
        }]
      },
      {
        "code" : "295003001",
        "display" : "Allergy to piretanide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piretanide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pirétanide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piretanid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al piretanide"
        }]
      },
      {
        "code" : "295004007",
        "display" : "Allergy to torasemide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to torasemide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la torasémide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Torasemid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla torasemide"
        }]
      },
      {
        "code" : "295008005",
        "display" : "Allergy to potassium canrenoate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to potassium canrenoate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au canrénoate de potassium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kaliumcanrenoat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al potassio canrenoato"
        }]
      },
      {
        "code" : "295009002",
        "display" : "Allergy to spironolactone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to spironolactone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la spironolactone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Spironolacton"
        },
        {
          "language" : "it-CH",
          "value" : "allergia allo spironolattone"
        }]
      },
      {
        "code" : "295010007",
        "display" : "Allergy to amiloride (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amiloride"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amiloride"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amilorid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amiloride"
        }]
      },
      {
        "code" : "295019008",
        "display" : "Allergy to mannitol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mannitol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au mannitol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mannitol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mannitolo"
        }]
      },
      {
        "code" : "295023000",
        "display" : "Allergy to chlortalidone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chlortalidone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la chlortalidone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Chlortalidon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al clortalidone"
        }]
      },
      {
        "code" : "295024006",
        "display" : "Allergy to indapamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to indapamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allerge à l'indapamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Indapamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’indapamide"
        }]
      },
      {
        "code" : "295026008",
        "display" : "Allergy to metolazone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to metolazone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la métolazone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Metolazon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metolazone"
        }]
      },
      {
        "code" : "295030006",
        "display" : "Allergy to acetazolamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acetazolamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acétazolamide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acetazolamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acetazolamide"
        }]
      },
      {
        "code" : "295054001",
        "display" : "Allergy to digoxin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to digoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la digoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Digoxin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla digossina"
        }]
      },
      {
        "code" : "295055000",
        "display" : "Allergy to digitoxin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to digitoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la digitoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Digitoxin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla digitossina"
        }]
      },
      {
        "code" : "295059006",
        "display" : "Allergy to phosphodiesterase inhibitor (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to phosphodiesterase inhibitor"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux inhibiteurs de phosphodiestérase"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Phosphodiesterasehemmer"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli inibitori della fosfodiesterasi"
        }]
      },
      {
        "code" : "295062009",
        "display" : "Allergy to milrinone (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to milrinone"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la milrinone"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Milrinon"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al milrinone"
        }]
      },
      {
        "code" : "295071000",
        "display" : "Allergy to minoxidil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to minoxidil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au minoxidil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Minoxidil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al minoxidil"
        }]
      },
      {
        "code" : "295074008",
        "display" : "Allergy to diazoxide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to diazoxide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au diazoxide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Diazoxid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al diazossido"
        }]
      },
      {
        "code" : "295075009",
        "display" : "Allergy to hydralazine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hydralazine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'hydralazine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hydralazin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’idralazina"
        }]
      },
      {
        "code" : "295079003",
        "display" : "Allergy to glyceryl trinitrate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to glyceryl trinitrate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la nitroglycérine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Glycerintrinitrat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nitroglicerina"
        }]
      },
      {
        "code" : "295108008",
        "display" : "Allergy to streptokinase (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to streptokinase"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la streptokinase"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Streptokinase"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla streptochinasi"
        }]
      },
      {
        "code" : "295109000",
        "display" : "Allergy to urokinase (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to urokinase"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'urokinase"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Urokinase"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’urochinasi"
        }]
      },
      {
        "code" : "295110005",
        "display" : "Allergy to alteplase (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to alteplase"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'altéplase"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Alteplase"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’alteplase"
        }]
      },
      {
        "code" : "295111009",
        "display" : "Allergy to anistreplase (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to anistreplase"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'anistreplase"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Anistreplase"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’anistreplase"
        }]
      },
      {
        "code" : "295112002",
        "display" : "Allergy to bromelains (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bromelains"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux bromélaïnes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bromelain"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla bromelina"
        }]
      },
      {
        "code" : "300910009",
        "display" : "Allergy to pollen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pollen"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pollen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai pollini"
        }]
      },
      {
        "code" : "300912001",
        "display" : "Allergy to chocolate (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chocolate"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au chocolat"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Schokolade"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cioccolato"
        }]
      },
      {
        "code" : "417532002",
        "display" : "Allergy to fish (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fish"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au poisson"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Fisch"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al pesce"
        }]
      },
      {
        "code" : "417918006",
        "display" : "Allergy to pork (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pork"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au porc"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Schweinefleisch"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carne di maiale"
        }]
      },
      {
        "code" : "418085001",
        "display" : "Allergy to citrus fruit (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to citrus fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au citron"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Zitrusfrüchte"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli agrumi"
        }]
      },
      {
        "code" : "418689008",
        "display" : "Allergy to grass pollen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to grass pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pollen de graminées"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gräserpollen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai pollini di graminacee"
        }]
      },
      {
        "code" : "418779002",
        "display" : "Allergy to tomato (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tomato"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la tomate"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tomate"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al pomodoro"
        }]
      },
      {
        "code" : "419263009",
        "display" : "Allergy to tree pollen (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tree pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au pollen d' arbres"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Baumpollen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai pollini di alberi"
        }]
      },
      {
        "code" : "419412007",
        "display" : "Allergy to rubber (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to rubber"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au caoutchouc"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gummi"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al lattice"
        }]
      },
      {
        "code" : "419573007",
        "display" : "Allergy to corn (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to corn"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au maïs"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mais"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al mais"
        }]
      },
      {
        "code" : "419619007",
        "display" : "Allergy to potato (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to potato"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pomme de terre"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kartoffeln"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla patata"
        }]
      },
      {
        "code" : "419788000",
        "display" : "Allergy to nickel (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nickel"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nickel"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nickel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al nichel"
        }]
      },
      {
        "code" : "419972009",
        "display" : "Allergy to shrimp (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to shrimp"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux crevettes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Shrimps"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai gamberetti"
        }]
      },
      {
        "code" : "420080006",
        "display" : "Allergy to carrot (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carrot"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la carotte"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Karotten"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carota"
        }]
      },
      {
        "code" : "420174000",
        "display" : "Allergy to wheat (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to wheat"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au blé"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Weizen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al grano"
        }]
      },
      {
        "code" : "423058007",
        "display" : "Allergy to wasp venom (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to wasp venom"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au venin de guêpe"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Wespengift"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al veleno di vespa"
        }]
      },
      {
        "code" : "424213003",
        "display" : "Allergy to bee venom (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bee venom"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au venin d'abeille"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bienengift"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al veleno di ape"
        }]
      },
      {
        "code" : "441954006",
        "display" : "Allergy to sevoflurane (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sevoflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la sévoflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sevofluran"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sevoflurano"
        }]
      },
      {
        "code" : "441955007",
        "display" : "Allergy to sufentanil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sufentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au sufentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sufentanil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sufentanil"
        }]
      },
      {
        "code" : "441992007",
        "display" : "Allergy to remifentanil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to remifentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au rémifentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Remifentanil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al remifentanil"
        }]
      },
      {
        "code" : "448438007",
        "display" : "Allergy to cisatracurium (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cisatracurium"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au cisatracurium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cisatracurium"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al cisatracurio"
        }]
      },
      {
        "code" : "450767000",
        "display" : "Allergy to tramadol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tramadol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tramadol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Tramadol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tramadolo"
        }]
      },
      {
        "code" : "473077006",
        "display" : "Allergy to teriparatide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to teriparatide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au tériparatide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Teriparatid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al teriparatide"
        }]
      },
      {
        "code" : "609409007",
        "display" : "Pseudoallergic reaction caused by sulfite (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pseudoallergic reaction caused by sulfite"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction pseudo-allergique aux sulfites"
        },
        {
          "language" : "de-CH",
          "value" : "Pseudoallergische Reaktion, verursacht durch Sulfit"
        },
        {
          "language" : "it-CH",
          "value" : "reazione pseudoallergica causata da solfiti"
        }]
      },
      {
        "code" : "609534005",
        "display" : "Non-allergic hypersensitivity to losartan (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "hypersensibilité non allergique au losartan"
        },
        {
          "language" : "fr-CH",
          "value" : "Non-allergic hypersensitivity to losartan"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Losartan"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al losartan"
        }]
      },
      {
        "code" : "609536007",
        "display" : "Non-allergic hypersensitivity to dextran (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to dextran"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au dextran"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Dextran"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al destrano"
        }]
      },
      {
        "code" : "609538008",
        "display" : "Non-allergic hypersensitivity to captopril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to captopril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au captopril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Captopril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al captopril"
        }]
      },
      {
        "code" : "609539000",
        "display" : "Non-allergic hypersensitivity to cilazapril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to cilazapril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au cilazapril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Cilazapril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al cilazapril"
        }]
      },
      {
        "code" : "609540003",
        "display" : "Non-allergic hypersensitivity to enalapril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to enalapril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique à l'enalapril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Enalapril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica all’enalapril"
        }]
      },
      {
        "code" : "609541004",
        "display" : "Non-allergic hypersensitivity to fosinopril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to fosinopril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au forsinopril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Fosinopril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al fosinopril"
        }]
      },
      {
        "code" : "609542006",
        "display" : "Non-allergic hypersensitivity to lisinopril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to lisinopril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au lisinopril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Lisinopril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al lisinopril"
        }]
      },
      {
        "code" : "609543001",
        "display" : "Non-allergic hypersensitivity to perindopril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to perindopril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au perindopril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Perindopril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al perindopril"
        }]
      },
      {
        "code" : "609544007",
        "display" : "Non-allergic hypersensitivity to quinapril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to quinapril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au quinapril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Quinapril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al quinapril"
        }]
      },
      {
        "code" : "609545008",
        "display" : "Non-allergic hypersensitivity to ramipril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to ramipril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au ramipril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Ramipril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al ramipril"
        }]
      },
      {
        "code" : "609546009",
        "display" : "Non-allergic hypersensitivity to trandolapril (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to trandolapril"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique au trandolapril"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Trandolapril"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al trandolapril"
        }]
      },
      {
        "code" : "609548005",
        "display" : "Non-allergic hypersensitivity to aspartame (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to aspartame"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique à l'aspartame"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Aspartam"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica all’aspartame"
        }]
      },
      {
        "code" : "700468006",
        "display" : "Allergy to Rotavirus vaccine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Rotavirus vaccine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au vaccin contre le rotavirus"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Rotavirus-Impfstoff"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al vaccino contro i rotavirus"
        }]
      },
      {
        "code" : "703076003",
        "display" : "Non-allergic hypersensitivity to benzoic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to benzoic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensibilité non allergique à l'acide benzoïque"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Benzoesäure"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica all’acido benzoico"
        }]
      },
      {
        "code" : "703930000",
        "display" : "Allergy to beef (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to beef"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au bœuf"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Rindfleisch"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carne di manzo"
        }]
      },
      {
        "code" : "703932008",
        "display" : "Allergy to chicken meat (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to chicken meat"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la viande de poulet"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pouletfleisch"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carne di pollo"
        }]
      },
      {
        "code" : "712840004",
        "display" : "Allergy to hazelnut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to hazelnut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux noisettes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Haselnüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle nocciole"
        }]
      },
      {
        "code" : "712843002",
        "display" : "Allergy to celery (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to celery"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au céleri"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sellerie"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sedano"
        }]
      },
      {
        "code" : "713018004",
        "display" : "Allergy to darunavir (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to darunavir"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au darunavir"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Darunavir"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al darunavir"
        }]
      },
      {
        "code" : "713296005",
        "display" : "Allergy to protease inhibitor (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to protease inhibitor"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux inhibiteurs de la protéase rétrovirale"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Proteasehemmer"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli inibitori della proteasi"
        }]
      },
      {
        "code" : "713707006",
        "display" : "Allergy to abacavir (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to abacavir"
        },
        {
          "language" : "fr-CH",
          "value" : "allerge à l'abacavir"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Abacavir"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'abacavir"
        }]
      },
      {
        "code" : "713725004",
        "display" : "Allergy to nevirapine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nevirapine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la névirapine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nevirapin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla nevirapina"
        }]
      },
      {
        "code" : "714332003",
        "display" : "Allergy to banana (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to banana"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la banane"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bananen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla banana"
        }]
      },
      {
        "code" : "718535005",
        "display" : "Allergy to pitavastatin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pitavastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pitavastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pitavastatin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla pitavastatina"
        }]
      },
      {
        "code" : "737493007",
        "display" : "Allergy to denosumab (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to denosumab"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au dénosumab"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Denosumab"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al denosumab"
        }]
      },
      {
        "code" : "767203005",
        "display" : "Allergy to cromoglicic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cromoglicic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide cromoglicide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cromoglicinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido cromoglicico"
        }]
      },
      {
        "code" : "767468001",
        "display" : "Allergy to pea (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pea"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux pois"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Erbsen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai piselli"
        }]
      },
      {
        "code" : "767475000",
        "display" : "Allergy to vitamin B12 and vitamin B12 derivative (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to vitamin B12 and vitamin B12 derivative"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la vitamine B12 et aux substances apparentées"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Vitamin B12 und Vitamin B12-Derivate"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla vitamina B12 e ai derivati della vitamina B12"
        }]
      },
      {
        "code" : "767478003",
        "display" : "Allergy to thiamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la thiamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla tiamina"
        }]
      },
      {
        "code" : "767479006",
        "display" : "Allergy to pyridoxine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pyridoxine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pyridoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pyridoxin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla piridossina"
        }]
      },
      {
        "code" : "772021008",
        "display" : "Allergy to nebivolol (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to nebivolol"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au nébivolol"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nebivolol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al nebivololo"
        }]
      },
      {
        "code" : "773399002",
        "display" : "Allergy to acetylcholine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to acetylcholine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acétylcholine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Acetylcholin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acetilcolina"
        }]
      },
      {
        "code" : "773427008",
        "display" : "Allergy to danaparoid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to danaparoid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au danaparoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Danaparoid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al danaparoid"
        }]
      },
      {
        "code" : "773485002",
        "display" : "Allergy to valproic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to valproic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide valproïque"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Valproinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido valproico"
        }]
      },
      {
        "code" : "773490004",
        "display" : "Allergy to dihydroergotamine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to dihydroergotamine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la dihydroergotamine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dihydroergotamin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla diidroergotamina"
        }]
      },
      {
        "code" : "773491000",
        "display" : "Allergy to pamidronic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pamidronic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'acide pamidronique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Pamidronat"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’acido pamidronico"
        }]
      },
      {
        "code" : "773505002",
        "display" : "Allergy to propamidine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to propamidine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la propamidine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Propamidin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla propamidina"
        }]
      },
      {
        "code" : "77560002",
        "display" : "Contact dermatitis caused by adhesive plaster (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Contact dermatitis caused by adhesive plaster"
        },
        {
          "language" : "fr-CH",
          "value" : "dermatite de contact due aux pansements adhésifs"
        },
        {
          "language" : "de-CH",
          "value" : "Kontaktdermatitis, verursacht durch Heftpflaster"
        },
        {
          "language" : "it-CH",
          "value" : "dermatite da contatto causata da cerotto adesivo"
        }]
      },
      {
        "code" : "782415009",
        "display" : "Intolerance to lactose (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Intolerance to lactose"
        },
        {
          "language" : "fr-CH",
          "value" : "intolérance au lactose"
        },
        {
          "language" : "de-CH",
          "value" : "Laktoseintoleranz"
        },
        {
          "language" : "it-CH",
          "value" : "intolleranza al lattosio"
        }]
      },
      {
        "code" : "782529008",
        "display" : "Allergy to digitalis glycoside (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to digitalis glycoside"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au glucoside digitalique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Digitalisglykosid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai glicosidi digitalici"
        }]
      },
      {
        "code" : "782563005",
        "display" : "Allergy to lithium compound (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lithium compound"
        },
        {
          "language" : "fr-CH",
          "value" : "Allergie au composé de lithium"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lithiumverbindungen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai composti del litio"
        }]
      },
      {
        "code" : "782575000",
        "display" : "Allergy to lupine seed (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lupine seed"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux graines de lupin"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Lupinensamen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai semi di lupino"
        }]
      },
      {
        "code" : "782595006",
        "display" : "Allergy to thiouracil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au thiouracil"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiouracil"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al tiouracile"
        }]
      },
      {
        "code" : "78373000",
        "display" : "Sucrase-isomaltase deficiency (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sucrase-isomaltase deficiency"
        },
        {
          "language" : "fr-CH",
          "value" : "déficit en sucrase-isomaltase"
        },
        {
          "language" : "de-CH",
          "value" : "Sucrase-Isomaltase-Mangel"
        },
        {
          "language" : "it-CH",
          "value" : "deficit di sucrasi-isomaltasi"
        }]
      },
      {
        "code" : "830080006",
        "display" : "Allergy to zinc and zinc compound (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to zinc and zinc compound"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au zinc et à ses composés"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Zink und Zinkverbindungen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia allo zinco e ai composti dello zinco"
        }]
      },
      {
        "code" : "830171008",
        "display" : "Allergy to meclozine (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to meclozine"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la méclozine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Meclozin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla meclozina"
        }]
      },
      {
        "code" : "830172001",
        "display" : "Allergy to metamizole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to metamizole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au métamizole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Metamizol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al metamizolo"
        }]
      },
      {
        "code" : "860604008",
        "display" : "Allergy to apple (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to apple"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux pommes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Äpfel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla mela"
        }]
      },
      {
        "code" : "860764004",
        "display" : "Allergy to triazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to triazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au triazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Triazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai triazoli"
        }]
      },
      {
        "code" : "860775000",
        "display" : "Allergy to imidazole (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to imidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'imidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Imidazol"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'imidazolo"
        }]
      },
      {
        "code" : "870712009",
        "display" : "Allergy to piperacillin and/or tazobactam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to piperacillin and/or tazobactam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pipéracilline et/ou au tazobactam"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Piperacillin und/oder Tazobactam"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla piperacillina e/o al tazobactam"
        }]
      },
      {
        "code" : "870714005",
        "display" : "Allergy to sulfamethoxazole and/or trimethoprim (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "allergie au sulfaméthoxazole et/ou au triméthoprime"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie to sulfamethoxazole and/or trimethoprim"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfamethoxazol und/oder Trimethoprim"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al sulfametossazolo e/o al trimetoprim"
        }]
      },
      {
        "code" : "870731003",
        "display" : "Allergy to carbidopa and/or levodopa (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to carbidopa and/or levodopa"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la carbidopa et/ou à la levodopa"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Carbidopa und/oder Levodopa"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla carbidopa e/o alla levodopa"
        }]
      },
      {
        "code" : "870749003",
        "display" : "Allergic contact dermatitis caused by usnic acid (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergic contact dermatitis caused by usnic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "dermatite de contact allergique due à l'acide usnique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergische Kontaktdermatitis, verursacht durch Usninsäure"
        },
        {
          "language" : "it-CH",
          "value" : "dermatite allergica da contatto causata da acido usnico"
        }]
      },
      {
        "code" : "871508005",
        "display" : "Allergy to amoxicillin and/or clavulanic acid (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to amoxicillin and/or clavulanic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'amoxicilline et/ou à l'acide clavulanique"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Amoxicillin und/oder Clavulansäure"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’amoxicillina e/o all'acido clavulanico"
        }]
      },
      {
        "code" : "91931000",
        "display" : "Allergy to erythromycin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to erythromycin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'érythromycine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Erythromycin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'eritromicina"
        }]
      },
      {
        "code" : "91935009",
        "display" : "Allergy to peanut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to peanut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux arachides"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Erdnüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle arachidi"
        }]
      },
      {
        "code" : "91936005",
        "display" : "Allergy to penicillin (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to penicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la pénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Penicillin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla penicillina"
        }]
      },
      {
        "code" : "91938006",
        "display" : "Allergy to strawberry (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to strawberry"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux fraises"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Erdbeeren"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle fragole"
        }]
      },
      {
        "code" : "91939003",
        "display" : "Allergy to sulfonamide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to sulfonamide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux sulfamides"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Sulfonamid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai sulfamidici"
        }]
      },
      {
        "code" : "91940001",
        "display" : "Allergy to walnut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to walnut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux noix"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Walnüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle noci"
        }]
      },
      {
        "code" : "294031004",
        "display" : "Allergy to xylometazoline (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to xylometazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à la xylométazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Xylometazolin"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla xilometazolina"
        }]
      },
      {
        "code" : "860765003",
        "display" : "Allergy to thiazide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to thiazide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux thiazidiques"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Thiazid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai tiazidici"
        }]
      },
      {
        "code" : "860907004",
        "display" : "Allergy to macrolide (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to macrolide"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux macrolides"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Makrolid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai macrolidi"
        }]
      },
      {
        "code" : "294462007",
        "display" : "Allergy to aminoglycoside (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to aminoglycoside"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux aminosides"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Aminoglykosid"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli aminoglicosidi"
        }]
      },
      {
        "code" : "292937002",
        "display" : "Vancomycin adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vancomycin adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la vancomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Vancomycin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla vancomicina"
        }]
      },
      {
        "code" : "292691002",
        "display" : "Vecuronium adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vecuronium adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable au vécuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Vecuronium"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al vecuronio"
        }]
      },
      {
        "code" : "269722001",
        "display" : "Adverse reaction caused by salicylate (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adverse reaction caused by salicylate"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable au salicylate"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Salicylat"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa causata da salicilati"
        }]
      },
      {
        "code" : "292044008",
        "display" : "Aspirin adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aspirin adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à l'aspirine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Aspirin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa all’aspirina"
        }]
      },
      {
        "code" : "292118005",
        "display" : "Mesalazine adverse reaction",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mesalazine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la mésalazine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Mesalazin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla mesalazina"
        }]
      },
      {
        "code" : "292054007",
        "display" : "Buprenorphine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buprenorphine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la buprénorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Buprenorphin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla buprenorfina"
        }]
      },
      {
        "code" : "292066001",
        "display" : "Meptazinol adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meptazinol adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable au meptazinol"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Meptazinol"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al meptazinolo"
        }]
      },
      {
        "code" : "292052006",
        "display" : "Methadone adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methadone adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la méthadone"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Methadon"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al metadone"
        }]
      },
      {
        "code" : "292046005",
        "display" : "Pentazocine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentazocine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la pentazocine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Pentazocin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla pentazocina"
        }]
      },
      {
        "code" : "292055008",
        "display" : "Codeine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Codeine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la codéine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Kodein"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla codeina"
        }]
      },
      {
        "code" : "292056009",
        "display" : "Diamorphine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diamorphine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la diamorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Diamorphin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla diamorfina"
        }]
      },
      {
        "code" : "292059002",
        "display" : "Morphine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Morphine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la morphine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Morphin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla morfina"
        }]
      },
      {
        "code" : "292058005",
        "display" : "Nalbuphine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nalbuphine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la nalbuphine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Nalbuphin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla nalbufina"
        }]
      },
      {
        "code" : "292738000",
        "display" : "Naloxone adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naloxone adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la naloxone"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Naloxon"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al naloxone"
        }]
      },
      {
        "code" : "292737005",
        "display" : "Naltrexone adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naltrexone adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable au naltrexone"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Naltrexon"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al naltrexone"
        }]
      },
      {
        "code" : "292610002",
        "display" : "Pholcodine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pholcodine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la pholcodine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Pholcodin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla folcodina"
        }]
      },
      {
        "code" : "292062004",
        "display" : "Alfentanil adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alfentanil adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à l'alfentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Alfentanil"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa all’alfentanil"
        }]
      },
      {
        "code" : "292063009",
        "display" : "Fentanyl adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fentanyl adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable au fentanyl"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Fentanyl"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa al fentanyl"
        }]
      },
      {
        "code" : "292064003",
        "display" : "Pethidine adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pethidine adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable à la péthidine"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von Pethidin"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa alla petidina"
        }]
      },
      {
        "code" : "703933003",
        "display" : "Allergy to Dermatophagoides pteronyssinus protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Dermatophagoides pteronyssinus protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux protéines de Dermatophagoïdes pteronyssinus"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dermatophagoides pteronyssinus-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine di Dermatophagoides pteronyssinus"
        }]
      },
      {
        "code" : "703902000",
        "display" : "Allergy to Dermatophagoides farinae protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Dermatophagoides farinae protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux protéines de Dermatophagoïdes farinae"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Dermatophagoides farinae-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine di Dermatophagoides farinae"
        }]
      },
      {
        "code" : "1003755004",
        "display" : "Allergy to Hevea brasiliensis latex protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Hevea brasiliensis latex protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux protéines du latex de l'Hevea brasiliensis"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hevea brasiliensis-Latexprotein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine del lattice di Hevea brasiliensis"
        }]
      },
      {
        "code" : "232346004",
        "display" : "Allergy to cat dander (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cat dander"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux phanères de chat"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hautschuppen der Katze"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al pelo di gatto"
        }]
      },
      {
        "code" : "712841000",
        "display" : "Allergy to barley (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to barley"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'orge"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Gerste"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’orzo"
        }]
      },
      {
        "code" : "419342009",
        "display" : "Allergy to oat (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oat"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'avoine"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hafer"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’avena"
        }]
      },
      {
        "code" : "418626004",
        "display" : "Allergy to lobster (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to lobster"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au homard"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hummer"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all'astice"
        }]
      },
      {
        "code" : "409136006",
        "display" : "Allergy to pulse vegetable (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to pulse vegetable"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux légumineuses"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Hülsenfrüchte"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle leguminose"
        }]
      },
      {
        "code" : "294317009",
        "display" : "Allergy to Arachis oil (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to Arachis oil"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie à l'huile d'arachide"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Arachisöl"
        },
        {
          "language" : "it-CH",
          "value" : "allergia all’olio di semi di arachide"
        }]
      },
      {
        "code" : "767470005",
        "display" : "Allergy to fenugreek (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to fenugreek"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au fenugrec"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bockshornklee"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al fieno greco"
        }]
      },
      {
        "code" : "703925004",
        "display" : "Allergy to bean (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to bean"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux fèves"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Bohnen"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai fagioli"
        }]
      },
      {
        "code" : "48821000119104",
        "display" : "Allergy to tree nut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to tree nut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux fruits à coque"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Baumnüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alla frutta a guscio"
        }]
      },
      {
        "code" : "712839001",
        "display" : "Allergy to almond (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to almond"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux amandes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Mandeln"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle mandorle"
        }]
      },
      {
        "code" : "712838009",
        "display" : "Allergy to cashew nut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cashew nut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux noix de cajou"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Cashewnüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia agli anacardi"
        }]
      },
      {
        "code" : "712844008",
        "display" : "Allergy to macadamia nut (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to macadamia nut"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux noix de macadamia"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Nacadamianüsse"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle noci di macadamia"
        }]
      },
      {
        "code" : "712842007",
        "display" : "Allergy to mollusk (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mollusk"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux mollusques"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Weichtiere"
        },
        {
          "language" : "it-CH",
          "value" : "allergia ai molluschi"
        }]
      },
      {
        "code" : "703911000",
        "display" : "Allergy to clam (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to clam"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux palourdes"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Venusmuscheln"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle vongole"
        }]
      },
      {
        "code" : "12921000122102",
        "display" : "Allergy to mussel (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to mussel"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux moules"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Muscheln"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle cozze"
        }]
      },
      {
        "code" : "419967000",
        "display" : "Allergy to oyster (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to oyster"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux huîtres"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Austern"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle ostriche"
        }]
      },
      {
        "code" : "23171000122102",
        "display" : "Allergy to kiwi fruit (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to kiwi fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au kiwi"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kiwifrucht"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al kiwi"
        }]
      },
      {
        "code" : "293637006",
        "display" : "Allergy to contrast media (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to contrast media"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux produits de contraste"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "allergia a mezzo di contrasto"
        }]
      },
      {
        "code" : "609551003",
        "display" : "Non-allergic hypersensitivity to contrast media (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to contrast media"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensitivité non allergique aux produits de contraste"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica a mezzo di contrasto"
        }]
      },
      {
        "code" : "860936004",
        "display" : "Non-allergic hypersensitivity to gadolinium and gadolinium compound (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-allergic hypersensitivity to gadolinium and gadolinium compound"
        },
        {
          "language" : "fr-CH",
          "value" : "hypersensitivité non allergique au gadolinium et à ses composés"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-allergische Überempfindlichkeit gegenüber Gadolinium und Gadoliniumverbindungen"
        },
        {
          "language" : "it-CH",
          "value" : "ipersensibilità non allergica al gadolinio e ai composti del gadolinio"
        }]
      },
      {
        "code" : "292097002",
        "display" : "Magnetic resonance imaging contrast media adverse reaction (disorder)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Magnetic resonance imaging contrast media adverse reaction"
        },
        {
          "language" : "fr-CH",
          "value" : "réaction indésirable aux produits de contraste de l'imagerie par résonance magnétique"
        },
        {
          "language" : "de-CH",
          "value" : "Nebenwirkung von MRT-Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "reazione avversa a mezzo di contrasto della tomografia a risonanza magnetica"
        }]
      },
      {
        "code" : "16224591000119103",
        "display" : "Allergy to honey bee venom (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to honey bee venom"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie au venin d'abeilles domestiques"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Honigbienengift"
        },
        {
          "language" : "it-CH",
          "value" : "allergia al veleno di ape"
        }]
      },
      {
        "code" : "782555009",
        "display" : "Allergy to cow's milk protein (finding)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allergy to cow's milk protein"
        },
        {
          "language" : "fr-CH",
          "value" : "allergie aux protéines de lait de vache"
        },
        {
          "language" : "de-CH",
          "value" : "Allergie gegen Kuhmilchprotein"
        },
        {
          "language" : "it-CH",
          "value" : "allergia alle proteine del latte vaccino"
        }]
      },
      {
        "code" : "259496005",
        "display" : "5-aminolevulinic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "5-aminolevulinic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide 5-aminolévulinique"
        },
        {
          "language" : "de-CH",
          "value" : "5-Aminolevulinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido 5-aminolevulinico"
        }]
      },
      {
        "code" : "387005008",
        "display" : "Abacavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Abacavir"
        },
        {
          "language" : "fr-CH",
          "value" : "abacavir"
        },
        {
          "language" : "de-CH",
          "value" : "Abacavir"
        },
        {
          "language" : "it-CH",
          "value" : "abacavir"
        }]
      },
      {
        "code" : "421777009",
        "display" : "Abatacept (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Abatacept"
        },
        {
          "language" : "fr-CH",
          "value" : "abatacept"
        },
        {
          "language" : "de-CH",
          "value" : "Abatacept"
        },
        {
          "language" : "it-CH",
          "value" : "abatacept"
        }]
      },
      {
        "code" : "386951001",
        "display" : "Abciximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Abciximab"
        },
        {
          "language" : "fr-CH",
          "value" : "abciximab"
        },
        {
          "language" : "de-CH",
          "value" : "Abciximab"
        },
        {
          "language" : "it-CH",
          "value" : "abciximab"
        }]
      },
      {
        "code" : "391704009",
        "display" : "Acemetacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acemetacin"
        },
        {
          "language" : "fr-CH",
          "value" : "acémétacine"
        },
        {
          "language" : "de-CH",
          "value" : "Acemetacin"
        },
        {
          "language" : "it-CH",
          "value" : "acemetacina"
        }]
      },
      {
        "code" : "372709008",
        "display" : "Acetazolamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acetazolamide"
        },
        {
          "language" : "fr-CH",
          "value" : "acétazolamide"
        },
        {
          "language" : "de-CH",
          "value" : "Acetazolamid"
        },
        {
          "language" : "it-CH",
          "value" : "acetazolamide"
        }]
      },
      {
        "code" : "387440002",
        "display" : "Acetylcysteine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acetylcysteine"
        },
        {
          "language" : "fr-CH",
          "value" : "acétylcystéine"
        },
        {
          "language" : "de-CH",
          "value" : "Acetylcystein"
        },
        {
          "language" : "it-CH",
          "value" : "acetilcisteina"
        }]
      },
      {
        "code" : "372729009",
        "display" : "Aciclovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "aciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Aciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "aciclovir"
        }]
      },
      {
        "code" : "391711008",
        "display" : "Acipimox (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acipimox"
        },
        {
          "language" : "fr-CH",
          "value" : "acipimox"
        },
        {
          "language" : "de-CH",
          "value" : "Acipimox"
        },
        {
          "language" : "it-CH",
          "value" : "acipimox"
        }]
      },
      {
        "code" : "386938006",
        "display" : "Acitretin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acitretin"
        },
        {
          "language" : "fr-CH",
          "value" : "acitrétine"
        },
        {
          "language" : "de-CH",
          "value" : "Acitretin"
        },
        {
          "language" : "it-CH",
          "value" : "acitretina"
        }]
      },
      {
        "code" : "407317001",
        "display" : "Adalimumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adalimumab"
        },
        {
          "language" : "fr-CH",
          "value" : "adalimumab"
        },
        {
          "language" : "de-CH",
          "value" : "Adalimumab"
        },
        {
          "language" : "it-CH",
          "value" : "adalimumab"
        }]
      },
      {
        "code" : "386934008",
        "display" : "Adapalene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adapalene"
        },
        {
          "language" : "fr-CH",
          "value" : "adapalène"
        },
        {
          "language" : "de-CH",
          "value" : "Adapalen"
        },
        {
          "language" : "it-CH",
          "value" : "adapalene"
        }]
      },
      {
        "code" : "412072006",
        "display" : "Adefovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adefovir"
        },
        {
          "language" : "fr-CH",
          "value" : "adéfovir"
        },
        {
          "language" : "de-CH",
          "value" : "Adefovir"
        },
        {
          "language" : "it-CH",
          "value" : "adefovir"
        }]
      },
      {
        "code" : "35431001",
        "display" : "Adenosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adenosine"
        },
        {
          "language" : "fr-CH",
          "value" : "adénosine"
        },
        {
          "language" : "de-CH",
          "value" : "Adenosin"
        },
        {
          "language" : "it-CH",
          "value" : "adenosina"
        }]
      },
      {
        "code" : "703579002",
        "display" : "Afatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Afatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "afatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Afatinib"
        },
        {
          "language" : "it-CH",
          "value" : "afatinib"
        }]
      },
      {
        "code" : "424905009",
        "display" : "Agalsidase alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Agalsidase alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "agalsidase alfa"
        },
        {
          "language" : "de-CH",
          "value" : "Agalsidase alfa"
        },
        {
          "language" : "it-CH",
          "value" : "agalsidasi alfa"
        }]
      },
      {
        "code" : "424725004",
        "display" : "Agalsidase beta (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Agalsidase beta"
        },
        {
          "language" : "fr-CH",
          "value" : "agalsidase bêta"
        },
        {
          "language" : "de-CH",
          "value" : "Agalsidase beta"
        },
        {
          "language" : "it-CH",
          "value" : "agalsidasi beta"
        }]
      },
      {
        "code" : "698012009",
        "display" : "Agomelatine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Agomelatine"
        },
        {
          "language" : "fr-CH",
          "value" : "agomélatine"
        },
        {
          "language" : "de-CH",
          "value" : "Agomelatin"
        },
        {
          "language" : "it-CH",
          "value" : "agomelatina"
        }]
      },
      {
        "code" : "387558006",
        "display" : "Albendazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Albendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "albendazole"
        },
        {
          "language" : "de-CH",
          "value" : "Albendazol"
        },
        {
          "language" : "it-CH",
          "value" : "albendazolo"
        }]
      },
      {
        "code" : "386917000",
        "display" : "Aldesleukin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aldesleukin"
        },
        {
          "language" : "fr-CH",
          "value" : "aldesleukine"
        },
        {
          "language" : "de-CH",
          "value" : "Aldesleukin"
        },
        {
          "language" : "it-CH",
          "value" : "aldesleuchina"
        }]
      },
      {
        "code" : "716039000",
        "display" : "Alectinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alectinib"
        },
        {
          "language" : "fr-CH",
          "value" : "alectinib"
        },
        {
          "language" : "de-CH",
          "value" : "Alectinib"
        },
        {
          "language" : "it-CH",
          "value" : "alectinib"
        }]
      },
      {
        "code" : "129472003",
        "display" : "Alemtuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alemtuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "alemtuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Alemtuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "alemtuzumab"
        }]
      },
      {
        "code" : "391730008",
        "display" : "Alendronic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alendronic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide alendronique"
        },
        {
          "language" : "de-CH",
          "value" : "Alendronsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido alendronico"
        }]
      },
      {
        "code" : "387560008",
        "display" : "Alfentanil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alfentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "alfentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Alfentanil"
        },
        {
          "language" : "it-CH",
          "value" : "alfentanil"
        }]
      },
      {
        "code" : "395954002",
        "display" : "Alfuzosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alfuzosin"
        },
        {
          "language" : "fr-CH",
          "value" : "alfuzosine"
        },
        {
          "language" : "de-CH",
          "value" : "Alfuzosin"
        },
        {
          "language" : "it-CH",
          "value" : "alfuzosina"
        }]
      },
      {
        "code" : "715186005",
        "display" : "Alirocumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alirocumab"
        },
        {
          "language" : "fr-CH",
          "value" : "alirocumab"
        },
        {
          "language" : "de-CH",
          "value" : "Alirocumab"
        },
        {
          "language" : "it-CH",
          "value" : "alirocumab"
        }]
      },
      {
        "code" : "426725002",
        "display" : "Aliskiren (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aliskiren"
        },
        {
          "language" : "fr-CH",
          "value" : "aliskirène"
        },
        {
          "language" : "de-CH",
          "value" : "Aliskiren"
        },
        {
          "language" : "it-CH",
          "value" : "aliskiren"
        }]
      },
      {
        "code" : "387135004",
        "display" : "Allopurinol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allopurinol"
        },
        {
          "language" : "fr-CH",
          "value" : "allopurinol"
        },
        {
          "language" : "de-CH",
          "value" : "Allopurinol"
        },
        {
          "language" : "it-CH",
          "value" : "allopurinolo"
        }]
      },
      {
        "code" : "363569003",
        "display" : "Almotriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Almotriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "almotriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Almotriptan"
        },
        {
          "language" : "it-CH",
          "value" : "almotriptan"
        }]
      },
      {
        "code" : "702799001",
        "display" : "Alogliptin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alogliptin"
        },
        {
          "language" : "fr-CH",
          "value" : "alogliptine"
        },
        {
          "language" : "de-CH",
          "value" : "Alogliptin"
        },
        {
          "language" : "it-CH",
          "value" : "alogliptin"
        }]
      },
      {
        "code" : "386983007",
        "display" : "Alprazolam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alprazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "alprazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Alprazolam"
        },
        {
          "language" : "it-CH",
          "value" : "alprazolam"
        }]
      },
      {
        "code" : "48988008",
        "display" : "Alprostadil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alprostadil"
        },
        {
          "language" : "fr-CH",
          "value" : "alprostadil"
        },
        {
          "language" : "de-CH",
          "value" : "Alprostadil"
        },
        {
          "language" : "it-CH",
          "value" : "alprostadil"
        }]
      },
      {
        "code" : "387152000",
        "display" : "Alteplase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alteplase"
        },
        {
          "language" : "fr-CH",
          "value" : "altéplase"
        },
        {
          "language" : "de-CH",
          "value" : "Alteplase"
        },
        {
          "language" : "it-CH",
          "value" : "alteplase"
        }]
      },
      {
        "code" : "428159003",
        "display" : "Ambrisentan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ambrisentan"
        },
        {
          "language" : "fr-CH",
          "value" : "ambrisentan"
        },
        {
          "language" : "de-CH",
          "value" : "Ambrisentan"
        },
        {
          "language" : "it-CH",
          "value" : "ambrisentan"
        }]
      },
      {
        "code" : "387266001",
        "display" : "Amikacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amikacin"
        },
        {
          "language" : "fr-CH",
          "value" : "amikacine"
        },
        {
          "language" : "de-CH",
          "value" : "Amikacin"
        },
        {
          "language" : "it-CH",
          "value" : "amikacina"
        }]
      },
      {
        "code" : "387503008",
        "display" : "Amiloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amiloride"
        },
        {
          "language" : "fr-CH",
          "value" : "amiloride"
        },
        {
          "language" : "de-CH",
          "value" : "Amilorid"
        },
        {
          "language" : "it-CH",
          "value" : "amiloride"
        }]
      },
      {
        "code" : "373508009",
        "display" : "Aminophylline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aminophylline"
        },
        {
          "language" : "fr-CH",
          "value" : "aminophylline"
        },
        {
          "language" : "de-CH",
          "value" : "Aminophyllin"
        },
        {
          "language" : "it-CH",
          "value" : "aminofillina"
        }]
      },
      {
        "code" : "391761004",
        "display" : "Amisulpride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amisulpride"
        },
        {
          "language" : "fr-CH",
          "value" : "amisulpride"
        },
        {
          "language" : "de-CH",
          "value" : "Amisulprid"
        },
        {
          "language" : "it-CH",
          "value" : "amisulpride"
        }]
      },
      {
        "code" : "372726002",
        "display" : "Amitriptyline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amitriptyline"
        },
        {
          "language" : "fr-CH",
          "value" : "amitriptyline"
        },
        {
          "language" : "de-CH",
          "value" : "Amitriptylin"
        },
        {
          "language" : "it-CH",
          "value" : "amitriptilina"
        }]
      },
      {
        "code" : "386864001",
        "display" : "Amlodipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amlodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "amlodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Amlodipin"
        },
        {
          "language" : "it-CH",
          "value" : "amlodipina"
        }]
      },
      {
        "code" : "391769002",
        "display" : "Amorolfine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amorolfine"
        },
        {
          "language" : "fr-CH",
          "value" : "amorolfine"
        },
        {
          "language" : "de-CH",
          "value" : "Amorolfin"
        },
        {
          "language" : "it-CH",
          "value" : "amorolfina"
        }]
      },
      {
        "code" : "372687004",
        "display" : "Amoxicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amoxicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "amoxicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Amoxicillin"
        },
        {
          "language" : "it-CH",
          "value" : "amoxicillina"
        }]
      },
      {
        "code" : "77703004",
        "display" : "Amphotericin B (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amphotericin B"
        },
        {
          "language" : "fr-CH",
          "value" : "amphotéricine B"
        },
        {
          "language" : "de-CH",
          "value" : "Amphotericin B"
        },
        {
          "language" : "it-CH",
          "value" : "amfotericina b"
        }]
      },
      {
        "code" : "387170002",
        "display" : "Ampicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ampicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "ampicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Ampicillin"
        },
        {
          "language" : "it-CH",
          "value" : "ampicillina"
        }]
      },
      {
        "code" : "372561005",
        "display" : "Anagrelide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anagrelide"
        },
        {
          "language" : "fr-CH",
          "value" : "anagrélide"
        },
        {
          "language" : "de-CH",
          "value" : "Anagrelid"
        },
        {
          "language" : "it-CH",
          "value" : "anagrelide"
        }]
      },
      {
        "code" : "385549000",
        "display" : "Anakinra (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anakinra"
        },
        {
          "language" : "fr-CH",
          "value" : "anakinra"
        },
        {
          "language" : "de-CH",
          "value" : "Anakinra"
        },
        {
          "language" : "it-CH",
          "value" : "anakinra"
        }]
      },
      {
        "code" : "386910003",
        "display" : "Anastrozole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anastrozole"
        },
        {
          "language" : "fr-CH",
          "value" : "anastrozole"
        },
        {
          "language" : "de-CH",
          "value" : "Anastrozol"
        },
        {
          "language" : "it-CH",
          "value" : "anastrozolo"
        }]
      },
      {
        "code" : "422157006",
        "display" : "Anidulafungin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anidulafungin"
        },
        {
          "language" : "fr-CH",
          "value" : "anidulafungine"
        },
        {
          "language" : "de-CH",
          "value" : "Anidulafungin"
        },
        {
          "language" : "it-CH",
          "value" : "anidulafungina"
        }]
      },
      {
        "code" : "373544004",
        "display" : "Antazoline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Antazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "antazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Antazolin"
        },
        {
          "language" : "it-CH",
          "value" : "antazolina"
        }]
      },
      {
        "code" : "698090000",
        "display" : "Apixaban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Apixaban"
        },
        {
          "language" : "fr-CH",
          "value" : "apixaban"
        },
        {
          "language" : "de-CH",
          "value" : "Apixaban"
        },
        {
          "language" : "it-CH",
          "value" : "apixaban"
        }]
      },
      {
        "code" : "387375001",
        "display" : "Apomorphine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Apomorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "apomorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Apomorphin"
        },
        {
          "language" : "it-CH",
          "value" : "apomorfina"
        }]
      },
      {
        "code" : "409205009",
        "display" : "Aprepitant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aprepitant"
        },
        {
          "language" : "fr-CH",
          "value" : "aprépitant"
        },
        {
          "language" : "de-CH",
          "value" : "Aprepitant"
        },
        {
          "language" : "it-CH",
          "value" : "aprepitant"
        }]
      },
      {
        "code" : "386961008",
        "display" : "Aprotinin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aprotinin"
        },
        {
          "language" : "fr-CH",
          "value" : "aprotinine"
        },
        {
          "language" : "de-CH",
          "value" : "Aprotinin"
        },
        {
          "language" : "it-CH",
          "value" : "aprotinina"
        }]
      },
      {
        "code" : "116508003",
        "display" : "Argatroban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Argatroban"
        },
        {
          "language" : "fr-CH",
          "value" : "argatroban"
        },
        {
          "language" : "de-CH",
          "value" : "Argatroban"
        },
        {
          "language" : "it-CH",
          "value" : "argatroban"
        }]
      },
      {
        "code" : "406784005",
        "display" : "Aripiprazole (substance)|",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aripiprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "aripiprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Aripiprazol"
        },
        {
          "language" : "it-CH",
          "value" : "aripirazolo"
        }]
      },
      {
        "code" : "72251000",
        "display" : "Arsenic trioxide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Arsenic trioxide"
        },
        {
          "language" : "fr-CH",
          "value" : "trioxyde d'arsenic"
        },
        {
          "language" : "de-CH",
          "value" : "Arsentrioxid"
        },
        {
          "language" : "it-CH",
          "value" : "arsenico triossido"
        }]
      },
      {
        "code" : "703107005",
        "display" : "Articaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Articaine"
        },
        {
          "language" : "fr-CH",
          "value" : "articaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Articain"
        },
        {
          "language" : "it-CH",
          "value" : "articaina"
        }]
      },
      {
        "code" : "43706004",
        "display" : "Ascorbic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ascorbic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide ascorbique (Vitamine C, E300)"
        },
        {
          "language" : "de-CH",
          "value" : "Ascorbinsäure (Vitamin C, E300)"
        },
        {
          "language" : "it-CH",
          "value" : "acido ascorbico (vitamina c, e300)"
        }]
      },
      {
        "code" : "371014004",
        "display" : "Asparaginase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Asparaginase"
        },
        {
          "language" : "fr-CH",
          "value" : "asparaginase"
        },
        {
          "language" : "de-CH",
          "value" : "Asparaginase"
        },
        {
          "language" : "it-CH",
          "value" : "asparaginasi"
        }]
      },
      {
        "code" : "387458008",
        "display" : "Aspirin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aspirin"
        },
        {
          "language" : "fr-CH",
          "value" : "acide acétylsalicylique"
        },
        {
          "language" : "de-CH",
          "value" : "Acetylsalicylsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido acetilsalicilico"
        }]
      },
      {
        "code" : "413592000",
        "display" : "Atazanavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atazanavir"
        },
        {
          "language" : "fr-CH",
          "value" : "atazanavir"
        },
        {
          "language" : "de-CH",
          "value" : "Atazanavir"
        },
        {
          "language" : "it-CH",
          "value" : "atazanavir"
        }]
      },
      {
        "code" : "387506000",
        "display" : "Atenolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atenolol"
        },
        {
          "language" : "fr-CH",
          "value" : "aténolol"
        },
        {
          "language" : "de-CH",
          "value" : "Atenolol"
        },
        {
          "language" : "it-CH",
          "value" : "atenololo"
        }]
      },
      {
        "code" : "719371003",
        "display" : "Atezolizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atezolizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "atézolizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Atezolizumab"
        },
        {
          "language" : "it-CH",
          "value" : "atezolizumab"
        }]
      },
      {
        "code" : "373444002",
        "display" : "Atorvastatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atorvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "atorvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Atorvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "atorvastatina"
        }]
      },
      {
        "code" : "391792002",
        "display" : "Atosiban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atosiban"
        },
        {
          "language" : "fr-CH",
          "value" : "atosiban"
        },
        {
          "language" : "de-CH",
          "value" : "Atosiban"
        },
        {
          "language" : "it-CH",
          "value" : "atosiban"
        }]
      },
      {
        "code" : "386899002",
        "display" : "Atovaquone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atovaquone"
        },
        {
          "language" : "fr-CH",
          "value" : "atovaquone"
        },
        {
          "language" : "de-CH",
          "value" : "Atovaquon"
        },
        {
          "language" : "it-CH",
          "value" : "atovaquone"
        }]
      },
      {
        "code" : "372835000",
        "display" : "Atracurium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atracurium"
        },
        {
          "language" : "fr-CH",
          "value" : "atracurium"
        },
        {
          "language" : "de-CH",
          "value" : "Atracurium"
        },
        {
          "language" : "it-CH",
          "value" : "atracurio"
        }]
      },
      {
        "code" : "372832002",
        "display" : "Atropine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Atropine"
        },
        {
          "language" : "fr-CH",
          "value" : "atropine"
        },
        {
          "language" : "de-CH",
          "value" : "Atropin"
        },
        {
          "language" : "it-CH",
          "value" : "atropina"
        }]
      },
      {
        "code" : "412328000",
        "display" : "Azacitidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azacitidine"
        },
        {
          "language" : "fr-CH",
          "value" : "azacitidine"
        },
        {
          "language" : "de-CH",
          "value" : "Azacitidin"
        },
        {
          "language" : "it-CH",
          "value" : "azacitidina"
        }]
      },
      {
        "code" : "372574004",
        "display" : "Azathioprine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azathioprine"
        },
        {
          "language" : "fr-CH",
          "value" : "azathioprine"
        },
        {
          "language" : "de-CH",
          "value" : "Azathioprin"
        },
        {
          "language" : "it-CH",
          "value" : "azatioprina"
        }]
      },
      {
        "code" : "372520005",
        "display" : "Azelastine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azelastine"
        },
        {
          "language" : "fr-CH",
          "value" : "azélastine"
        },
        {
          "language" : "de-CH",
          "value" : "Azelastin"
        },
        {
          "language" : "it-CH",
          "value" : "azelastina"
        }]
      },
      {
        "code" : "387531004",
        "display" : "Azithromycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azithromycin"
        },
        {
          "language" : "fr-CH",
          "value" : "azithromycine"
        },
        {
          "language" : "de-CH",
          "value" : "Azithromycin"
        },
        {
          "language" : "it-CH",
          "value" : "azitromicina"
        }]
      },
      {
        "code" : "387386004",
        "display" : "Aztreonam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aztreonam"
        },
        {
          "language" : "fr-CH",
          "value" : "aztréonam"
        },
        {
          "language" : "de-CH",
          "value" : "Aztreonam"
        },
        {
          "language" : "it-CH",
          "value" : "aztreonam"
        }]
      },
      {
        "code" : "5220000",
        "display" : "Bacitracin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bacitracin"
        },
        {
          "language" : "fr-CH",
          "value" : "bacitracine"
        },
        {
          "language" : "de-CH",
          "value" : "Bacitracin"
        },
        {
          "language" : "it-CH",
          "value" : "bacitracina"
        }]
      },
      {
        "code" : "387342009",
        "display" : "Baclofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Baclofen"
        },
        {
          "language" : "fr-CH",
          "value" : "baclofène"
        },
        {
          "language" : "de-CH",
          "value" : "Baclofen"
        },
        {
          "language" : "it-CH",
          "value" : "baclofene"
        }]
      },
      {
        "code" : "386978004",
        "display" : "Basiliximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Basiliximab"
        },
        {
          "language" : "fr-CH",
          "value" : "basiliximab"
        },
        {
          "language" : "de-CH",
          "value" : "Basiliximab"
        },
        {
          "language" : "it-CH",
          "value" : "basiliximab"
        }]
      },
      {
        "code" : "116574000",
        "display" : "Beclometasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Beclometasone"
        },
        {
          "language" : "fr-CH",
          "value" : "béclométasone"
        },
        {
          "language" : "de-CH",
          "value" : "Beclometason"
        },
        {
          "language" : "it-CH",
          "value" : "beclometasone"
        }]
      },
      {
        "code" : "449043000",
        "display" : "Belimumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Belimumab"
        },
        {
          "language" : "fr-CH",
          "value" : "bélimumab"
        },
        {
          "language" : "de-CH",
          "value" : "Belimumab"
        },
        {
          "language" : "it-CH",
          "value" : "belimumab"
        }]
      },
      {
        "code" : "387357002",
        "display" : "Benzocaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "benzocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Benzocain"
        },
        {
          "language" : "it-CH",
          "value" : "benzocaina"
        }]
      },
      {
        "code" : "421319000",
        "display" : "Benzydamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzydamine"
        },
        {
          "language" : "fr-CH",
          "value" : "benzydamine"
        },
        {
          "language" : "de-CH",
          "value" : "Benzydamin"
        },
        {
          "language" : "it-CH",
          "value" : "benzidamina"
        }]
      },
      {
        "code" : "323389000",
        "display" : "Benzylpenicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzylpenicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "benzylpénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Benzylpenicillin"
        },
        {
          "language" : "it-CH",
          "value" : "benzilpenicillina"
        }]
      },
      {
        "code" : "116571008",
        "display" : "Betamethasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Betamethasone"
        },
        {
          "language" : "fr-CH",
          "value" : "bétaméthasone"
        },
        {
          "language" : "de-CH",
          "value" : "Betamethason"
        },
        {
          "language" : "it-CH",
          "value" : "betametasone"
        }]
      },
      {
        "code" : "409276006",
        "display" : "Betaxolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Betaxolol"
        },
        {
          "language" : "fr-CH",
          "value" : "bétaxolol"
        },
        {
          "language" : "de-CH",
          "value" : "Betaxolol"
        },
        {
          "language" : "it-CH",
          "value" : "betaxololo"
        }]
      },
      {
        "code" : "409406007",
        "display" : "Bevacizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bevacizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "bévacizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Bevacizumab"
        },
        {
          "language" : "it-CH",
          "value" : "bevacizumab"
        }]
      },
      {
        "code" : "396025003",
        "display" : "Bezafibrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bezafibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "bézafibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Bezafibrat"
        },
        {
          "language" : "it-CH",
          "value" : "bezafibrato"
        }]
      },
      {
        "code" : "386908000",
        "display" : "Bicalutamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bicalutamide"
        },
        {
          "language" : "fr-CH",
          "value" : "bicalutamide"
        },
        {
          "language" : "de-CH",
          "value" : "Bicalutamid"
        },
        {
          "language" : "it-CH",
          "value" : "bicalutamide"
        }]
      },
      {
        "code" : "772193003",
        "display" : "Bictegravir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bictegravir"
        },
        {
          "language" : "fr-CH",
          "value" : "bictégravir"
        },
        {
          "language" : "de-CH",
          "value" : "Bictegravir"
        },
        {
          "language" : "it-CH",
          "value" : "bictegravir"
        }]
      },
      {
        "code" : "129492005",
        "display" : "Bimatoprost (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bimatoprost"
        },
        {
          "language" : "fr-CH",
          "value" : "bimatoprost"
        },
        {
          "language" : "de-CH",
          "value" : "Bimatoprost"
        },
        {
          "language" : "it-CH",
          "value" : "bimatoprost"
        }]
      },
      {
        "code" : "8919000",
        "display" : "Biotin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Biotin"
        },
        {
          "language" : "fr-CH",
          "value" : "biotine"
        },
        {
          "language" : "de-CH",
          "value" : "Biotin"
        },
        {
          "language" : "it-CH",
          "value" : "biotina"
        }]
      },
      {
        "code" : "387359004",
        "display" : "Biperiden (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Biperiden"
        },
        {
          "language" : "fr-CH",
          "value" : "bipéridène"
        },
        {
          "language" : "de-CH",
          "value" : "Biperiden"
        },
        {
          "language" : "it-CH",
          "value" : "biperidene"
        }]
      },
      {
        "code" : "387075009",
        "display" : "Bisacodyl (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bisacodyl"
        },
        {
          "language" : "fr-CH",
          "value" : "bisacodyl"
        },
        {
          "language" : "de-CH",
          "value" : "Bisacodyl"
        },
        {
          "language" : "it-CH",
          "value" : "bisacodile"
        }]
      },
      {
        "code" : "386868003",
        "display" : "Bisoprolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bisoprolol"
        },
        {
          "language" : "fr-CH",
          "value" : "bisoprolol"
        },
        {
          "language" : "de-CH",
          "value" : "Bisoprolol"
        },
        {
          "language" : "it-CH",
          "value" : "bisoprololo"
        }]
      },
      {
        "code" : "129498009",
        "display" : "Bivalirudin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bivalirudin"
        },
        {
          "language" : "fr-CH",
          "value" : "bivalirudine"
        },
        {
          "language" : "de-CH",
          "value" : "Bivalirudin"
        },
        {
          "language" : "it-CH",
          "value" : "bivalirudina"
        }]
      },
      {
        "code" : "372843005",
        "display" : "Bleomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bleomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "bléomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Bleomycin"
        },
        {
          "language" : "it-CH",
          "value" : "bleomicina"
        }]
      },
      {
        "code" : "407097007",
        "display" : "Bortezomib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bortezomib"
        },
        {
          "language" : "fr-CH",
          "value" : "bortézomib"
        },
        {
          "language" : "de-CH",
          "value" : "Bortezomib"
        },
        {
          "language" : "it-CH",
          "value" : "bortezomib"
        }]
      },
      {
        "code" : "385559004",
        "display" : "Bosentan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bosentan"
        },
        {
          "language" : "fr-CH",
          "value" : "bosentan"
        },
        {
          "language" : "de-CH",
          "value" : "Bosentan"
        },
        {
          "language" : "it-CH",
          "value" : "bosentan"
        }]
      },
      {
        "code" : "703128001",
        "display" : "Bosutinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bosutinib"
        },
        {
          "language" : "fr-CH",
          "value" : "bosutinib"
        },
        {
          "language" : "de-CH",
          "value" : "Bosutinib"
        },
        {
          "language" : "it-CH",
          "value" : "bosutinib"
        }]
      },
      {
        "code" : "108890005",
        "display" : "Botulinum toxin type A (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Botulinum toxin type A"
        },
        {
          "language" : "fr-CH",
          "value" : "toxine botulique de type A"
        },
        {
          "language" : "de-CH",
          "value" : "Botulinumtoxin Typ A"
        },
        {
          "language" : "it-CH",
          "value" : "tossina botulinica tipo a"
        }]
      },
      {
        "code" : "713395006",
        "display" : "Brentuximab vedotin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brentuximab vedotin"
        },
        {
          "language" : "fr-CH",
          "value" : "brentuximab védotine"
        },
        {
          "language" : "de-CH",
          "value" : "Brentuximab vedotin"
        },
        {
          "language" : "it-CH",
          "value" : "brentuximab vedotin"
        }]
      },
      {
        "code" : "716069007",
        "display" : "Brexpiprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brexpiprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "brexpiprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Brexpiprazol"
        },
        {
          "language" : "it-CH",
          "value" : "brexpiprazolo"
        }]
      },
      {
        "code" : "372547000",
        "display" : "Brimonidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brimonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "brimonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Brimonidin"
        },
        {
          "language" : "it-CH",
          "value" : "brimonidina"
        }]
      },
      {
        "code" : "386925003",
        "display" : "Brinzolamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brinzolamide"
        },
        {
          "language" : "fr-CH",
          "value" : "brinzolamide"
        },
        {
          "language" : "de-CH",
          "value" : "Brinzolamid"
        },
        {
          "language" : "it-CH",
          "value" : "brinzolamide"
        }]
      },
      {
        "code" : "420813001",
        "display" : "Brivaracetam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brivaracetam"
        },
        {
          "language" : "fr-CH",
          "value" : "brivaracétam"
        },
        {
          "language" : "de-CH",
          "value" : "Brivaracetam"
        },
        {
          "language" : "it-CH",
          "value" : "brivaracetam"
        }]
      },
      {
        "code" : "698049003",
        "display" : "Brivudine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brivudine"
        },
        {
          "language" : "fr-CH",
          "value" : "brivudine"
        },
        {
          "language" : "de-CH",
          "value" : "Brivudin"
        },
        {
          "language" : "it-CH",
          "value" : "brivudina"
        }]
      },
      {
        "code" : "387571009",
        "display" : "Bromazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bromazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "bromazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Bromazepam"
        },
        {
          "language" : "it-CH",
          "value" : "bromazepam"
        }]
      },
      {
        "code" : "108520008",
        "display" : "Bromfenac (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bromfenac"
        },
        {
          "language" : "fr-CH",
          "value" : "bromfénac"
        },
        {
          "language" : "de-CH",
          "value" : "Bromfenac"
        },
        {
          "language" : "it-CH",
          "value" : "bromfenac"
        }]
      },
      {
        "code" : "387039007",
        "display" : "Bromocriptine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bromocriptine"
        },
        {
          "language" : "fr-CH",
          "value" : "bromocriptine"
        },
        {
          "language" : "de-CH",
          "value" : "Bromocriptin"
        },
        {
          "language" : "it-CH",
          "value" : "bromocriptina"
        }]
      },
      {
        "code" : "395726003",
        "display" : "Budesonide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Budesonide"
        },
        {
          "language" : "fr-CH",
          "value" : "budésonide"
        },
        {
          "language" : "de-CH",
          "value" : "Budesonid"
        },
        {
          "language" : "it-CH",
          "value" : "budesonide"
        }]
      },
      {
        "code" : "273952005",
        "display" : "Bufexamac (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bufexamac"
        },
        {
          "language" : "fr-CH",
          "value" : "bufexamac"
        },
        {
          "language" : "de-CH",
          "value" : "Bufexamac"
        },
        {
          "language" : "it-CH",
          "value" : "bufexamac"
        }]
      },
      {
        "code" : "387150008",
        "display" : "Bupivacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bupivacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "bupivacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Bupivacain"
        },
        {
          "language" : "it-CH",
          "value" : "bupivacaina"
        }]
      },
      {
        "code" : "387173000",
        "display" : "Buprenorphine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buprenorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "buprénorphine"
        },
        {
          "language" : "de-CH",
          "value" : "Buprenorphin"
        },
        {
          "language" : "it-CH",
          "value" : "buprenorfina"
        }]
      },
      {
        "code" : "395744006",
        "display" : "Buserelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buserelin"
        },
        {
          "language" : "fr-CH",
          "value" : "buséréline"
        },
        {
          "language" : "de-CH",
          "value" : "Buserelin"
        },
        {
          "language" : "it-CH",
          "value" : "buserelina"
        }]
      },
      {
        "code" : "446706007",
        "display" : "Cabazitaxel (substance",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cabazitaxel"
        },
        {
          "language" : "fr-CH",
          "value" : "cabazitaxel"
        },
        {
          "language" : "de-CH",
          "value" : "Cabazitaxel"
        },
        {
          "language" : "it-CH",
          "value" : "cabazitaxel"
        }]
      },
      {
        "code" : "386979007",
        "display" : "Cabergoline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cabergoline"
        },
        {
          "language" : "fr-CH",
          "value" : "cabergoline"
        },
        {
          "language" : "de-CH",
          "value" : "Cabergolin"
        },
        {
          "language" : "it-CH",
          "value" : "cabergolina"
        }]
      },
      {
        "code" : "703676004",
        "display" : "Canagliflozin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Canagliflozin"
        },
        {
          "language" : "fr-CH",
          "value" : "canagliflozine"
        },
        {
          "language" : "de-CH",
          "value" : "Canagliflozin"
        },
        {
          "language" : "it-CH",
          "value" : "canagliflozin"
        }]
      },
      {
        "code" : "698091001",
        "display" : "Canakinumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Canakinumab"
        },
        {
          "language" : "fr-CH",
          "value" : "canakinumab"
        },
        {
          "language" : "de-CH",
          "value" : "Canakinumab"
        },
        {
          "language" : "it-CH",
          "value" : "canakinumab"
        }]
      },
      {
        "code" : "372512008",
        "display" : "Candesartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Candesartan"
        },
        {
          "language" : "fr-CH",
          "value" : "candésartan"
        },
        {
          "language" : "de-CH",
          "value" : "Candesartan"
        },
        {
          "language" : "it-CH",
          "value" : "candesartan"
        }]
      },
      {
        "code" : "716118009",
        "display" : "Cangrelor (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cangrelor"
        },
        {
          "language" : "fr-CH",
          "value" : "cangrélor"
        },
        {
          "language" : "de-CH",
          "value" : "Cangrelor"
        },
        {
          "language" : "it-CH",
          "value" : "cangrelor"
        }]
      },
      {
        "code" : "386906001",
        "display" : "Capecitabine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Capecitabine"
        },
        {
          "language" : "fr-CH",
          "value" : "capécitabine"
        },
        {
          "language" : "de-CH",
          "value" : "Capecitabin"
        },
        {
          "language" : "it-CH",
          "value" : "capecitabina"
        }]
      },
      {
        "code" : "95995002",
        "display" : "Capsaicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Capsaicin"
        },
        {
          "language" : "fr-CH",
          "value" : "capsaïcine"
        },
        {
          "language" : "de-CH",
          "value" : "Capsaicin"
        },
        {
          "language" : "it-CH",
          "value" : "capsaicina"
        }]
      },
      {
        "code" : "387160004",
        "display" : "Captopril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Captopril"
        },
        {
          "language" : "fr-CH",
          "value" : "captopril"
        },
        {
          "language" : "de-CH",
          "value" : "Captopril"
        },
        {
          "language" : "it-CH",
          "value" : "captopril"
        }]
      },
      {
        "code" : "387222003",
        "display" : "Carbamazepine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbamazepine"
        },
        {
          "language" : "fr-CH",
          "value" : "carbamazépine"
        },
        {
          "language" : "de-CH",
          "value" : "Carbamazepin"
        },
        {
          "language" : "it-CH",
          "value" : "carbamazepina"
        }]
      },
      {
        "code" : "425003007",
        "display" : "Carbetocin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbetocin"
        },
        {
          "language" : "fr-CH",
          "value" : "carbétocine"
        },
        {
          "language" : "de-CH",
          "value" : "Carbetocin"
        },
        {
          "language" : "it-CH",
          "value" : "carbetocina"
        }]
      },
      {
        "code" : "73579000",
        "display" : "Carbidopa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbidopa"
        },
        {
          "language" : "fr-CH",
          "value" : "carbidopa"
        },
        {
          "language" : "de-CH",
          "value" : "Carbidopa"
        },
        {
          "language" : "it-CH",
          "value" : "carbidopa"
        }]
      },
      {
        "code" : "395831005",
        "display" : "Carbimazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbimazole"
        },
        {
          "language" : "fr-CH",
          "value" : "carbimazole"
        },
        {
          "language" : "de-CH",
          "value" : "Carbimazol"
        },
        {
          "language" : "it-CH",
          "value" : "carbimazolo"
        }]
      },
      {
        "code" : "395842001",
        "display" : "Carbocisteine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbocisteine"
        },
        {
          "language" : "fr-CH",
          "value" : "carbocistéine"
        },
        {
          "language" : "de-CH",
          "value" : "Carbocistein"
        },
        {
          "language" : "it-CH",
          "value" : "carbocisteina"
        }]
      },
      {
        "code" : "386905002",
        "display" : "Carboplatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carboplatin"
        },
        {
          "language" : "fr-CH",
          "value" : "carboplatine"
        },
        {
          "language" : "de-CH",
          "value" : "Carboplatin"
        },
        {
          "language" : "it-CH",
          "value" : "carboplatino"
        }]
      },
      {
        "code" : "713463006",
        "display" : "Carfilzomib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carfilzomib"
        },
        {
          "language" : "fr-CH",
          "value" : "carfilzomib"
        },
        {
          "language" : "de-CH",
          "value" : "Carfilzomib"
        },
        {
          "language" : "it-CH",
          "value" : "carfilzomib"
        }]
      },
      {
        "code" : "715295006",
        "display" : "Cariprazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cariprazine"
        },
        {
          "language" : "fr-CH",
          "value" : "cariprazine"
        },
        {
          "language" : "de-CH",
          "value" : "Cariprazin"
        },
        {
          "language" : "it-CH",
          "value" : "cariprazina"
        }]
      },
      {
        "code" : "387281007",
        "display" : "Carmustine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carmustine"
        },
        {
          "language" : "fr-CH",
          "value" : "carmustine"
        },
        {
          "language" : "de-CH",
          "value" : "Carmustin"
        },
        {
          "language" : "it-CH",
          "value" : "carmustina"
        }]
      },
      {
        "code" : "386870007",
        "display" : "Carvedilol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carvedilol"
        },
        {
          "language" : "fr-CH",
          "value" : "carvédilol"
        },
        {
          "language" : "de-CH",
          "value" : "Carvedilol"
        },
        {
          "language" : "it-CH",
          "value" : "carvedilolo"
        }]
      },
      {
        "code" : "413770001",
        "display" : "Caspofungin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Caspofungin"
        },
        {
          "language" : "fr-CH",
          "value" : "caspofungine"
        },
        {
          "language" : "de-CH",
          "value" : "Caspofungin"
        },
        {
          "language" : "it-CH",
          "value" : "caspofungin"
        }]
      },
      {
        "code" : "387270009",
        "display" : "Cefaclor (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefaclor"
        },
        {
          "language" : "fr-CH",
          "value" : "céfaclor"
        },
        {
          "language" : "de-CH",
          "value" : "Cefaclor"
        },
        {
          "language" : "it-CH",
          "value" : "cefaclor"
        }]
      },
      {
        "code" : "387470007",
        "display" : "Cefazolin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefazolin"
        },
        {
          "language" : "fr-CH",
          "value" : "céfazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Cefazolin"
        },
        {
          "language" : "it-CH",
          "value" : "cefazolina"
        }]
      },
      {
        "code" : "96048006",
        "display" : "Cefepime (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefepime"
        },
        {
          "language" : "fr-CH",
          "value" : "céfépime"
        },
        {
          "language" : "de-CH",
          "value" : "Cefepim"
        },
        {
          "language" : "it-CH",
          "value" : "cefepime"
        }]
      },
      {
        "code" : "387534007",
        "display" : "Cefpodoxime (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefpodoxime"
        },
        {
          "language" : "fr-CH",
          "value" : "cefpodoxime"
        },
        {
          "language" : "de-CH",
          "value" : "Cefpodoxim"
        },
        {
          "language" : "it-CH",
          "value" : "cefpodoxima"
        }]
      },
      {
        "code" : "387200005",
        "display" : "Ceftazidime (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceftazidime"
        },
        {
          "language" : "fr-CH",
          "value" : "ceftazidime"
        },
        {
          "language" : "de-CH",
          "value" : "Ceftazidim"
        },
        {
          "language" : "it-CH",
          "value" : "ceftazidime"
        }]
      },
      {
        "code" : "372670001",
        "display" : "Ceftriaxone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceftriaxone"
        },
        {
          "language" : "fr-CH",
          "value" : "ceftriaxone"
        },
        {
          "language" : "de-CH",
          "value" : "Ceftriaxon"
        },
        {
          "language" : "it-CH",
          "value" : "ceftriaxone"
        }]
      },
      {
        "code" : "372833007",
        "display" : "Cefuroxime (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefuroxime"
        },
        {
          "language" : "fr-CH",
          "value" : "céfuroxime"
        },
        {
          "language" : "de-CH",
          "value" : "Cefuroxim"
        },
        {
          "language" : "it-CH",
          "value" : "cefuroxime"
        }]
      },
      {
        "code" : "116081000",
        "display" : "Celecoxib (substance",
        "designation" : [{
          "language" : "en-US",
          "value" : "Celecoxib"
        },
        {
          "language" : "fr-CH",
          "value" : "célécoxib"
        },
        {
          "language" : "de-CH",
          "value" : "Celecoxib"
        },
        {
          "language" : "it-CH",
          "value" : "celecoxib"
        }]
      },
      {
        "code" : "372523007",
        "display" : "Cetirizine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cetirizine"
        },
        {
          "language" : "fr-CH",
          "value" : "cétirizine"
        },
        {
          "language" : "de-CH",
          "value" : "Cetirizin"
        },
        {
          "language" : "it-CH",
          "value" : "cetirizina"
        }]
      },
      {
        "code" : "372777009",
        "display" : "Chloramphenicol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chloramphenicol"
        },
        {
          "language" : "fr-CH",
          "value" : "chloramphénicol"
        },
        {
          "language" : "de-CH",
          "value" : "Chloramphenicol"
        },
        {
          "language" : "it-CH",
          "value" : "cloramfenicolo"
        }]
      },
      {
        "code" : "372866006",
        "display" : "Chlordiazepoxide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlordiazepoxide"
        },
        {
          "language" : "fr-CH",
          "value" : "chlordiazépoxide"
        },
        {
          "language" : "de-CH",
          "value" : "Chlordiazepoxid"
        },
        {
          "language" : "it-CH",
          "value" : "clordiazepossido"
        }]
      },
      {
        "code" : "373568007",
        "display" : "Chlorhexidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorhexidine"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhexidine"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorhexidin"
        },
        {
          "language" : "it-CH",
          "value" : "clorexidina"
        }]
      },
      {
        "code" : "373468005",
        "display" : "Chloroquine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chloroquine"
        },
        {
          "language" : "fr-CH",
          "value" : "chloroquine"
        },
        {
          "language" : "de-CH",
          "value" : "Chloroquin"
        },
        {
          "language" : "it-CH",
          "value" : "clorochina"
        }]
      },
      {
        "code" : "387258005",
        "display" : "Chlorpromazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorpromazine"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorpromazine"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorpromazin"
        },
        {
          "language" : "it-CH",
          "value" : "clorpromazina"
        }]
      },
      {
        "code" : "387317000",
        "display" : "Chlorprothixene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorprothixene"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorprothixène"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorprothixen"
        },
        {
          "language" : "it-CH",
          "value" : "clorprotixene"
        }]
      },
      {
        "code" : "387324004",
        "display" : "Chlortalidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlortalidone"
        },
        {
          "language" : "fr-CH",
          "value" : "chlortalidone"
        },
        {
          "language" : "de-CH",
          "value" : "Chlortalidon"
        },
        {
          "language" : "it-CH",
          "value" : "clortalidone"
        }]
      },
      {
        "code" : "4104007",
        "display" : "Chondroitin sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chondroitin sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "chondroïtine sulfate"
        },
        {
          "language" : "de-CH",
          "value" : "Chondroitinsulfate-Gemisch"
        },
        {
          "language" : "it-CH",
          "value" : "condroitinsolfato"
        }]
      },
      {
        "code" : "129494006",
        "display" : "Choriogonadotropin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Choriogonadotropin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "choriogonadotropine alfa"
        },
        {
          "language" : "de-CH",
          "value" : "Choriogonadotropin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "coriogonadotropina alfa"
        }]
      },
      {
        "code" : "417420004",
        "display" : "Ciclesonide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ciclesonide"
        },
        {
          "language" : "fr-CH",
          "value" : "ciclésonide"
        },
        {
          "language" : "de-CH",
          "value" : "Ciclesonid"
        },
        {
          "language" : "it-CH",
          "value" : "ciclesonide"
        }]
      },
      {
        "code" : "372854000",
        "display" : "Ciclopirox (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ciclopirox"
        },
        {
          "language" : "fr-CH",
          "value" : "ciclopirox"
        },
        {
          "language" : "de-CH",
          "value" : "Ciclopirox"
        },
        {
          "language" : "it-CH",
          "value" : "ciclopirox"
        }]
      },
      {
        "code" : "387467008",
        "display" : "Ciclosporin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ciclosporin"
        },
        {
          "language" : "fr-CH",
          "value" : "ciclosporine"
        },
        {
          "language" : "de-CH",
          "value" : "Ciclosporin"
        },
        {
          "language" : "it-CH",
          "value" : "ciclosporina"
        }]
      },
      {
        "code" : "395947008",
        "display" : "Cilazapril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cilazapril"
        },
        {
          "language" : "fr-CH",
          "value" : "cilazapril"
        },
        {
          "language" : "de-CH",
          "value" : "Cilazapril"
        },
        {
          "language" : "it-CH",
          "value" : "cilazapril"
        }]
      },
      {
        "code" : "373541007",
        "display" : "Cimetidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cimetidine"
        },
        {
          "language" : "fr-CH",
          "value" : "cimétidine"
        },
        {
          "language" : "de-CH",
          "value" : "Cimetidin"
        },
        {
          "language" : "it-CH",
          "value" : "cimetidina"
        }]
      },
      {
        "code" : "409392004",
        "display" : "Cinacalcet (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cinacalcet"
        },
        {
          "language" : "fr-CH",
          "value" : "cinacalcet"
        },
        {
          "language" : "de-CH",
          "value" : "Cinacalcet"
        },
        {
          "language" : "it-CH",
          "value" : "cinacalcet"
        }]
      },
      {
        "code" : "395953008",
        "display" : "Cinchocaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cinchocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "cinchocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Cinchocain"
        },
        {
          "language" : "it-CH",
          "value" : "cincocaina"
        }]
      },
      {
        "code" : "395955001",
        "display" : "Cinnarizine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cinnarizine"
        },
        {
          "language" : "fr-CH",
          "value" : "cinnarizine"
        },
        {
          "language" : "de-CH",
          "value" : "Cinnarizin"
        },
        {
          "language" : "it-CH",
          "value" : "cinnarizina"
        }]
      },
      {
        "code" : "372840008",
        "display" : "Ciprofloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ciprofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "ciprofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Ciprofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "ciprofloxacina"
        }]
      },
      {
        "code" : "372495006",
        "display" : "Cisatracurium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cisatracurium"
        },
        {
          "language" : "fr-CH",
          "value" : "cisatracurium"
        },
        {
          "language" : "de-CH",
          "value" : "Cisatracurium"
        },
        {
          "language" : "it-CH",
          "value" : "cisatracurio"
        }]
      },
      {
        "code" : "387318005",
        "display" : "Cisplatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cisplatin"
        },
        {
          "language" : "fr-CH",
          "value" : "cisplatine"
        },
        {
          "language" : "de-CH",
          "value" : "Cisplatin"
        },
        {
          "language" : "it-CH",
          "value" : "cisplatino"
        }]
      },
      {
        "code" : "372596005",
        "display" : "Citalopram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Citalopram"
        },
        {
          "language" : "fr-CH",
          "value" : "citalopram"
        },
        {
          "language" : "de-CH",
          "value" : "Citalopram"
        },
        {
          "language" : "it-CH",
          "value" : "citalopram"
        }]
      },
      {
        "code" : "386916009",
        "display" : "Cladribine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cladribine"
        },
        {
          "language" : "fr-CH",
          "value" : "cladribine"
        },
        {
          "language" : "de-CH",
          "value" : "Cladribin"
        },
        {
          "language" : "it-CH",
          "value" : "cladribina"
        }]
      },
      {
        "code" : "387487009",
        "display" : "Clarithromycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clarithromycin"
        },
        {
          "language" : "fr-CH",
          "value" : "clarithromycine"
        },
        {
          "language" : "de-CH",
          "value" : "Clarithromycin"
        },
        {
          "language" : "it-CH",
          "value" : "claritromicina"
        }]
      },
      {
        "code" : "395939008",
        "display" : "Clavulanic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clavulanic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide clavulanique"
        },
        {
          "language" : "de-CH",
          "value" : "Clavulansäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido clavulanico"
        }]
      },
      {
        "code" : "372744005",
        "display" : "Clemastine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clemastine"
        },
        {
          "language" : "fr-CH",
          "value" : "clémastine"
        },
        {
          "language" : "de-CH",
          "value" : "Clemastin"
        },
        {
          "language" : "it-CH",
          "value" : "clemastina"
        }]
      },
      {
        "code" : "439471002",
        "display" : "Clevidipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clevidipine"
        },
        {
          "language" : "fr-CH",
          "value" : "clévidipine"
        },
        {
          "language" : "de-CH",
          "value" : "Clevidipin"
        },
        {
          "language" : "it-CH",
          "value" : "clevidipina"
        }]
      },
      {
        "code" : "372786004",
        "display" : "Clindamycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clindamycin"
        },
        {
          "language" : "fr-CH",
          "value" : "clindamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Clindamycin"
        },
        {
          "language" : "it-CH",
          "value" : "clindamicina"
        }]
      },
      {
        "code" : "387291001",
        "display" : "Clioquinol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clioquinol"
        },
        {
          "language" : "fr-CH",
          "value" : "clioquinol"
        },
        {
          "language" : "de-CH",
          "value" : "Clioquinol"
        },
        {
          "language" : "it-CH",
          "value" : "cliochinolo"
        }]
      },
      {
        "code" : "387572002",
        "display" : "Clobazam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clobazam"
        },
        {
          "language" : "fr-CH",
          "value" : "clobazam"
        },
        {
          "language" : "de-CH",
          "value" : "Clobazam"
        },
        {
          "language" : "it-CH",
          "value" : "clobazam"
        }]
      },
      {
        "code" : "419129004",
        "display" : "Clobetasol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clobetasol"
        },
        {
          "language" : "fr-CH",
          "value" : "clobétasol"
        },
        {
          "language" : "de-CH",
          "value" : "Clobetasol"
        },
        {
          "language" : "it-CH",
          "value" : "clobetasolo"
        }]
      },
      {
        "code" : "413873006",
        "display" : "Clofarabine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clofarabine"
        },
        {
          "language" : "fr-CH",
          "value" : "clofarabine"
        },
        {
          "language" : "de-CH",
          "value" : "Clofarabin"
        },
        {
          "language" : "it-CH",
          "value" : "clofarabina"
        }]
      },
      {
        "code" : "395978007",
        "display" : "Clomethiazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clomethiazole"
        },
        {
          "language" : "fr-CH",
          "value" : "clométhiazole"
        },
        {
          "language" : "de-CH",
          "value" : "Clomethiazol"
        },
        {
          "language" : "it-CH",
          "value" : "clometiazolo"
        }]
      },
      {
        "code" : "372903001",
        "display" : "Clomipramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clomipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "clomipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Clomipramin"
        },
        {
          "language" : "it-CH",
          "value" : "clomipramina"
        }]
      },
      {
        "code" : "387383007",
        "display" : "Clonazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clonazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "clonazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Clonazepam"
        },
        {
          "language" : "it-CH",
          "value" : "clonazepam"
        }]
      },
      {
        "code" : "372805007",
        "display" : "Clonidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "clonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Clonidin"
        },
        {
          "language" : "it-CH",
          "value" : "clonidina"
        }]
      },
      {
        "code" : "386952008",
        "display" : "Clopidogrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clopidogrel"
        },
        {
          "language" : "fr-CH",
          "value" : "clopidogrel"
        },
        {
          "language" : "de-CH",
          "value" : "Clopidogrel"
        },
        {
          "language" : "it-CH",
          "value" : "clopidogrel"
        }]
      },
      {
        "code" : "698028004",
        "display" : "Clotiapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clotiapine"
        },
        {
          "language" : "fr-CH",
          "value" : "clotiapine"
        },
        {
          "language" : "de-CH",
          "value" : "Clotiapin"
        },
        {
          "language" : "it-CH",
          "value" : "clotiapina"
        }]
      },
      {
        "code" : "387325003",
        "display" : "Clotrimazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clotrimazole"
        },
        {
          "language" : "fr-CH",
          "value" : "clotrimazole"
        },
        {
          "language" : "de-CH",
          "value" : "Clotrimazol"
        },
        {
          "language" : "it-CH",
          "value" : "clotrimazolo"
        }]
      },
      {
        "code" : "387568001",
        "display" : "Clozapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clozapine"
        },
        {
          "language" : "fr-CH",
          "value" : "clozapine"
        },
        {
          "language" : "de-CH",
          "value" : "Clozapin"
        },
        {
          "language" : "it-CH",
          "value" : "clozapina"
        }]
      },
      {
        "code" : "710109003",
        "display" : "Cobicistat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cobicistat"
        },
        {
          "language" : "fr-CH",
          "value" : "cobicistat"
        },
        {
          "language" : "de-CH",
          "value" : "Cobicistat"
        },
        {
          "language" : "it-CH",
          "value" : "cobicistat"
        }]
      },
      {
        "code" : "387494007",
        "display" : "Codeine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Codeine"
        },
        {
          "language" : "fr-CH",
          "value" : "codéine"
        },
        {
          "language" : "de-CH",
          "value" : "Codein"
        },
        {
          "language" : "it-CH",
          "value" : "codeina"
        }]
      },
      {
        "code" : "387408001",
        "display" : "Colestyramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Colestyramine"
        },
        {
          "language" : "fr-CH",
          "value" : "colestyramine"
        },
        {
          "language" : "de-CH",
          "value" : "Colestyramin"
        },
        {
          "language" : "it-CH",
          "value" : "colestiramina"
        }]
      },
      {
        "code" : "387412007",
        "display" : "Colistin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Colistin"
        },
        {
          "language" : "fr-CH",
          "value" : "colistine"
        },
        {
          "language" : "de-CH",
          "value" : "Colistin"
        },
        {
          "language" : "it-CH",
          "value" : "colistina"
        }]
      },
      {
        "code" : "372672009",
        "display" : "Cromoglicic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cromoglicic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide cromoglicique"
        },
        {
          "language" : "de-CH",
          "value" : "Cromoglicinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido cromoglicico"
        }]
      },
      {
        "code" : "419382002",
        "display" : "Cyanocobalamin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cyanocobalamin"
        },
        {
          "language" : "fr-CH",
          "value" : "cyanocobalamine (Vitamine B12)"
        },
        {
          "language" : "de-CH",
          "value" : "Cyanocobalamin (Vitamin B12)"
        },
        {
          "language" : "it-CH",
          "value" : "cianocobalamina"
        }]
      },
      {
        "code" : "387420009",
        "display" : "Cyclophosphamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cyclophosphamide"
        },
        {
          "language" : "fr-CH",
          "value" : "cyclophosphamide"
        },
        {
          "language" : "de-CH",
          "value" : "Cyclophosphamid"
        },
        {
          "language" : "it-CH",
          "value" : "ciclofosfamide"
        }]
      },
      {
        "code" : "387282000",
        "display" : "Cycloserine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cycloserine"
        },
        {
          "language" : "fr-CH",
          "value" : "cycloserine"
        },
        {
          "language" : "de-CH",
          "value" : "Cycloserin"
        },
        {
          "language" : "it-CH",
          "value" : "cicloserina"
        }]
      },
      {
        "code" : "387511003",
        "display" : "Cytarabine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cytarabine"
        },
        {
          "language" : "fr-CH",
          "value" : "cytarabine"
        },
        {
          "language" : "de-CH",
          "value" : "Cytarabin"
        },
        {
          "language" : "it-CH",
          "value" : "citarabina"
        }]
      },
      {
        "code" : "703641001",
        "display" : "Dabrafenib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dabrafenib"
        },
        {
          "language" : "fr-CH",
          "value" : "dabrafénib"
        },
        {
          "language" : "de-CH",
          "value" : "Dabrafenib"
        },
        {
          "language" : "it-CH",
          "value" : "dabrafenib"
        }]
      },
      {
        "code" : "387441003",
        "display" : "Dacarbazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dacarbazine"
        },
        {
          "language" : "fr-CH",
          "value" : "dacarbazine"
        },
        {
          "language" : "de-CH",
          "value" : "Dacarbazin"
        },
        {
          "language" : "it-CH",
          "value" : "dacarbazina"
        }]
      },
      {
        "code" : "387353003",
        "display" : "Dactinomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dactinomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "dactinomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Dactinomycin"
        },
        {
          "language" : "it-CH",
          "value" : "dactinomicina"
        }]
      },
      {
        "code" : "372564002",
        "display" : "Danaparoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Danaparoid"
        },
        {
          "language" : "fr-CH",
          "value" : "danaparoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Danaparoid"
        },
        {
          "language" : "it-CH",
          "value" : "danaparoid"
        }]
      },
      {
        "code" : "372819007",
        "display" : "Dantrolene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dantrolene"
        },
        {
          "language" : "fr-CH",
          "value" : "dantrolène"
        },
        {
          "language" : "de-CH",
          "value" : "Dantrolen"
        },
        {
          "language" : "it-CH",
          "value" : "dantrolene"
        }]
      },
      {
        "code" : "703674001",
        "display" : "Dapagliflozin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dapagliflozin"
        },
        {
          "language" : "fr-CH",
          "value" : "dapagliflozine"
        },
        {
          "language" : "de-CH",
          "value" : "Dapagliflozin"
        },
        {
          "language" : "it-CH",
          "value" : "dapagliflozin"
        }]
      },
      {
        "code" : "406439009",
        "display" : "Daptomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Daptomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "daptomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Daptomycin"
        },
        {
          "language" : "it-CH",
          "value" : "daptomicina"
        }]
      },
      {
        "code" : "385608005",
        "display" : "Darbepoetin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Darbepoetin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "darbépoétine alfa"
        },
        {
          "language" : "de-CH",
          "value" : "Darbepoetin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "darbepoetina alfa"
        }]
      },
      {
        "code" : "423888002",
        "display" : "Darunavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Darunavir"
        },
        {
          "language" : "fr-CH",
          "value" : "darunavir"
        },
        {
          "language" : "de-CH",
          "value" : "Darunavir"
        },
        {
          "language" : "it-CH",
          "value" : "darunavir"
        }]
      },
      {
        "code" : "423658008",
        "display" : "Dasatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dasatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "dasatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Dasatinib"
        },
        {
          "language" : "it-CH",
          "value" : "dasatinib"
        }]
      },
      {
        "code" : "372715008",
        "display" : "Daunorubicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Daunorubicin"
        },
        {
          "language" : "fr-CH",
          "value" : "daunorubicine"
        },
        {
          "language" : "de-CH",
          "value" : "Daunorubicin"
        },
        {
          "language" : "it-CH",
          "value" : "daunorubicina"
        }]
      },
      {
        "code" : "419985007",
        "display" : "Deferasirox (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Deferasirox"
        },
        {
          "language" : "fr-CH",
          "value" : "déférasirox"
        },
        {
          "language" : "de-CH",
          "value" : "Deferasirox"
        },
        {
          "language" : "it-CH",
          "value" : "deferasirox"
        }]
      },
      {
        "code" : "396012006",
        "display" : "Deflazacort (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Deflazacort"
        },
        {
          "language" : "fr-CH",
          "value" : "déflazacort"
        },
        {
          "language" : "de-CH",
          "value" : "Deflazacort"
        },
        {
          "language" : "it-CH",
          "value" : "deflazacort"
        }]
      },
      {
        "code" : "441864003",
        "display" : "Degarelix (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Degarelix"
        },
        {
          "language" : "fr-CH",
          "value" : "dégarélix"
        },
        {
          "language" : "de-CH",
          "value" : "Degarelix"
        },
        {
          "language" : "it-CH",
          "value" : "degarelix"
        }]
      },
      {
        "code" : "446321003",
        "display" : "Denosumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Denosumab"
        },
        {
          "language" : "fr-CH",
          "value" : "dénosumab"
        },
        {
          "language" : "de-CH",
          "value" : "Denosumab"
        },
        {
          "language" : "it-CH",
          "value" : "denosumab"
        }]
      },
      {
        "code" : "386841003",
        "display" : "Desflurane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Desflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "desflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Desfluran"
        },
        {
          "language" : "it-CH",
          "value" : "desflurano"
        }]
      },
      {
        "code" : "396015008",
        "display" : "Desloratadine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Desloratadine"
        },
        {
          "language" : "fr-CH",
          "value" : "desloratadine"
        },
        {
          "language" : "de-CH",
          "value" : "Desloratadin"
        },
        {
          "language" : "it-CH",
          "value" : "desloratadina"
        }]
      },
      {
        "code" : "126189002",
        "display" : "Desmopressin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Desmopressin"
        },
        {
          "language" : "fr-CH",
          "value" : "desmopressine"
        },
        {
          "language" : "de-CH",
          "value" : "Desmopressin"
        },
        {
          "language" : "it-CH",
          "value" : "desmopressina"
        }]
      },
      {
        "code" : "126108008",
        "display" : "Desogestrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Desogestrel"
        },
        {
          "language" : "fr-CH",
          "value" : "désogestrel"
        },
        {
          "language" : "de-CH",
          "value" : "Desogestrel"
        },
        {
          "language" : "it-CH",
          "value" : "desogestrel"
        }]
      },
      {
        "code" : "372584003",
        "display" : "Dexamethasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexamethasone"
        },
        {
          "language" : "fr-CH",
          "value" : "dexaméthasone"
        },
        {
          "language" : "de-CH",
          "value" : "Dexamethason"
        },
        {
          "language" : "it-CH",
          "value" : "desametasone"
        }]
      },
      {
        "code" : "418868002",
        "display" : "Dexibuprofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexibuprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "dexibuprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Dexibuprofen"
        },
        {
          "language" : "it-CH",
          "value" : "dexibuprofene"
        }]
      },
      {
        "code" : "396018005",
        "display" : "Dexketoprofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexketoprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "dexkétoprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Dexketoprofen"
        },
        {
          "language" : "it-CH",
          "value" : "desketoprofene"
        }]
      },
      {
        "code" : "441863009",
        "display" : "Dexlansoprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexlansoprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "dexlansoprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Dexlansoprazol"
        },
        {
          "language" : "it-CH",
          "value" : "dexlansoprazolo"
        }]
      },
      {
        "code" : "126226000",
        "display" : "Dexpanthenol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexpanthenol"
        },
        {
          "language" : "fr-CH",
          "value" : "dexpanthénol"
        },
        {
          "language" : "de-CH",
          "value" : "Dexpanthenol"
        },
        {
          "language" : "it-CH",
          "value" : "despantenolo"
        }]
      },
      {
        "code" : "108825009",
        "display" : "Dexrazoxane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dexrazoxane"
        },
        {
          "language" : "fr-CH",
          "value" : "dexrazoxane"
        },
        {
          "language" : "de-CH",
          "value" : "Dexrazoxan"
        },
        {
          "language" : "it-CH",
          "value" : "dexrazoxano"
        }]
      },
      {
        "code" : "387341002",
        "display" : "Diamorphine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diamorphine"
        },
        {
          "language" : "fr-CH",
          "value" : "héroïne"
        },
        {
          "language" : "de-CH",
          "value" : "Heroin"
        },
        {
          "language" : "it-CH",
          "value" : "eroina"
        }]
      },
      {
        "code" : "387264003",
        "display" : "Diazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "diazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Diazepam"
        },
        {
          "language" : "it-CH",
          "value" : "diazepam"
        }]
      },
      {
        "code" : "7034005",
        "display" : "Diclofenac (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diclofenac"
        },
        {
          "language" : "fr-CH",
          "value" : "diclofénac"
        },
        {
          "language" : "de-CH",
          "value" : "Diclofenac"
        },
        {
          "language" : "it-CH",
          "value" : "diclofenac"
        }]
      },
      {
        "code" : "373534001",
        "display" : "Digitoxin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Digitoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "digitoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Digitoxin"
        },
        {
          "language" : "it-CH",
          "value" : "digitossina"
        }]
      },
      {
        "code" : "387461009",
        "display" : "Digoxin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Digoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "digoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Digoxin"
        },
        {
          "language" : "it-CH",
          "value" : "digossina"
        }]
      },
      {
        "code" : "372793000",
        "display" : "Diltiazem (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diltiazem"
        },
        {
          "language" : "fr-CH",
          "value" : "diltiazem"
        },
        {
          "language" : "de-CH",
          "value" : "Diltiazem"
        },
        {
          "language" : "it-CH",
          "value" : "diltiazem"
        }]
      },
      {
        "code" : "387142004",
        "display" : "Dimetindene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dimetindene"
        },
        {
          "language" : "fr-CH",
          "value" : "dimétindène"
        },
        {
          "language" : "de-CH",
          "value" : "Dimetinden"
        },
        {
          "language" : "it-CH",
          "value" : "dimetindene"
        }]
      },
      {
        "code" : "387245009",
        "display" : "Dinoprostone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dinoprostone"
        },
        {
          "language" : "fr-CH",
          "value" : "dinoprostone"
        },
        {
          "language" : "de-CH",
          "value" : "Dinoproston"
        },
        {
          "language" : "it-CH",
          "value" : "dinoprostone"
        }]
      },
      {
        "code" : "372682005",
        "display" : "Diphenhydramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diphenhydramine"
        },
        {
          "language" : "fr-CH",
          "value" : "diphénhydramine"
        },
        {
          "language" : "de-CH",
          "value" : "Diphenhydramin"
        },
        {
          "language" : "it-CH",
          "value" : "difenidramina"
        }]
      },
      {
        "code" : "387453004",
        "display" : "Dipotassium clorazepate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dipotassium clorazepate"
        },
        {
          "language" : "fr-CH",
          "value" : "clorazépate dipotassique"
        },
        {
          "language" : "de-CH",
          "value" : "Dikalium clorazepat"
        },
        {
          "language" : "it-CH",
          "value" : "clorazepato dipotassico"
        }]
      },
      {
        "code" : "387212009",
        "display" : "Disulfiram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Disulfiram"
        },
        {
          "language" : "fr-CH",
          "value" : "disulfirame"
        },
        {
          "language" : "de-CH",
          "value" : "Disulfiram"
        },
        {
          "language" : "it-CH",
          "value" : "disulfiram"
        }]
      },
      {
        "code" : "387145002",
        "display" : "Dobutamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dobutamine"
        },
        {
          "language" : "fr-CH",
          "value" : "dobutamine"
        },
        {
          "language" : "de-CH",
          "value" : "Dobutamin"
        },
        {
          "language" : "it-CH",
          "value" : "dobutamina"
        }]
      },
      {
        "code" : "386918005",
        "display" : "Docetaxel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Docetaxel"
        },
        {
          "language" : "fr-CH",
          "value" : "docétaxel"
        },
        {
          "language" : "de-CH",
          "value" : "Docetaxel"
        },
        {
          "language" : "it-CH",
          "value" : "docetaxel"
        }]
      },
      {
        "code" : "713464000",
        "display" : "Dolutegravir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dolutegravir"
        },
        {
          "language" : "fr-CH",
          "value" : "dolutégravir"
        },
        {
          "language" : "de-CH",
          "value" : "Dolutegravir"
        },
        {
          "language" : "it-CH",
          "value" : "dolutegravir"
        }]
      },
      {
        "code" : "387181004",
        "display" : "Domperidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Domperidone"
        },
        {
          "language" : "fr-CH",
          "value" : "dompéridone"
        },
        {
          "language" : "de-CH",
          "value" : "Domperidon"
        },
        {
          "language" : "it-CH",
          "value" : "domperidone"
        }]
      },
      {
        "code" : "386855006",
        "display" : "Donepezil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Donepezil"
        },
        {
          "language" : "fr-CH",
          "value" : "donépézil"
        },
        {
          "language" : "de-CH",
          "value" : "Donepezil"
        },
        {
          "language" : "it-CH",
          "value" : "donepezil"
        }]
      },
      {
        "code" : "373447009",
        "display" : "Dorzolamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dorzolamide"
        },
        {
          "language" : "fr-CH",
          "value" : "dorzolamide"
        },
        {
          "language" : "de-CH",
          "value" : "Dorzolamid"
        },
        {
          "language" : "it-CH",
          "value" : "dorzolamide"
        }]
      },
      {
        "code" : "373339005",
        "display" : "Doxapram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Doxapram"
        },
        {
          "language" : "fr-CH",
          "value" : "doxapram"
        },
        {
          "language" : "de-CH",
          "value" : "Doxapram"
        },
        {
          "language" : "it-CH",
          "value" : "doxapram"
        }]
      },
      {
        "code" : "372508002",
        "display" : "Doxazosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Doxazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "doxazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Doxazosin"
        },
        {
          "language" : "it-CH",
          "value" : "doxazosina"
        }]
      },
      {
        "code" : "372587005",
        "display" : "Doxepin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Doxepin"
        },
        {
          "language" : "fr-CH",
          "value" : "doxépine"
        },
        {
          "language" : "de-CH",
          "value" : "Doxepin"
        },
        {
          "language" : "it-CH",
          "value" : "doxepina"
        }]
      },
      {
        "code" : "372478003",
        "display" : "Doxycycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Doxycycline"
        },
        {
          "language" : "fr-CH",
          "value" : "doxycycline"
        },
        {
          "language" : "de-CH",
          "value" : "Doxycyclin"
        },
        {
          "language" : "it-CH",
          "value" : "doxiciclina"
        }]
      },
      {
        "code" : "44068004",
        "display" : "Doxylamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Doxylamine"
        },
        {
          "language" : "fr-CH",
          "value" : "doxylamine"
        },
        {
          "language" : "de-CH",
          "value" : "Doxylamin"
        },
        {
          "language" : "it-CH",
          "value" : "doxilamina"
        }]
      },
      {
        "code" : "387146001",
        "display" : "Droperidol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Droperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "dropéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Droperidol"
        },
        {
          "language" : "it-CH",
          "value" : "droperidolo"
        }]
      },
      {
        "code" : "410919000",
        "display" : "Drospirenone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Drospirenone"
        },
        {
          "language" : "fr-CH",
          "value" : "drospirénone"
        },
        {
          "language" : "de-CH",
          "value" : "Drospirenon"
        },
        {
          "language" : "it-CH",
          "value" : "drospirenone"
        }]
      },
      {
        "code" : "385572003",
        "display" : "Dutasteride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dutasteride"
        },
        {
          "language" : "fr-CH",
          "value" : "dutastéride"
        },
        {
          "language" : "de-CH",
          "value" : "Dutasterid"
        },
        {
          "language" : "it-CH",
          "value" : "dutasteride"
        }]
      },
      {
        "code" : "126093005",
        "display" : "Dydrogesterone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dydrogesterone"
        },
        {
          "language" : "fr-CH",
          "value" : "dydrogestérone"
        },
        {
          "language" : "de-CH",
          "value" : "Dydrogesteron"
        },
        {
          "language" : "it-CH",
          "value" : "didrogesterone"
        }]
      },
      {
        "code" : "373471002",
        "display" : "Econazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Econazole"
        },
        {
          "language" : "fr-CH",
          "value" : "éconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Econazol"
        },
        {
          "language" : "it-CH",
          "value" : "econazolo"
        }]
      },
      {
        "code" : "427429004",
        "display" : "Eculizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eculizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "éculizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Eculizumab"
        },
        {
          "language" : "it-CH",
          "value" : "eculizumab"
        }]
      },
      {
        "code" : "712778008",
        "display" : "Edoxaban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Edoxaban"
        },
        {
          "language" : "fr-CH",
          "value" : "édoxaban"
        },
        {
          "language" : "de-CH",
          "value" : "Edoxaban"
        },
        {
          "language" : "it-CH",
          "value" : "edoxaban"
        }]
      },
      {
        "code" : "387001004",
        "display" : "Efavirenz (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Efavirenz"
        },
        {
          "language" : "fr-CH",
          "value" : "éfavirenz"
        },
        {
          "language" : "de-CH",
          "value" : "Efavirenz"
        },
        {
          "language" : "it-CH",
          "value" : "efavirenz"
        }]
      },
      {
        "code" : "410843003",
        "display" : "Eletriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eletriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "élétriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Eletriptan"
        },
        {
          "language" : "it-CH",
          "value" : "eletriptan"
        }]
      },
      {
        "code" : "715660001",
        "display" : "Elotuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Elotuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "élotuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Elotuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "elotuzumab"
        }]
      },
      {
        "code" : "703894008",
        "display" : "Empagliflozin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Empagliflozin"
        },
        {
          "language" : "fr-CH",
          "value" : "empagliflozine"
        },
        {
          "language" : "de-CH",
          "value" : "Empagliflozin"
        },
        {
          "language" : "it-CH",
          "value" : "empagliflozin"
        }]
      },
      {
        "code" : "404856006",
        "display" : "Emtricitabine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Emtricitabine"
        },
        {
          "language" : "fr-CH",
          "value" : "emtricitabine"
        },
        {
          "language" : "de-CH",
          "value" : "Emtricitabin"
        },
        {
          "language" : "it-CH",
          "value" : "emtricitabina"
        }]
      },
      {
        "code" : "372658000",
        "display" : "Enalapril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Enalapril"
        },
        {
          "language" : "fr-CH",
          "value" : "énalapril"
        },
        {
          "language" : "de-CH",
          "value" : "Enalapril"
        },
        {
          "language" : "it-CH",
          "value" : "enalapril"
        }]
      },
      {
        "code" : "772201002",
        "display" : "Encorafenib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Encorafenib"
        },
        {
          "language" : "fr-CH",
          "value" : "encorafénib"
        },
        {
          "language" : "de-CH",
          "value" : "Encorafenib"
        },
        {
          "language" : "it-CH",
          "value" : "encorafenib"
        }]
      },
      {
        "code" : "387018000",
        "display" : "Entacapone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Entacapone"
        },
        {
          "language" : "fr-CH",
          "value" : "entacapone"
        },
        {
          "language" : "de-CH",
          "value" : "Entacapon"
        },
        {
          "language" : "it-CH",
          "value" : "entacapone"
        }]
      },
      {
        "code" : "416644000",
        "display" : "Entecavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Entecavir"
        },
        {
          "language" : "fr-CH",
          "value" : "entécavir"
        },
        {
          "language" : "de-CH",
          "value" : "Entecavir"
        },
        {
          "language" : "it-CH",
          "value" : "entacavir"
        }]
      },
      {
        "code" : "256012001",
        "display" : "Eosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eosine"
        },
        {
          "language" : "fr-CH",
          "value" : "éosine"
        },
        {
          "language" : "de-CH",
          "value" : "Eosin"
        },
        {
          "language" : "it-CH",
          "value" : "eosina"
        }]
      },
      {
        "code" : "387358007",
        "display" : "Ephedrine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ephedrine"
        },
        {
          "language" : "fr-CH",
          "value" : "éphédrine"
        },
        {
          "language" : "de-CH",
          "value" : "Ephedrin"
        },
        {
          "language" : "it-CH",
          "value" : "efedrina"
        }]
      },
      {
        "code" : "407068009",
        "display" : "Epinastine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Epinastine"
        },
        {
          "language" : "fr-CH",
          "value" : "épinastine"
        },
        {
          "language" : "de-CH",
          "value" : "Epinastin"
        },
        {
          "language" : "it-CH",
          "value" : "epinastina"
        }]
      },
      {
        "code" : "407010008",
        "display" : "Eplerenone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eplerenone"
        },
        {
          "language" : "fr-CH",
          "value" : "éplérénone"
        },
        {
          "language" : "de-CH",
          "value" : "Eplerenon"
        },
        {
          "language" : "it-CH",
          "value" : "eplerenone"
        }]
      },
      {
        "code" : "386947003",
        "display" : "Epoetin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Epoetin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "époétine alfa recombinante"
        },
        {
          "language" : "de-CH",
          "value" : "Epoetin alfa rekombiniert"
        },
        {
          "language" : "it-CH",
          "value" : "epoetina alfa ricombinante"
        }]
      },
      {
        "code" : "396043004",
        "display" : "Epoetin beta (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Epoetin beta"
        },
        {
          "language" : "fr-CH",
          "value" : "époétine bêta recombinante"
        },
        {
          "language" : "de-CH",
          "value" : "Epoetin beta rekombiniert"
        },
        {
          "language" : "it-CH",
          "value" : "epoetina beta ricombinante"
        }]
      },
      {
        "code" : "708829008",
        "display" : "Epoetin theta (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Epoetin theta"
        },
        {
          "language" : "fr-CH",
          "value" : "époétine thêta"
        },
        {
          "language" : "de-CH",
          "value" : "Epoetin theta"
        },
        {
          "language" : "it-CH",
          "value" : "epoetina teta"
        }]
      },
      {
        "code" : "396044005",
        "display" : "Eprosartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eprosartan"
        },
        {
          "language" : "fr-CH",
          "value" : "éprosartan"
        },
        {
          "language" : "de-CH",
          "value" : "Eprosartan"
        },
        {
          "language" : "it-CH",
          "value" : "eprosartan"
        }]
      },
      {
        "code" : "386998009",
        "display" : "Eptifibatide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eptifibatide"
        },
        {
          "language" : "fr-CH",
          "value" : "eptifibatide"
        },
        {
          "language" : "de-CH",
          "value" : "Eptifibatid"
        },
        {
          "language" : "it-CH",
          "value" : "eptifibatide"
        }]
      },
      {
        "code" : "708166000",
        "display" : "Eribulin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eribulin"
        },
        {
          "language" : "fr-CH",
          "value" : "éribuline"
        },
        {
          "language" : "de-CH",
          "value" : "Eribulin"
        },
        {
          "language" : "it-CH",
          "value" : "eribulina"
        }]
      },
      {
        "code" : "414123001",
        "display" : "Erlotinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Erlotinib"
        },
        {
          "language" : "fr-CH",
          "value" : "erlotinib"
        },
        {
          "language" : "de-CH",
          "value" : "Erlotinib"
        },
        {
          "language" : "it-CH",
          "value" : "erlotinib"
        }]
      },
      {
        "code" : "396346003",
        "display" : "Ertapenem (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ertapenem"
        },
        {
          "language" : "fr-CH",
          "value" : "ertapénem"
        },
        {
          "language" : "de-CH",
          "value" : "Ertapenem"
        },
        {
          "language" : "it-CH",
          "value" : "ertapenem"
        }]
      },
      {
        "code" : "764274008",
        "display" : "Ertugliflozin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ertugliflozin"
        },
        {
          "language" : "fr-CH",
          "value" : "ertugliflozine"
        },
        {
          "language" : "de-CH",
          "value" : "Ertugliflozin"
        },
        {
          "language" : "it-CH",
          "value" : "ertugliflozin"
        }]
      },
      {
        "code" : "372694001",
        "display" : "Erythromycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Erythromycin"
        },
        {
          "language" : "fr-CH",
          "value" : "érythromycine"
        },
        {
          "language" : "de-CH",
          "value" : "Erythromycin"
        },
        {
          "language" : "it-CH",
          "value" : "eritromicina"
        }]
      },
      {
        "code" : "400447003",
        "display" : "Escitalopram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Escitalopram"
        },
        {
          "language" : "fr-CH",
          "value" : "escitalopram"
        },
        {
          "language" : "de-CH",
          "value" : "Escitalopram"
        },
        {
          "language" : "it-CH",
          "value" : "escitalopram"
        }]
      },
      {
        "code" : "396047003",
        "display" : "Esomeprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Esomeprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "ésoméprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Esomeprazol"
        },
        {
          "language" : "it-CH",
          "value" : "esomeprazolo"
        }]
      },
      {
        "code" : "126172005",
        "display" : "Estradiol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Estradiol"
        },
        {
          "language" : "fr-CH",
          "value" : "estradiol"
        },
        {
          "language" : "de-CH",
          "value" : "Estradiol"
        },
        {
          "language" : "it-CH",
          "value" : "estradiolo"
        }]
      },
      {
        "code" : "73723004",
        "display" : "Estriol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Estriol"
        },
        {
          "language" : "fr-CH",
          "value" : "estriol"
        },
        {
          "language" : "de-CH",
          "value" : "Estriol"
        },
        {
          "language" : "it-CH",
          "value" : "estriolo"
        }]
      },
      {
        "code" : "387045004",
        "display" : "Etanercept (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etanercept"
        },
        {
          "language" : "fr-CH",
          "value" : "étanercept"
        },
        {
          "language" : "de-CH",
          "value" : "Etanercept"
        },
        {
          "language" : "it-CH",
          "value" : "etanercept"
        }]
      },
      {
        "code" : "387129004",
        "display" : "Ethambutol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ethambutol"
        },
        {
          "language" : "fr-CH",
          "value" : "éthambutol"
        },
        {
          "language" : "de-CH",
          "value" : "Ethambutol"
        },
        {
          "language" : "it-CH",
          "value" : "etambutolo"
        }]
      },
      {
        "code" : "387244008",
        "display" : "Ethosuximide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ethosuximide"
        },
        {
          "language" : "fr-CH",
          "value" : "éthosuximide"
        },
        {
          "language" : "de-CH",
          "value" : "Ethosuximid"
        },
        {
          "language" : "it-CH",
          "value" : "etosuccimide"
        }]
      },
      {
        "code" : "22005007",
        "display" : "Ethyl chloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ethyl chloride"
        },
        {
          "language" : "fr-CH",
          "value" : "éthyle chlorure"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorethan"
        },
        {
          "language" : "it-CH",
          "value" : "cloruro di etile"
        }]
      },
      {
        "code" : "387218008",
        "display" : "Etomidate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etomidate"
        },
        {
          "language" : "fr-CH",
          "value" : "étomidate"
        },
        {
          "language" : "de-CH",
          "value" : "Etomidat"
        },
        {
          "language" : "it-CH",
          "value" : "etomidato"
        }]
      },
      {
        "code" : "396050000",
        "display" : "Etonogestrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etonogestrel"
        },
        {
          "language" : "fr-CH",
          "value" : "étonogestrel"
        },
        {
          "language" : "de-CH",
          "value" : "Etonogestrel"
        },
        {
          "language" : "it-CH",
          "value" : "etonogestrel"
        }]
      },
      {
        "code" : "387316009",
        "display" : "Etoposide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etoposide"
        },
        {
          "language" : "fr-CH",
          "value" : "étoposide"
        },
        {
          "language" : "de-CH",
          "value" : "Etoposid"
        },
        {
          "language" : "it-CH",
          "value" : "etoposide"
        }]
      },
      {
        "code" : "409134009",
        "display" : "Etoricoxib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etoricoxib"
        },
        {
          "language" : "fr-CH",
          "value" : "étoricoxib"
        },
        {
          "language" : "de-CH",
          "value" : "Etoricoxib"
        },
        {
          "language" : "it-CH",
          "value" : "etoricoxib"
        }]
      },
      {
        "code" : "428698007",
        "display" : "Everolimus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Everolimus"
        },
        {
          "language" : "fr-CH",
          "value" : "évérolimus"
        },
        {
          "language" : "de-CH",
          "value" : "Everolimus"
        },
        {
          "language" : "it-CH",
          "value" : "everolimus"
        }]
      },
      {
        "code" : "387017005",
        "display" : "Exemestane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Exemestane"
        },
        {
          "language" : "fr-CH",
          "value" : "exémestane"
        },
        {
          "language" : "de-CH",
          "value" : "Exemestan"
        },
        {
          "language" : "it-CH",
          "value" : "exemestane"
        }]
      },
      {
        "code" : "416859008",
        "display" : "Exenatide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Exenatide"
        },
        {
          "language" : "fr-CH",
          "value" : "exénatide"
        },
        {
          "language" : "de-CH",
          "value" : "Exenatid"
        },
        {
          "language" : "it-CH",
          "value" : "exenatide"
        }]
      },
      {
        "code" : "409149001",
        "display" : "Ezetimibe (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ezetimibe"
        },
        {
          "language" : "fr-CH",
          "value" : "ézétimibe"
        },
        {
          "language" : "de-CH",
          "value" : "Ezetimib"
        },
        {
          "language" : "it-CH",
          "value" : "ezetimibe"
        }]
      },
      {
        "code" : "387557001",
        "display" : "Famciclovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Famciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "famciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Famciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "famciclovir"
        }]
      },
      {
        "code" : "441743008",
        "display" : "Febuxostat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Febuxostat"
        },
        {
          "language" : "fr-CH",
          "value" : "fébuxostat"
        },
        {
          "language" : "de-CH",
          "value" : "Febuxostat"
        },
        {
          "language" : "it-CH",
          "value" : "febuxostat"
        }]
      },
      {
        "code" : "96194006",
        "display" : "Felbamate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Felbamate"
        },
        {
          "language" : "fr-CH",
          "value" : "felbamate"
        },
        {
          "language" : "de-CH",
          "value" : "Felbamat"
        },
        {
          "language" : "it-CH",
          "value" : "felbamato"
        }]
      },
      {
        "code" : "386863007",
        "display" : "Felodipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Felodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "félodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Felodipin"
        },
        {
          "language" : "it-CH",
          "value" : "felodipina"
        }]
      },
      {
        "code" : "386879008",
        "display" : "Fenofibrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fenofibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "fénofibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Fenofibrat"
        },
        {
          "language" : "it-CH",
          "value" : "fenofibrato"
        }]
      },
      {
        "code" : "395976006",
        "display" : "Fenoterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fenoterol"
        },
        {
          "language" : "fr-CH",
          "value" : "fénotérol"
        },
        {
          "language" : "de-CH",
          "value" : "Fenoterol"
        },
        {
          "language" : "it-CH",
          "value" : "fenoterolo"
        }]
      },
      {
        "code" : "373492002",
        "display" : "Fentanyl (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fentanyl"
        },
        {
          "language" : "fr-CH",
          "value" : "fentanyl"
        },
        {
          "language" : "de-CH",
          "value" : "Fentanyl"
        },
        {
          "language" : "it-CH",
          "value" : "fentanil"
        }]
      },
      {
        "code" : "441469003",
        "display" : "Fesoterodine fumarate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fesoterodine fumarate"
        },
        {
          "language" : "fr-CH",
          "value" : "fésotérodine fumarate"
        },
        {
          "language" : "de-CH",
          "value" : "Fesoterodin fumarat"
        },
        {
          "language" : "it-CH",
          "value" : "fesoterodine fumarato"
        }]
      },
      {
        "code" : "703664004",
        "display" : "Fidaxomicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fidaxomicin"
        },
        {
          "language" : "fr-CH",
          "value" : "fidaxomicine"
        },
        {
          "language" : "de-CH",
          "value" : "Fidaxomicin"
        },
        {
          "language" : "it-CH",
          "value" : "fidaxomicina"
        }]
      },
      {
        "code" : "386948008",
        "display" : "Filgrastim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Filgrastim"
        },
        {
          "language" : "fr-CH",
          "value" : "filgrastim recombinant"
        },
        {
          "language" : "de-CH",
          "value" : "Filgrastim rekombiniert"
        },
        {
          "language" : "it-CH",
          "value" : "filgrastim"
        }]
      },
      {
        "code" : "386963006",
        "display" : "Finasteride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Finasteride"
        },
        {
          "language" : "fr-CH",
          "value" : "finastéride"
        },
        {
          "language" : "de-CH",
          "value" : "Finasterid"
        },
        {
          "language" : "it-CH",
          "value" : "finasteride"
        }]
      },
      {
        "code" : "372768002",
        "display" : "Flavoxate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flavoxate"
        },
        {
          "language" : "fr-CH",
          "value" : "flavoxate"
        },
        {
          "language" : "de-CH",
          "value" : "Flavoxat"
        },
        {
          "language" : "it-CH",
          "value" : "flavossato"
        }]
      },
      {
        "code" : "387544009",
        "display" : "Flucloxacillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flucloxacillin"
        },
        {
          "language" : "fr-CH",
          "value" : "flucloxacilline"
        },
        {
          "language" : "de-CH",
          "value" : "Flucloxacillin"
        },
        {
          "language" : "it-CH",
          "value" : "flucloxacillina"
        }]
      },
      {
        "code" : "387174006",
        "display" : "Fluconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "fluconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Fluconazol"
        },
        {
          "language" : "it-CH",
          "value" : "fluconazolo"
        }]
      },
      {
        "code" : "116586002",
        "display" : "Fludrocortisone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fludrocortisone"
        },
        {
          "language" : "fr-CH",
          "value" : "fludrocortisone"
        },
        {
          "language" : "de-CH",
          "value" : "Fludrocortison"
        },
        {
          "language" : "it-CH",
          "value" : "fludrocortisone"
        }]
      },
      {
        "code" : "387575000",
        "display" : "Flumazenil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flumazenil"
        },
        {
          "language" : "fr-CH",
          "value" : "flumazénil"
        },
        {
          "language" : "de-CH",
          "value" : "Flumazenil"
        },
        {
          "language" : "it-CH",
          "value" : "flumazenil"
        }]
      },
      {
        "code" : "418221001",
        "display" : "Flunarizine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flunarizine"
        },
        {
          "language" : "fr-CH",
          "value" : "flunarizine"
        },
        {
          "language" : "de-CH",
          "value" : "Flunarizin"
        },
        {
          "language" : "it-CH",
          "value" : "flunarizina"
        }]
      },
      {
        "code" : "387573007",
        "display" : "Flunitrazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flunitrazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "flunitrazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Flunitrazepam"
        },
        {
          "language" : "it-CH",
          "value" : "flunitrazepam"
        }]
      },
      {
        "code" : "396060009",
        "display" : "Fluocinonide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluocinonide"
        },
        {
          "language" : "fr-CH",
          "value" : "fluocinonide"
        },
        {
          "language" : "de-CH",
          "value" : "Fluocinonid"
        },
        {
          "language" : "it-CH",
          "value" : "fluocinonide"
        }]
      },
      {
        "code" : "2925007",
        "display" : "Fluorometholone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluorometholone"
        },
        {
          "language" : "fr-CH",
          "value" : "fluorométholone"
        },
        {
          "language" : "de-CH",
          "value" : "Fluorometholon"
        },
        {
          "language" : "it-CH",
          "value" : "fluorometolone"
        }]
      },
      {
        "code" : "387172005",
        "display" : "Fluorouracil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluorouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "fluorouracil"
        },
        {
          "language" : "de-CH",
          "value" : "Fluorouracil"
        },
        {
          "language" : "it-CH",
          "value" : "fluorouracile"
        }]
      },
      {
        "code" : "372767007",
        "display" : "Fluoxetine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluoxetine"
        },
        {
          "language" : "fr-CH",
          "value" : "fluoxétine"
        },
        {
          "language" : "de-CH",
          "value" : "Fluoxetin"
        },
        {
          "language" : "it-CH",
          "value" : "fluoxetina"
        }]
      },
      {
        "code" : "387567006",
        "display" : "Flupentixol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flupentixol"
        },
        {
          "language" : "fr-CH",
          "value" : "flupentixol"
        },
        {
          "language" : "de-CH",
          "value" : "Flupentixol"
        },
        {
          "language" : "it-CH",
          "value" : "flupentixolo"
        }]
      },
      {
        "code" : "387109000",
        "display" : "Flurazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flurazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "flurazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Flurazepam"
        },
        {
          "language" : "it-CH",
          "value" : "flurazepam"
        }]
      },
      {
        "code" : "373506008",
        "display" : "Flurbiprofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flurbiprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "flurbiprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Flurbiprofen"
        },
        {
          "language" : "it-CH",
          "value" : "flurbiprofene"
        }]
      },
      {
        "code" : "397192001",
        "display" : "Fluticasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluticasone"
        },
        {
          "language" : "fr-CH",
          "value" : "fluticasone"
        },
        {
          "language" : "de-CH",
          "value" : "Fluticason"
        },
        {
          "language" : "it-CH",
          "value" : "fluticasone"
        }]
      },
      {
        "code" : "387585004",
        "display" : "Fluvastatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "fluvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Fluvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "fluvastatina"
        }]
      },
      {
        "code" : "372905008",
        "display" : "Fluvoxamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluvoxamine"
        },
        {
          "language" : "fr-CH",
          "value" : "fluvoxamine"
        },
        {
          "language" : "de-CH",
          "value" : "Fluvoxamin"
        },
        {
          "language" : "it-CH",
          "value" : "fluvoxamina"
        }]
      },
      {
        "code" : "63718003",
        "display" : "Folic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Folic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide folique"
        },
        {
          "language" : "de-CH",
          "value" : "Folsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido folico"
        }]
      },
      {
        "code" : "395862009",
        "display" : "Follitropin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Follitropin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "follitropine alfa"
        },
        {
          "language" : "de-CH",
          "value" : "Follitropin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "follitropina alfa"
        }]
      },
      {
        "code" : "386970006",
        "display" : "Fomepizole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fomepizole"
        },
        {
          "language" : "fr-CH",
          "value" : "fomépizole"
        },
        {
          "language" : "de-CH",
          "value" : "Fomepizol"
        },
        {
          "language" : "it-CH",
          "value" : "fomepizolo"
        }]
      },
      {
        "code" : "385517000",
        "display" : "Fondaparinux sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fondaparinux sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "fondaparinux sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Fondaparinux natrium"
        },
        {
          "language" : "it-CH",
          "value" : "fondaparinux sodico"
        }]
      },
      {
        "code" : "414289007",
        "display" : "Formoterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Formoterol"
        },
        {
          "language" : "fr-CH",
          "value" : "formotérol"
        },
        {
          "language" : "de-CH",
          "value" : "Formoterol"
        },
        {
          "language" : "it-CH",
          "value" : "formoterolo"
        }]
      },
      {
        "code" : "407017006",
        "display" : "Fosamprenavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fosamprenavir"
        },
        {
          "language" : "fr-CH",
          "value" : "fosamprénavir"
        },
        {
          "language" : "de-CH",
          "value" : "Fosamprenavir"
        },
        {
          "language" : "it-CH",
          "value" : "fosamprenavir"
        }]
      },
      {
        "code" : "372902006",
        "display" : "Foscarnet (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Foscarnet"
        },
        {
          "language" : "fr-CH",
          "value" : "foscarnet"
        },
        {
          "language" : "de-CH",
          "value" : "Foscarnet"
        },
        {
          "language" : "it-CH",
          "value" : "foscarnet"
        }]
      },
      {
        "code" : "372534005",
        "display" : "Fosfomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fosfomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "fosfomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Fosfomycin"
        },
        {
          "language" : "it-CH",
          "value" : "fosfomicina"
        }]
      },
      {
        "code" : "411990007",
        "display" : "Frovatriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Frovatriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "frovatriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Frovatriptan"
        },
        {
          "language" : "it-CH",
          "value" : "frovatriptan"
        }]
      },
      {
        "code" : "385519002",
        "display" : "Fulvestrant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fulvestrant"
        },
        {
          "language" : "fr-CH",
          "value" : "fulvestrant"
        },
        {
          "language" : "de-CH",
          "value" : "Fulvestrant"
        },
        {
          "language" : "it-CH",
          "value" : "fulvestrant"
        }]
      },
      {
        "code" : "387475002",
        "display" : "Furosemide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Furosemide"
        },
        {
          "language" : "fr-CH",
          "value" : "furosémide"
        },
        {
          "language" : "de-CH",
          "value" : "Furosemid"
        },
        {
          "language" : "it-CH",
          "value" : "furosemide"
        }]
      },
      {
        "code" : "387530003",
        "display" : "Fusidic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fusidic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide fusidique"
        },
        {
          "language" : "de-CH",
          "value" : "Fusidinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido fusidico"
        }]
      },
      {
        "code" : "386845007",
        "display" : "Gabapentin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gabapentin"
        },
        {
          "language" : "fr-CH",
          "value" : "gabapentine"
        },
        {
          "language" : "de-CH",
          "value" : "Gabapentin"
        },
        {
          "language" : "it-CH",
          "value" : "gabapentin"
        }]
      },
      {
        "code" : "38182007",
        "display" : "Galactose (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Galactose"
        },
        {
          "language" : "fr-CH",
          "value" : "galactose"
        },
        {
          "language" : "de-CH",
          "value" : "Galactose"
        },
        {
          "language" : "it-CH",
          "value" : "galattosio"
        }]
      },
      {
        "code" : "395728002",
        "display" : "Ganirelix (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ganirelix"
        },
        {
          "language" : "fr-CH",
          "value" : "ganirélix"
        },
        {
          "language" : "de-CH",
          "value" : "Ganirelix"
        },
        {
          "language" : "it-CH",
          "value" : "ganirelix"
        }]
      },
      {
        "code" : "387321007",
        "display" : "Gentamicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gentamicin"
        },
        {
          "language" : "fr-CH",
          "value" : "gentamicine"
        },
        {
          "language" : "de-CH",
          "value" : "Gentamicin"
        },
        {
          "language" : "it-CH",
          "value" : "gentamicina"
        }]
      },
      {
        "code" : "395945000",
        "display" : "Gestodene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gestodene"
        },
        {
          "language" : "fr-CH",
          "value" : "gestodène"
        },
        {
          "language" : "de-CH",
          "value" : "Gestoden"
        },
        {
          "language" : "it-CH",
          "value" : "gestodene"
        }]
      },
      {
        "code" : "372535006",
        "display" : "Glatiramer (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glatiramer"
        },
        {
          "language" : "fr-CH",
          "value" : "glatiramère"
        },
        {
          "language" : "de-CH",
          "value" : "Glatiramer"
        },
        {
          "language" : "it-CH",
          "value" : "glatiramer"
        }]
      },
      {
        "code" : "384978002",
        "display" : "Glibenclamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glibenclamide"
        },
        {
          "language" : "fr-CH",
          "value" : "glibenclamide"
        },
        {
          "language" : "de-CH",
          "value" : "Glibenclamid"
        },
        {
          "language" : "it-CH",
          "value" : "glibenclamide"
        }]
      },
      {
        "code" : "395731001",
        "display" : "Gliclazide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gliclazide"
        },
        {
          "language" : "fr-CH",
          "value" : "gliclazide"
        },
        {
          "language" : "de-CH",
          "value" : "Gliclazid"
        },
        {
          "language" : "it-CH",
          "value" : "gliclazide"
        }]
      },
      {
        "code" : "386966003",
        "display" : "Glimepiride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glimepiride"
        },
        {
          "language" : "fr-CH",
          "value" : "glimépiride"
        },
        {
          "language" : "de-CH",
          "value" : "Glimepirid"
        },
        {
          "language" : "it-CH",
          "value" : "glimepiride"
        }]
      },
      {
        "code" : "66603002",
        "display" : "Glucagon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glucagon"
        },
        {
          "language" : "fr-CH",
          "value" : "glucagon"
        },
        {
          "language" : "de-CH",
          "value" : "Glucagon"
        },
        {
          "language" : "it-CH",
          "value" : "glucagone"
        }]
      },
      {
        "code" : "67079006",
        "display" : "Glucose (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glucose"
        },
        {
          "language" : "fr-CH",
          "value" : "glucose"
        },
        {
          "language" : "de-CH",
          "value" : "Glucose"
        },
        {
          "language" : "it-CH",
          "value" : "glucosio"
        }]
      },
      {
        "code" : "387404004",
        "display" : "Glyceryl trinitrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glyceryl trinitrate"
        },
        {
          "language" : "fr-CH",
          "value" : "nitroglycérine"
        },
        {
          "language" : "de-CH",
          "value" : "Nitroglycerin"
        },
        {
          "language" : "it-CH",
          "value" : "nitroglicerina"
        }]
      },
      {
        "code" : "769097000",
        "display" : "Glycopyrronium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glycopyrronium"
        },
        {
          "language" : "fr-CH",
          "value" : "glycopyrronium"
        },
        {
          "language" : "de-CH",
          "value" : "Glycopyrronium-Kation"
        },
        {
          "language" : "it-CH",
          "value" : "glicopirronio"
        }]
      },
      {
        "code" : "442435002",
        "display" : "Golimumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Golimumab"
        },
        {
          "language" : "fr-CH",
          "value" : "golimumab"
        },
        {
          "language" : "de-CH",
          "value" : "Golimumab"
        },
        {
          "language" : "it-CH",
          "value" : "golimumab"
        }]
      },
      {
        "code" : "397197007",
        "display" : "Gonadorelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gonadorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "gonadoréline"
        },
        {
          "language" : "de-CH",
          "value" : "Gonadorelin"
        },
        {
          "language" : "it-CH",
          "value" : "gonadorelina"
        }]
      },
      {
        "code" : "387524003",
        "display" : "Gramicidin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gramicidin"
        },
        {
          "language" : "fr-CH",
          "value" : "gramicidine"
        },
        {
          "language" : "de-CH",
          "value" : "Gramicidin"
        },
        {
          "language" : "it-CH",
          "value" : "gramicidina"
        }]
      },
      {
        "code" : "372489005",
        "display" : "Granisetron (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Granisetron"
        },
        {
          "language" : "fr-CH",
          "value" : "granisétron"
        },
        {
          "language" : "de-CH",
          "value" : "Granisetron"
        },
        {
          "language" : "it-CH",
          "value" : "granisetron"
        }]
      },
      {
        "code" : "372507007",
        "display" : "Guanfacine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Guanfacine"
        },
        {
          "language" : "fr-CH",
          "value" : "guanfacine"
        },
        {
          "language" : "de-CH",
          "value" : "Guanfacin"
        },
        {
          "language" : "it-CH",
          "value" : "guanfacina"
        }]
      },
      {
        "code" : "395735005",
        "display" : "Halcinonide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Halcinonide"
        },
        {
          "language" : "fr-CH",
          "value" : "halcinonide"
        },
        {
          "language" : "de-CH",
          "value" : "Halcinonid"
        },
        {
          "language" : "it-CH",
          "value" : "alcinonide"
        }]
      },
      {
        "code" : "704673003",
        "display" : "Halometasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Halometasone"
        },
        {
          "language" : "fr-CH",
          "value" : "halométasone"
        },
        {
          "language" : "de-CH",
          "value" : "Halometason"
        },
        {
          "language" : "it-CH",
          "value" : "alometasone"
        }]
      },
      {
        "code" : "386837002",
        "display" : "Haloperidol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Haloperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "halopéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Haloperidol"
        },
        {
          "language" : "it-CH",
          "value" : "aloperidolo"
        }]
      },
      {
        "code" : "372877000",
        "display" : "Heparin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Heparin"
        },
        {
          "language" : "fr-CH",
          "value" : "héparine"
        },
        {
          "language" : "de-CH",
          "value" : "Heparin"
        },
        {
          "language" : "it-CH",
          "value" : "eparina"
        }]
      },
      {
        "code" : "703831002",
        "display" : "Hexamidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hexamidine"
        },
        {
          "language" : "fr-CH",
          "value" : "hexamidine"
        },
        {
          "language" : "de-CH",
          "value" : "Hexamidin"
        },
        {
          "language" : "it-CH",
          "value" : "esamidina"
        }]
      },
      {
        "code" : "387132001",
        "display" : "Hexetidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hexetidine"
        },
        {
          "language" : "fr-CH",
          "value" : "hexétidine"
        },
        {
          "language" : "de-CH",
          "value" : "Hexetidin"
        },
        {
          "language" : "it-CH",
          "value" : "esetidina"
        }]
      },
      {
        "code" : "704987001",
        "display" : "Hexoprenaline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hexoprenaline"
        },
        {
          "language" : "fr-CH",
          "value" : "hexoprénaline"
        },
        {
          "language" : "de-CH",
          "value" : "Hexoprenalin"
        },
        {
          "language" : "it-CH",
          "value" : "esoprenalina"
        }]
      },
      {
        "code" : "8203003",
        "display" : "Human menopausal gonadotropin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Human menopausal gonadotropin"
        },
        {
          "language" : "fr-CH",
          "value" : "ménotropine"
        },
        {
          "language" : "de-CH",
          "value" : "Menotropin"
        },
        {
          "language" : "it-CH",
          "value" : "menotropina"
        }]
      },
      {
        "code" : "387525002",
        "display" : "Hydrochlorothiazide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydrochlorothiazide"
        },
        {
          "language" : "fr-CH",
          "value" : "hydrochlorothiazide"
        },
        {
          "language" : "de-CH",
          "value" : "Hydrochlorothiazid"
        },
        {
          "language" : "it-CH",
          "value" : "idroclorotiazide"
        }]
      },
      {
        "code" : "372671002",
        "display" : "Hydrocodone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydrocodone"
        },
        {
          "language" : "fr-CH",
          "value" : "hydrocodone"
        },
        {
          "language" : "de-CH",
          "value" : "Hydrocodon"
        },
        {
          "language" : "it-CH",
          "value" : "idrocodone"
        }]
      },
      {
        "code" : "44508008",
        "display" : "Hydromorphone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydromorphone"
        },
        {
          "language" : "fr-CH",
          "value" : "hydromorphone"
        },
        {
          "language" : "de-CH",
          "value" : "Hydromorphon"
        },
        {
          "language" : "it-CH",
          "value" : "idromorfone"
        }]
      },
      {
        "code" : "409258004",
        "display" : "Hydroxocobalamin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydroxocobalamin"
        },
        {
          "language" : "fr-CH",
          "value" : "hydroxocobalamine"
        },
        {
          "language" : "de-CH",
          "value" : "Hydroxocobalamin"
        },
        {
          "language" : "it-CH",
          "value" : "idrossocobalamina"
        }]
      },
      {
        "code" : "387314007",
        "display" : "Hydroxycarbamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydroxycarbamide"
        },
        {
          "language" : "fr-CH",
          "value" : "hydroxycarbamide"
        },
        {
          "language" : "de-CH",
          "value" : "Hydroxycarbamid"
        },
        {
          "language" : "it-CH",
          "value" : "idrossicarbamide"
        }]
      },
      {
        "code" : "372856003",
        "display" : "Hydroxyzine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydroxyzine"
        },
        {
          "language" : "fr-CH",
          "value" : "hydroxyzine"
        },
        {
          "language" : "de-CH",
          "value" : "Hydroxyzin"
        },
        {
          "language" : "it-CH",
          "value" : "idrossizina"
        }]
      },
      {
        "code" : "420936009",
        "display" : "Ibandronic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ibandronic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide ibandronique (ibandronate)"
        },
        {
          "language" : "de-CH",
          "value" : "Ibandronsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido ibandronico"
        }]
      },
      {
        "code" : "387207008",
        "display" : "Ibuprofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ibuprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "ibuprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Ibuprofen"
        },
        {
          "language" : "it-CH",
          "value" : "ibuprofene"
        }]
      },
      {
        "code" : "703834005",
        "display" : "Icatibant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Icatibant"
        },
        {
          "language" : "fr-CH",
          "value" : "icatibant"
        },
        {
          "language" : "de-CH",
          "value" : "Icatibant"
        },
        {
          "language" : "it-CH",
          "value" : "icatibant"
        }]
      },
      {
        "code" : "372539000",
        "display" : "Idarubicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Idarubicin"
        },
        {
          "language" : "fr-CH",
          "value" : "idarubicine"
        },
        {
          "language" : "de-CH",
          "value" : "Idarubicin"
        },
        {
          "language" : "it-CH",
          "value" : "idarubicina"
        }]
      },
      {
        "code" : "716017002",
        "display" : "Idarucizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Idarucizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "idarucizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Idarucizumab"
        },
        {
          "language" : "it-CH",
          "value" : "idarucizumab"
        }]
      },
      {
        "code" : "429666007",
        "display" : "Idebenone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Idebenone"
        },
        {
          "language" : "fr-CH",
          "value" : "idébénone"
        },
        {
          "language" : "de-CH",
          "value" : "Idebenon"
        },
        {
          "language" : "it-CH",
          "value" : "idebenone"
        }]
      },
      {
        "code" : "710278000",
        "display" : "Idelalisib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Idelalisib"
        },
        {
          "language" : "fr-CH",
          "value" : "idélalisib"
        },
        {
          "language" : "de-CH",
          "value" : "Idelalisib"
        },
        {
          "language" : "it-CH",
          "value" : "idelalisib"
        }]
      },
      {
        "code" : "386904003",
        "display" : "Ifosfamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ifosfamide"
        },
        {
          "language" : "fr-CH",
          "value" : "ifosfamide"
        },
        {
          "language" : "de-CH",
          "value" : "Ifosfamid"
        },
        {
          "language" : "it-CH",
          "value" : "ifosfamide"
        }]
      },
      {
        "code" : "395740002",
        "display" : "Iloprost (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iloprost"
        },
        {
          "language" : "fr-CH",
          "value" : "iloprost"
        },
        {
          "language" : "de-CH",
          "value" : "Iloprost"
        },
        {
          "language" : "it-CH",
          "value" : "iloprost"
        }]
      },
      {
        "code" : "414460008",
        "display" : "Imatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Imatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "imatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Imatinib"
        },
        {
          "language" : "it-CH",
          "value" : "imatinib"
        }]
      },
      {
        "code" : "46558003",
        "display" : "Imipenem (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Imipenem"
        },
        {
          "language" : "fr-CH",
          "value" : "imipénem"
        },
        {
          "language" : "de-CH",
          "value" : "Imipenem"
        },
        {
          "language" : "it-CH",
          "value" : "imipenem"
        }]
      },
      {
        "code" : "372718005",
        "display" : "Imipramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Imipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "imipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Imipramin"
        },
        {
          "language" : "it-CH",
          "value" : "imipramina"
        }]
      },
      {
        "code" : "386941002",
        "display" : "Imiquimod (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Imiquimod"
        },
        {
          "language" : "fr-CH",
          "value" : "imiquimod"
        },
        {
          "language" : "de-CH",
          "value" : "Imiquimod"
        },
        {
          "language" : "it-CH",
          "value" : "imiquimod"
        }]
      },
      {
        "code" : "702801003",
        "display" : "Indacaterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Indacaterol"
        },
        {
          "language" : "fr-CH",
          "value" : "indacatérol"
        },
        {
          "language" : "de-CH",
          "value" : "Indacaterol"
        },
        {
          "language" : "it-CH",
          "value" : "indacaterol"
        }]
      },
      {
        "code" : "387419003",
        "display" : "Indapamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Indapamide"
        },
        {
          "language" : "fr-CH",
          "value" : "indapamide"
        },
        {
          "language" : "de-CH",
          "value" : "Indapamid"
        },
        {
          "language" : "it-CH",
          "value" : "indapamide"
        }]
      },
      {
        "code" : "373513008",
        "display" : "Indometacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Indometacin"
        },
        {
          "language" : "fr-CH",
          "value" : "indométacine"
        },
        {
          "language" : "de-CH",
          "value" : "Indometacin"
        },
        {
          "language" : "it-CH",
          "value" : "indometacina"
        }]
      },
      {
        "code" : "386891004",
        "display" : "Infliximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Infliximab"
        },
        {
          "language" : "fr-CH",
          "value" : "infliximab"
        },
        {
          "language" : "de-CH",
          "value" : "Infliximab"
        },
        {
          "language" : "it-CH",
          "value" : "infliximab"
        }]
      },
      {
        "code" : "395750001",
        "display" : "Iodixanol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iodixanol"
        },
        {
          "language" : "fr-CH",
          "value" : "iodixanol"
        },
        {
          "language" : "de-CH",
          "value" : "Iodixanol"
        },
        {
          "language" : "it-CH",
          "value" : "iodixanolo"
        }]
      },
      {
        "code" : "395751002",
        "display" : "Iohexol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iohexol"
        },
        {
          "language" : "fr-CH",
          "value" : "iohexol"
        },
        {
          "language" : "de-CH",
          "value" : "Iohexol"
        },
        {
          "language" : "it-CH",
          "value" : "ioexolo"
        }]
      },
      {
        "code" : "395754005",
        "display" : "Iopamidol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iopamidol"
        },
        {
          "language" : "fr-CH",
          "value" : "iopamidol"
        },
        {
          "language" : "de-CH",
          "value" : "Iopamidol"
        },
        {
          "language" : "it-CH",
          "value" : "iopamidolo"
        }]
      },
      {
        "code" : "395756007",
        "display" : "Iopromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iopromide"
        },
        {
          "language" : "fr-CH",
          "value" : "iopromide"
        },
        {
          "language" : "de-CH",
          "value" : "Iopromid"
        },
        {
          "language" : "it-CH",
          "value" : "iopromide"
        }]
      },
      {
        "code" : "697995005",
        "display" : "Ipilimumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ipilimumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ipilimumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ipilimumab"
        },
        {
          "language" : "it-CH",
          "value" : "ipilimumab"
        }]
      },
      {
        "code" : "386877005",
        "display" : "Irbesartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Irbesartan"
        },
        {
          "language" : "fr-CH",
          "value" : "irbésartan"
        },
        {
          "language" : "de-CH",
          "value" : "Irbesartan"
        },
        {
          "language" : "it-CH",
          "value" : "irbesartan"
        }]
      },
      {
        "code" : "372538008",
        "display" : "Irinotecan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Irinotecan"
        },
        {
          "language" : "fr-CH",
          "value" : "irinotécan"
        },
        {
          "language" : "de-CH",
          "value" : "Irinotecan"
        },
        {
          "language" : "it-CH",
          "value" : "irinotecan"
        }]
      },
      {
        "code" : "765386003",
        "display" : "Isavuconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isavuconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "isavuconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Isavuconazol"
        },
        {
          "language" : "it-CH",
          "value" : "isavuconazolo"
        }]
      },
      {
        "code" : "387472004",
        "display" : "Isoniazid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isoniazid"
        },
        {
          "language" : "fr-CH",
          "value" : "isoniazide"
        },
        {
          "language" : "de-CH",
          "value" : "Isoniazid"
        },
        {
          "language" : "it-CH",
          "value" : "isoniazide"
        }]
      },
      {
        "code" : "372781009",
        "display" : "Isoprenaline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isoprenaline"
        },
        {
          "language" : "fr-CH",
          "value" : "isoprénaline"
        },
        {
          "language" : "de-CH",
          "value" : "Isoprenalin"
        },
        {
          "language" : "it-CH",
          "value" : "isoprenalina"
        }]
      },
      {
        "code" : "387332007",
        "display" : "Isosorbide dinitrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isosorbide dinitrate"
        },
        {
          "language" : "fr-CH",
          "value" : "isosorbide dinitrate"
        },
        {
          "language" : "de-CH",
          "value" : "Isosorbid dinitrat"
        },
        {
          "language" : "it-CH",
          "value" : "isosorbide dinitrato"
        }]
      },
      {
        "code" : "387208003",
        "display" : "Isotretinoin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isotretinoin"
        },
        {
          "language" : "fr-CH",
          "value" : "isotrétinoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Isotretinoin"
        },
        {
          "language" : "it-CH",
          "value" : "isotretinoina"
        }]
      },
      {
        "code" : "387532006",
        "display" : "Itraconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Itraconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "itraconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Itraconazol"
        },
        {
          "language" : "it-CH",
          "value" : "itraconazolo"
        }]
      },
      {
        "code" : "387559003",
        "display" : "Ivermectin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ivermectin"
        },
        {
          "language" : "fr-CH",
          "value" : "ivermectine"
        },
        {
          "language" : "de-CH",
          "value" : "Ivermectin"
        },
        {
          "language" : "it-CH",
          "value" : "ivermectina"
        }]
      },
      {
        "code" : "724037000",
        "display" : "Ixekizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ixekizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ixékizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ixekizumab"
        },
        {
          "language" : "it-CH",
          "value" : "ixekizumab"
        }]
      },
      {
        "code" : "373464007",
        "display" : "Ketamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketamine"
        },
        {
          "language" : "fr-CH",
          "value" : "kétamine"
        },
        {
          "language" : "de-CH",
          "value" : "Ketamin"
        },
        {
          "language" : "it-CH",
          "value" : "ketamina"
        }]
      },
      {
        "code" : "387216007",
        "display" : "Ketoconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketoconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "kétoconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Ketoconazol"
        },
        {
          "language" : "it-CH",
          "value" : "ketoconazolo"
        }]
      },
      {
        "code" : "386832008",
        "display" : "Ketoprofen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketoprofen"
        },
        {
          "language" : "fr-CH",
          "value" : "kétoprofène"
        },
        {
          "language" : "de-CH",
          "value" : "Ketoprofen"
        },
        {
          "language" : "it-CH",
          "value" : "ketoprofene"
        }]
      },
      {
        "code" : "372642003",
        "display" : "Ketotifen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketotifen"
        },
        {
          "language" : "fr-CH",
          "value" : "kétotifène"
        },
        {
          "language" : "de-CH",
          "value" : "Ketotifen"
        },
        {
          "language" : "it-CH",
          "value" : "ketotifene"
        }]
      },
      {
        "code" : "441647003",
        "display" : "Lacosamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lacosamide"
        },
        {
          "language" : "fr-CH",
          "value" : "lacosamide"
        },
        {
          "language" : "de-CH",
          "value" : "Lacosamid"
        },
        {
          "language" : "it-CH",
          "value" : "lacosamide"
        }]
      },
      {
        "code" : "47703008",
        "display" : "Lactose (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lactose"
        },
        {
          "language" : "fr-CH",
          "value" : "lactose"
        },
        {
          "language" : "de-CH",
          "value" : "Lactose"
        },
        {
          "language" : "it-CH",
          "value" : "lattosio"
        }]
      },
      {
        "code" : "386897000",
        "display" : "Lamivudine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lamivudine"
        },
        {
          "language" : "fr-CH",
          "value" : "lamivudine"
        },
        {
          "language" : "de-CH",
          "value" : "Lamivudin"
        },
        {
          "language" : "it-CH",
          "value" : "lamivudina"
        }]
      },
      {
        "code" : "387562000",
        "display" : "Lamotrigine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lamotrigine"
        },
        {
          "language" : "fr-CH",
          "value" : "lamotrigine"
        },
        {
          "language" : "de-CH",
          "value" : "Lamotrigin"
        },
        {
          "language" : "it-CH",
          "value" : "lamotrigina"
        }]
      },
      {
        "code" : "395765000",
        "display" : "Lanreotide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lanreotide"
        },
        {
          "language" : "fr-CH",
          "value" : "lanréotide"
        },
        {
          "language" : "de-CH",
          "value" : "Lanreotid"
        },
        {
          "language" : "it-CH",
          "value" : "lanreotide"
        }]
      },
      {
        "code" : "386888004",
        "display" : "Lansoprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lansoprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "lansoprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Lansoprazol"
        },
        {
          "language" : "it-CH",
          "value" : "lansoprazolo"
        }]
      },
      {
        "code" : "414571007",
        "display" : "Lanthanum carbonate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lanthanum carbonate"
        },
        {
          "language" : "fr-CH",
          "value" : "lanthane(III) carbonate"
        },
        {
          "language" : "de-CH",
          "value" : "Lanthan(III) carbonat"
        },
        {
          "language" : "it-CH",
          "value" : "lantanio carbonato"
        }]
      },
      {
        "code" : "386926002",
        "display" : "Latanoprost (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Latanoprost"
        },
        {
          "language" : "fr-CH",
          "value" : "latanoprost"
        },
        {
          "language" : "de-CH",
          "value" : "Latanoprost"
        },
        {
          "language" : "it-CH",
          "value" : "latanoprost"
        }]
      },
      {
        "code" : "386981009",
        "display" : "Leflunomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Leflunomide"
        },
        {
          "language" : "fr-CH",
          "value" : "léflunomide"
        },
        {
          "language" : "de-CH",
          "value" : "Leflunomid"
        },
        {
          "language" : "it-CH",
          "value" : "leflunomide"
        }]
      },
      {
        "code" : "421471009",
        "display" : "Lenalidomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lenalidomide"
        },
        {
          "language" : "fr-CH",
          "value" : "lénalidomide"
        },
        {
          "language" : "de-CH",
          "value" : "Lenalidomid"
        },
        {
          "language" : "it-CH",
          "value" : "lenalidomide"
        }]
      },
      {
        "code" : "395767008",
        "display" : "Lenograstim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lenograstime"
        },
        {
          "language" : "fr-CH",
          "value" : "lénograstim"
        },
        {
          "language" : "de-CH",
          "value" : "Lenograstim"
        },
        {
          "language" : "it-CH",
          "value" : "lenograstim"
        }]
      },
      {
        "code" : "395986007",
        "display" : "Lercanidipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lercanidipine"
        },
        {
          "language" : "fr-CH",
          "value" : "lercanidipine"
        },
        {
          "language" : "de-CH",
          "value" : "Lercanidipin"
        },
        {
          "language" : "it-CH",
          "value" : "lercanidipina"
        }]
      },
      {
        "code" : "386911004",
        "display" : "Letrozole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Letrozole"
        },
        {
          "language" : "fr-CH",
          "value" : "létrozole"
        },
        {
          "language" : "de-CH",
          "value" : "Letrozol"
        },
        {
          "language" : "it-CH",
          "value" : "letrozolo"
        }]
      },
      {
        "code" : "397198002",
        "display" : "Leuprorelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Leuprorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "leuproréline"
        },
        {
          "language" : "de-CH",
          "value" : "Leuprorelin"
        },
        {
          "language" : "it-CH",
          "value" : "leuprorelina"
        }]
      },
      {
        "code" : "387000003",
        "display" : "Levetiracetam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levetiracetam"
        },
        {
          "language" : "fr-CH",
          "value" : "lévétiracétam"
        },
        {
          "language" : "de-CH",
          "value" : "Levetiracetam"
        },
        {
          "language" : "it-CH",
          "value" : "levetiracetam"
        }]
      },
      {
        "code" : "387011006",
        "display" : "Levobupivacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levobupivacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "lévobupivacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Levobupivacain"
        },
        {
          "language" : "it-CH",
          "value" : "levobupivacaina"
        }]
      },
      {
        "code" : "372554006",
        "display" : "Levocabastine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levocabastine"
        },
        {
          "language" : "fr-CH",
          "value" : "lévocabastine"
        },
        {
          "language" : "de-CH",
          "value" : "Levocabastin"
        },
        {
          "language" : "it-CH",
          "value" : "levocabastina"
        }]
      },
      {
        "code" : "387552007",
        "display" : "Levofloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "lévofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Levofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "levofloxacina"
        }]
      },
      {
        "code" : "387509007",
        "display" : "Levomepromazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levomepromazine"
        },
        {
          "language" : "fr-CH",
          "value" : "lévomépromazine"
        },
        {
          "language" : "de-CH",
          "value" : "Levomepromazin"
        },
        {
          "language" : "it-CH",
          "value" : "levomepromazina"
        }]
      },
      {
        "code" : "126109000",
        "display" : "Levonorgestrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levonorgestrel"
        },
        {
          "language" : "fr-CH",
          "value" : "lévonorgestrel"
        },
        {
          "language" : "de-CH",
          "value" : "Levonorgestrel"
        },
        {
          "language" : "it-CH",
          "value" : "levonorgestrel"
        }]
      },
      {
        "code" : "387480006",
        "display" : "Lidocaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lidocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "lidocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Lidocain"
        },
        {
          "language" : "it-CH",
          "value" : "lidocaina"
        }]
      },
      {
        "code" : "387056004",
        "display" : "Linezolid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Linezolid"
        },
        {
          "language" : "fr-CH",
          "value" : "linézolide"
        },
        {
          "language" : "de-CH",
          "value" : "Linezolid"
        },
        {
          "language" : "it-CH",
          "value" : "linezolid"
        }]
      },
      {
        "code" : "444828003",
        "display" : "Liraglutide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Liraglutide"
        },
        {
          "language" : "fr-CH",
          "value" : "liraglutide"
        },
        {
          "language" : "de-CH",
          "value" : "Liraglutid"
        },
        {
          "language" : "it-CH",
          "value" : "liraglutide"
        }]
      },
      {
        "code" : "386873009",
        "display" : "Lisinopril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lisinopril"
        },
        {
          "language" : "fr-CH",
          "value" : "lisinopril"
        },
        {
          "language" : "de-CH",
          "value" : "Lisinopril"
        },
        {
          "language" : "it-CH",
          "value" : "lisinopril"
        }]
      },
      {
        "code" : "708808004",
        "display" : "Lixisenatide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lixisenatide"
        },
        {
          "language" : "fr-CH",
          "value" : "lixisénatide"
        },
        {
          "language" : "de-CH",
          "value" : "Lixisenatid"
        },
        {
          "language" : "it-CH",
          "value" : "lixisenatide"
        }]
      },
      {
        "code" : "387227009",
        "display" : "Lomustine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lomustine"
        },
        {
          "language" : "fr-CH",
          "value" : "lomustine"
        },
        {
          "language" : "de-CH",
          "value" : "Lomustin"
        },
        {
          "language" : "it-CH",
          "value" : "lomustina"
        }]
      },
      {
        "code" : "387067003",
        "display" : "Lopinavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lopinavir"
        },
        {
          "language" : "fr-CH",
          "value" : "lopinavir"
        },
        {
          "language" : "de-CH",
          "value" : "Lopinavir"
        },
        {
          "language" : "it-CH",
          "value" : "lopinavir"
        }]
      },
      {
        "code" : "386884002",
        "display" : "Loratadine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Loratadine"
        },
        {
          "language" : "fr-CH",
          "value" : "loratadine"
        },
        {
          "language" : "de-CH",
          "value" : "Loratadin"
        },
        {
          "language" : "it-CH",
          "value" : "loratadina"
        }]
      },
      {
        "code" : "387106007",
        "display" : "Lorazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lorazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "lorazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Lorazepam"
        },
        {
          "language" : "it-CH",
          "value" : "lorazepam"
        }]
      },
      {
        "code" : "387570005",
        "display" : "Lormetazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lormetazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "lormétazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Lormetazepam"
        },
        {
          "language" : "it-CH",
          "value" : "lormetazepam"
        }]
      },
      {
        "code" : "373567002",
        "display" : "Losartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Losartan"
        },
        {
          "language" : "fr-CH",
          "value" : "losartan"
        },
        {
          "language" : "de-CH",
          "value" : "Losartan"
        },
        {
          "language" : "it-CH",
          "value" : "losartan"
        }]
      },
      {
        "code" : "415248001",
        "display" : "Lutropin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lutropin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "lutropine alfa"
        },
        {
          "language" : "de-CH",
          "value" : "Lutropin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "lutropina alfa"
        }]
      },
      {
        "code" : "8030004",
        "display" : "Macrogol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Macrogol"
        },
        {
          "language" : "fr-CH",
          "value" : "macrogol"
        },
        {
          "language" : "de-CH",
          "value" : "Macrogol"
        },
        {
          "language" : "it-CH",
          "value" : "macrogol"
        }]
      },
      {
        "code" : "387168006",
        "display" : "Mannitol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mannitol"
        },
        {
          "language" : "fr-CH",
          "value" : "mannitol"
        },
        {
          "language" : "de-CH",
          "value" : "Mannitol"
        },
        {
          "language" : "it-CH",
          "value" : "mannitolo"
        }]
      },
      {
        "code" : "429603001",
        "display" : "Maraviroc (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Maraviroc"
        },
        {
          "language" : "fr-CH",
          "value" : "maraviroc"
        },
        {
          "language" : "de-CH",
          "value" : "Maraviroc"
        },
        {
          "language" : "it-CH",
          "value" : "maraviroc"
        }]
      },
      {
        "code" : "387311004",
        "display" : "Mebendazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mebendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "mébendazole"
        },
        {
          "language" : "de-CH",
          "value" : "Mebendazol"
        },
        {
          "language" : "it-CH",
          "value" : "mebendazolo"
        }]
      },
      {
        "code" : "419830007",
        "display" : "Mebeverine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mebeverine"
        },
        {
          "language" : "fr-CH",
          "value" : "mébévérine"
        },
        {
          "language" : "de-CH",
          "value" : "Mebeverin"
        },
        {
          "language" : "it-CH",
          "value" : "mebeverina"
        }]
      },
      {
        "code" : "372879002",
        "display" : "Meclozine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meclozine"
        },
        {
          "language" : "fr-CH",
          "value" : "méclozine"
        },
        {
          "language" : "de-CH",
          "value" : "Meclozin"
        },
        {
          "language" : "it-CH",
          "value" : "meclozina"
        }]
      },
      {
        "code" : "387185008",
        "display" : "Mefenamic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mefenamic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide méfénamique"
        },
        {
          "language" : "de-CH",
          "value" : "Mefenaminsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido mefenamico"
        }]
      },
      {
        "code" : "387505001",
        "display" : "Mefloquine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mefloquine"
        },
        {
          "language" : "fr-CH",
          "value" : "méfloquine"
        },
        {
          "language" : "de-CH",
          "value" : "Mefloquin"
        },
        {
          "language" : "it-CH",
          "value" : "meflochina"
        }]
      },
      {
        "code" : "41199001",
        "display" : "Melatonin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Melatonin"
        },
        {
          "language" : "fr-CH",
          "value" : "mélatonine"
        },
        {
          "language" : "de-CH",
          "value" : "Melatonin"
        },
        {
          "language" : "it-CH",
          "value" : "melatonina"
        }]
      },
      {
        "code" : "442519006",
        "display" : "Melperone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Melperone"
        },
        {
          "language" : "fr-CH",
          "value" : "melpérone"
        },
        {
          "language" : "de-CH",
          "value" : "Melperon"
        },
        {
          "language" : "it-CH",
          "value" : "melperone"
        }]
      },
      {
        "code" : "387297002",
        "display" : "Melphalan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Melphalan"
        },
        {
          "language" : "fr-CH",
          "value" : "melphalan"
        },
        {
          "language" : "de-CH",
          "value" : "Melphalan"
        },
        {
          "language" : "it-CH",
          "value" : "melphalan"
        }]
      },
      {
        "code" : "59560006",
        "display" : "Mepivacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mepivacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "mépivacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Mepivacain"
        },
        {
          "language" : "it-CH",
          "value" : "mepivacaina"
        }]
      },
      {
        "code" : "373457005",
        "display" : "Mercaptamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mercaptamine"
        },
        {
          "language" : "fr-CH",
          "value" : "mercaptamine"
        },
        {
          "language" : "de-CH",
          "value" : "Mercaptamin"
        },
        {
          "language" : "it-CH",
          "value" : "mercaptamina"
        }]
      },
      {
        "code" : "387540000",
        "display" : "Meropenem (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meropenem"
        },
        {
          "language" : "fr-CH",
          "value" : "méropénem"
        },
        {
          "language" : "de-CH",
          "value" : "Meropenem"
        },
        {
          "language" : "it-CH",
          "value" : "meropenem"
        }]
      },
      {
        "code" : "387501005",
        "display" : "Mesalazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mesalazine"
        },
        {
          "language" : "fr-CH",
          "value" : "mésalazine"
        },
        {
          "language" : "de-CH",
          "value" : "Mesalazin"
        },
        {
          "language" : "it-CH",
          "value" : "mesalazina"
        }]
      },
      {
        "code" : "386922000",
        "display" : "Mesna (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mesna"
        },
        {
          "language" : "fr-CH",
          "value" : "mesna"
        },
        {
          "language" : "de-CH",
          "value" : "Mesna"
        },
        {
          "language" : "it-CH",
          "value" : "mesna"
        }]
      },
      {
        "code" : "372567009",
        "display" : "Metformin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metformin"
        },
        {
          "language" : "fr-CH",
          "value" : "metformine"
        },
        {
          "language" : "de-CH",
          "value" : "Metformin"
        },
        {
          "language" : "it-CH",
          "value" : "metformina"
        }]
      },
      {
        "code" : "387286002",
        "display" : "Methadone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methadone"
        },
        {
          "language" : "fr-CH",
          "value" : "méthadone"
        },
        {
          "language" : "de-CH",
          "value" : "Methadon"
        },
        {
          "language" : "it-CH",
          "value" : "metadone"
        }]
      },
      {
        "code" : "387381009",
        "display" : "Methotrexate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methotrexate"
        },
        {
          "language" : "fr-CH",
          "value" : "méthotrexate"
        },
        {
          "language" : "de-CH",
          "value" : "Methotrexat"
        },
        {
          "language" : "it-CH",
          "value" : "metotrexato"
        }]
      },
      {
        "code" : "41062004",
        "display" : "Methoxsalen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methoxsalen"
        },
        {
          "language" : "fr-CH",
          "value" : "méthoxsalène"
        },
        {
          "language" : "de-CH",
          "value" : "Methoxsalen"
        },
        {
          "language" : "it-CH",
          "value" : "metoxsalene"
        }]
      },
      {
        "code" : "425913002",
        "display" : "Methoxy polyethylene glycol-epoetin beta (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methoxy polyethylene glycol-epoetin beta"
        },
        {
          "language" : "fr-CH",
          "value" : "époétine bêta pégylée"
        },
        {
          "language" : "de-CH",
          "value" : "PEG-Epoetin beta"
        },
        {
          "language" : "it-CH",
          "value" : "metossipolietilenglicole-epoetina beta"
        }]
      },
      {
        "code" : "373337007",
        "display" : "Methylphenidate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methylphenidate"
        },
        {
          "language" : "fr-CH",
          "value" : "méthylphénidate"
        },
        {
          "language" : "de-CH",
          "value" : "Methylphenidat"
        },
        {
          "language" : "it-CH",
          "value" : "metilfenidato"
        }]
      },
      {
        "code" : "116593003",
        "display" : "Methylprednisolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methylprednisolone"
        },
        {
          "language" : "fr-CH",
          "value" : "méthylprednisolone"
        },
        {
          "language" : "de-CH",
          "value" : "Methylprednisolon"
        },
        {
          "language" : "it-CH",
          "value" : "metilprednisolone"
        }]
      },
      {
        "code" : "372776000",
        "display" : "Metoclopramide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metoclopramide"
        },
        {
          "language" : "fr-CH",
          "value" : "métoclopramide"
        },
        {
          "language" : "de-CH",
          "value" : "Metoclopramid"
        },
        {
          "language" : "it-CH",
          "value" : "metoclopramide"
        }]
      },
      {
        "code" : "387123003",
        "display" : "Metolazone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metolazone"
        },
        {
          "language" : "fr-CH",
          "value" : "métolazone"
        },
        {
          "language" : "de-CH",
          "value" : "Metolazon"
        },
        {
          "language" : "it-CH",
          "value" : "metolazone"
        }]
      },
      {
        "code" : "372602008",
        "display" : "Metronidazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metronidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "métronidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Metronidazol"
        },
        {
          "language" : "it-CH",
          "value" : "metronidazolo"
        }]
      },
      {
        "code" : "372738006",
        "display" : "Miconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Miconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "miconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Miconazol"
        },
        {
          "language" : "it-CH",
          "value" : "miconazolo"
        }]
      },
      {
        "code" : "373476007",
        "display" : "Midazolam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Midazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "midazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Midazolam"
        },
        {
          "language" : "it-CH",
          "value" : "midazolam"
        }]
      },
      {
        "code" : "395796009",
        "display" : "Mifepristone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mifepristone"
        },
        {
          "language" : "fr-CH",
          "value" : "mifépristone"
        },
        {
          "language" : "de-CH",
          "value" : "Mifepriston"
        },
        {
          "language" : "it-CH",
          "value" : "mifepristone"
        }]
      },
      {
        "code" : "373441005",
        "display" : "Milrinone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Milrinone"
        },
        {
          "language" : "fr-CH",
          "value" : "milrinone"
        },
        {
          "language" : "de-CH",
          "value" : "Milrinon"
        },
        {
          "language" : "it-CH",
          "value" : "milrinone"
        }]
      },
      {
        "code" : "372653009",
        "display" : "Minocycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Minocycline"
        },
        {
          "language" : "fr-CH",
          "value" : "minocycline"
        },
        {
          "language" : "de-CH",
          "value" : "Minocyclin"
        },
        {
          "language" : "it-CH",
          "value" : "minociclina"
        }]
      },
      {
        "code" : "387272001",
        "display" : "Minoxidil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Minoxidil"
        },
        {
          "language" : "fr-CH",
          "value" : "minoxidil"
        },
        {
          "language" : "de-CH",
          "value" : "Minoxidil"
        },
        {
          "language" : "it-CH",
          "value" : "minoxidil"
        }]
      },
      {
        "code" : "703803006",
        "display" : "Mirabegron (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mirabegron"
        },
        {
          "language" : "fr-CH",
          "value" : "mirabégron"
        },
        {
          "language" : "de-CH",
          "value" : "Mirabegron"
        },
        {
          "language" : "it-CH",
          "value" : "mirabegron"
        }]
      },
      {
        "code" : "386847004",
        "display" : "Mirtazapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mirtazapine"
        },
        {
          "language" : "fr-CH",
          "value" : "mirtazapine"
        },
        {
          "language" : "de-CH",
          "value" : "Mirtazapin"
        },
        {
          "language" : "it-CH",
          "value" : "mirtazapina"
        }]
      },
      {
        "code" : "387242007",
        "display" : "Misoprostol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Misoprostol"
        },
        {
          "language" : "fr-CH",
          "value" : "misoprostol"
        },
        {
          "language" : "de-CH",
          "value" : "Misoprostol"
        },
        {
          "language" : "it-CH",
          "value" : "misoprostolo"
        }]
      },
      {
        "code" : "387331000",
        "display" : "Mitomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mitomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "mitomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Mitomycin"
        },
        {
          "language" : "it-CH",
          "value" : "mitomicina"
        }]
      },
      {
        "code" : "386913001",
        "display" : "Mitoxantrone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mitoxantrone"
        },
        {
          "language" : "fr-CH",
          "value" : "mitoxantrone"
        },
        {
          "language" : "de-CH",
          "value" : "Mitoxantron"
        },
        {
          "language" : "it-CH",
          "value" : "mitoxantrone"
        }]
      },
      {
        "code" : "395800003",
        "display" : "Moclobemide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Moclobemide"
        },
        {
          "language" : "fr-CH",
          "value" : "moclobémide"
        },
        {
          "language" : "de-CH",
          "value" : "Moclobemid"
        },
        {
          "language" : "it-CH",
          "value" : "moclobemide"
        }]
      },
      {
        "code" : "387004007",
        "display" : "Modafinil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Modafinil"
        },
        {
          "language" : "fr-CH",
          "value" : "modafinil"
        },
        {
          "language" : "de-CH",
          "value" : "Modafinil"
        },
        {
          "language" : "it-CH",
          "value" : "modafinil"
        }]
      },
      {
        "code" : "698196008",
        "display" : "Molsidomine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Molsidomine"
        },
        {
          "language" : "fr-CH",
          "value" : "molsidomine"
        },
        {
          "language" : "de-CH",
          "value" : "Molsidomin"
        },
        {
          "language" : "it-CH",
          "value" : "molsidomina"
        }]
      },
      {
        "code" : "395990009",
        "display" : "Mometasone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mometasone"
        },
        {
          "language" : "fr-CH",
          "value" : "mométasone"
        },
        {
          "language" : "de-CH",
          "value" : "Mometason"
        },
        {
          "language" : "it-CH",
          "value" : "mometasone"
        }]
      },
      {
        "code" : "373728005",
        "display" : "Montelukast (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Montelukast"
        },
        {
          "language" : "fr-CH",
          "value" : "montélukast"
        },
        {
          "language" : "de-CH",
          "value" : "Montelukast"
        },
        {
          "language" : "it-CH",
          "value" : "montelukast"
        }]
      },
      {
        "code" : "373529000",
        "display" : "Morphine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Morphine"
        },
        {
          "language" : "fr-CH",
          "value" : "morphine"
        },
        {
          "language" : "de-CH",
          "value" : "Morphin"
        },
        {
          "language" : "it-CH",
          "value" : "morfina"
        }]
      },
      {
        "code" : "412439003",
        "display" : "Moxifloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Moxifloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "moxifloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Moxifloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "moxifloxacina"
        }]
      },
      {
        "code" : "395805008",
        "display" : "Moxonidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Moxonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "moxonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Moxonidin"
        },
        {
          "language" : "it-CH",
          "value" : "moxonidina"
        }]
      },
      {
        "code" : "387397004",
        "display" : "Mupirocin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mupirocin"
        },
        {
          "language" : "fr-CH",
          "value" : "mupirocine"
        },
        {
          "language" : "de-CH",
          "value" : "Mupirocin"
        },
        {
          "language" : "it-CH",
          "value" : "mupirocina"
        }]
      },
      {
        "code" : "386976000",
        "display" : "Mycophenolate mofetil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mycophenolate mofetil"
        },
        {
          "language" : "fr-CH",
          "value" : "mycophénolate mofétil"
        },
        {
          "language" : "de-CH",
          "value" : "Mycophenolat mofetil"
        },
        {
          "language" : "it-CH",
          "value" : "micofenolato mofetile"
        }]
      },
      {
        "code" : "387482003",
        "display" : "Nadolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nadolol"
        },
        {
          "language" : "fr-CH",
          "value" : "nadolol"
        },
        {
          "language" : "de-CH",
          "value" : "Nadolol"
        },
        {
          "language" : "it-CH",
          "value" : "nadololo"
        }]
      },
      {
        "code" : "698278006",
        "display" : "Nadroparin calcium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nadroparin calcium"
        },
        {
          "language" : "fr-CH",
          "value" : "nadroparine calcique"
        },
        {
          "language" : "de-CH",
          "value" : "Nadroparin calcium"
        },
        {
          "language" : "it-CH",
          "value" : "nadroparina calcica"
        }]
      },
      {
        "code" : "395992001",
        "display" : "Naftidrofuryl (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naftidrofuryl"
        },
        {
          "language" : "fr-CH",
          "value" : "naftidrofuryl"
        },
        {
          "language" : "de-CH",
          "value" : "Naftidrofuryl"
        },
        {
          "language" : "it-CH",
          "value" : "naftidrofurile"
        }]
      },
      {
        "code" : "109098006",
        "display" : "Nalmefene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nalmefene"
        },
        {
          "language" : "fr-CH",
          "value" : "nalméfène"
        },
        {
          "language" : "de-CH",
          "value" : "Nalmefen"
        },
        {
          "language" : "it-CH",
          "value" : "nalmefene"
        }]
      },
      {
        "code" : "372890007",
        "display" : "Naloxone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naloxone"
        },
        {
          "language" : "fr-CH",
          "value" : "naloxone"
        },
        {
          "language" : "de-CH",
          "value" : "Naloxon"
        },
        {
          "language" : "it-CH",
          "value" : "naloxone"
        }]
      },
      {
        "code" : "373546002",
        "display" : "Naltrexone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naltrexone"
        },
        {
          "language" : "fr-CH",
          "value" : "naltrexone"
        },
        {
          "language" : "de-CH",
          "value" : "Naltrexon"
        },
        {
          "language" : "it-CH",
          "value" : "naltrexone"
        }]
      },
      {
        "code" : "372803000",
        "display" : "Naphazoline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naphazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "naphazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Naphazolin"
        },
        {
          "language" : "it-CH",
          "value" : "nafazolina"
        }]
      },
      {
        "code" : "372588000",
        "display" : "Naproxen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naproxen"
        },
        {
          "language" : "fr-CH",
          "value" : "naproxène"
        },
        {
          "language" : "de-CH",
          "value" : "Naproxen"
        },
        {
          "language" : "it-CH",
          "value" : "naprossene"
        }]
      },
      {
        "code" : "363571003",
        "display" : "Naratriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naratriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "naratriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Naratriptan"
        },
        {
          "language" : "it-CH",
          "value" : "naratriptan"
        }]
      },
      {
        "code" : "414805007",
        "display" : "Natalizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Natalizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "natalizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Natalizumab"
        },
        {
          "language" : "it-CH",
          "value" : "natalizumab"
        }]
      },
      {
        "code" : "387070004",
        "display" : "Nateglinide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nateglinide"
        },
        {
          "language" : "fr-CH",
          "value" : "natéglinide"
        },
        {
          "language" : "de-CH",
          "value" : "Nateglinid"
        },
        {
          "language" : "it-CH",
          "value" : "nateglinide"
        }]
      },
      {
        "code" : "395808005",
        "display" : "Nebivolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nebivolol"
        },
        {
          "language" : "fr-CH",
          "value" : "nébivolol"
        },
        {
          "language" : "de-CH",
          "value" : "Nebivolol"
        },
        {
          "language" : "it-CH",
          "value" : "nebivololo"
        }]
      },
      {
        "code" : "373445001",
        "display" : "Nelfinavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nelfinavir"
        },
        {
          "language" : "fr-CH",
          "value" : "nelfinavir"
        },
        {
          "language" : "de-CH",
          "value" : "Nelfinavir"
        },
        {
          "language" : "it-CH",
          "value" : "nelfinavir"
        }]
      },
      {
        "code" : "373528008",
        "display" : "Neomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Neomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "néomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Neomycin"
        },
        {
          "language" : "it-CH",
          "value" : "neomicina"
        }]
      },
      {
        "code" : "373346001",
        "display" : "Neostigmine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Neostigmine"
        },
        {
          "language" : "fr-CH",
          "value" : "néostigmine"
        },
        {
          "language" : "de-CH",
          "value" : "Neostigmin"
        },
        {
          "language" : "it-CH",
          "value" : "neostigmina"
        }]
      },
      {
        "code" : "386898005",
        "display" : "Nevirapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nevirapine"
        },
        {
          "language" : "fr-CH",
          "value" : "névirapine"
        },
        {
          "language" : "de-CH",
          "value" : "Nevirapin"
        },
        {
          "language" : "it-CH",
          "value" : "nevirapina"
        }]
      },
      {
        "code" : "68540007",
        "display" : "Nicotine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nicotine"
        },
        {
          "language" : "fr-CH",
          "value" : "nicotine"
        },
        {
          "language" : "de-CH",
          "value" : "Nicotin"
        },
        {
          "language" : "it-CH",
          "value" : "nicotina"
        }]
      },
      {
        "code" : "387490003",
        "display" : "Nifedipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nifedipine"
        },
        {
          "language" : "fr-CH",
          "value" : "nifédipine"
        },
        {
          "language" : "de-CH",
          "value" : "Nifedipin"
        },
        {
          "language" : "it-CH",
          "value" : "nifedipina"
        }]
      },
      {
        "code" : "387502003",
        "display" : "Nimodipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nimodipine"
        },
        {
          "language" : "fr-CH",
          "value" : "nimodipine"
        },
        {
          "language" : "de-CH",
          "value" : "Nimodipin"
        },
        {
          "language" : "it-CH",
          "value" : "nimodipina"
        }]
      },
      {
        "code" : "712494002",
        "display" : "Nintedanib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nintedanib"
        },
        {
          "language" : "fr-CH",
          "value" : "nintédanib"
        },
        {
          "language" : "de-CH",
          "value" : "Nintedanib"
        },
        {
          "language" : "it-CH",
          "value" : "nintedanib"
        }]
      },
      {
        "code" : "385996000",
        "display" : "Nitisinone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nitisinone"
        },
        {
          "language" : "fr-CH",
          "value" : "nitisinone"
        },
        {
          "language" : "de-CH",
          "value" : "Nitisinon"
        },
        {
          "language" : "it-CH",
          "value" : "nitisinone"
        }]
      },
      {
        "code" : "387449001",
        "display" : "Nitrazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nitrazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "nitrazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Nitrazepam"
        },
        {
          "language" : "it-CH",
          "value" : "nitrazepam"
        }]
      },
      {
        "code" : "373543005",
        "display" : "Nitrofurantoin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nitrofurantoin"
        },
        {
          "language" : "fr-CH",
          "value" : "nitrofurantoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Nitrofurantoin"
        },
        {
          "language" : "it-CH",
          "value" : "nitrofurantoina"
        }]
      },
      {
        "code" : "704191007",
        "display" : "Nivolumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nivolumab"
        },
        {
          "language" : "fr-CH",
          "value" : "nivolumab"
        },
        {
          "language" : "de-CH",
          "value" : "Nivolumab"
        },
        {
          "language" : "it-CH",
          "value" : "nivolumab"
        }]
      },
      {
        "code" : "698277001",
        "display" : "Nomegestrol acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nomegestrol acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "nomégestrol acétate"
        },
        {
          "language" : "de-CH",
          "value" : "Nomegestrol acetat"
        },
        {
          "language" : "it-CH",
          "value" : "nomegestrolo acetato"
        }]
      },
      {
        "code" : "126102009",
        "display" : "Norethisterone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Norethisterone"
        },
        {
          "language" : "fr-CH",
          "value" : "noréthistérone"
        },
        {
          "language" : "de-CH",
          "value" : "Norethisteron"
        },
        {
          "language" : "it-CH",
          "value" : "noretisterone"
        }]
      },
      {
        "code" : "387271008",
        "display" : "Norfloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Norfloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "norfloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Norfloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "norfloxacina"
        }]
      },
      {
        "code" : "126106007",
        "display" : "Norgestrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Norgestrel"
        },
        {
          "language" : "fr-CH",
          "value" : "norgestrel"
        },
        {
          "language" : "de-CH",
          "value" : "Norgestrel"
        },
        {
          "language" : "it-CH",
          "value" : "norgestrel"
        }]
      },
      {
        "code" : "372652004",
        "display" : "Nortriptyline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nortriptyline"
        },
        {
          "language" : "fr-CH",
          "value" : "nortriptyline"
        },
        {
          "language" : "de-CH",
          "value" : "Nortriptylin"
        },
        {
          "language" : "it-CH",
          "value" : "nortriptilina"
        }]
      },
      {
        "code" : "387437002",
        "display" : "Noscapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Noscapine"
        },
        {
          "language" : "fr-CH",
          "value" : "noscapine"
        },
        {
          "language" : "de-CH",
          "value" : "Noscapin"
        },
        {
          "language" : "it-CH",
          "value" : "noscapina"
        }]
      },
      {
        "code" : "387048002",
        "display" : "Nystatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nystatin"
        },
        {
          "language" : "fr-CH",
          "value" : "nystatine"
        },
        {
          "language" : "de-CH",
          "value" : "Nystatin"
        },
        {
          "language" : "it-CH",
          "value" : "nistatina"
        }]
      },
      {
        "code" : "710287009",
        "display" : "Obinutuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Obinutuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "obinutuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Obinutuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "obinutuzumab"
        }]
      },
      {
        "code" : "733464008",
        "display" : "Ocrelizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ocrelizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ocrélizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ocrelizumab"
        },
        {
          "language" : "it-CH",
          "value" : "ocrelizumab"
        }]
      },
      {
        "code" : "109053000",
        "display" : "Octreotide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Octreotide"
        },
        {
          "language" : "fr-CH",
          "value" : "octréotide"
        },
        {
          "language" : "de-CH",
          "value" : "Octreotid"
        },
        {
          "language" : "it-CH",
          "value" : "octreotide"
        }]
      },
      {
        "code" : "387551000",
        "display" : "Ofloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ofloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "ofloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Ofloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "ofloxacina"
        }]
      },
      {
        "code" : "386849001",
        "display" : "Olanzapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Olanzapine"
        },
        {
          "language" : "fr-CH",
          "value" : "olanzapine"
        },
        {
          "language" : "de-CH",
          "value" : "Olanzapin"
        },
        {
          "language" : "it-CH",
          "value" : "olanzapina"
        }]
      },
      {
        "code" : "704459002",
        "display" : "Olodaterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Olodaterol"
        },
        {
          "language" : "fr-CH",
          "value" : "olodatérol"
        },
        {
          "language" : "de-CH",
          "value" : "Olodaterol"
        },
        {
          "language" : "it-CH",
          "value" : "olodaterolo"
        }]
      },
      {
        "code" : "406443008",
        "display" : "Omalizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Omalizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "omalizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Omalizumab"
        },
        {
          "language" : "it-CH",
          "value" : "omalizumab"
        }]
      },
      {
        "code" : "387137007",
        "display" : "Omeprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Omeprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "oméprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Omeprazol"
        },
        {
          "language" : "it-CH",
          "value" : "omeprazolo"
        }]
      },
      {
        "code" : "372487007",
        "display" : "Ondansetron (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ondansetron"
        },
        {
          "language" : "fr-CH",
          "value" : "ondansétron"
        },
        {
          "language" : "de-CH",
          "value" : "Ondansetron"
        },
        {
          "language" : "it-CH",
          "value" : "ondansetron"
        }]
      },
      {
        "code" : "387007000",
        "display" : "Orlistat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Orlistat"
        },
        {
          "language" : "fr-CH",
          "value" : "orlistat"
        },
        {
          "language" : "de-CH",
          "value" : "Orlistat"
        },
        {
          "language" : "it-CH",
          "value" : "orlistat"
        }]
      },
      {
        "code" : "442924004",
        "display" : "Ornidazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ornidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "ornidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Ornidazol"
        },
        {
          "language" : "it-CH",
          "value" : "ornidazolo"
        }]
      },
      {
        "code" : "412261005",
        "display" : "Oseltamivir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oseltamivir"
        },
        {
          "language" : "fr-CH",
          "value" : "oseltamivir"
        },
        {
          "language" : "de-CH",
          "value" : "Oseltamivir"
        },
        {
          "language" : "it-CH",
          "value" : "oseltamivir"
        }]
      },
      {
        "code" : "395814003",
        "display" : "Oxaliplatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxaliplatin"
        },
        {
          "language" : "fr-CH",
          "value" : "oxaliplatine"
        },
        {
          "language" : "de-CH",
          "value" : "Oxaliplatin"
        },
        {
          "language" : "it-CH",
          "value" : "oxaliplatino"
        }]
      },
      {
        "code" : "387455006",
        "display" : "Oxazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "oxazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Oxazepam"
        },
        {
          "language" : "it-CH",
          "value" : "oxazepam"
        }]
      },
      {
        "code" : "387025007",
        "display" : "Oxcarbazepine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxcarbazepine"
        },
        {
          "language" : "fr-CH",
          "value" : "oxcarbazépine"
        },
        {
          "language" : "de-CH",
          "value" : "Oxcarbazepin"
        },
        {
          "language" : "it-CH",
          "value" : "oxcarbazepina"
        }]
      },
      {
        "code" : "772837001",
        "display" : "Oxomemazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxomemazine"
        },
        {
          "language" : "fr-CH",
          "value" : "oxomémazine"
        },
        {
          "language" : "de-CH",
          "value" : "Oxomemazin"
        },
        {
          "language" : "it-CH",
          "value" : "oxomemazina"
        }]
      },
      {
        "code" : "52140009",
        "display" : "Oxybuprocaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxybuprocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "oxybuprocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Oxybuprocain"
        },
        {
          "language" : "it-CH",
          "value" : "oxibuprocaina"
        }]
      },
      {
        "code" : "372717000",
        "display" : "Oxybutynin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxybutynin"
        },
        {
          "language" : "fr-CH",
          "value" : "oxybutynine"
        },
        {
          "language" : "de-CH",
          "value" : "Oxybutynin"
        },
        {
          "language" : "it-CH",
          "value" : "ossibutinina"
        }]
      },
      {
        "code" : "372675006",
        "display" : "Oxytetracycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxytetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "oxytétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Oxytetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "ossitetraciclina"
        }]
      },
      {
        "code" : "112115002",
        "display" : "Oxytocin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxytocin"
        },
        {
          "language" : "fr-CH",
          "value" : "oxytocine"
        },
        {
          "language" : "de-CH",
          "value" : "Oxytocin"
        },
        {
          "language" : "it-CH",
          "value" : "ossitocina"
        }]
      },
      {
        "code" : "387374002",
        "display" : "Paclitaxel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paclitaxel"
        },
        {
          "language" : "fr-CH",
          "value" : "paclitaxel"
        },
        {
          "language" : "de-CH",
          "value" : "Paclitaxel"
        },
        {
          "language" : "it-CH",
          "value" : "paclitaxel"
        }]
      },
      {
        "code" : "426276000",
        "display" : "Paliperidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paliperidone"
        },
        {
          "language" : "fr-CH",
          "value" : "palipéridone"
        },
        {
          "language" : "de-CH",
          "value" : "Paliperidon"
        },
        {
          "language" : "it-CH",
          "value" : "paliperidone"
        }]
      },
      {
        "code" : "386900007",
        "display" : "Palivizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Palivizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "palivizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Palivizumab"
        },
        {
          "language" : "it-CH",
          "value" : "palivizumab"
        }]
      },
      {
        "code" : "404852008",
        "display" : "Palonosetron (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Palonosetron"
        },
        {
          "language" : "fr-CH",
          "value" : "palonosétron"
        },
        {
          "language" : "de-CH",
          "value" : "Palonosetron"
        },
        {
          "language" : "it-CH",
          "value" : "palonosetron"
        }]
      },
      {
        "code" : "395821003",
        "display" : "Pantoprazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pantoprazole"
        },
        {
          "language" : "fr-CH",
          "value" : "pantoprazole"
        },
        {
          "language" : "de-CH",
          "value" : "Pantoprazol"
        },
        {
          "language" : "it-CH",
          "value" : "pantoprazolo"
        }]
      },
      {
        "code" : "86431009",
        "display" : "Pantothenic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pantothenic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide pantothénique"
        },
        {
          "language" : "de-CH",
          "value" : "Pantothensäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido pantotenico"
        }]
      },
      {
        "code" : "372784001",
        "display" : "Papaverine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Papaverine"
        },
        {
          "language" : "fr-CH",
          "value" : "papavérine"
        },
        {
          "language" : "de-CH",
          "value" : "Papaverin"
        },
        {
          "language" : "it-CH",
          "value" : "papaverina"
        }]
      },
      {
        "code" : "387517004",
        "display" : "Paracetamol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paracetamol"
        },
        {
          "language" : "fr-CH",
          "value" : "paracétamol"
        },
        {
          "language" : "de-CH",
          "value" : "Paracetamol"
        },
        {
          "language" : "it-CH",
          "value" : "paracetamolo"
        }]
      },
      {
        "code" : "255667006",
        "display" : "Paraffin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paraffin"
        },
        {
          "language" : "fr-CH",
          "value" : "paraffine"
        },
        {
          "language" : "de-CH",
          "value" : "Paraffin"
        },
        {
          "language" : "it-CH",
          "value" : "paraffina"
        }]
      },
      {
        "code" : "372595009",
        "display" : "Paroxetine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paroxetine"
        },
        {
          "language" : "fr-CH",
          "value" : "paroxétine"
        },
        {
          "language" : "de-CH",
          "value" : "Paroxetin"
        },
        {
          "language" : "it-CH",
          "value" : "paroxetina"
        }]
      },
      {
        "code" : "108814000",
        "display" : "Pegaspargase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pegaspargase"
        },
        {
          "language" : "fr-CH",
          "value" : "pégaspargase"
        },
        {
          "language" : "de-CH",
          "value" : "Pegaspargase"
        },
        {
          "language" : "it-CH",
          "value" : "pegaspargase"
        }]
      },
      {
        "code" : "385544005",
        "display" : "Pegfilgrastim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pegfilgrastim"
        },
        {
          "language" : "fr-CH",
          "value" : "pegfilgrastim"
        },
        {
          "language" : "de-CH",
          "value" : "Pegfilgrastim"
        },
        {
          "language" : "it-CH",
          "value" : "pegfilgrastim"
        }]
      },
      {
        "code" : "421559001",
        "display" : "Peginterferon alfa-2a (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Peginterferon alfa-2a"
        },
        {
          "language" : "fr-CH",
          "value" : "peginterféron alfa-2a"
        },
        {
          "language" : "de-CH",
          "value" : "Peginterferon alfa-2a"
        },
        {
          "language" : "it-CH",
          "value" : "peginterferone alfa-2a"
        }]
      },
      {
        "code" : "716125002",
        "display" : "Pembrolizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pembrolizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "pembrolizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Pembrolizumab"
        },
        {
          "language" : "it-CH",
          "value" : "pembrolizumab"
        }]
      },
      {
        "code" : "409159000",
        "display" : "Pemetrexed (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pemetrexed"
        },
        {
          "language" : "fr-CH",
          "value" : "pémétrexed"
        },
        {
          "language" : "de-CH",
          "value" : "Pemetrexed"
        },
        {
          "language" : "it-CH",
          "value" : "pemetrexed"
        }]
      },
      {
        "code" : "386939003",
        "display" : "Penciclovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Penciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "penciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Penciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "penciclovir"
        }]
      },
      {
        "code" : "372916001",
        "display" : "Perindopril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Perindopril"
        },
        {
          "language" : "fr-CH",
          "value" : "périndopril"
        },
        {
          "language" : "de-CH",
          "value" : "Perindopril"
        },
        {
          "language" : "it-CH",
          "value" : "perindopril"
        }]
      },
      {
        "code" : "410457007",
        "display" : "Permethrin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Permethrin"
        },
        {
          "language" : "fr-CH",
          "value" : "perméthrine"
        },
        {
          "language" : "de-CH",
          "value" : "Permethrin"
        },
        {
          "language" : "it-CH",
          "value" : "permetrina"
        }]
      },
      {
        "code" : "704226002",
        "display" : "Pertuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pertuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "pertuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Pertuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "pertuzumab"
        }]
      },
      {
        "code" : "387298007",
        "display" : "Pethidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pethidine"
        },
        {
          "language" : "fr-CH",
          "value" : "péthidine"
        },
        {
          "language" : "de-CH",
          "value" : "Pethidin"
        },
        {
          "language" : "it-CH",
          "value" : "petidina"
        }]
      },
      {
        "code" : "55486005",
        "display" : "Phenazone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenazone"
        },
        {
          "language" : "fr-CH",
          "value" : "phénazone"
        },
        {
          "language" : "de-CH",
          "value" : "Phenazon"
        },
        {
          "language" : "it-CH",
          "value" : "fenazone"
        }]
      },
      {
        "code" : "373500002",
        "display" : "Pheniramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pheniramine"
        },
        {
          "language" : "fr-CH",
          "value" : "phéniramine"
        },
        {
          "language" : "de-CH",
          "value" : "Pheniramin"
        },
        {
          "language" : "it-CH",
          "value" : "feniramina"
        }]
      },
      {
        "code" : "373505007",
        "display" : "Phenobarbital (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenobarbital"
        },
        {
          "language" : "fr-CH",
          "value" : "phénobarbital"
        },
        {
          "language" : "de-CH",
          "value" : "Phenobarbital"
        },
        {
          "language" : "it-CH",
          "value" : "fenobarbital"
        }]
      },
      {
        "code" : "59488002",
        "display" : "Phenprocoumon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenprocoumon"
        },
        {
          "language" : "fr-CH",
          "value" : "phenprocoumone"
        },
        {
          "language" : "de-CH",
          "value" : "Phenprocoumon"
        },
        {
          "language" : "it-CH",
          "value" : "fenprocumone"
        }]
      },
      {
        "code" : "372771005",
        "display" : "Phenylephrine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenylephrine"
        },
        {
          "language" : "fr-CH",
          "value" : "phényléphrine"
        },
        {
          "language" : "de-CH",
          "value" : "Phenylephrin"
        },
        {
          "language" : "it-CH",
          "value" : "fenilefrina"
        }]
      },
      {
        "code" : "387220006",
        "display" : "Phenytoin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenytoin"
        },
        {
          "language" : "fr-CH",
          "value" : "phénytoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Phenytoin"
        },
        {
          "language" : "it-CH",
          "value" : "fenitoina"
        }]
      },
      {
        "code" : "396486005",
        "display" : "Pholcodine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pholcodine"
        },
        {
          "language" : "fr-CH",
          "value" : "pholcodine"
        },
        {
          "language" : "de-CH",
          "value" : "Pholcodin"
        },
        {
          "language" : "it-CH",
          "value" : "folcodina"
        }]
      },
      {
        "code" : "66656000",
        "display" : "Phytomenadione (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phytomenadione"
        },
        {
          "language" : "fr-CH",
          "value" : "phytoménadione (Vitamine K1)"
        },
        {
          "language" : "de-CH",
          "value" : "Phytomenadion (Vitamin K1)"
        },
        {
          "language" : "it-CH",
          "value" : "fitomenadione (vitamina k1)"
        }]
      },
      {
        "code" : "372895002",
        "display" : "Pilocarpine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pilocarpine"
        },
        {
          "language" : "fr-CH",
          "value" : "pilocarpine"
        },
        {
          "language" : "de-CH",
          "value" : "Pilocarpin"
        },
        {
          "language" : "it-CH",
          "value" : "pilocarpina"
        }]
      },
      {
        "code" : "385580005",
        "display" : "Pimecrolimus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pimecrolimus"
        },
        {
          "language" : "fr-CH",
          "value" : "pimécrolimus"
        },
        {
          "language" : "de-CH",
          "value" : "Pimecrolimus"
        },
        {
          "language" : "it-CH",
          "value" : "pimecrolimus"
        }]
      },
      {
        "code" : "703362007",
        "display" : "Pipamperone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pipamperone"
        },
        {
          "language" : "fr-CH",
          "value" : "pipampérone"
        },
        {
          "language" : "de-CH",
          "value" : "Pipamperon"
        },
        {
          "language" : "it-CH",
          "value" : "pipamperone"
        }]
      },
      {
        "code" : "372836004",
        "display" : "Piperacillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piperacillin"
        },
        {
          "language" : "fr-CH",
          "value" : "pipéracilline"
        },
        {
          "language" : "de-CH",
          "value" : "Piperacillin"
        },
        {
          "language" : "it-CH",
          "value" : "piperacillina"
        }]
      },
      {
        "code" : "395833008",
        "display" : "Piracetam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piracetam"
        },
        {
          "language" : "fr-CH",
          "value" : "piracétam"
        },
        {
          "language" : "de-CH",
          "value" : "Piracetam"
        },
        {
          "language" : "it-CH",
          "value" : "piracetam"
        }]
      },
      {
        "code" : "419451002",
        "display" : "Piretanide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piretanide"
        },
        {
          "language" : "fr-CH",
          "value" : "pirétanide"
        },
        {
          "language" : "de-CH",
          "value" : "Piretanid"
        },
        {
          "language" : "it-CH",
          "value" : "piretanide"
        }]
      },
      {
        "code" : "387153005",
        "display" : "Piroxicam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piroxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "piroxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Piroxicam"
        },
        {
          "language" : "it-CH",
          "value" : "piroxicam"
        }]
      },
      {
        "code" : "443586000",
        "display" : "Pitavastatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pitavastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "pitavastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Pitavastatin"
        },
        {
          "language" : "it-CH",
          "value" : "pitavastatina"
        }]
      },
      {
        "code" : "442264009",
        "display" : "Plerixafor (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Plerixafor"
        },
        {
          "language" : "fr-CH",
          "value" : "plérixafor"
        },
        {
          "language" : "de-CH",
          "value" : "Plerixafor"
        },
        {
          "language" : "it-CH",
          "value" : "plerixafor"
        }]
      },
      {
        "code" : "421952002",
        "display" : "Polihexanide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Polihexanide"
        },
        {
          "language" : "fr-CH",
          "value" : "polyhexanide"
        },
        {
          "language" : "de-CH",
          "value" : "Polihexanid"
        },
        {
          "language" : "it-CH",
          "value" : "poliesanide"
        }]
      },
      {
        "code" : "421747003",
        "display" : "Posaconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Posaconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "posaconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Posaconazol"
        },
        {
          "language" : "it-CH",
          "value" : "posaconazolo"
        }]
      },
      {
        "code" : "443129001",
        "display" : "Prasugrel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prasugrel"
        },
        {
          "language" : "fr-CH",
          "value" : "prasugrel"
        },
        {
          "language" : "de-CH",
          "value" : "Prasugrel"
        },
        {
          "language" : "it-CH",
          "value" : "prasugrel"
        }]
      },
      {
        "code" : "373566006",
        "display" : "Pravastatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pravastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "pravastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Pravastatin"
        },
        {
          "language" : "it-CH",
          "value" : "pravastatina"
        }]
      },
      {
        "code" : "387417001",
        "display" : "Prazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "prazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Prazepam"
        },
        {
          "language" : "it-CH",
          "value" : "prazepam"
        }]
      },
      {
        "code" : "387310003",
        "display" : "Praziquantel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Praziquantel"
        },
        {
          "language" : "fr-CH",
          "value" : "praziquantel"
        },
        {
          "language" : "de-CH",
          "value" : "Praziquantel"
        },
        {
          "language" : "it-CH",
          "value" : "praziquantel"
        }]
      },
      {
        "code" : "126086006",
        "display" : "Prednicarbate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prednicarbate"
        },
        {
          "language" : "fr-CH",
          "value" : "prednicarbate"
        },
        {
          "language" : "de-CH",
          "value" : "Prednicarbat"
        },
        {
          "language" : "it-CH",
          "value" : "prednicarbato"
        }]
      },
      {
        "code" : "116601002",
        "display" : "Prednisolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prednisolone"
        },
        {
          "language" : "fr-CH",
          "value" : "prednisolone"
        },
        {
          "language" : "de-CH",
          "value" : "Prednisolon"
        },
        {
          "language" : "it-CH",
          "value" : "prednisolone"
        }]
      },
      {
        "code" : "116602009",
        "display" : "Prednisone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prednisone"
        },
        {
          "language" : "fr-CH",
          "value" : "prednisone"
        },
        {
          "language" : "de-CH",
          "value" : "Prednison"
        },
        {
          "language" : "it-CH",
          "value" : "prednisone"
        }]
      },
      {
        "code" : "415160008",
        "display" : "Pregabalin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pregabalin"
        },
        {
          "language" : "fr-CH",
          "value" : "prégabaline"
        },
        {
          "language" : "de-CH",
          "value" : "Pregabalin"
        },
        {
          "language" : "it-CH",
          "value" : "pregabalin"
        }]
      },
      {
        "code" : "429663004",
        "display" : "Primaquine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Primaquine"
        },
        {
          "language" : "fr-CH",
          "value" : "primaquine"
        },
        {
          "language" : "de-CH",
          "value" : "Primaquin"
        },
        {
          "language" : "it-CH",
          "value" : "primachina"
        }]
      },
      {
        "code" : "387256009",
        "display" : "Primidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Primidone"
        },
        {
          "language" : "fr-CH",
          "value" : "primidone"
        },
        {
          "language" : "de-CH",
          "value" : "Primidon"
        },
        {
          "language" : "it-CH",
          "value" : "primidone"
        }]
      },
      {
        "code" : "387365004",
        "display" : "Probenecid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Probenecid"
        },
        {
          "language" : "fr-CH",
          "value" : "probénécide"
        },
        {
          "language" : "de-CH",
          "value" : "Probenecid"
        },
        {
          "language" : "it-CH",
          "value" : "probenecid"
        }]
      },
      {
        "code" : "372589008",
        "display" : "Procainamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Procainamide"
        },
        {
          "language" : "fr-CH",
          "value" : "procaïnamide"
        },
        {
          "language" : "de-CH",
          "value" : "Procainamid"
        },
        {
          "language" : "it-CH",
          "value" : "procainamide"
        }]
      },
      {
        "code" : "387238009",
        "display" : "Procaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Procaine"
        },
        {
          "language" : "fr-CH",
          "value" : "procaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Procain"
        },
        {
          "language" : "it-CH",
          "value" : "procaina"
        }]
      },
      {
        "code" : "16683002",
        "display" : "Progesterone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Progesterone"
        },
        {
          "language" : "fr-CH",
          "value" : "progestérone"
        },
        {
          "language" : "de-CH",
          "value" : "Progesteron"
        },
        {
          "language" : "it-CH",
          "value" : "progesterone"
        }]
      },
      {
        "code" : "387094004",
        "display" : "Proguanil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Proguanil"
        },
        {
          "language" : "fr-CH",
          "value" : "proguanil"
        },
        {
          "language" : "de-CH",
          "value" : "Proguanil"
        },
        {
          "language" : "it-CH",
          "value" : "proguanil"
        }]
      },
      {
        "code" : "79135001",
        "display" : "Promazine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Promazine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "promazine chlorhydrate"
        },
        {
          "language" : "de-CH",
          "value" : "Promazin hydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "promazina cloridrato"
        }]
      },
      {
        "code" : "372871004",
        "display" : "Promethazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Promethazine"
        },
        {
          "language" : "fr-CH",
          "value" : "prométhazine"
        },
        {
          "language" : "de-CH",
          "value" : "Promethazin"
        },
        {
          "language" : "it-CH",
          "value" : "prometazina"
        }]
      },
      {
        "code" : "387423006",
        "display" : "Propofol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propofol"
        },
        {
          "language" : "fr-CH",
          "value" : "propofol"
        },
        {
          "language" : "de-CH",
          "value" : "Propofol"
        },
        {
          "language" : "it-CH",
          "value" : "propofol"
        }]
      },
      {
        "code" : "372772003",
        "display" : "Propranolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propranolol"
        },
        {
          "language" : "fr-CH",
          "value" : "propranolol"
        },
        {
          "language" : "de-CH",
          "value" : "Propranolol"
        },
        {
          "language" : "it-CH",
          "value" : "propranololo"
        }]
      },
      {
        "code" : "699188007",
        "display" : "Propyphenazone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propyphenazone"
        },
        {
          "language" : "fr-CH",
          "value" : "propyphénazone"
        },
        {
          "language" : "de-CH",
          "value" : "Propyphenazon"
        },
        {
          "language" : "it-CH",
          "value" : "propifenazone"
        }]
      },
      {
        "code" : "372630008",
        "display" : "Protamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Protamine"
        },
        {
          "language" : "fr-CH",
          "value" : "protamine"
        },
        {
          "language" : "de-CH",
          "value" : "Protamin"
        },
        {
          "language" : "it-CH",
          "value" : "protamina"
        }]
      },
      {
        "code" : "412495007",
        "display" : "Protirelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Protireline"
        },
        {
          "language" : "fr-CH",
          "value" : "protiréline"
        },
        {
          "language" : "de-CH",
          "value" : "Protirelin"
        },
        {
          "language" : "it-CH",
          "value" : "protirelina"
        }]
      },
      {
        "code" : "387076005",
        "display" : "Pyrazinamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pyrazinamide"
        },
        {
          "language" : "fr-CH",
          "value" : "pyrazinamide"
        },
        {
          "language" : "de-CH",
          "value" : "Pyrazinamid"
        },
        {
          "language" : "it-CH",
          "value" : "pirazinamide"
        }]
      },
      {
        "code" : "34915005",
        "display" : "Pyridostigmine bromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pyridostigmine bromide"
        },
        {
          "language" : "fr-CH",
          "value" : "pyridostigmine bromure"
        },
        {
          "language" : "de-CH",
          "value" : "Pyridostigmin bromid"
        },
        {
          "language" : "it-CH",
          "value" : "piridostigmina bromuro"
        }]
      },
      {
        "code" : "430469009",
        "display" : "Pyridoxine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pyridoxine"
        },
        {
          "language" : "fr-CH",
          "value" : "pyridoxine (Vitamine B6)"
        },
        {
          "language" : "de-CH",
          "value" : "Pyridoxin (Vitamin B6)"
        },
        {
          "language" : "it-CH",
          "value" : "piridossina (vitamina b6)"
        }]
      },
      {
        "code" : "373769001",
        "display" : "Pyrimethamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pyrimethamine"
        },
        {
          "language" : "fr-CH",
          "value" : "pyriméthamine"
        },
        {
          "language" : "de-CH",
          "value" : "Pyrimethamin"
        },
        {
          "language" : "it-CH",
          "value" : "pirimetamina"
        }]
      },
      {
        "code" : "386850001",
        "display" : "Quetiapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Quetiapine"
        },
        {
          "language" : "fr-CH",
          "value" : "quétiapine"
        },
        {
          "language" : "de-CH",
          "value" : "Quetiapin"
        },
        {
          "language" : "it-CH",
          "value" : "quetiapina"
        }]
      },
      {
        "code" : "386874003",
        "display" : "Quinapril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Quinapril"
        },
        {
          "language" : "fr-CH",
          "value" : "quinapril"
        },
        {
          "language" : "de-CH",
          "value" : "Quinapril"
        },
        {
          "language" : "it-CH",
          "value" : "quinapril"
        }]
      },
      {
        "code" : "373497008",
        "display" : "Quinine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Quinine"
        },
        {
          "language" : "fr-CH",
          "value" : "quinine"
        },
        {
          "language" : "de-CH",
          "value" : "Chinin"
        },
        {
          "language" : "it-CH",
          "value" : "chinina"
        }]
      },
      {
        "code" : "429707008",
        "display" : "Raltegravir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Raltegravir"
        },
        {
          "language" : "fr-CH",
          "value" : "raltégravir"
        },
        {
          "language" : "de-CH",
          "value" : "Raltegravir"
        },
        {
          "language" : "it-CH",
          "value" : "raltegravir"
        }]
      },
      {
        "code" : "386872004",
        "display" : "Ramipril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ramipril"
        },
        {
          "language" : "fr-CH",
          "value" : "ramipril"
        },
        {
          "language" : "de-CH",
          "value" : "Ramipril"
        },
        {
          "language" : "it-CH",
          "value" : "ramipril"
        }]
      },
      {
        "code" : "372755005",
        "display" : "Ranitidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ranitidine"
        },
        {
          "language" : "fr-CH",
          "value" : "ranitidine"
        },
        {
          "language" : "de-CH",
          "value" : "Ranitidin"
        },
        {
          "language" : "it-CH",
          "value" : "ranitidina"
        }]
      },
      {
        "code" : "420365007",
        "display" : "Ranolazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ranolazine"
        },
        {
          "language" : "fr-CH",
          "value" : "ranolazine"
        },
        {
          "language" : "de-CH",
          "value" : "Ranolazin"
        },
        {
          "language" : "it-CH",
          "value" : "ranolazina"
        }]
      },
      {
        "code" : "418734001",
        "display" : "Rasagiline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rasagiline"
        },
        {
          "language" : "fr-CH",
          "value" : "rasagiline"
        },
        {
          "language" : "de-CH",
          "value" : "Rasagilin"
        },
        {
          "language" : "it-CH",
          "value" : "rasagilina"
        }]
      },
      {
        "code" : "395858003",
        "display" : "Rasburicase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rasburicase"
        },
        {
          "language" : "fr-CH",
          "value" : "rasburicase"
        },
        {
          "language" : "de-CH",
          "value" : "Rasburicase"
        },
        {
          "language" : "it-CH",
          "value" : "rasburicase"
        }]
      },
      {
        "code" : "386839004",
        "display" : "Remifentanil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Remifentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "rémifentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Remifentanil"
        },
        {
          "language" : "it-CH",
          "value" : "remifentanil"
        }]
      },
      {
        "code" : "386964000",
        "display" : "Repaglinide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Repaglinide"
        },
        {
          "language" : "fr-CH",
          "value" : "répaglinide"
        },
        {
          "language" : "de-CH",
          "value" : "Repaglinid"
        },
        {
          "language" : "it-CH",
          "value" : "repaglinide"
        }]
      },
      {
        "code" : "82622003",
        "display" : "Retinol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Retinol"
        },
        {
          "language" : "fr-CH",
          "value" : "rétinol (Vitamine a)"
        },
        {
          "language" : "de-CH",
          "value" : "Retinol (Vitamin A)"
        },
        {
          "language" : "it-CH",
          "value" : "retinolo (vitamina a)"
        }]
      },
      {
        "code" : "387188005",
        "display" : "Ribavirin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ribavirin"
        },
        {
          "language" : "fr-CH",
          "value" : "ribavirine"
        },
        {
          "language" : "de-CH",
          "value" : "Ribavirin"
        },
        {
          "language" : "it-CH",
          "value" : "ribavirina"
        }]
      },
      {
        "code" : "386893001",
        "display" : "Rifabutin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rifabutin"
        },
        {
          "language" : "fr-CH",
          "value" : "rifabutine"
        },
        {
          "language" : "de-CH",
          "value" : "Rifabutin"
        },
        {
          "language" : "it-CH",
          "value" : "rifabutina"
        }]
      },
      {
        "code" : "387159009",
        "display" : "Rifampicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rifampicin"
        },
        {
          "language" : "fr-CH",
          "value" : "rifampicine"
        },
        {
          "language" : "de-CH",
          "value" : "Rifampicin"
        },
        {
          "language" : "it-CH",
          "value" : "rifampicina"
        }]
      },
      {
        "code" : "412553001",
        "display" : "Rifaximin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rifaximin"
        },
        {
          "language" : "fr-CH",
          "value" : "rifaximine"
        },
        {
          "language" : "de-CH",
          "value" : "Rifaximin"
        },
        {
          "language" : "it-CH",
          "value" : "rifaximina"
        }]
      },
      {
        "code" : "386980005",
        "display" : "Riluzole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Riluzole"
        },
        {
          "language" : "fr-CH",
          "value" : "riluzole"
        },
        {
          "language" : "de-CH",
          "value" : "Riluzol"
        },
        {
          "language" : "it-CH",
          "value" : "riluzolo"
        }]
      },
      {
        "code" : "387064005",
        "display" : "Risedronate sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Risedronate sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "risédronate sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Risedronat natrium"
        },
        {
          "language" : "it-CH",
          "value" : "sodio risedronato"
        }]
      },
      {
        "code" : "386840002",
        "display" : "Risperidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Risperidone"
        },
        {
          "language" : "fr-CH",
          "value" : "rispéridone"
        },
        {
          "language" : "de-CH",
          "value" : "Risperidon"
        },
        {
          "language" : "it-CH",
          "value" : "risperidone"
        }]
      },
      {
        "code" : "386896009",
        "display" : "Ritonavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ritonavir"
        },
        {
          "language" : "fr-CH",
          "value" : "ritonavir"
        },
        {
          "language" : "de-CH",
          "value" : "Ritonavir"
        },
        {
          "language" : "it-CH",
          "value" : "ritonavir"
        }]
      },
      {
        "code" : "386919002",
        "display" : "Rituximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rituximab"
        },
        {
          "language" : "fr-CH",
          "value" : "rituximab"
        },
        {
          "language" : "de-CH",
          "value" : "Rituximab"
        },
        {
          "language" : "it-CH",
          "value" : "rituximab"
        }]
      },
      {
        "code" : "442031002",
        "display" : "Rivaroxaban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rivaroxaban"
        },
        {
          "language" : "fr-CH",
          "value" : "rivaroxaban"
        },
        {
          "language" : "de-CH",
          "value" : "Rivaroxaban"
        },
        {
          "language" : "it-CH",
          "value" : "rivaroxaban"
        }]
      },
      {
        "code" : "395868008",
        "display" : "Rivastigmine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rivastigmine"
        },
        {
          "language" : "fr-CH",
          "value" : "rivastigmine"
        },
        {
          "language" : "de-CH",
          "value" : "Rivastigmin"
        },
        {
          "language" : "it-CH",
          "value" : "rivastigmina"
        }]
      },
      {
        "code" : "363573000",
        "display" : "Rizatriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rizatriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "rizatriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Rizatriptan"
        },
        {
          "language" : "it-CH",
          "value" : "rizatriptan"
        }]
      },
      {
        "code" : "448971002",
        "display" : "Roflumilast (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Roflumilast"
        },
        {
          "language" : "fr-CH",
          "value" : "roflumilast"
        },
        {
          "language" : "de-CH",
          "value" : "Roflumilast"
        },
        {
          "language" : "it-CH",
          "value" : "roflumilast"
        }]
      },
      {
        "code" : "439122000",
        "display" : "Romiplostim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Romiplostim"
        },
        {
          "language" : "fr-CH",
          "value" : "romiplostim"
        },
        {
          "language" : "de-CH",
          "value" : "Romiplostim"
        },
        {
          "language" : "it-CH",
          "value" : "romiplostim"
        }]
      },
      {
        "code" : "386969005",
        "display" : "Ropivacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ropivacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "ropivacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Ropivacain"
        },
        {
          "language" : "it-CH",
          "value" : "ropivacaina"
        }]
      },
      {
        "code" : "421924006",
        "display" : "Rotigotine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rotigotine"
        },
        {
          "language" : "fr-CH",
          "value" : "rotigotine"
        },
        {
          "language" : "de-CH",
          "value" : "Rotigotin"
        },
        {
          "language" : "it-CH",
          "value" : "rotigotina"
        }]
      },
      {
        "code" : "429835003",
        "display" : "Rufinamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rufinamide"
        },
        {
          "language" : "fr-CH",
          "value" : "rufinamide"
        },
        {
          "language" : "de-CH",
          "value" : "Rufinamid"
        },
        {
          "language" : "it-CH",
          "value" : "rufinamide"
        }]
      },
      {
        "code" : "718852000",
        "display" : "Safinamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Safinamide"
        },
        {
          "language" : "fr-CH",
          "value" : "safinamide"
        },
        {
          "language" : "de-CH",
          "value" : "Safinamid"
        },
        {
          "language" : "it-CH",
          "value" : "safinamide"
        }]
      },
      {
        "code" : "372897005",
        "display" : "Salbutamol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salbutamol"
        },
        {
          "language" : "fr-CH",
          "value" : "salbutamol"
        },
        {
          "language" : "de-CH",
          "value" : "Salbutamol"
        },
        {
          "language" : "it-CH",
          "value" : "salbutamolo"
        }]
      },
      {
        "code" : "22192002",
        "display" : "Salicylamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salicylamide"
        },
        {
          "language" : "fr-CH",
          "value" : "salicylamide"
        },
        {
          "language" : "de-CH",
          "value" : "Salicylamid"
        },
        {
          "language" : "it-CH",
          "value" : "salicilamide"
        }]
      },
      {
        "code" : "387253001",
        "display" : "Salicylic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salicylic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide salicylique"
        },
        {
          "language" : "de-CH",
          "value" : "Salicylsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido salicilico"
        }]
      },
      {
        "code" : "372515005",
        "display" : "Salmeterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salmeterol"
        },
        {
          "language" : "fr-CH",
          "value" : "salmétérol"
        },
        {
          "language" : "de-CH",
          "value" : "Salmeterol"
        },
        {
          "language" : "it-CH",
          "value" : "salmeterolo"
        }]
      },
      {
        "code" : "372530001",
        "display" : "Saquinavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Saquinavir"
        },
        {
          "language" : "fr-CH",
          "value" : "saquinavir"
        },
        {
          "language" : "de-CH",
          "value" : "Saquinavir"
        },
        {
          "language" : "it-CH",
          "value" : "saquinavir"
        }]
      },
      {
        "code" : "443087004",
        "display" : "Saxagliptin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Saxagliptin"
        },
        {
          "language" : "fr-CH",
          "value" : "saxagliptine"
        },
        {
          "language" : "de-CH",
          "value" : "Saxagliptin"
        },
        {
          "language" : "it-CH",
          "value" : "saxagliptin"
        }]
      },
      {
        "code" : "387409009",
        "display" : "Scopolamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Scopolamine"
        },
        {
          "language" : "fr-CH",
          "value" : "scopolamine"
        },
        {
          "language" : "de-CH",
          "value" : "Scopolamin"
        },
        {
          "language" : "it-CH",
          "value" : "scopolamina"
        }]
      },
      {
        "code" : "395739004",
        "display" : "Scopolamine butylbromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Scopolamine butylbromide"
        },
        {
          "language" : "fr-CH",
          "value" : "scopolamine butylbromure"
        },
        {
          "language" : "de-CH",
          "value" : "Scopolamin butylbromid"
        },
        {
          "language" : "it-CH",
          "value" : "scopolamina butilbromuro"
        }]
      },
      {
        "code" : "708822004",
        "display" : "Secukinumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Secukinumab"
        },
        {
          "language" : "fr-CH",
          "value" : "sécukinumab"
        },
        {
          "language" : "de-CH",
          "value" : "Secukinumab"
        },
        {
          "language" : "it-CH",
          "value" : "secukinumab"
        }]
      },
      {
        "code" : "372594008",
        "display" : "Sertraline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sertraline"
        },
        {
          "language" : "fr-CH",
          "value" : "sertraline"
        },
        {
          "language" : "de-CH",
          "value" : "Sertralin"
        },
        {
          "language" : "it-CH",
          "value" : "sertralina"
        }]
      },
      {
        "code" : "386842005",
        "display" : "Sevoflurane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sevoflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "sévoflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Sevofluran"
        },
        {
          "language" : "it-CH",
          "value" : "sevoflurano"
        }]
      },
      {
        "code" : "372572000",
        "display" : "Sildenafil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sildenafil"
        },
        {
          "language" : "fr-CH",
          "value" : "sildénafil"
        },
        {
          "language" : "de-CH",
          "value" : "Sildenafil"
        },
        {
          "language" : "it-CH",
          "value" : "sildenafil"
        }]
      },
      {
        "code" : "442042006",
        "display" : "Silodosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Silodosin"
        },
        {
          "language" : "fr-CH",
          "value" : "silodosine"
        },
        {
          "language" : "de-CH",
          "value" : "Silodosin"
        },
        {
          "language" : "it-CH",
          "value" : "silodosina"
        }]
      },
      {
        "code" : "387584000",
        "display" : "Simvastatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Simvastatin"
        },
        {
          "language" : "fr-CH",
          "value" : "simvastatine"
        },
        {
          "language" : "de-CH",
          "value" : "Simvastatin"
        },
        {
          "language" : "it-CH",
          "value" : "simvastatina"
        }]
      },
      {
        "code" : "387014003",
        "display" : "Sirolimus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sirolimus"
        },
        {
          "language" : "fr-CH",
          "value" : "sirolimus"
        },
        {
          "language" : "de-CH",
          "value" : "Sirolimus"
        },
        {
          "language" : "it-CH",
          "value" : "sirolimus"
        }]
      },
      {
        "code" : "423307000",
        "display" : "Sitagliptin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sitagliptin"
        },
        {
          "language" : "fr-CH",
          "value" : "sitagliptine"
        },
        {
          "language" : "de-CH",
          "value" : "Sitagliptin"
        },
        {
          "language" : "it-CH",
          "value" : "sitagliptin"
        }]
      },
      {
        "code" : "395881001",
        "display" : "Sodium picosulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sodium picosulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "picosulfate sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Natrium picosulfat"
        },
        {
          "language" : "it-CH",
          "value" : "sodio picosolfato"
        }]
      },
      {
        "code" : "710806008",
        "display" : "Sofosbuvir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sofosbuvir"
        },
        {
          "language" : "fr-CH",
          "value" : "sofosbuvir"
        },
        {
          "language" : "de-CH",
          "value" : "Sofosbuvir"
        },
        {
          "language" : "it-CH",
          "value" : "sofosbuvir"
        }]
      },
      {
        "code" : "407030007",
        "display" : "Solifenacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Solifenacin"
        },
        {
          "language" : "fr-CH",
          "value" : "solifénacine"
        },
        {
          "language" : "de-CH",
          "value" : "Solifenacin"
        },
        {
          "language" : "it-CH",
          "value" : "solifenacina"
        }]
      },
      {
        "code" : "395883003",
        "display" : "Somatropin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Somatropin"
        },
        {
          "language" : "fr-CH",
          "value" : "somatropine"
        },
        {
          "language" : "de-CH",
          "value" : "Somatropin"
        },
        {
          "language" : "it-CH",
          "value" : "somatropina"
        }]
      },
      {
        "code" : "422042001",
        "display" : "Sorafenib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sorafenib"
        },
        {
          "language" : "fr-CH",
          "value" : "sorafénib"
        },
        {
          "language" : "de-CH",
          "value" : "Sorafenib"
        },
        {
          "language" : "it-CH",
          "value" : "sorafenib"
        }]
      },
      {
        "code" : "372911006",
        "display" : "Sotalol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sotalol"
        },
        {
          "language" : "fr-CH",
          "value" : "sotalol"
        },
        {
          "language" : "de-CH",
          "value" : "Sotalol"
        },
        {
          "language" : "it-CH",
          "value" : "sotalolo"
        }]
      },
      {
        "code" : "387078006",
        "display" : "Spironolactone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Spironolactone"
        },
        {
          "language" : "fr-CH",
          "value" : "spironolactone"
        },
        {
          "language" : "de-CH",
          "value" : "Spironolacton"
        },
        {
          "language" : "it-CH",
          "value" : "spironolattone"
        }]
      },
      {
        "code" : "428221002",
        "display" : "Stiripentol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Stiripentol"
        },
        {
          "language" : "fr-CH",
          "value" : "stiripentol"
        },
        {
          "language" : "de-CH",
          "value" : "Stiripentol"
        },
        {
          "language" : "it-CH",
          "value" : "stiripentolo"
        }]
      },
      {
        "code" : "49998007",
        "display" : "Sufentanil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sufentanil"
        },
        {
          "language" : "fr-CH",
          "value" : "sufentanil"
        },
        {
          "language" : "de-CH",
          "value" : "Sufentanil"
        },
        {
          "language" : "it-CH",
          "value" : "sufentanil"
        }]
      },
      {
        "code" : "442340006",
        "display" : "Sugammadex (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sugammadex"
        },
        {
          "language" : "fr-CH",
          "value" : "sugammadex"
        },
        {
          "language" : "de-CH",
          "value" : "Sugammadex"
        },
        {
          "language" : "it-CH",
          "value" : "sugammadex"
        }]
      },
      {
        "code" : "74523009",
        "display" : "Sulfadiazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfadiazine"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfadiazine"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfadiazin"
        },
        {
          "language" : "it-CH",
          "value" : "sulfadiazina"
        }]
      },
      {
        "code" : "363528007",
        "display" : "Sulfamethoxazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfamethoxazole"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfaméthoxazole"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfamethoxazol"
        },
        {
          "language" : "it-CH",
          "value" : "sulfametossazolo"
        }]
      },
      {
        "code" : "387248006",
        "display" : "Sulfasalazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfasalazine"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfasalazine"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfasalazin"
        },
        {
          "language" : "it-CH",
          "value" : "sulfasalazina"
        }]
      },
      {
        "code" : "395891007",
        "display" : "Sulpiride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulpiride"
        },
        {
          "language" : "fr-CH",
          "value" : "sulpiride"
        },
        {
          "language" : "de-CH",
          "value" : "Sulpirid"
        },
        {
          "language" : "it-CH",
          "value" : "sulpiride"
        }]
      },
      {
        "code" : "713461008",
        "display" : "Sulprostone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulprostone"
        },
        {
          "language" : "fr-CH",
          "value" : "sulprostone"
        },
        {
          "language" : "de-CH",
          "value" : "Sulproston"
        },
        {
          "language" : "it-CH",
          "value" : "sulprostone"
        }]
      },
      {
        "code" : "50580004",
        "display" : "Sulthiamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulthiamine"
        },
        {
          "language" : "fr-CH",
          "value" : "sultiame"
        },
        {
          "language" : "de-CH",
          "value" : "Sultiam"
        },
        {
          "language" : "it-CH",
          "value" : "sultiame"
        }]
      },
      {
        "code" : "395892000",
        "display" : "Sumatriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sumatriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "sumatriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Sumatriptan"
        },
        {
          "language" : "it-CH",
          "value" : "sumatriptan"
        }]
      },
      {
        "code" : "386975001",
        "display" : "Tacrolimus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tacrolimus"
        },
        {
          "language" : "fr-CH",
          "value" : "tacrolimus"
        },
        {
          "language" : "de-CH",
          "value" : "Tacrolimus"
        },
        {
          "language" : "it-CH",
          "value" : "tacrolimus"
        }]
      },
      {
        "code" : "407111005",
        "display" : "Tadalafil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tadalafil"
        },
        {
          "language" : "fr-CH",
          "value" : "tadalafil"
        },
        {
          "language" : "de-CH",
          "value" : "Tadalafil"
        },
        {
          "language" : "it-CH",
          "value" : "tadalafil"
        }]
      },
      {
        "code" : "699181001",
        "display" : "Tafluprost (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tafluprost"
        },
        {
          "language" : "fr-CH",
          "value" : "tafluprost"
        },
        {
          "language" : "de-CH",
          "value" : "Tafluprost"
        },
        {
          "language" : "it-CH",
          "value" : "tafluprost"
        }]
      },
      {
        "code" : "373345002",
        "display" : "Tamoxifen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tamoxifen"
        },
        {
          "language" : "fr-CH",
          "value" : "tamoxifène"
        },
        {
          "language" : "de-CH",
          "value" : "Tamoxifen"
        },
        {
          "language" : "it-CH",
          "value" : "tamoxifene"
        }]
      },
      {
        "code" : "372509005",
        "display" : "Tamsulosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tamsulosin"
        },
        {
          "language" : "fr-CH",
          "value" : "tamsulosine"
        },
        {
          "language" : "de-CH",
          "value" : "Tamsulosin"
        },
        {
          "language" : "it-CH",
          "value" : "tamsulosina"
        }]
      },
      {
        "code" : "96007008",
        "display" : "Tazobactam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tazobactam"
        },
        {
          "language" : "fr-CH",
          "value" : "tazobactam"
        },
        {
          "language" : "de-CH",
          "value" : "Tazobactam"
        },
        {
          "language" : "it-CH",
          "value" : "tazobactam"
        }]
      },
      {
        "code" : "387529008",
        "display" : "Teicoplanin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Teicoplanin"
        },
        {
          "language" : "fr-CH",
          "value" : "téicoplanine"
        },
        {
          "language" : "de-CH",
          "value" : "Teicoplanin"
        },
        {
          "language" : "it-CH",
          "value" : "teicoplanina"
        }]
      },
      {
        "code" : "387069000",
        "display" : "Telmisartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Telmisartan"
        },
        {
          "language" : "fr-CH",
          "value" : "telmisartan"
        },
        {
          "language" : "de-CH",
          "value" : "Telmisartan"
        },
        {
          "language" : "it-CH",
          "value" : "telmisartan"
        }]
      },
      {
        "code" : "387300007",
        "display" : "Temazepam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Temazepam"
        },
        {
          "language" : "fr-CH",
          "value" : "témazépam"
        },
        {
          "language" : "de-CH",
          "value" : "Temazepam"
        },
        {
          "language" : "it-CH",
          "value" : "temazepam"
        }]
      },
      {
        "code" : "387009002",
        "display" : "Temozolomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Temozolomide"
        },
        {
          "language" : "fr-CH",
          "value" : "témozolomide"
        },
        {
          "language" : "de-CH",
          "value" : "Temozolomid"
        },
        {
          "language" : "it-CH",
          "value" : "temozolomide"
        }]
      },
      {
        "code" : "373450007",
        "display" : "Terbinafine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terbinafine"
        },
        {
          "language" : "fr-CH",
          "value" : "terbinafine"
        },
        {
          "language" : "de-CH",
          "value" : "Terbinafin"
        },
        {
          "language" : "it-CH",
          "value" : "terbinafina"
        }]
      },
      {
        "code" : "24583009",
        "display" : "Terbutaline sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terbutaline sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "terbutaline sulfate"
        },
        {
          "language" : "de-CH",
          "value" : "Terbutalin sulfat"
        },
        {
          "language" : "it-CH",
          "value" : "terbutalina solfato"
        }]
      },
      {
        "code" : "425438001",
        "display" : "Teriparatide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Teriparatide"
        },
        {
          "language" : "fr-CH",
          "value" : "tériparatide"
        },
        {
          "language" : "de-CH",
          "value" : "Teriparatid"
        },
        {
          "language" : "it-CH",
          "value" : "teriparatide"
        }]
      },
      {
        "code" : "395899009",
        "display" : "Terlipressin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terlipressin"
        },
        {
          "language" : "fr-CH",
          "value" : "terlipressine"
        },
        {
          "language" : "de-CH",
          "value" : "Terlipressin"
        },
        {
          "language" : "it-CH",
          "value" : "terlipressina"
        }]
      },
      {
        "code" : "43688007",
        "display" : "Testosterone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Testosterone"
        },
        {
          "language" : "fr-CH",
          "value" : "testostérone"
        },
        {
          "language" : "de-CH",
          "value" : "Testosteron"
        },
        {
          "language" : "it-CH",
          "value" : "testosterone"
        }]
      },
      {
        "code" : "387309008",
        "display" : "Tetracaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetracaine"
        },
        {
          "language" : "fr-CH",
          "value" : "tétracaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Tetracain"
        },
        {
          "language" : "it-CH",
          "value" : "tetracaina"
        }]
      },
      {
        "code" : "96363002",
        "display" : "Tetracosactide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetracosactide"
        },
        {
          "language" : "fr-CH",
          "value" : "tétracosactide"
        },
        {
          "language" : "de-CH",
          "value" : "Tetracosactid"
        },
        {
          "language" : "it-CH",
          "value" : "tetracosactide"
        }]
      },
      {
        "code" : "372809001",
        "display" : "Tetracycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "tétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Tetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "tetraciclina"
        }]
      },
      {
        "code" : "372673004",
        "display" : "Tetryzoline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetryzoline"
        },
        {
          "language" : "fr-CH",
          "value" : "tétryzoline"
        },
        {
          "language" : "de-CH",
          "value" : "Tetryzolin"
        },
        {
          "language" : "it-CH",
          "value" : "tetrizolina"
        }]
      },
      {
        "code" : "259659006",
        "display" : "Thiamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiamine"
        },
        {
          "language" : "fr-CH",
          "value" : "thiamine (Vitamine B1)"
        },
        {
          "language" : "de-CH",
          "value" : "Thiamin (Vitamin B1)"
        },
        {
          "language" : "it-CH",
          "value" : "tiamina (vitamina b1)"
        }]
      },
      {
        "code" : "387508004",
        "display" : "Thiotepa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiotepa"
        },
        {
          "language" : "fr-CH",
          "value" : "thiotépa"
        },
        {
          "language" : "de-CH",
          "value" : "Thiotepa"
        },
        {
          "language" : "it-CH",
          "value" : "tiotepa"
        }]
      },
      {
        "code" : "395903002",
        "display" : "Tibolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tibolone"
        },
        {
          "language" : "fr-CH",
          "value" : "tibolone"
        },
        {
          "language" : "de-CH",
          "value" : "Tibolon"
        },
        {
          "language" : "it-CH",
          "value" : "tibolone"
        }]
      },
      {
        "code" : "698805004",
        "display" : "Ticagrelor (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ticagrelor"
        },
        {
          "language" : "fr-CH",
          "value" : "ticagrélor"
        },
        {
          "language" : "de-CH",
          "value" : "Ticagrelor"
        },
        {
          "language" : "it-CH",
          "value" : "ticagrelor"
        }]
      },
      {
        "code" : "418313005",
        "display" : "Tigecycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tigecycline"
        },
        {
          "language" : "fr-CH",
          "value" : "tigécycline"
        },
        {
          "language" : "de-CH",
          "value" : "Tigecyclin"
        },
        {
          "language" : "it-CH",
          "value" : "tigeciclina"
        }]
      },
      {
        "code" : "372880004",
        "display" : "Timolol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Timolol"
        },
        {
          "language" : "fr-CH",
          "value" : "timolol"
        },
        {
          "language" : "de-CH",
          "value" : "Timolol"
        },
        {
          "language" : "it-CH",
          "value" : "timololo"
        }]
      },
      {
        "code" : "409169006",
        "display" : "Tiotropium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tiotropium"
        },
        {
          "language" : "fr-CH",
          "value" : "tiotropium"
        },
        {
          "language" : "de-CH",
          "value" : "Tiotropium"
        },
        {
          "language" : "it-CH",
          "value" : "tiotropio"
        }]
      },
      {
        "code" : "419409009",
        "display" : "Tipranavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tipranavir"
        },
        {
          "language" : "fr-CH",
          "value" : "tipranavir"
        },
        {
          "language" : "de-CH",
          "value" : "Tipranavir"
        },
        {
          "language" : "it-CH",
          "value" : "tipranavir"
        }]
      },
      {
        "code" : "373440006",
        "display" : "Tizanidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tizanidine"
        },
        {
          "language" : "fr-CH",
          "value" : "tizanidine"
        },
        {
          "language" : "de-CH",
          "value" : "Tizanidin"
        },
        {
          "language" : "it-CH",
          "value" : "tizanidina"
        }]
      },
      {
        "code" : "373548001",
        "display" : "Tobramycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tobramycine"
        },
        {
          "language" : "fr-CH",
          "value" : "tobramycine"
        },
        {
          "language" : "de-CH",
          "value" : "Tobramycin"
        },
        {
          "language" : "it-CH",
          "value" : "tobramicina"
        }]
      },
      {
        "code" : "444648007",
        "display" : "Tocilizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tocilizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "tocilizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Tocilizumab"
        },
        {
          "language" : "it-CH",
          "value" : "tocilizumab"
        }]
      },
      {
        "code" : "703717006",
        "display" : "Tolperisone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tolperisone"
        },
        {
          "language" : "fr-CH",
          "value" : "tolpérisone"
        },
        {
          "language" : "de-CH",
          "value" : "Tolperison"
        },
        {
          "language" : "it-CH",
          "value" : "tolperisone"
        }]
      },
      {
        "code" : "372570008",
        "display" : "Tolterodine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tolterodine"
        },
        {
          "language" : "fr-CH",
          "value" : "toltérodine"
        },
        {
          "language" : "de-CH",
          "value" : "Tolterodin"
        },
        {
          "language" : "it-CH",
          "value" : "tolterodina"
        }]
      },
      {
        "code" : "386844006",
        "display" : "Topiramate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Topiramate"
        },
        {
          "language" : "fr-CH",
          "value" : "topiramate"
        },
        {
          "language" : "de-CH",
          "value" : "Topiramat"
        },
        {
          "language" : "it-CH",
          "value" : "topiramato"
        }]
      },
      {
        "code" : "372536007",
        "display" : "Topotecan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Topotecan"
        },
        {
          "language" : "fr-CH",
          "value" : "topotécan"
        },
        {
          "language" : "de-CH",
          "value" : "Topotecan"
        },
        {
          "language" : "it-CH",
          "value" : "topotecan"
        }]
      },
      {
        "code" : "108476002",
        "display" : "Torasemide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Torasemide"
        },
        {
          "language" : "fr-CH",
          "value" : "torasémide"
        },
        {
          "language" : "de-CH",
          "value" : "Torasemid"
        },
        {
          "language" : "it-CH",
          "value" : "torasemide"
        }]
      },
      {
        "code" : "386858008",
        "display" : "Tramadol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tramadol"
        },
        {
          "language" : "fr-CH",
          "value" : "tramadol"
        },
        {
          "language" : "de-CH",
          "value" : "Tramadol"
        },
        {
          "language" : "it-CH",
          "value" : "tramadol"
        }]
      },
      {
        "code" : "708711009",
        "display" : "Trametinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trametinib"
        },
        {
          "language" : "fr-CH",
          "value" : "tramétinib"
        },
        {
          "language" : "de-CH",
          "value" : "Trametinib"
        },
        {
          "language" : "it-CH",
          "value" : "trametinib"
        }]
      },
      {
        "code" : "386871006",
        "display" : "Trandolapril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trandolapril"
        },
        {
          "language" : "fr-CH",
          "value" : "trandolapril"
        },
        {
          "language" : "de-CH",
          "value" : "Trandolapril"
        },
        {
          "language" : "it-CH",
          "value" : "trandolapril"
        }]
      },
      {
        "code" : "386960009",
        "display" : "Tranexamic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tranexamic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide tranexamique"
        },
        {
          "language" : "de-CH",
          "value" : "Tranexamsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido tranexamico"
        }]
      },
      {
        "code" : "387003001",
        "display" : "Trastuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trastuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "trastuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Trastuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "trastuzumab"
        }]
      },
      {
        "code" : "129493000",
        "display" : "Travoprost (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Travoprost"
        },
        {
          "language" : "fr-CH",
          "value" : "travoprost"
        },
        {
          "language" : "de-CH",
          "value" : "Travoprost"
        },
        {
          "language" : "it-CH",
          "value" : "travoprost"
        }]
      },
      {
        "code" : "372829000",
        "display" : "Trazodone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trazodone"
        },
        {
          "language" : "fr-CH",
          "value" : "trazodone"
        },
        {
          "language" : "de-CH",
          "value" : "Trazodon"
        },
        {
          "language" : "it-CH",
          "value" : "trazodone"
        }]
      },
      {
        "code" : "443570007",
        "display" : "Treprostinil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Treprostinil"
        },
        {
          "language" : "fr-CH",
          "value" : "tréprostinil"
        },
        {
          "language" : "de-CH",
          "value" : "Treprostinil"
        },
        {
          "language" : "it-CH",
          "value" : "treprostinil"
        }]
      },
      {
        "code" : "387305002",
        "display" : "Tretinoin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tretinoin"
        },
        {
          "language" : "fr-CH",
          "value" : "trétinoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Tretinoin"
        },
        {
          "language" : "it-CH",
          "value" : "tretinoina"
        }]
      },
      {
        "code" : "116594009",
        "display" : "Triamcinolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Triamcinolone"
        },
        {
          "language" : "fr-CH",
          "value" : "triamcinolone"
        },
        {
          "language" : "de-CH",
          "value" : "Triamcinolon"
        },
        {
          "language" : "it-CH",
          "value" : "triamcinolone"
        }]
      },
      {
        "code" : "386984001",
        "display" : "Triazolam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Triazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "triazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Triazolam"
        },
        {
          "language" : "it-CH",
          "value" : "triazolam"
        }]
      },
      {
        "code" : "387179001",
        "display" : "Trimethoprim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trimethoprim"
        },
        {
          "language" : "fr-CH",
          "value" : "triméthoprime"
        },
        {
          "language" : "de-CH",
          "value" : "Trimethoprim"
        },
        {
          "language" : "it-CH",
          "value" : "trimetoprim"
        }]
      },
      {
        "code" : "373550009",
        "display" : "Trimipramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trimipramine"
        },
        {
          "language" : "fr-CH",
          "value" : "trimipramine"
        },
        {
          "language" : "de-CH",
          "value" : "Trimipramin"
        },
        {
          "language" : "it-CH",
          "value" : "trimipramina"
        }]
      },
      {
        "code" : "395915003",
        "display" : "Triptorelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Triptorelin"
        },
        {
          "language" : "fr-CH",
          "value" : "triptoréline"
        },
        {
          "language" : "de-CH",
          "value" : "Triptorelin"
        },
        {
          "language" : "it-CH",
          "value" : "triptorelina"
        }]
      },
      {
        "code" : "387526001",
        "display" : "Tropicamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tropicamide"
        },
        {
          "language" : "fr-CH",
          "value" : "tropicamide"
        },
        {
          "language" : "de-CH",
          "value" : "Tropicamid"
        },
        {
          "language" : "it-CH",
          "value" : "tropicamide"
        }]
      },
      {
        "code" : "326557004",
        "display" : "Trospium chloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trospium chloride"
        },
        {
          "language" : "fr-CH",
          "value" : "trospium chlorure"
        },
        {
          "language" : "de-CH",
          "value" : "Trospium chlorid"
        },
        {
          "language" : "it-CH",
          "value" : "trospio cloruro"
        }]
      },
      {
        "code" : "108731003",
        "display" : "Tuberculin purified protein derivative (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tuberculin purified protein derivative"
        },
        {
          "language" : "fr-CH",
          "value" : "tuberculine dérivé protéinique purifié"
        },
        {
          "language" : "de-CH",
          "value" : "Tuberkulin, gereinigtes PPD"
        },
        {
          "language" : "it-CH",
          "value" : "tubercolina derivato proteico purificato (ppd)"
        }]
      },
      {
        "code" : "36661005",
        "display" : "Tyrothricin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tyrothricin"
        },
        {
          "language" : "fr-CH",
          "value" : "tyrothricine"
        },
        {
          "language" : "de-CH",
          "value" : "Tyrothricin"
        },
        {
          "language" : "it-CH",
          "value" : "tirotricina"
        }]
      },
      {
        "code" : "698807007",
        "display" : "Urapidil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Urapidil"
        },
        {
          "language" : "fr-CH",
          "value" : "urapidil"
        },
        {
          "language" : "de-CH",
          "value" : "Urapidil"
        },
        {
          "language" : "it-CH",
          "value" : "urapidil"
        }]
      },
      {
        "code" : "59082006",
        "display" : "Urokinase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Urokinase"
        },
        {
          "language" : "fr-CH",
          "value" : "urokinase"
        },
        {
          "language" : "de-CH",
          "value" : "Urokinase"
        },
        {
          "language" : "it-CH",
          "value" : "urochinasi"
        }]
      },
      {
        "code" : "443465002",
        "display" : "Ustekinumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ustekinumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ustékinumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ustekinumab"
        },
        {
          "language" : "it-CH",
          "value" : "ustekinumab"
        }]
      },
      {
        "code" : "96098007",
        "display" : "Valaciclovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Valaciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "valaciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Valaciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "valaciclovir"
        }]
      },
      {
        "code" : "129476000",
        "display" : "Valganciclovir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Valganciclovir"
        },
        {
          "language" : "fr-CH",
          "value" : "valganciclovir"
        },
        {
          "language" : "de-CH",
          "value" : "Valganciclovir"
        },
        {
          "language" : "it-CH",
          "value" : "valganciclovir"
        }]
      },
      {
        "code" : "387080000",
        "display" : "Valproic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Valproic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide valproïque"
        },
        {
          "language" : "de-CH",
          "value" : "Valproinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido valproico"
        }]
      },
      {
        "code" : "386876001",
        "display" : "Valsartan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Valsartan"
        },
        {
          "language" : "fr-CH",
          "value" : "valsartan"
        },
        {
          "language" : "de-CH",
          "value" : "Valsartan"
        },
        {
          "language" : "it-CH",
          "value" : "valsartan"
        }]
      },
      {
        "code" : "372735009",
        "display" : "Vancomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vancomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "vancomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Vancomycin"
        },
        {
          "language" : "it-CH",
          "value" : "vancomicina"
        }]
      },
      {
        "code" : "404858007",
        "display" : "Vardenafil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vardenafil"
        },
        {
          "language" : "fr-CH",
          "value" : "vardénafil"
        },
        {
          "language" : "de-CH",
          "value" : "Vardenafil"
        },
        {
          "language" : "it-CH",
          "value" : "vardenafil"
        }]
      },
      {
        "code" : "421772003",
        "display" : "Varenicline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Varenicline"
        },
        {
          "language" : "fr-CH",
          "value" : "varénicline"
        },
        {
          "language" : "de-CH",
          "value" : "Vareniclin"
        },
        {
          "language" : "it-CH",
          "value" : "vareniclina"
        }]
      },
      {
        "code" : "259858000",
        "display" : "Varicella-zoster virus antibody (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Varicella-zoster virus antibody"
        },
        {
          "language" : "fr-CH",
          "value" : "immunoglobuline humaine antivaricelle"
        },
        {
          "language" : "de-CH",
          "value" : "Varizellen-Immunglobulin vom Menschen"
        },
        {
          "language" : "it-CH",
          "value" : "immunoglobulina umana antivaricella"
        }]
      },
      {
        "code" : "704256006",
        "display" : "Vedolizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vedolizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "védolizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Vedolizumab"
        },
        {
          "language" : "it-CH",
          "value" : "vedolizumab"
        }]
      },
      {
        "code" : "372490001",
        "display" : "Venlafaxine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Venlafaxine"
        },
        {
          "language" : "fr-CH",
          "value" : "venlafaxine"
        },
        {
          "language" : "de-CH",
          "value" : "Venlafaxin"
        },
        {
          "language" : "it-CH",
          "value" : "venlafaxina"
        }]
      },
      {
        "code" : "372754009",
        "display" : "Verapamil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Verapamil"
        },
        {
          "language" : "fr-CH",
          "value" : "vérapamil"
        },
        {
          "language" : "de-CH",
          "value" : "Verapamil"
        },
        {
          "language" : "it-CH",
          "value" : "verapamil"
        }]
      },
      {
        "code" : "310283001",
        "display" : "Vigabatrin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vigabatrin"
        },
        {
          "language" : "fr-CH",
          "value" : "vigabatrine"
        },
        {
          "language" : "de-CH",
          "value" : "Vigabatrin"
        },
        {
          "language" : "it-CH",
          "value" : "vigabatrin"
        }]
      },
      {
        "code" : "702408004",
        "display" : "Vilanterol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vilanterol"
        },
        {
          "language" : "fr-CH",
          "value" : "vilantérol"
        },
        {
          "language" : "de-CH",
          "value" : "Vilanterol"
        },
        {
          "language" : "it-CH",
          "value" : "vilanterolo"
        }]
      },
      {
        "code" : "428611002",
        "display" : "Vildagliptin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vildagliptin"
        },
        {
          "language" : "fr-CH",
          "value" : "vildagliptine"
        },
        {
          "language" : "de-CH",
          "value" : "Vildagliptin"
        },
        {
          "language" : "it-CH",
          "value" : "vildagliptin"
        }]
      },
      {
        "code" : "409198005",
        "display" : "Vindesine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vindesine"
        },
        {
          "language" : "fr-CH",
          "value" : "vindésine"
        },
        {
          "language" : "de-CH",
          "value" : "Vindesin"
        },
        {
          "language" : "it-CH",
          "value" : "vindesina"
        }]
      },
      {
        "code" : "372541004",
        "display" : "Vinorelbine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vinorelbine"
        },
        {
          "language" : "fr-CH",
          "value" : "vinorelbine"
        },
        {
          "language" : "de-CH",
          "value" : "Vinorelbin"
        },
        {
          "language" : "it-CH",
          "value" : "vinorelbina"
        }]
      },
      {
        "code" : "385469007",
        "display" : "Voriconazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Voriconazole"
        },
        {
          "language" : "fr-CH",
          "value" : "voriconazole"
        },
        {
          "language" : "de-CH",
          "value" : "Voriconazol"
        },
        {
          "language" : "it-CH",
          "value" : "voriconazolo"
        }]
      },
      {
        "code" : "372756006",
        "display" : "Warfarin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Warfarin"
        },
        {
          "language" : "fr-CH",
          "value" : "warfarine"
        },
        {
          "language" : "de-CH",
          "value" : "Warfarin"
        },
        {
          "language" : "it-CH",
          "value" : "warfarin"
        }]
      },
      {
        "code" : "372841007",
        "display" : "Xylometazoline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Xylometazoline"
        },
        {
          "language" : "fr-CH",
          "value" : "xylométazoline"
        },
        {
          "language" : "de-CH",
          "value" : "Xylometazolin"
        },
        {
          "language" : "it-CH",
          "value" : "xilometazolina"
        }]
      },
      {
        "code" : "387010007",
        "display" : "Zanamivir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zanamivir"
        },
        {
          "language" : "fr-CH",
          "value" : "zanamivir"
        },
        {
          "language" : "de-CH",
          "value" : "Zanamivir"
        },
        {
          "language" : "it-CH",
          "value" : "zanamivir"
        }]
      },
      {
        "code" : "387151007",
        "display" : "Zidovudine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zidovudine"
        },
        {
          "language" : "fr-CH",
          "value" : "zidovudine"
        },
        {
          "language" : "de-CH",
          "value" : "Zidovudin"
        },
        {
          "language" : "it-CH",
          "value" : "zidovudina"
        }]
      },
      {
        "code" : "395926009",
        "display" : "Zoledronic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zoledronic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide zolédronique (zolédronate)"
        },
        {
          "language" : "de-CH",
          "value" : "Zoledronsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido zoledronico"
        }]
      },
      {
        "code" : "363582006",
        "display" : "Zolmitriptan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zolmitriptan"
        },
        {
          "language" : "fr-CH",
          "value" : "zolmitriptan"
        },
        {
          "language" : "de-CH",
          "value" : "Zolmitriptan"
        },
        {
          "language" : "it-CH",
          "value" : "zolmitriptan"
        }]
      },
      {
        "code" : "125693002",
        "display" : "Zonisamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zonisamide"
        },
        {
          "language" : "fr-CH",
          "value" : "zonisamide"
        },
        {
          "language" : "de-CH",
          "value" : "Zonisamid"
        },
        {
          "language" : "it-CH",
          "value" : "zonisamide"
        }]
      },
      {
        "code" : "395929002",
        "display" : "Zopiclone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zopiclone"
        },
        {
          "language" : "fr-CH",
          "value" : "zopiclone"
        },
        {
          "language" : "de-CH",
          "value" : "Zopiclon"
        },
        {
          "language" : "it-CH",
          "value" : "zopiclone"
        }]
      },
      {
        "code" : "428715002",
        "display" : "Zuclopenthixol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zuclopenthixol"
        },
        {
          "language" : "fr-CH",
          "value" : "zuclopenthixol"
        },
        {
          "language" : "de-CH",
          "value" : "Zuclopenthixol"
        },
        {
          "language" : "it-CH",
          "value" : "zuclopentixolo"
        }]
      },
      {
        "code" : "1557002",
        "display" : "Talc (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Talc"
        },
        {
          "language" : "fr-CH",
          "value" : "talc"
        },
        {
          "language" : "de-CH",
          "value" : "Talkum"
        },
        {
          "language" : "it-CH",
          "value" : "talco"
        }]
      },
      {
        "code" : "2159007",
        "display" : "Azorubin S stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azorubin S stain"
        },
        {
          "language" : "fr-CH",
          "value" : "azorubine"
        },
        {
          "language" : "de-CH",
          "value" : "Azorubin S-Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "azorubina S"
        }]
      },
      {
        "code" : "2309006",
        "display" : "Gold (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gold"
        },
        {
          "language" : "fr-CH",
          "value" : "or"
        },
        {
          "language" : "de-CH",
          "value" : "Gold"
        },
        {
          "language" : "it-CH",
          "value" : "oro"
        }]
      },
      {
        "code" : "2796008",
        "display" : "Methantheline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methantheline"
        },
        {
          "language" : "fr-CH",
          "value" : "méthantheline"
        },
        {
          "language" : "de-CH",
          "value" : "Methanthelin"
        },
        {
          "language" : "it-CH",
          "value" : "metantelina"
        }]
      },
      {
        "code" : "5007006",
        "display" : "Papain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Papain"
        },
        {
          "language" : "fr-CH",
          "value" : "papaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Papain"
        },
        {
          "language" : "it-CH",
          "value" : "papaina"
        }]
      },
      {
        "code" : "6602005",
        "display" : "Aminoacridine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aminoacridine"
        },
        {
          "language" : "fr-CH",
          "value" : "aminoacridine"
        },
        {
          "language" : "de-CH",
          "value" : "Aminoacridin"
        },
        {
          "language" : "it-CH",
          "value" : "aminoacridina"
        }]
      },
      {
        "code" : "7434003",
        "display" : "Erythrosin B stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Erythrosin B stain"
        },
        {
          "language" : "fr-CH",
          "value" : "érythrosine"
        },
        {
          "language" : "de-CH",
          "value" : "Erythrosin B-Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "eritrosina B"
        }]
      },
      {
        "code" : "8687009",
        "display" : "Gum arabic (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gum arabic"
        },
        {
          "language" : "fr-CH",
          "value" : "gomme arabique"
        },
        {
          "language" : "de-CH",
          "value" : "Gummiarabikum"
        },
        {
          "language" : "it-CH",
          "value" : "gomma arabica"
        }]
      },
      {
        "code" : "8886003",
        "display" : "Flecainide acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flecainide acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate de flécaïnide"
        },
        {
          "language" : "de-CH",
          "value" : "Flecainidacetat"
        },
        {
          "language" : "it-CH",
          "value" : "flecainide acetato"
        }]
      },
      {
        "code" : "9234005",
        "display" : "Chlorobutanol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorobutanol"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorobutanol"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorobutanol"
        },
        {
          "language" : "it-CH",
          "value" : "clorobutanolo"
        }]
      },
      {
        "code" : "11136004",
        "display" : "Methoxyflurane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methoxyflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "méthoxyfluraan"
        },
        {
          "language" : "de-CH",
          "value" : "Methoxyfluran"
        },
        {
          "language" : "it-CH",
          "value" : "metossiflurano"
        }]
      },
      {
        "code" : "11526002",
        "display" : "Aspartame (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aspartame"
        },
        {
          "language" : "fr-CH",
          "value" : "aspartame"
        },
        {
          "language" : "de-CH",
          "value" : "Aspartam"
        },
        {
          "language" : "it-CH",
          "value" : "aspartame"
        }]
      },
      {
        "code" : "11984007",
        "display" : "Alfacalcidol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alfacalcidol"
        },
        {
          "language" : "fr-CH",
          "value" : "Alfacalcidol"
        },
        {
          "language" : "de-CH",
          "value" : "Alfacalcidol"
        },
        {
          "language" : "it-CH",
          "value" : "alfacalcidolo"
        }]
      },
      {
        "code" : "12358005",
        "display" : "Citronella oil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Citronella oil"
        },
        {
          "language" : "fr-CH",
          "value" : "essence de citronelle"
        },
        {
          "language" : "de-CH",
          "value" : "Zitronengrasöl"
        },
        {
          "language" : "it-CH",
          "value" : "olio di citronella"
        }]
      },
      {
        "code" : "13502005",
        "display" : "Hydroxychloroquine sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydroxychloroquine sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate d'hydroxychloroquine"
        },
        {
          "language" : "de-CH",
          "value" : "Hydroxychloroquinsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "idrossiclorochina solfato"
        }]
      },
      {
        "code" : "13577000",
        "display" : "Nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix"
        },
        {
          "language" : "de-CH",
          "value" : "Nuss"
        },
        {
          "language" : "it-CH",
          "value" : "frutto a guscio"
        }]
      },
      {
        "code" : "13668001",
        "display" : "Propylene glycol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propylene glycol"
        },
        {
          "language" : "fr-CH",
          "value" : "propylène glycol"
        },
        {
          "language" : "de-CH",
          "value" : "Propylenglykol"
        },
        {
          "language" : "it-CH",
          "value" : "glicole propilenico"
        }]
      },
      {
        "code" : "14472001",
        "display" : "Dehydroacetic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dehydroacetic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide déhydroacétique"
        },
        {
          "language" : "de-CH",
          "value" : "Dehydracetsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido deidroacetico"
        }]
      },
      {
        "code" : "15730005",
        "display" : "Porphyrin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Porphyrin"
        },
        {
          "language" : "fr-CH",
          "value" : "porphyrine"
        },
        {
          "language" : "de-CH",
          "value" : "Porphyrin"
        },
        {
          "language" : "it-CH",
          "value" : "porfirina"
        }]
      },
      {
        "code" : "16968005",
        "display" : "Diethyltoluamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diethyltoluamide"
        },
        {
          "language" : "fr-CH",
          "value" : "diéthyltoluamide"
        },
        {
          "language" : "de-CH",
          "value" : "Diethyltoluamid"
        },
        {
          "language" : "it-CH",
          "value" : "dietiltoluamide"
        }]
      },
      {
        "code" : "19126005",
        "display" : "Merbromin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Merbromin"
        },
        {
          "language" : "fr-CH",
          "value" : "merbromine"
        },
        {
          "language" : "de-CH",
          "value" : "Merbromin"
        },
        {
          "language" : "it-CH",
          "value" : "merbromina"
        }]
      },
      {
        "code" : "19421007",
        "display" : "Chloroprocaine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chloroprocaine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de chloroprocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Chloroprocainhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "cloroprocaina cloridrato"
        }]
      },
      {
        "code" : "19595005",
        "display" : "Phenolphthalein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenolphthalein"
        },
        {
          "language" : "fr-CH",
          "value" : "phénolphthaléine"
        },
        {
          "language" : "de-CH",
          "value" : "Phenolphthalein"
        },
        {
          "language" : "it-CH",
          "value" : "fenoftaleina"
        }]
      },
      {
        "code" : "22165008",
        "display" : "Metamizole sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metamizole sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "métamizole sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Metamizol-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "metamizolo sodico"
        }]
      },
      {
        "code" : "27120008",
        "display" : "Malachite green stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Malachite green stain"
        },
        {
          "language" : "fr-CH",
          "value" : "vert malachite"
        },
        {
          "language" : "de-CH",
          "value" : "Malachitgrün-Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "verde malachite"
        }]
      },
      {
        "code" : "27138006",
        "display" : "Saccharin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Saccharin"
        },
        {
          "language" : "fr-CH",
          "value" : "saccharine"
        },
        {
          "language" : "de-CH",
          "value" : "Saccharin"
        },
        {
          "language" : "it-CH",
          "value" : "saccarina"
        }]
      },
      {
        "code" : "28268006",
        "display" : "Pregnanediol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pregnanediol"
        },
        {
          "language" : "fr-CH",
          "value" : "prégnandiol"
        },
        {
          "language" : "de-CH",
          "value" : "Pregnanediol"
        },
        {
          "language" : "it-CH",
          "value" : "pregnandiolo"
        }]
      },
      {
        "code" : "28421003",
        "display" : "Sorbic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sorbic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide sorbique"
        },
        {
          "language" : "de-CH",
          "value" : "Sorbinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido sorbico"
        }]
      },
      {
        "code" : "28647000",
        "display" : "Meat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meat"
        },
        {
          "language" : "fr-CH",
          "value" : "viande"
        },
        {
          "language" : "de-CH",
          "value" : "Fleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne"
        }]
      },
      {
        "code" : "32757009",
        "display" : "Dibenzepin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dibenzepin"
        },
        {
          "language" : "fr-CH",
          "value" : "dibenzepine"
        },
        {
          "language" : "de-CH",
          "value" : "Dibenzepin"
        },
        {
          "language" : "it-CH",
          "value" : "dibenzepina"
        }]
      },
      {
        "code" : "33396006",
        "display" : "Nickel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nickel"
        },
        {
          "language" : "fr-CH",
          "value" : "nickel"
        },
        {
          "language" : "de-CH",
          "value" : "Nickel"
        },
        {
          "language" : "it-CH",
          "value" : "nichel"
        }]
      },
      {
        "code" : "35098001",
        "display" : "Imidazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Imidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "imidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Imidazol"
        },
        {
          "language" : "it-CH",
          "value" : "imidazolo"
        }]
      },
      {
        "code" : "35318005",
        "display" : "Esmolol hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Esmolol hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate d'esmolol"
        },
        {
          "language" : "de-CH",
          "value" : "Esmololhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "esmololo cloridrato"
        }]
      },
      {
        "code" : "36378007",
        "display" : "Lithium compound (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lithium compound"
        },
        {
          "language" : "fr-CH",
          "value" : "composé de lithium"
        },
        {
          "language" : "de-CH",
          "value" : "Lithiumverbindung"
        },
        {
          "language" : "it-CH",
          "value" : "composto del litio"
        }]
      },
      {
        "code" : "37656002",
        "display" : "Thiamazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiamazole"
        },
        {
          "language" : "fr-CH",
          "value" : "thiamazole"
        },
        {
          "language" : "de-CH",
          "value" : "Thiamazol"
        },
        {
          "language" : "it-CH",
          "value" : "tiamazolo"
        }]
      },
      {
        "code" : "37957009",
        "display" : "Pentoxyverine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentoxyverine"
        },
        {
          "language" : "fr-CH",
          "value" : "pentoxyvérine"
        },
        {
          "language" : "de-CH",
          "value" : "Pentoxyverin"
        },
        {
          "language" : "it-CH",
          "value" : "pentoxiverina"
        }]
      },
      {
        "code" : "38044001",
        "display" : "Paromomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paromomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "paromomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Paromomycin"
        },
        {
          "language" : "it-CH",
          "value" : "paromomicina"
        }]
      },
      {
        "code" : "38686006",
        "display" : "Colistimethate sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Colistimethate sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "colistiméthate sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Colistimethat-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "colistimetato sodico"
        }]
      },
      {
        "code" : "39012008",
        "display" : "Thiram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiram"
        },
        {
          "language" : "fr-CH",
          "value" : "thirame"
        },
        {
          "language" : "de-CH",
          "value" : "Thiram"
        },
        {
          "language" : "it-CH",
          "value" : "thiram"
        }]
      },
      {
        "code" : "40789008",
        "display" : "Adrenocorticotropic hormone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adrenocorticotropic hormone"
        },
        {
          "language" : "fr-CH",
          "value" : "corticoréline"
        },
        {
          "language" : "de-CH",
          "value" : "Adrenocorticotropes Hormon"
        },
        {
          "language" : "it-CH",
          "value" : "ormone adrenocorticotropo"
        }]
      },
      {
        "code" : "41412001",
        "display" : "Tannic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tannic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide tannique"
        },
        {
          "language" : "de-CH",
          "value" : "Tanninsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido tannico"
        }]
      },
      {
        "code" : "41598000",
        "display" : "Estrogen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Estrogen"
        },
        {
          "language" : "fr-CH",
          "value" : "œstrogène"
        },
        {
          "language" : "de-CH",
          "value" : "Östrogen"
        },
        {
          "language" : "it-CH",
          "value" : "estrogeno"
        }]
      },
      {
        "code" : "42033003",
        "display" : "Sterculia gum (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sterculia gum"
        },
        {
          "language" : "fr-CH",
          "value" : "sterculia, gomme"
        },
        {
          "language" : "de-CH",
          "value" : "Sterculia-Gummi"
        },
        {
          "language" : "it-CH",
          "value" : "gomma sterculia"
        }]
      },
      {
        "code" : "42416001",
        "display" : "Lanolin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lanolin"
        },
        {
          "language" : "fr-CH",
          "value" : "lanoline"
        },
        {
          "language" : "de-CH",
          "value" : "Lanolin"
        },
        {
          "language" : "it-CH",
          "value" : "lanolina"
        }]
      },
      {
        "code" : "43230003",
        "display" : "Rubber (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rubber"
        },
        {
          "language" : "fr-CH",
          "value" : "caoutchouc"
        },
        {
          "language" : "de-CH",
          "value" : "Gummi"
        },
        {
          "language" : "it-CH",
          "value" : "caucciù"
        }]
      },
      {
        "code" : "43735007",
        "display" : "Sulfur (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfur"
        },
        {
          "language" : "fr-CH",
          "value" : "soufre"
        },
        {
          "language" : "de-CH",
          "value" : "Schwefel"
        },
        {
          "language" : "it-CH",
          "value" : "zolfo"
        }]
      },
      {
        "code" : "45262002",
        "display" : "Mercury (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mercury"
        },
        {
          "language" : "fr-CH",
          "value" : "mercure"
        },
        {
          "language" : "de-CH",
          "value" : "Quecksilber"
        },
        {
          "language" : "it-CH",
          "value" : "mercurio"
        }]
      },
      {
        "code" : "45475000",
        "display" : "Indigo carmine stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Indigo carmine stain"
        },
        {
          "language" : "fr-CH",
          "value" : "carmin d'indigo"
        },
        {
          "language" : "de-CH",
          "value" : "Indigokarmin-Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "indaco carminio"
        }]
      },
      {
        "code" : "45754009",
        "display" : "Interferon alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Interferon alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "interféron alpha"
        },
        {
          "language" : "de-CH",
          "value" : "Interferon alfa"
        },
        {
          "language" : "it-CH",
          "value" : "interferone alfa"
        }]
      },
      {
        "code" : "46843002",
        "display" : "Xanthine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Xanthine"
        },
        {
          "language" : "fr-CH",
          "value" : "xanthine"
        },
        {
          "language" : "de-CH",
          "value" : "Xanthin"
        },
        {
          "language" : "it-CH",
          "value" : "xantina"
        }]
      },
      {
        "code" : "48052001",
        "display" : "Enalaprilat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Enalaprilat"
        },
        {
          "language" : "fr-CH",
          "value" : "énalaprilate"
        },
        {
          "language" : "de-CH",
          "value" : "Enalaprilat"
        },
        {
          "language" : "it-CH",
          "value" : "enalaprilato"
        }]
      },
      {
        "code" : "48714008",
        "display" : "Palladium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Palladium"
        },
        {
          "language" : "fr-CH",
          "value" : "palladium"
        },
        {
          "language" : "de-CH",
          "value" : "Palladium"
        },
        {
          "language" : "it-CH",
          "value" : "palladio"
        }]
      },
      {
        "code" : "50665003",
        "display" : "Hydrocortisone butyrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydrocortisone butyrate"
        },
        {
          "language" : "fr-CH",
          "value" : "butyrate d'hydrocortisone"
        },
        {
          "language" : "de-CH",
          "value" : "Hydrocortisonbutyrat"
        },
        {
          "language" : "it-CH",
          "value" : "idrocortisone butirrato"
        }]
      },
      {
        "code" : "51503008",
        "display" : "Rose oil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rose oil"
        },
        {
          "language" : "fr-CH",
          "value" : "huile essentielle de rose"
        },
        {
          "language" : "de-CH",
          "value" : "Rosenöl"
        },
        {
          "language" : "it-CH",
          "value" : "olio di rosa"
        }]
      },
      {
        "code" : "51844001",
        "display" : "Tetracaine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetracaine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de tétracaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Tetracainhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "tetracaina cloridrato"
        }]
      },
      {
        "code" : "51905005",
        "display" : "Mustard (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mustard"
        },
        {
          "language" : "fr-CH",
          "value" : "moutarde"
        },
        {
          "language" : "de-CH",
          "value" : "Senf"
        },
        {
          "language" : "it-CH",
          "value" : "senape"
        }]
      },
      {
        "code" : "52370008",
        "display" : "Psyllium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Psyllium"
        },
        {
          "language" : "fr-CH",
          "value" : "psyllium"
        },
        {
          "language" : "de-CH",
          "value" : "Psyllium"
        },
        {
          "language" : "it-CH",
          "value" : "psillio"
        }]
      },
      {
        "code" : "52574003",
        "display" : "Amiodarone hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amiodarone hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate d'amiodarone"
        },
        {
          "language" : "de-CH",
          "value" : "Amiodaronhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "amiodarone cloridrato"
        }]
      },
      {
        "code" : "53034005",
        "display" : "Coal tar (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Coal tar"
        },
        {
          "language" : "fr-CH",
          "value" : "goudron de houille"
        },
        {
          "language" : "de-CH",
          "value" : "Kohleteer"
        },
        {
          "language" : "it-CH",
          "value" : "catrame di carbone"
        }]
      },
      {
        "code" : "54172006",
        "display" : "Orciprenaline sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Orciprenaline sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate d'orciprénaline"
        },
        {
          "language" : "de-CH",
          "value" : "Orciprenalinsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "orciprenalina solfato"
        }]
      },
      {
        "code" : "54808007",
        "display" : "Cobalt (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cobalt"
        },
        {
          "language" : "fr-CH",
          "value" : "cobalt"
        },
        {
          "language" : "de-CH",
          "value" : "Kobalt"
        },
        {
          "language" : "it-CH",
          "value" : "cobalto"
        }]
      },
      {
        "code" : "55358003",
        "display" : "Thiouracil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "thiouracil"
        },
        {
          "language" : "de-CH",
          "value" : "Thiouracil"
        },
        {
          "language" : "it-CH",
          "value" : "tiouracile"
        }]
      },
      {
        "code" : "55902002",
        "display" : "Benzyl alcohol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzyl alcohol"
        },
        {
          "language" : "fr-CH",
          "value" : "alcool benzylique"
        },
        {
          "language" : "de-CH",
          "value" : "Benzylalcohol"
        },
        {
          "language" : "it-CH",
          "value" : "alcol benzilico"
        }]
      },
      {
        "code" : "57272005",
        "display" : "Iodine compound (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iodine compound"
        },
        {
          "language" : "fr-CH",
          "value" : "composé d'iode"
        },
        {
          "language" : "de-CH",
          "value" : "Jodverbindung"
        },
        {
          "language" : "it-CH",
          "value" : "composto dello iodio"
        }]
      },
      {
        "code" : "57795002",
        "display" : "Chemical element (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chemical element"
        },
        {
          "language" : "fr-CH",
          "value" : "élément chimique"
        },
        {
          "language" : "de-CH",
          "value" : "Chemisches Element"
        },
        {
          "language" : "it-CH",
          "value" : "elemento chimico"
        }]
      },
      {
        "code" : "58202007",
        "display" : "Fructose (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fructose"
        },
        {
          "language" : "fr-CH",
          "value" : "fructose"
        },
        {
          "language" : "de-CH",
          "value" : "Fructose"
        },
        {
          "language" : "it-CH",
          "value" : "fruttosio"
        }]
      },
      {
        "code" : "58325006",
        "display" : "Mesuximide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mesuximide"
        },
        {
          "language" : "fr-CH",
          "value" : "mésuximide"
        },
        {
          "language" : "de-CH",
          "value" : "Mesuximid"
        },
        {
          "language" : "it-CH",
          "value" : "mesuximide"
        }]
      },
      {
        "code" : "63730009",
        "display" : "Calcitonin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Calcitonin"
        },
        {
          "language" : "fr-CH",
          "value" : "calcitonine"
        },
        {
          "language" : "de-CH",
          "value" : "Calcitonin"
        },
        {
          "language" : "it-CH",
          "value" : "calcitonina"
        }]
      },
      {
        "code" : "64099008",
        "display" : "Oligo-1,6-glucosidase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oligo-1,6-glucosidase"
        },
        {
          "language" : "fr-CH",
          "value" : "oligo-1,6-glucosidase"
        },
        {
          "language" : "de-CH",
          "value" : "Oligo-1,6-Glucosidase"
        },
        {
          "language" : "it-CH",
          "value" : "oligo-1,6-glucosidasi"
        }]
      },
      {
        "code" : "64686009",
        "display" : "Benzalkonium chloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzalkonium chloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorure de benzalkonium"
        },
        {
          "language" : "de-CH",
          "value" : "Benzalkoniumchlorid"
        },
        {
          "language" : "it-CH",
          "value" : "benzalconio cloruro"
        }]
      },
      {
        "code" : "65302009",
        "display" : "Choline salicylate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Choline salicylate"
        },
        {
          "language" : "fr-CH",
          "value" : "salicylate de choline"
        },
        {
          "language" : "de-CH",
          "value" : "Cholinsalicylat"
        },
        {
          "language" : "it-CH",
          "value" : "colina salicilato"
        }]
      },
      {
        "code" : "66925006",
        "display" : "Copper (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Copper"
        },
        {
          "language" : "fr-CH",
          "value" : "cuivre"
        },
        {
          "language" : "de-CH",
          "value" : "Kupfer"
        },
        {
          "language" : "it-CH",
          "value" : "rame"
        }]
      },
      {
        "code" : "67324005",
        "display" : "Rice (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rice"
        },
        {
          "language" : "fr-CH",
          "value" : "riz"
        },
        {
          "language" : "de-CH",
          "value" : "Reis"
        },
        {
          "language" : "it-CH",
          "value" : "riso"
        }]
      },
      {
        "code" : "67866001",
        "display" : "Insulin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Insulin"
        },
        {
          "language" : "fr-CH",
          "value" : "insuline"
        },
        {
          "language" : "de-CH",
          "value" : "Insulin"
        },
        {
          "language" : "it-CH",
          "value" : "insulina"
        }]
      },
      {
        "code" : "69314008",
        "display" : "Benzophenone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzophenone"
        },
        {
          "language" : "fr-CH",
          "value" : "benzophénone"
        },
        {
          "language" : "de-CH",
          "value" : "Benzophenon"
        },
        {
          "language" : "it-CH",
          "value" : "benzofenone"
        }]
      },
      {
        "code" : "69507005",
        "display" : "Phthalic acid ester (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phthalic acid ester"
        },
        {
          "language" : "fr-CH",
          "value" : "ester de l'acide phthalique"
        },
        {
          "language" : "de-CH",
          "value" : "Phthalsäureester"
        },
        {
          "language" : "it-CH",
          "value" : "estere dell’acido ftalico"
        }]
      },
      {
        "code" : "70570002",
        "display" : "Sulfadoxine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfadoxine"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfadoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfadoxin"
        },
        {
          "language" : "it-CH",
          "value" : "sulfadossina"
        }]
      },
      {
        "code" : "72069001",
        "display" : "Cytosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cytosine"
        },
        {
          "language" : "fr-CH",
          "value" : "cytosine"
        },
        {
          "language" : "de-CH",
          "value" : "Cytosin"
        },
        {
          "language" : "it-CH",
          "value" : "citosina"
        }]
      },
      {
        "code" : "72770009",
        "display" : "Metoprolol tartrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Metoprolol tartrate"
        },
        {
          "language" : "fr-CH",
          "value" : "tartrate de métoprolol"
        },
        {
          "language" : "de-CH",
          "value" : "Metoprololtartrat"
        },
        {
          "language" : "it-CH",
          "value" : "metoprololo tartrato"
        }]
      },
      {
        "code" : "75247008",
        "display" : "Benzathine benzylpenicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzathine benzylpenicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "benzathine benzylpénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Benzylpenicillin-Benzathin"
        },
        {
          "language" : "it-CH",
          "value" : "benzilpenicillina benzatinica"
        }]
      },
      {
        "code" : "75413007",
        "display" : "Arachis hypogaea (organism)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Arachis hypogaea"
        },
        {
          "language" : "fr-CH",
          "value" : "Arachis hypogaea"
        },
        {
          "language" : "de-CH",
          "value" : "Arachis hypogaea"
        },
        {
          "language" : "it-CH",
          "value" : "Arachis hypogaea"
        }]
      },
      {
        "code" : "76575003",
        "display" : "Podophyllotoxin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Podophyllotoxin"
        },
        {
          "language" : "fr-CH",
          "value" : "podophyllotoxine"
        },
        {
          "language" : "de-CH",
          "value" : "Podophyllotoxin"
        },
        {
          "language" : "it-CH",
          "value" : "podofillotossina"
        }]
      },
      {
        "code" : "77496001",
        "display" : "Lindane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lindane"
        },
        {
          "language" : "fr-CH",
          "value" : "lindane"
        },
        {
          "language" : "de-CH",
          "value" : "Lindan"
        },
        {
          "language" : "it-CH",
          "value" : "lindano"
        }]
      },
      {
        "code" : "77671006",
        "display" : "Antidiuretic hormone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Antidiuretic hormone"
        },
        {
          "language" : "fr-CH",
          "value" : "hormone antidiurétique"
        },
        {
          "language" : "de-CH",
          "value" : "Antidiuretisches Hormon"
        },
        {
          "language" : "it-CH",
          "value" : "ormone antidiuretico"
        }]
      },
      {
        "code" : "78702007",
        "display" : "Thalidomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thalidomide"
        },
        {
          "language" : "fr-CH",
          "value" : "thalidomide"
        },
        {
          "language" : "de-CH",
          "value" : "Thalidomid"
        },
        {
          "language" : "it-CH",
          "value" : "talidomide"
        }]
      },
      {
        "code" : "78772008",
        "display" : "Phenanthrene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenanthrene"
        },
        {
          "language" : "fr-CH",
          "value" : "phénanthrène"
        },
        {
          "language" : "de-CH",
          "value" : "Phenanthren"
        },
        {
          "language" : "it-CH",
          "value" : "fenantrene"
        }]
      },
      {
        "code" : "83595008",
        "display" : "Goat's milk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Goat's milk"
        },
        {
          "language" : "fr-CH",
          "value" : "lait de chèvre"
        },
        {
          "language" : "de-CH",
          "value" : "Ziegenmilch"
        },
        {
          "language" : "it-CH",
          "value" : "latte di capra"
        }]
      },
      {
        "code" : "84629008",
        "display" : "Androgen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Androgen"
        },
        {
          "language" : "fr-CH",
          "value" : "androgène"
        },
        {
          "language" : "de-CH",
          "value" : "Androgen"
        },
        {
          "language" : "it-CH",
          "value" : "androgeno"
        }]
      },
      {
        "code" : "85596006",
        "display" : "Fluorescein stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluorescein stain"
        },
        {
          "language" : "fr-CH",
          "value" : "fluorescéine"
        },
        {
          "language" : "de-CH",
          "value" : "Fluorescein-Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "fluoresceina"
        }]
      },
      {
        "code" : "85737002",
        "display" : "Chlorphenamine maleate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorphenamine maleate"
        },
        {
          "language" : "fr-CH",
          "value" : "maléate de chlorphénamine"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorphenaminmaleat"
        },
        {
          "language" : "it-CH",
          "value" : "clorfenamina maleato"
        }]
      },
      {
        "code" : "87097009",
        "display" : "Nitrofural (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nitrofural"
        },
        {
          "language" : "fr-CH",
          "value" : "nitrofural"
        },
        {
          "language" : "de-CH",
          "value" : "Nitrofural"
        },
        {
          "language" : "it-CH",
          "value" : "nitrofurazone"
        }]
      },
      {
        "code" : "387189002",
        "display" : "Gemfibrozil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gemfibrozil"
        },
        {
          "language" : "fr-CH",
          "value" : "gemfibrozil"
        },
        {
          "language" : "de-CH",
          "value" : "Gemfibrozil"
        },
        {
          "language" : "it-CH",
          "value" : "gemfibrozil"
        }]
      },
      {
        "code" : "87645001",
        "display" : "Hexylene glycol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hexylene glycol"
        },
        {
          "language" : "fr-CH",
          "value" : "hexylène glycol"
        },
        {
          "language" : "de-CH",
          "value" : "Hexylenglykol"
        },
        {
          "language" : "it-CH",
          "value" : "esilenglicole"
        }]
      },
      {
        "code" : "89811004",
        "display" : "Gluten (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gluten"
        },
        {
          "language" : "fr-CH",
          "value" : "gluten"
        },
        {
          "language" : "de-CH",
          "value" : "Gluten"
        },
        {
          "language" : "it-CH",
          "value" : "glutine"
        }]
      },
      {
        "code" : "90220005",
        "display" : "Novobiocin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Novobiocin"
        },
        {
          "language" : "fr-CH",
          "value" : "novobiocine"
        },
        {
          "language" : "de-CH",
          "value" : "Novobiocin"
        },
        {
          "language" : "it-CH",
          "value" : "novobiocina"
        }]
      },
      {
        "code" : "96079005",
        "display" : "Pipemidic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pipemidic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide pipémidique"
        },
        {
          "language" : "de-CH",
          "value" : "Pipemidinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido pipemidico"
        }]
      },
      {
        "code" : "96229001",
        "display" : "Azaperone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azaperone"
        },
        {
          "language" : "fr-CH",
          "value" : "azapérone"
        },
        {
          "language" : "de-CH",
          "value" : "Azaperon"
        },
        {
          "language" : "it-CH",
          "value" : "azaperone"
        }]
      },
      {
        "code" : "102261002",
        "display" : "Strawberry (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Strawberry"
        },
        {
          "language" : "fr-CH",
          "value" : "fraise"
        },
        {
          "language" : "de-CH",
          "value" : "Erdbeere"
        },
        {
          "language" : "it-CH",
          "value" : "fragola"
        }]
      },
      {
        "code" : "102262009",
        "display" : "Chocolate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chocolate"
        },
        {
          "language" : "fr-CH",
          "value" : "chocolat"
        },
        {
          "language" : "de-CH",
          "value" : "Schokolade"
        },
        {
          "language" : "it-CH",
          "value" : "cioccolato"
        }]
      },
      {
        "code" : "102693004",
        "display" : "Dermatan sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dermatan sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "dermatane sulfate"
        },
        {
          "language" : "de-CH",
          "value" : "Dermatansulfat"
        },
        {
          "language" : "it-CH",
          "value" : "dermatan solfato"
        }]
      },
      {
        "code" : "102698008",
        "display" : "Alpha-lactalbumin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alpha-lactalbumin"
        },
        {
          "language" : "fr-CH",
          "value" : "alpha-lactalbumine"
        },
        {
          "language" : "de-CH",
          "value" : "Alpha-Lactalbumin"
        },
        {
          "language" : "it-CH",
          "value" : "alfa-lattoalbumina"
        }]
      },
      {
        "code" : "108501006",
        "display" : "Propafenone hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propafenone hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de propafénone"
        },
        {
          "language" : "de-CH",
          "value" : "Propafenonhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "propafenone cloridrato"
        }]
      },
      {
        "code" : "108513001",
        "display" : "Ketorolac trometamol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketorolac trometamol"
        },
        {
          "language" : "fr-CH",
          "value" : "kétorolac trométhamine"
        },
        {
          "language" : "de-CH",
          "value" : "Ketorolactrometamol"
        },
        {
          "language" : "it-CH",
          "value" : "ketorolac trometamolo"
        }]
      },
      {
        "code" : "108527006",
        "display" : "Nicardipine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nicardipine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de nicardipine"
        },
        {
          "language" : "de-CH",
          "value" : "Nicardipinhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "nicardipina cloridrato"
        }]
      },
      {
        "code" : "108570006",
        "display" : "Fosinopril sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fosinopril sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "fosinopril sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Fosinopril-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "fosinopril sodico"
        }]
      },
      {
        "code" : "108573008",
        "display" : "Benazepril hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benazepril hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de bénazépril"
        },
        {
          "language" : "de-CH",
          "value" : "Benazeprilhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "benazepril cloridrato"
        }]
      },
      {
        "code" : "108653007",
        "display" : "Fexofenadine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fexofenadine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de fexofénadine"
        },
        {
          "language" : "de-CH",
          "value" : "Fexofenadinhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "fexofenadina cloridrato"
        }]
      },
      {
        "code" : "108686006",
        "display" : "Rifapentine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rifapentine"
        },
        {
          "language" : "fr-CH",
          "value" : "rifapentine"
        },
        {
          "language" : "de-CH",
          "value" : "Rifapentin"
        },
        {
          "language" : "it-CH",
          "value" : "rifapentina"
        }]
      },
      {
        "code" : "108765002",
        "display" : "Fludarabine phosphate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fludarabine phosphate"
        },
        {
          "language" : "fr-CH",
          "value" : "phosphate de fludarabine"
        },
        {
          "language" : "de-CH",
          "value" : "Fludarabinphosphat"
        },
        {
          "language" : "it-CH",
          "value" : "fludarabina fosfato"
        }]
      },
      {
        "code" : "108867000",
        "display" : "Sulfacetamide sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfacetamide sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfacétamide sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfacetamid-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "sulfacetamide sodica"
        }]
      },
      {
        "code" : "109046009",
        "display" : "Nafarelin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nafarelin"
        },
        {
          "language" : "fr-CH",
          "value" : "nafaréline"
        },
        {
          "language" : "de-CH",
          "value" : "Nafarelin"
        },
        {
          "language" : "it-CH",
          "value" : "nafarelina"
        }]
      },
      {
        "code" : "109106000",
        "display" : "Tiopronin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tiopronin"
        },
        {
          "language" : "fr-CH",
          "value" : "tiopronine"
        },
        {
          "language" : "de-CH",
          "value" : "Tiopronin"
        },
        {
          "language" : "it-CH",
          "value" : "tiopronina"
        }]
      },
      {
        "code" : "109117004",
        "display" : "Pentosan polysulfate sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentosan polysulfate sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "pentosane polysulfate sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Pentosanpolysulfat-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "pentosano polisolfato sodico"
        }]
      },
      {
        "code" : "111070004",
        "display" : "Chromium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chromium"
        },
        {
          "language" : "fr-CH",
          "value" : "chrome"
        },
        {
          "language" : "de-CH",
          "value" : "Chromium"
        },
        {
          "language" : "it-CH",
          "value" : "cromo"
        }]
      },
      {
        "code" : "111095003",
        "display" : "Formaldehyde (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Formaldehyde"
        },
        {
          "language" : "fr-CH",
          "value" : "formaldéhyde"
        },
        {
          "language" : "de-CH",
          "value" : "Formaldehyd"
        },
        {
          "language" : "it-CH",
          "value" : "formaldeide"
        }]
      },
      {
        "code" : "111100001",
        "display" : "Tosylchloramide sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tosylchloramide sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "tosylchloramide sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Tosylchloramid-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "tosilcloramide sodica"
        }]
      },
      {
        "code" : "111134000",
        "display" : "Oxetacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxetacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "oxétacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Oxetacain"
        },
        {
          "language" : "it-CH",
          "value" : "oxetacaina"
        }]
      },
      {
        "code" : "116086005",
        "display" : "Alitretinoin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alitretinoin"
        },
        {
          "language" : "fr-CH",
          "value" : "alitrétinoïne"
        },
        {
          "language" : "de-CH",
          "value" : "Alitretinoin"
        },
        {
          "language" : "it-CH",
          "value" : "alitretinoina"
        }]
      },
      {
        "code" : "116087001",
        "display" : "Cilostazol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cilostazol"
        },
        {
          "language" : "fr-CH",
          "value" : "Cilostazol"
        },
        {
          "language" : "de-CH",
          "value" : "Cilostazol"
        },
        {
          "language" : "it-CH",
          "value" : "cilostazolo"
        }]
      },
      {
        "code" : "116108007",
        "display" : "Epirubicin hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Epirubicin hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate d'épirubicine"
        },
        {
          "language" : "de-CH",
          "value" : "Epirubicinhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "epirubicina cloridrato"
        }]
      },
      {
        "code" : "116287005",
        "display" : "Triarylmethane dye (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Triarylmethane dye"
        },
        {
          "language" : "fr-CH",
          "value" : "bleu patenté sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Triarylmethan-Farbstoff"
        },
        {
          "language" : "it-CH",
          "value" : "triarilmetano"
        }]
      },
      {
        "code" : "116613007",
        "display" : "Phenol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenol"
        },
        {
          "language" : "fr-CH",
          "value" : "phénol"
        },
        {
          "language" : "de-CH",
          "value" : "Phenol"
        },
        {
          "language" : "it-CH",
          "value" : "fenolo"
        }]
      },
      {
        "code" : "126075009",
        "display" : "Methylergometrine maleate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methylergometrine maleate"
        },
        {
          "language" : "fr-CH",
          "value" : "maléate de méthylergométrine"
        },
        {
          "language" : "de-CH",
          "value" : "Methylergometrinmaleat"
        },
        {
          "language" : "it-CH",
          "value" : "metilergometrina maleato"
        }]
      },
      {
        "code" : "126092000",
        "display" : "Megestrol acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Megestrol acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate de mégestrol"
        },
        {
          "language" : "de-CH",
          "value" : "Megestrolacetat"
        },
        {
          "language" : "it-CH",
          "value" : "megestrolo acetato"
        }]
      },
      {
        "code" : "126120000",
        "display" : "Cyproterone acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cyproterone acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate de cyprotérone"
        },
        {
          "language" : "de-CH",
          "value" : "Cyproteronacetat"
        },
        {
          "language" : "it-CH",
          "value" : "ciproterone acetato"
        }]
      },
      {
        "code" : "126124009",
        "display" : "Danazol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Danazol"
        },
        {
          "language" : "fr-CH",
          "value" : "danazol"
        },
        {
          "language" : "de-CH",
          "value" : "Danazol"
        },
        {
          "language" : "it-CH",
          "value" : "danazolo"
        }]
      },
      {
        "code" : "126225001",
        "display" : "Calcium pantothenate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Calcium pantothenate"
        },
        {
          "language" : "fr-CH",
          "value" : "pantothénate de calcium"
        },
        {
          "language" : "de-CH",
          "value" : "Calciumpantothenat"
        },
        {
          "language" : "it-CH",
          "value" : "calcio pantotenato"
        }]
      },
      {
        "code" : "127382005",
        "display" : "Cortisone acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cortisone acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate de cortisone"
        },
        {
          "language" : "de-CH",
          "value" : "Cortisonacetat"
        },
        {
          "language" : "it-CH",
          "value" : "cortisone acetato"
        }]
      },
      {
        "code" : "127384006",
        "display" : "Salmon calcitonin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salmon calcitonin"
        },
        {
          "language" : "fr-CH",
          "value" : "calcitonine de saumon"
        },
        {
          "language" : "de-CH",
          "value" : "Calcitonin vom Lachs"
        },
        {
          "language" : "it-CH",
          "value" : "calcitonina di salmone"
        }]
      },
      {
        "code" : "127964000",
        "display" : "Gemtuzumab ozogamicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gemtuzumab ozogamicin"
        },
        {
          "language" : "fr-CH",
          "value" : "gemtuzumab ozogamicin"
        },
        {
          "language" : "de-CH",
          "value" : "Gemtuzumab-Ozogamicin"
        },
        {
          "language" : "it-CH",
          "value" : "gemtuzumab ozogamicin"
        }]
      },
      {
        "code" : "128488006",
        "display" : "House dust (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "House dust"
        },
        {
          "language" : "fr-CH",
          "value" : "poussière de maison"
        },
        {
          "language" : "de-CH",
          "value" : "Hausstaub"
        },
        {
          "language" : "it-CH",
          "value" : "polvere domestica"
        }]
      },
      {
        "code" : "226723006",
        "display" : "Buckwheat - cereal (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buckwheat - cereal"
        },
        {
          "language" : "fr-CH",
          "value" : "gruau de sarrasin"
        },
        {
          "language" : "de-CH",
          "value" : "Buchweizen - Getreide"
        },
        {
          "language" : "it-CH",
          "value" : "grano saraceno"
        }]
      },
      {
        "code" : "226791004",
        "display" : "Sheep milk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sheep milk"
        },
        {
          "language" : "fr-CH",
          "value" : "lait de brebis"
        },
        {
          "language" : "de-CH",
          "value" : "Schafsmilch"
        },
        {
          "language" : "it-CH",
          "value" : "latte di pecora"
        }]
      },
      {
        "code" : "226916002",
        "display" : "Beef (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Beef"
        },
        {
          "language" : "fr-CH",
          "value" : "bœuf"
        },
        {
          "language" : "de-CH",
          "value" : "Rindfleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne di manzo"
        }]
      },
      {
        "code" : "226934003",
        "display" : "Pork (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pork"
        },
        {
          "language" : "fr-CH",
          "value" : "porc"
        },
        {
          "language" : "de-CH",
          "value" : "Schweinefleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne di maiale"
        }]
      },
      {
        "code" : "226955001",
        "display" : "Chicken - meat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chicken - meat"
        },
        {
          "language" : "fr-CH",
          "value" : "viande de poulet"
        },
        {
          "language" : "de-CH",
          "value" : "Poulet - Fleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne di pollo"
        }]
      },
      {
        "code" : "226963000",
        "display" : "Duck - meat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Duck - meat"
        },
        {
          "language" : "fr-CH",
          "value" : "viande de canard"
        },
        {
          "language" : "de-CH",
          "value" : "Ente - Fleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne di anatra"
        }]
      },
      {
        "code" : "227218003",
        "display" : "Asparagus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Asparagus"
        },
        {
          "language" : "fr-CH",
          "value" : "asperge"
        },
        {
          "language" : "de-CH",
          "value" : "Spargel"
        },
        {
          "language" : "it-CH",
          "value" : "asparago"
        }]
      },
      {
        "code" : "227313005",
        "display" : "Pulse vegetable (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pulse vegetable"
        },
        {
          "language" : "fr-CH",
          "value" : "légumes secs"
        },
        {
          "language" : "de-CH",
          "value" : "Hülsenfrucht"
        },
        {
          "language" : "it-CH",
          "value" : "leguminosa"
        }]
      },
      {
        "code" : "227388008",
        "display" : "Cinnamon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cinnamon"
        },
        {
          "language" : "fr-CH",
          "value" : "cannelle"
        },
        {
          "language" : "de-CH",
          "value" : "Zimt"
        },
        {
          "language" : "it-CH",
          "value" : "cannella"
        }]
      },
      {
        "code" : "227410007",
        "display" : "Rosemary (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rosemary"
        },
        {
          "language" : "fr-CH",
          "value" : "romarin"
        },
        {
          "language" : "de-CH",
          "value" : "Rosmarin"
        },
        {
          "language" : "it-CH",
          "value" : "rosmarino"
        }]
      },
      {
        "code" : "227411006",
        "display" : "Sage (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sage"
        },
        {
          "language" : "fr-CH",
          "value" : "sauge"
        },
        {
          "language" : "de-CH",
          "value" : "Salbei"
        },
        {
          "language" : "it-CH",
          "value" : "salvia"
        }]
      },
      {
        "code" : "227511008",
        "display" : "Pine nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pine nut"
        },
        {
          "language" : "fr-CH",
          "value" : "pomme de pin"
        },
        {
          "language" : "de-CH",
          "value" : "Pinienkern"
        },
        {
          "language" : "it-CH",
          "value" : "pinolo"
        }]
      },
      {
        "code" : "228083006",
        "display" : "Brilliant blue FCF (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brilliant blue FCF"
        },
        {
          "language" : "fr-CH",
          "value" : "bleu brillant FCF"
        },
        {
          "language" : "de-CH",
          "value" : "Brillantblau FCF"
        },
        {
          "language" : "it-CH",
          "value" : "blu brillante FCF"
        }]
      },
      {
        "code" : "229936000",
        "display" : "Cornflour (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cornflour"
        },
        {
          "language" : "fr-CH",
          "value" : "farine de maïs"
        },
        {
          "language" : "de-CH",
          "value" : "Maismehl"
        },
        {
          "language" : "it-CH",
          "value" : "amido di mais"
        }]
      },
      {
        "code" : "229940009",
        "display" : "Rye flour (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rye flour"
        },
        {
          "language" : "fr-CH",
          "value" : "farine de seigle"
        },
        {
          "language" : "de-CH",
          "value" : "Roggenmehl"
        },
        {
          "language" : "it-CH",
          "value" : "farina di segale"
        }]
      },
      {
        "code" : "229942001",
        "display" : "Millet flour (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Millet flour"
        },
        {
          "language" : "fr-CH",
          "value" : "farine de millet"
        },
        {
          "language" : "de-CH",
          "value" : "Hirsemehl"
        },
        {
          "language" : "it-CH",
          "value" : "farina di miglio"
        }]
      },
      {
        "code" : "229944000",
        "display" : "Wheat flour (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Wheat flour"
        },
        {
          "language" : "fr-CH",
          "value" : "farine de blé"
        },
        {
          "language" : "de-CH",
          "value" : "Weizenmehl"
        },
        {
          "language" : "it-CH",
          "value" : "farina di frumento"
        }]
      },
      {
        "code" : "255637000",
        "display" : "Salicylate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Salicylate"
        },
        {
          "language" : "fr-CH",
          "value" : "salicylate"
        },
        {
          "language" : "de-CH",
          "value" : "Salicylat"
        },
        {
          "language" : "it-CH",
          "value" : "salicilato"
        }]
      },
      {
        "code" : "255666002",
        "display" : "Para-aminosalicylic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Para-aminosalicylic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide para-aminosalicylique"
        },
        {
          "language" : "de-CH",
          "value" : "Paraaminosalicylsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido para-aminosalicilico"
        }]
      },
      {
        "code" : "255863008",
        "display" : "Clorquinaldol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clorquinaldol"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorquinaldol"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorquinaldol"
        },
        {
          "language" : "it-CH",
          "value" : "clorchinaldolo"
        }]
      },
      {
        "code" : "255881006",
        "display" : "2-bromo-2-nitropropane-1,3-diol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "2-bromo-2-nitropropane-1,3-diol"
        },
        {
          "language" : "fr-CH",
          "value" : "bronopol"
        },
        {
          "language" : "de-CH",
          "value" : "2-Brom-2-Nitro-1,3-Propandiol"
        },
        {
          "language" : "it-CH",
          "value" : "2-bromo-2-nitropropano-1,3-diolo"
        }]
      },
      {
        "code" : "255899003",
        "display" : "Polyoxethylene sorbitan oleate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Polyoxethylene sorbitan oleate"
        },
        {
          "language" : "fr-CH",
          "value" : "polysorbitate 80"
        },
        {
          "language" : "de-CH",
          "value" : "Polyoxyethylensorbitanoleat"
        },
        {
          "language" : "it-CH",
          "value" : "poliossietilene sorbitano oleato"
        }]
      },
      {
        "code" : "255904004",
        "display" : "Sorbitan monooleate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sorbitan monooleate"
        },
        {
          "language" : "fr-CH",
          "value" : "monoléate de sorbitane"
        },
        {
          "language" : "de-CH",
          "value" : "Sorbitanmonooleat"
        },
        {
          "language" : "it-CH",
          "value" : "sorbitano monooleato"
        }]
      },
      {
        "code" : "255905003",
        "display" : "Sorbitan sesquioleate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sorbitan sesquioleate"
        },
        {
          "language" : "fr-CH",
          "value" : "sesquioléate de sorbitane"
        },
        {
          "language" : "de-CH",
          "value" : "Sorbitansesquioleat"
        },
        {
          "language" : "it-CH",
          "value" : "sorbitano sesquioleato"
        }]
      },
      {
        "code" : "255947004",
        "display" : "Cocamidopropylbetaine (in water) (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cocamidopropylbetaine"
        },
        {
          "language" : "fr-CH",
          "value" : "bétaïne de cocamidopropyle"
        },
        {
          "language" : "de-CH",
          "value" : "Cocamidopropylbetain"
        },
        {
          "language" : "it-CH",
          "value" : "cocamidopropil betaina"
        }]
      },
      {
        "code" : "255971006",
        "display" : "Quinoline yellow (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Quinoline yellow"
        },
        {
          "language" : "fr-CH",
          "value" : "jaune de quinoléine"
        },
        {
          "language" : "de-CH",
          "value" : "Chinolingelb"
        },
        {
          "language" : "it-CH",
          "value" : "giallo di chinolina"
        }]
      },
      {
        "code" : "256013006",
        "display" : "Perfumes and flavors patch test series (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "séries de tests épicutanés de parfums et saveurs"
        },
        {
          "language" : "fr-CH",
          "value" : "Perfumes and flavors patch test series"
        },
        {
          "language" : "de-CH",
          "value" : "Düfte- und Aromen-Epikutantestreihe"
        },
        {
          "language" : "it-CH",
          "value" : "patch test serie profumi e aromi"
        }]
      },
      {
        "code" : "256015004",
        "display" : "Benzyl salicylate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzyl salicylate"
        },
        {
          "language" : "fr-CH",
          "value" : "salicylate de benzyle"
        },
        {
          "language" : "de-CH",
          "value" : "Benzylalicylat"
        },
        {
          "language" : "it-CH",
          "value" : "benzil salicilato"
        }]
      },
      {
        "code" : "256018002",
        "display" : "Clove oil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clove oil"
        },
        {
          "language" : "fr-CH",
          "value" : "huile de clou de girofle"
        },
        {
          "language" : "de-CH",
          "value" : "Nelkenöl"
        },
        {
          "language" : "it-CH",
          "value" : "olio di chiodi di garofano"
        }]
      },
      {
        "code" : "256079000",
        "display" : "Usnic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Usnic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide usnique"
        },
        {
          "language" : "de-CH",
          "value" : "Usninsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido usnico"
        }]
      },
      {
        "code" : "256166007",
        "display" : "Diphenylguanidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diphenylguanidine"
        },
        {
          "language" : "fr-CH",
          "value" : "diphénylguanidine"
        },
        {
          "language" : "de-CH",
          "value" : "Diphenylguanidin"
        },
        {
          "language" : "it-CH",
          "value" : "difenilguanidina"
        }]
      },
      {
        "code" : "256168008",
        "display" : "Nigrosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "nigrosine"
        },
        {
          "language" : "fr-CH",
          "value" : "nigrosine"
        },
        {
          "language" : "de-CH",
          "value" : "Nigrosin"
        },
        {
          "language" : "it-CH",
          "value" : "nigrosina"
        }]
      },
      {
        "code" : "256214007",
        "display" : "Chamomile extract (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chamomile extract"
        },
        {
          "language" : "fr-CH",
          "value" : "extrait de camomille"
        },
        {
          "language" : "de-CH",
          "value" : "Kamillenextrakt"
        },
        {
          "language" : "it-CH",
          "value" : "estratto di camomilla"
        }]
      },
      {
        "code" : "256259004",
        "display" : "Pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen"
        },
        {
          "language" : "de-CH",
          "value" : "Pollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline"
        }]
      },
      {
        "code" : "256262001",
        "display" : "Silver birch pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Silver birch pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen de bouleau"
        },
        {
          "language" : "de-CH",
          "value" : "Silberbirkenpollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline di betulla"
        }]
      },
      {
        "code" : "256263006",
        "display" : "Hazel pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hazel pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen de noisetier"
        },
        {
          "language" : "de-CH",
          "value" : "Haselpollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline di nocciolo"
        }]
      },
      {
        "code" : "256266003",
        "display" : "Ash pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ash pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen de frêne"
        },
        {
          "language" : "de-CH",
          "value" : "Eschenpollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline di frassino"
        }]
      },
      {
        "code" : "256277009",
        "display" : "Grass pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Grass pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen de graminées"
        },
        {
          "language" : "de-CH",
          "value" : "Gräserpollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline di graminacee"
        }]
      },
      {
        "code" : "256306003",
        "display" : "Orange - fruit (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Orange - fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "orange - fruit"
        },
        {
          "language" : "de-CH",
          "value" : "Orange - Frucht"
        },
        {
          "language" : "it-CH",
          "value" : "arancia"
        }]
      },
      {
        "code" : "256307007",
        "display" : "Banana (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Banana"
        },
        {
          "language" : "fr-CH",
          "value" : "banane"
        },
        {
          "language" : "de-CH",
          "value" : "Banane"
        },
        {
          "language" : "it-CH",
          "value" : "banana"
        }]
      },
      {
        "code" : "256313003",
        "display" : "Pineapple (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pineapple"
        },
        {
          "language" : "fr-CH",
          "value" : "ananas"
        },
        {
          "language" : "de-CH",
          "value" : "Ananas"
        },
        {
          "language" : "it-CH",
          "value" : "ananas"
        }]
      },
      {
        "code" : "256319004",
        "display" : "Carrot (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carrot"
        },
        {
          "language" : "fr-CH",
          "value" : "carotte"
        },
        {
          "language" : "de-CH",
          "value" : "Karotte"
        },
        {
          "language" : "it-CH",
          "value" : "carota"
        }]
      },
      {
        "code" : "256326004",
        "display" : "Celery (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Celery"
        },
        {
          "language" : "fr-CH",
          "value" : "céleri"
        },
        {
          "language" : "de-CH",
          "value" : "Sellerie"
        },
        {
          "language" : "it-CH",
          "value" : "sedano"
        }]
      },
      {
        "code" : "256352005",
        "display" : "Walnut - nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Walnut - nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix simple"
        },
        {
          "language" : "de-CH",
          "value" : "Walnuss - Nuss"
        },
        {
          "language" : "it-CH",
          "value" : "noce (frutto)"
        }]
      },
      {
        "code" : "256353000",
        "display" : "Hazelnut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hazelnut"
        },
        {
          "language" : "fr-CH",
          "value" : "noisette"
        },
        {
          "language" : "de-CH",
          "value" : "Haselnuss"
        },
        {
          "language" : "it-CH",
          "value" : "nocciola"
        }]
      },
      {
        "code" : "256409006",
        "display" : "Cat epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cat epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de chat"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel der Katze"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di gatto"
        }]
      },
      {
        "code" : "256411002",
        "display" : "Dog epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dog epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de chien"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel des Hundes"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di cane"
        }]
      },
      {
        "code" : "256417003",
        "display" : "Horse dander (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Horse dander"
        },
        {
          "language" : "fr-CH",
          "value" : "squame de cheval"
        },
        {
          "language" : "de-CH",
          "value" : "Hautschuppen des Pferdes"
        },
        {
          "language" : "it-CH",
          "value" : "pelo di cavallo"
        }]
      },
      {
        "code" : "256418008",
        "display" : "Horse epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Horse epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de cheval"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel des Pferdes"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di cavallo"
        }]
      },
      {
        "code" : "256419000",
        "display" : "Mouse epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mouse epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de souris"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel der Maus"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di topo"
        }]
      },
      {
        "code" : "256421005",
        "display" : "Rabbit epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rabbit epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de lapin"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel des Kaninchens"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di coniglio"
        }]
      },
      {
        "code" : "256422003",
        "display" : "Rat epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rat epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de rat"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel der Ratte"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di ratto"
        }]
      },
      {
        "code" : "256439001",
        "display" : "Honey bee venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Honey bee venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin d'abeille"
        },
        {
          "language" : "de-CH",
          "value" : "Honigbienengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di ape"
        }]
      },
      {
        "code" : "256440004",
        "display" : "Wasp venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Wasp venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de guêpe"
        },
        {
          "language" : "de-CH",
          "value" : "Wespengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di vespa"
        }]
      },
      {
        "code" : "256442007",
        "display" : "Egg yolk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Egg yolk"
        },
        {
          "language" : "fr-CH",
          "value" : "jaune d'œuf"
        },
        {
          "language" : "de-CH",
          "value" : "Eigelb"
        },
        {
          "language" : "it-CH",
          "value" : "tuorlo d’uovo"
        }]
      },
      {
        "code" : "259123004",
        "display" : "Allyl isothiocyanate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Allyl isothiocyanate"
        },
        {
          "language" : "fr-CH",
          "value" : "isothiocyanate d'allyle"
        },
        {
          "language" : "de-CH",
          "value" : "Allylisothiocyanat"
        },
        {
          "language" : "it-CH",
          "value" : "allile isotiocianato"
        }]
      },
      {
        "code" : "260159000",
        "display" : "Mouse serum proteins (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mouse serum proteins"
        },
        {
          "language" : "fr-CH",
          "value" : "protéines de sérum de souris"
        },
        {
          "language" : "de-CH",
          "value" : "Serumproteine der Maus"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del siero murino"
        }]
      },
      {
        "code" : "260160005",
        "display" : "Budgerigar droppings (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Budgerigar droppings"
        },
        {
          "language" : "fr-CH",
          "value" : "excréments de perruche"
        },
        {
          "language" : "de-CH",
          "value" : "Wellensittichkot"
        },
        {
          "language" : "it-CH",
          "value" : "escrementi di pappagallo"
        }]
      },
      {
        "code" : "260164001",
        "display" : "Hamster epithelium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hamster epithelium"
        },
        {
          "language" : "fr-CH",
          "value" : "épithélium de hamster"
        },
        {
          "language" : "de-CH",
          "value" : "Epithel des Hamsters"
        },
        {
          "language" : "it-CH",
          "value" : "epitelio di criceto"
        }]
      },
      {
        "code" : "260167008",
        "display" : "Sesame seed (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sesame seed"
        },
        {
          "language" : "fr-CH",
          "value" : "graine de sésame"
        },
        {
          "language" : "de-CH",
          "value" : "Sesamsamen"
        },
        {
          "language" : "it-CH",
          "value" : "semi di sesamo"
        }]
      },
      {
        "code" : "260176001",
        "display" : "Kiwi fruit (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Kiwi fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "kiwi"
        },
        {
          "language" : "de-CH",
          "value" : "Kiwifrucht"
        },
        {
          "language" : "it-CH",
          "value" : "kiwi"
        }]
      },
      {
        "code" : "260177005",
        "display" : "Melon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Melon"
        },
        {
          "language" : "fr-CH",
          "value" : "melon"
        },
        {
          "language" : "de-CH",
          "value" : "Melone"
        },
        {
          "language" : "it-CH",
          "value" : "melone"
        }]
      },
      {
        "code" : "260179008",
        "display" : "Mango fruit (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mango fruit"
        },
        {
          "language" : "fr-CH",
          "value" : "mangue"
        },
        {
          "language" : "de-CH",
          "value" : "Mangofrucht"
        },
        {
          "language" : "it-CH",
          "value" : "mango"
        }]
      },
      {
        "code" : "260184002",
        "display" : "Pea (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pea"
        },
        {
          "language" : "fr-CH",
          "value" : "pois"
        },
        {
          "language" : "de-CH",
          "value" : "Erbse"
        },
        {
          "language" : "it-CH",
          "value" : "pisello"
        }]
      },
      {
        "code" : "260196009",
        "display" : "European hornet venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "European hornet venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de frelon européen"
        },
        {
          "language" : "de-CH",
          "value" : "Gift der Europäischen Hornisse"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di calabrone europeo"
        }]
      },
      {
        "code" : "264295007",
        "display" : "Cow's milk protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cow's milk protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de lait de vache"
        },
        {
          "language" : "de-CH",
          "value" : "Kuhmilchprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del latte vaccino"
        }]
      },
      {
        "code" : "273948005",
        "display" : "Chloral hydrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chloral hydrate"
        },
        {
          "language" : "fr-CH",
          "value" : "hydrate de chloral"
        },
        {
          "language" : "de-CH",
          "value" : "Chloralhydrat"
        },
        {
          "language" : "it-CH",
          "value" : "cloralio idrato"
        }]
      },
      {
        "code" : "278840001",
        "display" : "Shrimp (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Shrimp"
        },
        {
          "language" : "fr-CH",
          "value" : "crevette"
        },
        {
          "language" : "de-CH",
          "value" : "Shrimps"
        },
        {
          "language" : "it-CH",
          "value" : "gamberetto"
        }]
      },
      {
        "code" : "280939008",
        "display" : "Insect venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Insect venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin d'insecte"
        },
        {
          "language" : "de-CH",
          "value" : "Insektengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di insetti"
        }]
      },
      {
        "code" : "297276002",
        "display" : "Chamomilla romana allergen patch test substance (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chamomilla romana allergen patch test substance"
        },
        {
          "language" : "fr-CH",
          "value" : "test cutané d'allergie à la camomille romaine"
        },
        {
          "language" : "de-CH",
          "value" : "Chamomilla romana Allergen-Epikutantestsubstanz"
        },
        {
          "language" : "it-CH",
          "value" : "allergene di camomilla romana per patch test"
        }]
      },
      {
        "code" : "303300008",
        "display" : "Egg protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Egg protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine d'œuf"
        },
        {
          "language" : "de-CH",
          "value" : "Eiprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine dell’uovo"
        }]
      },
      {
        "code" : "304111003",
        "display" : "Cobalamin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cobalamin"
        },
        {
          "language" : "fr-CH",
          "value" : "cobalamine"
        },
        {
          "language" : "de-CH",
          "value" : "Cobalamin"
        },
        {
          "language" : "it-CH",
          "value" : "cobalamina"
        }]
      },
      {
        "code" : "322052003",
        "display" : "Betahistine dihydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Betahistine dihydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "dichlorhydrate de bétahistine"
        },
        {
          "language" : "de-CH",
          "value" : "Betahistindihydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "betaistina dicloridrato"
        }]
      },
      {
        "code" : "331143003",
        "display" : "Benzydamine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzydamine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de benzydamine"
        },
        {
          "language" : "de-CH",
          "value" : "Benzydaminhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "benzidamina cloridrato"
        }]
      },
      {
        "code" : "363581004",
        "display" : "Tetrabenazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tetrabenazine"
        },
        {
          "language" : "fr-CH",
          "value" : "tétrabénazine"
        },
        {
          "language" : "de-CH",
          "value" : "Tetrabenazin"
        },
        {
          "language" : "it-CH",
          "value" : "tetrabenazina"
        }]
      },
      {
        "code" : "370893003",
        "display" : "Crisantaspase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Crisantaspase"
        },
        {
          "language" : "fr-CH",
          "value" : "erwinia asparaginase"
        },
        {
          "language" : "de-CH",
          "value" : "Crisantaspase"
        },
        {
          "language" : "it-CH",
          "value" : "crisantaspasi"
        }]
      },
      {
        "code" : "370969007",
        "display" : "Escherichia coli asparaginase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Escherichia coli asparaginase"
        },
        {
          "language" : "fr-CH",
          "value" : "asparaginase dérivée d'Escherichia coli"
        },
        {
          "language" : "de-CH",
          "value" : "Escherichia coli-Asparaginase"
        },
        {
          "language" : "it-CH",
          "value" : "asparaginasi di Escherichia coli"
        }]
      },
      {
        "code" : "372493004",
        "display" : "Mivacurium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mivacurium"
        },
        {
          "language" : "fr-CH",
          "value" : "mivacurium"
        },
        {
          "language" : "de-CH",
          "value" : "Mivacurium"
        },
        {
          "language" : "it-CH",
          "value" : "mivacurio"
        }]
      },
      {
        "code" : "372494005",
        "display" : "Rocuronium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rocuronium"
        },
        {
          "language" : "fr-CH",
          "value" : "rocuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Rocuronium"
        },
        {
          "language" : "it-CH",
          "value" : "rocuronio"
        }]
      },
      {
        "code" : "372498008",
        "display" : "Pergolide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pergolide"
        },
        {
          "language" : "fr-CH",
          "value" : "pergolide"
        },
        {
          "language" : "de-CH",
          "value" : "Pergolid"
        },
        {
          "language" : "it-CH",
          "value" : "pergolide"
        }]
      },
      {
        "code" : "372528003",
        "display" : "Substance with protease inhibitor mechanism of action (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Substance with protease inhibitor mechanism of action"
        },
        {
          "language" : "fr-CH",
          "value" : "inhibiteur de protéase"
        },
        {
          "language" : "de-CH",
          "value" : "Substanz mit Proteasehemmer-Wirkungsmechanismus"
        },
        {
          "language" : "it-CH",
          "value" : "sostanza con meccanismo d’azione degli inibitori della proteasi"
        }]
      },
      {
        "code" : "372529006",
        "display" : "Indinavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Indinavir"
        },
        {
          "language" : "fr-CH",
          "value" : "indinavir"
        },
        {
          "language" : "de-CH",
          "value" : "Indinavir"
        },
        {
          "language" : "it-CH",
          "value" : "indinavir"
        }]
      },
      {
        "code" : "372533004",
        "display" : "Eflornithine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eflornithine"
        },
        {
          "language" : "fr-CH",
          "value" : "éflornithine"
        },
        {
          "language" : "de-CH",
          "value" : "Eflornithin"
        },
        {
          "language" : "it-CH",
          "value" : "eflornitina"
        }]
      },
      {
        "code" : "372540003",
        "display" : "Anthracycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anthracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "anthracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Anthracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "antraciclina"
        }]
      },
      {
        "code" : "372543001",
        "display" : "Purine analog (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Purine analog"
        },
        {
          "language" : "fr-CH",
          "value" : "analogue de purine"
        },
        {
          "language" : "de-CH",
          "value" : "Purinanalogon"
        },
        {
          "language" : "it-CH",
          "value" : "analogo delle purine"
        }]
      },
      {
        "code" : "372562003",
        "display" : "Enoxaparin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Enoxaparin"
        },
        {
          "language" : "fr-CH",
          "value" : "énoxaparine"
        },
        {
          "language" : "de-CH",
          "value" : "Enoxaparin"
        },
        {
          "language" : "it-CH",
          "value" : "enoxaparina"
        }]
      },
      {
        "code" : "372563008",
        "display" : "Dalteparin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dalteparin"
        },
        {
          "language" : "fr-CH",
          "value" : "daltéparine"
        },
        {
          "language" : "de-CH",
          "value" : "Dalteparin"
        },
        {
          "language" : "it-CH",
          "value" : "dalteparina"
        }]
      },
      {
        "code" : "372577006",
        "display" : "Ticarcillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ticarcillin"
        },
        {
          "language" : "fr-CH",
          "value" : "ticarcilline"
        },
        {
          "language" : "de-CH",
          "value" : "Ticarcillin"
        },
        {
          "language" : "it-CH",
          "value" : "ticarcillina"
        }]
      },
      {
        "code" : "372579009",
        "display" : "Retinoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Retinoid"
        },
        {
          "language" : "fr-CH",
          "value" : "rétinoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Retinoid"
        },
        {
          "language" : "it-CH",
          "value" : "retinoide"
        }]
      },
      {
        "code" : "372637006",
        "display" : "Heparinoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Heparinoid"
        },
        {
          "language" : "fr-CH",
          "value" : "héparinoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Heparinoid"
        },
        {
          "language" : "it-CH",
          "value" : "eparinoide"
        }]
      },
      {
        "code" : "372639009",
        "display" : "Fluoride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluoride"
        },
        {
          "language" : "fr-CH",
          "value" : "fluoride"
        },
        {
          "language" : "de-CH",
          "value" : "Fluorid"
        },
        {
          "language" : "it-CH",
          "value" : "fluoruro"
        }]
      },
      {
        "code" : "372643008",
        "display" : "Amphotericin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amphotericin"
        },
        {
          "language" : "fr-CH",
          "value" : "amphotéricine"
        },
        {
          "language" : "de-CH",
          "value" : "Amphotericin"
        },
        {
          "language" : "it-CH",
          "value" : "amfotericina"
        }]
      },
      {
        "code" : "372650007",
        "display" : "Dextran (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dextran"
        },
        {
          "language" : "fr-CH",
          "value" : "dextran"
        },
        {
          "language" : "de-CH",
          "value" : "Dextran"
        },
        {
          "language" : "it-CH",
          "value" : "destrano"
        }]
      },
      {
        "code" : "372665008",
        "display" : "Non-steroidal anti-inflammatory agent (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Non-steroidal anti-inflammatory agent"
        },
        {
          "language" : "fr-CH",
          "value" : "anti-inflammatoire non stéroïdien"
        },
        {
          "language" : "de-CH",
          "value" : "Nicht-steroidaler Entzündungshemmer"
        },
        {
          "language" : "it-CH",
          "value" : "antinfiammatorio non steroideo"
        }]
      },
      {
        "code" : "372683000",
        "display" : "Cyproheptadine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cyproheptadine"
        },
        {
          "language" : "fr-CH",
          "value" : "cyproheptadine"
        },
        {
          "language" : "de-CH",
          "value" : "Cyproheptadin"
        },
        {
          "language" : "it-CH",
          "value" : "ciproeptadina"
        }]
      },
      {
        "code" : "372699006",
        "display" : "Pentamidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentamidine"
        },
        {
          "language" : "fr-CH",
          "value" : "pentamidine"
        },
        {
          "language" : "de-CH",
          "value" : "Pentamidin"
        },
        {
          "language" : "it-CH",
          "value" : "pentamidina"
        }]
      },
      {
        "code" : "372712006",
        "display" : "Natamycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Natamycin"
        },
        {
          "language" : "fr-CH",
          "value" : "natamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Natamycin"
        },
        {
          "language" : "it-CH",
          "value" : "natamicina"
        }]
      },
      {
        "code" : "372719002",
        "display" : "Thiethylperazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiethylperazine"
        },
        {
          "language" : "fr-CH",
          "value" : "thiethylperazine"
        },
        {
          "language" : "de-CH",
          "value" : "Thiethylperazin"
        },
        {
          "language" : "it-CH",
          "value" : "tietilperazina"
        }]
      },
      {
        "code" : "372724004",
        "display" : "Succinylcholine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Succinylcholine"
        },
        {
          "language" : "fr-CH",
          "value" : "succinylcholine"
        },
        {
          "language" : "de-CH",
          "value" : "Succinylcholin"
        },
        {
          "language" : "it-CH",
          "value" : "succinilcolina"
        }]
      },
      {
        "code" : "372725003",
        "display" : "Phenoxymethylpenicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenoxymethylpenicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "phénoxyméthylpénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Phenoxymethylpenicillin"
        },
        {
          "language" : "it-CH",
          "value" : "fenossimetilpenicillina"
        }]
      },
      {
        "code" : "372730004",
        "display" : "Fluphenazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluphenazine"
        },
        {
          "language" : "fr-CH",
          "value" : "fluphénazine"
        },
        {
          "language" : "de-CH",
          "value" : "Fluphenazin"
        },
        {
          "language" : "it-CH",
          "value" : "flufenazina"
        }]
      },
      {
        "code" : "372779007",
        "display" : "Demeclocycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Demeclocycline"
        },
        {
          "language" : "fr-CH",
          "value" : "déméclocycline"
        },
        {
          "language" : "de-CH",
          "value" : "Demeclocyclin"
        },
        {
          "language" : "it-CH",
          "value" : "demeclociclina"
        }]
      },
      {
        "code" : "372801003",
        "display" : "Cefamandole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefamandole"
        },
        {
          "language" : "fr-CH",
          "value" : "céfamandole"
        },
        {
          "language" : "de-CH",
          "value" : "Cefamandol"
        },
        {
          "language" : "it-CH",
          "value" : "cefamandolo"
        }]
      },
      {
        "code" : "372807004",
        "display" : "Griseofulvin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Griseofulvin"
        },
        {
          "language" : "fr-CH",
          "value" : "griséofulvine"
        },
        {
          "language" : "de-CH",
          "value" : "Griseofulvin"
        },
        {
          "language" : "it-CH",
          "value" : "griseofulvina"
        }]
      },
      {
        "code" : "372824005",
        "display" : "Polymyxin B (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Polymyxin B"
        },
        {
          "language" : "fr-CH",
          "value" : "polymyxine B"
        },
        {
          "language" : "de-CH",
          "value" : "Polymyxin B"
        },
        {
          "language" : "it-CH",
          "value" : "polimixina B"
        }]
      },
      {
        "code" : "372831009",
        "display" : "Amobarbital (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amobarbital"
        },
        {
          "language" : "fr-CH",
          "value" : "amobarbital"
        },
        {
          "language" : "de-CH",
          "value" : "Amobarbital"
        },
        {
          "language" : "it-CH",
          "value" : "amobarbital"
        }]
      },
      {
        "code" : "372839006",
        "display" : "Phenothiazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Phenothiazine"
        },
        {
          "language" : "fr-CH",
          "value" : "phénothiazine"
        },
        {
          "language" : "de-CH",
          "value" : "Phenothiazin"
        },
        {
          "language" : "it-CH",
          "value" : "fenotiazina"
        }]
      },
      {
        "code" : "372844004",
        "display" : "Disopyramide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Disopyramide"
        },
        {
          "language" : "fr-CH",
          "value" : "disopyramide"
        },
        {
          "language" : "de-CH",
          "value" : "Disopyramid"
        },
        {
          "language" : "it-CH",
          "value" : "disopiramide"
        }]
      },
      {
        "code" : "372883002",
        "display" : "Vecuronium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vecuronium"
        },
        {
          "language" : "fr-CH",
          "value" : "vécuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Vecuronium"
        },
        {
          "language" : "it-CH",
          "value" : "vecuronio"
        }]
      },
      {
        "code" : "372907000",
        "display" : "Bisphosphonate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bisphosphonate"
        },
        {
          "language" : "fr-CH",
          "value" : "bisphosphonate"
        },
        {
          "language" : "de-CH",
          "value" : "Bisphosphonat"
        },
        {
          "language" : "it-CH",
          "value" : "bifosfonato"
        }]
      },
      {
        "code" : "372909002",
        "display" : "Mexiletine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mexiletine"
        },
        {
          "language" : "fr-CH",
          "value" : "méxilétine"
        },
        {
          "language" : "de-CH",
          "value" : "Mexiletin"
        },
        {
          "language" : "it-CH",
          "value" : "mexiletina"
        }]
      },
      {
        "code" : "373235001",
        "display" : "Nitroimidazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nitroimidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "nitro-imidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Nitroimidazol"
        },
        {
          "language" : "it-CH",
          "value" : "nitroimidazolo"
        }]
      },
      {
        "code" : "373463001",
        "display" : "Undecenoate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Undecenoate"
        },
        {
          "language" : "fr-CH",
          "value" : "undécénoate"
        },
        {
          "language" : "de-CH",
          "value" : "Undecenoat"
        },
        {
          "language" : "it-CH",
          "value" : "undecanoato"
        }]
      },
      {
        "code" : "373465008",
        "display" : "Proxymetacaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Proxymetacaine"
        },
        {
          "language" : "fr-CH",
          "value" : "proxymétacaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Proxymetacain"
        },
        {
          "language" : "it-CH",
          "value" : "prossimetacaina"
        }]
      },
      {
        "code" : "373509001",
        "display" : "Chlortetracycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlortetracycline"
        },
        {
          "language" : "fr-CH",
          "value" : "chlortétracycline"
        },
        {
          "language" : "de-CH",
          "value" : "Chlortetracyclin"
        },
        {
          "language" : "it-CH",
          "value" : "clorotetraciclina"
        }]
      },
      {
        "code" : "373512003",
        "display" : "Trifluridine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Trifluridine"
        },
        {
          "language" : "fr-CH",
          "value" : "trifluridine"
        },
        {
          "language" : "de-CH",
          "value" : "Trifluridin"
        },
        {
          "language" : "it-CH",
          "value" : "trifluridina"
        }]
      },
      {
        "code" : "373539006",
        "display" : "Nalbuphine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nalbuphine"
        },
        {
          "language" : "fr-CH",
          "value" : "nalbuphine"
        },
        {
          "language" : "de-CH",
          "value" : "Nalbuphin"
        },
        {
          "language" : "it-CH",
          "value" : "nalbufina"
        }]
      },
      {
        "code" : "373542000",
        "display" : "Methyldopa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methyldopa"
        },
        {
          "language" : "fr-CH",
          "value" : "méthyldopa"
        },
        {
          "language" : "de-CH",
          "value" : "Methyldopa"
        },
        {
          "language" : "it-CH",
          "value" : "metildopa"
        }]
      },
      {
        "code" : "373562008",
        "display" : "Tilidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tilidine"
        },
        {
          "language" : "fr-CH",
          "value" : "tilidine"
        },
        {
          "language" : "de-CH",
          "value" : "Tilidin"
        },
        {
          "language" : "it-CH",
          "value" : "tilidina"
        }]
      },
      {
        "code" : "373727000",
        "display" : "Tacrine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tacrine"
        },
        {
          "language" : "fr-CH",
          "value" : "tacrine"
        },
        {
          "language" : "de-CH",
          "value" : "Tacrin"
        },
        {
          "language" : "it-CH",
          "value" : "tacrina"
        }]
      },
      {
        "code" : "373764006",
        "display" : "Pancuronium bromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pancuronium bromide"
        },
        {
          "language" : "fr-CH",
          "value" : "bromure de pancuronium"
        },
        {
          "language" : "de-CH",
          "value" : "Pancuroniumbromid"
        },
        {
          "language" : "it-CH",
          "value" : "pancuronio bromuro"
        }]
      },
      {
        "code" : "385420005",
        "display" : "Contrast media (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Contrast media"
        },
        {
          "language" : "fr-CH",
          "value" : "substance de contraste"
        },
        {
          "language" : "de-CH",
          "value" : "Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "mezzo di contrasto"
        }]
      },
      {
        "code" : "385578004",
        "display" : "Norelgestromin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Norelgestromin"
        },
        {
          "language" : "fr-CH",
          "value" : "norelgestromine"
        },
        {
          "language" : "de-CH",
          "value" : "Norelgestromin"
        },
        {
          "language" : "it-CH",
          "value" : "norelgestromina"
        }]
      },
      {
        "code" : "386835005",
        "display" : "Mercaptopurine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mercaptopurine"
        },
        {
          "language" : "fr-CH",
          "value" : "mercaptopurine"
        },
        {
          "language" : "de-CH",
          "value" : "Mercaptopurin"
        },
        {
          "language" : "it-CH",
          "value" : "mercaptopurina"
        }]
      },
      {
        "code" : "386862002",
        "display" : "Isradipine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isradipine"
        },
        {
          "language" : "fr-CH",
          "value" : "isradipine"
        },
        {
          "language" : "de-CH",
          "value" : "Isradipin"
        },
        {
          "language" : "it-CH",
          "value" : "isradipina"
        }]
      },
      {
        "code" : "386867008",
        "display" : "Carteolol hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carteolol hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de cartéolol"
        },
        {
          "language" : "de-CH",
          "value" : "Carteololhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "carteololo cloridrato"
        }]
      },
      {
        "code" : "386880006",
        "display" : "Zafirlukast (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zafirlukast"
        },
        {
          "language" : "fr-CH",
          "value" : "zafirlukast"
        },
        {
          "language" : "de-CH",
          "value" : "Zafirlukast"
        },
        {
          "language" : "it-CH",
          "value" : "zafirlukast"
        }]
      },
      {
        "code" : "386881005",
        "display" : "Ipratropium bromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ipratropium bromide"
        },
        {
          "language" : "fr-CH",
          "value" : "bromure d'ipratropium"
        },
        {
          "language" : "de-CH",
          "value" : "Ipratropiumbromid"
        },
        {
          "language" : "it-CH",
          "value" : "ipratropio bromuro"
        }]
      },
      {
        "code" : "386895008",
        "display" : "Stavudine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Stavudine"
        },
        {
          "language" : "fr-CH",
          "value" : "stavudine"
        },
        {
          "language" : "de-CH",
          "value" : "Stavudin"
        },
        {
          "language" : "it-CH",
          "value" : "stavudina"
        }]
      },
      {
        "code" : "386909008",
        "display" : "Estramustine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Estramustine"
        },
        {
          "language" : "fr-CH",
          "value" : "estramustine"
        },
        {
          "language" : "de-CH",
          "value" : "Estramustin"
        },
        {
          "language" : "it-CH",
          "value" : "estramustina"
        }]
      },
      {
        "code" : "386935009",
        "display" : "Tazarotene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tazarotene"
        },
        {
          "language" : "fr-CH",
          "value" : "tazarotène"
        },
        {
          "language" : "de-CH",
          "value" : "Tazaroten"
        },
        {
          "language" : "it-CH",
          "value" : "tazarotene"
        }]
      },
      {
        "code" : "386950000",
        "display" : "Ticlopidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ticlopidine"
        },
        {
          "language" : "fr-CH",
          "value" : "ticlopidine"
        },
        {
          "language" : "de-CH",
          "value" : "Ticlopidin"
        },
        {
          "language" : "it-CH",
          "value" : "ticlopidina"
        }]
      },
      {
        "code" : "386953003",
        "display" : "Tirofiban (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tirofiban"
        },
        {
          "language" : "fr-CH",
          "value" : "tirofiban"
        },
        {
          "language" : "de-CH",
          "value" : "Tirofiban"
        },
        {
          "language" : "it-CH",
          "value" : "tirofiban"
        }]
      },
      {
        "code" : "386957002",
        "display" : "Reteplase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Reteplase"
        },
        {
          "language" : "fr-CH",
          "value" : "rétéplase"
        },
        {
          "language" : "de-CH",
          "value" : "Reteplase"
        },
        {
          "language" : "it-CH",
          "value" : "reteplase"
        }]
      },
      {
        "code" : "386958007",
        "display" : "Anistreplase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Anistreplase"
        },
        {
          "language" : "fr-CH",
          "value" : "anistreplase"
        },
        {
          "language" : "de-CH",
          "value" : "Anistreplase"
        },
        {
          "language" : "it-CH",
          "value" : "anistreplase"
        }]
      },
      {
        "code" : "386977009",
        "display" : "Daclizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Daclizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "daclizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Daclizumab"
        },
        {
          "language" : "it-CH",
          "value" : "daclizumab"
        }]
      },
      {
        "code" : "386990002",
        "display" : "Undecylenic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Undecylenic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide undecylénique"
        },
        {
          "language" : "de-CH",
          "value" : "Undecylensäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido undecilenico"
        }]
      },
      {
        "code" : "387006009",
        "display" : "Amprenavir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amprenavir"
        },
        {
          "language" : "fr-CH",
          "value" : "amprénavir"
        },
        {
          "language" : "de-CH",
          "value" : "Amprenavir"
        },
        {
          "language" : "it-CH",
          "value" : "amprenavir"
        }]
      },
      {
        "code" : "387008005",
        "display" : "Rofecoxib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rofecoxib"
        },
        {
          "language" : "fr-CH",
          "value" : "rofécoxib"
        },
        {
          "language" : "de-CH",
          "value" : "Rofecoxib"
        },
        {
          "language" : "it-CH",
          "value" : "rofecoxib"
        }]
      },
      {
        "code" : "387012004",
        "display" : "Zaleplon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zaleplon"
        },
        {
          "language" : "fr-CH",
          "value" : "zaléplone"
        },
        {
          "language" : "de-CH",
          "value" : "Zaleplon"
        },
        {
          "language" : "it-CH",
          "value" : "zaleplon"
        }]
      },
      {
        "code" : "387013009",
        "display" : "Rabeprazole sodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rabeprazole sodium"
        },
        {
          "language" : "fr-CH",
          "value" : "rabéprazole sodique"
        },
        {
          "language" : "de-CH",
          "value" : "Rabeprazol-Natrium"
        },
        {
          "language" : "it-CH",
          "value" : "rabeprazolo sodico"
        }]
      },
      {
        "code" : "387023000",
        "display" : "Bexarotene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bexarotene"
        },
        {
          "language" : "fr-CH",
          "value" : "bexarotène"
        },
        {
          "language" : "de-CH",
          "value" : "Bexaroten"
        },
        {
          "language" : "it-CH",
          "value" : "bexarotene"
        }]
      },
      {
        "code" : "387024006",
        "display" : "Oxycodone hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxycodone hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate d'oxycodone"
        },
        {
          "language" : "de-CH",
          "value" : "Oxycodonhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "ossicodone cloridrato"
        }]
      },
      {
        "code" : "387055000",
        "display" : "Meloxicam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meloxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "méloxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Meloxicam"
        },
        {
          "language" : "it-CH",
          "value" : "meloxicam"
        }]
      },
      {
        "code" : "387059006",
        "display" : "Verteporfin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Verteporfin"
        },
        {
          "language" : "fr-CH",
          "value" : "vertéporfine"
        },
        {
          "language" : "de-CH",
          "value" : "Verteporfin"
        },
        {
          "language" : "it-CH",
          "value" : "verteporfina"
        }]
      },
      {
        "code" : "387066007",
        "display" : "Tenecteplase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tenecteplase"
        },
        {
          "language" : "fr-CH",
          "value" : "ténectéplase"
        },
        {
          "language" : "de-CH",
          "value" : "Tenecteplase"
        },
        {
          "language" : "it-CH",
          "value" : "tenecteplase"
        }]
      },
      {
        "code" : "387068008",
        "display" : "Terazosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "térazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Terazosin"
        },
        {
          "language" : "it-CH",
          "value" : "terazosina"
        }]
      },
      {
        "code" : "387077001",
        "display" : "Dimercaprol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dimercaprol"
        },
        {
          "language" : "fr-CH",
          "value" : "dimercaprol"
        },
        {
          "language" : "de-CH",
          "value" : "Dimercaprol"
        },
        {
          "language" : "it-CH",
          "value" : "dimercaprolo"
        }]
      },
      {
        "code" : "387079003",
        "display" : "Co-trimoxazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Co-trimoxazole"
        },
        {
          "language" : "fr-CH",
          "value" : "co-trimoxazole"
        },
        {
          "language" : "de-CH",
          "value" : "Co-trimoxazol"
        },
        {
          "language" : "it-CH",
          "value" : "cotrimoxazolo"
        }]
      },
      {
        "code" : "387087002",
        "display" : "Mepyramine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mepyramine"
        },
        {
          "language" : "fr-CH",
          "value" : "mépyramine"
        },
        {
          "language" : "de-CH",
          "value" : "Mepyramin"
        },
        {
          "language" : "it-CH",
          "value" : "mepiramina"
        }]
      },
      {
        "code" : "387089004",
        "display" : "Terfenadine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terfenadine"
        },
        {
          "language" : "fr-CH",
          "value" : "terfénadine"
        },
        {
          "language" : "de-CH",
          "value" : "Terfenadin"
        },
        {
          "language" : "it-CH",
          "value" : "terfenadina"
        }]
      },
      {
        "code" : "387096002",
        "display" : "Dapsone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dapsone"
        },
        {
          "language" : "fr-CH",
          "value" : "dapsone"
        },
        {
          "language" : "de-CH",
          "value" : "Dapson"
        },
        {
          "language" : "it-CH",
          "value" : "dapsone"
        }]
      },
      {
        "code" : "387105006",
        "display" : "Didanosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Didanosine"
        },
        {
          "language" : "fr-CH",
          "value" : "didanosine"
        },
        {
          "language" : "de-CH",
          "value" : "Didanosin"
        },
        {
          "language" : "it-CH",
          "value" : "didanosina"
        }]
      },
      {
        "code" : "387112002",
        "display" : "Silver sulfadiazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Silver sulfadiazine"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfadiazine  d'argent"
        },
        {
          "language" : "de-CH",
          "value" : "Silbersulfadiazin"
        },
        {
          "language" : "it-CH",
          "value" : "sulfadiazina argentica"
        }]
      },
      {
        "code" : "387115000",
        "display" : "Vinblastine sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vinblastine sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate de vinblastine"
        },
        {
          "language" : "de-CH",
          "value" : "Vinblastinsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "vinblastina solfato"
        }]
      },
      {
        "code" : "387125005",
        "display" : "Hydralazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hydralazine"
        },
        {
          "language" : "fr-CH",
          "value" : "hydralazine"
        },
        {
          "language" : "de-CH",
          "value" : "Hydralazin"
        },
        {
          "language" : "it-CH",
          "value" : "idralazina"
        }]
      },
      {
        "code" : "387136003",
        "display" : "Ichthammol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ichthammol"
        },
        {
          "language" : "fr-CH",
          "value" : "ichthammol"
        },
        {
          "language" : "de-CH",
          "value" : "Ichthammol"
        },
        {
          "language" : "it-CH",
          "value" : "ictammolo"
        }]
      },
      {
        "code" : "387138002",
        "display" : "Busulfan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Busulfan"
        },
        {
          "language" : "fr-CH",
          "value" : "busulfan"
        },
        {
          "language" : "de-CH",
          "value" : "Busulfan"
        },
        {
          "language" : "it-CH",
          "value" : "busulfano"
        }]
      },
      {
        "code" : "387154004",
        "display" : "Pentostatin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentostatin"
        },
        {
          "language" : "fr-CH",
          "value" : "pentostatine"
        },
        {
          "language" : "de-CH",
          "value" : "Pentostatin"
        },
        {
          "language" : "it-CH",
          "value" : "pentostatina"
        }]
      },
      {
        "code" : "387155003",
        "display" : "Flucytosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flucytosine"
        },
        {
          "language" : "fr-CH",
          "value" : "flucytosine"
        },
        {
          "language" : "de-CH",
          "value" : "Flucytosin"
        },
        {
          "language" : "it-CH",
          "value" : "flucitosina"
        }]
      },
      {
        "code" : "387163002",
        "display" : "Spiramycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Spiramycin"
        },
        {
          "language" : "fr-CH",
          "value" : "spiramycine"
        },
        {
          "language" : "de-CH",
          "value" : "Spiramycin"
        },
        {
          "language" : "it-CH",
          "value" : "spiramicina"
        }]
      },
      {
        "code" : "387166005",
        "display" : "Clomifene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clomifene"
        },
        {
          "language" : "fr-CH",
          "value" : "clomifène"
        },
        {
          "language" : "de-CH",
          "value" : "Clomifen"
        },
        {
          "language" : "it-CH",
          "value" : "clomifene"
        }]
      },
      {
        "code" : "387175007",
        "display" : "Pramocaine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pramocaine"
        },
        {
          "language" : "fr-CH",
          "value" : "pramocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Pramocain"
        },
        {
          "language" : "it-CH",
          "value" : "pramocaina"
        }]
      },
      {
        "code" : "387180003",
        "display" : "Maprotiline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Maprotiline"
        },
        {
          "language" : "fr-CH",
          "value" : "maprotiline"
        },
        {
          "language" : "de-CH",
          "value" : "Maprotilin"
        },
        {
          "language" : "it-CH",
          "value" : "maprotilina"
        }]
      },
      {
        "code" : "387203007",
        "display" : "Propylthiouracil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propylthiouracil"
        },
        {
          "language" : "fr-CH",
          "value" : "propylthiouracile"
        },
        {
          "language" : "de-CH",
          "value" : "Propylthiouracil"
        },
        {
          "language" : "it-CH",
          "value" : "propiltiouracile"
        }]
      },
      {
        "code" : "387213004",
        "display" : "Pentazocine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentazocine"
        },
        {
          "language" : "fr-CH",
          "value" : "pentazocine"
        },
        {
          "language" : "de-CH",
          "value" : "Pentazocin"
        },
        {
          "language" : "it-CH",
          "value" : "pentazocina"
        }]
      },
      {
        "code" : "387219000",
        "display" : "Bromelains (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bromelains"
        },
        {
          "language" : "fr-CH",
          "value" : "bromélaïnes"
        },
        {
          "language" : "de-CH",
          "value" : "Bromelain"
        },
        {
          "language" : "it-CH",
          "value" : "bromelina"
        }]
      },
      {
        "code" : "387223008",
        "display" : "Streptomycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Streptomycin"
        },
        {
          "language" : "fr-CH",
          "value" : "streptomycine"
        },
        {
          "language" : "de-CH",
          "value" : "Streptomycin"
        },
        {
          "language" : "it-CH",
          "value" : "streptomicina"
        }]
      },
      {
        "code" : "387224002",
        "display" : "Deferoxamine mesilate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Deferoxamine mesilate"
        },
        {
          "language" : "fr-CH",
          "value" : "déféroxamine mésilate"
        },
        {
          "language" : "de-CH",
          "value" : "Deferoxaminmesilat"
        },
        {
          "language" : "it-CH",
          "value" : "deferoxamina mesilato"
        }]
      },
      {
        "code" : "387235007",
        "display" : "Penicillamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Penicillamine"
        },
        {
          "language" : "fr-CH",
          "value" : "pénicillamine"
        },
        {
          "language" : "de-CH",
          "value" : "Penicillamin"
        },
        {
          "language" : "it-CH",
          "value" : "penicillamina"
        }]
      },
      {
        "code" : "387249003",
        "display" : "Chlorambucil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlorambucil"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorambucil"
        },
        {
          "language" : "de-CH",
          "value" : "Chlorambucil"
        },
        {
          "language" : "it-CH",
          "value" : "clorambucile"
        }]
      },
      {
        "code" : "387257000",
        "display" : "Aminoglutethimide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aminoglutethimide"
        },
        {
          "language" : "fr-CH",
          "value" : "aminogluthétimide"
        },
        {
          "language" : "de-CH",
          "value" : "Aminoglutethimid"
        },
        {
          "language" : "it-CH",
          "value" : "aminoglutetimide"
        }]
      },
      {
        "code" : "387261006",
        "display" : "Nalidixic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nalidixic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide nalidixique"
        },
        {
          "language" : "de-CH",
          "value" : "Nalidixinsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido nalidixico"
        }]
      },
      {
        "code" : "387267005",
        "display" : "Dihydroergotamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dihydroergotamine"
        },
        {
          "language" : "fr-CH",
          "value" : "dihydroergotamine"
        },
        {
          "language" : "de-CH",
          "value" : "Dihydroergotamin"
        },
        {
          "language" : "it-CH",
          "value" : "diidroergotamina"
        }]
      },
      {
        "code" : "387296006",
        "display" : "Levamisole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levamisole"
        },
        {
          "language" : "fr-CH",
          "value" : "lévamisole"
        },
        {
          "language" : "de-CH",
          "value" : "Levamisol"
        },
        {
          "language" : "it-CH",
          "value" : "levamisolo"
        }]
      },
      {
        "code" : "387299004",
        "display" : "Prilocaine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prilocaine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de prilocaïne"
        },
        {
          "language" : "de-CH",
          "value" : "Prilocainhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "prilocaina cloridrato"
        }]
      },
      {
        "code" : "387328001",
        "display" : "Diazoxide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diazoxide"
        },
        {
          "language" : "fr-CH",
          "value" : "diazoxide"
        },
        {
          "language" : "de-CH",
          "value" : "Diazoxid"
        },
        {
          "language" : "it-CH",
          "value" : "diazossido"
        }]
      },
      {
        "code" : "387349000",
        "display" : "Levobunolol hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levobunolol hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de lévobunolol"
        },
        {
          "language" : "de-CH",
          "value" : "Levobunololhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "levobunololo cloridrato"
        }]
      },
      {
        "code" : "387350000",
        "display" : "Benzoic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzoic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide benzoïque"
        },
        {
          "language" : "de-CH",
          "value" : "Benzoesäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido benzoico"
        }]
      },
      {
        "code" : "387351001",
        "display" : "Halothane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Halothane"
        },
        {
          "language" : "fr-CH",
          "value" : "halothane"
        },
        {
          "language" : "de-CH",
          "value" : "Halothan"
        },
        {
          "language" : "it-CH",
          "value" : "alotano"
        }]
      },
      {
        "code" : "387368002",
        "display" : "Isoflurane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Isoflurane"
        },
        {
          "language" : "fr-CH",
          "value" : "isoflurane"
        },
        {
          "language" : "de-CH",
          "value" : "Isofluran"
        },
        {
          "language" : "it-CH",
          "value" : "isoflurano"
        }]
      },
      {
        "code" : "387395007",
        "display" : "Meprobamate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meprobamate"
        },
        {
          "language" : "fr-CH",
          "value" : "méprobamate"
        },
        {
          "language" : "de-CH",
          "value" : "Meprobamat"
        },
        {
          "language" : "it-CH",
          "value" : "meprobamato"
        }]
      },
      {
        "code" : "387406002",
        "display" : "Sulfonamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfonamide"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfonamide"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfonamid"
        },
        {
          "language" : "it-CH",
          "value" : "sulfamidico"
        }]
      },
      {
        "code" : "387414008",
        "display" : "Menthol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Menthol"
        },
        {
          "language" : "fr-CH",
          "value" : "menthol"
        },
        {
          "language" : "de-CH",
          "value" : "Menthol"
        },
        {
          "language" : "it-CH",
          "value" : "mentolo"
        }]
      },
      {
        "code" : "387418006",
        "display" : "Edetate disodium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Edetate disodium"
        },
        {
          "language" : "fr-CH",
          "value" : "sodium édétate"
        },
        {
          "language" : "de-CH",
          "value" : "Dinatriumedetat"
        },
        {
          "language" : "it-CH",
          "value" : "EDTA disodico"
        }]
      },
      {
        "code" : "387427007",
        "display" : "Vincristine sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vincristine sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate de vincristine"
        },
        {
          "language" : "de-CH",
          "value" : "Vincristinsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "vincristina solfato"
        }]
      },
      {
        "code" : "387433003",
        "display" : "Prazosin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prazosin"
        },
        {
          "language" : "fr-CH",
          "value" : "prazosine"
        },
        {
          "language" : "de-CH",
          "value" : "Prazosin"
        },
        {
          "language" : "it-CH",
          "value" : "prazosina"
        }]
      },
      {
        "code" : "387439004",
        "display" : "Clofibrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clofibrate"
        },
        {
          "language" : "fr-CH",
          "value" : "clofibrate"
        },
        {
          "language" : "de-CH",
          "value" : "Clofibrat"
        },
        {
          "language" : "it-CH",
          "value" : "clofibrato"
        }]
      },
      {
        "code" : "387447004",
        "display" : "Reserpine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Reserpine"
        },
        {
          "language" : "fr-CH",
          "value" : "réserpine"
        },
        {
          "language" : "de-CH",
          "value" : "Reserpin"
        },
        {
          "language" : "it-CH",
          "value" : "reserpina"
        }]
      },
      {
        "code" : "387460005",
        "display" : "Teniposide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Teniposide"
        },
        {
          "language" : "fr-CH",
          "value" : "téniposide"
        },
        {
          "language" : "de-CH",
          "value" : "Teniposid"
        },
        {
          "language" : "it-CH",
          "value" : "teniposide"
        }]
      },
      {
        "code" : "387474003",
        "display" : "Procarbazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Procarbazine"
        },
        {
          "language" : "fr-CH",
          "value" : "procarbazine"
        },
        {
          "language" : "de-CH",
          "value" : "Procarbazin"
        },
        {
          "language" : "it-CH",
          "value" : "procarbazina"
        }]
      },
      {
        "code" : "387486000",
        "display" : "Methocarbamol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Methocarbamol"
        },
        {
          "language" : "fr-CH",
          "value" : "méthocarbamol"
        },
        {
          "language" : "de-CH",
          "value" : "Methocarbamol"
        },
        {
          "language" : "it-CH",
          "value" : "metocarbamolo"
        }]
      },
      {
        "code" : "387496009",
        "display" : "Acetylcholine chloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Acetylcholine chloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorure d'acétylcholine"
        },
        {
          "language" : "de-CH",
          "value" : "Acetylcholinchlorid"
        },
        {
          "language" : "it-CH",
          "value" : "acetilcolina cloruro"
        }]
      },
      {
        "code" : "387515007",
        "display" : "Crotamiton (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Crotamiton"
        },
        {
          "language" : "fr-CH",
          "value" : "crotamiton"
        },
        {
          "language" : "de-CH",
          "value" : "Crotamiton"
        },
        {
          "language" : "it-CH",
          "value" : "crotamitone"
        }]
      },
      {
        "code" : "387523009",
        "display" : "Buspirone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buspirone"
        },
        {
          "language" : "fr-CH",
          "value" : "buspirone"
        },
        {
          "language" : "de-CH",
          "value" : "Buspiron"
        },
        {
          "language" : "it-CH",
          "value" : "buspirone"
        }]
      },
      {
        "code" : "387536009",
        "display" : "Cefixime (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cefixime"
        },
        {
          "language" : "fr-CH",
          "value" : "céfixime"
        },
        {
          "language" : "de-CH",
          "value" : "Cefixim"
        },
        {
          "language" : "it-CH",
          "value" : "cefixima"
        }]
      },
      {
        "code" : "387543003",
        "display" : "Temocillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Temocillin"
        },
        {
          "language" : "fr-CH",
          "value" : "témocilline"
        },
        {
          "language" : "de-CH",
          "value" : "Temocillin"
        },
        {
          "language" : "it-CH",
          "value" : "temocillina"
        }]
      },
      {
        "code" : "387548007",
        "display" : "Lymecycline (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lymecycline"
        },
        {
          "language" : "fr-CH",
          "value" : "lymécycline"
        },
        {
          "language" : "de-CH",
          "value" : "Lymecyclin"
        },
        {
          "language" : "it-CH",
          "value" : "limeciclina"
        }]
      },
      {
        "code" : "387549004",
        "display" : "Cinoxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cinoxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "cinoxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Cinoxacin"
        },
        {
          "language" : "it-CH",
          "value" : "cinoxacina"
        }]
      },
      {
        "code" : "387565003",
        "display" : "Mianserin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mianserin"
        },
        {
          "language" : "fr-CH",
          "value" : "miansérine"
        },
        {
          "language" : "de-CH",
          "value" : "Mianserin"
        },
        {
          "language" : "it-CH",
          "value" : "mianserina"
        }]
      },
      {
        "code" : "391774005",
        "display" : "Amsacrine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amsacrine"
        },
        {
          "language" : "fr-CH",
          "value" : "amsacrine"
        },
        {
          "language" : "de-CH",
          "value" : "Amsacrin"
        },
        {
          "language" : "it-CH",
          "value" : "amsacrina"
        }]
      },
      {
        "code" : "391786008",
        "display" : "Apraclonidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Apraclonidine"
        },
        {
          "language" : "fr-CH",
          "value" : "apraclonidine"
        },
        {
          "language" : "de-CH",
          "value" : "Apraclonidin"
        },
        {
          "language" : "it-CH",
          "value" : "apraclonidina"
        }]
      },
      {
        "code" : "391798003",
        "display" : "Azapropazone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azapropazone"
        },
        {
          "language" : "fr-CH",
          "value" : "azapropazone"
        },
        {
          "language" : "de-CH",
          "value" : "Azapropazon"
        },
        {
          "language" : "it-CH",
          "value" : "azapropazone"
        }]
      },
      {
        "code" : "391820006",
        "display" : "Benperidol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benperidol"
        },
        {
          "language" : "fr-CH",
          "value" : "benpéridol"
        },
        {
          "language" : "de-CH",
          "value" : "Benperidol"
        },
        {
          "language" : "it-CH",
          "value" : "benperidolo"
        }]
      },
      {
        "code" : "395733003",
        "display" : "Bupropion hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bupropion hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de bupropione"
        },
        {
          "language" : "de-CH",
          "value" : "Bupropionhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "bupropione cloridrato"
        }]
      },
      {
        "code" : "395783008",
        "display" : "Meptazinol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Meptazinol"
        },
        {
          "language" : "fr-CH",
          "value" : "meptazinol"
        },
        {
          "language" : "de-CH",
          "value" : "Meptazinol"
        },
        {
          "language" : "it-CH",
          "value" : "meptazinolo"
        }]
      },
      {
        "code" : "395798005",
        "display" : "Mizolastine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mizolastine"
        },
        {
          "language" : "fr-CH",
          "value" : "mizolastine"
        },
        {
          "language" : "de-CH",
          "value" : "Mizolastin"
        },
        {
          "language" : "it-CH",
          "value" : "mizolastina"
        }]
      },
      {
        "code" : "395801004",
        "display" : "Molgramostim (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Molgramostim"
        },
        {
          "language" : "fr-CH",
          "value" : "molgramostim"
        },
        {
          "language" : "de-CH",
          "value" : "Molgramostim"
        },
        {
          "language" : "it-CH",
          "value" : "molgramostim"
        }]
      },
      {
        "code" : "395823000",
        "display" : "Peginterferon alfa-2b (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Peginterferon alfa-2b"
        },
        {
          "language" : "fr-CH",
          "value" : "péginterféron alpha-2b"
        },
        {
          "language" : "de-CH",
          "value" : "Peginterferon alfa-2b"
        },
        {
          "language" : "it-CH",
          "value" : "peginterferone alfa-2b"
        }]
      },
      {
        "code" : "395845004",
        "display" : "Proguanil hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Proguanil hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de proguanil"
        },
        {
          "language" : "de-CH",
          "value" : "Proguanilhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "proguanil cloridrato"
        }]
      },
      {
        "code" : "395874008",
        "display" : "Celiprolol hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Celiprolol hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de céliprolol"
        },
        {
          "language" : "de-CH",
          "value" : "Celiprololhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "celiprololo cloridrato"
        }]
      },
      {
        "code" : "395889004",
        "display" : "Streptokinase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Streptokinase"
        },
        {
          "language" : "fr-CH",
          "value" : "streptokinase"
        },
        {
          "language" : "de-CH",
          "value" : "Streptokinase"
        },
        {
          "language" : "it-CH",
          "value" : "streptochinasi"
        }]
      },
      {
        "code" : "395898001",
        "display" : "Tenoxicam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tenoxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "ténoxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Tenoxicam"
        },
        {
          "language" : "it-CH",
          "value" : "tenoxicam"
        }]
      },
      {
        "code" : "395906005",
        "display" : "Cetrorelix (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cetrorelix"
        },
        {
          "language" : "fr-CH",
          "value" : "cétrorélix"
        },
        {
          "language" : "de-CH",
          "value" : "Cetrorelix"
        },
        {
          "language" : "it-CH",
          "value" : "cetrorelix"
        }]
      },
      {
        "code" : "395907001",
        "display" : "Tinidazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tinidazole"
        },
        {
          "language" : "fr-CH",
          "value" : "tinidazole"
        },
        {
          "language" : "de-CH",
          "value" : "Tinidazol"
        },
        {
          "language" : "it-CH",
          "value" : "tinidazolo"
        }]
      },
      {
        "code" : "395912000",
        "display" : "Treosulfan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Treosulfan"
        },
        {
          "language" : "fr-CH",
          "value" : "tréosulfan"
        },
        {
          "language" : "de-CH",
          "value" : "Treosulfan"
        },
        {
          "language" : "it-CH",
          "value" : "treosulfano"
        }]
      },
      {
        "code" : "395917006",
        "display" : "Tropisetron (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tropisetron"
        },
        {
          "language" : "fr-CH",
          "value" : "tropisétron"
        },
        {
          "language" : "de-CH",
          "value" : "Tropisetron"
        },
        {
          "language" : "it-CH",
          "value" : "tropisetrone"
        }]
      },
      {
        "code" : "395920003",
        "display" : "Urofollitropin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Urofollitropin"
        },
        {
          "language" : "fr-CH",
          "value" : "urofollitropine"
        },
        {
          "language" : "de-CH",
          "value" : "Urofollitropin"
        },
        {
          "language" : "it-CH",
          "value" : "urofollitropina"
        }]
      },
      {
        "code" : "395930007",
        "display" : "Zotepine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zotepine"
        },
        {
          "language" : "fr-CH",
          "value" : "zotépine"
        },
        {
          "language" : "de-CH",
          "value" : "Zotepin"
        },
        {
          "language" : "it-CH",
          "value" : "zotepina"
        }]
      },
      {
        "code" : "395944001",
        "display" : "Flumetasone pivalate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flumetasone pivalate"
        },
        {
          "language" : "fr-CH",
          "value" : "pivalate de flumétasone"
        },
        {
          "language" : "de-CH",
          "value" : "Flumetasonpivalat"
        },
        {
          "language" : "it-CH",
          "value" : "flumetasone pivalato"
        }]
      },
      {
        "code" : "395996003",
        "display" : "Propamidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Propamidine"
        },
        {
          "language" : "fr-CH",
          "value" : "propamidine"
        },
        {
          "language" : "de-CH",
          "value" : "Propamidin"
        },
        {
          "language" : "it-CH",
          "value" : "propamidina"
        }]
      },
      {
        "code" : "396014007",
        "display" : "Barium sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Barium sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate de barium"
        },
        {
          "language" : "de-CH",
          "value" : "Bariumsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "bario solfato"
        }]
      },
      {
        "code" : "396027006",
        "display" : "Diflucortolone valerate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Diflucortolone valerate"
        },
        {
          "language" : "fr-CH",
          "value" : "valérate de diflucortolone"
        },
        {
          "language" : "de-CH",
          "value" : "Diflucortolonvalerat"
        },
        {
          "language" : "it-CH",
          "value" : "diflucortolone valerato"
        }]
      },
      {
        "code" : "396033002",
        "display" : "Distigmine bromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Distigmine bromide"
        },
        {
          "language" : "fr-CH",
          "value" : "bromure de distigmine"
        },
        {
          "language" : "de-CH",
          "value" : "Distigminbromid"
        },
        {
          "language" : "it-CH",
          "value" : "distigmina bromuro"
        }]
      },
      {
        "code" : "396345004",
        "display" : "Carbapenem (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carbapenem"
        },
        {
          "language" : "fr-CH",
          "value" : "carbapénème"
        },
        {
          "language" : "de-CH",
          "value" : "Carbapenem"
        },
        {
          "language" : "it-CH",
          "value" : "carbapeneme"
        }]
      },
      {
        "code" : "397165007",
        "display" : "Stain (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Stain"
        },
        {
          "language" : "fr-CH",
          "value" : "colorant"
        },
        {
          "language" : "de-CH",
          "value" : "Färbung"
        },
        {
          "language" : "it-CH",
          "value" : "colorante"
        }]
      },
      {
        "code" : "398669004",
        "display" : "Pirenzepine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pirenzepine"
        },
        {
          "language" : "fr-CH",
          "value" : "pirenzépine"
        },
        {
          "language" : "de-CH",
          "value" : "Pirenzepin"
        },
        {
          "language" : "it-CH",
          "value" : "pirenzepina"
        }]
      },
      {
        "code" : "398705004",
        "display" : "Cannabis (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cannabis"
        },
        {
          "language" : "fr-CH",
          "value" : "cannabis"
        },
        {
          "language" : "de-CH",
          "value" : "Cannabis"
        },
        {
          "language" : "it-CH",
          "value" : "cannabis"
        }]
      },
      {
        "code" : "406759007",
        "display" : "Digitalis glycoside (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Digitalis glycoside"
        },
        {
          "language" : "fr-CH",
          "value" : "glycoside digitalique"
        },
        {
          "language" : "de-CH",
          "value" : "Digitalisglykosid"
        },
        {
          "language" : "it-CH",
          "value" : "glicoside digitalico"
        }]
      },
      {
        "code" : "406778007",
        "display" : "Beta-lactam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Beta-lactam"
        },
        {
          "language" : "fr-CH",
          "value" : "bêta-lactame"
        },
        {
          "language" : "de-CH",
          "value" : "Beta-Laktam"
        },
        {
          "language" : "it-CH",
          "value" : "beta-lattamico"
        }]
      },
      {
        "code" : "407100002",
        "display" : "Gefitinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gefitinib"
        },
        {
          "language" : "fr-CH",
          "value" : "génitinib"
        },
        {
          "language" : "de-CH",
          "value" : "Gefitinib"
        },
        {
          "language" : "it-CH",
          "value" : "gefitinib"
        }]
      },
      {
        "code" : "408755005",
        "display" : "Choriogonadotropin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Choriogonadotropin"
        },
        {
          "language" : "fr-CH",
          "value" : "choriogonadotropine"
        },
        {
          "language" : "de-CH",
          "value" : "Choriogonadotropin"
        },
        {
          "language" : "it-CH",
          "value" : "coriogonadotropina"
        }]
      },
      {
        "code" : "409132008",
        "display" : "Monobactam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Monobactam"
        },
        {
          "language" : "fr-CH",
          "value" : "monobactame"
        },
        {
          "language" : "de-CH",
          "value" : "Monobactam"
        },
        {
          "language" : "it-CH",
          "value" : "monobattami"
        }]
      },
      {
        "code" : "409264006",
        "display" : "Laronidase (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Laronidase"
        },
        {
          "language" : "fr-CH",
          "value" : "laronidase"
        },
        {
          "language" : "de-CH",
          "value" : "Laronidase"
        },
        {
          "language" : "it-CH",
          "value" : "laronidasi"
        }]
      },
      {
        "code" : "409356003",
        "display" : "Ziprasidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ziprasidone"
        },
        {
          "language" : "fr-CH",
          "value" : "Ziprasidone"
        },
        {
          "language" : "de-CH",
          "value" : "Ziprasidon"
        },
        {
          "language" : "it-CH",
          "value" : "ziprasidone"
        }]
      },
      {
        "code" : "410942007",
        "display" : "Drug or medicament (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Drug or medicament"
        },
        {
          "language" : "fr-CH",
          "value" : "drogue ou médicament"
        },
        {
          "language" : "de-CH",
          "value" : "Arzneimittel oder Medikament"
        },
        {
          "language" : "it-CH",
          "value" : "droga o medicamento"
        }]
      },
      {
        "code" : "412013008",
        "display" : "Lornoxicam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lornoxicam"
        },
        {
          "language" : "fr-CH",
          "value" : "lornoxicam"
        },
        {
          "language" : "de-CH",
          "value" : "Lornoxicam"
        },
        {
          "language" : "it-CH",
          "value" : "lornoxicam"
        }]
      },
      {
        "code" : "412046002",
        "display" : "Paraben and paraben derivative (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paraben and paraben derivative"
        },
        {
          "language" : "fr-CH",
          "value" : "parabène et ses dérivés"
        },
        {
          "language" : "de-CH",
          "value" : "Paraben und Parabenderivate"
        },
        {
          "language" : "it-CH",
          "value" : "parabene e derivati del parabene"
        }]
      },
      {
        "code" : "412071004",
        "display" : "Wheat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Wheat"
        },
        {
          "language" : "fr-CH",
          "value" : "blé"
        },
        {
          "language" : "de-CH",
          "value" : "Weizen"
        },
        {
          "language" : "it-CH",
          "value" : "frumento"
        }]
      },
      {
        "code" : "412115004",
        "display" : "Cetyl alcohol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cetyl alcohol"
        },
        {
          "language" : "fr-CH",
          "value" : "hexadécanol"
        },
        {
          "language" : "de-CH",
          "value" : "Cetylalkohol"
        },
        {
          "language" : "it-CH",
          "value" : "alcol cetilico"
        }]
      },
      {
        "code" : "412138001",
        "display" : "Horse serum protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Horse serum protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de sérum de cheval"
        },
        {
          "language" : "de-CH",
          "value" : "Pferdeserum-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del siero equino"
        }]
      },
      {
        "code" : "412156001",
        "display" : "Silk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Silk"
        },
        {
          "language" : "fr-CH",
          "value" : "soie"
        },
        {
          "language" : "de-CH",
          "value" : "Seide"
        },
        {
          "language" : "it-CH",
          "value" : "seta"
        }]
      },
      {
        "code" : "412166009",
        "display" : "Polysorbate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Polysorbate"
        },
        {
          "language" : "fr-CH",
          "value" : "polysorbate"
        },
        {
          "language" : "de-CH",
          "value" : "Polysorbat"
        },
        {
          "language" : "it-CH",
          "value" : "polisorbato"
        }]
      },
      {
        "code" : "412201008",
        "display" : "Porcine heparin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Porcine heparin"
        },
        {
          "language" : "fr-CH",
          "value" : "héparine de porc"
        },
        {
          "language" : "de-CH",
          "value" : "Heparin vom Schwein"
        },
        {
          "language" : "it-CH",
          "value" : "eparina suina"
        }]
      },
      {
        "code" : "412244007",
        "display" : "Menadione (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Menadione"
        },
        {
          "language" : "fr-CH",
          "value" : "ménadione"
        },
        {
          "language" : "de-CH",
          "value" : "Menadion"
        },
        {
          "language" : "it-CH",
          "value" : "menadione"
        }]
      },
      {
        "code" : "412260006",
        "display" : "Olmesartan medoxomil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Olmesartan medoxomil"
        },
        {
          "language" : "fr-CH",
          "value" : "olmésartan médoxomil"
        },
        {
          "language" : "de-CH",
          "value" : "Olmesartanmedoxomil"
        },
        {
          "language" : "it-CH",
          "value" : "olmesartan medoxomil"
        }]
      },
      {
        "code" : "412310002",
        "display" : "Sodium lauryl sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sodium lauryl sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "laurylsulfate de sodium"
        },
        {
          "language" : "de-CH",
          "value" : "Natriumlaurylsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "sodio laurilsolfato"
        }]
      },
      {
        "code" : "412322004",
        "display" : "Tixocortol pivalate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tixocortol pivalate"
        },
        {
          "language" : "fr-CH",
          "value" : "pivalate de tixocortol"
        },
        {
          "language" : "de-CH",
          "value" : "Tixocortolpivalat"
        },
        {
          "language" : "it-CH",
          "value" : "tixocortol pivalato"
        }]
      },
      {
        "code" : "412363005",
        "display" : "Desonide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Desonide"
        },
        {
          "language" : "fr-CH",
          "value" : "désonide"
        },
        {
          "language" : "de-CH",
          "value" : "Desonid"
        },
        {
          "language" : "it-CH",
          "value" : "desonide"
        }]
      },
      {
        "code" : "412395006",
        "display" : "Ginseng extract (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ginseng extract"
        },
        {
          "language" : "fr-CH",
          "value" : "extrait de ginseng"
        },
        {
          "language" : "de-CH",
          "value" : "Ginseng-Extrakt"
        },
        {
          "language" : "it-CH",
          "value" : "estratto di ginseng"
        }]
      },
      {
        "code" : "412411004",
        "display" : "Amrinone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amrinone"
        },
        {
          "language" : "fr-CH",
          "value" : "amrinone"
        },
        {
          "language" : "de-CH",
          "value" : "Amrinon"
        },
        {
          "language" : "it-CH",
          "value" : "amrinone"
        }]
      },
      {
        "code" : "412520006",
        "display" : "Thyrotropin alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thyrotropin alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "thyrotropine alpha"
        },
        {
          "language" : "de-CH",
          "value" : "Thyrotropin alfa"
        },
        {
          "language" : "it-CH",
          "value" : "tireotropina alfa"
        }]
      },
      {
        "code" : "412605006",
        "display" : "Thiopental (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Thiopental"
        },
        {
          "language" : "fr-CH",
          "value" : "thiopental"
        },
        {
          "language" : "de-CH",
          "value" : "Thiopental"
        },
        {
          "language" : "it-CH",
          "value" : "tiopentale"
        }]
      },
      {
        "code" : "414407009",
        "display" : "Hirudin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hirudin"
        },
        {
          "language" : "fr-CH",
          "value" : "hirudine"
        },
        {
          "language" : "de-CH",
          "value" : "Hirudin"
        },
        {
          "language" : "it-CH",
          "value" : "irudina"
        }]
      },
      {
        "code" : "415562007",
        "display" : "Soy bean product (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Soy bean product"
        },
        {
          "language" : "fr-CH",
          "value" : "produit à base de soja"
        },
        {
          "language" : "de-CH",
          "value" : "Sojabohnenprodukt"
        },
        {
          "language" : "it-CH",
          "value" : "prodotto di soia"
        }]
      },
      {
        "code" : "415853004",
        "display" : "Ximelagatran (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ximelagatran"
        },
        {
          "language" : "fr-CH",
          "value" : "ximélagatran"
        },
        {
          "language" : "de-CH",
          "value" : "Ximelagatran"
        },
        {
          "language" : "it-CH",
          "value" : "ximelagatran"
        }]
      },
      {
        "code" : "416127003",
        "display" : "Micafungin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Micafungin"
        },
        {
          "language" : "fr-CH",
          "value" : "micafungine"
        },
        {
          "language" : "de-CH",
          "value" : "Micafungin"
        },
        {
          "language" : "it-CH",
          "value" : "micafungin"
        }]
      },
      {
        "code" : "416459001",
        "display" : "Gadoxetic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gadoxetic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide gadoxétique"
        },
        {
          "language" : "de-CH",
          "value" : "Gadoxetsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido gadoxetico"
        }]
      },
      {
        "code" : "416512006",
        "display" : "Ziconotide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ziconotide"
        },
        {
          "language" : "fr-CH",
          "value" : "ziconotide"
        },
        {
          "language" : "de-CH",
          "value" : "Ziconotid"
        },
        {
          "language" : "it-CH",
          "value" : "ziconotide"
        }]
      },
      {
        "code" : "416559004",
        "display" : "Icaridin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Icaridin"
        },
        {
          "language" : "fr-CH",
          "value" : "icaridine"
        },
        {
          "language" : "de-CH",
          "value" : "Icaridin"
        },
        {
          "language" : "it-CH",
          "value" : "icaridina"
        }]
      },
      {
        "code" : "416624006",
        "display" : "Tiabendazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tiabendazole"
        },
        {
          "language" : "fr-CH",
          "value" : "tiabendazol"
        },
        {
          "language" : "de-CH",
          "value" : "Tiabendazol"
        },
        {
          "language" : "it-CH",
          "value" : "tiabendazolo"
        }]
      },
      {
        "code" : "417533007",
        "display" : "Sulfiram (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfiram"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfiram"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfiram"
        },
        {
          "language" : "it-CH",
          "value" : "sulfiram"
        }]
      },
      {
        "code" : "417550009",
        "display" : "Palifermin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Palifermin"
        },
        {
          "language" : "fr-CH",
          "value" : "palifermine"
        },
        {
          "language" : "de-CH",
          "value" : "Palifermin"
        },
        {
          "language" : "it-CH",
          "value" : "palifermina"
        }]
      },
      {
        "code" : "418157000",
        "display" : "Mecasermin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mecasermin"
        },
        {
          "language" : "fr-CH",
          "value" : "mécasermine"
        },
        {
          "language" : "de-CH",
          "value" : "Mecasermin"
        },
        {
          "language" : "it-CH",
          "value" : "mecasermina"
        }]
      },
      {
        "code" : "418260004",
        "display" : "Vandetanib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vandetanib"
        },
        {
          "language" : "fr-CH",
          "value" : "vandétanib"
        },
        {
          "language" : "de-CH",
          "value" : "Vandetanib"
        },
        {
          "language" : "it-CH",
          "value" : "vandetanib"
        }]
      },
      {
        "code" : "418547009",
        "display" : "Citrus aurantium extract (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Citrus aurantium extract"
        },
        {
          "language" : "fr-CH",
          "value" : "extrait d'orange amère"
        },
        {
          "language" : "de-CH",
          "value" : "Extrakt aus Citrus aurantium"
        },
        {
          "language" : "it-CH",
          "value" : "estratto di Citrus aurantium"
        }]
      },
      {
        "code" : "418784008",
        "display" : "Nelarabine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nelarabine"
        },
        {
          "language" : "fr-CH",
          "value" : "nélarabine"
        },
        {
          "language" : "de-CH",
          "value" : "Nelarabin"
        },
        {
          "language" : "it-CH",
          "value" : "nelarabina"
        }]
      },
      {
        "code" : "419373008",
        "display" : "Fluspirilene (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluspirilene"
        },
        {
          "language" : "fr-CH",
          "value" : "fluspirilène"
        },
        {
          "language" : "de-CH",
          "value" : "Fluspirilen"
        },
        {
          "language" : "it-CH",
          "value" : "fluspirilene"
        }]
      },
      {
        "code" : "419384001",
        "display" : "Glibornuride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glibornuride"
        },
        {
          "language" : "fr-CH",
          "value" : "glibornuride"
        },
        {
          "language" : "de-CH",
          "value" : "Glibornurid"
        },
        {
          "language" : "it-CH",
          "value" : "glibornuride"
        }]
      },
      {
        "code" : "419432008",
        "display" : "Carmellose (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Carmellose"
        },
        {
          "language" : "fr-CH",
          "value" : "carmellose"
        },
        {
          "language" : "de-CH",
          "value" : "Carmellose"
        },
        {
          "language" : "it-CH",
          "value" : "carmellosio"
        }]
      },
      {
        "code" : "419460005",
        "display" : "Nepafenac (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nepafenac"
        },
        {
          "language" : "fr-CH",
          "value" : "népafénac"
        },
        {
          "language" : "de-CH",
          "value" : "Nepafenac"
        },
        {
          "language" : "it-CH",
          "value" : "nepafenac"
        }]
      },
      {
        "code" : "419615001",
        "display" : "Potassium canrenoate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Potassium canrenoate"
        },
        {
          "language" : "fr-CH",
          "value" : "canrénoate de potassium"
        },
        {
          "language" : "de-CH",
          "value" : "Kaliumcanrenoat"
        },
        {
          "language" : "it-CH",
          "value" : "potassio canrenoato"
        }]
      },
      {
        "code" : "419632002",
        "display" : "Mebhydrolin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mebhydrolin"
        },
        {
          "language" : "fr-CH",
          "value" : "mébhydroline"
        },
        {
          "language" : "de-CH",
          "value" : "Mebhydrolin"
        },
        {
          "language" : "it-CH",
          "value" : "mebidrolina"
        }]
      },
      {
        "code" : "419657007",
        "display" : "Ketazolam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ketazolam"
        },
        {
          "language" : "fr-CH",
          "value" : "kétazolam"
        },
        {
          "language" : "de-CH",
          "value" : "Ketazolam"
        },
        {
          "language" : "it-CH",
          "value" : "ketazolam"
        }]
      },
      {
        "code" : "419933005",
        "display" : "Glucocorticoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Glucocorticoid"
        },
        {
          "language" : "fr-CH",
          "value" : "glucocorticoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Glucocorticoid"
        },
        {
          "language" : "it-CH",
          "value" : "glucocorticoide"
        }]
      },
      {
        "code" : "420442001",
        "display" : "Pamidronic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pamidronic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide pamidronique"
        },
        {
          "language" : "de-CH",
          "value" : "Pamidronsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido pamidronico"
        }]
      },
      {
        "code" : "420946006",
        "display" : "Streptogramin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Streptogramin"
        },
        {
          "language" : "fr-CH",
          "value" : "pristinamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Streptogramin"
        },
        {
          "language" : "it-CH",
          "value" : "streptogramina"
        }]
      },
      {
        "code" : "420963005",
        "display" : "Amaranth (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amaranth"
        },
        {
          "language" : "fr-CH",
          "value" : "amarante"
        },
        {
          "language" : "de-CH",
          "value" : "Amaranth"
        },
        {
          "language" : "it-CH",
          "value" : "amaranto"
        }]
      },
      {
        "code" : "421147008",
        "display" : "Tasonermin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tasonermin"
        },
        {
          "language" : "fr-CH",
          "value" : "tasonermine"
        },
        {
          "language" : "de-CH",
          "value" : "Tasonermin"
        },
        {
          "language" : "it-CH",
          "value" : "tasonermina"
        }]
      },
      {
        "code" : "421192001",
        "display" : "Sunitinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sunitinib"
        },
        {
          "language" : "fr-CH",
          "value" : "sunitinib"
        },
        {
          "language" : "de-CH",
          "value" : "Sunitinib"
        },
        {
          "language" : "it-CH",
          "value" : "sunitinib"
        }]
      },
      {
        "code" : "421203005",
        "display" : "Tenofovir disoproxil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tenofovir disoproxil"
        },
        {
          "language" : "fr-CH",
          "value" : "ténofovir disoproxil"
        },
        {
          "language" : "de-CH",
          "value" : "Tenofovirdisoproxil"
        },
        {
          "language" : "it-CH",
          "value" : "tenofovir disoproxil"
        }]
      },
      {
        "code" : "422377009",
        "display" : "Benzothiazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzothiazole"
        },
        {
          "language" : "fr-CH",
          "value" : "benzothiazole"
        },
        {
          "language" : "de-CH",
          "value" : "Benzothiazol"
        },
        {
          "language" : "it-CH",
          "value" : "benzotiazolo"
        }]
      },
      {
        "code" : "422456007",
        "display" : "Ranibizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ranibizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ranibizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ranibizumab"
        },
        {
          "language" : "it-CH",
          "value" : "ranibizumab"
        }]
      },
      {
        "code" : "422654000",
        "display" : "Amifampridine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Amifampridine"
        },
        {
          "language" : "fr-CH",
          "value" : "amifampridine"
        },
        {
          "language" : "de-CH",
          "value" : "Amifampridin"
        },
        {
          "language" : "it-CH",
          "value" : "amifampridina"
        }]
      },
      {
        "code" : "422751003",
        "display" : "Fusafungine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fusafungine"
        },
        {
          "language" : "fr-CH",
          "value" : "fusafungine"
        },
        {
          "language" : "de-CH",
          "value" : "Fusafungin"
        },
        {
          "language" : "it-CH",
          "value" : "fusafungina"
        }]
      },
      {
        "code" : "423259008",
        "display" : "Panitumumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Panitumumab"
        },
        {
          "language" : "fr-CH",
          "value" : "panitumumab"
        },
        {
          "language" : "de-CH",
          "value" : "Panitumumab"
        },
        {
          "language" : "it-CH",
          "value" : "panitumumab"
        }]
      },
      {
        "code" : "424943007",
        "display" : "Flavonoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Flavonoid"
        },
        {
          "language" : "fr-CH",
          "value" : "flavonoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Flavonoid"
        },
        {
          "language" : "it-CH",
          "value" : "flavonoide"
        }]
      },
      {
        "code" : "425461004",
        "display" : "Levocetirizine dihydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Levocetirizine dihydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "lévocétirizine dichlorhydrate"
        },
        {
          "language" : "de-CH",
          "value" : "Levocetirizindihydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "levocetirizina dicloridrato"
        }]
      },
      {
        "code" : "425820005",
        "display" : "Lapatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lapatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "lapatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Lapatinib"
        },
        {
          "language" : "it-CH",
          "value" : "lapatinib"
        }]
      },
      {
        "code" : "426233002",
        "display" : "Triazole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Triazole"
        },
        {
          "language" : "fr-CH",
          "value" : "triazole"
        },
        {
          "language" : "de-CH",
          "value" : "Triazol"
        },
        {
          "language" : "it-CH",
          "value" : "triazolo"
        }]
      },
      {
        "code" : "427153004",
        "display" : "Temsirolimus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Temsirolimus"
        },
        {
          "language" : "fr-CH",
          "value" : "temsirolimus"
        },
        {
          "language" : "de-CH",
          "value" : "Temsirolimus"
        },
        {
          "language" : "it-CH",
          "value" : "temsirolimus"
        }]
      },
      {
        "code" : "427427002",
        "display" : "Lisdexamfetamine dimesylate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lisdexamfetamine dimesylate"
        },
        {
          "language" : "fr-CH",
          "value" : "dimésylate de lisdexamfétamine"
        },
        {
          "language" : "de-CH",
          "value" : "Lisdexamfetamindimesylat"
        },
        {
          "language" : "it-CH",
          "value" : "lisdexamfetamina dimesilato"
        }]
      },
      {
        "code" : "427882000",
        "display" : "Axitinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Axitinib"
        },
        {
          "language" : "fr-CH",
          "value" : "axitinib"
        },
        {
          "language" : "de-CH",
          "value" : "Axitinib"
        },
        {
          "language" : "it-CH",
          "value" : "axitinib"
        }]
      },
      {
        "code" : "427941004",
        "display" : "Nilotinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nilotinib"
        },
        {
          "language" : "fr-CH",
          "value" : "nilotinib"
        },
        {
          "language" : "de-CH",
          "value" : "Nilotinib"
        },
        {
          "language" : "it-CH",
          "value" : "nilotinib"
        }]
      },
      {
        "code" : "428598004",
        "display" : "Pralatrexate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pralatrexate"
        },
        {
          "language" : "fr-CH",
          "value" : "pralatrexate"
        },
        {
          "language" : "de-CH",
          "value" : "Pralatrexat"
        },
        {
          "language" : "it-CH",
          "value" : "pralatrexato"
        }]
      },
      {
        "code" : "428699004",
        "display" : "Aminopyrimidine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aminopyrimidine"
        },
        {
          "language" : "fr-CH",
          "value" : "aminopyrimidine"
        },
        {
          "language" : "de-CH",
          "value" : "Aminopyrimidin"
        },
        {
          "language" : "it-CH",
          "value" : "aminopirimidina"
        }]
      },
      {
        "code" : "428714003",
        "display" : "Piperazine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piperazine"
        },
        {
          "language" : "fr-CH",
          "value" : "pipérazine"
        },
        {
          "language" : "de-CH",
          "value" : "Piperazin"
        },
        {
          "language" : "it-CH",
          "value" : "piperazina"
        }]
      },
      {
        "code" : "428826003",
        "display" : "Sevelamer carbonate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sevelamer carbonate"
        },
        {
          "language" : "fr-CH",
          "value" : "carbonate de sévélamer"
        },
        {
          "language" : "de-CH",
          "value" : "Sevelamercarbonat"
        },
        {
          "language" : "it-CH",
          "value" : "sevelamer carbonato"
        }]
      },
      {
        "code" : "429461005",
        "display" : "Pentetic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pentetic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide pentétique"
        },
        {
          "language" : "de-CH",
          "value" : "Diethylentriaminpentaessigsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido pentetico"
        }]
      },
      {
        "code" : "429825009",
        "display" : "Fosaprepitant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fosaprepitant"
        },
        {
          "language" : "fr-CH",
          "value" : "fosaprépitant"
        },
        {
          "language" : "de-CH",
          "value" : "Fosaprepitant"
        },
        {
          "language" : "it-CH",
          "value" : "fosaprepitant"
        }]
      },
      {
        "code" : "430082006",
        "display" : "Bendamustine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bendamustine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de bendamustine"
        },
        {
          "language" : "de-CH",
          "value" : "Bendamustinhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "bendamustina cloridrato"
        }]
      },
      {
        "code" : "430242005",
        "display" : "Regadenoson (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Regadenoson"
        },
        {
          "language" : "fr-CH",
          "value" : "regadenoson"
        },
        {
          "language" : "de-CH",
          "value" : "Regadenoson"
        },
        {
          "language" : "it-CH",
          "value" : "regadenoson"
        }]
      },
      {
        "code" : "430306004",
        "display" : "Certolizumab pegol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Certolizumab pegol"
        },
        {
          "language" : "fr-CH",
          "value" : "certolizumab pegol"
        },
        {
          "language" : "de-CH",
          "value" : "Certolizumab pegol"
        },
        {
          "language" : "it-CH",
          "value" : "certolizumab pegolo"
        }]
      },
      {
        "code" : "432727001",
        "display" : "Strontium ranelate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Strontium ranelate"
        },
        {
          "language" : "fr-CH",
          "value" : "ranélate de strontium"
        },
        {
          "language" : "de-CH",
          "value" : "Strontiumranelat"
        },
        {
          "language" : "it-CH",
          "value" : "stronzio ranelato"
        }]
      },
      {
        "code" : "439581000",
        "display" : "Pirfenidone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pirfenidone"
        },
        {
          "language" : "fr-CH",
          "value" : "pirfenidone"
        },
        {
          "language" : "de-CH",
          "value" : "Pirfenidon"
        },
        {
          "language" : "it-CH",
          "value" : "pirfenidone"
        }]
      },
      {
        "code" : "441641002",
        "display" : "Milnacipran (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Milnacipran"
        },
        {
          "language" : "fr-CH",
          "value" : "milnacipran"
        },
        {
          "language" : "de-CH",
          "value" : "Milnacipran"
        },
        {
          "language" : "it-CH",
          "value" : "milnacipran"
        }]
      },
      {
        "code" : "442008002",
        "display" : "Framycetin sulfate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Framycetin sulfate"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfate de framycétine"
        },
        {
          "language" : "de-CH",
          "value" : "Framycetinsulfat"
        },
        {
          "language" : "it-CH",
          "value" : "framicetina solfato"
        }]
      },
      {
        "code" : "443375003",
        "display" : "Asenapine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Asenapine"
        },
        {
          "language" : "fr-CH",
          "value" : "asénapine"
        },
        {
          "language" : "de-CH",
          "value" : "Asenapin"
        },
        {
          "language" : "it-CH",
          "value" : "asenapina"
        }]
      },
      {
        "code" : "443763005",
        "display" : "Pazopanib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pazopanib"
        },
        {
          "language" : "fr-CH",
          "value" : "pazopanib"
        },
        {
          "language" : "de-CH",
          "value" : "Pazopanib"
        },
        {
          "language" : "it-CH",
          "value" : "pazopanib"
        }]
      },
      {
        "code" : "444607009",
        "display" : "Ofatumumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ofatumumab"
        },
        {
          "language" : "fr-CH",
          "value" : "ofatumumab"
        },
        {
          "language" : "de-CH",
          "value" : "Ofatumumab"
        },
        {
          "language" : "it-CH",
          "value" : "ofatumumab"
        }]
      },
      {
        "code" : "449561004",
        "display" : "Azilsartan medoxomil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Azilsartan medoxomil"
        },
        {
          "language" : "fr-CH",
          "value" : "azilsartan médoxomil"
        },
        {
          "language" : "de-CH",
          "value" : "Azilsartanmedoxomil"
        },
        {
          "language" : "it-CH",
          "value" : "azilsartan medoxomil"
        }]
      },
      {
        "code" : "698025001",
        "display" : "Benzbromarone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benzbromarone"
        },
        {
          "language" : "fr-CH",
          "value" : "benzbromarone"
        },
        {
          "language" : "de-CH",
          "value" : "Benzbromaron"
        },
        {
          "language" : "it-CH",
          "value" : "benzbromarone"
        }]
      },
      {
        "code" : "698089009",
        "display" : "Besilesomab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Besilesomab"
        },
        {
          "language" : "fr-CH",
          "value" : "bésilésomab"
        },
        {
          "language" : "de-CH",
          "value" : "Besilesomab"
        },
        {
          "language" : "it-CH",
          "value" : "besilesomab"
        }]
      },
      {
        "code" : "698183007",
        "display" : "Boceprevir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Boceprevir"
        },
        {
          "language" : "fr-CH",
          "value" : "bocéprévir"
        },
        {
          "language" : "de-CH",
          "value" : "Boceprevir"
        },
        {
          "language" : "it-CH",
          "value" : "boceprevir"
        }]
      },
      {
        "code" : "698806003",
        "display" : "Telaprevir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Telaprevir"
        },
        {
          "language" : "fr-CH",
          "value" : "télaprévir"
        },
        {
          "language" : "de-CH",
          "value" : "Telaprevir"
        },
        {
          "language" : "it-CH",
          "value" : "telaprevir"
        }]
      },
      {
        "code" : "698843001",
        "display" : "Vinflunine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vinflunine"
        },
        {
          "language" : "fr-CH",
          "value" : "vinflunine"
        },
        {
          "language" : "de-CH",
          "value" : "Vinflunin"
        },
        {
          "language" : "it-CH",
          "value" : "vinflunina"
        }]
      },
      {
        "code" : "698871007",
        "display" : "Dabigatran (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dabigatran"
        },
        {
          "language" : "fr-CH",
          "value" : "dabigatran"
        },
        {
          "language" : "de-CH",
          "value" : "Dabigatran"
        },
        {
          "language" : "it-CH",
          "value" : "dabigatran"
        }]
      },
      {
        "code" : "699272003",
        "display" : "Racecadotril (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Racecadotril"
        },
        {
          "language" : "fr-CH",
          "value" : "racécadotril"
        },
        {
          "language" : "de-CH",
          "value" : "Racecadotril"
        },
        {
          "language" : "it-CH",
          "value" : "racecadotril"
        }]
      },
      {
        "code" : "700015007",
        "display" : "Eslicarbazepine acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eslicarbazepine acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate d'eslicarbazépine"
        },
        {
          "language" : "de-CH",
          "value" : "Eslicarbazepinacetat"
        },
        {
          "language" : "it-CH",
          "value" : "eslicarbazepina acetato"
        }]
      },
      {
        "code" : "702415007",
        "display" : "Ceftaroline fosamil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceftaroline fosamil"
        },
        {
          "language" : "fr-CH",
          "value" : "ceftaroline fosamil"
        },
        {
          "language" : "de-CH",
          "value" : "Ceftarolinfosamil"
        },
        {
          "language" : "it-CH",
          "value" : "ceftarolina fosamil"
        }]
      },
      {
        "code" : "702804006",
        "display" : "Regorafenib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Regorafenib"
        },
        {
          "language" : "fr-CH",
          "value" : "régorafénib"
        },
        {
          "language" : "de-CH",
          "value" : "Regorafenib"
        },
        {
          "language" : "it-CH",
          "value" : "regorafenib"
        }]
      },
      {
        "code" : "702805007",
        "display" : "Vemurafenib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vemurafenib"
        },
        {
          "language" : "fr-CH",
          "value" : "vémurafénib"
        },
        {
          "language" : "de-CH",
          "value" : "Vemurafenib"
        },
        {
          "language" : "it-CH",
          "value" : "vemurafenib"
        }]
      },
      {
        "code" : "703116009",
        "display" : "Lurasidone hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lurasidone hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de lurasidone"
        },
        {
          "language" : "de-CH",
          "value" : "Lurasidonhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "lurasidone cloridrato"
        }]
      },
      {
        "code" : "703125003",
        "display" : "Enzalutamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Enzalutamide"
        },
        {
          "language" : "fr-CH",
          "value" : "enzalutamide"
        },
        {
          "language" : "de-CH",
          "value" : "Enzalutamid"
        },
        {
          "language" : "it-CH",
          "value" : "enzalutamide"
        }]
      },
      {
        "code" : "703146007",
        "display" : "Ceritinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceritinib"
        },
        {
          "language" : "fr-CH",
          "value" : "céritinib"
        },
        {
          "language" : "de-CH",
          "value" : "Ceritinib"
        },
        {
          "language" : "it-CH",
          "value" : "ceritinib"
        }]
      },
      {
        "code" : "703250005",
        "display" : "Ulipristal acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ulipristal acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate d'ulipristal"
        },
        {
          "language" : "de-CH",
          "value" : "Ulipristalacetat"
        },
        {
          "language" : "it-CH",
          "value" : "ulipristal acetato"
        }]
      },
      {
        "code" : "703352000",
        "display" : "Ambroxol hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ambroxol hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate d'ambroxol"
        },
        {
          "language" : "de-CH",
          "value" : "Ambroxolhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "ambroxolo cloridrato"
        }]
      },
      {
        "code" : "703393008",
        "display" : "Alglucosidase alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Alglucosidase alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "alglucosidase alpha"
        },
        {
          "language" : "de-CH",
          "value" : "Alglucosidase alfa"
        },
        {
          "language" : "it-CH",
          "value" : "alglucosidasi alfa"
        }]
      },
      {
        "code" : "703405005",
        "display" : "Buflomedil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Buflomedil"
        },
        {
          "language" : "fr-CH",
          "value" : "buflomédil"
        },
        {
          "language" : "de-CH",
          "value" : "Buflomedil"
        },
        {
          "language" : "it-CH",
          "value" : "buflomedil"
        }]
      },
      {
        "code" : "703471002",
        "display" : "Nifuroxazide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nifuroxazide"
        },
        {
          "language" : "fr-CH",
          "value" : "nifuroxazide"
        },
        {
          "language" : "de-CH",
          "value" : "Nifuroxazide"
        },
        {
          "language" : "it-CH",
          "value" : "nifuroxazide"
        }]
      },
      {
        "code" : "703572006",
        "display" : "Proglumetacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Proglumetacin"
        },
        {
          "language" : "fr-CH",
          "value" : "proglumétacine"
        },
        {
          "language" : "de-CH",
          "value" : "Proglumetacin"
        },
        {
          "language" : "it-CH",
          "value" : "proglumetacina"
        }]
      },
      {
        "code" : "703637000",
        "display" : "Crizotinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Crizotinib"
        },
        {
          "language" : "fr-CH",
          "value" : "crizotinib"
        },
        {
          "language" : "de-CH",
          "value" : "Crizotinib"
        },
        {
          "language" : "it-CH",
          "value" : "crizotinib"
        }]
      },
      {
        "code" : "703720003",
        "display" : "Tromantadine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tromantadine"
        },
        {
          "language" : "fr-CH",
          "value" : "tromantadine"
        },
        {
          "language" : "de-CH",
          "value" : "Tromantadin"
        },
        {
          "language" : "it-CH",
          "value" : "tromantadina"
        }]
      },
      {
        "code" : "703785006",
        "display" : "Teriflunomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Teriflunomide"
        },
        {
          "language" : "fr-CH",
          "value" : "tériflunomide"
        },
        {
          "language" : "de-CH",
          "value" : "Teriflunomid"
        },
        {
          "language" : "it-CH",
          "value" : "teriflunomide"
        }]
      },
      {
        "code" : "703789000",
        "display" : "Pomalidomide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pomalidomide"
        },
        {
          "language" : "fr-CH",
          "value" : "pomalidomide"
        },
        {
          "language" : "de-CH",
          "value" : "Pomalidomid"
        },
        {
          "language" : "it-CH",
          "value" : "pomalidomide"
        }]
      },
      {
        "code" : "703796003",
        "display" : "Ponatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ponatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "ponatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Ponatinib"
        },
        {
          "language" : "it-CH",
          "value" : "ponatinib"
        }]
      },
      {
        "code" : "703812008",
        "display" : "Vismodegib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vismodegib"
        },
        {
          "language" : "fr-CH",
          "value" : "vismodégib"
        },
        {
          "language" : "de-CH",
          "value" : "Vismodegib"
        },
        {
          "language" : "it-CH",
          "value" : "vismodegib"
        }]
      },
      {
        "code" : "703913002",
        "display" : "Tedizolid phosphate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tedizolid phosphate"
        },
        {
          "language" : "fr-CH",
          "value" : "phosphate de tédizolide"
        },
        {
          "language" : "de-CH",
          "value" : "Tedizolidphosphat"
        },
        {
          "language" : "it-CH",
          "value" : "tedizolid fosfato"
        }]
      },
      {
        "code" : "703922001",
        "display" : "Aclidinium bromide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aclidinium bromide"
        },
        {
          "language" : "fr-CH",
          "value" : "bromure d'aclidinium"
        },
        {
          "language" : "de-CH",
          "value" : "Aclidiniumbromid"
        },
        {
          "language" : "it-CH",
          "value" : "aclidinio bromuro"
        }]
      },
      {
        "code" : "704262001",
        "display" : "Siltuximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Siltuximab"
        },
        {
          "language" : "fr-CH",
          "value" : "siltuximab"
        },
        {
          "language" : "de-CH",
          "value" : "Siltuximab"
        },
        {
          "language" : "it-CH",
          "value" : "siltuximab"
        }]
      },
      {
        "code" : "704313003",
        "display" : "Tofacitinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tofacitinib"
        },
        {
          "language" : "fr-CH",
          "value" : "tofacitinib"
        },
        {
          "language" : "de-CH",
          "value" : "Tofacitinib"
        },
        {
          "language" : "it-CH",
          "value" : "tofacitinib"
        }]
      },
      {
        "code" : "706897007",
        "display" : "Peginterferon beta-1a (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Peginterferon beta-1a"
        },
        {
          "language" : "fr-CH",
          "value" : "peginterféron bêta-1a"
        },
        {
          "language" : "de-CH",
          "value" : "Peginterferon beta-1a"
        },
        {
          "language" : "it-CH",
          "value" : "peginterferone beta-1a"
        }]
      },
      {
        "code" : "707543009",
        "display" : "Pyrvinium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pyrvinium"
        },
        {
          "language" : "fr-CH",
          "value" : "pyrvinium"
        },
        {
          "language" : "de-CH",
          "value" : "Pyrvinium"
        },
        {
          "language" : "it-CH",
          "value" : "pirvinio"
        }]
      },
      {
        "code" : "707837002",
        "display" : "Piritramide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Piritramide"
        },
        {
          "language" : "fr-CH",
          "value" : "piritramide"
        },
        {
          "language" : "de-CH",
          "value" : "Piritramid"
        },
        {
          "language" : "it-CH",
          "value" : "piritramide"
        }]
      },
      {
        "code" : "708792003",
        "display" : "Ceftolozane (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceftolozane"
        },
        {
          "language" : "fr-CH",
          "value" : "ceftolozane"
        },
        {
          "language" : "de-CH",
          "value" : "Ceftolozan"
        },
        {
          "language" : "it-CH",
          "value" : "ceftolozano"
        }]
      },
      {
        "code" : "708823009",
        "display" : "Simeprevir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Simeprevir"
        },
        {
          "language" : "fr-CH",
          "value" : "siméprévir"
        },
        {
          "language" : "de-CH",
          "value" : "Simeprevir"
        },
        {
          "language" : "it-CH",
          "value" : "simeprevir"
        }]
      },
      {
        "code" : "708830003",
        "display" : "Eprazinone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eprazinone"
        },
        {
          "language" : "fr-CH",
          "value" : "éprazinone"
        },
        {
          "language" : "de-CH",
          "value" : "Eprazinon"
        },
        {
          "language" : "it-CH",
          "value" : "eprazinone"
        }]
      },
      {
        "code" : "710179004",
        "display" : "Lupine seed (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lupine seed"
        },
        {
          "language" : "fr-CH",
          "value" : "lupin"
        },
        {
          "language" : "de-CH",
          "value" : "Lupinensamen"
        },
        {
          "language" : "it-CH",
          "value" : "semi di lupino"
        }]
      },
      {
        "code" : "710184005",
        "display" : "Mutton (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mutton"
        },
        {
          "language" : "fr-CH",
          "value" : "mouton"
        },
        {
          "language" : "de-CH",
          "value" : "Hammelfleisch"
        },
        {
          "language" : "it-CH",
          "value" : "carne di montone"
        }]
      },
      {
        "code" : "710202000",
        "display" : "Sultamicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sultamicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "sultamicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Sultamicillin"
        },
        {
          "language" : "it-CH",
          "value" : "sultamicillina"
        }]
      },
      {
        "code" : "710220009",
        "display" : "Common millet (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Common millet"
        },
        {
          "language" : "fr-CH",
          "value" : "millet commun"
        },
        {
          "language" : "de-CH",
          "value" : "Rispenhirse"
        },
        {
          "language" : "it-CH",
          "value" : "miglio comune"
        }]
      },
      {
        "code" : "710228002",
        "display" : "Ibrutinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ibrutinib"
        },
        {
          "language" : "fr-CH",
          "value" : "ibrutinib"
        },
        {
          "language" : "de-CH",
          "value" : "Ibrutinib"
        },
        {
          "language" : "it-CH",
          "value" : "ibrutinib"
        }]
      },
      {
        "code" : "710279008",
        "display" : "Ingenol mebutate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ingenol mebutate"
        },
        {
          "language" : "fr-CH",
          "value" : "mébutate d'ingénol"
        },
        {
          "language" : "de-CH",
          "value" : "Ingenolmebutat"
        },
        {
          "language" : "it-CH",
          "value" : "ingenol mebutato"
        }]
      },
      {
        "code" : "710284002",
        "display" : "Mifamurtide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mifamurtide"
        },
        {
          "language" : "fr-CH",
          "value" : "mifamurtide"
        },
        {
          "language" : "de-CH",
          "value" : "Mifamurtid"
        },
        {
          "language" : "it-CH",
          "value" : "mifamurtide"
        }]
      },
      {
        "code" : "710810006",
        "display" : "Gadobenic acid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gadobenic acid"
        },
        {
          "language" : "fr-CH",
          "value" : "acide gadobénique"
        },
        {
          "language" : "de-CH",
          "value" : "Gadobeninsäure"
        },
        {
          "language" : "it-CH",
          "value" : "acido gadobenico"
        }]
      },
      {
        "code" : "710932003",
        "display" : "Moth protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Moth protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de mite"
        },
        {
          "language" : "de-CH",
          "value" : "Mottenprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine di falena"
        }]
      },
      {
        "code" : "710939007",
        "display" : "Fire ant venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fire ant venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de fourmi de feu"
        },
        {
          "language" : "de-CH",
          "value" : "Feuerameisengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno delle formiche di fuoco"
        }]
      },
      {
        "code" : "710943006",
        "display" : "Cockroach protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cockroach protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de cafard"
        },
        {
          "language" : "de-CH",
          "value" : "Kakerlaken-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine delle blatte"
        }]
      },
      {
        "code" : "711075002",
        "display" : "Dog serum albumin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dog serum albumin"
        },
        {
          "language" : "fr-CH",
          "value" : "albumine sérique de chien"
        },
        {
          "language" : "de-CH",
          "value" : "Hundeserum-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "albumina di siero canino"
        }]
      },
      {
        "code" : "711084002",
        "display" : "Rabbit serum protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rabbit serum protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine sérique de lapin"
        },
        {
          "language" : "de-CH",
          "value" : "Kaninchenserum-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del siero di coniglio"
        }]
      },
      {
        "code" : "712688003",
        "display" : "Etofenamate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Etofenamate"
        },
        {
          "language" : "fr-CH",
          "value" : "étofenamate"
        },
        {
          "language" : "de-CH",
          "value" : "Etofenamate"
        },
        {
          "language" : "it-CH",
          "value" : "etofenamato"
        }]
      },
      {
        "code" : "713438006",
        "display" : "Pranlukast (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pranlukast"
        },
        {
          "language" : "fr-CH",
          "value" : "pranlukast"
        },
        {
          "language" : "de-CH",
          "value" : "Pranlukast"
        },
        {
          "language" : "it-CH",
          "value" : "pranlukast"
        }]
      },
      {
        "code" : "713478004",
        "display" : "Clobutinol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clobutinol"
        },
        {
          "language" : "fr-CH",
          "value" : "clobutinol"
        },
        {
          "language" : "de-CH",
          "value" : "Clobutinol"
        },
        {
          "language" : "it-CH",
          "value" : "clobutinolo"
        }]
      },
      {
        "code" : "713480005",
        "display" : "Oxaceprol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oxaceprol"
        },
        {
          "language" : "fr-CH",
          "value" : "oxacéprol"
        },
        {
          "language" : "de-CH",
          "value" : "Oxaceprol"
        },
        {
          "language" : "it-CH",
          "value" : "oxaceprolo"
        }]
      },
      {
        "code" : "713642004",
        "display" : "Miltefosine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Miltefosine"
        },
        {
          "language" : "fr-CH",
          "value" : "miltéfosine"
        },
        {
          "language" : "de-CH",
          "value" : "Miltefosine"
        },
        {
          "language" : "it-CH",
          "value" : "miltefosina"
        }]
      },
      {
        "code" : "714097004",
        "display" : "Delamanid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Delamanid"
        },
        {
          "language" : "fr-CH",
          "value" : "délamanid"
        },
        {
          "language" : "de-CH",
          "value" : "Delamanid"
        },
        {
          "language" : "it-CH",
          "value" : "delamanid"
        }]
      },
      {
        "code" : "714108002",
        "display" : "Lenvatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lenvatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "lenvatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Lenvatinib"
        },
        {
          "language" : "it-CH",
          "value" : "lenvatinib"
        }]
      },
      {
        "code" : "715187001",
        "display" : "Sonidegib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sonidegib"
        },
        {
          "language" : "fr-CH",
          "value" : "sonidégib"
        },
        {
          "language" : "de-CH",
          "value" : "Sonidegib"
        },
        {
          "language" : "it-CH",
          "value" : "sonidegib"
        }]
      },
      {
        "code" : "715220007",
        "display" : "Tenofovir alafenamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tenofovir alafenamide"
        },
        {
          "language" : "fr-CH",
          "value" : "ténofovir alafénamide"
        },
        {
          "language" : "de-CH",
          "value" : "Tenofoviralafenamid"
        },
        {
          "language" : "it-CH",
          "value" : "tenofovir alafenamide"
        }]
      },
      {
        "code" : "715254008",
        "display" : "Rolapitant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rolapitant"
        },
        {
          "language" : "fr-CH",
          "value" : "rolapitant"
        },
        {
          "language" : "de-CH",
          "value" : "Rolapitant"
        },
        {
          "language" : "it-CH",
          "value" : "rolapitant"
        }]
      },
      {
        "code" : "715255009",
        "display" : "Asfotase alfa (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Asfotase alfa"
        },
        {
          "language" : "fr-CH",
          "value" : "asfotase alpha"
        },
        {
          "language" : "de-CH",
          "value" : "Asfotase alfa"
        },
        {
          "language" : "it-CH",
          "value" : "asfotase alfa"
        }]
      },
      {
        "code" : "715256005",
        "display" : "Ixazomib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ixazomib"
        },
        {
          "language" : "fr-CH",
          "value" : "ixazomib"
        },
        {
          "language" : "de-CH",
          "value" : "Ixazomib"
        },
        {
          "language" : "it-CH",
          "value" : "ixazomib"
        }]
      },
      {
        "code" : "715389007",
        "display" : "Cortivazol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cortivazol"
        },
        {
          "language" : "fr-CH",
          "value" : "cortivazol"
        },
        {
          "language" : "de-CH",
          "value" : "Cortivazol"
        },
        {
          "language" : "it-CH",
          "value" : "cortivazolo"
        }]
      },
      {
        "code" : "715958001",
        "display" : "Palbociclib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Palbociclib"
        },
        {
          "language" : "fr-CH",
          "value" : "palbociclib"
        },
        {
          "language" : "de-CH",
          "value" : "Palbociclib"
        },
        {
          "language" : "it-CH",
          "value" : "palbociclib"
        }]
      },
      {
        "code" : "716032009",
        "display" : "Osimertinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Osimertinib"
        },
        {
          "language" : "fr-CH",
          "value" : "osimertinib"
        },
        {
          "language" : "de-CH",
          "value" : "Osimertinib"
        },
        {
          "language" : "it-CH",
          "value" : "osimertinib"
        }]
      },
      {
        "code" : "716046009",
        "display" : "Mepolizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mepolizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "mépolizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Mepolizumab"
        },
        {
          "language" : "it-CH",
          "value" : "mepolizumab"
        }]
      },
      {
        "code" : "716122004",
        "display" : "Blinatumomab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Blinatumomab"
        },
        {
          "language" : "fr-CH",
          "value" : "blinatumomab"
        },
        {
          "language" : "de-CH",
          "value" : "Blinatumomab"
        },
        {
          "language" : "it-CH",
          "value" : "blinatumomab"
        }]
      },
      {
        "code" : "716228008",
        "display" : "Lomitapide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lomitapide"
        },
        {
          "language" : "fr-CH",
          "value" : "lomitapide"
        },
        {
          "language" : "de-CH",
          "value" : "Lomitapide"
        },
        {
          "language" : "it-CH",
          "value" : "lomitapide"
        }]
      },
      {
        "code" : "716308007",
        "display" : "Pitolisant (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pitolisant"
        },
        {
          "language" : "fr-CH",
          "value" : "pitolisant"
        },
        {
          "language" : "de-CH",
          "value" : "Pitolisant"
        },
        {
          "language" : "it-CH",
          "value" : "pitolisant"
        }]
      },
      {
        "code" : "717178009",
        "display" : "Reslizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Reslizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "reslizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Reslizumab"
        },
        {
          "language" : "it-CH",
          "value" : "reslizumab"
        }]
      },
      {
        "code" : "717219000",
        "display" : "Talimogene laherparepvec (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Talimogene laherparepvec"
        },
        {
          "language" : "fr-CH",
          "value" : "talimogène laherparepvec"
        },
        {
          "language" : "de-CH",
          "value" : "Talimogenlaherparepvec"
        },
        {
          "language" : "it-CH",
          "value" : "talimogene laherparepvec"
        }]
      },
      {
        "code" : "717359004",
        "display" : "Selexipag (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Selexipag"
        },
        {
          "language" : "fr-CH",
          "value" : "sélexipag"
        },
        {
          "language" : "de-CH",
          "value" : "Selexipag"
        },
        {
          "language" : "it-CH",
          "value" : "selexipag"
        }]
      },
      {
        "code" : "718844003",
        "display" : "Cabozantinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cabozantinib"
        },
        {
          "language" : "fr-CH",
          "value" : "cabozantinib"
        },
        {
          "language" : "de-CH",
          "value" : "Cabozantinib"
        },
        {
          "language" : "it-CH",
          "value" : "cabozantinib"
        }]
      },
      {
        "code" : "719411008",
        "display" : "Naloxegol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Naloxegol"
        },
        {
          "language" : "fr-CH",
          "value" : "naloxégol"
        },
        {
          "language" : "de-CH",
          "value" : "Naloxegol"
        },
        {
          "language" : "it-CH",
          "value" : "naloxegol"
        }]
      },
      {
        "code" : "720687003",
        "display" : "Dust mite protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dust mite protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine d'acarien de la poussière domestique"
        },
        {
          "language" : "de-CH",
          "value" : "Hausstaubmilbenprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine degli acari della polvere"
        }]
      },
      {
        "code" : "723523007",
        "display" : "Olaratumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Olaratumab"
        },
        {
          "language" : "fr-CH",
          "value" : "olaratumab"
        },
        {
          "language" : "de-CH",
          "value" : "Olaratumab"
        },
        {
          "language" : "it-CH",
          "value" : "olaratumab"
        }]
      },
      {
        "code" : "723984009",
        "display" : "Rucaparib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rucaparib"
        },
        {
          "language" : "fr-CH",
          "value" : "rucaparib"
        },
        {
          "language" : "de-CH",
          "value" : "Rucaparib"
        },
        {
          "language" : "it-CH",
          "value" : "rucaparib"
        }]
      },
      {
        "code" : "724029008",
        "display" : "Tipiracil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tipiracil"
        },
        {
          "language" : "fr-CH",
          "value" : "tipiracil"
        },
        {
          "language" : "de-CH",
          "value" : "Tipiracil"
        },
        {
          "language" : "it-CH",
          "value" : "tipiracil"
        }]
      },
      {
        "code" : "724035008",
        "display" : "Dimethyl fumarate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dimethyl fumarate"
        },
        {
          "language" : "fr-CH",
          "value" : "fumarate de diméthyle"
        },
        {
          "language" : "de-CH",
          "value" : "Dimethylfumarat"
        },
        {
          "language" : "it-CH",
          "value" : "dimetilfumarato"
        }]
      },
      {
        "code" : "724036009",
        "display" : "Dinutuximab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dinutuximab"
        },
        {
          "language" : "fr-CH",
          "value" : "dinutuximab"
        },
        {
          "language" : "de-CH",
          "value" : "Dinutuximab"
        },
        {
          "language" : "it-CH",
          "value" : "dinutuximab"
        }]
      },
      {
        "code" : "725650009",
        "display" : "Pramipexole dihydrochloride monohydrate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pramipexole dihydrochloride monohydrate"
        },
        {
          "language" : "fr-CH",
          "value" : "dichlorhydrate de pramipexole monohydraté"
        },
        {
          "language" : "de-CH",
          "value" : "Pramipexoldihydrochlorid-Monohydrat"
        },
        {
          "language" : "it-CH",
          "value" : "pramipexolo dicloridrato monoidrato"
        }]
      },
      {
        "code" : "732257004",
        "display" : "Ribociclib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ribociclib"
        },
        {
          "language" : "fr-CH",
          "value" : "ribociclib"
        },
        {
          "language" : "de-CH",
          "value" : "Ribociclib"
        },
        {
          "language" : "it-CH",
          "value" : "ribociclib"
        }]
      },
      {
        "code" : "734512008",
        "display" : "Ceftobiprole (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ceftobiprole"
        },
        {
          "language" : "fr-CH",
          "value" : "ceftobiprole"
        },
        {
          "language" : "de-CH",
          "value" : "Ceftobiprol"
        },
        {
          "language" : "it-CH",
          "value" : "ceftobiprolo"
        }]
      },
      {
        "code" : "734647009",
        "display" : "Chlormadinone acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chlormadinone acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate de chlormadinone"
        },
        {
          "language" : "de-CH",
          "value" : "Chlormadinonacetat"
        },
        {
          "language" : "it-CH",
          "value" : "clormadinone acetato"
        }]
      },
      {
        "code" : "734881000",
        "display" : "Tomato (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tomato"
        },
        {
          "language" : "fr-CH",
          "value" : "tomate"
        },
        {
          "language" : "de-CH",
          "value" : "Tomate"
        },
        {
          "language" : "it-CH",
          "value" : "pomodoro"
        }]
      },
      {
        "code" : "735011001",
        "display" : "Delafloxacin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Delafloxacin"
        },
        {
          "language" : "fr-CH",
          "value" : "délafloxacine"
        },
        {
          "language" : "de-CH",
          "value" : "Delafloxacin"
        },
        {
          "language" : "it-CH",
          "value" : "delafloxacina"
        }]
      },
      {
        "code" : "735030001",
        "display" : "Garlic (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Garlic"
        },
        {
          "language" : "fr-CH",
          "value" : "ail"
        },
        {
          "language" : "de-CH",
          "value" : "Knoblauch"
        },
        {
          "language" : "it-CH",
          "value" : "aglio"
        }]
      },
      {
        "code" : "735047000",
        "display" : "Onion (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Onion"
        },
        {
          "language" : "fr-CH",
          "value" : "oignon"
        },
        {
          "language" : "de-CH",
          "value" : "Zwiebel"
        },
        {
          "language" : "it-CH",
          "value" : "cipolla"
        }]
      },
      {
        "code" : "735048005",
        "display" : "Parsley (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Parsley"
        },
        {
          "language" : "fr-CH",
          "value" : "persil"
        },
        {
          "language" : "de-CH",
          "value" : "Petersilie"
        },
        {
          "language" : "it-CH",
          "value" : "prezzemolo"
        }]
      },
      {
        "code" : "735053000",
        "display" : "Potato (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Potato"
        },
        {
          "language" : "fr-CH",
          "value" : "pomme de terre"
        },
        {
          "language" : "de-CH",
          "value" : "Kartoffel"
        },
        {
          "language" : "it-CH",
          "value" : "patata"
        }]
      },
      {
        "code" : "735215001",
        "display" : "Apple (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Apple"
        },
        {
          "language" : "fr-CH",
          "value" : "pomme"
        },
        {
          "language" : "de-CH",
          "value" : "Apfel"
        },
        {
          "language" : "it-CH",
          "value" : "mela"
        }]
      },
      {
        "code" : "735249009",
        "display" : "Avocado (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Avocado"
        },
        {
          "language" : "fr-CH",
          "value" : "avocat"
        },
        {
          "language" : "de-CH",
          "value" : "Avocado"
        },
        {
          "language" : "it-CH",
          "value" : "avocado"
        }]
      },
      {
        "code" : "735340006",
        "display" : "Lemon (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lemon"
        },
        {
          "language" : "fr-CH",
          "value" : "citron"
        },
        {
          "language" : "de-CH",
          "value" : "Zitrone"
        },
        {
          "language" : "it-CH",
          "value" : "limone"
        }]
      },
      {
        "code" : "735971005",
        "display" : "Fish (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fish"
        },
        {
          "language" : "fr-CH",
          "value" : "poisson"
        },
        {
          "language" : "de-CH",
          "value" : "Fisch"
        },
        {
          "language" : "it-CH",
          "value" : "pesce"
        }]
      },
      {
        "code" : "736495009",
        "display" : "Inotuzumab ozogamicin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Inotuzumab ozogamicin"
        },
        {
          "language" : "fr-CH",
          "value" : "inotuzumab ozogamicine"
        },
        {
          "language" : "de-CH",
          "value" : "Inotuzumab-Ozogamicin"
        },
        {
          "language" : "it-CH",
          "value" : "inotuzumab ozogamicin"
        }]
      },
      {
        "code" : "736632003",
        "display" : "Neratinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Neratinib"
        },
        {
          "language" : "fr-CH",
          "value" : "nératinib"
        },
        {
          "language" : "de-CH",
          "value" : "Neratinib"
        },
        {
          "language" : "it-CH",
          "value" : "neratinib"
        }]
      },
      {
        "code" : "736634002",
        "display" : "Brigatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brigatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "brigatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Brigatinib"
        },
        {
          "language" : "it-CH",
          "value" : "brigatinib"
        }]
      },
      {
        "code" : "762952008",
        "display" : "Peanut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Peanut"
        },
        {
          "language" : "fr-CH",
          "value" : "arachide"
        },
        {
          "language" : "de-CH",
          "value" : "Erdnuss"
        },
        {
          "language" : "it-CH",
          "value" : "arachide"
        }]
      },
      {
        "code" : "763651005",
        "display" : "Benralizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Benralizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "benralizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Benralizumab"
        },
        {
          "language" : "it-CH",
          "value" : "benralizumab"
        }]
      },
      {
        "code" : "764146007",
        "display" : "Penicillin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Penicillin"
        },
        {
          "language" : "fr-CH",
          "value" : "pénicilline"
        },
        {
          "language" : "de-CH",
          "value" : "Penicillin"
        },
        {
          "language" : "it-CH",
          "value" : "penicillina"
        }]
      },
      {
        "code" : "764147003",
        "display" : "Cephalosporin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cephalosporin"
        },
        {
          "language" : "fr-CH",
          "value" : "céphalosporine"
        },
        {
          "language" : "de-CH",
          "value" : "Cephalosporin"
        },
        {
          "language" : "it-CH",
          "value" : "cefalosporina"
        }]
      },
      {
        "code" : "765323009",
        "display" : "Manidipine hydrochloride (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Manidipine hydrochloride"
        },
        {
          "language" : "fr-CH",
          "value" : "chlorhydrate de manidipine"
        },
        {
          "language" : "de-CH",
          "value" : "Manidipinhydrochlorid"
        },
        {
          "language" : "it-CH",
          "value" : "manidipina cloridrato"
        }]
      },
      {
        "code" : "765360008",
        "display" : "Nimotuzumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Nimotuzumab"
        },
        {
          "language" : "fr-CH",
          "value" : "nimotuzumab"
        },
        {
          "language" : "de-CH",
          "value" : "Nimotuzumab"
        },
        {
          "language" : "it-CH",
          "value" : "nimotuzumab"
        }]
      },
      {
        "code" : "766972001",
        "display" : "Apalutamide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Apalutamide"
        },
        {
          "language" : "fr-CH",
          "value" : "apalutamide"
        },
        {
          "language" : "de-CH",
          "value" : "Apalutamid"
        },
        {
          "language" : "it-CH",
          "value" : "apalutamide"
        }]
      },
      {
        "code" : "767406000",
        "display" : "Sulfite and sulfite derivative (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfite and sulfite derivative"
        },
        {
          "language" : "fr-CH",
          "value" : "sulfites et leurs dérivés"
        },
        {
          "language" : "de-CH",
          "value" : "Sulfit und Sulfitderivate"
        },
        {
          "language" : "it-CH",
          "value" : "solfiti e derivati dei solfiti"
        }]
      },
      {
        "code" : "767513003",
        "display" : "Zinc and zinc compound (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Zinc and zinc compound"
        },
        {
          "language" : "fr-CH",
          "value" : "zinc et ses composés"
        },
        {
          "language" : "de-CH",
          "value" : "Zink und Zinkverbindung"
        },
        {
          "language" : "it-CH",
          "value" : "zinco e composti dello zinco"
        }]
      },
      {
        "code" : "768489007",
        "display" : "Fluprednidene acetate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluprednidene acetate"
        },
        {
          "language" : "fr-CH",
          "value" : "acétate  de fluprednidène"
        },
        {
          "language" : "de-CH",
          "value" : "Fluprednidenacetat"
        },
        {
          "language" : "it-CH",
          "value" : "fluprednidene acetato"
        }]
      },
      {
        "code" : "768973004",
        "display" : "Rifamycin (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Rifamycin"
        },
        {
          "language" : "fr-CH",
          "value" : "rifamycine"
        },
        {
          "language" : "de-CH",
          "value" : "Rifamycin"
        },
        {
          "language" : "it-CH",
          "value" : "rifamicina"
        }]
      },
      {
        "code" : "771591006",
        "display" : "Tildrakizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tildrakizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "tildrakizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Tildrakizumab"
        },
        {
          "language" : "it-CH",
          "value" : "tildrakizumab"
        }]
      },
      {
        "code" : "772245002",
        "display" : "Wool alcohol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Wool alcohol"
        },
        {
          "language" : "fr-CH",
          "value" : "alcool de laine"
        },
        {
          "language" : "de-CH",
          "value" : "Wollwachsalkohol"
        },
        {
          "language" : "it-CH",
          "value" : "alcoli della lanolina"
        }]
      },
      {
        "code" : "781492009",
        "display" : "Dacomitinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dacomitinib"
        },
        {
          "language" : "fr-CH",
          "value" : "dacomitinib"
        },
        {
          "language" : "de-CH",
          "value" : "Dacomitinib"
        },
        {
          "language" : "it-CH",
          "value" : "dacomitinib"
        }]
      },
      {
        "code" : "782376000",
        "display" : "Substance with prostaglandin-endoperoxide synthase inhibitor mechanism of action (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Substance with prostaglandin-endoperoxide synthase inhibitor mechanism of action"
        },
        {
          "language" : "fr-CH",
          "value" : "inhibiteur de cyclooxygénase"
        },
        {
          "language" : "de-CH",
          "value" : "Substanz mit Prostaglandin-Endoperoxid-Synthase-Hemmer Wirkmechanismus"
        },
        {
          "language" : "it-CH",
          "value" : "inibitore della prostaglandina-endoperossido sintasi"
        }]
      },
      {
        "code" : "782576004",
        "display" : "Tree pollen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tree pollen"
        },
        {
          "language" : "fr-CH",
          "value" : "pollen d'arbres"
        },
        {
          "language" : "de-CH",
          "value" : "Baumpollen"
        },
        {
          "language" : "it-CH",
          "value" : "polline di alberi"
        }]
      },
      {
        "code" : "782581008",
        "display" : "Inotersen (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Inotersen"
        },
        {
          "language" : "fr-CH",
          "value" : "inotersen"
        },
        {
          "language" : "de-CH",
          "value" : "Inotersen"
        },
        {
          "language" : "it-CH",
          "value" : "inotersen"
        }]
      },
      {
        "code" : "782974005",
        "display" : "Gilteritinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gilteritinib"
        },
        {
          "language" : "fr-CH",
          "value" : "giltéritinib"
        },
        {
          "language" : "de-CH",
          "value" : "Gilteritinib"
        },
        {
          "language" : "it-CH",
          "value" : "gilteritinib"
        }]
      },
      {
        "code" : "782976007",
        "display" : "Lorlatinib (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lorlatinib"
        },
        {
          "language" : "fr-CH",
          "value" : "lorlatinib"
        },
        {
          "language" : "de-CH",
          "value" : "Lorlatinib"
        },
        {
          "language" : "it-CH",
          "value" : "lorlatinib"
        }]
      },
      {
        "code" : "783849004",
        "display" : "Mangafodipir (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mangafodipir"
        },
        {
          "language" : "fr-CH",
          "value" : "mangafodipir"
        },
        {
          "language" : "de-CH",
          "value" : "Mangafodipir"
        },
        {
          "language" : "it-CH",
          "value" : "mangafodipir"
        }]
      },
      {
        "code" : "785816006",
        "display" : "Esketamine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Esketamine"
        },
        {
          "language" : "fr-CH",
          "value" : "eskétamine"
        },
        {
          "language" : "de-CH",
          "value" : "Esketamin"
        },
        {
          "language" : "it-CH",
          "value" : "esketamina"
        }]
      },
      {
        "code" : "787359005",
        "display" : "Romosozumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Romosozumab"
        },
        {
          "language" : "fr-CH",
          "value" : "romosozumab"
        },
        {
          "language" : "de-CH",
          "value" : "Romosozumab"
        },
        {
          "language" : "it-CH",
          "value" : "romosozumab"
        }]
      },
      {
        "code" : "789261007",
        "display" : "Albumin human (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Albumin human"
        },
        {
          "language" : "fr-CH",
          "value" : "albumine humaine"
        },
        {
          "language" : "de-CH",
          "value" : "Humanalbumin"
        },
        {
          "language" : "it-CH",
          "value" : "albumina umana"
        }]
      },
      {
        "code" : "819963008",
        "display" : "Brolucizumab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brolucizumab"
        },
        {
          "language" : "fr-CH",
          "value" : "brolucizumab"
        },
        {
          "language" : "de-CH",
          "value" : "Brolucizumab"
        },
        {
          "language" : "it-CH",
          "value" : "brolucizumab"
        }]
      },
      {
        "code" : "830076001",
        "display" : "Adhesive plaster (physical object)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Adhesive plaster"
        },
        {
          "language" : "fr-CH",
          "value" : "emplâtre adhésif"
        },
        {
          "language" : "de-CH",
          "value" : "Heftpflaster"
        },
        {
          "language" : "it-CH",
          "value" : "cerotto adesivo"
        }]
      },
      {
        "code" : "836374004",
        "display" : "Vaccine product containing Hepatitis B virus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Hepatitis B virus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène du virus de l'hépatite B"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Hepatitis-B-Virus-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni del virus dell’epatite B"
        }]
      },
      {
        "code" : "836375003",
        "display" : "Vaccine product containing Hepatitis A virus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Hepatitis A virus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène du virus de l'hépatite A"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Hepatitis-A-Virus-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni del virus dell’epatite A"
        }]
      },
      {
        "code" : "836380007",
        "display" : "Vaccine product containing Haemophilus influenzae type B antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Haemophilus influenzae type B antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène de Haemophilus influenzae de type B"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Haemophilus influenzae B-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di Haemophilus influenzae tipo B"
        }]
      },
      {
        "code" : "836381006",
        "display" : "Vaccine product containing Corynebacterium diphtheriae antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Corynebacterium diphtheriae antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène de Corynebacterium diphtheriae"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Corynebacterium diphtheriae-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "Vaccino contenente antigeni di Corynebacterium diphtheriae"
        }]
      },
      {
        "code" : "836387005",
        "display" : "Vaccine product containing Rotavirus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Rotavirus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène du rotavirus"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Rotavirus-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "Vaccino contenente antigeni di rotavirus"
        }]
      },
      {
        "code" : "836388000",
        "display" : "Vaccine product containing Rubella virus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Rubella virus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène du virus de la rubéole"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Rötelnvirus-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni del virus della rosolia"
        }]
      },
      {
        "code" : "836393002",
        "display" : "Vaccine product containing Rabies lyssavirus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Rabies lyssavirus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène du lyssavirus de la rage"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Rabies lyssavirus-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di Rabies lyssavirus"
        }]
      },
      {
        "code" : "836398006",
        "display" : "Vaccine product containing Streptococcus pneumoniae antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Streptococcus pneumoniae antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène de Streptococcus pneumoniae"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Streptococcus pneumoniae-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di Streptococcus pneumoniae"
        }]
      },
      {
        "code" : "838284008",
        "display" : "Fluoroquinolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fluoroquinolone"
        },
        {
          "language" : "fr-CH",
          "value" : "fluoroquinolone"
        },
        {
          "language" : "de-CH",
          "value" : "Fluorchinolon"
        },
        {
          "language" : "it-CH",
          "value" : "fluorochinolone"
        }]
      },
      {
        "code" : "863911006",
        "display" : "Vaccine product containing Clostridium tetani antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Clostridium tetani antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "produit vaccinal contenant l'antigène de Clostridium tetani"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Clostridium tetani-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di Clostridium tetani"
        }]
      },
      {
        "code" : "871724008",
        "display" : "Vaccine product containing only Japanese encephalitis virus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing only Japanese encephalitis virus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "vaccin contre l'encéphalite japonaise"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt, das nur das Antigen des Japanischen Enzephalitis-Virus enthält"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente solo antigeni del virus dell’encefalite giapponese"
        }]
      },
      {
        "code" : "161000221102",
        "display" : "Antigen of Corynebacterium diphtheriae toxoid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Antigen of Corynebacterium diphtheriae toxoid"
        },
        {
          "language" : "fr-CH",
          "value" : "antigène de l'anatoxine de Corynebacterium diphtheriae"
        },
        {
          "language" : "de-CH",
          "value" : "Corynebacterium diphtheriae-Toxoid-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "antigene del tossoide di Corynebacterium diphtheriae"
        }]
      },
      {
        "code" : "601000221108",
        "display" : "Vaccine product containing Bordetella pertussis antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Bordetella pertussis antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "vaccin contre la coqueluche"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit  Bordetella pertussis-Antigen"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di Bordetella pertussis"
        }]
      },
      {
        "code" : "961000221100",
        "display" : "Vaccine product containing only Salmonella enterica subspecies enterica serovar Typhi antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing only Salmonella enterica subspecies enterica serovar Typhi antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "vaccin contre la typhoïde"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt, das nur Salmonella enterica subspecies enterica serovar Typhi-Antigen enthält"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente solo antigeni di Salmonella enterica subspecies enterica serovar Typhi"
        }]
      },
      {
        "code" : "1031000221108",
        "display" : "Vaccine product containing Human poliovirus antigen (medicinal product)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Vaccine product containing Human poliovirus antigen"
        },
        {
          "language" : "fr-CH",
          "value" : "vaccin contenant l'antigène de la poliomyélite"
        },
        {
          "language" : "de-CH",
          "value" : "Impfstoffprodukt mit Antigen des humanen Poliovirus"
        },
        {
          "language" : "it-CH",
          "value" : "vaccino contenente antigeni di poliovirus umano"
        }]
      },
      {
        "code" : "18751000122108",
        "display" : "Dropropizine (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dropropizine"
        },
        {
          "language" : "fr-CH",
          "value" : "dropropizine"
        },
        {
          "language" : "de-CH",
          "value" : "Dropropizin"
        },
        {
          "language" : "it-CH",
          "value" : "dropropizina"
        }]
      },
      {
        "code" : "20741000122103",
        "display" : "Tiropramide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tiropramide"
        },
        {
          "language" : "fr-CH",
          "value" : "tiropramide"
        },
        {
          "language" : "de-CH",
          "value" : "Tiropramid"
        },
        {
          "language" : "it-CH",
          "value" : "tiropramide"
        }]
      },
      {
        "code" : "428787002",
        "display" : "Macrolide (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Macrolide"
        },
        {
          "language" : "fr-CH",
          "value" : "macrolide"
        },
        {
          "language" : "de-CH",
          "value" : "Macrolid"
        },
        {
          "language" : "it-CH",
          "value" : "macrolide"
        }]
      },
      {
        "code" : "763805006",
        "display" : "Aminoglycoside (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Aminoglycoside"
        },
        {
          "language" : "fr-CH",
          "value" : "aminoglycosides"
        },
        {
          "language" : "de-CH",
          "value" : "Aminoglycosid"
        },
        {
          "language" : "it-CH",
          "value" : "aminoglicoside"
        }]
      },
      {
        "code" : "764148008",
        "display" : "Quinolone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Quinolone"
        },
        {
          "language" : "fr-CH",
          "value" : "quinolone"
        },
        {
          "language" : "de-CH",
          "value" : "Chinolon"
        },
        {
          "language" : "it-CH",
          "value" : "chinolone"
        }]
      },
      {
        "code" : "711094007",
        "display" : "Dermatophagoides pteronyssinus protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dermatophagoides pteronyssinus protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de Dermatophagoïdes pteronyssinus"
        },
        {
          "language" : "de-CH",
          "value" : "Dermatophagoides pteronyssinus-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine di Dermatophagoides pteronyssinus"
        }]
      },
      {
        "code" : "711092006",
        "display" : "Dermatophagoides farinae protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Dermatophagoides farinae protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine de Dermatophagoïdes farinae"
        },
        {
          "language" : "de-CH",
          "value" : "Dermatophagoides farinae-Protein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine di Dermatophagoides farinae"
        }]
      },
      {
        "code" : "1003752001",
        "display" : "Hevea brasiliensis latex protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hevea brasiliensis latex protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine du latex d'Hevea brasiliensis"
        },
        {
          "language" : "de-CH",
          "value" : "Hevea brasiliensis-Latexprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del lattice di Hevea brasiliensis"
        }]
      },
      {
        "code" : "260152009",
        "display" : "Cat dander (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cat dander"
        },
        {
          "language" : "fr-CH",
          "value" : "squames de chat"
        },
        {
          "language" : "de-CH",
          "value" : "Hautschuppen der Katze"
        },
        {
          "language" : "it-CH",
          "value" : "pelo di gatto"
        }]
      },
      {
        "code" : "735124003",
        "display" : "Barley (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Barley"
        },
        {
          "language" : "fr-CH",
          "value" : "orge"
        },
        {
          "language" : "de-CH",
          "value" : "Gerste"
        },
        {
          "language" : "it-CH",
          "value" : "orzo"
        }]
      },
      {
        "code" : "418504009",
        "display" : "Oat (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oat"
        },
        {
          "language" : "fr-CH",
          "value" : "avoine"
        },
        {
          "language" : "de-CH",
          "value" : "Hafer"
        },
        {
          "language" : "it-CH",
          "value" : "avena"
        }]
      },
      {
        "code" : "412357001",
        "display" : "Corn (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Corn"
        },
        {
          "language" : "fr-CH",
          "value" : "maïs"
        },
        {
          "language" : "de-CH",
          "value" : "Mais"
        },
        {
          "language" : "it-CH",
          "value" : "mais"
        }]
      },
      {
        "code" : "735977009",
        "display" : "Marine crustacean (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Marine crustacean"
        },
        {
          "language" : "fr-CH",
          "value" : "crustacés marins"
        },
        {
          "language" : "de-CH",
          "value" : "Meereskrebstier"
        },
        {
          "language" : "it-CH",
          "value" : "crostaceo marino"
        }]
      },
      {
        "code" : "736162008",
        "display" : "Lobster (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lobster"
        },
        {
          "language" : "fr-CH",
          "value" : "homard"
        },
        {
          "language" : "de-CH",
          "value" : "Hummer"
        },
        {
          "language" : "it-CH",
          "value" : "astice"
        }]
      },
      {
        "code" : "736159005",
        "display" : "Crab (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Crab"
        },
        {
          "language" : "fr-CH",
          "value" : "crabe"
        },
        {
          "language" : "de-CH",
          "value" : "Krabbe"
        },
        {
          "language" : "it-CH",
          "value" : "granchio"
        }]
      },
      {
        "code" : "735972003",
        "display" : "Crayfish (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Crayfish"
        },
        {
          "language" : "fr-CH",
          "value" : "écrevisse"
        },
        {
          "language" : "de-CH",
          "value" : "Flusskrebs"
        },
        {
          "language" : "it-CH",
          "value" : "gambero d’acqua dolce"
        }]
      },
      {
        "code" : "227151004",
        "display" : "Prawns (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Prawns"
        },
        {
          "language" : "fr-CH",
          "value" : "crevette rose"
        },
        {
          "language" : "de-CH",
          "value" : "Garnelen"
        },
        {
          "language" : "it-CH",
          "value" : "gamberetto"
        }]
      },
      {
        "code" : "227156009",
        "display" : "Scampi (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Scampi"
        },
        {
          "language" : "fr-CH",
          "value" : "langoustine"
        },
        {
          "language" : "de-CH",
          "value" : "Scampi"
        },
        {
          "language" : "it-CH",
          "value" : "scampo"
        }]
      },
      {
        "code" : "710185006",
        "display" : "Spiny lobster (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Spiny lobster"
        },
        {
          "language" : "fr-CH",
          "value" : "langouste"
        },
        {
          "language" : "de-CH",
          "value" : "Languste"
        },
        {
          "language" : "it-CH",
          "value" : "aragosta di roccia"
        }]
      },
      {
        "code" : "102263004",
        "display" : "Eggs (edible) (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Eggs"
        },
        {
          "language" : "fr-CH",
          "value" : "œufs"
        },
        {
          "language" : "de-CH",
          "value" : "Eier"
        },
        {
          "language" : "it-CH",
          "value" : "uova"
        }]
      },
      {
        "code" : "256443002",
        "display" : "Egg white (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Egg white"
        },
        {
          "language" : "fr-CH",
          "value" : "blanc d'œuf"
        },
        {
          "language" : "de-CH",
          "value" : "Eiweiss"
        },
        {
          "language" : "it-CH",
          "value" : "bianco d’uovo"
        }]
      },
      {
        "code" : "226885005",
        "display" : "Raw egg (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Raw egg"
        },
        {
          "language" : "fr-CH",
          "value" : "œuf cru"
        },
        {
          "language" : "de-CH",
          "value" : "Rohes Ei"
        },
        {
          "language" : "it-CH",
          "value" : "uovo crudo"
        }]
      },
      {
        "code" : "417889008",
        "display" : "Arachis oil (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Arachis oil"
        },
        {
          "language" : "fr-CH",
          "value" : "huile d'arachide"
        },
        {
          "language" : "de-CH",
          "value" : "Arachisöl"
        },
        {
          "language" : "it-CH",
          "value" : "olio di semi di arachide"
        }]
      },
      {
        "code" : "227346004",
        "display" : "Chick peas (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chick peas"
        },
        {
          "language" : "fr-CH",
          "value" : "pois chiches"
        },
        {
          "language" : "de-CH",
          "value" : "Kichererbsen"
        },
        {
          "language" : "it-CH",
          "value" : "ceci"
        }]
      },
      {
        "code" : "227244003",
        "display" : "Fenugreek (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Fenugreek"
        },
        {
          "language" : "fr-CH",
          "value" : "fenugrec"
        },
        {
          "language" : "de-CH",
          "value" : "Bockshornklee"
        },
        {
          "language" : "it-CH",
          "value" : "fieno greco"
        }]
      },
      {
        "code" : "227350006",
        "display" : "Lentils (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Lentils"
        },
        {
          "language" : "fr-CH",
          "value" : "lentilles"
        },
        {
          "language" : "de-CH",
          "value" : "Linsen"
        },
        {
          "language" : "it-CH",
          "value" : "lenticchie"
        }]
      },
      {
        "code" : "256354006",
        "display" : "Bean (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bean"
        },
        {
          "language" : "fr-CH",
          "value" : "fèves"
        },
        {
          "language" : "de-CH",
          "value" : "Bohne"
        },
        {
          "language" : "it-CH",
          "value" : "fagiolo"
        }]
      },
      {
        "code" : "3718001",
        "display" : "Cow's milk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cow's milk"
        },
        {
          "language" : "fr-CH",
          "value" : "lait de vache"
        },
        {
          "language" : "de-CH",
          "value" : "Kuhmilch"
        },
        {
          "language" : "it-CH",
          "value" : "latte vaccino"
        }]
      },
      {
        "code" : "442571000124108",
        "display" : "Tree nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Tree nut"
        },
        {
          "language" : "fr-CH",
          "value" : "fruits à coque"
        },
        {
          "language" : "de-CH",
          "value" : "Baumnuss"
        },
        {
          "language" : "it-CH",
          "value" : "frutta a guscio"
        }]
      },
      {
        "code" : "256350002",
        "display" : "Almond (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Almond"
        },
        {
          "language" : "fr-CH",
          "value" : "amande"
        },
        {
          "language" : "de-CH",
          "value" : "Mandel"
        },
        {
          "language" : "it-CH",
          "value" : "mandorla"
        }]
      },
      {
        "code" : "227493005",
        "display" : "Cashew nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cashew nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix de cajou"
        },
        {
          "language" : "de-CH",
          "value" : "Cashewnuss"
        },
        {
          "language" : "it-CH",
          "value" : "anacardio"
        }]
      },
      {
        "code" : "260189007",
        "display" : "Pecan nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pecan nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix de pécan"
        },
        {
          "language" : "de-CH",
          "value" : "Pekannuss"
        },
        {
          "language" : "it-CH",
          "value" : "noce pecan"
        }]
      },
      {
        "code" : "256351003",
        "display" : "Brazil nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Brazil nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix du Brésil"
        },
        {
          "language" : "de-CH",
          "value" : "Paranuss"
        },
        {
          "language" : "it-CH",
          "value" : "noce del Brasile"
        }]
      },
      {
        "code" : "227512001",
        "display" : "Pistachio nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Pistachio nut"
        },
        {
          "language" : "fr-CH",
          "value" : "pistache"
        },
        {
          "language" : "de-CH",
          "value" : "Pistaziennuss"
        },
        {
          "language" : "it-CH",
          "value" : "pistacchio"
        }]
      },
      {
        "code" : "227501001",
        "display" : "Macadamia nut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Macadamia nut"
        },
        {
          "language" : "fr-CH",
          "value" : "noix de macadamia"
        },
        {
          "language" : "de-CH",
          "value" : "Macadamianuss"
        },
        {
          "language" : "it-CH",
          "value" : "noce di macadamia"
        }]
      },
      {
        "code" : "260188004",
        "display" : "Chestnut (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Chestnut"
        },
        {
          "language" : "fr-CH",
          "value" : "châtaigne"
        },
        {
          "language" : "de-CH",
          "value" : "Kastanie"
        },
        {
          "language" : "it-CH",
          "value" : "castagna"
        }]
      },
      {
        "code" : "86233005",
        "display" : "Sulfur dioxide (substance",
        "designation" : [{
          "language" : "en-US",
          "value" : "Sulfur dioxide"
        },
        {
          "language" : "fr-CH",
          "value" : "dioxyde de soufre"
        },
        {
          "language" : "de-CH",
          "value" : "Schwefeldioxid"
        },
        {
          "language" : "it-CH",
          "value" : "zolfo diossido"
        }]
      },
      {
        "code" : "770326002",
        "display" : "Mollusk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mollusk"
        },
        {
          "language" : "fr-CH",
          "value" : "mollusque"
        },
        {
          "language" : "de-CH",
          "value" : "Weichtier"
        },
        {
          "language" : "it-CH",
          "value" : "mollusco"
        }]
      },
      {
        "code" : "735002001",
        "display" : "Terrestrial mollusk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Terrestrial mollusk"
        },
        {
          "language" : "fr-CH",
          "value" : "mollusque terrestre"
        },
        {
          "language" : "de-CH",
          "value" : "Terrestrisches Weichtier"
        },
        {
          "language" : "it-CH",
          "value" : "mollusco terrestre"
        }]
      },
      {
        "code" : "735959004",
        "display" : "Marine mollusk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Marine mollusk"
        },
        {
          "language" : "fr-CH",
          "value" : "mollusque marin"
        },
        {
          "language" : "de-CH",
          "value" : "Meeresweichtier"
        },
        {
          "language" : "it-CH",
          "value" : "mollusco marino"
        }]
      },
      {
        "code" : "765098000",
        "display" : "Abalone (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Abalone"
        },
        {
          "language" : "fr-CH",
          "value" : "ormeau"
        },
        {
          "language" : "de-CH",
          "value" : "Seeohren"
        },
        {
          "language" : "it-CH",
          "value" : "abalone"
        }]
      },
      {
        "code" : "736030007",
        "display" : "Clam (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Clam"
        },
        {
          "language" : "fr-CH",
          "value" : "palourde"
        },
        {
          "language" : "de-CH",
          "value" : "Venusmuschel"
        },
        {
          "language" : "it-CH",
          "value" : "vongola"
        }]
      },
      {
        "code" : "227147001",
        "display" : "Cockles (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cockles"
        },
        {
          "language" : "fr-CH",
          "value" : "coques"
        },
        {
          "language" : "de-CH",
          "value" : "Herzmuschel"
        },
        {
          "language" : "it-CH",
          "value" : "cardio"
        }]
      },
      {
        "code" : "726759005",
        "display" : "Cuttlefish (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Cuttlefish"
        },
        {
          "language" : "fr-CH",
          "value" : "seiche"
        },
        {
          "language" : "de-CH",
          "value" : "Sepien"
        },
        {
          "language" : "it-CH",
          "value" : "seppia"
        }]
      },
      {
        "code" : "227150003",
        "display" : "Mussel (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Mussel"
        },
        {
          "language" : "fr-CH",
          "value" : "moule"
        },
        {
          "language" : "de-CH",
          "value" : "Muschel"
        },
        {
          "language" : "it-CH",
          "value" : "cozza"
        }]
      },
      {
        "code" : "735979007",
        "display" : "Octopus (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Octopus"
        },
        {
          "language" : "fr-CH",
          "value" : "poulpe"
        },
        {
          "language" : "de-CH",
          "value" : "Tintenfisch"
        },
        {
          "language" : "it-CH",
          "value" : "polpo"
        }]
      },
      {
        "code" : "736031006",
        "display" : "Oyster (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Oyster"
        },
        {
          "language" : "fr-CH",
          "value" : "huître"
        },
        {
          "language" : "de-CH",
          "value" : "Auster"
        },
        {
          "language" : "it-CH",
          "value" : "ostrica"
        }]
      },
      {
        "code" : "736027000",
        "display" : "Scallop (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Scallop"
        },
        {
          "language" : "fr-CH",
          "value" : "coquille Saint-Jacques"
        },
        {
          "language" : "de-CH",
          "value" : "Jakobsmuschel"
        },
        {
          "language" : "it-CH",
          "value" : "capasanta"
        }]
      },
      {
        "code" : "735006003",
        "display" : "Squid (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Squid"
        },
        {
          "language" : "fr-CH",
          "value" : "calamar"
        },
        {
          "language" : "de-CH",
          "value" : "Kalmar"
        },
        {
          "language" : "it-CH",
          "value" : "calamaro"
        }]
      },
      {
        "code" : "227168000",
        "display" : "Whelks (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Whelks"
        },
        {
          "language" : "fr-CH",
          "value" : "bulots"
        },
        {
          "language" : "de-CH",
          "value" : "Wellhornschnecke"
        },
        {
          "language" : "it-CH",
          "value" : "buccino"
        }]
      },
      {
        "code" : "227169008",
        "display" : "Winkles (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Winkles"
        },
        {
          "language" : "fr-CH",
          "value" : "bigorneaux"
        },
        {
          "language" : "de-CH",
          "value" : "Strandschnecke"
        },
        {
          "language" : "it-CH",
          "value" : "littorina"
        }]
      },
      {
        "code" : "426722004",
        "display" : "Iodinated contrast media (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iodinated contrast media"
        },
        {
          "language" : "fr-CH",
          "value" : "produit de contraste iodé"
        },
        {
          "language" : "de-CH",
          "value" : "Jodhaltiges Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "mezzo di contrasto iodato"
        }]
      },
      {
        "code" : "395760005",
        "display" : "Ioxaglate (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ioxaglate"
        },
        {
          "language" : "fr-CH",
          "value" : "ioxaglate"
        },
        {
          "language" : "de-CH",
          "value" : "Ioxaglat"
        },
        {
          "language" : "it-CH",
          "value" : "ioxaglato"
        }]
      },
      {
        "code" : "395753004",
        "display" : "Iomeprol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iomeprol"
        },
        {
          "language" : "fr-CH",
          "value" : "ioméprol"
        },
        {
          "language" : "de-CH",
          "value" : "Iomeprol"
        },
        {
          "language" : "it-CH",
          "value" : "iomeprolo"
        }]
      },
      {
        "code" : "704384003",
        "display" : "Iobitridol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iobitridol"
        },
        {
          "language" : "fr-CH",
          "value" : "iobitridol"
        },
        {
          "language" : "de-CH",
          "value" : "Iobitridol"
        },
        {
          "language" : "it-CH",
          "value" : "iobitridolo"
        }]
      },
      {
        "code" : "395759000",
        "display" : "Ioversol (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Ioversol"
        },
        {
          "language" : "fr-CH",
          "value" : "ioversol"
        },
        {
          "language" : "de-CH",
          "value" : "Ioversol"
        },
        {
          "language" : "it-CH",
          "value" : "ioversolo"
        }]
      },
      {
        "code" : "395758008",
        "display" : "Iotrolan (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Iotrolan"
        },
        {
          "language" : "fr-CH",
          "value" : "iotrolan"
        },
        {
          "language" : "de-CH",
          "value" : "Iotrolan"
        },
        {
          "language" : "it-CH",
          "value" : "iotrolan"
        }]
      },
      {
        "code" : "767234009",
        "display" : "Gadolinium and/or gadolinium compound (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gadolinium and gadolinium compound"
        },
        {
          "language" : "fr-CH",
          "value" : "gadolinium et ses composés"
        },
        {
          "language" : "de-CH",
          "value" : "Gadolinium und Gadoliniumverbindung"
        },
        {
          "language" : "it-CH",
          "value" : "gadolinio e composti del gadolinio"
        }]
      },
      {
        "code" : "419909004",
        "display" : "Magnetic resonance imaging contrast medium agent (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Magnetic resonance imaging contrast medium agent"
        },
        {
          "language" : "fr-CH",
          "value" : "agent de contraste pour l'imagerie par résonance magnétique"
        },
        {
          "language" : "de-CH",
          "value" : "MRT-Kontrastmittel"
        },
        {
          "language" : "it-CH",
          "value" : "mezzo di contrasto della tomografia a risonanza magnetica"
        }]
      },
      {
        "code" : "58281002",
        "display" : "Gadolinium (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Gadolinium"
        },
        {
          "language" : "fr-CH",
          "value" : "gadolinium"
        },
        {
          "language" : "de-CH",
          "value" : "Gadolinium"
        },
        {
          "language" : "it-CH",
          "value" : "gadolinio"
        }]
      },
      {
        "code" : "288328004",
        "display" : "Bee venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bee venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin d'abeille"
        },
        {
          "language" : "de-CH",
          "value" : "Bienengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di ape"
        }]
      },
      {
        "code" : "288460008",
        "display" : "Bumble bee venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Bumble bee venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de bourdon"
        },
        {
          "language" : "de-CH",
          "value" : "Hummelgift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di bombo"
        }]
      },
      {
        "code" : "260194007",
        "display" : "Paper wasp venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Paper wasp venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de guêpes polistes"
        },
        {
          "language" : "de-CH",
          "value" : "Papierwespengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di vespa cartonaia"
        }]
      },
      {
        "code" : "288326000",
        "display" : "Hornet venom (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hornet venom"
        },
        {
          "language" : "fr-CH",
          "value" : "venin de frelon"
        },
        {
          "language" : "de-CH",
          "value" : "Hornissengift"
        },
        {
          "language" : "it-CH",
          "value" : "veleno di calabrone"
        }]
      },
      {
        "code" : "70813002",
        "display" : "Milk (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Milk"
        },
        {
          "language" : "fr-CH",
          "value" : "lait"
        },
        {
          "language" : "de-CH",
          "value" : "Milch"
        },
        {
          "language" : "it-CH",
          "value" : "latte"
        }]
      },
      {
        "code" : "10827009",
        "display" : "Milk protein (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Milk protein"
        },
        {
          "language" : "fr-CH",
          "value" : "protéine du lait"
        },
        {
          "language" : "de-CH",
          "value" : "Milchprotein"
        },
        {
          "language" : "it-CH",
          "value" : "proteine del latte"
        }]
      },
      {
        "code" : "1003751008",
        "display" : "Hevea brasiliensis latex (substance)",
        "designation" : [{
          "language" : "en-US",
          "value" : "Hevea brasiliensis latex"
        },
        {
          "language" : "fr-CH",
          "value" : "latex d'Hevea brasiliensis"
        },
        {
          "language" : "de-CH",
          "value" : "Hevea brasiliensis-Latex"
        },
        {
          "language" : "it-CH",
          "value" : "lattice di Hevea brasiliensis"
        }]
      }]
    }]
  }
}

```
