# DocumentEntry.confidentialityCode - CH Term (R4) v3.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentEntry.confidentialityCode**

## ValueSet: DocumentEntry.confidentialityCode 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-term/ValueSet/DocumentEntry.confidentialityCode | *Version*:3.4.0 |
| Active as of 2026-06-10 | *Computable Name*:DocumentEntryConfidentialityCode |
| *Other Identifiers:*OID:2.16.756.5.30.1.127.3.10.1.5 (use: official, ) | |
| **Copyright/Legal**: This artefact includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license - for more information contact http://www.snomed.org/snomed-ct/getsnomed-ct or info@snomed.org. | |

 
Document confidentiality as per Annex; EPRO-FDHA. 

 **References** 

 Detailed information about the **current version** of this artifact, including cross-references to resources that use it, can be found [here](http://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-term%7Ccurrent/ValueSet/DocumentEntry.confidentialityCode) via the XIG (Cross-IG) index for FHIR specifications. 

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DocumentEntry.confidentialityCode",
  "meta" : {
    "source" : "https://art-decor.org/fhir/ValueSet/2.16.756.5.30.1.127.3.10.1.5--20220626133515",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2022-06-26T13:35:15+02:00"
    }
  }],
  "url" : "http://fhir.ch/ig/ch-term/ValueSet/DocumentEntry.confidentialityCode",
  "identifier" : [{
    "use" : "official",
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.756.5.30.1.127.3.10.1.5"
  }],
  "version" : "3.4.0",
  "name" : "DocumentEntryConfidentialityCode",
  "title" : "DocumentEntry.confidentialityCode",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-10T09:49:50+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "Document confidentiality as per Annex; EPRO-FDHA.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "immutable" : false,
  "copyright" : "This artefact includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license - for more information contact http://www.snomed.org/snomed-ct/getsnomed-ct or info@snomed.org.",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/2011000195101",
      "concept" : [{
        "code" : "1141000195107",
        "display" : "Secret (qualifier value)",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Geheim"
        },
        {
          "language" : "fr-CH",
          "value" : "secret"
        },
        {
          "language" : "it-CH",
          "value" : "segreto"
        },
        {
          "language" : "en-US",
          "value" : "Secret"
        },
        {
          "language" : "rm-CH",
          "value" : "secret"
        }]
      }]
    },
    {
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "17621005",
        "display" : "Normal (qualifier value)",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Normal"
        },
        {
          "language" : "fr-CH",
          "value" : "normal"
        },
        {
          "language" : "it-CH",
          "value" : "normale"
        },
        {
          "language" : "en-US",
          "value" : "Normal"
        },
        {
          "language" : "rm-CH",
          "value" : "normal"
        }]
      },
      {
        "code" : "263856008",
        "display" : "Restricted (qualifier value)",
        "designation" : [{
          "language" : "de-CH",
          "value" : "Eingeschränkt"
        },
        {
          "language" : "fr-CH",
          "value" : "restreint"
        },
        {
          "language" : "it-CH",
          "value" : "limitato"
        },
        {
          "language" : "en-US",
          "value" : "Restricted"
        },
        {
          "language" : "rm-CH",
          "value" : "restrenschida"
        }]
      }]
    }]
  }
}

```
