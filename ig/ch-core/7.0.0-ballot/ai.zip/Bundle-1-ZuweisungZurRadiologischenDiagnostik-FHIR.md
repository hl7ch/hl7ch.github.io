# Zuweisung zur radiologischen Diagnostik - CH Core (R4) v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Zuweisung zur radiologischen Diagnostik**

## Example Bundle: Zuweisung zur radiologischen Diagnostik



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "1-ZuweisungZurRadiologischenDiagnostik-FHIR",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-document",
    "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-document-epr"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:31397b31-be60-47e1-bec6-f37816d42b0c"
  },
  "type" : "document",
  "timestamp" : "2017-10-03T17:33:00+01:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/ZuweisungZurRadiologischenDiagnostik",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "ZuweisungZurRadiologischenDiagnostik",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-composition",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-composition-epr"]
      },
      "language" : "de-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"Composition_ZuweisungZurRadiologischenDiagnostik\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition ZuweisungZurRadiologischenDiagnostik</b></p><a name=\"ZuweisungZurRadiologischenDiagnostik\"> </a><a name=\"hcZuweisungZurRadiologischenDiagnostik\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-composition.html\">CH Core Composition</a>, <a href=\"StructureDefinition-ch-core-composition-epr.html\">CH Core Composition EPR</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/7.0.1/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:31397b31-be60-47e1-bec6-f37816d42b0c</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 28616-1}, {http://snomed.info/sct 371535009}\">Physician Transfer note</span></p><p><b>date</b>: 2017-10-03 17:33:00+0100</p><p><b>author</b>: <a href=\"Practitioner-AllzeitBereit.html\">Practitioner Allzeit Bereit (official)</a></p><p><b>title</b>: Zuweisung zur Radiologischen Diagnostik</p><p><b>confidentiality</b>: normal</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Legal</td><td>2017-10-03</td><td><a href=\"Practitioner-AllzeitBereit.html\">Practitioner Allzeit Bereit (official)</a></td></tr></table><p><b>custodian</b>: <a href=\"Organization-GruppenpraxisCH.html\">Organization Gruppenpraxis CH</a></p></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:31397b31-be60-47e1-bec6-f37816d42b0c"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "28616-1",
          "display" : "Physician Transfer note"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "371535009",
          "display" : "Transfer summary report"
        }]
      },
      "subject" : {
        "reference" : "Patient/MaxMuster"
      },
      "date" : "2017-10-03T17:33:00+01:00",
      "author" : [{
        "reference" : "Practitioner/AllzeitBereit"
      }],
      "title" : "Zuweisung zur Radiologischen Diagnostik",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal"
            }]
          }
        }]
      },
      "attester" : [{
        "mode" : "legal",
        "time" : "2017-10-03",
        "party" : {
          "reference" : "Practitioner/AllzeitBereit"
        }
      }],
      "custodian" : {
        "reference" : "Organization/GruppenpraxisCH"
      },
      "section" : [{
        "title" : "Gewünschte Untersuchung",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Der Patient erwartet Ihr Aufgebot zur Untersuchung.<br/><i>Spezifizierung der gewünschten Untersuchung</i><br/></div>"
        }
      },
      {
        "title" : "Dringlichkeit / Wunschtermin",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><i>Angaben zum gewünschten Termin</i></div>"
        }
      },
      {
        "title" : "Fragestellung",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><i>Grund für die Durchführung der Untersuchung und Angaben zum aktuellen Leiden resp. zum Grund der Untersuchung</i></div>"
        }
      },
      {
        "title" : "Angaben zum Patienten",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><i>Erfolgte Voruntersuchungen<br/>Befundkopie – Empfänger</i><br/></div>"
        }
      },
      {
        "title" : "Klinische Angaben",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><i>Beschreibung des aktuellen Leidens<br/>Schwangerschaft ja / nein<br/>Laborwerte (Quick / Tc, Kreatinin)<br/>Bekannte Allergien</i><br/></div>"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/AllzeitBereit",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "AllzeitBereit",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_AllzeitBereit\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner AllzeitBereit</b></p><a name=\"AllzeitBereit\"> </a><a name=\"hcAllzeitBereit\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-practitioner.html\">CH Core Practitioner</a>, <a href=\"StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000201041</p><p><b>name</b>: Allzeit Bereit (Official)</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000201041"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Bereit",
        "given" : ["Allzeit"],
        "prefix" : ["Herr", "Dr. med.", "Allg. Gruppenpraxis AG"],
        "_prefix" : [null,
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "AC"
          }]
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "LS"
          }]
        }],
        "suffix" : ["Facharzt für Allgemeine Medizin"]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/MaxMuster",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "MaxMuster",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "language" : "de-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"Patient_MaxMuster\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient MaxMuster</b></p><a name=\"MaxMuster\"> </a><a name=\"hcMaxMuster\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-patient.html\">CH Core Patient</a>, <a href=\"StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Max Muster (official) Male, DoB: 1938-12-12 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+41326851234\">+41326851234</a></li><li>ph: 079 333 22 11(Mobile)</li><li><a href=\"tel:+41321237788\">+41321237788</a></li><li><a href=\"mailto:max.muster@example.com\">max.muster@example.com</a></li><li><a href=\"http://example.com\">http://example.com</a></li><li>079 333 22 11</li><li>Leidensweg 10 Specimendorf 9999 CH (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>Managing Organization: <a href=\"Organization-GruppenpraxisCH.html\">Organization Gruppenpraxis CH</a></li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "8733"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Muster",
        "_family" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-name",
            "valueCode" : "officialName"
          }]
        },
        "given" : ["Max"],
        "_given" : [{
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-firstname",
            "valueCode" : "officialFirstName"
          }]
        }]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41326851234",
        "use" : "home",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "1",
                "display" : "private Telefonnummer"
              }]
            }
          }]
        }
      },
      {
        "system" : "phone",
        "value" : "079 333 22 11",
        "use" : "mobile",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "2",
                "display" : "private Mobil-Nummer"
              }]
            }
          }]
        }
      },
      {
        "system" : "phone",
        "value" : "+41321237788",
        "use" : "work",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "6",
                "display" : "geschäftliche Nummer (Durchwahl)"
              }]
            }
          }]
        }
      },
      {
        "system" : "email",
        "value" : "max.muster@example.com",
        "use" : "home",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-emailcategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-emailcategory",
                "code" : "1",
                "display" : "private Email-Adresse"
              }]
            }
          }]
        }
      },
      {
        "system" : "url",
        "value" : "http://example.com",
        "use" : "work",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-internetcategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-internetcategory",
                "code" : "2",
                "display" : "geschäftliche Internet-Adresse"
              }]
            }
          }]
        }
      },
      {
        "system" : "sms",
        "value" : "079 333 22 11"
      }],
      "gender" : "male",
      "birthDate" : "1938-12-12",
      "address" : [{
        "use" : "home",
        "line" : ["Leidensweg", "10"],
        "city" : "Specimendorf",
        "postalCode" : "9999",
        "country" : "CH"
      }],
      "managingOrganization" : {
        "reference" : "Organization/GruppenpraxisCH"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/GruppenpraxisCH",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "GruppenpraxisCH",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_GruppenpraxisCH\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization GruppenpraxisCH</b></p><a name=\"GruppenpraxisCH\"> </a><a name=\"hcGruppenpraxisCH\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-organization.html\">CH Core Organization</a>, <a href=\"StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000201041</p><p><b>name</b>: Gruppenpraxis CH</p><p><b>telecom</b>: <a href=\"tel:+41322345566\">+41322345566</a>, fax: +41322346677(Work), <a href=\"mailto:bereit@gruppenpraxis.ch\">bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Doktorgasse 2 Musterhausen 8888 CH (work)</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000201041"
      }],
      "name" : "Gruppenpraxis CH",
      "telecom" : [{
        "system" : "phone",
        "value" : "+41322345566",
        "use" : "work"
      },
      {
        "system" : "fax",
        "value" : "+41322346677",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "use" : "work",
        "line" : ["Doktorgasse", "2"],
        "city" : "Musterhausen",
        "postalCode" : "8888",
        "country" : "CH"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/SchreibKraftAtGruppenpraxisCH",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "SchreibKraftAtGruppenpraxisCH",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitionerrole"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_SchreibKraftAtGruppenpraxisCH\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole SchreibKraftAtGruppenpraxisCH</b></p><a name=\"SchreibKraftAtGruppenpraxisCH\"> </a><a name=\"hcSchreibKraftAtGruppenpraxisCH\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-core-practitionerrole.html\">CH Core PractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-SchreibKraft.html\">Practitioner Schreib Kraft (official)</a></p><p><b>organization</b>: <a href=\"Organization-GruppenpraxisCH.html\">Organization Gruppenpraxis CH</a></p></div>"
      },
      "practitioner" : {
        "reference" : "Practitioner/SchreibKraft"
      },
      "organization" : {
        "reference" : "Organization/GruppenpraxisCH"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/SchreibKraft",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "SchreibKraft",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_SchreibKraft\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner SchreibKraft</b></p><a name=\"SchreibKraft\"> </a><a name=\"hcSchreibKraft\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-core-practitioner.html\">CH Core Practitioner</a></p></div><p><b>identifier</b>: <code>urn:oid:2.999.1.2.3.4</code>/0812763</p><p><b>name</b>: Schreib Kraft (Official)</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "0812763"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Kraft",
        "given" : ["Schreib"]
      }]
    }
  }]
}

```
