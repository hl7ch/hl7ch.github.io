# BFS Extension Medical Statistic: Admit Role for Encounter - CH Core (R4) v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BFS Extension Medical Statistic: Admit Role for Encounter**

## Extension: BFS Extension Medical Statistic: Admit Role for Encounter 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-bfs-ms-admitrole | *Version*:7.0.0-ballot |
| Active as of 2026-06-10 | *Computable Name*:BfsMsAdmitRole |
| **Copyright/Legal**: CC0-1.0 | |

BFS Extension Admit Role for Encounter

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [CH Core Encounter](StructureDefinition-ch-core-encounter.md)
* Examples for this Extension: [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-core|current/StructureDefinition/StructureDefinition-ch-ext-bfs-ms-admitrole.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ch-ext-bfs-ms-admitrole.csv), [Excel](StructureDefinition-ch-ext-bfs-ms-admitrole.xlsx), [Schematron](StructureDefinition-ch-ext-bfs-ms-admitrole.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ch-ext-bfs-ms-admitrole",
  "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-bfs-ms-admitrole",
  "version" : "7.0.0-ballot",
  "name" : "BfsMsAdmitRole",
  "title" : "BFS Extension Medical Statistic: Admit Role for Encounter",
  "status" : "active",
  "date" : "2026-06-10T15:05:01+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "BFS Extension Admit Role for Encounter",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Encounter.hospitalization"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-bfs-ms-admitrole"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Extension.value[x]:valueCoding",
      "path" : "Extension.value[x]",
      "sliceName" : "valueCoding",
      "definition" : "Value of extension - may be a resource or one of a constrained set of the data types (see Extensibility in the spec for list).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "extensible",
        "description" : "A set of codes advising a system or user which name in a set of names to select for a given purpose.",
        "valueSet" : "http://fhir.ch/ig/ch-core/ValueSet/bfs-medstats-19-admitrole"
      }
    }]
  }
}

```
