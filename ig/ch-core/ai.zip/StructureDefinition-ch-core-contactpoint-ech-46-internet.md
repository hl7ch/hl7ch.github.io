# CH Core ContactPoint eCH-0046 Internet - CH Core (R4) v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH Core ContactPoint eCH-0046 Internet**

## Data Type Profile: CH Core ContactPoint eCH-0046 Internet 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-contactpoint-ech-46-internet | *Version*:7.0.0-ballot |
| Active as of 2026-06-10 | *Computable Name*:CHCoreContactPointECH46Internet |
| **Copyright/Legal**: CC0-1.0 | |

 
Internet address as contact point of a person or organization according to eCH-0046 

**Usages:**

* Use this DataType Profile: [CH Core Location](StructureDefinition-ch-core-location.md), [CH Core Organization](StructureDefinition-ch-core-organization.md), [CH Core Patient](StructureDefinition-ch-core-patient.md), [CH Core Practitioner](StructureDefinition-ch-core-practitioner.md) and [CH Core RelatedPerson](StructureDefinition-ch-core-relatedperson.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ch.fhir.ig.ch-core|current/StructureDefinition/StructureDefinition-ch-core-contactpoint-ech-46-internet.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ch-core-contactpoint-ech-46-internet.csv), [Excel](StructureDefinition-ch-core-contactpoint-ech-46-internet.xlsx), [Schematron](StructureDefinition-ch-core-contactpoint-ech-46-internet.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ch-core-contactpoint-ech-46-internet",
  "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-contactpoint-ech-46-internet",
  "version" : "7.0.0-ballot",
  "name" : "CHCoreContactPointECH46Internet",
  "title" : "CH Core ContactPoint eCH-0046 Internet",
  "status" : "active",
  "date" : "2026-06-10T15:05:01+00:00",
  "publisher" : "HL7 Switzerland",
  "contact" : [{
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/"
    }]
  },
  {
    "name" : "HL7 Switzerland",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.ch/",
      "use" : "work"
    }]
  }],
  "description" : "Internet address as contact point of a person or organization according to eCH-0046",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "eCH",
    "uri" : "https://www.ech.ch/",
    "name" : "eCH Standards"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "ContactPoint",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ContactPoint",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ContactPoint",
      "path" : "ContactPoint",
      "short" : "CH Core ContactPoint eCH-0046 Internet",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: internet"
      }]
    },
    {
      "id" : "ContactPoint.system",
      "path" : "ContactPoint.system",
      "min" : 1,
      "fixedCode" : "url",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: internetType"
      }]
    },
    {
      "id" : "ContactPoint.value",
      "path" : "ContactPoint.value",
      "min" : 1,
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: internetAddress"
      }]
    },
    {
      "id" : "ContactPoint.use",
      "path" : "ContactPoint.use",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: internetCategory/otherInternetCategory"
      }]
    },
    {
      "id" : "ContactPoint.use.extension",
      "path" : "ContactPoint.use.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "ContactPoint.use.extension:internetCategory",
      "path" : "ContactPoint.use.extension",
      "sliceName" : "internetCategory",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-internetcategory"]
      }],
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: internetCategory"
      }]
    },
    {
      "id" : "ContactPoint.period",
      "path" : "ContactPoint.period",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: validity"
      }]
    },
    {
      "id" : "ContactPoint.period.start",
      "path" : "ContactPoint.period.start",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: dateFrom"
      }]
    },
    {
      "id" : "ContactPoint.period.end",
      "path" : "ContactPoint.period.end",
      "mapping" : [{
        "identity" : "eCH",
        "map" : "eCH-0046: dateTo"
      }]
    }]
  }
}

```
