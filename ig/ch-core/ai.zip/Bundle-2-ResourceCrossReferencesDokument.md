# Dokument Eintrag referenz zu anderem Eintrag in einem anderen Dokument - CH Core (R4) v7.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Dokument Eintrag referenz zu anderem Eintrag in einem anderen Dokument**

## Example Bundle: Dokument Eintrag referenz zu anderem Eintrag in einem anderen Dokument



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "2-ResourceCrossReferencesDokument",
  "meta" : {
    "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-document"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:66403c99-f41f-4225-bbea-3e34ac1c0d3c"
  },
  "type" : "document",
  "timestamp" : "2023-11-02T12:00:00+01:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/ResourceCrossReferencesDokumentComposition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "ResourceCrossReferencesDokumentComposition",
      "language" : "en-US",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en-US\" lang=\"en-US\"><a name=\"Composition_ResourceCrossReferencesDokumentComposition\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition ResourceCrossReferencesDokumentComposition</b></p><a name=\"ResourceCrossReferencesDokumentComposition\"> </a><a name=\"hcResourceCrossReferencesDokumentComposition\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en-US</p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:e652561f-5df2-418e-8cb4-b4b07fd2ee42</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 41000179103}\">Immunization record</span></p><p><b>date</b>: 2021-06-01 00:00:00+0200</p><p><b>author</b>: <a href=\"Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.html#http-//test.fhir.ch/r4/Practitioner/AllzeitBereit\">Practitioner Allzeit Bereit (official)</a></p><p><b>title</b>: Immunization Administration</p><p><b>confidentiality</b>: normal</p></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:e652561f-5df2-418e-8cb4-b4b07fd2ee42"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "41000179103",
          "display" : "Immunization record"
        }]
      },
      "subject" : {
        "reference" : "http://test.fhir.ch/r4/Patient/MaxMuster"
      },
      "date" : "2021-06-01T00:00:00+02:00",
      "author" : [{
        "reference" : "http://test.fhir.ch/r4/Practitioner/AllzeitBereit"
      }],
      "title" : "Immunization Administration",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "17621005",
              "display" : "Normal (qualifier value)"
            }]
          }
        }]
      },
      "section" : [{
        "id" : "administration",
        "title" : "Immunization Administration",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6",
            "display" : "History of Immunization note"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"en-US\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><p><b>Code: </b><span>History of Immunization note (http://loinc.org#11369-6)</span></p><p><b>Entries:</b></p><table><tr><td><a href=\"Immunization-ImmunizationEntry.html\">Immunization/ImmunizationEntry</a></td></tr></table></div>"
        },
        "entry" : [{
          "reference" : "http://test.fhir.ch/r4/Immunization/ImmunizationEntry"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/AllzeitBereit",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "AllzeitBereit",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-practitioner-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_AllzeitBereit\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner AllzeitBereit</b></p><a name=\"AllzeitBereit\"> </a><a name=\"hcAllzeitBereit\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-practitioner.html\">CH Core Practitioner</a>, <a href=\"StructureDefinition-ch-core-practitioner-epr.html\">CH Core Practitioner EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000201041</p><p><b>name</b>: Allzeit Bereit (Official)</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000201041"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Bereit",
        "given" : ["Allzeit"],
        "prefix" : ["Herr", "Dr. med.", "Allg. Gruppenpraxis AG"],
        "_prefix" : [null,
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "AC"
          }]
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "LS"
          }]
        }],
        "suffix" : ["Facharzt für Allgemeine Medizin"]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/MaxMuster",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "MaxMuster",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-patient-epr"]
      },
      "language" : "de-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"Patient_MaxMuster\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient MaxMuster</b></p><a name=\"MaxMuster\"> </a><a name=\"hcMaxMuster\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-patient.html\">CH Core Patient</a>, <a href=\"StructureDefinition-ch-core-patient-epr.html\">CH Core Patient EPR</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Max Muster (official) Male, DoB: 1938-12-12 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+41326851234\">+41326851234</a></li><li>ph: 079 333 22 11(Mobile)</li><li><a href=\"tel:+41321237788\">+41321237788</a></li><li><a href=\"mailto:max.muster@example.com\">max.muster@example.com</a></li><li><a href=\"http://example.com\">http://example.com</a></li><li>079 333 22 11</li><li>Leidensweg 10 Specimendorf 9999 CH (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>Managing Organization: <a href=\"Organization-GruppenpraxisCH.html\">Organization Gruppenpraxis CH</a></li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "urn:oid:2.999.1.2.3.4",
        "value" : "8733"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Muster",
        "_family" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-name",
            "valueCode" : "officialName"
          }]
        },
        "given" : ["Max"],
        "_given" : [{
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-11-firstname",
            "valueCode" : "officialFirstName"
          }]
        }]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41326851234",
        "use" : "home",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "1",
                "display" : "private Telefonnummer"
              }]
            }
          }]
        }
      },
      {
        "system" : "phone",
        "value" : "079 333 22 11",
        "use" : "mobile",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "2",
                "display" : "private Mobil-Nummer"
              }]
            }
          }]
        }
      },
      {
        "system" : "phone",
        "value" : "+41321237788",
        "use" : "work",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-phonecategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-phonecategory",
                "code" : "6",
                "display" : "geschäftliche Nummer (Durchwahl)"
              }]
            }
          }]
        }
      },
      {
        "system" : "email",
        "value" : "max.muster@example.com",
        "use" : "home",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-emailcategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-emailcategory",
                "code" : "1",
                "display" : "private Email-Adresse"
              }]
            }
          }]
        }
      },
      {
        "system" : "url",
        "value" : "http://example.com",
        "use" : "work",
        "_use" : {
          "extension" : [{
            "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-ech-46-internetcategory",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-46-internetcategory",
                "code" : "2",
                "display" : "geschäftliche Internet-Adresse"
              }]
            }
          }]
        }
      },
      {
        "system" : "sms",
        "value" : "079 333 22 11"
      }],
      "gender" : "male",
      "birthDate" : "1938-12-12",
      "address" : [{
        "use" : "home",
        "line" : ["Leidensweg", "10"],
        "city" : "Specimendorf",
        "postalCode" : "9999",
        "country" : "CH"
      }],
      "managingOrganization" : {
        "reference" : "Organization/GruppenpraxisCH"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Immunization/ImmunizationEntry",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "ImmunizationEntry",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_ImmunizationEntry\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization ImmunizationEntry</b></p><a name=\"ImmunizationEntry\"> </a><a name=\"hcImmunizationEntry\"> </a><blockquote><p><b>Entry Resource Cross References</b></p><ul><li>entry: Identifier: <a href=\"http://terminology.hl7.org/6.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:19aaeae7-05cc-4b97-9d03-a65ae4aac2ac</li><li>container: Identifier: <a href=\"http://terminology.hl7.org/6.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:1d118906-ede6-4109-bca1-0fc25f58bc69</li><li>relationcode: replaces</li></ul></blockquote><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:9f326dee-1265-4b59-88b3-fd63bb2da934</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://snomed.info/sct 871751006}\">Vaccine product containing only Hepatitis A virus antigen (medicinal product)</span></p><p><b>patient</b>: <a href=\"Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.html#http-//test.fhir.ch/r4/Patient/MaxMuster\">Max Muster (official) Male, DoB: 1938-12-12 ( Medical record number)</a></p><p><b>occurrence</b>: 2021-06-01</p><p><b>recorded</b>: 2021-06-02 00:00:00+0200</p><p><b>lotNumber</b>: AHAVB946A</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20035000}\">Intramuscular use</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.html#http-//test.fhir.ch/r4/Practitioner/AllzeitBereit\">Practitioner Allzeit Bereit (official)</a></td></tr></table><p><b>note</b>: By http://test.fhir.ch/r4/Practitioner/AllzeitBereit @2021-06-01</p><blockquote><div><p>Der Patient hat diese Impfung ohne jegliche Nebenwirkungen gut vertragen.</p>\n</div></blockquote><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>TargetDisease</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 40468003}\">Viral hepatitis, type A (disorder)</span></td><td>1</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "entry",
          "valueReference" : {
            "type" : "Immunization",
            "identifier" : {
              "system" : "urn:ietf:rfc:3986",
              "value" : "urn:uuid:19aaeae7-05cc-4b97-9d03-a65ae4aac2ac"
            }
          }
        },
        {
          "url" : "container",
          "valueReference" : {
            "type" : "Composition",
            "identifier" : {
              "system" : "urn:ietf:rfc:3986",
              "value" : "urn:uuid:1d118906-ede6-4109-bca1-0fc25f58bc69"
            }
          }
        },
        {
          "url" : "relationcode",
          "valueCode" : "replaces"
        }],
        "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-ext-entry-resource-cross-references"
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:9f326dee-1265-4b59-88b3-fd63bb2da934"
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "871751006",
          "display" : "Vaccine product containing only Hepatitis A virus antigen (medicinal product)"
        }]
      },
      "patient" : {
        "reference" : "http://test.fhir.ch/r4/Patient/MaxMuster"
      },
      "occurrenceDateTime" : "2021-06-01",
      "recorded" : "2021-06-02T00:00:00.390+02:00",
      "lotNumber" : "AHAVB946A",
      "route" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "20035000",
          "display" : "Intramuscular use"
        }]
      },
      "performer" : [{
        "actor" : {
          "reference" : "http://test.fhir.ch/r4/Practitioner/AllzeitBereit"
        }
      }],
      "note" : [{
        "authorReference" : {
          "reference" : "http://test.fhir.ch/r4/Practitioner/AllzeitBereit"
        },
        "time" : "2021-06-01",
        "text" : "Der Patient hat diese Impfung ohne jegliche Nebenwirkungen gut vertragen."
      }],
      "protocolApplied" : [{
        "targetDisease" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "40468003",
            "display" : "Viral hepatitis, type A (disorder)"
          }]
        }],
        "doseNumberPositiveInt" : 1
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/GruppenpraxisCH",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "GruppenpraxisCH",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization",
        "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization-epr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_GruppenpraxisCH\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization GruppenpraxisCH</b></p><a name=\"GruppenpraxisCH\"> </a><a name=\"hcGruppenpraxisCH\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ch-core-organization.html\">CH Core Organization</a>, <a href=\"StructureDefinition-ch-core-organization-epr.html\">CH Core Organization EPR</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.4.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000201041</p><p><b>name</b>: Gruppenpraxis CH</p><p><b>telecom</b>: <a href=\"tel:+41322345566\">+41322345566</a>, fax: +41322346677(Work), <a href=\"mailto:bereit@gruppenpraxis.ch\">bereit@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Doktorgasse 2 Musterhausen 8888 CH (work)</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000201041"
      }],
      "name" : "Gruppenpraxis CH",
      "telecom" : [{
        "system" : "phone",
        "value" : "+41322345566",
        "use" : "work"
      },
      {
        "system" : "fax",
        "value" : "+41322346677",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "bereit@gruppenpraxis.ch",
        "use" : "work"
      },
      {
        "system" : "url",
        "value" : "http://www.gruppenpraxis.ch",
        "use" : "work"
      }],
      "address" : [{
        "use" : "work",
        "line" : ["Doktorgasse", "2"],
        "city" : "Musterhausen",
        "postalCode" : "8888",
        "country" : "CH"
      }]
    }
  }]
}

```
