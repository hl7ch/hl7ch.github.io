# Home - CH Core (R4) v6.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-core/ImplementationGuide/ch.fhir.ig.ch-core | *Version*:6.0.0 |
| Active as of 2025-12-16 | *Computable Name*:CH_Core |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

This implementation guide is provided to support the use of FHIR®© in Switzerland.

This guide is a working specification. We anticipate that it will be implemented and tested by FHIR system producers whose feedback will help improve its content. With this standard for trial use, we are looking for feedback on whether the following goals have been met:

* The guide provides guidance on essential resources for identifiers, code systems, value sets and naming systems in Switzerland, specifically in relation to the Swiss Electronic Patient Record ([EPR](https://www.patientendossier.ch/en)).
* The guide defines extensions that are necessary for local use in Switzerland.
* The guide covers the requirements for [eCH-0010 postal address (V7.0)](https://www.ech.ch/de/ech/ech-0010/7.0), [eCH-0046 contact (V5.0)](https://www.ech.ch/de/ech/ech-0046/5.0) and [eCH-0011 personal data (V8.1)](https://www.ech.ch/de/ech/ech-0011/8.1) (including [eCH-0007 municipality (V6.0)](https://www.ech.ch/de/ech/ech-0007/6.0) and [eCH-0021 additional personal data (V7.0)](https://www.ech.ch/de/ech/ech-0021/7.0)).
* The guide incorporates Federal Statistics Office (BFS) variables for medical statistics. See [BFS](https://www.bfs.admin.ch/bfs/de/home/statistiken/kataloge-datenbanken/publikationen.assetdetail.7066232.html) (available in German, French and Italian).
* The guide does not define additions to the FHIR API, for further FHIR API definitions please refer to: 
* [CH EPR FHIR](http://fhir.ch/ig/ch-epr-fhir/) - Swiss EPR FHIR Implementation Guide
* [IPA (International Patient Access)](https://hl7.org/fhir/uv/ipa/) - International FHIR API specification for patient access
* or other FHIR Implementation Guides
 

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in [NPM format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](package.tgz).

### Relation to the Swiss EPR

The Annexes to the Swiss [Electronic Patient Record](https://www.patientendossier.ch/en) (EPR) law specify the technical and semantic requirements for interoperability.

#### Metadata (Annex 3 and Annex 9)

Metadata relating to the Swiss EPR is defined in Annexes 3 and 9 by the [Ministry of Health](https://www.bag.admin.ch/bag/de/home/gesetze-und-bewilligungen/gesetzgebung/gesetzgebung-mensch-gesundheit/gesetzgebung-elektronisches-patientendossier.html). [eHealth Suisse](https://www.e-health-suisse.ch/en/home.html) maintains the value sets with additional provided translations in ART-DECOR in the [CH-EPR](https://art-decor.org/art-decor/decor-project--ch-epr-) project. All code systems and value sets from the CH-EPR project are exported to the FHIR implementation guide [CH Term](http://fhir.ch/ig/ch-term/index.html), which forms the basis for CH Core.

#### Exchange formats (Annex 4)

Exchange formats for the Swiss EPR are defined in Annex 4. Exchange formats can be represented as FHIR documents.

* [CH Core Document Profile EPR](StructureDefinition-ch-core-document.md): the base definition for a structured document in the Swiss EPR.
* [CH Core Composition Profile EPR](StructureDefinition-ch-core-composition-epr.md): the base definition for a composition, providing the basic structure of the FHIR document.

#### CH:ATC Profile (Annex 5, Amendment 2.2)

The CH ATC profile defines the requirements for a patient’s audit trail. It is defined in the [CH EPR FHIR](https://fhir.ch/ig/ch-epr-fhir/ch-atc.html) implementation guide.

### Scope

This document presents Swiss use concepts defined via FHIR processable artifacts:

* [Profiles](profiles.md) - useful constraints of essential FHIR resources and data types for Swiss use.
* [Extensions](extensions.md) - FHIR extensions that are added for local use, covering necessary Swiss concepts.
* [Terminology](https://fhir.ch/ig/ch-term/index.html) - defined or referenced code systems and value sets for Switzerland.

See also the **guidance** section with detailed descriptions about some special topics:

* [Usage of Swiss Core Artifacts](usage-swiss-core-artifacts.md)
* [SNOMED CT Swiss Extension](sct-swiss-ext.md)
* [Readable Representation of EPR Documents](readable-representation-epr-docs.md)

### Governance

The CH Core implementation guide is managed by HL7 Switzerland in the [HL7 Switzerland FHIR technical committee](https://www.hl7.ch/technisches-komitee/), see also [source](https://github.com/hl7ch/ch-core).

### Collaboration

This guide is the product of collaborative work undertaken with participants from:

* [Swiss FHIR Implementers Community](https://www.fhir.ch)
* [HL7 Switzerland](https://www.hl7.ch)
* [eHealth Suisse](https://www.e-health-suisse.ch/en/home.html)

### Safety Considerations

This implementation guide defines data elements, resources, formats, and methods for exchanging healthcare data between different participants in the healthcare process. As such, clinical safety is a key concern. Additional guidance regarding safety for the specification’s many and various implementations is available at: [https://www.hl7.org/FHIR/safety.html](https://www.hl7.org/FHIR/safety.html).

Although the present specification does gives users the opportunity to observe data protection and data security regulations, its use does not guarantee compliance with these regulations. Effective compliance must be ensured by appropriate measures during implementation projects and in daily operations. The corresponding implementation measures are explained in the standard. In addition, the present specification can only influence compliance with the security regulations in the technical area of standardization. It cannot influence organizational and contractual matters.

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [BFS Medizinische Statistik - 17 1.2.V02 - Aufenthaltsort vor dem Eintritt / Séjour avant l’admission / Luogo di soggiorno prima dell’ammissione](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-17-admitsource.html): [CHCoreEncounter](StructureDefinition-ch-core-encounter.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [BFS Medizinische Statistik - 18 1.2.V03 - Eintrittsart / Mode d’admission / Genere di ricovero](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-18-admittype.html): [CHCoreEncounter](StructureDefinition-ch-core-encounter.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [BFS Medizinische Statistik - 19 1.2.V04 - Einweisende Instanz / Décision d’envoi / Istanza ricoverante](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-19-admitrole.html): [BfsMsAdmitRole](StructureDefinition-ch-ext-bfs-ms-admitrole.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [BFS Medizinische Statistik - 20 1.3.V01 - Behandlungsart / Type de prise en charge / Genere di trattamento](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-20-encounterclass.html): [CHCoreClaim](StructureDefinition-ch-core-claim.md) and [Claim/ClaimInpatientTreatmentPsychiatry](Claim-ClaimInpatientTreatmentPsychiatry.md)
* [BFS Medizinische Statistik - 25 1.4.V02 - Hauptkostenträger für Grundversicherungsleistungen / Prise en charge des soins de base / Unità d’imputazione principale per le prestazioni dell’assicurazione di base](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-25-mainguarantor.html): [CHCoreCoverage](StructureDefinition-ch-core-coverage.md)
* [BFS Medizinische Statistik - 27 1.5.V02 - Entscheid für Austritt / Décision de sortie / Décisione dell’uscita](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-27-dischargedecision.html): [BfsDischargeDecision](StructureDefinition-ch-ext-bfs-ms-dischargedecision.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [BFS Medizinische Statistik - 28 1.5.V03 - Aufenthalt nach Austritt / Séjour après la sortie / Destinazione dopo l’uscita](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-28-dischargedestination.html): [BfsDischargeDestination](StructureDefinition-ch-ext-bfs-ms-dischargedestination.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [BFS Medizinische Statistik - 29 1.5.V04 - Behandlung nach Austritt / Prise en charge après la sortie / Trattamento dopo l’uscita](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-bfs-medstats-29-dischargeencounter.html): [CHCoreEncounter](StructureDefinition-ch-core-encounter.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [eCH-010 Types](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-10.html): [ECH0010AddressLineType](StructureDefinition-ch-ext-ech-10-linetype.md)
* [eCH-011 Types](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11.html): [CHCorePatient](StructureDefinition-ch-core-patient.md), [CHCorePatientEPR](StructureDefinition-ch-core-patient-epr.md), [ECH011FirstName](StructureDefinition-ch-ext-ech-11-firstname.md), [ECH011Name](StructureDefinition-ch-ext-ech-11-name.md) and [Patient/PersonEch011](Patient-PersonEch011.md)
* [eCH-011 MaritalData Separation](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11-maritaldata-separation.html): [ECH011MaritalDataSeparation](StructureDefinition-ch-ext-ech-11-maritaldata-separation.md) and [Patient/PersonEch011](Patient-PersonEch011.md)
* [eCH-011 MaritalStatus](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-11-maritalstatus.html): [CHCorePatient](StructureDefinition-ch-core-patient.md), [Patient/ElisabethBroennimannByBFH](Patient-ElisabethBroennimannByBFH.md)...Show 4 more,[Patient/FranzMuster](Patient-FranzMuster.md),[Patient/ManuelaMuster](Patient-ManuelaMuster.md),[Patient/MarvinMuster](Patient-MarvinMuster.md)and[Patient/PersonEch011](Patient-PersonEch011.md)
* [eCH-0046 Email Category](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-46-emailcategory.html): [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md), [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md), [ECH46EmailCategory](StructureDefinition-ch-ext-ech-46-emailcategory.md) and [Patient/MaxMuster](Patient-MaxMuster.md)
* [eCH-0046 Internet Category](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-46-internetcategory.html): [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md), [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md), [ECH46InternetCategory](StructureDefinition-ch-ext-ech-46-internetcategory.md) and [Patient/MaxMuster](Patient-MaxMuster.md)
* [eCH-0046 Phone Category](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-46-phonecategory.html): [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md), [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md), [ECH46PhoneCategory](StructureDefinition-ch-ext-ech-46-phonecategory.md) and [Patient/MaxMuster](Patient-MaxMuster.md)
* [eCH-0007 Canton Abbreviation incl. FL (Fürstentum Liechtenstein)](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ech-7-cantonflabbreviation.html): [CHCoreAddress](StructureDefinition-ch-core-address.md)
* [Main guarantor](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-mainguarantor.html): [CHCoreCoverage](StructureDefinition-ch-core-coverage.md)
* [ServiceRequest Category](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-servicerequest-category.html): [CHCoreServiceRequest](StructureDefinition-ch-core-servicerequest.md) and [ServiceRequest/LabOrder](ServiceRequest-LabOrder.md)
* [CH VACD Swiss Immunization Recommendation Categories](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ch-vacd-recommendation-categories-cs.html): [CHCoreImmunizationRecommendation](StructureDefinition-ch-core-immunization-recommendation.md) and [ImmunizationRecommendation/CHCoreImmunizationRecommendationExample](ImmunizationRecommendation-CHCoreImmunizationRecommendationExample.md)
* [CH VACD Swiss Recommendation Forecast Status](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ch-vacd-recommendation-forecast-status-cs.html): [CHCoreImmunizationRecommendation](StructureDefinition-ch-core-immunization-recommendation.md)
* [CH VACD Swissmedic Authorized Vaccines](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-ch-vacd-swissmedic-cs.html): [Immunization/CHCoreImmunizationExample](Immunization-CHCoreImmunizationExample.md) and [ImmunizationRecommendation/CHCoreImmunizationRecommendationExample](ImmunizationRecommendation-CHCoreImmunizationRecommendationExample.md)
* [EDQM - Standard Terms](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-edqm-standardterms.html): [CHCoreDosage](StructureDefinition-ch-core-dosage.md), [CHCoreMedication](StructureDefinition-ch-core-medication.md)...Show 5 more,[CHCoreMedicationAdministration](StructureDefinition-ch-core-medicationadministration.md),[MedicationAdministration/3-2-MedAdminFentanyl](MedicationAdministration-3-2-MedAdminFentanyl.md),[MedicationDispense/2-4-MedDispBeloczok](MedicationDispense-2-4-MedDispBeloczok.md),[MedicationRequest/2-6-MedReqNorvasc](MedicationRequest-2-6-MedReqNorvasc.md)and[MedicationStatement/1-1-MedStatTriatec](MedicationStatement-1-1-MedStatTriatec.md)
* [DICOM Unique Identifiers (UIDs)](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-dcmuid.html): [CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md)
* [ch-ehealth-codesystem-language](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.10.12.html): [CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md)
* [ch-ehealth-codesystem-medreg](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.5.html): [CHCorePractitionerRole](StructureDefinition-ch-core-practitionerrole.md), [CHCorePractitionerRoleEpr](StructureDefinition-ch-core-practitionerrole-epr.md) and [PractitionerRole/HPWengerRole](PractitionerRole-HPWengerRole.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [AHVN13Identifier](StructureDefinition-ch-core-ahvn13-identifier.md), [Accident](StructureDefinition-ch-ext-accident.md)...Show 76 more,[Author](StructureDefinition-ch-ext-author.md),[BERIdentifier](StructureDefinition-ch-core-ber-identifier.md),[BfsDischargeDecision](StructureDefinition-ch-ext-bfs-ms-dischargedecision.md),[BfsDischargeDestination](StructureDefinition-ch-ext-bfs-ms-dischargedestination.md),[BfsMsAdmitRole](StructureDefinition-ch-ext-bfs-ms-admitrole.md),[Biller](StructureDefinition-ch-ext-biller.md),[CHCoreAddress](StructureDefinition-ch-core-address.md),[CHCoreAddressECH10](StructureDefinition-ch-core-address-ech-10.md),[CHCoreAddressECH11PlaceOfOrigin](StructureDefinition-ch-core-address-ech-11-placeoforigin.md),[CHCoreAddressEch11PlaceOfBirth](StructureDefinition-ch-core-address-ech-11-placeofbirth.md),[CHCoreAllergyIntolerance](StructureDefinition-ch-core-allergyintolerance.md),[CHCoreClaim](StructureDefinition-ch-core-claim.md),[CHCoreComposition](StructureDefinition-ch-core-composition.md),[CHCoreCompositionEPR](StructureDefinition-ch-core-composition-epr.md),[CHCoreCondition](StructureDefinition-ch-core-condition.md),[CHCoreContactPointECH46Email](StructureDefinition-ch-core-contactpoint-ech-46-email.md),[CHCoreContactPointECH46Internet](StructureDefinition-ch-core-contactpoint-ech-46-internet.md),[CHCoreContactPointECH46Phone](StructureDefinition-ch-core-contactpoint-ech-46-phone.md),[CHCoreCoverage](StructureDefinition-ch-core-coverage.md),[CHCoreDocument](StructureDefinition-ch-core-document.md),[CHCoreDocumentEPR](StructureDefinition-ch-core-document-epr.md),[CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md),[CHCoreDosage](StructureDefinition-ch-core-dosage.md),[CHCoreEPRConsent](StructureDefinition-ch-core-epr-consent.md),[CHCoreEncounter](StructureDefinition-ch-core-encounter.md),[CHCoreHumanName](StructureDefinition-ch-core-humanname.md),[CHCoreImmunization](StructureDefinition-ch-core-immunization.md),[CHCoreImmunizationRecommendation](StructureDefinition-ch-core-immunization-recommendation.md),[CHCoreLocation](StructureDefinition-ch-core-location.md),[CHCoreMedication](StructureDefinition-ch-core-medication.md),[CHCoreMedicationAdministration](StructureDefinition-ch-core-medicationadministration.md),[CHCoreMedicationDispense](StructureDefinition-ch-core-medicationdispense.md),[CHCoreMedicationRequest](StructureDefinition-ch-core-medicationrequest.md),[CHCoreMedicationStatement](StructureDefinition-ch-core-medicationstatement.md),[CHCoreOrganization](StructureDefinition-ch-core-organization.md),[CHCoreOrganizationEPR](StructureDefinition-ch-core-organization-epr.md),[CHCorePatient](StructureDefinition-ch-core-patient.md),[CHCorePatientEPR](StructureDefinition-ch-core-patient-epr.md),[CHCorePractitioner](StructureDefinition-ch-core-practitioner.md),[CHCorePractitionerEPR](StructureDefinition-ch-core-practitioner-epr.md),[CHCorePractitionerRole](StructureDefinition-ch-core-practitionerrole.md),[CHCorePractitionerRoleEpr](StructureDefinition-ch-core-practitionerrole-epr.md),[CHCoreQuantityWithEmedUnits](StructureDefinition-ch-core-quantity-with-emed-units.md),[CHCoreRangeWithEmedUnits](StructureDefinition-ch-core-range-with-emed-units.md),[CHCoreRatioWithEmedUnits](StructureDefinition-ch-emed-ratio-with-emed-units.md),[CHCoreRelatedPerson](StructureDefinition-ch-core-relatedperson.md),[CHCoreServiceRequest](StructureDefinition-ch-core-servicerequest.md),[CHEMEDExtSubstitution](StructureDefinition-ch-emed-ext-substitution.md),[CHEMEDExtTreatmentReason](StructureDefinition-ch-emed-ext-treatmentreason.md),[CH_Core](index.md),[ChCorePatientEch11PlaceOfBirth](StructureDefinition-ch-core-patient-ech-11-placeofbirth.md),[ChCorePatientEch11PlaceOfOrigin](StructureDefinition-ch-core-patient-ech-11-placeoforigin.md),[ECH0010AddressLineType](StructureDefinition-ch-ext-ech-10-linetype.md),[ECH007MunicipalityId](StructureDefinition-ch-ext-ech-7-municipalityid.md),[ECH011FirstName](StructureDefinition-ch-ext-ech-11-firstname.md),[ECH011MaritalDataSeparation](StructureDefinition-ch-ext-ech-11-maritaldata-separation.md),[ECH011Name](StructureDefinition-ch-ext-ech-11-name.md),[ECH46EmailCategory](StructureDefinition-ch-ext-ech-46-emailcategory.md),[ECH46InternetCategory](StructureDefinition-ch-ext-ech-46-internetcategory.md),[ECH46PhoneCategory](StructureDefinition-ch-ext-ech-46-phonecategory.md),[EPRConfidentialityCode](StructureDefinition-ch-ext-epr-confidentialitycode.md),[EPRDataEnterer](StructureDefinition-ch-ext-epr-dataenterer.md),[EPRInformationRecipient](StructureDefinition-ch-ext-epr-informationrecipient.md),[EPRSPIDIdentifier](StructureDefinition-ch-core-epr-spid-identifier.md),[EPRTime](StructureDefinition-ch-ext-epr-time.md),[EncounterSupsectedReadmission](StructureDefinition-ch-ext-encounter-susp-readmission.md),[EntryResourceCrossReferences](StructureDefinition-ch-core-ext-entry-resource-cross-references.md),[GLNIdentifier](StructureDefinition-ch-core-gln-identifier.md),[Patient/ElisabethBroennimannByBFH](Patient-ElisabethBroennimannByBFH.md),[Patient/PersonEch011](Patient-PersonEch011.md),[Patient/UpiEprTestKrcmarevic](Patient-UpiEprTestKrcmarevic.md),[RelatedPerson/BiologicalFather](RelatedPerson-BiologicalFather.md),[Responsible](StructureDefinition-ch-ext-responsible.md),[UIDBIdentifier](StructureDefinition-ch-core-uidb-identifier.md),[VEKAIdentifier](StructureDefinition-ch-core-veka-identifier.md)and[ZSRIdentifier](StructureDefinition-ch-core-zsr-identifier.md)


* Some content from IHE® Copyright © 2015 [IHE International, Inc](http://www.ihe.net/Governance/#Intellectual_Property) .

* [IHE Format Code set for use with Document Sharing](https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.4.0/CodeSystem-formatcode.html): [CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md) and [DocumentReference/Docu](DocumentReference-Docu.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [CHCoreQuantityWithEmedUnits](StructureDefinition-ch-core-quantity-with-emed-units.md), [MedicationAdministration/3-2-MedAdminFentanyl](MedicationAdministration-3-2-MedAdminFentanyl.md), [MedicationDispense/2-4-MedDispBeloczok](MedicationDispense-2-4-MedDispBeloczok.md), [MedicationRequest/2-6-MedReqNorvasc](MedicationRequest-2-6-MedReqNorvasc.md) and [MedicationStatement/1-1-MedStatTriatec](MedicationStatement-1-1-MedStatTriatec.md)


* This artefact includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license - for more information contact [http://www.snomed.org/snomed-ct/getsnomed-ct](http://www.snomed.org/snomed-ct/getsnomed-ct) or info@snomed.org.

* [ch-ehealth-codesystem-format](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.10.10.html): [CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md)
* [ch-ehealth-codesystem-hpd](http://fhir.ch/ig/ch-term/3.3.0/CodeSystem-2.16.756.5.30.1.127.3.10.9.html): [CHCorePractitionerRole](StructureDefinition-ch-core-practitionerrole.md) and [CHCorePractitionerRoleEpr](StructureDefinition-ch-core-practitionerrole-epr.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md), [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md)...Show 6 more,[Bundle/DocumentContainingOriginalRepresentationAsPdfA](Bundle-DocumentContainingOriginalRepresentationAsPdfA.md),[CHCoreCompositionEPR](StructureDefinition-ch-core-composition-epr.md),[Composition/ResourceCrossReferencesDokumentComposition](Composition-ResourceCrossReferencesDokumentComposition.md),[Composition/ZuweisungZurRadiologischenDiagnostik](Composition-ZuweisungZurRadiologischenDiagnostik.md),[ImmunizationRecommendation/CHCoreImmunizationRecommendationExample](ImmunizationRecommendation-CHCoreImmunizationRecommendationExample.md)and[ServiceRequest/LabOrder](ServiceRequest-LabOrder.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/AllergyToCatDander](AllergyIntolerance-AllergyToCatDander.md), [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md)...Show 32 more,[Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md),[Bundle/DocumentContainingOriginalRepresentationAsPdfA](Bundle-DocumentContainingOriginalRepresentationAsPdfA.md),[CHCoreAllergyIntolerance](StructureDefinition-ch-core-allergyintolerance.md),[CHCoreClaim](StructureDefinition-ch-core-claim.md),[CHCoreCompositionEPR](StructureDefinition-ch-core-composition-epr.md),[CHCoreCondition](StructureDefinition-ch-core-condition.md),[CHCoreDocumentReference](StructureDefinition-ch-core-documentreference.md),[CHCoreImmunization](StructureDefinition-ch-core-immunization.md),[CHCoreImmunizationRecommendation](StructureDefinition-ch-core-immunization-recommendation.md),[CHCoreMedication](StructureDefinition-ch-core-medication.md),[CHCoreOrganization](StructureDefinition-ch-core-organization.md),[CHCoreOrganizationEPR](StructureDefinition-ch-core-organization-epr.md),[CHCorePractitionerRole](StructureDefinition-ch-core-practitionerrole.md),[CHCorePractitionerRoleEpr](StructureDefinition-ch-core-practitionerrole-epr.md),[CHCoreQuantityWithEmedUnits](StructureDefinition-ch-core-quantity-with-emed-units.md),[Claim/ClaimInpatientTreatmentPsychiatry](Claim-ClaimInpatientTreatmentPsychiatry.md),[Composition/ResourceCrossReferencesDokumentComposition](Composition-ResourceCrossReferencesDokumentComposition.md),[Composition/ZuweisungZurRadiologischenDiagnostik](Composition-ZuweisungZurRadiologischenDiagnostik.md),[Condition/Urticaria](Condition-Urticaria.md),[DocumentReference/Docu](DocumentReference-Docu.md),[EPRConfidentialityCode](StructureDefinition-ch-ext-epr-confidentialitycode.md),[Immunization/CHCoreImmunizationExample](Immunization-CHCoreImmunizationExample.md),[Immunization/ImmunizationEntry](Immunization-ImmunizationEntry.md),[ImmunizationRecommendation/CHCoreImmunizationRecommendationExample](ImmunizationRecommendation-CHCoreImmunizationRecommendationExample.md),[MedicationAdministration/3-2-MedAdminFentanyl](MedicationAdministration-3-2-MedAdminFentanyl.md),[MedicationDispense/2-4-MedDispBeloczok](MedicationDispense-2-4-MedDispBeloczok.md),[MedicationRequest/2-6-MedReqNorvasc](MedicationRequest-2-6-MedReqNorvasc.md),[MedicationStatement/1-1-MedStatTriatec](MedicationStatement-1-1-MedStatTriatec.md),[PractitionerRole/HPWengerRole](PractitionerRole-HPWengerRole.md),[RelatedPerson/BiologicalFather](RelatedPerson-BiologicalFather.md),[RoDiag Radiologieinstitut](Organization-Radiologieinstitut.md)and[Spital Seeblick](Organization-SpitalSeeblick.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/AllergyToCatDander](AllergyIntolerance-AllergyToCatDander.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-verification.html): [AllergyIntolerance/AllergyToCatDander](AllergyIntolerance-AllergyToCatDander.md)
* [Claim Information Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-claiminformationcategory.html): [CHCoreClaim](StructureDefinition-ch-core-claim.md) and [Claim/ClaimInpatientTreatmentPsychiatry](Claim-ClaimInpatientTreatmentPsychiatry.md)
* [Condition Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-category.html): [CHCoreCondition](StructureDefinition-ch-core-condition.md) and [Condition/Urticaria](Condition-Urticaria.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-clinical.html): [Condition/Urticaria](Condition-Urticaria.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.0.1/CodeSystem-condition-ver-status.html): [Condition/Urticaria](Condition-Urticaria.md)
* [Consent PolicyRule Codes](http://terminology.hl7.org/7.0.1/CodeSystem-consentpolicycodes.html): [CHCoreEPRConsent](StructureDefinition-ch-core-epr-consent.md), [Consent/EncounterExcludedForEpr](Consent-EncounterExcludedForEpr.md) and [Consent/PatientHasEpr](Consent-PatientHasEpr.md)
* [Consent Scope Codes](http://terminology.hl7.org/7.0.1/CodeSystem-consentscope.html): [CHCoreEPRConsent](StructureDefinition-ch-core-epr-consent.md), [Consent/EncounterExcludedForEpr](Consent-EncounterExcludedForEpr.md) and [Consent/PatientHasEpr](Consent-PatientHasEpr.md)
* [Immunization Recommendation Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-immunization-recommendation-status.html): [ImmunizationRecommendation/CHCoreImmunizationRecommendationExample](ImmunizationRecommendation-CHCoreImmunizationRecommendationExample.md)
* [Process Priority Codes](http://terminology.hl7.org/7.0.1/CodeSystem-processpriority.html): [Claim/ClaimInpatientTreatmentPsychiatry](Claim-ClaimInpatientTreatmentPsychiatry.md)
* [AllergyIntoleranceCertainty](http://terminology.hl7.org/7.0.1/CodeSystem-reaction-event-certainty.html): [AllergyIntolerance/AllergyToCatDander](AllergyIntolerance-AllergyToCatDander.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/1-ZuweisungZurRadiologischenDiagnostik-FHIR](Bundle-1-ZuweisungZurRadiologischenDiagnostik-FHIR.md), [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md)...Show 9 more,[Bundle/DocumentContainingOriginalRepresentationAsPdfA](Bundle-DocumentContainingOriginalRepresentationAsPdfA.md),[CHCoreEncounter](StructureDefinition-ch-core-encounter.md),[CHCorePatient](StructureDefinition-ch-core-patient.md),[CHCorePatientEPR](StructureDefinition-ch-core-patient-epr.md),[Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md),[Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md),[Patient/FranzMuster](Patient-FranzMuster.md),[Patient/ImmunizationPatientExample](Patient-ImmunizationPatientExample.md)and[Patient/MaxMuster](Patient-MaxMuster.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [Consent/EncounterExcludedForEpr](Consent-EncounterExcludedForEpr.md), [Consent/PatientHasEpr](Consent-PatientHasEpr.md), [Encounter/EncounterAccidentBroennimann](Encounter-EncounterAccidentBroennimann.md) and [Encounter/EncounterAmbulantBroennimann](Encounter-EncounterAmbulantBroennimann.md)
* [MaritalStatus](http://terminology.hl7.org/7.0.1/CodeSystem-v3-MaritalStatus.html): [Patient/ElisabethBroennimannByBFH](Patient-ElisabethBroennimannByBFH.md) and [Patient/PersonEch011](Patient-PersonEch011.md)
* [ParticipationFunction](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ParticipationFunction.html): [CHCoreEncounter](StructureDefinition-ch-core-encounter.md)
* [Religious Affiliation](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ReligiousAffiliation.html): [Patient/FranzMuster](Patient-FranzMuster.md), [Patient/ManuelaMuster](Patient-ManuelaMuster.md) and [Patient/MarvinMuster](Patient-MarvinMuster.md)
* [RoleCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-RoleCode.html): [CHCorePatient](StructureDefinition-ch-core-patient.md), [CHCorePatientEPR](StructureDefinition-ch-core-patient-epr.md) and [Patient/UpiEprTestKrcmarevic](Patient-UpiEprTestKrcmarevic.md)
* [Substance Admin Substitution](http://terminology.hl7.org/7.0.1/CodeSystem-v3-substanceAdminSubstitution.html): [CHCoreMedicationDispense](StructureDefinition-ch-core-medicationdispense.md), [CHCoreMedicationRequest](StructureDefinition-ch-core-medicationrequest.md), [CHEMEDExtSubstitution](StructureDefinition-ch-emed-ext-substitution.md), [MedicationDispense/2-4-MedDispBeloczok](MedicationDispense-2-4-MedDispBeloczok.md) and [MedicationRequest/2-6-MedReqNorvasc](MedicationRequest-2-6-MedReqNorvasc.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r4/ValueSet/edqm): [Bundle/2-ResourceCrossReferencesDokument](Bundle-2-ResourceCrossReferencesDokument.md), [CHCoreImmunization](StructureDefinition-ch-core-immunization.md), [Immunization/CHCoreImmunizationExample](Immunization-CHCoreImmunizationExample.md) and [Immunization/ImmunizationEntry](Immunization-ImmunizationEntry.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-core.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-core.r4b)](package.r4b.tgz) are available.

### Dependency Table






### Globals Table

*There are no Global profiles defined*

