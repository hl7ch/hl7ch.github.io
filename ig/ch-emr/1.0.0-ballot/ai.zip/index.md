# Home - CH EMR (R4) v1.0.0-ballot

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-emr/ImplementationGuide/ch.fhir.ig.ch-emr | *Version*:1.0.0-ballot |
| Active as of 2026-06-12 | *Computable Name*:CH_EMR |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

The **emergency record** contains all the important medical information needed in situations in which quick access or a quick overview of medical data is required. For example, in cases of unconsciousness, language barriers or limited health literacy. 
 The emergency record combines key administrative and clinical data such as patient details, emergency contacts, medication, allergies, vaccinations, implants, diagnose, CPR status and references to living wills and other relevant documents.

The CH EMR implementation guide describes the FHIR representation of the electronic emergency record in Switzerland. It is dependent on [CH Core](http://fhir.ch/ig/ch-core/index.html) and [CH Term](http://fhir.ch/ig/ch-term/index.html), which describe the Swiss-specific context, particularly in relation to the Swiss Electronic Patient Record (EPR). 
 This implementation guide is based on the concept for the exchange format of the electronic emergency record ([de](https://www.e-health-suisse.ch/upload/documents/Konzept_eNotfallpass_DE.pdf), [fr](https://www.e-health-suisse.ch/upload/documents/Konzept_Notfallpass_FR.pdf)).

### Dependencies Overview

The CH EMR (Emergency Record) implementation guide builds upon several Swiss FHIR specifications. The following diagram illustrates the relationships between these implementation guides:

**Fig. 1: Schematic representation of the dependency mechanism of the implementation guides**

The **CH EMR** is primarily derived from the [CH IPS (International Patient Summary)](https://fhir.ch/ig/ch-ips/index.html), which provides the foundational clinical profiles for patient summaries in Switzerland. CH IPS itself is based on the international [IPS UV](https://hl7.org/fhir/uv/ips/) specification by HL7, ensuring cross-border interoperability.

Both CH EMR and CH IPS depend on [CH Core](https://fhir.ch/ig/ch-core/index.html), which defines the Swiss-specific base profiles (e.g. patient, practitioner, organization) including Swiss identifiers such as AHV, GLN and EPR-SPID. [CH Term](https://fhir.ch/ig/ch-term/index.html) provides the shared Swiss terminologies, value sets and code systems used across all Swiss FHIR implementation guides.

For the medication content, CH EMR additionally depends on [CH EMED](https://fhir.ch/ig/ch-emed/index.html), the Swiss eMedikation specification. CH EMR's Medication Statement reuses the CH EMED dosage profiles (`ch-emed-dosage` and `ch-emed-dosage-split`) so that dosing schedules in the Emergency Record follow the same structure as the rest of the Swiss eMedikation ecosystem.

Where CH IPS profiles were available and applicable, CH EMR profiles inherit from them (e.g. Patient, Medication, AllergyIntolerance, Condition, Immunization). For emergency-specific content not covered by IPS, such as resuscitation status, emergency contacts, risk factors and disabilities, CH EMR defines its own profiles based on CH Core or FHIR base resources.

This implementation guide is under STU ballot by [HL7 Switzerland](https://www.hl7.ch/de/) from August 4th, 2026 until end of 2026. 
 Please add your feedback via the ‘Propose a change’-link in the footer on the page where you have comments.

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in the [npm package format](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) from [here](package.tgz).

### Objective

The emergency report is designed to give medical professionals quick and structured access to a patient's most important medical information in emergency situations. However, this medical information can also be used in unforeseen patient contacts where, for example, language barriers exist or health literacy is limited.

### Content scope

#### Core units

* **Patient information**: Demographic data and contact information
* **Emergency contacts**: Family and trusted persons
* **Care Team**: Treating Health care professional
* **Resuscitation status**: Patient's wishes regarding resuscitation measures in emergency situations
* **Current medication**: Information and dosage of medications
* **Vaccinations**: Current vaccinations
* **Allergies and intolerances**: Known allergic reactions and intolerances
* **Risk factors**: Risks relevant to treatment
* **Problem list**: Diagnoses and problems
* **Advance directive**: Information on advance directives or medical directives
* **Other documents**: Other documents like organ donor cards
* **Implants**: Medical devices
* **Pregnancy**: Current pregnancy information
* **Disability**: Information about disabilities

#### Profiles

The Implementation Guide defines the following main profiles:

| | | |
| :--- | :--- | :--- |
| [CH Emergency Record Bundle](StructureDefinition-ch-emr-bundle.md) | Bundle profile for Emergency Record. | [CH IPS Document](http://fhir.ch/ig/ch-ips/StructureDefinition-ch-ips-document.html) |
| [CH Emergency Record Composition](StructureDefinition-ch-emr-composition.md) | Swiss Emergency Record based on International Patient Summary. | [CH IPS Composition](http://fhir.ch/ig/ch-ips/StructureDefinition-ch-ips-composition.html) |
| [CH Emergency Record Device Use Statement](StructureDefinition-ch-emr-deviceusestatement.md) | Use of an implanted device in the Emergency Record. | [IPS DeviceUseStatement](http://hl7.org/fhir/uv/ips/StructureDefinition-DeviceUseStatement-uv-ips.html) |
| [CH Emergency Record Device](StructureDefinition-ch-emr-device.md) | Device profile for implants in the Emergency Record. | [IPS Device](http://hl7.org/fhir/uv/ips/StructureDefinition-Device-uv-ips.html) |
| [CH Emergency Record Body Structure](StructureDefinition-ch-emr-bodystructure.md) | Structured anatomical location of an implant, carrying an unlateralised body site and the laterality qualifier. | [BodyStructure (FHIR R4)](http://hl7.org/fhir/R4/bodystructure.html) |
| [CH Emergency Record RelatedPerson](StructureDefinition-ch-emr-relatedperson.md) | RelatedPerson profile for emergency contacts and family members in the Emergency Record. | [CH Core RelatedPerson](http://fhir.ch/ig/ch-core/StructureDefinition-ch-core-relatedperson.html) |
| [CH Emergency Record Observation Resuscitation Status](StructureDefinition-ch-emr-observation-resuscitation-status.md) | Observation profile for documenting the patient's resuscitation (code) status. | [Observation (FHIR R4)](http://hl7.org/fhir/R4/observation.html) |
| [CH Emergency Record Advance Directive DocumentReference](StructureDefinition-ch-emr-documentreference-advance-directive.md) | Reference to advance directives and emergency medical orders. | [CH Core DocumentReference](http://fhir.ch/ig/ch-core/StructureDefinition-ch-core-documentreference.html) |
| [CH Emergency Record Risk to Healthcare Personnel](StructureDefinition-ch-emr-flag-risk-to-healthcare-personnel.md) | Risk to healthcare personnel emanating from the patient (e.g. communicable disease). | [IPS Flag (alert)](http://hl7.org/fhir/uv/ips/StructureDefinition-Flag-alert-uv-ips.html) |
| [CH Emergency Record DocumentReference](StructureDefinition-ch-emr-documentreference.md) | DocumentReference profile for information on documents in the Emergency Record. | [CH Core DocumentReference](http://fhir.ch/ig/ch-core/StructureDefinition-ch-core-documentreference.html) |
| [CH Emergency Record Observation Cognitive Disability](StructureDefinition-ch-emr-observation-cognitive-disability.md) | Observation profile for cognitive disability in the Emergency Record. | [Observation (FHIR R4)](http://hl7.org/fhir/R4/observation.html) |
| [CH Emergency Record Physical Disability Observation](StructureDefinition-ch-emr-observation-physical-disability.md) | Observation profile for physical disability in the Emergency Record. | [Observation (FHIR R4)](http://hl7.org/fhir/R4/observation.html) |
| [CH Emergency Record MedicationStatement](StructureDefinition-ch-emr-medicationstatement.md) | MedicationStatement profile for medication in the Emergency Record. | [CH IPS MedicationStatement](http://fhir.ch/ig/ch-ips/StructureDefinition-ch-ips-medicationstatement.html) |

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [eCH-011 Types](http://fhir.ch/ig/ch-term/3.4.0/CodeSystem-ech-11.html): [ChEmrDocument](StructureDefinition-ch-emr-bundle.md)
* [CH EMR MRI Safety Status](CodeSystem-ch-emr-mri-safety-status-cs.md): [Bundle/UC1-Bundle-emr-MusterMax](Bundle-UC1-Bundle-emr-MusterMax.md), [Bundle/UC3-Bundle-emr-LaraKeller](Bundle-UC3-Bundle-emr-LaraKeller.md)... Show 4 more, [ChEmrDevice](StructureDefinition-ch-emr-device.md), [ChEmrMriSafetyStatusVS](ValueSet-ch-emr-mri-safety-status-vs.md), [Device/UC1-Device-Pacemaker](Device-UC1-Device-Pacemaker.md) and [Device/UC3-Device-AorticValve](Device-UC3-Device-AorticValve.md)
* [CH VACD Swissmedic Authorized Vaccines](http://fhir.ch/ig/ch-term/3.4.0/CodeSystem-ch-vacd-swissmedic-cs.html): [Bundle/EX-Bundle](Bundle-EX-Bundle.md) and [Immunization/EX-Immunization](Immunization-EX-Immunization.md)
* [EDQM - Standard Terms](http://fhir.ch/ig/ch-term/3.4.0/CodeSystem-edqm-standardterms.html): [Bundle/EX-Bundle](Bundle-EX-Bundle.md), [Bundle/UC1-Bundle-emr-MusterMax](Bundle-UC1-Bundle-emr-MusterMax.md)... Show 30 more, [Bundle/UC2-Bundle-emr-WalterSchmid](Bundle-UC2-Bundle-emr-WalterSchmid.md), [Bundle/UC3-Bundle-emr-LaraKeller](Bundle-UC3-Bundle-emr-LaraKeller.md), [Bundle/UC4-Bundle-emr-BeatFrei](Bundle-UC4-Bundle-emr-BeatFrei.md), [Bundle/UC5-Bundle-emr-AnnaMeier](Bundle-UC5-Bundle-emr-AnnaMeier.md), [Medication/EX-Metformin](Medication-EX-Metformin.md), [Medication/UC1-Medication-BelocZok](Medication-UC1-Medication-BelocZok.md), [Medication/UC1-Medication-Plavix](Medication-UC1-Medication-Plavix.md), [Medication/UC2-Medication-AspirinCardio](Medication-UC2-Medication-AspirinCardio.md), [Medication/UC2-Medication-Atorvastatin](Medication-UC2-Medication-Atorvastatin.md), [Medication/UC2-Medication-Epril](Medication-UC2-Medication-Epril.md), [Medication/UC2-Medication-XigduoXR](Medication-UC2-Medication-XigduoXR.md), [Medication/UC3-Medication-Marcoumar](Medication-UC3-Medication-Marcoumar.md), [Medication/UC4-Medication-Bilol](Medication-UC4-Medication-Bilol.md), [Medication/UC5-Medication-AspirinCardio](Medication-UC5-Medication-AspirinCardio.md), [Medication/UC5-Medication-Atorvastatin](Medication-UC5-Medication-Atorvastatin.md), [Medication/UC5-Medication-Bilol](Medication-UC5-Medication-Bilol.md), [Medication/UC5-Medication-Pemzek](Medication-UC5-Medication-Pemzek.md), [MedicationStatement/EX-MedicationStatement](MedicationStatement-EX-MedicationStatement.md), [MedicationStatement/UC1-MedicationStatement-BelocZok](MedicationStatement-UC1-MedicationStatement-BelocZok.md), [MedicationStatement/UC1-MedicationStatement-Plavix](MedicationStatement-UC1-MedicationStatement-Plavix.md), [MedicationStatement/UC2-MedicationStatement-AspirinCardio](MedicationStatement-UC2-MedicationStatement-AspirinCardio.md), [MedicationStatement/UC2-MedicationStatement-Atorvastatin](MedicationStatement-UC2-MedicationStatement-Atorvastatin.md), [MedicationStatement/UC2-MedicationStatement-Epril](MedicationStatement-UC2-MedicationStatement-Epril.md), [MedicationStatement/UC2-MedicationStatement-XigduoXR](MedicationStatement-UC2-MedicationStatement-XigduoXR.md), [MedicationStatement/UC3-MedicationStatement-Marcoumar](MedicationStatement-UC3-MedicationStatement-Marcoumar.md), [MedicationStatement/UC4-MedicationStatement-Bilol](MedicationStatement-UC4-MedicationStatement-Bilol.md), [MedicationStatement/UC5-MedicationStatement-AspirinCardio](MedicationStatement-UC5-MedicationStatement-AspirinCardio.md), [MedicationStatement/UC5-MedicationStatement-Atorvastatin](MedicationStatement-UC5-MedicationStatement-Atorvastatin.md), [MedicationStatement/UC5-MedicationStatement-Bilol](MedicationStatement-UC5-MedicationStatement-Bilol.md) and [MedicationStatement/UC5-MedicationStatement-Pemzek](MedicationStatement-UC5-MedicationStatement-Pemzek.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [CH_EMR](index.md), [ChEmrAdvanceDirectiveTypeVS](ValueSet-ch-emr-advance-directive-type-vs.md)... Show 24 more, [ChEmrBodyStructure](StructureDefinition-ch-emr-bodystructure.md), [ChEmrBodyStructureReference](StructureDefinition-ch-emr-body-structure-reference.md), [ChEmrClinicalDocumentTypesVS](ValueSet-ch-emr-clinical-document-types-vs.md), [ChEmrCognitiveDisabilityTypesVS](ValueSet-ch-emr-cognitive-disability-types-vs.md), [ChEmrComposition](StructureDefinition-ch-emr-composition.md), [ChEmrDevice](StructureDefinition-ch-emr-device.md), [ChEmrDeviceUseStatement](StructureDefinition-ch-emr-deviceusestatement.md), [ChEmrDocument](StructureDefinition-ch-emr-bundle.md), [ChEmrDocumentReference](StructureDefinition-ch-emr-documentreference.md), [ChEmrDocumentReferenceAdvanceDirective](StructureDefinition-ch-emr-documentreference-advance-directive.md), [ChEmrFlagRiskToHealthcarePersonnel](StructureDefinition-ch-emr-flag-risk-to-healthcare-personnel.md), [ChEmrImplantTypeVS](ValueSet-ch-emr-implant-type-vs.md), [ChEmrMedicationStatement](StructureDefinition-ch-emr-medicationstatement.md), [ChEmrMriSafetyStatusCS](CodeSystem-ch-emr-mri-safety-status-cs.md), [ChEmrMriSafetyStatusVS](ValueSet-ch-emr-mri-safety-status-vs.md), [ChEmrObservationCognitiveDisability](StructureDefinition-ch-emr-observation-cognitive-disability.md), [ChEmrObservationPhysicalDisability](StructureDefinition-ch-emr-observation-physical-disability.md), [ChEmrObservationResuscitationStatus](StructureDefinition-ch-emr-observation-resuscitation-status.md), [ChEmrPhysicalDisabilityTypesVS](ValueSet-ch-emr-physical-disability-types-vs.md), [ChEmrRelatedPerson](StructureDefinition-ch-emr-relatedperson.md), [ChEmrResuscitationStatusVS](ValueSet-ch-emr-resuscitation-status-vs.md), [ChEmrRiskToHealthcarePersonnelVS](ValueSet-ch-emr-risk-to-healthcare-personnel-vs.md), [EuropeanCommissionUDI](NamingSystem-eu-ec-udi.md) and [GS1DeviceIdentifier](NamingSystem-gs1-di.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/EX-Bundle](Bundle-EX-Bundle.md), [Bundle/UC1-Bundle-emr-MusterMax](Bundle-UC1-Bundle-emr-MusterMax.md)... Show 18 more, [Bundle/UC2-Bundle-emr-WalterSchmid](Bundle-UC2-Bundle-emr-WalterSchmid.md), [Bundle/UC3-Bundle-emr-LaraKeller](Bundle-UC3-Bundle-emr-LaraKeller.md), [Bundle/UC4-Bundle-emr-BeatFrei](Bundle-UC4-Bundle-emr-BeatFrei.md), [Bundle/UC5-Bundle-emr-AnnaMeier](Bundle-UC5-Bundle-emr-AnnaMeier.md), [ChEmrAdvanceDirectiveTypeVS](ValueSet-ch-emr-advance-directive-type-vs.md), [ChEmrComposition](StructureDefinition-ch-emr-composition.md), [ChEmrDocumentReferenceAdvanceDirective](StructureDefinition-ch-emr-documentreference-advance-directive.md), [Composition/EX-Composition](Composition-EX-Composition.md), [Composition/UC1-Composition-emr-MusterMax](Composition-UC1-Composition-emr-MusterMax.md), [Composition/UC2-Composition-emr-WalterSchmid](Composition-UC2-Composition-emr-WalterSchmid.md), [Composition/UC3-Composition-emr-LaraKeller](Composition-UC3-Composition-emr-LaraKeller.md), [Composition/UC4-Composition-emr-BeatFrei](Composition-UC4-Composition-emr-BeatFrei.md), [Composition/UC5-Composition-emr-AnnaMeier](Composition-UC5-Composition-emr-AnnaMeier.md), [DocumentReference/EX-AdvanceDirective](DocumentReference-EX-AdvanceDirective.md), [DocumentReference/UC1-DocumentReference-Notanordnung](DocumentReference-UC1-DocumentReference-Notanordnung.md), [DocumentReference/UC1-DocumentReference-Patientenverfuegung](DocumentReference-UC1-DocumentReference-Patientenverfuegung.md), [DocumentReference/UC2-DocumentReference-Patientenverfuegung](DocumentReference-UC2-DocumentReference-Patientenverfuegung.md) and [Observation/EX-Pregnancy](Observation-EX-Pregnancy.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/EX-AllergyIntolerance](AllergyIntolerance-EX-AllergyIntolerance.md), [AllergyIntolerance/UC2-AllergyIntolerance-Penicillin](AllergyIntolerance-UC2-AllergyIntolerance-Penicillin.md)... Show 72 more, [Bundle/EX-Bundle](Bundle-EX-Bundle.md), [Bundle/UC1-Bundle-emr-MusterMax](Bundle-UC1-Bundle-emr-MusterMax.md), [Bundle/UC2-Bundle-emr-WalterSchmid](Bundle-UC2-Bundle-emr-WalterSchmid.md), [Bundle/UC3-Bundle-emr-LaraKeller](Bundle-UC3-Bundle-emr-LaraKeller.md), [Bundle/UC4-Bundle-emr-BeatFrei](Bundle-UC4-Bundle-emr-BeatFrei.md), [Bundle/UC5-Bundle-emr-AnnaMeier](Bundle-UC5-Bundle-emr-AnnaMeier.md), [ChEmrBodyStructure](StructureDefinition-ch-emr-bodystructure.md), [ChEmrClinicalDocumentTypesVS](ValueSet-ch-emr-clinical-document-types-vs.md), [ChEmrCognitiveDisabilityTypesVS](ValueSet-ch-emr-cognitive-disability-types-vs.md), [ChEmrDevice](StructureDefinition-ch-emr-device.md), [ChEmrDeviceUseStatement](StructureDefinition-ch-emr-deviceusestatement.md), [ChEmrDocumentReference](StructureDefinition-ch-emr-documentreference.md), [ChEmrFlagRiskToHealthcarePersonnel](StructureDefinition-ch-emr-flag-risk-to-healthcare-personnel.md), [ChEmrImplantTypeVS](ValueSet-ch-emr-implant-type-vs.md), [ChEmrObservationCognitiveDisability](StructureDefinition-ch-emr-observation-cognitive-disability.md), [ChEmrObservationPhysicalDisability](StructureDefinition-ch-emr-observation-physical-disability.md), [ChEmrObservationResuscitationStatus](StructureDefinition-ch-emr-observation-resuscitation-status.md), [ChEmrPhysicalDisabilityTypesVS](ValueSet-ch-emr-physical-disability-types-vs.md), [ChEmrResuscitationStatusVS](ValueSet-ch-emr-resuscitation-status-vs.md), [ChEmrRiskToHealthcarePersonnelVS](ValueSet-ch-emr-risk-to-healthcare-personnel-vs.md), [Composition/EX-Composition](Composition-EX-Composition.md), [Composition/UC1-Composition-emr-MusterMax](Composition-UC1-Composition-emr-MusterMax.md), [Composition/UC2-Composition-emr-WalterSchmid](Composition-UC2-Composition-emr-WalterSchmid.md), [Composition/UC3-Composition-emr-LaraKeller](Composition-UC3-Composition-emr-LaraKeller.md), [Composition/UC4-Composition-emr-BeatFrei](Composition-UC4-Composition-emr-BeatFrei.md), [Composition/UC5-Composition-emr-AnnaMeier](Composition-UC5-Composition-emr-AnnaMeier.md), [Condition/EX-Condition](Condition-EX-Condition.md), [Condition/UC1-Condition-Hypertonie](Condition-UC1-Condition-Hypertonie.md), [Condition/UC1-Condition-KoronareHerzkrankheit](Condition-UC1-Condition-KoronareHerzkrankheit.md), [Condition/UC2-Condition-Schlaganfall](Condition-UC2-Condition-Schlaganfall.md), [Condition/UC3-Condition-AngeborenerHerzfehler](Condition-UC3-Condition-AngeborenerHerzfehler.md), [Condition/UC3-Condition-Eisenmangelanaemie](Condition-UC3-Condition-Eisenmangelanaemie.md), [Condition/UC4-Condition-Aortenaneurysma](Condition-UC4-Condition-Aortenaneurysma.md), [Condition/UC5-Condition-KoronareHerzkrankheit](Condition-UC5-Condition-KoronareHerzkrankheit.md), [Device/EX-MedicalDevice](Device-EX-MedicalDevice.md), [Device/UC1-Device-Pacemaker](Device-UC1-Device-Pacemaker.md), [Device/UC3-Device-AorticValve](Device-UC3-Device-AorticValve.md), [DeviceUseStatement/EX-DeviceUseStatement](DeviceUseStatement-EX-DeviceUseStatement.md), [DeviceUseStatement/UC1-DeviceUseStatement-Pacemaker](DeviceUseStatement-UC1-DeviceUseStatement-Pacemaker.md), [DeviceUseStatement/UC3-DeviceUseStatement-AorticValve](DeviceUseStatement-UC3-DeviceUseStatement-AorticValve.md), [DocumentReference/EX-AdvanceDirective](DocumentReference-EX-AdvanceDirective.md), [DocumentReference/EX-DocumentReferences](DocumentReference-EX-DocumentReferences.md), [DocumentReference/UC1-DocumentReference-Notanordnung](DocumentReference-UC1-DocumentReference-Notanordnung.md), [DocumentReference/UC1-DocumentReference-Patientenverfuegung](DocumentReference-UC1-DocumentReference-Patientenverfuegung.md), [DocumentReference/UC1-DocumentReference-Schrittmacherausweis](DocumentReference-UC1-DocumentReference-Schrittmacherausweis.md), [DocumentReference/UC2-DocumentReference-Patientenverfuegung](DocumentReference-UC2-DocumentReference-Patientenverfuegung.md), [Flag/EX-RiskFactor](Flag-EX-RiskFactor.md), [Gynäkologie Praxis Basel](Organization-EX-Organization-GynPraxis.md), [Hausarztpraxis UC1](Organization-UC1-Organization-Hausarztpraxis.md), [Hausarztpraxis UC2](Organization-UC2-Organization-Hausarztpraxis.md), [Hausarztpraxis UC3](Organization-UC3-Organization-Hausarztpraxis.md), [Hausarztpraxis UC4](Organization-UC4-Organization-Hausarztpraxis.md), [Hausarztpraxis UC5](Organization-UC5-Organization-Hausarztpraxis.md), [Immunization/EX-Immunization](Immunization-EX-Immunization.md), [Medication/EX-Metformin](Medication-EX-Metformin.md), [MedicationStatement/EX-MedicationStatement](MedicationStatement-EX-MedicationStatement.md), [Observation/EX-CognitiveDisability](Observation-EX-CognitiveDisability.md), [Observation/EX-PhysicalDisability](Observation-EX-PhysicalDisability.md), [Observation/EX-Resuscitation](Observation-EX-Resuscitation.md), [Observation/UC2-PhysicalDisability-Aphasie](Observation-UC2-PhysicalDisability-Aphasie.md), [Practitioner/EX-Practitioner](Practitioner-EX-Practitioner.md), [Practitioner/UC1-Practitioner-Hausarzt](Practitioner-UC1-Practitioner-Hausarzt.md), [Practitioner/UC2-Practitioner-Hausarzt](Practitioner-UC2-Practitioner-Hausarzt.md), [Practitioner/UC3-Practitioner-Hausarzt](Practitioner-UC3-Practitioner-Hausarzt.md), [Practitioner/UC4-Practitioner-Hausarzt](Practitioner-UC4-Practitioner-Hausarzt.md), [Practitioner/UC5-Practitioner-Hausarzt](Practitioner-UC5-Practitioner-Hausarzt.md), [PractitionerRole/EX-PractitionerRole](PractitionerRole-EX-PractitionerRole.md), [PractitionerRole/UC1-PractitionerRole-Hausarzt](PractitionerRole-UC1-PractitionerRole-Hausarzt.md), [PractitionerRole/UC2-PractitionerRole-Hausarzt](PractitionerRole-UC2-PractitionerRole-Hausarzt.md), [PractitionerRole/UC3-PractitionerRole-Hausarzt](PractitionerRole-UC3-PractitionerRole-Hausarzt.md), [PractitionerRole/UC4-PractitionerRole-Hausarzt](PractitionerRole-UC4-PractitionerRole-Hausarzt.md) and [PractitionerRole/UC5-PractitionerRole-Hausarzt](PractitionerRole-UC5-PractitionerRole-Hausarzt.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-emr.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-emr.r4b)](package.r4b.tgz) are available.

### Dependency Table













### Globals Table

*There are no Global profiles defined*

