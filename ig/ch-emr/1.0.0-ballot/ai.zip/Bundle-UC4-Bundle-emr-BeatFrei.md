# UC4-Bundle-emr-BeatFrei - CH EMR (R4) v1.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UC4-Bundle-emr-BeatFrei**

## Example Bundle: UC4-Bundle-emr-BeatFrei



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "UC4-Bundle-emr-BeatFrei",
  "meta" : {
    "lastUpdated" : "2026-06-02T08:00:00+02:00",
    "profile" : ["http://fhir.ch/ig/ch-emr/StructureDefinition/ch-emr-bundle"]
  },
  "language" : "de-CH",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:44444444-aaaa-4444-8444-444444444444"
  },
  "type" : "document",
  "timestamp" : "2026-06-02T08:00:00+02:00",
  "entry" : [{
    "fullUrl" : "http://fhir.ch/ig/emr/Composition/UC4-Composition-emr-BeatFrei",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "UC4-Composition-emr-BeatFrei",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-emr/StructureDefinition/ch-emr-composition"]
      },
      "language" : "de-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"Composition_UC4-Composition-emr-BeatFrei\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition UC4-Composition-emr-BeatFrei</b></p><a name=\"UC4-Composition-emr-BeatFrei\"> </a><a name=\"hcUC4-Composition-emr-BeatFrei\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emr-composition.html\">CH Emergency Record Composition</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/7.1.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:44444444-aaaa-4444-8444-444444444444</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 60591-5}\">Patient summary Document</span></p><p><b>date</b>: 2026-06-02 08:00:00+0200</p><p><b>author</b>: <a href=\"PractitionerRole-UC4-PractitionerRole-Hausarzt.html\">PractitionerRole Physician</a></p><p><b>title</b>: Elektronischer Notfallpass — Beat Frei</p><p><b>confidentiality</b>: normal</p></div>"
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:44444444-aaaa-4444-8444-444444444444"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5"
        }]
      },
      "subject" : {
        "reference" : "Patient/UC4-Patient-BeatFrei"
      },
      "date" : "2026-06-02T08:00:00+02:00",
      "author" : [{
        "reference" : "PractitionerRole/UC4-PractitionerRole-Hausarzt"
      }],
      "title" : "Elektronischer Notfallpass — Beat Frei",
      "confidentiality" : "N",
      "_confidentiality" : {
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/2011000195101",
              "code" : "17621005"
            }]
          }
        }]
      },
      "section" : [{
        "title" : "Notfallkontakte",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "56864-2"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li>Sandra Frei (Ehefrau): +41 79 555 33 44</li></ul></div>"
        },
        "entry" : [{
          "reference" : "RelatedPerson/UC4-RelatedPerson-Ehefrau"
        }]
      },
      {
        "title" : "Behandelnde Gesundheitsfachperson",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85847-2"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li>Dr. med. UC4 Hausarzt</li></ul></div>"
        },
        "entry" : [{
          "reference" : "Practitioner/UC4-Practitioner-Hausarzt"
        },
        {
          "reference" : "PractitionerRole/UC4-PractitionerRole-Hausarzt"
        }]
      },
      {
        "title" : "Reanimationsstatus",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "100822-6"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Kein Reanimationsstatus erfasst.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      },
      {
        "title" : "Medikation",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10160-0"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li>Bilol 5 mg (Bisoprolol), 1-0-0-0 — Blutdrucksenkung bei Aortenaneurysma</li></ul></div>"
        },
        "entry" : [{
          "reference" : "MedicationStatement/UC4-MedicationStatement-Bilol"
        }]
      },
      {
        "title" : "Impfungen",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine Impfungen dokumentiert.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      },
      {
        "title" : "Allergien oder Unverträglichkeiten",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48765-2"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine Allergien bekannt.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "nilknown",
            "display" : "Nil Known"
          }]
        }
      },
      {
        "title" : "Risiken für Behandelnde",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "46467-7"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine Risikofaktoren bekannt.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      },
      {
        "title" : "Probleme und Diagnosen",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li>2024 Aortenaneurysma</li></ul></div>"
        },
        "entry" : [{
          "reference" : "Condition/UC4-Condition-Aortenaneurysma"
        }]
      },
      {
        "title" : "Patientenverfügungen und Ärztliche Notfallanordnung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "42348-3"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine Patientenverfügung hinterlegt.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      },
      {
        "title" : "Andere Dokumente",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "55108-5"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine zusätzlichen Dokumente hinterlegt.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      },
      {
        "title" : "Implantate",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "46264-8"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine medizinischen Geräte dokumentiert.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "nilknown",
            "display" : "Nil Known"
          }]
        }
      },
      {
        "title" : "Schwangerschaft",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10162-6"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Nicht zutreffend.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "notasked",
            "display" : "Not Asked"
          }]
        }
      },
      {
        "title" : "Kognitive Beeinträchtigungen",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "66610-7"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keine bekannt.</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "nilknown",
            "display" : "Nil Known"
          }]
        }
      },
      {
        "title" : "Physische Beeinträchtigungen",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96386-8"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Rezidivierende Lumbalgien (anamnestisch).</p></div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable",
            "display" : "Information not available"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/Patient/UC4-Patient-BeatFrei",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "UC4-Patient-BeatFrei",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_UC4-Patient-BeatFrei\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient UC4-Patient-BeatFrei</b></p><a name=\"UC4-Patient-BeatFrei\"> </a><a name=\"hcUC4-Patient-BeatFrei\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-patient.html\">CH IPS Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Beat Frei (official) Male, DoB: 1968-07-22 ( urn:oid:2.16.756.5.30.1.123.100.1.1.1#InsuranceCardNumber#80756014444444444444)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">Hauptstrasse 12 Basel 4051 CH </td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Language spoken\">Language:</td><td colspan=\"3\"><span title=\"Codes:{urn:ietf:bcp:47 de}\">German</span> (preferred)</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.30.1.123.100.1.1.1",
        "value" : "80756014444444444444"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Frei",
        "given" : ["Beat"]
      }],
      "gender" : "male",
      "birthDate" : "1968-07-22",
      "address" : [{
        "line" : ["Hauptstrasse 12"],
        "city" : "Basel",
        "postalCode" : "4051",
        "country" : "CH"
      }],
      "communication" : [{
        "language" : {
          "coding" : [{
            "system" : "urn:ietf:bcp:47",
            "code" : "de"
          }]
        },
        "preferred" : true
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/RelatedPerson/UC4-RelatedPerson-Ehefrau",
    "resource" : {
      "resourceType" : "RelatedPerson",
      "id" : "UC4-RelatedPerson-Ehefrau",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-emr/StructureDefinition/ch-emr-relatedperson"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_UC4-RelatedPerson-Ehefrau\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson UC4-RelatedPerson-Ehefrau</b></p><a name=\"UC4-RelatedPerson-Ehefrau\"> </a><a name=\"hcUC4-RelatedPerson-Ehefrau\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emr-relatedperson.html\">CH Emergency Record RelatedPerson</a></p></div><p><b>active</b>: true</p><p><b>patient</b>: <a href=\"Patient-UC4-Patient-BeatFrei.html\">Beat Frei (official) Male, DoB: 1968-07-22 ( urn:oid:2.16.756.5.30.1.123.100.1.1.1#InsuranceCardNumber#80756014444444444444)</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode WIFE}\">wife</span></p><p><b>name</b>: Sandra Frei (Official)</p><p><b>telecom</b>: <a href=\"tel:+41795553344\">+41 79 555 33 44</a></p><p><b>gender</b>: Female</p><h3>Communications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Language</b></td><td><b>Preferred</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:ietf:bcp:47 de}\">German</span></td><td>true</td></tr></table></div>"
      },
      "active" : true,
      "patient" : {
        "reference" : "Patient/UC4-Patient-BeatFrei"
      },
      "relationship" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "WIFE",
          "display" : "wife"
        }]
      }],
      "name" : [{
        "use" : "official",
        "family" : "Frei",
        "given" : ["Sandra"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 555 33 44",
        "use" : "mobile",
        "rank" : 1
      }],
      "gender" : "female",
      "communication" : [{
        "language" : {
          "coding" : [{
            "system" : "urn:ietf:bcp:47",
            "code" : "de"
          }]
        },
        "preferred" : true
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/Practitioner/UC4-Practitioner-Hausarzt",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "UC4-Practitioner-Hausarzt",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-practitioner"]
      },
      "language" : "de-CH",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de-CH\" lang=\"de-CH\"><a name=\"Practitioner_UC4-Practitioner-Hausarzt\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner UC4-Practitioner-Hausarzt</b></p><a name=\"UC4-Practitioner-Hausarzt\"> </a><a name=\"hcUC4-Practitioner-Hausarzt\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: de-CH</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-practitioner.html\">CH IPS Practitioner</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.3.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000000071</p><p><b>name</b>: UC4 Hausarzt (Official)</p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 309343006}\">Arzt</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000071"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Hausarzt",
        "given" : ["UC4"],
        "prefix" : ["Dr. med."]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "version" : "http://snomed.info/sct/2011000195101",
            "code" : "309343006"
          }],
          "text" : "Arzt"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/PractitionerRole/UC4-PractitionerRole-Hausarzt",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "UC4-PractitionerRole-Hausarzt",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-practitionerrole"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_UC4-PractitionerRole-Hausarzt\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole UC4-PractitionerRole-Hausarzt</b></p><a name=\"UC4-PractitionerRole-Hausarzt\"> </a><a name=\"hcUC4-PractitionerRole-Hausarzt\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-practitionerrole.html\">CH IPS PractitionerRole</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-UC4-Practitioner-Hausarzt.html\">Practitioner UC4 Hausarzt (official)</a></p><p><b>organization</b>: <a href=\"Organization-UC4-Organization-Hausarztpraxis.html\">Organization Hausarztpraxis UC4</a></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 309343006}\">Arzt</span></p><p><b>specialty</b>: <span title=\"Codes:{http://snomed.info/sct 419772000}\">Allgemeine Innere Medizin</span></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/UC4-Practitioner-Hausarzt"
      },
      "organization" : {
        "reference" : "Organization/UC4-Organization-Hausarztpraxis"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "309343006"
        }],
        "text" : "Arzt"
      }],
      "specialty" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "419772000"
        }],
        "text" : "Allgemeine Innere Medizin"
      }]
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/Organization/UC4-Organization-Hausarztpraxis",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "UC4-Organization-Hausarztpraxis",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_UC4-Organization-Hausarztpraxis\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization UC4-Organization-Hausarztpraxis</b></p><a name=\"UC4-Organization-Hausarztpraxis\"> </a><a name=\"hcUC4-Organization-Hausarztpraxis\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-organization.html\">CH IPS Organization</a></p></div><p><b>identifier</b>: <a href=\"http://fhir.ch/ig/ch-term/3.3.0/NamingSystem-gln.html\" title=\"Each healthcare partner (natural or legal person) is referenced with a unique code of type GLN (former name: EAN code) of the [GS1](https://www.gs1.ch/de/home) system, see [refdata](https://www.refdata.ch/).\">GLN</a>/7601000000088</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 394802001}\">Allgemeine Innere Medizin</span></p><p><b>name</b>: Hausarztpraxis UC4</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000088"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "394802001"
        }],
        "text" : "Allgemeine Innere Medizin"
      }],
      "name" : "Hausarztpraxis UC4"
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/Condition/UC4-Condition-Aortenaneurysma",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "UC4-Condition-Aortenaneurysma",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-condition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_UC4-Condition-Aortenaneurysma\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition UC4-Condition-Aortenaneurysma</b></p><a name=\"UC4-Condition-Aortenaneurysma\"> </a><a name=\"hcUC4-Condition-Aortenaneurysma\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-condition.html\">CH IPS Condition</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 67362008}\">Aortic aneurysm</span></p><p><b>subject</b>: <a href=\"Patient-UC4-Patient-BeatFrei.html\">Beat Frei (official) Male, DoB: 1968-07-22 ( urn:oid:2.16.756.5.30.1.123.100.1.1.1#InsuranceCardNumber#80756014444444444444)</a></p><p><b>onset</b>: 2024</p><p><b>recordedDate</b>: 2024-01-01</p><p><b>recorder</b>: <a href=\"Practitioner-UC4-Practitioner-Hausarzt.html\">Practitioner UC4 Hausarzt (official)</a></p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "67362008"
        }]
      },
      "subject" : {
        "reference" : "Patient/UC4-Patient-BeatFrei"
      },
      "onsetDateTime" : "2024",
      "recordedDate" : "2024-01-01",
      "recorder" : {
        "reference" : "Practitioner/UC4-Practitioner-Hausarzt"
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/Medication/UC4-Medication-Bilol",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "UC4-Medication-Bilol",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-ips/StructureDefinition/ch-ips-medication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_UC4-Medication-Bilol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication UC4-Medication-Bilol</b></p><a name=\"UC4-Medication-Bilol\"> </a><a name=\"hcUC4-Medication-Bilol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-ips/2.0.0/StructureDefinition-ch-ips-medication.html\">CH IPS Medication</a></p></div><p><b>code</b>: <span title=\"Codes:{urn:oid:2.51.1.1 7680540300100}, {http://www.whocc.no/atc C07AB07}\">Bilol 5 mg (Bisoprolol)</span></p><p><b>form</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 10219000}\">Tablette</span></p><p><b>amount</b>: 30 Tablette<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = '732936001')</span>/1 Packung<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code1681000175101 = '1681000175101')</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "urn:oid:2.51.1.1",
          "code" : "7680540300100",
          "display" : "BILOL Filmtabl 5 mg 30 Stk"
        },
        {
          "system" : "http://www.whocc.no/atc",
          "code" : "C07AB07",
          "display" : "bisoprolol"
        }],
        "text" : "Bilol 5 mg (Bisoprolol)"
      },
      "form" : {
        "coding" : [{
          "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
          "code" : "10219000"
        }],
        "text" : "Tablette"
      },
      "amount" : {
        "numerator" : {
          "value" : 30,
          "unit" : "Tablette",
          "system" : "http://snomed.info/sct|http://snomed.info/sct/2011000195101",
          "code" : "732936001"
        },
        "denominator" : {
          "value" : 1,
          "unit" : "Packung",
          "system" : "http://snomed.info/sct|http://snomed.info/sct/2011000195101",
          "code" : "1681000175101"
        }
      }
    }
  },
  {
    "fullUrl" : "http://fhir.ch/ig/emr/MedicationStatement/UC4-MedicationStatement-Bilol",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "UC4-MedicationStatement-Bilol",
      "meta" : {
        "profile" : ["http://fhir.ch/ig/ch-emr/StructureDefinition/ch-emr-medicationstatement"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_UC4-MedicationStatement-Bilol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement UC4-MedicationStatement-Bilol</b></p><a name=\"UC4-MedicationStatement-Bilol\"> </a><a name=\"hcUC4-MedicationStatement-Bilol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-emr-medicationstatement.html\">CH Emergency Record Medication Statement</a></p></div><p><b>status</b>: Active</p><p><b>medication</b>: <a href=\"Medication-UC4-Medication-Bilol.html\">Medication BILOL Filmtabl 5 mg 30 Stk</a></p><p><b>subject</b>: <a href=\"Patient-UC4-Patient-BeatFrei.html\">Beat Frei (official) Male, DoB: 1968-07-22 ( urn:oid:2.16.756.5.30.1.123.100.1.1.1#InsuranceCardNumber#80756014444444444444)</a></p><p><b>effective</b>: 2024-02-01 --&gt; (ongoing)</p><p><b>reasonReference</b>: <a href=\"Condition-UC4-Condition-Aortenaneurysma.html\">Condition Aortic aneurysm</a></p><blockquote><p><b>dosage</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Morning, Once</p><p><b>route</b>: <span title=\"Codes:{urn:oid:0.4.0.127.0.16.1.1.2.1 20053000}\">zum Einnehmen</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Tablette<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = '732936001')</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "medicationReference" : {
        "reference" : "Medication/UC4-Medication-Bilol"
      },
      "subject" : {
        "reference" : "Patient/UC4-Patient-BeatFrei"
      },
      "effectivePeriod" : {
        "start" : "2024-02-01"
      },
      "reasonReference" : [{
        "reference" : "Condition/UC4-Condition-Aortenaneurysma"
      }],
      "dosage" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "when" : ["MORN"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "urn:oid:0.4.0.127.0.16.1.1.2.1",
            "code" : "20053000"
          }],
          "text" : "zum Einnehmen"
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Tablette",
            "system" : "http://snomed.info/sct|http://snomed.info/sct/2011000195101",
            "code" : "732936001"
          }
        }]
      }]
    }
  }]
}

```
