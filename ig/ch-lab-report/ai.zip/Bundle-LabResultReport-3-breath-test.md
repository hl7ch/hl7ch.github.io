# Bundle 3-breath-test - CH LAB-Report (R4) v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle 3-breath-test**

## Example Bundle: Bundle 3-breath-test



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "LabResultReport-3-breath-test",
  "meta" : {
    "lastUpdated" : "2024-03-13T01:43:30Z",
    "profile" : [
      "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-report-document",
      "http://hl7.eu/fhir/laboratory/StructureDefinition/Bundle-eu-lab"
    ]
  },
  "identifier" : {
    "system" : "http://example.org",
    "value" : "b611e310-0a3a-44a9-8897-1bed3443394d"
  },
  "type" : "document",
  "timestamp" : "2024-03-13T01:43:30Z",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:1c437141-1784-4c8f-8f69-6deaea948a4d",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "1c437141-1784-4c8f-8f69-6deaea948a4d",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-report-composition"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_1c437141-1784-4c8f-8f69-6deaea948a4d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition 1c437141-1784-4c8f-8f69-6deaea948a4d</b></p><a name=\"1c437141-1784-4c8f-8f69-6deaea948a4d\"> </a><a name=\"hc1c437141-1784-4c8f-8f69-6deaea948a4d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-report-composition.html\">CH LAB-Report Composition: Laboratory Report</a></p></div><p><b>Information recipient</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-3771d254-cee2-498e-a448-c5660ccd583d\">TheoTillmannGruppenpraxis</a></p><p><b>Document DiagnosticReport Reference</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-aa659dd8-28be-4c7e-ab27-286c5beff53c\">DiagnosticReport-3-breath-test</a></p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/5.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:075e3f2d-7ed8-4b6e-a3bb-9b784f5006c0</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 11502-2}\">Laboratory report</span></p><p><b>date</b>: 2024-03-13 01:43:30+0000</p><p><b>author</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Dr. Katrin Klauser</a></p><p><b>title</b>: Laboratory Report - 10 Theoh, 2023 14:30</p><p><b>confidentiality</b>: normal</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Legal</td><td>2024-03-13 01:43:30+0000</td><td><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Katrin Klauser</a></td></tr></table><p><b>custodian</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-8030393e-d1c2-409f-841b-0c3af4e68494\">Labor Schildknecht</a></p></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.eu/fhir/StructureDefinition/information-recipient",
            "valueReference" : {
              "reference" : "urn:uuid:3771d254-cee2-498e-a448-c5660ccd583d",
              "display" : "TheoTillmannGruppenpraxis"
            }
          },
          {
            "url" : "http://hl7.eu/fhir/laboratory/StructureDefinition/composition-diagnosticReportReference",
            "valueReference" : {
              "reference" : "urn:uuid:aa659dd8-28be-4c7e-ab27-286c5beff53c",
              "display" : "DiagnosticReport-3-breath-test"
            }
          }
        ],
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:075e3f2d-7ed8-4b6e-a3bb-9b784f5006c0"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "11502-2",
              "display" : "Laboratory report"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "date" : "2024-03-13T01:43:30Z",
        "author" : [
          {
            "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
            "display" : "Dr. Katrin Klauser"
          }
        ],
        "title" : "Laboratory Report - 10 Theoh, 2023 14:30",
        "confidentiality" : "N",
        "attester" : [
          {
            "mode" : "legal",
            "time" : "2024-03-13T01:43:30Z",
            "party" : {
              "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
              "display" : "Katrin Klauser"
            }
          }
        ],
        "custodian" : {
          "reference" : "urn:uuid:8030393e-d1c2-409f-841b-0c3af4e68494",
          "display" : "Labor Schildknecht"
        },
        "section" : [
          {
            "title" : "Laboratory examinations",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "26436-6",
                  "display" : "Laboratory studies (set)"
                }
              ],
              "text" : "Laboratory studies"
            },
            "section" : [
              {
                "title" : "Chemistry studies (set)",
                "code" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "18719-5"
                    }
                  ]
                },
                "entry" : [
                  {
                    "reference" : "urn:uuid:3318e76e-570d-48d5-b599-1110cf92ee86",
                    "display" : "Observation-3-breath-test"
                  }
                ]
              },
              {
                "title" : "Chemistry studies (set)",
                "code" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "18719-5"
                    }
                  ]
                },
                "entry" : [
                  {
                    "reference" : "urn:uuid:f57378f6-738b-4f2c-8ab7-03341eac9518",
                    "display" : "Observation-3-breath-test-hydrogen"
                  }
                ]
              },
              {
                "title" : "Chemistry studies (set)",
                "code" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "18719-5"
                    }
                  ]
                },
                "entry" : [
                  {
                    "reference" : "urn:uuid:57c1026b-6e7d-4172-9c74-cdb87dfeedb9",
                    "display" : "Observation-3-breath-test-methane"
                  }
                ]
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:aa659dd8-28be-4c7e-ab27-286c5beff53c",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "aa659dd8-28be-4c7e-ab27-286c5beff53c",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-diagnosticreport"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_aa659dd8-28be-4c7e-ab27-286c5beff53c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport aa659dd8-28be-4c7e-ab27-286c5beff53c</b></p><a name=\"aa659dd8-28be-4c7e-ab27-286c5beff53c\"> </a><a name=\"hcaa659dd8-28be-4c7e-ab27-286c5beff53c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-diagnosticreport.html\">CH LAB-Report DiagnosticReport: Laboratory Report</a></p></div><h2><span title=\"Codes:{http://loinc.org 11502-2}\">Laboratory report</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Emil Emmenegger Male, DoB: 1981-01-01 ( urn:oid:2.16.756.5.30.1.123.100.1.1.1#80756011110123400111)</td></tr><tr><td>When For</td><td>2024-03-13 01:43:30+0000</td></tr><tr><td>Performer</td><td> <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-525e02f3-cac3-4cdc-a497-ce6e441b8a80\">Dr. Katrin Klauser</a></td></tr><tr><td>Identifier</td><td> <a href=\"http://terminology.hl7.org/5.3.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:075e3f2d-7ed8-4b6e-a3bb-9b784f5006c0</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td></tr><tr><td><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-3318e76e-570d-48d5-b599-1110cf92ee86\"><span title=\"Codes:{http://loinc.org 50584-2}\">Lactose challenge (hydrogen breath test) panel (Exhl gas)</span></a></td><td/><td>Final</td></tr><tr><td><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-f57378f6-738b-4f2c-8ab7-03341eac9518\"><span title=\"Codes:{http://loinc.org 105751-2}\">Lactose challenge (hydrogen breath test) panel (Exhl gas)</span></a></td><td/><td>Final</td></tr><tr><td><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-57c1026b-6e7d-4172-9c74-cdb87dfeedb9\"><span title=\"Codes:{http://loinc.org 105750-4}\">Lactose challenge (methane breath test) panel (Exhl gas)</span></a></td><td/><td>Final</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
            "valueReference" : {
              "reference" : "urn:uuid:1c437141-1784-4c8f-8f69-6deaea948a4d"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:uuid:075e3f2d-7ed8-4b6e-a3bb-9b784f5006c0"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "11502-2",
              "display" : "Laboratory report"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "effectiveDateTime" : "2024-03-13T01:43:30Z",
        "performer" : [
          {
            "reference" : "urn:uuid:525e02f3-cac3-4cdc-a497-ce6e441b8a80",
            "display" : "Dr. Katrin Klauser"
          }
        ],
        "specimen" : [
          {
            "reference" : "urn:uuid:85c72094-e3e8-4d3a-8a18-c2812310fd10",
            "display" : "Gas-3-breath-test"
          }
        ],
        "result" : [
          {
            "reference" : "urn:uuid:3318e76e-570d-48d5-b599-1110cf92ee86",
            "display" : "Observation-3-breath-test"
          },
          {
            "reference" : "urn:uuid:f57378f6-738b-4f2c-8ab7-03341eac9518",
            "display" : "Observation-3-breath-test-hydrogen"
          },
          {
            "reference" : "urn:uuid:57c1026b-6e7d-4172-9c74-cdb87dfeedb9",
            "display" : "Observation-3-breath-test-mathane"
          }
        ],
        "presentedForm" : [
          {
            "contentType" : "application/pdf",
            "data" : "R0lGODlhpB4EDfEAAAAAAKCgoL6+vv///yH5BAAAAAAAIf8LSUNDUkdCRzEwMTL/AAAKEAAAAAACEAAAbW50clJHQiBYWVogAAAAAAAAAAAAAAAAYWNzcEFQUEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPbWAAEAAAAA0y0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKZGVzYwAAAPwAAAB8Y3BydAAAAXgAAAAod3RwdAAAAaAAAAAUYmtwdAAAAbQAAAAUclhZWgAAAcgAAAAUZ1hZWgAAAdwAAAAUYlhZWgAAAfAAAAAUclRSQwAAAgQAAAgMZ1RSQwAAAgQAAAgMYlRSQwAAAgQAAAgMZGVz/2MAAAAAAAAAIkFydGlmZXggU29mdHdhcmUgc1JHQiBJQ0MgUHJvZmlsZQAAAAAAAAAAAAAAIkFydGlmZXggU29mdHdhcmUgc1JHQiBJQ0MgUHJvZmlsZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAENvcHlyaWdodCBBcnRpZmV4IFNvZnR3YXJlIDIwMTEAWFlaIAAAAAAAAPNRAAEAAAABFsxYWVogAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAP8PhAAAts9jdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQP/OANDA08DWgNmA3IDfgOKA5YDogOuA7oDxwPTA+AD7AP5BAYEEwQgBC0EOwRIBFUEYwRxBH4EjASaBKgEtgTEBNME4QTwBP4FDQUcBSsFOgVJBVgFZwV3BYYFlgWmBbUFxQXVBeUF9gYGBhYGJwY3BkgGWQZqBnsGjAadBq8GwAbRBuMG9QcHBxkHKwc9B08HYQd0B4YHmQesB78H0gflB/gICwgfCDIIRghaCG4IggiWCKoIvgjSCOcI+wkQCSUJOglPCWQJeQmPCaQJugnPCeUJ+woRCicKPQpUCmoKgQqYCq4KxQrcCvMLCwsiCzkLUQtpC4ALmAuwC8gL4Qv5/wwSDCoMQwxcDHUMjgynDMAM2QzzDQ0NJg1ADVoNdA2ODakNww3eDfgOEw4uDkkOZA5/DpsOtg7SDu4PCQ8lD0EPXg96D5YPsw/PD+wQCRAmEEMQYRB+EJsQuRDXEPURExExEU8RbRGMEaoRyRHoEgcSJhJFEmQShBKjEsMS4xMDEyMTQxNjE4MTpBPFE+UUBhQnFEkUahSLFK0UzhTwFRIVNBVWFXgVmxW9FeAWAxYmFkkWbBaPFrIW1hb6Fx0XQRdlF4kXrhfSF/cYGxhAGGUYihivGNUY+hkgGUUZaxmRGbcZ3RoEGioaURp3Gp4axRrsGxQbOxtjG4obshvaHP8CHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCv/NGU0njTYNRM1TTWHNcI1/TY3NnI2rjbpNyQ3YDecN9c4FDhQOIw4yDkFOUI5fzm8Ofk6Njp0OrI67zstO2s7qjvoPCc8ZTykPOM9Ij1hPaE94D4gPmA+oD7gPyE/YT+iP+JAI0BkQKZA50EpQWpBrEHuQjBCckK1QvdDOkN9Q8BEA0RHRIpEzkUSRVVFmkXeRiJGZ0arRvBHNUd7R8BIBUhLSJFI10kdSWNJqUnwSjdKfUrESwxLU0uaS+JMKkxyTLpNAk1KTZNN3E4lTm5Ot08AT0lPk0/dUCdQcVC7UQZRUFGbUeZSMVJ8UsdTE1NfU6pT9lRCVI9U21UoVXVV/8JWD1ZcVqlW91dEV5JX4FgvWH1Yy1kaWWlZuFoHWlZaplr1W0VblVvlXDVchlzWXSddeF3JXhpebF69Xw9fYV+zYAVgV2CqYPxhT2GiYfViSWKcYvBjQ2OXY+tkQGSUZOllPWWSZedmPWaSZuhnPWeTZ+loP2iWaOxpQ2maafFqSGqfavdrT2una/9sV2yvbQhtYG25bhJua27Ebx5veG/RcCtwhnDgcTpxlXHwcktypnMBc11zuHQUdHB0zHUodYV14XY+dpt2+HdWd7N4EXhueMx5KnmJeed6RnqlewR7Y3vCfCF8gXzhfUF9oX4BfmJ+wn8jf4R/5YBHgKiBCv+Ba4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Lf/aLfguFm40blKucK6O7q1uy67p7whvJu9Fb2Pvgq+hL7/v3q/9cBwwOzBZ8Hjwl/C28NYw9TEUcTOxUvFyMZGxsPHQce/yD3IvMk6ybnKOMq3yzbLtsw1zLXNNc21zjbOts83z7jQOdC60TzRvtI/0sHTRNPG1EnUy9VO1dHWVdbY11zX4Nhk2OjZbNnx2nba+9uA3AXcit0Q3ZbeHN6i3ynfr+A24L3hROHM4lPi2+Nj4+vkc+T85YTmDeaW5x/nqegy6LzpRunQ6lvq5etw6/vshu0R7ZzuKO6070DvzPBY8OXxcvH/8ozzGfOn9DT0wvVQ9d72bfb794r4GfioGvk4+cf6V/rn+3f8B/yY/Sn9uv5L/tz/bf//ACwAAAAApB4EDQAC/pyPqcvtD6OctNqLs968+w+G4kiW5omm6sq27gvH8kzX9o3n+s73/g8MCofEovGITCqXzKbzCY1Kp9Sq9YrNarfcrvcLDovH5LL5jE6r1+y2+w2Py+f0uv2Oz+v3/L7/DxgoOEhYaHiImKi4yNjo+AgZKTlJWWl5iZmpucnZ6fkJGio6SlpqeoqaqrrK2ur6ChsrO0tba3uLm6u7y9vr+wscLDxMXGx8jJysvMzc7PwMHS09TV1tfY2drb3N3e39DR4uPk5ebn6Onq6+zt7u/g4fLz9PX29/j5+vv8/f7/8PMKDAgQQLGjyIMKHChQwbOnwIMaLEiRQrWryIMaPG/o0cO3r8CDKkyJEkS5o8iTKlypUsW7p8CTOmzJk0a9q8iTOnzp08e/r8CTSo0KFEixo9ijSp0qVMmzp9CjWq1KlUq1q9ijWr1q1cu3r9Cjas2LFky5o9izat2rVs27p9Czeu3Ll069q9izev3r18+/r9Cziw4MGECxs+jDix4sWMGzt+DDmy5MmUK1u+jDmz5s2cO3v+DDq06NGkS5s+jTq16tWsW7t+DTu27Nm0a9u+jTu37t28e/v+DTy48OHEixs/jjy58uXMmzt/Dj269OnUq1u/jj279u3cu3v/Dj68+PHky5s/jz69+vXs27t/Dz++/Pn069u/jz+//v38/vv7/w9ggAIOSGCBBh6IYIIKLshggw4+CGGEEk5IYYUWXohhhhpuyGGHHn4IYogijkhiiSaeiGKKKq7IYosuvghjjDLOSGONNt6IY4467shjjz7+CGSQQg5JZJFGHolkkkouyWSTTj4JZZRSTklllVZeiWWWWm7JZZdefglmmGKOSWaZZp6JZppqrslmm26+CWeccs5JZ5123olnnnruyWeffv4JaKCCDkpooYYeimiiii7KaKOOPgpppJJOSmmlll6Kaaaabsppp55+Cmqooo5Kaqmmnopqqqquymqrrr4Ka6yyzkprrbbeimuuuu7Ka6MAAHDFr1UI6wKxvR6L/myyyi7LbLPOPhvmr9JOS62xRlSLrbRIZFutCNxiC2244o5Lbrnmnotuut1xO8G37gKrArsSvPvtCvJCQG+3HOQLrrr+/gtwwAIPTHDBBtt1rwP8uptCwg0sXC8KDi8Asb4XVNzvwRpvzHHHHn8McsgiPzRxAhgzbELJCJwccQkqG8CyxfPGLPPINt+Mc84678xzzz6f8vIANAe9b7YKD53xCC8jPW27TDf9c9RST0111VZfjXXWRaj8NNEZcN110iCAHXYEYUOtddpqr812226/DffGJZ9ttLd1m0x3zR5MnDe8R/cdd+CCD0544YYfjrivdx/ArwIY2y220Pk6/l4x5HpPznjjD79LseaJfw566KKPTnrppu+4uOQtP7Cw5WjDjDK+nn+Q+uqbx4536rfjfnrvvv8OfPDCD0/8eYvzPjPnYyeNvNn0hnC87qzbDnvksjdffPbab899995/D75kd1NPAeZ7Z0y+08qfb7H0zjvs9e7Wh09//fbfj3/++u8f1PjzW7C+DvhPbxgIYNHA5b7kiS2BCvwf/x4IwQhKcIIUrKAF21E3BgIQexfrlwYrYEANsMuBDaRW5ggIwvRdcIUsbKELXwjDGMqwExBzHQnVZz7acTCFORThAF/nww/OcIhELKIRj4jEJCpxW7NbXvze9zylqZCHIfza/ghRWMAnLnGLXOyiF78IxjAOsYnQmyIOd3hAIV6vilZEoAmdeEMxynGOdKyjHe+IR8H10IZv3MAey6jFv6Fxg38MYhzziMhEKnKRjGykI5lVSDgeUpBmFGAl1xjIEmZSk9p6pCc/CcpQinKUpHRUFE8wSEyq0Y+XnF4qCflKKmKxlLSspS1victc6tJIp0TlJikXS1auUn6TlOUwy/fLXSpzmcxspjOfCU3+sFGKyTxhNWFZzM61EpvHRGY2ownOcIpznOQspzl9M01qfjN31+QmEN3ZR0BuE55+O6c974nPfOpzn/xkTDAt2U12rtOQs4TiQA16UIR2sp8MbahD/h8K0YhKtCn/TGNCKyrMgFozoaqMJx8XOtGQinSkJC2pSU+6kHnqUKPV42gWWao6mHb0nZL0KEpvitOc6nSnPO1pMlTKvou286VClelMQfpRa/l0qUxtqlOfCtWoKgKoAC2qSzsIU6p606iUtKlUvwrWsIp1rGQtKxO5itWCuvKqafXqGd26UrYSk6Zmratd74rXvOp1rxula8OqOdQ2HlSrb/VrUNXK18QqdrGMbaxjyRlYoiKWAZFtK1yPKrHKUlazj+2sZz8L2tCKFoac3epktXnapNbTmEhVZ2ola9jRyna2tK2tbW+rvdIWtrW7XS0LCKtbgV72sLHFrXGP/ovc5Cp3uT0LrkJ5y0nf2guwaO1qcS16XeZqd7vc7a53v6sr5x5VutGNAXCrO1fo1lS94G2ve98L3/jKV3FypSd5n3vfzLJUvC19rWXZO98AC3jABC6wgbfEX+sCWMH59eV+0btZCKN2uAeusIUvjOEMazhFCU6vUk2bXddS2MP6rW+E/bvhFKt4xSxusYvj0+ETo7i/IVatYEecURznuMYv7rGPfwzkIAtZODGesI6BOeOqJjnBHS7ykJ8M5ShLecpU1ouThcvjlUm4tw1mcImPfOMsV3nMZC6zmc+MZq9cWcsPNjGIxUzjBWNXznP+cJrvjOc863nPfM7JmvsK/ueYgnm9dDZyocN8aETbuc+MbrSjHw3pSB/kz3FONJuTXOdF4/fLgX6zpiUN6lCLetSkLjU1KC3oQQP60w4e7JaxzGriWtrUtK61rW+N61xrAtXndTOXFd3lTP/V17outrGPjexkK5sLvKYusfEbbBl3urycnvWyr43tbGt729y+AWF3bO1Kx5oE12Tyq2Ed7W6re93sbre7323ocBNU1aset42BXW17g1vf8O63v/8N8IBD+tvATne8+R1XTJv72Zemt8AfDvGIS3ziGiY4bDtt8f/Ke+GY7i3FPw7ykIt85PDF6LynbfKC79vgF0d4y1lO8pjLfOY0rzlYU/5y/pij2+Ur13nDp73pfPvc5kQvutGPjnR8pvPeBee5yk/udE8PXepJr7rVr471rDNz6YSWd6o7LvWoi1vowwa71s+O9rSrfe0r7GXKhup2l8H93PUuu8PZjve8633vfAde3EV8d3EDHdpTH3urA0/tvit+8YxvvOMLF8mEI/7rDBe8kge/1slj9vGc77znPw96kZGx62Kvt9k9XHrDv73yqg+9618P+9jL/lijlzXma395zXNc85nH/Ox/D/zgC3/4g2od4G+P+54Xvu6H972XiQ/96Et/+tTH0xV5b/rl193NOEc32b9f/fCLf/zkL/+Uro99rnscvepPvNxZT3nt/pt//vSvv/3vjyF5cfXv+KZ87k/feuRGd8yHfwVogAeIgAm4IPdSbu3ncQHIWgAIgUlld86ngBeIgRmogRvYHAwIVMmncX5TUSBIT+C3ehLIgSmogivIgi2YGgnTfsbXdT83WTIoeV4XdM2Hgy7Igz3ogz8IhIkBP3v0OBRIg7pThPKEfdK2g5sXhE8IhVEohVO4F3zTNxZIgNn3NALIek02gFQIhmEohmNIhjYxN1d4gl51hfLHhKnnhGmIhWUoh3NIh3VohxexNHSjg5qWN3vIhiRmgncoiINIiIVoiA0RNGcTiDt3MotohH54iJEoiZNIiZWIQR/ENPGCiUij/old+IXxZ4mhKIqjSIql+FNqFDO/hYoso4qeCH+oZoqxKIuzSIu1iAeZZIPTlU25aIu96Iu/CIzBmFJG5Yb/t3zFKIzJqIzLyIzNmA2w+IjOKI3TSI3VaI3mAI1KGIfXyI3d6I3fCI6mkI0zGI7laI7niI7pCArjeIPIqI7vCI/xKI/zKAbsaHt/SI/5qI/7yI/92AP2aIz+KJADSZAFaZA1AJDCdpALyZAN6ZAP+YZMkJAQSZEVaZEXGYkTCXX4iJEd6ZEfCZKHqJH9F5IlaZIniZKSOJIvl5It6ZIvCZNRuJIhGJM1aZM3iZMGOJMlmJM96ZM/CZSzt5MRyJFB/mmUR4mUSUlxQ0l1SumUTwmVUSlyTPmAUmmVV4mVWaltVOl+WumVXwmWYTlwn6iLKCiWZ4mWaamWBMaVObiWbwmXcSmXBdaWETmXd4mXeamXt1WXvdeEewmYgSmYg8lTffl8hImYiamYi7lThgmIjAmZkSmZk5lPjtmGRUmZmamZm8mZYGSZB9eZoSmao0madfSZSLaEpamaq8marbk9p+l9rimbs0mbtek9sHmEmGmbu8mbvembvwmcwSmcw0mcxWmcx4mcyamcy8mczemczwmd0Smd00md1Wmd14md2amd28md3emd3wme4Sme40me5Wme54me6ame68me7eme/u8Jn/Epn/NJn/Vpn/eJn/mpn/vJn/3pn/8JoAEqoANKoAVqoAeKoAmqoAvKoA3qoA8KoREqoRNKoRVqoReKoRmqoRvKoR3qoR8KoiEqoiNKoiVqoieKoimqoivKoi3qoi8KozEqozNKozVqozeKozmqozvKoz3qoz8KpEEqpENKpEVqpEeKpEmqpEvKpE3qpE8KpVEqpVNKpVVqpVeKpVmqpVvKpV3qpV8KpmEqpmNKpmVqpmeKpmmqpmvKpm3qpm8Kp3Eqp3NKp3Vqp3eKp3mqp3vKp33qp38KqIEqqINKqIVqqIeKqImqqIvKqI3qqI8KqZEqqZNKqZVqqZeK/qmZqqmbyqmd6qmfCqqhKqqjSqqlaqqniqqpqqqryqqt6qqvCquxKquzSqu1aqu3iqu5qqu7yqu96qu/CqzBKqzDSqzFaqzHiqzJqqzLyqzN6qzPCq3RKq3TSq3Vaq3Xiq3Zqq3byq3d6q3fCq7hKq7jSq7laq7niq7pqq7ryq7t6q7vCq/xKq/zSq/1aq/3iq/5qq/7yq/96q//CrABK7ADS7AFa7AHi7AJq7ALy7AN67APC7ERK7ETS7EVa7EXi7EZq7Eby7Ed67EfC7IhK7IjS7Ila7Ini7Ipq7Iry7It67IvC7MxK7MzS7M1a7M3i7M5q7M7y7M967M/C7RB/iu0Q0u0RWu0R4u0Sau0S8u0Teu0Twu1USu1U0u1VWu1V4u1Wau1W8u1Xeu1Xwu2YSu2Y0u2ZWu2Z4u2aau2a8u2beu2bwu3cSu3c0u3dWu3d4u3eau3e8u3feu3fwu4gSu4g0u4hWu4h4u4iau4i8u4jeu4jwu5kSu5k0u5lWu5l4u5mau5m8u5neu5nwu6oSu6o0u6pWu6p4u6qau6q8u6reu6rwu7sSu7s0u7tWu7t4u7uau7u8u7veu7vwu8wSu8w0u8xWu8x4u8yau8y8u8zeu8zwu90Su900u91Wu914u92au928u93eu93wu+4Su+40u+5Wu+54u+6au+/uvLvu3rvu8Lv/Erv/NLv/Vrv/eLv/mrv/vLv/3rv/8LwAEswANMwAVswAeMwAmswAucHbwIBA7MwBEswe/KlKn4AxY8wRmsweeace/HiTnQNRsswiPMrd0Hh0ODA4pIwivMws/KfzOAhjAMOC1MwzU8rJEHA2uom4T3wTbswz98qyTYAjrsjmEXwkCMxEncqhD8AkS8jainh0osxVMsqjVkA0xsxZ34wllMxV3sxZSahDLsgEJsjDpGxl+Mxmnsp41IAy/MYKmJmgGFw2pMx3Vsp6woxr3WwVAcdW5sx38MyG3KOdDoxzzswXO3x4GsyIsMpVFEyCYseLrpgH75/sSMbMmXDKSnBIuTTMlxyMlvXMSYLMqjnKO9tMmJHH9/mX3aaJak7Mqv3KJu12y6Bcm5GcqpvMOwrMu7/KFVNMuvVsuRzIVkycvFbMwPyn+UFsxxzHvLzIjHDM3RvKJbTMw754dsiMrMrMrSzM3dbKDp9GfOrM07KM7P7M3njM4XikbhnM3jrH3lbM3pLM/zjMybCH/uXIGD1874TM/97M8HWoPVLMxCV3rwbM7/jNAJ3Z8htmb7fHCF59D8rNATTdH1yW8NXWQEF9HxXNEd7dHsyXIYTcw4t9G2nMsfjdIpPZ1XZtAP3XSteM8qLdMzfZwsbdNtFtOWR9M7zdPj/nnTOZ3KT1eWrdzTRW3UvPnTRI16Qq3FSn3UTw3VqulkLX2ZOkfVLh3VWa3VNV3NJY3VRHnSX73VY03WSN3V7CzHaA3UZc3Wbb2WU63WKObVEu3WdW3XnAnXAq3TYN3EuHnXfw3YGJnXax3U9tXXeh3Yia3YPjnYTv3Ghn3YhL3Yk03ZLZnRc03XhJfDfl3Zne3Z6njZyoyLmM3Rn23apw2VoY3Yhc1lYS3WqA3bsf2Tqu3Yjx125sXZsq3bu+2LtA3H0RXSv1zbvE3cxQ2Pvl3JnRzcq83axu3cz12RyL3Nt03dkT3c0I3d2S2N0n3LwM3Xm83c2i3e4y2L3O3a/q89Xrgd3uTN3u1Nieat3rso3L/t3vVt36MI3+At38xN2vft3/9dh/lt3WDW37YM4AeO4MEo4MUy2vyd2wkO4RE+fQs+xA0u2c0t4Rmu4Rk50vPNYwVuejQgACNO4iVu4ieO4imu4ivO4i3u4i8O4zEu4zNO4zVu4zeO4zmu4zvO4z3u4z8O5EEu5ENO5EVu5EeO5Emu5EvO5E3u5E8O5VEu5VNO5VVu5VeO5Vmu5VvO5V3u5V8O5mEu5mNO5mVu5meO5mmu5mvO5m3u5m8O53Eu53NO53Vu53eO53mu53vO533u538O6IEu6INO6IVu6IeO6Imu6IvO6I3u6I8O/umRLumTTumVbumXjumZrumbbuRBQOEw/VogvtcxwOmlbuqnjuqpruqrzuqt7uqvDuuxLuuzTuu1buu3juu5ruu7zuu97uu/DuzBLuzDTuzFbuzHjuzJruzLzuzN7uzPDu3RLu3TTu3V7uye3uEOfkyijuEvYO3fDu7hLu7jTu7lbu7nju7pru7rzu7t7u7vDu/xLu/zTu/1bu/3ju/5ru/7zu/97u//DvABL/ADT/BVju0xze0qlfDZWPAN7/APD/ERL/ETT/EVb/EXj/EZr/Ebz/Ed7/EfD/IhL/IjT/Ilb/Inj/Ipr/Irz/IxfvDX3e1DTeAePt0W0PI3j/M5/q/zO8/zPe/zPw/0QS/0Q0/0RW/0R4/0Sa/0S8/0Te/0Tw/1US/1Pv7y9J3ZoD7z2n7hBzD1Xe/1Xw/2YS/2Y0/2ZW/2Z4/2aa/2a8/2be/2bw/3cS/3c0/3dc/nVZ/cBq7foU7z3b0FKL7hgS/4EPfpMv/hfX/eVAD4g8/4je9u5p34et/ae2/1WbD4jo/5mY9tkE/5hy/a680El6/5o0/6udbYlb/U383goL8Eol/6rw/7onb6eV/VkL36W98Erh/7u8/7fTb7NT9eMAfiV30Fut/7x4/8Zvb7fm/bqo/1tF/8J57800/9Y7b8kT/qv3b7MF8Fxl/93w/+Lnb9/gMuZsP/4N4u/eGv/uu/YuO//apm/qzf+unP/vVv/weW1Kh/9d5d4fKvBN5PAPMxdbn9YZSTVntx1pt3/8FQHMnSPNFUXdnWfeFYnunavvFc3/ne/4FB4ZBYNB6RSeWS2XQ+oVHplFq1XrFZ7Zbb9X7BYfGYXDaf0Wn1mt12v+Fx+Zxet9/xef2e3/dDAAIFBVsGDQEKDwcxFAlZGh31BCYpBf4uMTM1Nzk7PT9BQ0VHSUtNT1FTVVdZW11fYWNlZ2lrbW9xc3V3eXt9f4GDhYeJi42PXyETG5cVMyARH5X5KimRr7Gztbe5u72/wcPFx8nLzc/R09XX2dvd3+Hj/uXn6evt7/Hz9ff5T6ZXoDU79OyfioDUqlnqt5BhQ4cPIUaUOJFiRYsXMWbUuJFjR48fQYYUOZJkSZMnUaZEWTAFtGgGWVJwKY0ZwmoqcebUuZNnT58/gQYVOpRoUaNHkSZVupRpU6dPoUaVOlXgoqpWWx5kFLPETJuVqIYVO5ZsWbNn0aZVu5ZtW7dv4caVO5duXbt38eZFw9Uf3xFat9bMKnhPQoV6ESdWvJhxY8ePIUeWPJlyZcuXMWfWvJlzZ89J/HYNHQLwhdImTuMx/Jl1a9evYceWPZt2bdu3cefWvZt3b9+/gY8bTSL13+GAjncobmd1cOfPoUeXPp16/nXr17Fn176de3fv38GHP5KcNHkNy2WaJ0i4cELx7+HHlz+ffn379/Hn17+ff3///wEMMAL1PEDvAwMlQFA5AttoTsAHIYxQwgkprNDCCzHMUMMNOezQww9BTM+ZFxQ8r0Tk2BPBqz4cDNHFF2GMUcYZaazRxhtxzFHHHXns0ccoGFwwxfKGDGxE0YpUzb0fmWzSySehjFLKKams0sorscxSyy3ZCZKDFVU8EcUkvxQTjha5TFPNNdls08034YxTzjnprNPOO7fzskwyNzBzzIGI03MNNPEs1NBDEU1U0UUZbdTRRyGNVNJJ1RDUREsXAFNIPo080g9CKQ1V1FFJ/i3V1FNRTVXVVVlt1VXaMF2P0wo0LdDPB2r9yppXee3V11+BDVbYYYkt1thjkU2Wjlg7BfTAW/901lZmzwBV2WuxzVbbbbnt1ttvwQ1X3HEzpNY0aDNFN1pDnjXXDGvJjVfeeemt19578c1X33357Tcedy3INWCBp511XXYzgdffhRlu2OGHIY5Y4okprtjiiw8AmFaCE+R4U4MbcOklTBTG2OSTUU5Z5ZVZbtnll2GO+TuNN/aYAZFHRvJWnDkpWeafgQ5a6KGJLtroo5FOWml1aK7ZZgR4hklkEdU9c8mlsc5a66257trrr8EOW+yxdUa4BpwDwRXtnPuKOuS1/jvxmey56a7b7rvxzlvvvfnuO86mB15bcE+lHtzwtOO+2u/FGW/c8cchj1zyySmv3DLAAz9ccBg0N/wTuS0PXfTRSS/d9NNRT1311XfBPPPOq94T9tjlAJ3123HPXffdee/d99+BD34C11+f3WwZjCe+DNuFb97556GPXvrpqa/eenCVL954HJI//nPFrw9f/PHJL9/889FPX30Ps9de8x26Z/v7m9av3/778c9f//3579//tdp3rs79YHanYN7/EJhABS6QgQ104AMhGEGJDK4IFEzFASWYQQ1ukIMd9OAHQRhCEboBcVIooSswOEIVrpCFLXThC2EYQxnOECIp/qThDXGYQx3ukIc99OEPgUgGGwaRiEU04hGRmEQlNikATVziE5cyRChOkYpVtOIVsZjF3zSRi1r0Ykqk+EUxjpGMZTTjGdGIFC6uMY1tpEgY3RhHOc6RjnW04x25sUY94pGP8oBjHwEZSEEOkpCFNGQZ9JjIQy6yG39k5CMhGUlJTpKSlZxAIjFpSU3qwpGb9OQnQRlKUY4yiJg0JSlRaUDwpZKVrXTlK2EZSwSakpaytCWLVnlLXe6Sl7305S8fR0thApOYauhkMZGZTGUuk5nNHJcwoelMaV7hmNO05jWxmU1tblNO0PQmN8FJhGqGk5zlNOc50ZnOAHmTnep0/mcMxvlOec6TnvW05z05w0594pOfHohnPwEaUIEOlKAFFYo+EWpQhS7gnwt16EMhGlGJTvQcCLUoRQnaUIxulKMd9ehHQfoJi440pPbUaElRmlKVrpSlLXXCSGHqUnSeVKY1telNcZpTnVIApj3dqTZp+lOhDpWoRTUqQXua1KM2M6hLdepToRpVqf4yqVWdKjCbelWtbpWrXfVqH6sa1q/aMqtjNetZ0ZpWtfYwrG1dayrL+la5zpWudbXr/tqa17t6Mq579etfARtYwaYur4UdbCT7eljFLpaxjXVs1gob2ccSMrGTtexlMZtZzfIrsp3d7B0r+1nRjpa0pTUt/qs6m9rTtjG0q3Xta2EbW9lyKbW1na0YW3tb3e6Wt731LYZqG9zfVjG3wzXucZGbXOVSJ7jNXS4Si/tc6U6XutW1LmSam93r+jC62/Xud8EbXvEuJbvlHS8Nu3te9a6Xve11r0TKG9/3sjC987XvffGbX/1mI7793a8H6/tfAQ+YwAU2sEj7698DPzDAC3bwgyEcYQlzIcEJnnACG3xhDW+Ywx32sAwqLN8P5y/DIzbxiVGcYhUjIMTOXbH6SvxiGc+YxjW+b4tVa+PyxVjHPfbxj4HsWxx7NsjX43GRkZxkJS/5sEMmMpOjd2QoT5nKVbayU52c4ysLT8pb9vKX/sEcZopmWcti5l2XzZxmNa+ZzeEks23bnDs0x5nOdbbznV35ZjjjOXVz5vOfAR1oQeNRz9od9Oj8fGhFL5rRjUZioUXs6MglWtKVtvSlMc1BSFc404yjdKdBHWpRj5p8m8YxqfH2aVSvmtWtdnXpTJ3lV49N1bO29a1xnWuwxfrNuuZarX0dbGEPm9gm4/Wmi400YCeb2c129rPBdexYQztoy6b2tbGdbW2bCtIHkDYbt80ya4eb3OU297nb1O0EfLuL6MbYuN0db3nPm94zUjcD2O3EekcM3vv2978BHnD93NsB+da3wPnVb4QvnOENdzhwCB4Bgwfg4fdSeMUx/p5xjW98MhG/pGQHIFyOj+viIzf5yVGecrJ43AKGZfGeVZ6tksec5jW3+c1VwnIMuFUBIsf5sWb+c6EPnehF34fON2BVfMPc6L4KetOhHnWpT10bSO+ATx/gc6qv6ulb9/rXwR52VVgdBCSVONPFLqqup53tbXf72+VAdhEk9ONlhjuk1n53ve+d732HgtxL0M6Wo93vhsp74RGfeMUv/gWAP0E0d054xsvp8JO3/OUxn/kGOF4FtdSA1jXvpsqHnvSlN/3bOc+CTF5d8qe/0uhdH3vZz/7mqW88uD0AetpTCfa79/3vgS9w28eg3WVvffB91HvkL5/5zYf28K2g/nvn60j507f+9bGPauhjQfrZn1H1vR9+8Y+fz9vfgovJHyPwp5/97Xf/lM3vhe6/P0Prp//98Z//E8c/DPPXv4Ts7/8EcAAJ8L/4jwz8rwD9IwAVsAEd8AGr6wDPIAEh8D4YsAIxMAM18LUkMA0ocAPh4wJBcARJsAQHqwPb4ANNkDtEcAVd8AVhsKtQ8A1UMAarowVtMAd1cAdtagbj7vh4cDpwMAiJsAiNEKJ8sA5q8Ah3YwiZ8AmhMArTKQnxYAmlkDac8Aq1cAu5EJmoUA+ssAtbIwvFsAzN8AxD6Qv9IAzRMDPIsA3hMA7lEJDU8BLYcA4l4w3xcA/5sA+z/qgONeEO/XAx9HAQDfEQEXGHALETBDER7aIQHTESJXESN2gRQaERKfEtIDETObETPdF+LFEU0O8TEWMTSfEUUTEVhScUTQETVTEsTPEVZXEWaTF0WBEVXLEWnSIWdbEXffEX5+YWWSEXgdEoeLEYkTEZlVFohNEViHEZf+IYoXEaqbEaI6YZY+EZrREnpHEbvfEbwVFcsJEWtDEcR6IbzTEd1XEdfWUcb6Ec2ZEj0DEe6bEe7fFR3DEX4PEeK2Ie+fEfATIg1yQfe2EfBbIh/PEgFXIhGZJHCPIXDLIh8yEhJbIiLfIigavQGiIiMdKPcqkjQTIkRdJVHtIYOHIk/tWBIlFyJVmyJaWjJK/hJF1yHFRyJm3yJnHyNWCSv4DQES2ICDYHHGoyJ4myKI3yMXayG2SSCQuIgAaokT7yKKVyKqnyQ5LyG5YyCOPnhGxgK7dhKKsyLMVyLKHiKsUhK3NwK7HibNRSG8CSLOEyLuWyJ8yyHNDyBdVSWjgnLyPhGN5yLgEzMAWTI+oSHe6yBPmScK6iLZHhLwfzMSEzMvmhMNVhFOEwMQNoADDTe4bBMSXzM0EzNA1TI4HiMDPwfTLGcwBiM/VSGDxTNGEzNmXzGCgzHkwTAuFmQHJzMNxGAX6yM6NyNoVzOIlzKmqzHm5TAdFGgGhHN6emY3oz/hheszipszqtMxSO8x6ScwCj02kwpzud82luYTqvszzN8zztIDv1YTv17zllB2SY00vAsxfIEz3t8z7xcwzUsx/Y8/7EEzo1Zj6pBj5noT7z80ARNEGfYD83sid38D+Hpzl9E0IdgEJlwUAVNEM1dEN5gEEfoj/Zz0IBVDHfk0SbpTV5AUM5dEVZtEVRwEMnAkTHT0LThUDD00RlxUZfQUVdtEd99EcrAEYrQka9T0QjlFqMVG0y8w94FEid9EmBVEgxgkixj0ZvBkmtNDWXFJfoB0q99EvBNA+kdCOodPqydEJjJUkPpi9TNDjD9E3hNE7ljzTzokyZ70xrFEe9/pMziURPbaFJ5TRQBTUyxzQk7BT58BRN/XREURQE1PSC3HRQJXVSKbVD6bQxDvX3sid2HvVG+RQXALVSRXVUZ7JQUSJTaS9R87RRB/RT+5RV/zRSSXVWabVWP+9SOw5VY09VV3Ut4xNW20VHVyFUbbVYjdUeTZUndPX0eFVRgVVJFzVYn/VCZfVYrfVaRTVZf2JZSy+A1KVZtTRaY4FYsbVczRUYtTUoLPM0vVVPwNUAOrUUyPVc6bVeTzFdi4JbMe9doUY++VUztzQP5tVeCbZgExFfj0JfLe9fw3Vae9VXUYBhuRQsDLZiLfZAEZa8HPT/JBZghZVhO7Y9uvRi/km2ZIszY5tCYRWvY6EFZANWSUbWZGV2ZgkVV3tDZRGPZRkkXvcUYmM1Zmk2aIV2LFGWKnC273RWR5NWXFGoWof2aaF2JIt2LI5275bWYRPgal21QJ02ar32axdyasuiau9Oa312TeUnYl+WOboWbN32bdlRbNOCbN3ObM+2QjMzZAW2beG2b/2WGuV2LeiW7eyWTT31blFjbetgYP+2cR1X8wLXLQZX7CTWPY+UaV91a8eVbx+3cz3XEyM3LiYX7FzWTHjWfbjyZyn2c1m3dVExdOlidL2udNXjdHvWcGuBcV13d3m36WDXLmSX6miXQG23VRF3c4G2d5V3edvw/nf1Inij7l8F9EqF9WM0FxZ0l3m1d3srznkTA3qbrnjxlkL1Vm/vIHu5N33Vt968lzHWNf3edTmNF3cLB2tZAX3XN3/1d9vaFyk31vrE92Ex12MH2FEVdw7wd38VeIGJrX8lA3yHLoCzVn4v134z93ixl3MZeIM5ePocuDIg+OckGF53k1ExuGyud0c1uINZuIVl74MxI4RvboR/83DplzctWBUS2IV5uIcHDYY1Q4ZtToJrGG1jwHzZNnl9eImZGPOA2DOEmOaKlxlMd0uReHFXuIm1eIu/7olZI4pVznL7hIpr14oPuHaymIvVeI2Fzot18n8RVYx/1RGquHpL/vSEm1aJ2XiP+bjo3Fg2wBjlphdanaWOC1haUxgKDGORGbmRHfmRITmSJXmSKbmSLfmSMTmTNXmTObmTPfmTQTmURXmUSbmUTfmUUTmVVXmVWbmVXfmVYTmWZXmWabmWbfmWcTmXdXmXebmXffmXgTmYhXmYibmYjfmYkTmZlXmZmbmZnfmZoTmapXmaqbmarfmasTmbtXmbubmbvfmbwTmcxXmcybmczfmc0Tmd1Xmd2bmd3fmdMxnS4Hme6Rmdg6ue8Tmf9Xmf+bmf/fmfzxkKgtKGzcaQcxiR8fgJAHqhGbqhHfqhITqiJXqiKbqiLfqiMTqjNXqjObqjPfqj/kE6pEV6pEm6pE36pFE6pVV6pVm6pV36pWE6pmV6neV5pm36ne/5pnV6p3m6p30apIEENQmYgoc6kRvWqMPEjo/gp5m6qZ36qaE6qqV6qqm6qq36qrE6q7V6q7m6q736q8E6rMV6rMm6rM36rNE6rUm6ptW6rUs5p906ruV6ruk6n02INX2VQMr3jFWgrv36rwE7sAV7sAm7sA37sBE7sRV7sRm7sR37sSE7siV7sim7si17rQvtsusarjW7sz37s8GaCvBagNN2fA+5YA5aCUB7tVm7tV37tWE7tmV7tmm7tm37tnE7t3V7t3m7t337t4Ebotk6uK2as4n7uJE7/rmhuQo2k3pzeK+V2giUe7qpu7qt+7qxO7u1e7u5u7u9+7vBO7zFe7zJu7zNu5eH+7xf2rjVu73dO7ivIC9NG6lJOLpzlL51OI37eL/5+9z+GDsC2eTiZ01Rt7TV1r5FYYf7e8EZvL3+Wzve9/pgh6AN3LlP+45vmFr1uME5vMOv7cG9I8AFmagpvMArHIUT+n7128NZvMVJDcTBQ8Tr9mOX9IrpQMFdPMd1HLZg/D0inF1PO2RtHIFXfMeN/MjxrMflQ8Ypl8YR/HYzHHlXF8mpvMoZTcnrg8m/rmXzlq/jAMetPMzFnK6wHD+0XHiDpHBPPIM3fMzd/M2rrMz3/uPMpc5fn3x+U1d1dwXO+bzPoUzO+4POw9fOL/xSCt0UwNzPFX3RbwrQ1wmO3+9b2/XOQSHRGf3SMT2kHP1BBD2C3bV9RngTLD3TSb3UH2rTJaTTca5qhhe/h7XITT3WZT0CbdZYVL3mWB3UvfzLYX3Wff3XhazWk+XWYy7XN3XXrabNgX3ZmR25UJ1DiH3E7ZtfQ13Ue73ZsT3bL+vZQSTaR452qB3Zk33Ktb3czd21uN1FvF3jmjPcKT0URv3c5X3e01DYnwnSzZRZ4lfc3yDe6f3fAR6S0r1G1t3haBRchzyJyT3gGb7h32rgcaTgGe7gXSfhsVjZHT7jNR6q/iBeR34cgN2FV6u9Z659403+5D+q431E4v9NfEWe38d9z1F+5mkep1SeSVi+3gKYhi3+4he+5oE+6FPe3iUm5+WNiGmm531e5oW+6Z0+om5+Sowe3XgeYEY+cTD+6bV+6+Up6q1k6sut2qdY6Zd+Erj+7NGenrw+S8Be2+T4glOcwtc8d0s+7e3+7mNp7WkL3/f16k/36j3B3/F+8AlffPReTdr+2QbZgDHl7ds06ws/8iUflQ7fTRI/2Raf8QXF8R//5yf/80G/3vVMay5/0ea+gid9Zzi/85k+9F3/9SWp8umk9A8t7kk7tTHcfjM/FwQf9n3/9xlH9u+E9gOt/oCLmCZWv6jJHmY9H/id//nTSPgNhfj/jMQnfAbw2vbpHvKhv/u9H4qkH1GoH8+yP8pXc7T9su6/f/3Zv4XCn1HGn87K//TrV76voffbP//1f2Xe31Hiv80IAD6mLts8jHLSam/L+tzuPxiKI1manZCqwtm6LxzLM13bN57rO9/7PzAoHBKLxiMyqVwym84nNCqdUqvWKzar3XK73i84LB6Ty+YzOq1es9vuNzwun9Pr9js+r9/z+/4/YKDgoEuA4SFiouIiY+MhIWSk5CSRo6UjZabmJmen5yeo3caohhTpKUBo04qKqusrbKzsLG2t7S1uru4ub6/vL3Cw8DBx/rHxMXKy8jJzs/MzdLT0tOel9XUjtfa2JDY2N3i4+Di5MOp5KhV6QzkFa0p7vPw8fb39PX6+/j5/v/8/wIACBxIsaPAgwoQKFzJsyMUbxG8OJy6MeIkixowaN4Zaxy6LRw733rHgaPIkypQqV7Js6fIlzJgyZ9KsafMmzpw6d/Ls6csi0Gw+h/IKioko0qRKKYYEc24fyaVSp1KtavUq1qxat3Lt6vUr2LBix5Ita7aZ0bSPzrJ9o1ZR27hy5/YR+cZBwKh09/Lt6/cv4MCCBxMubPgw4sSKFzNurOltWseSf0BGNPky5syI9Wru7Pkz6NCiR5Mubfo06tSqV7Nu/u2yclDXrGEbkm37Nm6AnHPz7u37N/DgwocTL278OPLkypfrom2R+WXn0KdTr75nt/Xs2rdz7+79O/jw4seTL2/+fCbnEdEDls7+Pfz4ILDLr2//Pv78+vfz7+//P4ABCpiMehANOJZ7Byq4IGv0MfgghBFKOCGFFVp4IYYZarhhWAV6w2FVCYI4IolfOVgiiimquCKLLbr4IowxyjgjjQ94KFGNN4mYI489KnSij0EKOSSRRRp5JJJJKrkkk/LceE2TLe0YJZVVCgOklVlquSWXXXr5JZhhijnmiE9aQyZFU6K5Jpt2YNkmnHHKOSedddp5J5556lmRmZbsSZCa/n8KOigRbxJ6KKKJKrooo406+iikkUrQp5+S3hOopZk+aqimnXr6KaihijoqqaWa2hqlR50qDqarujomp6/KOiuttdp6K6656rorM6kKxeszrQI7LI+xEnsssskquyyzzTr7bLO+MgItgbRRe+2IxmK7LbfdevstuOGKOy6E0i5C7i/Corvue9qy+y688co7L7312nsvVubChW8t6vH7b3buAjwwwQUbfDDCCSu8cHr6WsZwKOpCPPFoAlN8McYZa7wxxx17XLDDD39MicQjmxyYxServDLLLbv8MswxexnyWjIHUrLNOWeVss49+/wz0EELPTTRxNFcW9F64Jw0/tMy8dw01FFLPTXVVVt99UpHB4C1HEtz/TVCT4M9Ntllm3022mmr/YfWa6/htdtxjyO23HXbfTfeeeu9d91t8y0G3H8LPgzdgxt+OOKJK7444+L63bgWgUM+OSiFU3455plrvjnnnXf5uOdSSB466XhYXjrqqau+Ouutu+4d6K8rMbrstYNxuu2567477737/vtXsQMfBO3DG48E7scrvzzzzTv/PPTUCB+9DsVTf/0LyWO/Pffde/89+OF/Mb34MVhfPvrao78+++27/z7835Mfvwnn03+9+vfrvz///fv/f97mB0AQ2G+Aw8ufAROowAUysIEOhJgAH1iBAkpQ/nYIrCAGM6jBDXKwg6uKoAcH4K8QLu+CJDwhClOowhWyMEkgTCEFWzg5E8qwhja8IQ5zqMP8vHCFMdzh4GgIxCESsYhGPCIST9NDGY4wiZwTohOjKMUpUrGKVrzKEm/4wyuWDYpc/CIYwyjGMZLRH1nU4RbLSDUvqrGNbnwjHOMox1iccYhpnKPQ2IjHPfKxj378IyC3UEcj3jGQMdOjIROpyEUyspGOtMAgkVjIR44MkZS8JCYzqclNFjGSUpwkJylmyVCSspSmPCUq9edJKoIylQYbpStjKctZ0rKWrlvlFVtpS3vBcpe+/CUwgynMtOESjLocJrp6icxlMrOZ/s585seKOcZjQpNbyqwmNrOpzW1ys1vSLCM1u8msa4qznOY8JzrTaalvvjGc6twVOd8pz3nSs572tBI74+jOe8oqnvz8J0ADKtCBViifeNwnQUXlz4QytKEOfShEtWPQPiI0opFaqEUzqtGNcrSjnZkoICvqUURhdKQmPSlKU6rSrYDUkE1c6a1KCtOZ0rSmNr1pmo6GTJHitE0y7SlQgyrUoRI1Gi19JE+L+qWfKrWpTn0qVKNKMp1WM6lSjRJTr6rVrXK1q159CFWzadWvFimrZD0rWtOq1rUWIqzcHCtba2TWuNK1rna9K1SP6kq44pVFc+0rYAMr2MFCVK+z/uQrYUH018QytrGOfWxV3SpPxEK2QoutLGYzq9nNXtKwwKQsZxV02dCStrSmPS0XPStM0KK2P6NtLWxjK9vZelC1y2Qtbevz2tzytre+/e36bOtM3AK3PLstLnKTq9zl1k64kYUNc/36juhSt7rWvW5wJatR4mKXOsftLnjDK97xQs254uQueY3z3fSyt73ufa/GzGtO9MLXN+utL37zq9/9jku+6aQvf11z3wATuMAGPjCt/DtZayEYPwNuMIQjLOEJC0rB9QQwhT3z4AxzuMMe/nCULHzPl4L4OxsuMYpTrOIVl0m7TcUwiw1z4hjTuMY2vrF9RExQGOPYLzPu/jGQgyzkIRtHxw7lMZHZ8uMkM7nJTn7yR13cVSRDGSxLrjKWs6zlLZvFyNtlMJcFPN0wk7nMZj6zEqWsViqjWSlXbjOc4yznOR/EyydlM5138uY887nPfv6z9NRsVzwDeiZ7LjSiE63oRcvCzjQlNKNVcuhIU7rSlr70HRxtU0hjOiOT7jSoQy3qUVdB0z3lNKl/NOZUs7rVrn41JEwtVFTDOi+rrjWuc63rXY9B1kWlNa/z8elgE7vYxv6zr18M5mNfZdjMfja0o/3kZEcV2NIOh7Ovre1tcxvE1L6qtbstjWyLu9zmPjd8v81VEqObJuRuN7zjLe/iqvur4Z43/jHeje9987vfla03Wu/t717oe+AGPzjCAy5o6go84bUouMMjLvGJ4xTgdW04xV0B8YxzvOMef6jF74rxj3Ni4yQ/OcpTXs6QB3bkKoeEyV8u85nT3JYsH6zLa+6HmOu85z7/OSNvzticA/0OPC860pOu9GkunL9EX/objg71qVO96jkUemafbnU0SH3rXv862CWI9c1qPexh6LrZ0672tbNv7KUtO9uzgPa4073udj+e208L97tLYe58/zvgAx+6vMN274Jfgt8Pr/jFM55vhJ+t4Rs/hMRLvvKWv/zVHs/byGOeB5TvPOhDL3qZad63nM8sOq6ACqjcevSufz3s/l9XeuSenrEhSQAUbo+Pz8e+977//b1mr9zaC/b2DFiC8XFPD94Dv/nOfz63hB9ddq84+RlAgvWVLw/mQ7/73v/+rqRvXeLTNfsbIIL5F7D91oO//e5/v8/E313yqzX9pAiC/dXfDu7Dv//+//+hyJ940R9Z5d/9+YAB6h858B8ANqADPiCaCGB6EWBXeYQENMUOJOBHzA37QaAHfiAI9lfT0RkFatUpjMDq6UAKUsBTcCArhCAMxqAMPosE4lcJQtUBlsAJ4kAOesAOYlsHzqAQDiERftAIFtoNNtUowEAPzsASkkATagMDFiEVVqEV+kcNElgSEtX5OWEp1MAT/upgF4LDFF6hGZ4hGpJHFh7YFgbVF9LAGMZAGJ5AHEphEKYhHuahHmrJGkJYG+LUG4Lh9XnhIL5AINrhC+6hIi4iIyJJH0rYH9pUId7AIbZAHVpiJY7bHTYiJ3aiJ5LII3JYJMJUJhLi8cnhJDJhKT5DGX6iK74iLApGKHrYKKpUKlLiBrrAKmJiLk5DK8YiMAajMHbIEeZaLZ7ULspAMoLAMppAMybDLw6jNE4jNSLFLK7YMXrULeJiL4phNyrjNrLiJlYjOZajOf7GNdJYNnJUONpAO4bAO6riKVJDNJ6jPd4jPvIJzcAb9YlXPJqiAujiPwrkNzpDPeYjQiak/kJeSjFq2zpa1ECi4jw6Y0TyogJqYiIupEZuJEe2R0Ny20NCVEUaYkHCY0kCpPZh5Ap0JEu2pEuKRTpO27KB1zPK40VC4UjSYU4Szji+pE/+JFDiRExWWUgmVE2S5ETiZFLmwE5eSU8GJVRGpVRuxFBqWVEO1FES5E2i4EnCYVdC41NOpViOJVkGRFWG2VUGVFNS5FKKwFp6Y1syw0GWJV3WpV0K0kceXFr+01sq5Vaa5FeiJAL4YljepWEeJmJWyz7K3F7eU19yZVx+wGP6ZUCqZCskJmZmpmYOw1mS4Ewy12Qy41uGplsGpjHM5Wampmqupgd0Jp815jxlJVv+/iVg0iYPmmYxoCZr7iZvaqZrIttnKhdpdsBoDmdtViY06GZvLidzkuVvIhpsqpNsQqZtSiZuCqZdiGNGNid3dqd3lsFzLlp0otN0HidywuV5IuB1OuV2fqd7vid8ik5e+tx4nlN5WmdkimZ+3uZ+HoNyxieABqgrhiem1ac4XaJNVid+Kig3MuhpFqaARqiETmgIzCfUGWg3IahFOihxrqdEcmi+QSiFjiiJSiiBkhqGcpOGomd6zmaL9oBxPpyIliiN1ih3WujXpag2rWhpeigLxqh5DmZyzqiNFqmRZuaJ1pqOZtMcUuaLsmhK/gCQzsJ/HqmVXuno4eja9WNu/jWpfvpoBdynVj4pWLYnlp4pmpZlkhLbklZTFGKAmE7AlH4pmSJDlaYpnuZp3Gkp37UpNP2gBXjpmEaplIIpwRGpniaqogrjmkabnz7TCkaAoCIliApif+Ymoi6qpm4qI/Lp4j2qM6XeALxpghKqel5qiJopp64qq3Jio3YbqIaq/TGloVJqnfpnpraqru4qCHoq5sVqM2VfBtbqoAqpdq4kryarshLhq/JjcPqW7vHAnC7orT6oqi4rtmar//mq6wGrrLagtBLrhpqqMtyptp4ruu5as/abtwqT9Q0rqrqjuOaCuaarvd7rqHEr8LWrL+Uff1aqV8YreyIrvhas/sFW3romHL/SkgamQ8ACLHbixbFe5sFWrMX26WIW4cKmUgpaYMQ6LP7N6xWQBMmWrMmeLMqmrMquLMu2rMu+LMzGrMzOLM3WrM3eLM7mrM7uLM/2rM/+LNAGrdAOLdEWrdEeLdImrdIuLdM2rdM+LdRGrdROLdVWrdVeLdZmrdZuLdd2rdd+LdiGrdiOLdmWrdmeLdqmrdquLdu2rdu+LdzGrdzOLd3Wrd3eLd7mrd7uLd/2rd/+LeAGruAOLs9qDeEeLuImruIuLuM2ruM+LuT2rHNELuVWruVeLuZmbtCiQaRCwDqAo8A+bLWSgeaWrumeLuqmruquLuu2ruu+/i7sxq7szi7t1q7t3i7u5q7u7i7v9q7v/i7wBq/wDi/xFq/xHi/yJq/NHo3yNq/zPi/0Rq/07u3kTq/1Xi/2Zi/LngGpXmDn6mTofiwcaC/5lq/5ni/6pq/6ri/7tq/7vi/8xq/8zi/91q/93i/+5q/+7i//9q//Wq/h/q8ADzABF7AB02z1HrACLzAD42wZdG+Yfq+TGmvIhq8XNDAGZ7AGbzAHd7AHfzAIh7AIjzAJl7AJnzAKp7AKrzALt7ALIy3zvrAMzzAN1/DWJrAN57AOyy4ZTCq1xum0+qDIWsEOF7ERHzESJ7ESLzETN7ETPzEUR7EUTzEVV7EVXzEW/ndtAGcxF3exF8uvenyxGI9x1I6BDwepBXvuEE9wdrIBGb8xHMexHM8xHdexHd8xHuexHu8xH/exH/8xIEttDAcyIReyIdMtDh+yInexGPAoG49uBKdxqVJwM9TrxV4yJgNZwi7dxiqSI0MpxD5AEHeoJPOCJWcyKqcyiunrGXYyIH0y+DZlnMYyJPPktaoyLueyv22y17lyH8HyuNaypI5yoK6xjN6yLiezMpsbK++hL+/RLP+wMKtxKQdzG8tlri6zNm/zq/Hylj5r/REzNVuwOP9oNevCKXOzOq9zcjWzJz4zHJWzKMumPA+zMdNCOrOzPu9z4bnzgIJzAdbz/qjupEDP8zmjczbzs0IvNJr5MzDCcxkV9ECvp0RLdMklNENntEbLZMYGJUSLUTQ/ssTSKbmq4D3jM0ZvtEqv9I05NDV+NBiFtEhT5zR/aE0DQz6ztE7vdLW5dDnC9BVZ9ERDbEELtSbkNE8ntVKfWkfbJVBXkVBnpUDL9C0g9VJfNVablDfD3lNPUVTn5FSfNEojc1aXtVnrl09rZFc7kVGDtVgX80EjNFmfNV3XdXhttfOt9RFR9Uz3aFyTNCUbZErbNWEXdmultUvqdRHxNU2XNFyHsoveNE4PtmFXtmVDFl63n2IPUVt7qDwb9SZY9WWPNmnbXFN752bvUGeH/u9nvzWVUnZpx7Zsk1Vm/x+XCtVqh3I5g/ZRw/Zs/zZwOxVi12Vq39BX+6g483Zvz3VwN7dzg9tw32Vx19BxQ3Zyu/ZrM/dzbzd3B1V0J+Z0sxBjA/Y1o/FIyyt2y4Jodzd7t3cU1fYQhrcKjbc0lzd5n7elQvbAUqx797d/o9R3q6Z8p1BFF+db07ctrPd/LziDnxB8m+GAkxCCP7Zkj3OFC/Ffm7JvNziHdzgzBThzRrgHTbg5V/N4k/hYE6yHrziLn9OD66GIdxCKW/iF07hjg7J9D6l2tziP9/gvgfh7xrgGAXOx3vh943eR5/jEwoOPN7mTfxaQx6eQZxCR/tNyjdvzX894ivP3k3e5l5tSlAvolFfQGSd5YFuzkpt3mgv2jn+5m785RYX5hI75A5V5ZOt3JBNrlZfrhsO5n/+5E8k5idK5A0GwSK85jp85hiv3Jyg4oD86pEPOi5MjoTcQoN45npPyUdq5jqt4pH86qLPSaV9ypS+QBC/6nh+6ott4euOCo4c6rMe62kx6Ppa6AmGgnH4uvDYsonc6l8s6sAe7Cgk6nt42MvK6lg91w+5fnwu7sz97do26Mtu6ASF7q2O5Aa5fm0M7t3c7/BD7plJ7tVt7r+f3rGq7p3u7uq/7+9D6Txr7sfP6EfjrPLw6u987vkOQtCu0uI97/rYngfnZg73nO8EXPL+4u1j2ewIFvBMY3+41u8FHvMQ3Drijq8Lfuqiqw6nXO8RPvMd/vN4gvHQDNE2CrD8MPMinvMojS8Ub7MVLGMqvvMzPPJVszRWIvG+SfNrFPM33vM8TSc3IZ8iQ9ssjGM//PNInvYwkQhTg/G4WvYEdvdJPPdWXyLk0QctPu857ndRXvdd/fUFNSxI4fXdCPX91PdinvdoPSKUUQdavs9nrF9qvPd3XPX6ciRCQPYDGfX3Nvd3/PeCbB470wNszNN+/l98HvuIv/nYYyA7oPYUefnslPuNXvuUnx3PgQOHrtOSTF+VfPuiHvm/EBg1AfpF2/r54fb7orz7rr0ZkmM++8zi8F53qt77t3z5ovEVbxX6Toz521T7uB7/wN0Zl1A/vd7nvWxfwDz/zN78sQleFbn5lJ390Lb/zXz/2x8XsS/9oU/9yWX/2h7/4B0+BQBL3l7b3Jxf4jz/7tz9VPMkEnP9vpz9wrb/73z/+80Sf2Ij8Bzf9+xYByJfR5faHUU5a7cVZb979B0NxJEvzRFN1ZVv3hWN5pmv7xnN953v/BwaFQ2LReEQmlUtm0/mERqVTatV6xWa1W27X+wWHxWNy2XxGp9Vrdinwhsflc3rdfsfn6W1+3/8HDBQcJCw0PAzUU4RDbHR8hIyUnKTcQjio/szU3OTs9PwEDRUdJS01PUVNVV1lbXV9hY2VnaWttb3FzdXd5Vj0/QUG5h0mLjY+Rk5WXgnGW36Gjpaelrw0oMbO1t7m7vb+Bg8XHycvNz9HT1dfZ293f4ePJ2mmrw+Wx8/X3+fvt7Lf40/gQIIFx1hLYFDhQoYNHT6EGFHiRIoVLV7EmFHjRo4dPe4CGFLknI8lTZ5EmZLLSEYqXb6ECQ1hTJo1bd7EmVPnTp49ff4EGlToUKJFb7JEWs/oUqZNnYZL+lTqVKpBZlbFmlXrVq5dvX4FG1bsWLJlzZ5F6yDp2l9p3b6FG5dHVLl17dK8elfvXr59/f4FHFjwYMKF/g0fRqyM7WJniR0/hsyTbmTKlbHltZxZ82bOnT1/Bh1a9GjSpU2PYpya5GnWrV1Dm/xa9mxAmGnfxp1b927evX3/Bh5c+PBhqo0TR55c+ZjYy50/j2Eb+nTq1a1fx55d+3bu3b27NJ76+3jy5S2sNZ+eunT17d2/hx9f/nz69e3fjx+eLX7+/XE39y/AztgTsEADD0QwQQUXZLBBBx8ERz8AIaSwQrcmtDBDtAjUsEMPPwQxRBFHJLFEExOUcKQTV2RRMgxbhLEnDmOksUYbb8QxRx135LFHjFIMyUchhxzoRSKPjGhGJJdkskknn4QySimnpFIHIIOsMkstizFy/ksvyVHySzHHJLNMM89EM001dbtSpDXfhDOSLuOk85Yw68QzTz335LNPP/8EtJ02VQy0UEOjmPNQRSm5c1FHH4U0UkknpbRSS2sYlNBLN+V0hEQ7BVWMRkMltVRTT0U1VVVXrTBTgFiFldRPY6W1iFFrxTVXXXfltVdff7XLVXqAJdbPWYtFNoVbk2W2WWefhTZaaaf1RlhhqMVWy2Oz5baBZbsFN1xxxyW3XHPPRcLaRdBlV8dt22X2W3jnpbdee+/FN99c1c1DX38/fPdfXOUVuGCDD0Y4YYUXvpFfOxiGWMCAIyaVYIovxjhjjTfmuGM2HQ7IY5HJm3jkRy02/jlllVdmuWWXXwYK5JBhphm5kmveE2Wcd+a5Z59/BjpoxWReTWijXbv56DN1Vrppp5+GOmqpp6aC6JmpxjqypLOWkmmuvwY7bLHHJhtqq4suO22+tlZbSK/bhjtuueemu+5sz0bbbr3DQm/vKN/2O3DBBye8cMPVxDvvwxdfim3GQQT8ccknp7xyyy8vMHHFMeecJsc7bzBy0EcnvXTTT0cdNM3lSL31jz53nT/RY6e9dttvxz33n1ZnXXffGYL99/ZmF754449HPnnloeI9juWfhyd46LUjfnrrr8c+e+23L6T53rkHvxvpw0+uevLPRz999ddn/wXvnW8/fmPG/pdfN/Prxz9//ffn33jVBthP/wQIC/oN8DT3M2ACFbhABjZwbP9bQAEdOEE2SJCCmkHgBTW4QQ520IMIE49aNPVBEiLCgiU8TAZRuEIWttCFL2RVCCHgJhjWsIJIsSFrVJhDHvbQhz8EorZkGIFXBdGIXTjhEdOyQyU20YlPhGIUUTTECShFildsQhKx6BUmbtGLXwRjGMXIGypWoBljRKMPtJjGp3SRjW+EYxzlOMe3QFAD16JjHluwRj3+xI19BGQgBTlIQpbEjr1YVyEV6QE+LhIv1nBkJCU5SUpWMiKHZKQeLLnJB/SNk1X54ydFOUpSltKUmSjjB/p1yk02/pKVFQnlK2U5S1rW0paISiUI7nBLSbqSlwuJ5S+FOUxiFtOYmWSMCupwTEJ6kpkwCeYzpTlNalZTlLl0w/esmUdfbrMd0fRmOMU5TnJiEZsngF8549hNdYIJku2EZzzlOU80YnKPAaDnG9mZT22Ak5//BGhABfo8ew70lfs06DL8mVCGNtShD5XcOSH6SYROlBcLtWhGNbpRjppNoh2lZEVBKguMjtSkJ0VpSiNWUJWGFIctLUdJYTpTmtbUptT66E0HKVKdhkKmPQVqUIU6VE7llKh95OlRGfVOpTbVqU+FKqxYGlWkvpSqxfjpVbW6Va52FUZT9aockxrWP2SV/qxnRWta1Yofo65VjGN16xnMGle61tWudyVOW/G6Rbju1Qtz9WtgBTtYwlIGrIXlq1UR2wnALtaxj4VsZMFyWMlGsa+VZUJjMbtZznbWszHR62eBeFnRDkGzpUVtalW72n5QlrU/dOZr23Ba2dbWtrfF7TNcm9sckpa30WHqb4U7XOIW9xyhNe4KfZtcFNCWuc+FbnSlewbkTveDy7WuB5ybXe5217vfDcJuwetB7I63Ats1b3rVu172bkC87b1geeHLAPTO1773xW92q5vfBcp3vvXlb4AFPGDWvpfA/VXsgW0AYAU32MEP3quBITxA/7KXwRPGcIY1DFUJb7h//hVO74U9PGISlxil+zVx/kA8XhGn2MUvhvE/Oxzj+q34uy2mcY51vGNmzpjH8bMxd3H8YyIX2cjXTOaRHRhk6w5ZyU+GcpTniGIpp4/J0nVylbW8ZS4r0cddPt+Vn5tlMJfZzGfu4JfRDD4xJ5fMa4ZznOVc4yTP+cNtJu6b7bxnPvd5eWr2M/bwLFw9B9rQh0a06QCd6OkNmreFZnSkJT1pwVGZ0o12dA4BsGlOd9rTAAgHpC89alKXOmuWNjVBEyy/T7fa1a+GdaxfLQNZw9obok51rnW9a5otmtfHy7Teaj1sYhd70y8wdqy3getfN9vZz2aYr6FdvGDTLdnX/sY2p12Q7Vlng9nTBne4xY0uVI+b2qtWH7fVTWwWrNvW1Pi2ueU9b3ojq9z19l214+Zufnc7Bf32dzTijW+CF9zgpZL2wW+nb7UB3OHa/vfDWz2NgSvc4hfHOKASnnHaMbxsEnc4CkAecIUGl+MnR3nKu3VvlXcc3eAbeb9Fzm4IGFvgJm95znW+c11tnOeo83jYYs7vEwz7AjQv+SV+vnSmNx1UPnd66YJOu3eToNYbMHrSERB1rnfd639i+dcV/XIYkjwEV+cA2pVRcbG33e1vL0/Y4U66qaOu6iJQewdkrXVMzN3vfwd8j6Ae+MvV3XR3P7uyE292rOKc8I+H/nzkMzR4yVPO8KNDPAj2jnfFI4PtlQd96EWfGLmP3nKX51zmP9B5zqv+oo43fexlP3vtUJ72i0O95Vyv9917gPWNV/rthT984g/H9sUvXGw/2HusM5/3jN/F55E/fepX3ybHt/7gci856D/f1RHvfi6kn33yl9/8Fin9+Q23/cU5PwPu9334cTF+9dff/vfPB/bxrzf2Fw7+Fvg9EwjA6IO9/TPAA0TAotC/BKSb/hOc/wNACEw7+bMF+mPAC8TADOSF9NPAvXFAv5FACgjB5vs+Y7DADkTBFFTBUuDAFbSbD6ybEZSAARRAGWSFE3TBHNTBHTyEBeTBtIHBubHB/pqjwBEYQlXAwR9UwiVkQjHwwSZ8ILIToCN0ACo8uiKchSSEwi3kwi5kghb0wrYJwobDQgywwggsQ1jQwjBkwzZ0Q0wBwzckmzH8uDSsABqcuRIchjWUwz70wz9EpsUARM6hQ7E5QwY4RDScOGLgw0F0xEeExDiExLApxK9JRAW4RBG0Q1doxEn0xE/sQkkExa+pRKzJxAE4xRncxFboxFF0xVdUwSeERakpxanJRDwEv0V8veCbxV70xV+UAVkERo9iCf25xVXUPGREwgIcxmZ0xmc8jzqDRsapRac5xVScAGxkLGacxm70RmAUxW+MmmpUmmtUxvjTQwLkRXFk/sd2dEVhdMejIcegSUVtjAB73IRWjMd95EeUg8d+FJp5/Jl6PEfv+zRG5EaAVMiFXMFwZMimUT7uwUV01MUYwMdM0MeH1MiN5LV/5MifEUicIciCNEhP28OE/MiUVEnk88iV7JmQpJmRTEcYuMhKyEiXxMmchDOH1EmjgcmWwcaJzMWD3MWt68mjRErJ48mkDJqfXJmgJMmS7LSTXEemtMqr7LqWxMqacUqT0caafACwnISb3MqyNMsH08qz7DUpPJ6vjMoJnMn5Q0m1pMu6BLeltMuXZEvhEUqKJMoZEMtqmMu8JMzCHLW0NMyW6cqNscfARMS3HAWyTMzJpMzf/kLMymSZxcSYxoRMDXBMSJBMzBTN0RStyyRNldHMiMHHz8TEzvSpwTzN2JRNHsPL2VzLYkSe1XRNM9zNTwhN2wTO4HQr0xTOkUnNhLlI1kTF3vSE3yzO54TOqCLO6PSY4zyY5GTOO8xOTnBO6vTO77yp2gRPxdzL1OnLZIxLZNvOfITN8XTP92Qu8YTPzCzPw1vPBVBO5aQBhODP/vTP/wTQABXQASXQAjXQA0XQBFXQBWXQBnXQB4XQCJXQCaXQCrXQC8XQDNXQDeXQDvXQDwXREBXRESXREjXRE0XRFFXRFWXRFnXRF4XRGJXRGaXRGrXRG8XRHNXRHeXRHvXR/h8F0iAV0iEl0iI10iNF0iRV0iVl0iZ10ieF0iiV0iml0iq10is9UNXA0i3l0i710i8F0zAV0zEl0zI10zNF0zRVUzFNijV10zeFUzHlg5rMz/vsgTjF0zzV0z3l0z710z8F1EAV1EEl1EI11ENF1ERV1EVl1EZ11EeF1EiV1Eml1Eq11EvF1ExVUy3V1E711E8F1VAV1VEl1VI11VPlz7VA1VVl1R5tA7Cs0/TUglal1Vq11VvF1VzV1V3l1V711V8F1mAV1mEl1mI11mNF1mRV1mVlVltNjWaF1miV1mml1mq11mtl1DbF1m0t1Ve109aU1RbQzxng1nI113NF/td0Vdd1Zdd2ddd3hdd4ldd5pdd6tdd7xdd8NVRO1dd+9dd/BdiAFdiBPVJtJdiDvVI2OM/Fq0iL/NYdQNiIldiJpdiKtdiLxdiM1diN5diO9diPBdmQFVlz5deRNdmTRdmUVdmVhVODZdmX5VCFfdjlDNd2m9kcgNmc1dmd5dme9dmfBdqgFdqhJdqiNdqjRVqMfdakZdqmddqnhVqAddmoJdo1WFiG/Utau9lI6M759NqvhSf5BFufrE/uu9lYbVi5rMqxZdu23azpdFucsU5zCcyrtbqtBc32jNu95du0gtu+vc0RwhzHtFsjxNtH6FrAVdzFtSSxZVyQLFv//sNb1hzXQ0jcx8XczK0qQdRc3IvcwClcrDVJwDxcR7jczkXd1AWjv1Vd8sTNyqHcya1cQzjd1rXd2w0i1sXdlZlbbAld0Z1Kra1ZWqjd3TXe41UuaUTeSvtcayvdz5xd2tXb5aXe6jUm3bVek+ndaEHbrFXP4c3C6c3e8SXfU8Le8hWZ7XWW3wVeiHNY8CUp8UXf+aXfSHLc+g1cGpJc+FUBwi1d05Vf/BXgARYr5SXgF2zeOvxfmk3bFWDfVCjeA5bgCW6d86XgjVFfYqncul3gRojgCwbhELa8+xVh1xXcGNzgs+1gRPjgEnbhF/ZAA4ZhuclgXpndB/bMFbbc/gCe4R72YQWy4B++mIiEm+iF1eiV3rUV4iVmYgYK4iammBquFRw2XP5t32MDPqOE4i3mYv154i6GGCmOFSQ+YiuOhRYG4zRW444h4TXW3gSGGiq+WzP2y9FFSCV24zzW43OT4T0uGzFOFSQG1wauQTpWQx7240RW5Ihq40VmYzguR0FmYO/NQ0IWP0R25EzWZATm3E2GG0AmFUkeZEouATlGBTT25FRW5WJp5FXGYEimRx1uAM405EPGY1fG5VyOwj7WZbABZU4x5VKGSllmYUzu5WNG5pf54mQ2mF+2FFHGz+yE5kJAZWa25ms2lFbG5iGGZZGc5kkmZfSsZVvW/uJtNudzRk1tRucw7uaYJOawvMRghmBjXud6tmd2WeZ79hdnfhR5Lrp4/mZCqGZ9JuiCXhJ1NuiF4edF8ed/hsyGPoWBTuiJpugaQeiKTpiFPpSAfsyo3LxkkGiMFumRBpiLJumD0WhAgWiHLsiPBml6PumYlulKyeeZtpeU9hOOnmWXvsKVjmiYtumgFmqN4+WhJsbXBRqfrmQIzLu1A2qjhuqoRpyiluqnwek80Wl4buoqRDq+u4aqBuuwBjuTFut9bmeNUer+HbrglYmnLuu3hmshqem4hperhpO0Vuu1pji3puu+9usWIeu/zhe7XpOsVsWRuwy+FuzFZuzJ/gvsxr7ps4YYvLZZifM2xYbszNbszHnsza4XwjYTw9ZOgOsnzPbs00Zt+Ojs1J4X0B4Tyv7edeOGkGbt2rZtvqHq2wYa1/4S2KZJbrs109bt4SZum1nt4sZnyU69Ygs14Ubu54Zu2pjr6B4X3oYXLDYH2qbu7eZulTju7jYX67Yh7Qbv8jZv9Pvu8yYX8X4h8lbv94Zvgpju+F455WYo96bv/NZvQUnv/Q4X9mYh/PbvASfwb+jvAgcXAC8hAUfwBnfwocntB4cZBf8gBpfwC8fwWpjvDJ8WCu8gC+fwEBfxUzjwEccWD9cgEDfxFWfxSijxFu9w+84nFYfxGrdx/kHY8Bt/FiLeKBrX8R8H8jLI8SB3FhRvIB8n8iRX8it48SXfcRmHJyR38imn8nRp8ipvFiNPICnH8i738hwY8i+3NygnJy4X8zNHc2aI8DQ3TjIXJzNn8ziXc0Tq5DnPXyzJKDi38z3n8wYI8z7/FS3fHz0H9EJn8z83dF8R9Pwh9ER3dCy/8kdnZTefpkaX9EsP8kjHdGJZ9Pix9E0HdRZH9FDvlU5nn08n9VS/8FFX9VKndGNC9VaX9QHX9FkHFlNHn1i39V1Xb1bn9V3BdfLR9V8n9uj29WIH9lf/pWFH9ma/7Vp39kBX9lti9mi3ds2G9mtX9GDPnmrX9m/v/utjB/eem/ZZ8vZxR/eqFvd035dyf6VzZ/d4t+lsl3dXd3dTgvd61/eKXvd9xxVuf5589/eBt+d+J/haAXjlEfiDZ3hrNviGR/h7/6SFh/iKx2V6t3h7P+FwoviM93hHfviPj5WEL56OF/mTX+OQR/mRl3hKMvmVh/kmxviY5xWS152Xp/mcf+GZ1/lkR2prwvmeF3oJVvmhl6qWX6SgN/qlR9+iZ/oYQvpCUvqnp/rl5fmqJ/eff6apx/quV12n9/pVsXnX4fqwN/vFBfuzV5WxT52yV/u3b9urh/t213picvu5x3v3lPu8p/uNX3bn5vvAH+m0F/xUYXvSufvC/lf80yT8xUcVHqelxHf8yU/Mvaf8f4/6OJL8y+f8s7T8zo/4uo98wAf90lflxjf9x8/8NNr81Hd9lUT91z+Vw6+c1pf921/Iz8d9WqH9ybH93Qd+doz94DeV3mec3yf+5G/G4Vd+hFv9L0L+5pf+V9T96Wd50R+l6Lf+7XfE6uf+6/f7iSf97yd/62X+8peV55ci7Uf/9m/C83f/UDF+wWH/+Lf/HPT++z967Hf58df//yeA+Zi63P4wykmrvTjrzbv/YCiOZGmeaKqubOu+cCzPdG2jQa7vfO//t6BwSCwaj8ikcslsOp/QqHRKrVqv2Kx2y+16v2Dnb0zWhc/o/rR6zW67L4K4XPCu2+/4vH7P7/v/gIGCg4SFhoeIiYqLjI2Oj5CRkpOUlZaXmJmam5w1ZZ+gnaKjpKWmp6ipqqusra6vsBOgs2axtre4uTVzcrq+v8DBwsPExcbHyMnKy8zNzs/Q0dLT1NXW16u02jzY3d7f4OHi4+Tl5ucl26Ho7O3uHbxx7/P09fb3+Pn6+/z9/v8AAwocSLCgwYNu1G1DyLChw4cQI0qcSLGFwjIVM2pMFI/Oxo8gQ4ocSbKkyZMoU6pcybKly5cwt1zUFrOmzZs4c+rcmXImGZ5Ag2roKLSo0aNIkypdyrSp06dQo0qdSjWKz1lVs2rdyrWr/tevHK76AEtWItGyaNOqXcu2rdu3cOPKnUu3rkGxGO3q3cu3r9+/pfByA0x42tnCiBMrXsy4sePHkCNLnky5m+AxlTNr3sy5M+LLOzyL3nR4tOnTqFOrXs26tevXsGMzBA1Etu3buHPrLkc7wO7fa0oDH068uPHjyJMrX868eeHePZxLn069unUsva9rpyF8u/fv4MOLH0++vPnz6KtAD52+vfv38HFnj09/Qff6+PPr38+/v///AAbY0nrsCWjggQgmKNR8Cop3X4MQRijhhBRWaOGFGGZ4BIG1aOjhhyCGeA2DIiL3YIkopqjiiiy26OKLMPbFoW8x1mjjjTgG/kJijq2dyOOPQAYp5JBEFmnkka3MiOSSTDbppAg7PjmZj1JWaeWVWGap5ZZcGjkjjV2GKeaYJUZJpl9Unqnmmmy26eabcMYp2Zdy1mnnneCZiadaae7p55+ABirooIQW6o6Shiaq6KKT6cmoVH0+KumklFZq6aWYZmoVh5p26umnTzkKKlCRjmrqqaimquqqrF5JZ6uwxirrQ6LOqlKptuaq66689urrr8O9CuywxBYLTa3GVoRrssw26+yz0EYrbUyITmvttdhSgmy2Ay3L7bfghivuuOSWy4qw5qar7rrY0cYuQN6+K++89NZr7734qoBuvvz2628H2/77TbwC/hds8MEIJ6xwqtUu7PDD9UIH8cDxTGzxxRhnrPHGUjbM8ccgJxtwyMEQTPLJKKes8sosI7dvyzDHnOnIMrdics0456zzzjz3vNXLPgct9Js0D01axUYnrfTSTDftNEQePy311EUWTbUjN1+t9dZcd+3119pGDfbYZF9oddmBZI322my37fbbcMcAdNx01+3e2Xa7oXbefPft99+AMz134IQX7rK7huuxd+KMN+7445CzK3bklFduGt6WS7F45px37vnnoE86eOikl84X5qYXsXnqrLfu+uuw3zh67LTXXhXqtsOweu689+7778CHN3nwxBd/E+7Gk7B78sw37/zz/tAvNnz01Fc/EfLWw4F09tx37/334P88ffjklz8P9ubbt3367Lfv/vvwIzR7/PTX3wz67y9v//789+///4HhFAAHSEBg4I99+iugAhfIwAY60Avze6AEJxiJA5ovgRTMoAY3yMEOhmV8HgyhCPUgsQdicIQoTKEKV2g/ELLwhTCUCeIaeMIY2vCGOMxh7Fyowx76sAgW/F4Nf0jEIhrxiG6LIBKXyEQTlFCBQ2yiFKdIxSquTIlWzKIWIxDE7EVxi2AMoxjHuC4ekvGMWuxi9b6Ixja68Y1wnJUZ40jHI6rxRgDIox73yEc+BqGPgNSjN9hYx0Ia8pCI/BMWE8nI/hje0UWBjKQkARCDSU7yGoRspCY3yclOemmOngxlBx+pIkuaEpAsOOUpqZFJUbrylbCM5YRAKctaMpCUIVKlLgWpgl2a0jDrs6Uwh0nMYs6SlsZMZv1wqSFf+jIFzlRlNFqpzGpa85rYXM0is8lN8zHTQtF85gnCKc1nULOb6EynOtdpF2Sy853R+6aEyLnLcdJzlc44Jzz3yc9++hMp7vynQH8nTwXd0wDlHME969kMfQ70oRCNqEQpss2JWhR2BT0QQymAShLosgEbVYZDL0rSkpr0pLwJKEpXyrmMAiihGdijR38pAZgiY6QszalOd8rTXKi0p0A1nEv7g88P/lBSBDStQFFvGsygOvWpUI1qMCoq1arybaj6SSoStKpUSy4Dp1YNq1jHSlYuULWsaF0bVunDVSO01QJeTQZY00rXutr1rhb5KV73KrW1vuetRYgrBy4p16by9bCITaxiaaDXxTrWZ09MEWGXINjBTtYYc32sZjfLWaCetbOgzZlfz3NZJZTWspJkKi9Cy9rWuhaxn32tbFM2WvKcdqupRWpuMWvY2fr2t8BFaWODS9yL1RY8t8VtJGe6XN6utrjQja503znc6Vr3YMf1TnLdulvdNrcYmb2ueMdLXhzGtrzo7Vd2r7Nd7gbSnu917hzSS9/62neM572vfuW1Xup0/pey//VufIkR3v0a+MAIBl91E8zgb/XXOQE2bYRDMGFfFLjBGM6whmuX3w17WFoPZk6FjzBio353GBf+sIpXzGLGdbjFMC5WiJFT4sDWuAPtxUWKY8zjHvsYbAv+sZDlOMMG3XgIR8bxiUvW2yE7+clQDlyQo0zlU82YOEkWQpY3sGWbNbnKYA6zmLX24jGbuVNX/k2XbbBmDOTYFjs+s5znTOd0lbnOeH5UmnWzZCa8GQRtTkWc80zoQht6WFM+tKIVWeSX9hnAA+7lo3Ux6EVb+tKY1lSiM81pOO1ZNoGeQagvMGpTVLrTqE61qut051W7+kyfhs2kJRxpaM5a/sdffrWud81rS7W618DGUqxbU2oY/JnCt4ZzroPN7GY729MCfLa05TRs1RT7Bdfuaq0tvOxpe/vb4EbSr8NN7h9VGzXJJnG6FbruV5y63PCOt7zFM+5529tFkWXrtv3cbmTvOxfvvrfAB07w32y64AgP0bk9k20XNHwCDz/acxNO8YpbPD0Hv7jGKbRwzvSbCBGPQMgzEfCNm/zkKKdLvVPOcgR1PDMfR3LMTfzvW5S85TjPuc6jsvKd+3w/L6fMzAEr4I46fOaC7vbPl870pssl406PenuCHpkjRxO+Ncd6H4Vxc6l7/etgpxXUw072PDXatuleKHOzboKRX6Lr/mWPu9znfqix0/3u0ulih26T7IXK1N9GPzrbYQF3vBv+8IhnRs8Tz/jDgSYEg+F7zf0eeNRWPpVIR0XhG8/5zns+G9H+vOjNg76xSP7yA6B85hfgdgi0vhKbH73sZ097Riy+9rhvDfIwY5s+q/7ar3dA8CcR+9wb//jIZ8Ptk898z6AuL7FZ8u+P/YDhM8D6kSh+87fP/e43we7eD/+czs7FT4A60kRPgE1JvXrLb53JExe//OdPf0CAv/74/wz5HUALWX+3sjWVfiLXflxGgKSgffmXgAq4gA+wfAz4gHoxMgvhGrk1agJYfQYYUxkoCggIgR74geHngCA4gnCB/iwKQYHNtYEAyFEbyH6D525KR4IyOIM0mAH3V4M4SBaiMhPEtlwtmHqBhn0KIISP0IE5eIRIGHYimIRMmBX5ZgBXwRriBHioN4AvuHbvBwxG2IRc2IUpt4ReGIah0mh4sRohRYVZyIJXyG5reAUd8YZwGIdyOId0WId2eId4mId6uId82Id++IeAGIiCOIiEWIiGeIiImIiKuIiM2IiO+IiQGImSOImUWImWeImYmImauImc2Ime+ImgGIqiOIqkWIqmeIqomIqquIqs2Iqu+IqwGIuyOIu0WIu2eIu4mIu6uIu82Iu++IvAGIzCOIzEWIzGqIkzcozKuIzM2IzO/viM0BiN0jiN1FiN1niN2JiN2riN3NiN3viN4DgHvSEHlxGO5liIU/BRJUB9CECE7fiDSnCO8jiP9FiP9niP+JiP+riP/NiP/viPABmQAjmQBFmQBnmQCJmQCrmQDNmQDvmQEBmRiZiMElmRFnmRGJmRGrmRHNmRHvmRIBmSImmRX3IVI9mM6bh+aOhH2laFttaGVnCSMjmTNFmTNnmTOJmTOrmTPNmTPvmTQBmUQjmURFmURnmUSJmUcvglStmUTvmUUBmVUjmVVFmVVnmVMlmSPoGVpJiSF+h+aRiAMAlo8JgEXHmWaJmWarmWbNmWbvmWcBmXcjmXdFmXdnmX/niZl2vJlHrZl375l4AZmII5mIRZmIaZh1o5E4c5iF7JjhrQZe54AJEpA4tZmZZ5mZiZmZq5mZzZmZ75maAZmqI5mqRZmsNIkaaZmqq5mqzZmq75mrCZl4mpELDZmNbnmJMJhGNJBbHZm775m8AZnMI5nMRZnMZ5nMiZnMq5nDOJmsz5nNAZndI5ndRZndbJC7OpDq9pm7upgTCZm7mpCFsohuRZntMGhuaZnlyRnRPYGV9Jcy55fWUJcfOJCeOpnviZn52GnvrZn1LBnv3nno4Jln9Hn/XpegdqCffpnwzaoHJ2gw4aoU0BoFjhcQNKoLwklt2JoXnEdTEooSAa/qLzxp8iWqJAQaHroBkriAJbNpnhyREfaqIyOqO9RqI0eqM2gaLQVxkrqnUsaaDx2XYJCnsxiqNGeqSKBqFIuqQvoaM/oaJDKp/fGaWs96KIsKBMmqVaClpKuqVeehJOyns8SqVDGHORaaVXWqRfuqZs+mE22qZwqhFhanpCR6bqZ6Z2+o4begpYGqd++qc99aaAOqhiN6cFIhlniqd76p1BGgt9SqiQGqkQ1aWSWql3YajRMRmJOqWL6mZ5CgmPaqmiOqrZJKikeqr4gKm1UXWfilBD16poegihiqq0WquuZKq2mqvooKpi+hib2qhl2qktCawwGH+6eqzIWlW4/pqszOoNvPqkvtqqukmsekqtHhCrsqqmzbqt3NpPlNqt4GoNz7qjjSGtkPmp2GoIsxqu7NquN7Ss7hqvxjCu5hetwjqsPwqk1sqhR+WhxiqvABuwxQSvAluwPkWv9VqusIp02HehqrCuBhuxEts/3zqxFmsLCFuhjOGOa9aw0lqE2nqxIjuyTFSxJHuyqZCxKbqx96qGYamv+eqjBeqv84WyNnuzUkSwOLuzlqCyCcuyLWuF+1qtL4uFMauFIcuzSru0D6SzTPu0juCzvQq0Q/uYqzd86Zqt/wq1XNu1DmSyXhu2jSC1mWqvVcuoRauhabuSGYpiSSu2cBu32eO0/nJbt35AtntntmvLth1qtUFbpR8Lsltrt4RbuNVDt4abuHaAt3X6tyBFgK+XtVpbs4pbuZZLPGB7uZq7uD4Lc1RqgW7nsKwAsZtbuqaLMpl7uqqbBioLpY4brGd7p6/rqrPbCaS7uribuwqDuLrbu+pBr5shukIbu0S7t2hrvJT2tr67vMzbV6nbvNBLBeMqoAeabcILuLVru8obvdzbvaIVet4bvoXAq6IxctdbvEdbgIGbfdsrvu77vhvzvPA7v0BkqKNxvrBLvNirv+g7s/LVC/QbwAKMuvI7wAY8A3N6GvgrmSGHvz1KswB8wBI8wbtbwBR8wSvgpOj2wC77/rocPLz8O7rti8EkXMLQYsEmnMIjgKLW9sEIGrouvL/ZOwq3q8I2fMNdwrs4vMMYAKBS+J6yG7lAPK3rSwk1zMNInMRVg8JK3MSyMJso+J4qWXQlpo5fNcJOnMVaXChMvMVevACJ6X9WzMBjLLPT17YihcVfvMZs3CZd3MZtXJLnd8Yh3MF03K/McMRwvMd8DCA63Mdf/MZqccfpy6KEPE1qDMiKvMhD8seMvMUEkhuEjMeCN33SoMePnMmavB2CvMla/IS9d8Y1YMmXnMiefMqonCGOnMpNvH+np3Y3QHnVgMmsXMu2HBurfMtJfBnHcVAgR06YZMq6PMzEHB+5/lzMPFyGynGG6jbFpTy4yBzN0vwfnTzNSByF1tG3WaDN4kDL1vzN4ByB1RzOOMyDZePN5JzO6owWx7zOKnyCaIPO7jzP9Pyf4FvP9Nye5yzM+NzP/jx+kfzP/RygayPPAn3QCD0g45zQJbyy8czPDB3REt0W7TzRF0yuDw3NFr3RHL0XC93RF72qbWPQIF3SJq0PFX3SB0ynbkPSKv3SMJ1S9xzT3xx5b+PSNJ3TOj0NH73TBpy3LQ3RPj3URC0RPV3USJ0tOJ3UTN3U53LUTh3VzbLUUl3VVt2zUH3VWu0rVL3VXv3V4zvTYD3WCtPVZH3WaJ0QYp3WbN0vZt3W/nAd11eQ0nJd15ry1nad13pdv2u91349Lnj914I92Bnc14R92NYS2Ii92Ixtg1nd2JBdJ4od2ZRd2QdA15ad2Wwy2Zrd2YT92J4d2l3C2aJd2nEN2qad2lZC2qrd2l6N2a4d203C2rJd20kN27ad20RC27rd2zGN2r4d3DjC28Jd3BaN28ad3C9C3Mrd3AMN3M4d3SXC3NJd3eCM3Nad3R5C3drd3boM3d4d3hPC3eJd3pmM3ead3glC3urd3myM3u4d3//B3vJd37ts2Pad305C3/rd3yQM3v4d4O7B3wJe4PQL3wae4ORB4Are4NCL4A4e4dvB4BJe4aoL4Bae/uHTQeEa3uGGC+EeHuImItQiXuKnDOImnuK/weEq3uI4i+EuHuO3weIyXuMSC+M2nuM9QuI63uM3jOI+HuSjQeNCXuTHCuRGnuSZQeRK3uSiiuNOHuWRweRSXuVxCuVWnuWKQeVa3uVLiuReHuZ9weViXuYiCuZmnuZzQeZq3ub6ieVuHuduweZyXuddiOZ2nudgQed63ucziOd+HuhZweeCXugLCOeGnuiQwuOK3ujMiuiOHulLQeiSXum5B+iWnumkwuia3umAiumeHuo2QemiXup0B+mmnuovQeqq3upRB+quHuslweqyXustB+u2nusbQeu63usUh+u+HuwR/sHrwl7s8obqxp7sD0Hsyt7szwbszh7t8MLp0l7tCQjt1p7t+cDs2t7tl4bs3h7u+MDt4l7udAbu5p7u7kDu6t7uUYbt7h7vFKPR8l7v3Qfv9p7vrETt+t7vUofu/h7wwETvAl/wnIfvBp/w/ysPCt/wBw/wDh/x4MXvEl/x9wbxFp/x3EbwGt/xOIfxHh/yhEfxIl/yvIbwJp/ypcDuKt/yaIXyLh/zmsDyMl/zUAXyNp/z9knyOt/zYobzPh/07MvxQl/0nAbzRp/06srzSt/0bgr0Th/1g0DzUl/1pYrfVp/13UD1Wt/1woT0Xh/2bcD1Yl/2nQT2Zp/2YUD2/mrf9oUE9W4f91/A9nJf9/iF9Xaf979A93rf9zkL934f+FHA94Jf+D2E9oaf+EdA+Irf+CsE+I4f+UTA+JJf+RqE+Jaf+brD9Jrf+QKF+Z4f+ilA+aJf+ssE+aaf+idA+qrf+uWD+q4f+yDA+rJf+9QD+raf+xVA+7rf+8GD+74f/A7A+8Jf/DuE98af/G9A/Mrf/KAD+84f/QbA/NJf/Y8D/NZf/NSf/dwPONjf/cG//eA//nQD/eSf/OJ//upfNt+//rmf/u4f/2Rm/vIf/pxf//j/tcif//y/+Pff/wQwH1OX2x9GOWm1F2e9efcfDMWRLM0TTdWVbd0XjuWZ/q7tG8/1ne/9HxgUDolF4xGZHAaYTecTGo0qqVXrFZvVbrld7xccFo/JZfMZnVav2W33Gx6Xz+l1+x2fpwr4fYEeMFBwkLDQ8BAxUXGRsdHxETJScpKy0vISM1Nzk7PT8/NSSnRUFNT0FDVVdZW11fUVNlZ2lrbW9hY3V3eXw6+PFzhYeJi42PgYOVl5mbnZ+Rk6WnqautoagzRb+5q72/sbPFx8nLzc/Bw9XX1d3JePHT5efp6+3v4eP19/n7/f/x9gQGLaCEoReBBhQoULGTZ0+BBiRIkTKR5x96diRo0bOXb0+BFkSJEjSZY0eRIlioIrnaR0+RJmTJkzada0/nkTZ05KF3X29PkTaFChQ4kWNXoUaVKlbVg2DbAUalSpU6lWtXoVa1atRHhu9foVbFixY8mWNXsWbdq0TlmqdfsWbly5c+nWtXuXTFe8e/n29fsXcGDBgwkXDsy2oGHFixk3dvwYcmTJzfROtnwZc2bNmzl39vwZdBDEiUOXNn0adWrVq1nzrdwadmzZs2nXtn0bd+5nownq9v0beHDhw4kLBnAceXLlAKS9Lv4cenTp06lXt36dNe9s2Ll39/4dfHjxZZaXN38efXrmL9Sjf+Z8fHz58+nXt38ff35n2knp9/8fwAAFHLC19gw80D0WEFSPGfgIfBDCCCWckMIK/i28cAH++sOQww49/BDEEDtakMQFFSwxwWQcFJHFFl18EcYYZZyRKA1HoRHHHHXckcceNUERyPRUCJJBZFb0EckklVySySadfNISGw2CksoqrbwSyyw7IJJL5VLoUshjjtSSzDLNPBPNNNWEUsop13wTzjjlnHM8MMFEwc4wixmTzj79/BPQQAUd9LI2pyAU0UQVXZTRu/Lk0oRHiySGz0YtvRTTTDXdlNOFDIWi01BFHZXUUimSNMhID2zARErdMRXWWGWdldZabZ3k05Zu3ZXXXn39dZbzsjBwglWHqRTYZJVdltlmnX3WgFx1hZbaaq29FtsqhL2ivQuIFQbZ/mzFHZfccs0910Npm0CX3XbdfdfdbbWd1IJuwX0V3nz13Zfffv1FTd2n/h2Y4IINHlReJezVgN5dwj0Y4oglnpjiil8K2OKMNd6YYw8TTqLhDPTk5eGOTT4Z5ZRVXtmYgAVmGeaYZZ65to+PCFnkkXUpmeaeff4Z6KCFFsPloY0+Gumk47LZCJ05wNkWnpWemuqqrb76aoyx3prrrr2GiWkinN4yxZ3x/RrttNVem+18i24b7rjlnpudsIcYm2y7Z5Ga7r79/hvwwLF8W/DCDT8c8Vf0BgLvvM0j+ezEJZ+c8sotB1DryzXfnPPO4Vj8h7JHEP0Wvj0/HfXUVV9d/rDMWX8d9thljwH0Hhr34PZYTJ+d9959/x14mAgPnvjijee9dh5yd3w5hyM/HvropZ+eenyGrx777LVvO/kdSB+9e1Z235788s0/H31NXE+f/fbdRzl8HJZnvvlcxn8f//z1359/K67vH4ABFCC24neD75HggLK43wAZ2EAHPhCCDvhfBClYQQteqoA2SKAINgiLBV4QhCEU4Qh7N0ESnhCFKaxSBmvQQRDMT3zPU+EMaVhDGx5ufTfU4Q552CEWzgCGuPvhJz7YQyMeEYlJNJgJldhEJz7xOkOknRTrRUVOFBGKWdTiFrkoKyZ2EYxhFKNprOgCF4bgjDH0xRjZ/thGN75xUTmE4xzpWMe/lLEFafyAHlWBRTv+EZCBFCSB5DhIQx4SkVXB4wqCuMdFXsKPiZTkJClZydp80ZKZ1OQmS/LIL3kyAnxERSQ5WUpTnhKVe8FkKlnZSlfuA5QnEKUQH1c6Gb4Sl7nU5S7BUkhe/hKYwaxGLFVVyzwSUxKkFOYymdlMZyZklc+U5jSpuQpkIvCaDJilKZRZTW9+E5zh3I8vxVlOc57zENnkoDoVsE1QdBOd8ZTnPOkZCnXVE5/51Gca2PnCfibAnZ6A5z4JWlCDHpRo90ToQhnaUNsZUwiN9CdE93ZLh14UoxnVaBGiuVGPfhSkDrBbQOnn/iX2/FMRAw3pSlna0ox21KUxlelBt0WkE6H0ACS9okVn2lOf/vSi5ATqUIlqTlTVT5Y4zalSD6HSoj4VqlHNpFClWlWr8vKoFEUjUweg00049aphFetYtQhTsp4VrYjMaiy9mjOt6o6naZXrXOkKRbPWFa95BeNaQdlWDPgVE2DV62AJW1jtUdWwiVVsD/kKWAM4tgKQrYRgF1tZy162c3fF7GY568DGOlayxeJqISjbWdOeFrVo02xqWdta8y3sAShy5FuHNFpClNa1udXtbleGWN7+FrjGoy0FEETL8kxxuK7AbXCZ21znvsu3z5XudD1n0tlCLbJcDe0klktd/u9+F7y3Wm14yVveuB2nmBJdwHZDadtBdNe88ZXvfAM1XvreF7+Vg623tOteQcA3vwEW8ICZFF0CHxjBfsOuBNgLgQbv4CIRlvCEKVxhC18YwxnW8IY53GEPfxjEIRbxiElcYhOfGMUpVvGKWdxiF78YxjGW8YxpXGMb3xjHOdbxjnncYx//GMhBFvKQiVxkIx8ZyUlW8pKZ3GQnPxnKUZbylKlcZStfGctZ1vKWudxlL38ZzGEW85jJvGSXlRnNaVbzmtncZje/Gc5xlvOc6VxnO98Zz3nW85753Gc//xnQgRb0oAl9ZUMs2MH9TS4XCt1oRz8a0pGW9KQpXWlL/l8a05nW9KY53WlPfxrUoRb1qEldalOfGtWpxvSZVd1qV78a1rGW9axpXWtb3xrXudb1rnnda1//usbpJOmDRepfFgAb2clW9rKZ3WxnPxva0Zb2tKldbWtfG9vZ1va2ud3tDbPa2+EW97jJXW5znxvd6Vb3utndbne/m8WIUO9SF51epI4B3vnW97753W9//xvgARf4wAlecIMfHOEJV/iNA7Zwhz8c4hGX+MQpXnGLXxzjGYd3IgJKbFYZewUaF/nISV5yk58c5SlX+cpZ3nKXvxzm/QZ3zGlec5vfHOc51/nOed5zn8uZ4+70uDZBroKfHx3pSVf60pnedKc//h3qUZf61Kne45lXHetZ1/rWud51r38d7GG3siKErujjRi2uCVb72tnuIwO3He5xP+82h77eoucBwHLX+975Dp239x3wgU/avOddUuTYco2CV/ziGS8e+zYe8pHvGN3rDtC74yHvktf85jnfl8d3HvSh51fZ643N0vcx7aJX/epZT5i/tx72sRcX6c9uxsvfIfOy1/3ueU+Tz/ce+MGnFeVPv9Xb2yH3wlf+8pnvkN83H/rRZxTxa3/T6tMi+dLX/va5n47Xdx/84Z8T9e/NyOMjP/XiV//62U+P77cf/vGHEvmta/3yVzTx8tf//vnfjef3HwADUEToLzlOqvhS/iH7BFABF5ABBeH/GhACIzBAaO/+8OT86iABJVADN5ADv+D9OhAEQ7BOWKjyuqoEUyr9RFAFV5AF0eADWxAGY3A4KLD+PukAETAFZVAHd5AHgeABexAIg7A0aLAA7a8GsS8HhVAJl5AJQ+AHmxAKo5AxiLAIa+sGRykJpVALt3ALX5ALvxAM/WKI6q7w3ikLwxAN03AFn1AN29ANw2LY+ukEFyED39AO73D12BAP95APlSIOr9Ctrq8W6rAPC9EQ+c4LD1ERFxEodGro5hAF848RJ5ESgy8RKxETMxElyvCx1AkSI9EPNFEUR5Hz9JAUTxEVHcKrPO4TE4EQUxEW/mMxsUxRFmvRFvOhrR6ME81QEm/RF3/xuy4RGIeRGNdhFzsREInrAjHvDIvRGZ/xpV6AFqGRGqvxGfzqGD9uGXGvGa3RG78xntZlBaYRHMvRHHUhG5FREK+rAtGuF88RHuNRnJ4gBchRHu8RH1EhHdVxHZ+mFUHxF/JRIAcymA6lBISRIBNSIX9kH/mxHQOxH90xFBeSIitSk0phBOzRIjeSI/UA0fjrkRqyE16xI0vSJAFoQz5AI0+SJVsSDfbLuCKyirYR77rRJW8SJ0doGzwAIXPSJ38SDGCSHR9SGf+RDm0SKJNSKfeHNDSgJ5cSKqPyhSxQJC3PEatyJJFS/iq3kiunpy2w4Sm7UizHstjQa50+0h8JDy2R8B3J0i3fEnqcwgJWEi7rcillsijXMi0bSSidpy3tEjADc3UQgwLCUjAPUymp8J+MRRv70mz+EjEjUzIRhzcigC4nEzMtsrjsTraO6bPWw1UgMzNHkzTXhj8kyDBLUzUr8jPxsgQ+U0y0cjVnkzZjxkYYIDVrUzfxsTWrEAb4SkVkczeHkzgnpk0SIDeLUzm/sTfNEoiOShlIcjmnkzpt5VOiJTmrUzuHsTdzQFKWQTq3UzzHM1NcJlfIEz1Zs7GU504aRDjTEz7j0zrN8zjl0z4J8jsZJ1WcITzv0z//M0voU0oA/pRA83E/m2YzoaE/C5RBG5RHBPQ2HVRCDdQ5v6BCq2FBJ1RDN/RDIPQ0ORREQxQ831NES9REd8RDK/NEV5RFcSFDWxRGYxQ7UnQ0ZNRGbxQLRRNHd5RHLYRG2aJHg1RIuYtEh9RIj7Q6frQpkJRJm/S9itRJo1RKL0lJm3JKrxRL1+BFs5RLu3QuqtRKvVRMxzQLtpRMzxRNtQJMdzJN29RNhcBM31RO51Qo1jQl6RRP8zQG4lRP+9RPUcJOb+RPB5VQRYBPCxVREzUiAvVOFdVRH5UBDhVSJ5VS84FRt6NSM1VRJVVTO9VTy+FS2fRTR3VOOZVUTxVVoSFUeyNV/lt1TE3VVWNVVnlhVcN0Vm/1SGEVV3eVV1ehVleiV4OVR3VVWIvVWKPkV1n1WJfVRImVWZ8VWg8hWTE1WqtVQp3VWrNVW+dgWjFyW7/1PrEVXMeVXMmgW0GlXNN1PMVVXdvVXZHgXA3yXed1ONmVXu8VX20gXuU1X/t1NO3VXwNWYDNyX/l1YA8WMAEWYReWYS2zYA22YSOWKxVWYit2YR/WWy1WY6GSYjfWY+kVYzP2Y0cWJzuWZE92W0NWUFGWZU/SZFsWZo1VZVc2ZmuWIl/WZnPWVWe2UXXWZ+8RZ39WaDOVZ3t2aI/2G4MWaZd2UIuWWpkWaqlRaaOWat3U/mmftmqz9henVmu7FkuvVlS9VmxhkWvH1myHdE0HwDzPlm1PsWzbFm5bNG0RIDvj1m6B8G3vVm81dG4VQFr2FnANMW8Dl3Dts28b4DoLV3HfcHAX13Gr83AfoD4fl3K/sHErF3NnM3IlIEIz13Ob8HI/V3QRc3MLUztGF3WDMHRTl3XFsnQvQEVbV3ZbcHVn13Z/8nUzgDBvl3dBsHZ7F3g5Mnc5QC6D13gh8HePV3nzcXh5EliXF3oBMHmjl3qtsXmdUFmrV3vZb3q313t98XoJ1mi/l3yjr3vLF31FMXxNYHzT132B73zfV34NcX1Vwk3mF395L37zl3/TsH7H/hFd+1eAW29/B9iAm/B/W4AeD5iBQa+AGxiCYzCBYUAcI9iCG++BL1iDN3CCZeBlNhiE+S6DQ5iE+6+DSxiFwW+EU5iFxe+EWxiGoW+FY5iGl++FaxiHg2+Gc5iHYe+GexiIY2+Hg5iIJe+HixiJRW+Ik5iJERFMmxiKmW+Jo5iKD+yIqxiLF2+Ks5iL4+uKuxiM926Lw5iMneuLyxiN2W6M05iNW+uM2xiOB2yN45iOK+uN6xiP6WuO85iP6+qO+xiQw2uPA5mQreqPCxmRpWuQE5mRfeqQGxmSf2uRI5mSPeqRKxmTW2uSM5mTD+qSOxmUOWuTQ5mUw/GJSxmV/slrlFOZlanpk1sZlgdrlWOZlnnplWsZl+dqlnOZl0/plnsZmMVql4OZmBPpl4sZmaNqmJOZmenomJsZmn9qmaOZmrnomasZm11qmrOZm4/omrsZnD1qm8OZnFPom8sZnR1qnNOZnSnonNsZngtqneOZnvnnnesZn+tpnvOZn8/nnvsZoM1pnwOaoKPnnwsaob1poBOaoXnnoBsaoptpoSOaoj3noSsao39pojOaoxPnojsapF1po0OapOfmo0sapU1ppFOapb3mpFsapitppWOappHmpWsapw9ppnOap2fmpnsaqO1op4OaqDnmp4saqd1oqJOaqQ/mqJsaqrto/qmjmqrh5amrGqufaKqzmqvF5aq7GqyNaKvDmqyX5avLGq1taKzTmq1r5azbGq5PaK3jmq475a3rGq8vaK7zmq8V5a77GrAdaK8Dm7Dn5K8LG7EBaLATm7HL5LAbG7LfZ7Ejm7Kb5LErG7PPZ7Izm7Nz5LI7G7SxZ7NDm7RD5LNLG7WhZ7RTm7Un5LRbG7Z/Z7Vjm7b147VrG7djZ7Zzm7cd75R7G7hRaLeDm7in47aLG7k3Z7iTm7l/47ibG7olZ7mjm7ph47mrG7srJEHfA0qz27sJ5bq/W7w/wzGNcLtHVEfHW70tJbzX270x41t+007cM73f274Bpb3vW78d/oMxbS9P0Hsi91vA/yS/B9zAC6O/zQ86jaS7D9zBPfu3H1zCveO8bTCrGLy+J1zDkaTAN9zD66JVFBw4jWG6P9zEq6LDT1zF3eJxkhEkYXNPGnzFZ/w/UpzGb5wshMXFZ9IxQ/xeMhzHgxxCbFzIi1wraso1Y7J7EhxygNzIn/w+iBzKp5wqjGnHRUst9RKunJzKu/w7pNzLwxwpkDzJN6C8Y0vLPUjGxZzNqbRK2xzOh9DKrzzRjjHNlWvN41zPASbC99zP4XvOyxwiBR3NaZIZufzPE701wFzRG30mEgaZ7rwx6Zyb8tzRL70xGB3TN/0kyibSIUvSUQ/ROZ3U/iVD00sd1UPiY4gJK7EyE0o81WN9Gk5d1ms9I2yG1bfL1SHJ0m3d18mC1n9d2B+CdNiKvXbdEmB92JddF4Kd2Z8dIZjG2Cm9LAldjQIc2rNdLpxd27u9H76nr3TRKA1B2b3d3D+B289d3e0hbMI9m8adtHp93ec9JtKd3u+9bobL3a39rwx9Dsod3wM+Eexd4AueHBLIk5Cd3qj9q+Td4B+eIgge4ifeG/Qm4eXQ3+MA4Cme491A4jse5KVhcS6e4euc33MU20Ne5Ufi41fe5Zehg0j+5Ps9499g418e57Gg5XOe54kBdEKy8uD9vxy+54teHHbe6JMeHUsP6Eu+/r2cntdHXemnfh2QnuqvXhbOqOlnftB9cxCJHuvDHhmsXuzLnhWSZ+uJEnygPtnB3uzfvtn7HO7nntjRvuQVnjO5XqDcnu773hXI3u8DPxP0aJHmUOgB4eYFX/ElV+4X3/H9IXwKX6kOXw8S//EfH/AvX/MdgY8kn+1NXu1bwfI33+8zn/RPX97ix/P1vusPD/FSHvVjnxVMX/ZrXxAKaPVDf+1Zf6ek3vZ/3xFoH/iHvw5mKfeP0Ap5XxNGn/hzXvibH/o/J4PwCO+J7vOTie+jX/vB4Pm33/v5KRmpHxIp/9Bh//vPPw+6H/3XXwwUcyiR38J1X9TNn/3r3+Mb/t/+818ZOo7hP5H8uZEAZE/qcvvDKCet9uKsN+/+g6E4kqV5oqm6sq37wrE807V947m+873/A4PCIbFoPCKTyiWz6XxCo9IptWq9YrPaLRcX+ILD4jG5bAZ30+o1u+1+w+PyOb1uv+Pz+j2/7/8DBgoOEhYaHiImKi4qATg+PnZATopMUs5YQjK2HHRufoKGio6SlpqeoqaqrrK2ur7CxsrO0tba3uKWnO3y9n7lAgcLDxMXGx8jJysvMzc7P0NHS09TV7dlRnJgA1Ru02xzI3ceWJebn6Onq6+zt7u/w8fLz9PX2997+erv/+L7/wMMKHAgwYIGDyJMqHAhw4YO/qOB8+AtRERME4+NQ/BwI8eOHj+CDClyJMmSJk+iTEmQH8teKl/CjClzJs2aNm/izKlzJ8+eNS5qw9ZNqEWiGDP6TKp0KdOmTp9CjSp1KtWqBVtiNWN1K9euXr+CDSt2LNmyZs8GqijJ6Ae1MdwWyygALd26du/izat3L9++fv+2ySpYDODChg8jTqx4MePGjh9DNgF3A1CJlV9MHiY3MufOnj+DDi16NOnSpoUMTh3gNOvWrl/Dji17Nu3atktcpszW8m7MuYVtvi18OPHixo8jT658uR3Vg5lDjy59OvXq1q9jz04ns4bf3b2v4B4suPby5s+jT69+Pfv2C50L/nYvfz79+vbv48+vf6b4DOAx9KdCgLiQt5+BByKYoIILMtiggwvAl9WDE1JYoYUXYpihhhum8B+AvQUFYgsDUiGXiSeimKKKK7LYoosvwhijjDPSWKONN+KYo4478tijjz8CGaSQQxJZpJFHIpmkkksy2aSTT0IZpZRTUlmllVdimaWWW3LZpZdfghmmmGOSWaaZZ6KZppprstmmm2/CGaecc9I5ZIRY1Zmnnnvy2aeffwIaqKCDElqooYcimqiiizLaqKOPQhqppJNSWqmll2KaqaaATkGiBR5+CuoJnkqxqamnopqqqquy2qqrr8Iaq6yz0lqrrbfimquuu/La/quvvz56Z0vAElussccim6yyyzLbrLPPQhuttNNSW62112Kb7ZVSkFqBqBR0S0K4T2hbrrnnopuuuuuy266778Ibr7zz0luvvfduKixL+PLbr7//AhywwAMTXLDBByOcsMILM+wqt996K+J3EocHMRQNY5yxxhtz3LHHH4Mcssgjk1yyyScrqS8/KLPcsssvwxyzzDPTXLPNN+OcM8xRjDuBxRH0TNHPTuhctNFHI5200ksz3bTTT0MdtdQqqrzP1FdjnbXWW3Pdtddfgx222GNbCUXQEgz9wNltpc0E2W/DHbfcc9Ndt91345233rtWrc/efwMeuOCDE1644Ycj/p443Ga3DTTFHz7eYeNKKF655Zdjnrnmm3Peueefn9q3L6CTXrrpp6Oeuuqrs97650+s7XgmQ81eVO1HjcOh7rvz3rvvvwMfvDqiuyS88ccjn7zyyzPf/Faxy24J7dLbTj3unjifvfbbc9+999+DTwHxvIRfvvnno5+++uuzbwf0EEy+ADjhvBX/KgW2n7/++/Pfv///12V8uwAgAQtowAMiMIEK5ND74Be5UNlvYrczBv4WaMELYjCDGtwgB2EhwDN0MIQiHCEJS2jCE1qlgQ6cINseKJkIpqKCKJwhDWtowxviMIcR+KBWdOjDHwIxiEIcIhFLoUK1uTBiSRQX/gxRIcMiQjGKUpwiFavYHh6WwYpa3CIXu+jFL4IRXE1EIgt5U0YWzC8ZTwwjG9voxjfCMY5JwSIZ5GjHO+Ixj3rcI/COuELrgcCPSjyjZpDCx0MiMpGKXCQjc0HHMTQykpKcJCUracnHCNIBTcykz8Z4ijVeMpSiHCUpS2nKGDySMKdcJStb6cpXwjIgnGzAJj0pxiXSApSx3CUve+nLX0oxlWEAJjGLacxjIjOZgJgfM5vpzGcCMnrRHJEtS6FLZWIzm9rcJjd/J0w0dDOc4hwnOctpTt1AM53qVCcECSk5XM7imuecJz3rac97luab/cAnP/vpz38CNI/rHChB/tM4yGkKaJajkGdAG+rQh0I0ojPR52okatGLYjSjGu1fQTvqUUe0E6HvdCdwDLnRk6I0pSpdaTQoytKXwjSmMp0pfT5q04GG9BIuUOhCTUrTnwI1qEId6htcStSjIjWpSl1qYW7qVGjmVKdorKY1fcrUq2I1q1rdKgaMytWvgjWsYh2rR55qVmZegKfyU2soGErWt8I1rnItp1fnate74jWves3FWfu6RLYmALCgcOteC2vYwyJWjnVNLGMb69jHQrYLfp2sJqKajanCM5dWjSxnO+vZz3JwsaAdLWlLa9rTMsGWgBXsJwiL2tfCNrayfZBoZ2vb2+I2t7plgGqp/rrWzGo2d7sdLnGLa9zl1Pa4yl0uc5vL1d4CF3IkLaRwnWvd62I3u3lJrna7693vghef1eSpQZfh2vCiN73qXa9DuMve98I3vvKl5Hh9OwDWDnaz890vf/vr35bq878CHjCBCxzF+lK1vObVr4Eb7OAHQ7gQ7o0whSts4QuXL8Eajm5wsYfhD4M4xCJWwoRHbOITozjF+9kwh/84XWKcV8UynjGNaVziGuM4xzrecW18q+BA4retDOYxkYtsZP/e+MhKXjKTm4wXH/vxxwuurpOrbOUrDzfJWN4yl7vsZf60uJMwlPKUPfzlM6M5zXbVsprb7OY3w5ke9r3v+9AK/o0YxznPet5zQNnM5z8DOtCCpsWc7RyiOTtxyINeNKMbbUw/OzrSkp40pfGA6GZKENGJpnKlO+3pTysS0qAeNalLbeogaNqZaTV0NPB86lfDOtYiFLWsa23rW+PasvSrGKalSeZmuDrXwh42sbtH62IjO9nKlrSmA0vZyk4j2MueNrWrzaBjWzvb2t72lZvt7GdbQ9rcHje5yy0dbJs73epeN4a9/e2+mkPc7J43vevdGXTbO9/63nd43f3up55D3vweOMELHhZ8GzzhCl84av2tALOiQ+AMnzjFK/4ShFs84xrfeFwd/nCbqkPiHB85yUuOD4ybPOUqXzlMPf5b/pyuQ+QsnznNa24MlNs85zrfOVzT+Q6Z8zzoQh86I3BO9KMjPelBBWk9gK70p0M96l0wutSrbvWr69npWN8617uuA6p7PexiH7uOtU72s6M97RYAu9rb7va3D9jscJ873a/O9rrjPe96d67c9+73v6v87oAfPOELP9q+Gz7xite34Bfv+MdD/q2IjzzlK4/sxls+85rf/Ewnz/nPg57SmA896Utv+n56/vSqX/2ZR8/618M+9sVMvexrb/sau/72ut897yVJ+94DP/gFzr3wi2/843vx98hfPvO1S/zmQz/60p+h8qdv/eu/9vnY3z73u/+/6ns//OLXq/bHb/7z/qOfeeBPP/vbn9Tyuz/+8p//g9ZP//vjH6Pwzz//++//89jf/wngAI7T/hHgASJgAtpGACpgAzrgKxngA0rgBFJgYzBgBWJgBh5SBGpgB3rgB5LFBYLgCJJgFXFgCaJgCqrgTojgCrrgC5bQCcLgDNJgDXZEC9pgDupg/8jgDvrgDwKhPOBgEBJhETJPDxphEirhEirDEDLhE0IhhSBhFFJhFVphDCnaFWrhFh7PFHLhF4JhGPqBE4phGZrhcXjhGarhGrIhFpBhG8JhHIJGGsphHdrhHfrAG+LhHvKhXtBhHwJiIAriCOjhIBriIUrFHyLiIjJiIyZAITpiJEoi/kwo4iRa4iXGISRi4iZy4nsEWCeCYiiKogRo4iia4im6QyWi4iqyog6WYivCYiwqgyrKYi3aIgi+4i3q4i6+Ai3y4i8C4wHmYjASYzEigi8aYzIqY/sN4zI64zPOATJC4zRSo/Q1YzViYzZKgTRqYzd6o+5d4zeK4zj2ADeS4zmi4+eFYzqyYzuegDm6YzzKY+Gt4zza4z1KADzi4z7yo9rVYz8CpDvqY0ASZEFe3T8aZEJm40AqZEM6ZNAh5ENKZDAy5ERa5EWaXERi5EayYkVy5EeCpMJpZEiSpCV6ZEmiZErO20iqZEsG4km6ZEzKZLWx5Eza5BrC5E3q5E7e/lpN8uRPWmFOAuVQEqWn+WRRIiUQCmVSMmVTBtpROmVUruBSSmVVWiWaQeVVamUFUuVWeuVXMllWguVYCmBXkuVZouWMiWVasiX7mWVbwmVcXthaymVdXt9b2mVe6uV/0eVe+mXw4eVfCuZgpldfEuZhsl5gIuZiMiZzGWZjQqblKWZkUmZl2tZjWmZmDt5kamZneqZnYeZnimbbceZomuZpFlZoouZqYl1psuZrwqZYqWZs0qbQuWZt4mZuJtVs6mZvptxt+mZwCudL8eZwGufCAedxKudySlRxMudz0ltyQud0Uqc9OWd1Yqe1SWd2cmd3btN1emd44tp2imd5/ppnL4Hnearnp5Hnerrne5JSesLnfApae9LnfeKnIslnfvJnmtlnfwJogMLRfgpogTbZfxpogipoFRHogjqojX3ig0rohOJTg1LohWIYgmLohnIoCVloh4KogGloiJJoiSrQh5poiqrXiKpoi7po/qDoi8poc7HojNrojXpPjOLojt5WjfLojwKp8ehokBLpZ/lokSJpkmbIkCppkxrWkTpplEopgjDplFrpWEHplWrplrpHlXLplypVloLpmJKpdXhpmaIpTIlpmrJpmxrHmbppnFrUmsppndqpa8DpnerpPdHpnvrpn3ZGngLqoHJTnxLqoSJqYQhqojKqLxlq/qNCaqTSxaJKaqWW0qNaaqZq6lZQ6qZ66iJh6qeK6qgqRaeS6qnGUaii6qqyqkyYaqvCqhWpaqzSaq2GxKvaaq7+0Kzqaq/6KkLg6q8KKwnx6rAa67HaQ7Ai67IqULEy67NCa8RlYbRSKzA5a7Via7YC27Rqa7ee0rV6a7iKay4o67iaK/KA67mq67qyQrmy67tuSLrC67zS6ya4a73iq4LIa77ya78Cwr36a8DOx74KbMEarBwA7MEqLHYQ7MI67MNqQcJC7MQiR8NS7MVirNtwa8ZyLAFZbMeCbMj+gMSKbMnOYYSabMqq7J1t7Mq6bPZ87MvK7MyWAMnS7M3i/kXM4uzO8uwF2GzPAu1X6GzQEm3RKsDPGm3SOsXQKm3TxmRHNcIz/VzLOm3VugfTWm3WfiTEDUFBsQPSam3YqgTWim3ZKuSz7ZoOOFU6gK3Zuq1HkO3byi0/oi204QDXxhvVzu3e3kbc8u3fumPdipRvwFs5tC3gIu7JoWziMi50Cu6LoQC4hZveNm7l3tviWm7mDufjQi5uoO3kcprmiq5n+O3omu40eu1HEW7dVsPhnu7rziLmwu7sviar6VqzQRUZqVq0US7t+u5YlO7vCu8vhtm//RoT2a6vuVx+he7wOm9ZBO/zSq8sStX0kFfy3tLxqlHvTm/3zpHsem/4/kLmZY0K9lpv52qS+TYh94pv+9JE9Lpv/Iqj+ppR/NDv9ZCD/OovT8Dv/vpvNmrvWjRQAFMQ+/7vAT9E/yLwAj8jAfuHAx8U+o6HATNwBQ+EAltwBhcjBK/aGN0vjFGwBovwPGDwCJvwLnJw9krw7abt+jbvCcOw4n5TDNMwbB5RCndw8b6C69ZwD/tACftwEKOiCuFwDq/wLfCwECuxDADxEjtxKA6wfQWZvYbwE1sxLTTxFWuxJdbZ9S4vIiTxFosxB2TxGJsxI3ZxoX3xIYTxGbvxDoHvG8txXKbxEWda9YpDFc/xHgtCGfPxH+Mh9BTxHeNxAb8wICNyIvhx/iIzchsKMu6ucSG0cSMv8SJT8iWrof1Csg63qx5j8idngSWD8ihz4SNzspidMhYeMimzshqIcivDMhXGziAf2uCW1CrHci5TwSvrci8n4Sy72xQnwiT7svzycjEjcxACcyqjsi1PMC4nczQDwTFLczXboCYzM9pE8iAQszULLzV7czjD4OTQsgDbcSx0szi/Ljirczuj4DKfc/0WMnWZmTvb8wqw8z3rswdiczybszOTqyfv80ArQD4T9EFLoCn7cy3P8y3XM0JDdAUYdERTNAIqNEC/UDZXFTRXdERPdEeDtP/VMUZ7rkaTQjqHdNJ+dEqz9P1FsUlrM0wLGUe3/rQ6r3RN43T7lfPLLTRD221cCHROg/JNC3VRj98HR3BDJ5RMM+9DG7U1E/VTSzX29RqQeZwwGwJKTzXIRvVWezX07a7QMLWLKXVA0/RXY3JXo/VaC5/UIm9P+zT5AvVZszUgq3Vd47XtsVNJwzU69bUqO3VeM/JdC3ZhR14L05lHRa7LYbUkB7Vh0zBhQ/ZkL17hLvZY6y5J14JWUza7SnZngzbhARxm/fUDYzYjcHZoh+tnq3Zr+53qwgBWNzYhpLZrVytr23Zu1x1B/QRjb/O/PrZuiy9uC3dxv93aUtNp09Jv/0FtG/evEvdzSzfanRWvlbZ0aXaH5e90i3B0/nP3d4vdZF32dRtxWRNIcIO36Xp3erP31iE2cr91dse3eZeI69j3feN3fuv3fvN3f/u3AFDUfwv4gBN4gRv4gSN4giv4gjN4zliaz833T6+ufJNLg1v4hWN4hmv4hnN4h7NKgHt4iIv4iJN4iZv4iaN4iqt4iPNB7oo1ed/uGqz4jNN4jdv4jeN4jq8OiOt4j/v4jwN5kAv5kBN5kRv5rvxBWLcQjCe1XG/BkUN5lEv5lFN5lVs5tPD4lWv5lnN5l3v5l4N5mIu5gacFUqswfZevcuPAmLN5m7v5m8N5nMt5i2T5nNv5neN5nuv5nvN5n/u5sgyCmcc0k5+5hEfs/p8jeqIr+qIzeqMXTp07eqRL+qRTeqVb+qVjuqITwk5/nJrzNJqXSqaL+qiTeqmb+qmjC6Sj+qqzequ7+qvDeqzLOt0UAqcnNqE3M6hrt0a0t++ud68De+hxuq37NYWjM3oHu0rHcbIz+xCTszDPNjcje7P37K9T+7VnHjwbu1Xj+kwHNra/rbWD+7gf9rN7uvEaukNvN7mH+7Kz+7tj4tpMMbGrgnPDu5OK+73ru+HJu8NFu7TT9b7TbL4LfMH/Xb+f+78Lgr0bPI4SfMNDvN41zrwzd3NPe8QH7MNj/MbP3dlQ/LmD8cVzPL1q/MibfNshfLenL8izscifvLqW/vzLyzzZpfy2x7WTg3DAz3zGu/vO+7wc1ryuc7vNwwLD/7yBxvzRKz3WBX26jzfR77DLLz2yJv3UW73UNb3TZ7TKe/u6Xz2/Vv3Xi33SabvQ/zPUu4LRj715hv3au/3Qlb3WRzjOz/W3v723tv3d673OxT3dbz3ap73U7/2n5v3gG/7M2fpqVTxw6/zh62rhO37km9xImz0h+33O273k+yrka37ncxzly/2LA37gN77nkyrnm37qV9xLdzu9t4Laqz5qon7s077C0bsXc31PlX7tQ+rs8/7vDxwRz5Lrv77gA7977tMQ+P7xM7+9Ef/wL/7CG3/zl+cwoUbPU3/2/o8g8d86jHN/J+++9gMoJP0w9ov/+WugoLPw3F++IWc++itoFu3A8sN//Wvb93f/6Hc6y6P29Ns/cxJAfBxdbn8YGaLVXozl5t1/MBRHsjRPNFVXtnVfOJZnurZvPNd3vvd/YFA4JBaNR2RSuWQ2nU9oVDqlVq1XbFa75Xa9X3BYPCaXzWd0Wr1mt90xQFw+l8Po99Wd/s4K/H8BPsFBwkLDQ8RExUXGRsdHyEjJScpKy0vMTM3NqwwDH89Q0VDOUtNT1FTVVdZW11fYWNlZ2lrbW9xc3V3eXt9f4GDhYRM9PDjjuJTkOmIOwD9n6Wnqautr7Gztbe5u72/wcHGi/lGd0XP0g/F19nb3d/h4+Xn6evt7/Hz9ff5+/3+A1ZTZYNYMGbMTBQF4g+Yn4EOIESVOpFjR4kWMGTVuxIbuRjqQojiOJFnS5EmUKVWuZNnS5UuYMWXOpFnzwZ6DBWsoXCiC57eGgWwOJVrU6FGkSZUuZdo0HMgZIaVqcFrV6lWsWbVu5drV61ewYcWOJRvMWAueA3f+/MCWYcOyceXOpVvX7l28efW+kQpj6l8KewUPJlzY8GHEiRUvZtzY8eOuCoulVUsw7QbKPd9Cg9zZ82fQoUWPJl060V8WgFUHMN3a9WvYsWXPpl3b9m3cufVlruyAN84cv4Ub3AxI93Hk/smVL2fe3Lk81SlWA35e3fp17Nm1b+fe3ft38BOHjz/Lg3xmcUHDr2ff3v17+PGxTy8xHbV8/Pn17+ff3/9/AAMUsLHzCgSiQJ3GUW9ABht08EEII5TQGvtYC6HCvibUcEMOO/TwQxBDFHFEEntAcDwhTtSDnQVLdPFFGGOUccYZMbSQAxuhonFHHnv08UcggxRySCI3UpE3I47sLZwWi3TySSijlHLKrXK8EQIrPaJySy679PJLMMMUc0wyQVASoSRUfKfJMtt0800445RzkyyvXKDOcubUc08++/TzT0ADFXSrM4lT4rx42Bx0UUYbdfRRSAfA88pJSYn0Ukwz/tV0U0479fTTMxCtAsl5FAX1VFRTVXXV7ip11RNWY5V1VlprtfVWXLk0VIwl6zE1V2CDFXZYYo969dgKilV2WWabdfZZaKOVtotfp7X2Wmyz1XYWZLvd9ltwwxV3XHLLNbfMas9Vd11223UXlG5ffXdeeuu1915889W3sHT39fdfgAMmNt5KBTb4YIQTVnhhhhsOpl+HI5Z4YoqLJBjPijPWeGOOO/b4Y5BZgDhkkks2+WTnLrYSZZZbdvllmGOWOdaRZ7b5Zpxz5kplG3X2+WeggxZ6aKL9q7lopJNWeml6eLaPaaijlnpqqqu2+qqjr9Z6a667tsTp1bwWe2yy/ss2+2y0c8k6bbbbdvttIcC+D26667b7brzz1juHtff2+2/A05Y7w8ALN/xwxBNXXOi+F3f8cchZHjydyCu3/HLMM9c83MY39/xz0Nmd/JzQSzf9dNRTV53Mzld3/XXYUx1dpNhrt/123HPXHbzWd/f9d+C5nD3P4Is3/njkk1e+q96Xd/556BkcnvToq7f+euyz136d5rf3/nvwb5tey/DLN/989NNXn4/u13f/ffjlGp/6+Ou3/37889d/hPb39/9/AKZkfpYKYAENeEAEJhB3/VNgAx34QHcMkCoQpGAFLXhBDJKNgRnkYAc9CAsJTvCDIyRhCU14wohtEIUr/mRhC9cQwgy4UIYzpGENbUgsFd5Qhzvk4Q9gCKseBlGIQyRiEb+UQyMmUYlLvNMPgchEKEZRilOkYn6QWEUsZrGDTqSdFr34RTCGUYyfueIYzXhG+HGxi2hkYxvd+EY4GqWMcaRjHYunRuLZUY975GMf/SiPOf5RkIO8HB7pR0hEJlKRi2SkKgLZSEhGUnCGPKQkLXlJTGZSk1t45CY9+cmgUZJ8oCRlKU15SlSeoJOpZGUrKyZKyrlSlrOkZS0XuUpb5lKX74Kljnb5S2AGU5hMxOUwjXlMZvUyJMhkZjOd+UwLFhOa06Qmp5RJuGpmU5vb5Cb2pNlNcIbzTZOb/kDBxHlOdKZTnaH75jrd+U4fkfMBk4JnPe15T3yyrZ355Gc/HTS6DdTJnwMlaEENarN9HlShC+UOQD2wMoZGVKITpei/ElpRjGYUNvK8EIY0+lGQhlSkzbroSE16UsFwlAQVQmlLXfpSmDaqpDGlaU2r4lAU0MemO+VpT306pJn+VKhDPQlOVxAdoiZVqUtlKoCC2lSoRhUfRnXB3KR6VaxmVau4eepWvfpVCg3OBtgEa1nNela04qWraWVrW12h0rHG0q1zpWtd7WqTtd5Vr3tVBFVxMEq+BlawgyWsPvJaWMQmtgt+3UEeFftYyEZWssA47GQte9m4iZUcT8Rs/mc9+1nQSqKyoSVtaU0A181ewLSrZW1rXUstuLxWtrMNAmOLoFra5la3u+VtDUbbW+Ai1rZISFZwjXtc5CZ3Ab9VbnPROtwlJMC506VudT/LXOtmt6molcIntPtd8IbXrtgVb3ljyl3zple9600uedn73opCF77zpW99Pete++Y3n/LVb3/9+9/xxhbAA1Yqegl8YAQnGKv4VXCDj2lgB0dYwhOGKYMpfOFW8hfDG+ZwhwtqYQ+H2JIaFnGJTXziboIYxSvmI4lZ/GIYx1iXKpZxjccIYRvnWMc7/iSNefzjJeIYyEMmcpH76GMjJ5mGLlZyk538ZCoiGcpT5iCT/ql8ZSxnmYZS1nKXDShkL4dZzGPOIJfJfGb3gRnNa2Zzm/NnZjfH+XpWlnOd7Xzn6sEZz3v+HZ35/GdAB7p2ehZ0oVHnZ0MnWtGLrhyhGf3oyKkZ0pOmdKX35mhLZ1pvktZ0pz396a5hGtSjLhuiSX1qVKcaZ6JWdauhZmpXx1rWs94Yq2l965xxGte75nWvDWZrXwebZLoWdrGNfWxzARvZy24YrJn9bGhHW1jKlna18eVsa2db29vmFLW5/e1xYRvc4yZ3ufXkbXOn+1nEVne73f1uL6Eb3vOuFbvpfW9855tG8tZ3vzclbn8HXOADFxC/CX7wPwEc4QtneMO9/mNwh0d8TPaWeMUtfnHlQBzjG7eYZjn+cZCH/DgaF3nJX6Rwk6dc5SunC8lZ/vIIoRzmM6d5zZvicpvnPD8y13nPff7zleAc6ENvqMeJfnSkJx0mQld6049DcadHXepTtwfTqX710vAc61vneteJYXWvhz0xWhd72c1+dleAHe1rpwvU2f52uMddE2qXe92z4na7513veycE3fn+96GQHfCDJ3zhqeB3wye+qHhXfOMd//gjIB7yk4+I4Cl/ecxnPgWS13zn68F4z4de9KN/hoBJf/q8gB71q2d95znfetg7w/Kxp33t9f562+f+FrPXfe99X3bc/174qlD98I1//vyuBx/5y6dE8Zn/fOgjXfnRp74heF997Ge/5NPXfvfPcH3vh1/8Duf++M2fBfCfX/3rz3f52f9+Jjgf/vOnv0KHIwX0lMr09ee/MOTffwAMwHVSkyUgj0TZPwFMQFpIPwVsQAcUpkLplR84Endwvwe8wJX6PwzcQA60pQg8hiA4k3awwA4swXkyOhNMQRVkpg9MhgP5QO5BwBWcwULQQBq8QRxMpBaUDPPYQQWRwRwMQjNgQCEsQiNEox1MkOBIQs0ACiA8QijEAiKMQiqsQipiQjSxDCxswm4gQSscvyn8QjEcwyKijLYglbW4DAhAwy58QjJ8QyCwQTicQzoU/iIlJAEzpAE17IA8bEPOqENAbCwUDERCLMQsKg8V2EM74MEQUERt8EJD1L0wjERKrEQKAg4WcIsX0MRGZMRtgERLZL1JDEVSLMUC2pVM9MRUvEM8ZEVsAEVTDD05jEVarEUD4sJFdMVl0MUR4MVqgEVbnLxZDEZiLEYZUsVdzEIUQEZrAEZjLLxRfEZpnMYK8sUSsMZexMavc0NqFMNo7EZwDMcD0kYzUcY8MMdm5EZxNMJvXEd3fEf8IcczdMFNREdqcEZ4FLthzEd+7Mf9scdWpMd6FMhrwEd/pLp9PEiFXEj3kUcOAMhzRMSCVEeGbMB2rEiMzMjncUgJ4Mhs/iTIX6RIjay/ixxJkzzJ4IHIcgTJgVyRVxRJlFS/hIxJmqxJ41HJeXTJGcBJYTBImzS5mfxJoRzK2+HJhzTKZURKX/BJosS4kmxKqIxKzFHKCKDKhGBJaWBKqWS4p9xKr/zKxLHKm8DKXNTJkPxDsGS+rkxLtmxLvRFL3yDLljTLadBKt6S3oLxLvdzLv4FLBvDIq5TIuoRJvvS8vCxMxExMuPHLBWDMgKTLrCRMxYS8tZxMy7zMqXHMAdBMn5DLnpRMzCS8ygxN0ixNotFMzuxEwYxMtDRNyhxE14xN2XxLzzzK2pxLTGRN45jNxDtM3vxN4NQZwPzL28TNOUjH/tYMzrwbTeVsTufkmOFszOJ0gdSMBbt8zlFjTuzcTu5sGNScTrQAz124zu6sNO0sT/RMT4D5ztVMQ8jcxuRUT4SETfmsT/u8meiUzvbUQ/HUBfK8zz/zTQAdUALNF86szs7cz4cBzQJNufNsUAiNUGxhTwXdyf7Ehf+UUDJ7UA3tUA9dlvxUgBCdjAr9hQz90CwTUBRdURaNlgNFUNV8z8+MzxbdOBWtURzNUWEZ0c280IiU0QWlUR1tOA4dUiM90kxJTRiNURDUzWhAUq68USidUirtFB7t0RKVgSVlhROtUhQrUi8NUzGdkyvd0pxsUmfo0jHtMCldUzd90z65/lIsBVL+zNJeUFM4jbA2zVM+7dM2QVAz9YBATQU89dMBA1NDTVRF/RE5nVM0xYFBRYVCXdT6QlRKvVRMdZFGddTchFQftYVJzVT12lNRLVVTnZFNjVTM+NRaCNVT1S5SfVVZnVUQ2VROPc4etFNecFVaVS5L7VVgDdb8sNVbRUUtpFMTZVBhTbRfXVZnfdbwIFZV7UhWPbyguFZszVZt3VZu7VZv/VZwDVdxHVdyLVdzPVd0TVd1XVd2bVd3fVd4jVd5nVd6rVd7vVd8zVd93Vd+7Vd//VeADViBHViCLViDPViETViFXViGbViHfViIjViJnViKrViLvViJHR2M/t1Yju1Yj/1YkA1ZkR1Zki1Zkz1ZlE1ZlV1Zlm1Zl31ZmI1ZmZ1Zmq1Zm71ZnM1Znd1Znu1Zn/1ZoA1aoR1aoi1aoz1apE1apVXYRiDWYpVA93zUMVhaqq1aq71arM1ard1aru1ar/1asA1bsR1bsi1bs9XXyTlbtV1btm1bt31buI1buZ1buq1bu71bvM1bvd1bvu1bv/1bwA1cwR1cwi1cw01aRnDap8XFG5jWIjhcyI1cyZ1cyq1cy71czM1czd1czjXctO1c0A1d0R1d0i1d0z1d1E1d1V1d1m1d131d2I1d2Z1d2q1d2/XYRVDcxTWRap2C2/1d4A1e4R1e/uItXuM9XuRNXpHVWOVtXud9XuiNXumdXuqtXuu9XuzNXu3dXu7tXu/9XtHN3UF13DXsXSkAX/RNX/VdX/ZtX/d9X/hlXeaNX/qtX/u9X/zNX/3dX/7tX//9XwAOYAEeYALuWkXQ3d3NVWT1ggJuYAd+YAiOYAmeYApO3c+tYAzOYA3eYA7uYA/+YBAOYREeYRIuYRP23kRA4ATeAfLdBF6F1smKVRieYRr+DxVeYR1o4blT1hqmsmbtYSAO4uu44cVl3Kjt1GF4YSHWqx9eYid+4uNgRurUYeLU1fHkYSjesSbOYp7yLiLz4tKUYuM01jpd4DvFYi6WMRlOY6yS/i4gc2PSJGL9NOMxhlrKQmM2/lL6zGPSKi4e82PMlOM5ltoypuMrFlI+1rEtTmSbwi1FtoDQFORBRuJCpuQZ3U1G1uI1zmSpiqEc8+TJlORJxtUltOJDxmROVuM9TmXQIqAYc+XCFOVRJmMtNV9ZUGJW7uJVzuXPcqwV8+W7lOVZtuOcIORLflJeLrFFTmaaAqwTc+a2FOYqNuQfNeYgRWVmxrBlzubzkqtn9uZopuKxNOVkJGe1wWNufq9tTmeYIqsQc+evlOYGoGJxzgRcZmeM2mR8hiqr8rB+9kox9lRzDkxqPmVk3udD3WWE7iyk8mfqAMuAFuiBvkZbvmV0/l5o6lpnjHYpneKwjpZKeS7fif7IkQbVi95o5NJolG4pltqwlobKiGbhiubDmbbOk17p3tJnnGaqnrmwnibKmJbpkmZSS07im97p2dJppF4qiJKwpv7JoFZga17FgjZoh1jq71JprD4pgdLTLBHKqJbqoq7msT7mq97q6dJqtDYpemqwtqbJsBZrUq7loTZpRF7r3VJrvB4pV1Gwvo7JuObdul7Vmrbpu95r2VJqxE6qY0Gwxj7JwBbsqibquUZObF7sxFZozLYsb0nox9bIyJbsyRbUenbho97swNJr1A4pggGw1s7I0PaB8S1siz7s1eZsxb7toVIZ/+Ltioxt/tk205C259PW7bbKbeMWKqfRr+VWSOB+wcIebuK27eQmLOSu7p+SG/vSbn98buge7Gke7V0tbuzWKtUu74+67sJS7xT07hAE1NIuhXtG70s6b/rWqNmBr/yGR/dOESWV7um+7PuuK/se8Iy6JlDuAS6qLSeKwwZ3cBhi8B+C8Ain8BCycAnCcO5eRwAn66m2Tdqmhfk2cERibxLfKQRPcB5YcA2fnxYfHwm/8BefnhkfnhiXcXiZ8By3cXHscKr2UU58RPI+8UbWbCKPrBRXcUHUcR968B3H8ScfoBvP8CZn8iiX8iqv8BXHcnCMbwuN6yAXcuo+cn42cTJv5ySH/uUl1/Ird/Esh3IFt/I4l/M1h/Mtp3NzcPI81/Ni3EIUmeIwD28fD/CDPvM2NnNDR/M0V/I9Z/M5d/Q6p/I35/I2h/FJp/RHt/NG1/QaSPJY9PP7q+NCYZIhT/T0NnJTf6xFZ/QcYPFLd/NKp/Eav0hXz3RJj3Uex/X9bvVVh2RCBHXhKGYYJPUxT/WaQnRj7+Ze93Vdp3U+j3RMv3NO53U8p3ZIh3ZYt/Vop4FlF6E5BPbfoOsIjMFiT3aWRnZzf6lud2Rtz/Z2t/Rm39Nnx3Z4f3dZf/V6l/Zp94t1Z3Y6BHc2FHVR+cFyT3fWRneDzyZ1sPdln3Vnr/a/mvdN/t/2iaf4iIf4i792a9/3qup3f/92gO9DcT+RESz1hMenAj/5WVqjiu93h5d3ic94jo8rjd/4W9f3m8d5i/+ImH8Bjwfkfw95RxT2Py/5glf5iEJ4pM+lh2b4VX95VJeBWtd5d6f6e4/3qOd3jOf5re/0nvf5n194QBT6oR/5cIeHEV/6HVJ6tUelr8b3Xof6Dcf6ubf6q3d6mO96bv96mq95rvd7rf/5KYdjjAz4NTH5tu+mlE98QoqXwW94uM91ugcbuaf8yueZx893er97u5f8zt91mV/3zOcshiRmtEd8xqemxU/9OgL9z/f0yHf912/TqZ/9urf92295zd98/s/nfdnve9G/fDXH67Rn/RJie+NvMb2PirAXft+O/Xasfd/Pe8D3+uVn/uuPAekHfsiH/qdZ6uJP/irLevGHpu23+e7He+qf+b3Pfu13/8Bnf+yvfuun//mX//iPe+f/aXYO//KnIAKIj6nLzQOjnLTai7PevPsPhuJIluaJpurKtu4Lx/JM1/aN5/rO9/4PDAqHxKLxiEwql8ym8wmNSqcuh/WKzSZ+2q73Cz74wuSygWtOe8fqNhbtji/g8rq4Z8+f2fo6vx+HBzj49kcIRpWouMjY6PgIGSk5SVlpeYmZqfki0OkpsBkqOkpaanqKmqq6ytrq+gobKztLW2t7/ktzqIXL2+v7CxwsPExcbHyMnKy8zNzsrNtGBz19x0NtJn29JqiNaNidlQ1eaD2+zW0ejp5+9c0euP7u4Exfb3+Pn6+/z99P8unJn8CBBAsaPIgwocKFDBs6fAixhrwAEStavIgxo8aNHDt6/Agy5L2J7dzJE4kypcqVtUjKMelyD8uZNGvavIkzpyOAnXT6/Ak0qNChRIsaPYq04MmkTJs6fQo1qtSpVKta3RCzgbh3V7t6/cova5qtWcGaPYs2rdq1GXiCYgs3rty5dOvavYtX59K8fPv6/Qs4sODBhHPMgxmTTgR2hRs7fhyCMQQ3ZBNDvow5s+bNOtxy/gw6/rTo0aRLmxY48bTq1axbu34NO7aHMJVdHjEnO7fumrixdqlNcrfw4cSLV/RsPLny5cybO38uNDX06dSrW7+OPbsjO4ht3+6mPbx4W+BOzOke3N349ezbP0fuPr78+fTr278vYS/+/fz7+/8PYFLToJeeEdoEiGCC8RxCiVjnLXiYghJOSCFO8FWIYYYabshhhwvp52GIIo5IYokmGiYZhGUhQc2JLmbYYoMObkGgOi/eiGOOpVyoY48+/ghkkEJeIN2QRh6JZJJKfjYjRTVylQQ0S05ZnZSVNIkAcGpQyWWXXmLA45dijklmmWYOVuSZaq7JZptu9oNlNeV4FwWD/m/eCZqdV8bp5Jzg4QlooPWFKWihhh6KaKL0pKloo44+CmmkOPDZp5/XSDKIpJrClakllFaqg1ibjkoqZISWimqqqq7KqgogtgprrLLOKiSlWo4VSh+07jqUrrk6eCuUvA5L7E+nFotsssou6+OrzD4LbbTSEmfrkyWtkse02maULSspWjrjtuKOO9Cx5J6Lbrrqusbouu6+C2+8UFWr4gO3+CFvvvbgS54uwX6rb8ACn2LuwAYfjHDCejmrcMMOPwzxIg+CC6x6xcATccaxYDwMvxSLqnHIIhNR8Mgmn4xyyrMwrHLLLr8s8hfWApxSNDDfPInNi3pTL504/ww0/pg8BU100UYf/fGBSC/NdNOrchwqvSzh6nTVRFDtT4RJW4aO1V63WvLXYo9Ntsbtlo122mq/qOfWPk9Nxtpyw1DGVFLvYOPcepMZ9t5+/w14q2cHTnjhhjfXW88F0kTb4Y5n0LhUd0dd9+OWj9j35ZpvzvmQg3cOeuii0wWy4p/XfM7oh8ts9+ST+qp67O1lLnvttt8uH8u478577yu5/nrpPv3mu9/Et87nzFAXz3xrtDcPffTSh6b79NZfj/2+ySvfLVN5Zy/291EBf8Pb4J/P1/Por89++8jT7H788s+PCvk2WHnVtfQvrX9Vcf6bjv0JUCrqG6ABD4hAiJwu/oEMbKADhWA/ibyEU1p5INC0ppYF5mJ7FuxgTQrowRCKcIT9gh8JT4jCFHIgghtkHV/spUKUwTAvl+JeeWKIw+MMLYc87KEPZWTCHwpxiIGjkdvMF7yJFUYBRDSbERujBwAmrolUzAcIq4jFLGpRBBrcohe/aLJdmK6L2MkSGBFmRupVbozCOqMbgXHFN8pxjjgkIx3viMdpbcmGf5qPTPIYrz+yhhxHtCPdAInIIcQxkYxs5PoM6chISrJRgJDiOCaJSVrJCW8cdFsmP1mCRYJylKTUXPVKicpUJqmPhTylKl85rk/xEVSwxKQoa4nLXDLNlbrspS8ThMQkNumX/sSMlizZmLpinvGWymymMxUGyWdKc5rJYeEM/kfNbMLKmjKIkTZ5yMxvinOcy4omOc+Jzjx1kpNtTKc7NcXNGPDyne0LJz3viU9KtjOf/OwnFNdJOfz5c6CKiifdhknQ7NkzoQxtqJLm6dCIStR/AEURdyaK0UdxrZX7zKjtFurRkIoUQ+YcqUlPOpNjcnSGKG2po26IzAC6VHUgnalNb5qdkuJ0pzx9hSADitBC9nSom+pUTKdIVMfVNKlMbapqdOrUqEp1Cv0DarjYMNWskkpnK5WpVv+21K+Kdaw07ChZz4pWS27SqhVLq1sDKcajXvKtaQsrXe+K16ZAFJM//s2rX0/Rva4i9a+EJRcT5TrXpBV2XHZdrGMfGxKoNjKNkK2sIrwp2MRadrM3M+gLeMZZWTU2tKQtLWr2+snDmna1mY3iLGvI2thGzLNVWJ5sEzXa2+p2t79ALShZytvgziaorWWlcI/7Ltq2wF/IZVNumwvd6G7Ct6PEoHSbq1wWbPS63EVXdlfg1e4e6bniLa95nSDZTFb1vLJVKTthy974xrKiwlycfElE3vvqd78SNOsvxcdfzrqXrRMMsIG9K7z3EvfAE8ovgx8M4RVSN5XHizBkv+sqrFl4w+4Kr4KvyuEAOTjEJD7whFXpwhL7FcMpiKuKXzww5iLWuDC2/s+Ia4zj6574lZHL8TgrOGOlrcPHRM5YgT8M4iLL58ZKbvJq04viuDnZl6BFcoKnjOUippjAV86ydpjs5TCveMe11LCYHXlkK6/ozGwmHHAtiqVstHkwYJ6znbNKZlxy9c5flHFxhcznQLuPxSiosKDVUudDK3qmec6lbRedQg9zebuQrjT0CG2ePVqagDvctKfxCmVdeuzTCWzrn+FL6lTXDtMmMKqqjdXpV8s6qqHuZWBnzb4BwzmYuO715lhdApj6OiSJHraxi1lrKrv22OAD9ggkzexo/5q+5eO1tBFS7Gtrm5SNRnYlty09Zz+bEOAut+ri/FrMmnsf2V63/rvx2G1ltu3duBM3FylD73zvLt7jxqa+79HufwucismWt58HPjp7RyaZCG948dS96wU7PBkBn7jFSVjwZkL84rN9opopHfG+cnzk07t1yLtMcmFUPOUsHyC/nwnoln9kraQx9KStLfOcZ1HKQUa1e2iez5XrfOjZe7k0hU10jHgcM3u+uX2TDnUwWkGtNLYokyjbT6FHfev7NvrRNct1hygRMK7+OM7DjnYs0vLkaxYqYcaOT62nfe7T9i9Dg0j308I9LmBnO8jzDnhiKhwE2LgLkPkp98Arfm8Z/6bXF8+Lqael7U5/OuQvH2V/n9q6X5E84mON+dBf7/HatLzo/p+x3nlR+35JPr3rub36/gp0fKlPZ+Jfj/sL2n2if8+9MVwsudi3cLC+L/5vhX9N0isdwLYHvfGfb0rlO/5TW4Y+KRj+lMF/YEDW7z6FkS9PzdsE++i8vffPb7DGp5P6VSYw+sNPfu+BH/6Pfr/9YXn2bmofIe0vv/PvD4BeI33kxH79V18DKHA8p3riV3lvFoAPCHM+53f5N3M91nwAAYEZuEu7N1IFaIDVxoBcV3gJAXQgiG49o4EpyE+ws3ncxzhrdIGfoIIz2FkISIAe+IGsF4Im6IIcpmn6QEhmZ3o0SIRjBoNCqH4H8YPnZH5F6ISokoTohINL2IB4J3sS/idd+LYMI9iCs/eEX+hYzMeDrYc6VChOTQiGaVhQNjh9U2hmExiFHbB/cjhqCZVmvcCCVciBasiHeYV1eghtB1iCJdR034SGfYiIb8KGN+iGRwiIfQeHcShhJ2hrdegKMReJkpiIm3hbcziJ8YctlphNh8iJpfgliyiFjeiImWiFw4eFY2hqSLh0CLRspjCEOkiJpqiL++WJvlF/02Vyo/h/u0iMs6KJ+KSKqyiIvYeLr9iMZMiKrehmeQhEzviMKFeM2chdvagBXpgz1EhNpKiN48g2qEhPyaiAsiiN+reD14iN7kh5cCZDZYcp83dQ5kiO+eiH3IgBe9gE5HaG/sOojwOZKPh4T+hogY+IdAq5kMvIjFcIjbAIiYIzb5HAj/0ogQSpkealaw7pj0FwcNMkjhtJkghikPmEkDkIke+4kiyZfO0Ijw/5krkIT964Hfb4WbVYkjv5YPEYjYEIQTbZTCPJk0VJH8cYUSkJii0pkzNpja4YkRLpk1LZlOwIkEe5cY1wkUTChUbplTU2kVRJger4i8RElF+Jljl1koC0d2KplLPokUiJkTAJlbHIkFXnlnLJlTRJLZiolThZW7WXloPZZFfZhSEZlBlZTGdJmI25HHqJSGIYk28Jl3n5kffIl5Z5mTlJl04ZlZMJmRWghU4Rlt14eGQJlLjo/pirWWmjiZrEBwSl6UuMyZq1KRtr6UYJ+ZMpmW49+Jqy6Zl2uZvAaZVPWZdTqZnrSIKwORm6mZzKaZvRaXFLeZzI2XOFaJYCKZ3bCUybyWNmGJfWppLB6ZLkaZ3VWZX0Z5zF+ZlMOZaYuZ7qeZr1o5S96ZvciZ9E15agGZoUcJ65RJv5KaCX0Z9eFIzhWaCcmZnPyZzu+Z4K2p7o+aCBGZ/yKZwM2pB3WaHwGaED6qEPuJUWUJ6wFKAfaqJ+kaAEV5EampU+dVHXeZ8I6p3L1ZnmmZ4cOqIWmqMQ2qHsiY5U55cnKqT3F6KiuaOoVKJDqqR8N6ORlKEYGqQLU6M6/vqfNnqLDnqlEpqizTmlOHqkNEqZQKqYS0qmxdeRUBqjupSkZcqmXYGbPPSmnselY0p7UYqlWzoAgAmmC3qncaqn4PWnLUaZIoem9Nimhwp9Z8qfqUmi2omoj7oaeBppVWqVvpim8VGk/tmlXkqpnHqjPHqhi9qkhTaohCqqBwqpqZqogZphGzpKa6qqsfoTkipCmRpsl3ofoXqqDdqnoyqomwqqX6pdrHqrpbp2MqqMsqqs9tejVDqhmQSryyqtKkGrGEesv5mOYjKfw4mXhUqnVpql4LqlmWqsg9irgjmt6TqD0BmsnQpK0aqu8aoRbxpDttpqhqkt15ppwLqn/q5Kof46rPy6r+UKQPJqsNkolOfqq40ErwfrsB+ysGxpr8Wqky+TrLvKq+LqpwILqBxLAuVamSv5sCO7k6KosPTaQw1LsisbFigLpxNLsSYbbvoas83qqc/asXzaryDLsj1Lss6ppbpKSirrs0W7hS7rQ4rKBKjqQYbqrS2KscTprDjbbyBrqkaLterKeSdbrThEtFkLtsCAtEKktEt7h8hIszUrtBobsdtnteYatnErt7/KfmrqqHOLtyIxtkRUtmaLnRjFrv9qs4K7tgFrtXmLuIl7r9TXS1+ruI8rCl1bcrE5uEvwtySWth+buXR4uJDruZ+7l5t7R44LuqX7/giS2zwO+LQvWo1Aq2Ie26o6266qaLq1a7t9W0qka7u7+wSo2zuSybUy27rUyWxByKJQO7Wyy7vLm7gwS0S6y7zRezVta0CuG7wX+yvVh372qrzS672Q2725e7ffS76RR73z45rHi66ARbzEmL6rC47lK7+fW7jPAgD3i7/5q78AYCHjO7//2wq+GzoVy61buzHAN7fuCsALjLUKnCP7i79LAMETDMEf5L8MjMHZG7j0g5gFfLUtYbx4S7UZTMIHO8InQsH8ewQpzMIVvBLQW8IxPJeMWr3deqpHa8AJvLcyzMOsKcDxwcIr3MJDnL8vfME9jMRSsMOrs7H7iQw5/izCG5zEUyyr5xsiQ1wERKzF+psSMEzFDPzDf1O/9Jc1Tpy3NPzFaSytaOwjREwEWwzHESwSXqzG5BvGc+O8BqFapiu1dezHqdrHOqLFQxDHhazCIEHHf8y7d8x4otsRf1i6NqzIkwzIdhokWxwEhqzJxHbElOzJhpux8pPHSniskYy8n4zKZfqtPwLHmTzIFtDKH5HIqYy4S+w4uEvLy9nBuczLSoqrQFLIQODGHPDKHTHLvZy1jGw4uIzMSrGizQzNH7rLlxzMPoDFIDDMHHHM0fyzthx9jszNyYCv4UzO+TnORrLJPXDNIbDOG7HN5Ryv3sw5zAzP+/Bt9YzP/tt5z0nSwgNAwerczyUQ0O7cyfnsx/IMOvRs0CPBtAvt0F5JwEJyzf/MAwMt0ClszAX90EiszC3zwWz7pButd2Up0iW9kax7JOtM0Tpg0ReN0QSNgSatyB19Mqobtfss0xD7vjnN0wR5thJt0SudA0GsAi1tEe/c0+aM0CODwB58uUnNf08N1VO9iztNzUQdAUJ9A1hd1C+dEUhN1bW51EZmvUH702HdEOCJ1mtdimoNzFyd1RO8A3CdAnQdEWDN1mg51g5j1Tdtc3ldEV0J2IOdiIIN1Hbtz3I91F7NAoj9EHhN2CRJ0wcT0fALt5GtQGWN2Zu9rpr9wEYd1y6M/gOM3QKkrUMxzdm3u9cBk7B+XcqpzS3aC9uzrYLj2SOgHdr7u9ha3dimDRGQTdu6uNpwJclm/dHBvXxNjdzLHYDtK8i+LQG8PQOOXdfS/dgazdwOO9zrgqdQnN2PDLzfLd6rGsIprdgYYN0xAN0rsN4NAdzjXYSTjWAODKbwfRPlbd/5babre9hyrAHp/QLUXd0AvhDvrd8QKN/iMsoHzhvezeAPfnlyyiVFTMznXQPtzd4ErhAGDuHnl+CGBc4djhTbKuIlDnkkPiX36wEa3tsWrt4sjm3YbeImut3psuAzjhJmjOM7LoJ7/CWHXOGifeEwfgICnhAczuOiV+Pc/n3jSe4RIevkUZ50UP4mRI4CRt7VLn7dqC3lQ/rhydXkXT6vxy3mZT5yl+0mVl7kam4CGH7kMm7mEL3kxA27cV4Ur23neX5xeI4nbO7SQj7dfu4PSK7nQzfn+aLQha7oi87oyyHoI+DmGa7lDkHojc5xhy4wYW7pm87pnQ4Xj87OkS7pgE7pcO7pnPjlRUXmN8vGp+7qrw7rmQHq2DzrIiDqBVHpsV5uqQ4pKO7aDa3rwS7swx4Ytb7ixk7rk84QuU7sxsbra4jfv+7WzU7t1W7tcoHsQU7qga7sBW7q106kVqzgnp28Zw3u547u6e4V2b4Bt57l277s367uz4fp/oBC0iBt2/Ou7/vO70XB7v/979qu26ctg/2ugc/uJvFr2atu8A3v8A+/EgGP3hLf7hSvDMwO8VmG8Gryy8at4xkP8iEv8hth8RSA5aVd8siA8SPvY/VeJoE8u1TO8jNP8zXPECkf3e7+7gP/2/Ju8znn8l4Srj7K8D9v9EeP9PaA87kN7zKg84Pu80kfYkU/BBs/JZVb31Kv9VvP9fiw9BDw9APe9G/O5V2PZZCsBFa/SiFu9m3v9m/v9d3e4mP/4nIf42UP9y0v85Qr7tvE9nkP+IEv+L7w9Ylt9zAQ9vyw8oPPex9/mNO+LZrO+JNP+ZXPCIWf+Gt++Aax+JZP/lAO7tTmfi6J7vmlb/qnLwqYX/gmv/oqF/WoL1z8fb3APvqSD/u3j/u57wKqv/m73/rB0Pm6f07hTfTFrS6kL/zJr/zLL8y9r/l0j/i/D0evz/yh9dce77SIbvvVz/3dr/u8D/0BLv2/EPzer3HOTapSbON/b/7t7/7tD/48P9rj7wvl//6VKNs52+rQLqbnfP//TwDzMXW5/WGUk1Z7cdabd//BUBzJ0jzRVF3Z1n3hWJ7p2r7xXN/53v+BQeGQWDQekUnlAtB0OldPKSA2fS6xFcGWK8h+wWHxmFw2n9Fp9Zrddr/hcfmcrgrc8Xn9PlDi/wEDBf/qCg0PFQBr/gYZGxsRISMlJykrLS8xMzU3OTs9P0FDRUdJS01PUVNVV1lbXV9hY2VnaWttb3+smqJ0qWB6fXG1uraEjY+Rk5WXmZudn6GjYxwVQaivse+kt88cF7PB+bjHycvNz9HT1dfZ293f4ePl5+nr7e/x8/X3+fv9PXrx0lUlYBtiBxEmVLiQYUOHDyFGlDiRYkWLFzFm1LiRY0ePH0GGFDmSZEmTJ1GmVLmSZUuXL2HGlDmTZk2bN3Hm1LmTZ0+fP4GmDKdn41CjfIImVbqUKc+hMo9eazqValWrV7Fm1bqVa1evX8GGFTuWbFmzZ9GmVbuWbVu3b+HGlTuXbl27d/Hm/tW7l29fv38BBxY8mDDbSAVTACM40GBhx48hR5Y8mXJly5cxZ9a8mXOXqHgufv7cmbRf0QGgnt5TmnVr169hx5Y9m3Zt27dx59a9m3dv37+BBxc+nHhx48eRJ899mHFixC4UN1Y+nXp169exZ9e+nXtl1aglfjfanbxF8aBTRy2/nn179+/hx5c/n359+/fx59e/n39///8BDFDAmpizQiADf3lOjQEZbNDBByGMUMIJYzvvofPCoZA4DP9IDxsNQQxRxBFJLNHEE1FMUcUVWWzRxRdhjFHGGV0rcIoDb0ywuTVo7NHHH4EMUsgh9+KQIQ4/JNI7JAfxUBAloYxS/sopqazSyiuxzFLLLbns0ssvwQxzJhulwLFMHRFkQ8w12WzTzTfh/I1JhJikJk646pQqJkDu7NPPPwENVNBBCS3U0EMRTVTRRRmdjMwrVIjuBUm5QeifSzHNVNNNOe3U0097yPOAPL0BFR5Sw/nG1FVZbdXVV2GNVdZZaa3V1ltxzVXXXXnt1ddfgQ22AwVNoLQFY6WxVNhlmW3W2WehjTYdVKkVRFpaqjXq2m257dbbb8ENV9xxyS3X3HPRTVfdddlt110WiC0BmGCOjRcaZd/NV999+e3X33yyDRiPfzURGByCEU5Y4YUZbtjhhyGOWOKJKa7Y4osxbtjeEeZF/jPHcfDNWOSRSS7Z5JENrvZkN1LOZuWXYY5Z5plprtnmm3HOWeedee7ZZ0825jjoYodmJuSfkU5a6aWZhqVlUZs+4ulroq7a6quxzlrrrbnu2uuvwQ5b7LGFTtO5HeEtepmjyW7b7bfhFntqJOOmYe5S685b77357tvvvwEPXPDBCS/ccA3U/gDZs9FO9qDDIY9c8smFvVs8ykWwnBHMOe/c889BD1300Ukv3fTTUf8icYBWB2HxaNhOXfbZaa+9E81Fsz0C3K3V3fffgQ9e+OGJL97445FP3p7WOXj9BOefiV356amv3voKeNeW+uwJud7778EPX/zxyS/f/PPR/jec+Q2gl3d9Y6RPX/756e+b+4P9Hthu7uvv3///ARhAAQ6QgAU04AHJ8b4MtI8EDDTa4xAYQQlOMGP3o5reAvGNuVGQgx304AdBGEIRjpCEJayfAheIwhQ2znHEMOELYRhDX1nwEXGjhgYDJkMd7pCHPfThD4EYRCEOUV0qvIADXYdEZcSPiE104hNnQcOhvG2K+4MaFLGYRS1ukYtd9OIXwRjGNRjRAkpkHQtb2AUxrpGNbcyCFL9DttPgMI5utOMd8ZhHPe6Rj330I/3IWAEzDiuQtGDiHxGZSD7CEVVfoxsdq6hISU6SkpW05CUxmUlNjqyQE+iYmSBVjkNu/pKUpaQgI5+2NZVZERumdOUrYRlLWc6SlrW0JTc66clcPuCTooTgLYEZTOKhUopRaxkkuydMZS6Tmc105jOhGU1pNhCNRKumCAaZjFFOk5vd7BoxwSkOn2kOmX3w5jnRmU51rpOd7XSnDHcZgWyu0Gzk2OY78ZnPh4WTnze8GQ1VpU+BDpSgBTXoQRGaUL7FU54MZYJDXXFPhU6Uor/q50W1NzNUVpSjHfXoR0EaUpGOVGQQdcA8y2jSVkiUpC11aTswGtPL1WyjL7XpTXGaU53ulKc9dYdKGYBSQQJ1FSz16VGRKgqZLvWKNCNmUqEaValOlapVtepVg0DUh16T/pBaTYVRsRpWsSaBqWU1GM6eOla1rpWtbXXrW+GaUK8mQKgSqCv8fhlXve7VDmb1691ylla+DpawhTXsYRGbWCfOFQG9xOZdhQFWxU42rH+1LEADW1PKbpaznfXsZ0Eb2toxtrEQhWxk8ypa1eb0sq0N584Eu1rZzpa2tbXtbXErM9IewLGKOy0uJJtb4TrTtcVlas80O1zlLpe5zXXuc6Fbq93y9rfUna4pghtd7SLSuN1t7bryUM4Nbpe85TXvedGbXvXO4roD6G3zqnuL7K6XvkD07n3xa05yZZCVx6zvfwEcYAEPmMAFHkJ73Vvd955jvgZ2cADzG+E6NWBq/uHy5wzO+mANb5jDHfbwhwmM4AQHcl70SkeDQZziYUqYxRjSgH+llVEZNFLFNbbxjXGcYx3vVcQlZt+CGZzaHQ9Zdi02smpQkOFmIbm/TCbyk6EcZSlPmcr6FPGI51liE6sDxVX2MteOHObPiPeRwCozhqPyZTWvmc1tdvOb/3hlLJtRy/DoMpzx/DIx7zlVQljlrv48Y5flmdCFNvShEZ3oCMp5zu3TMhTecWdFT1pffLZ0K8FA41qlssnJpPSnQR1qUY+a1KNjdKMfneozRVrIpXb1uS4d682xbMKxwl05X51rXe+a17329dJOjWpVp1oekv71sTcla2XzFxJM/moVZjGMbGlPm9rVtva12xVsYQ87vktsNbbBrY9lj1sPoOCQqZIbbnWvm93tdve7uaXtbXP7Y8X+NrzxzQxy71sbrDjPqtKdb4EPnOAFN/jB2yFvA9AbyO4wNsIhfgh+k/sYdUR3wCOecY1vnOMd97gkFL5whtebHg//+MmlNvFxc2OOrIotymEec5nPnOY1hw5XazDyXeTD5Db3eZJVruxTpfnZGP/50ZGedKUvnek0GHY/et50qSMg6Mvux1Fe9fKpb53rXff617e+80xFHewor7qsAd7nrDOy7G13+9vhHne5H4Psc3f32dF+K/zBiu129/vfAR94wQ9eOmok/jzE8X5pZ2HaGeHt9HgPH3nJT57ylbd8Cup+eTwnXvEWxlvFmS3oCmue9KU3/elRL/nMp17HnOdzvmp4iwuiOYest/3tcZ973dt89bsXsOtfz7BBYCuSone275GffOUvn/ng7n3zmwt8MYusd61wsvGvD33tb5/73fe+m5///c5Kf/oym3Upak17GYuf/e13//vhT+Dwx7+t5D/yzz7PiWyROfT09///ATAABXC15m8Aecr+7u9qZs8SOE39qsEAITACJXACKTCsCrACKQoBW0yOGA8Rbq3TMDAERXAESbAEK+oCTRCdNHAD+Ubt4qCYUjAGZXAGabAGbQoFbbCW/lZQwiJn/dbA6HIwCIVwCImwCJUJB41QkXaQB0OH6NoACJMwCqVwCqmwCtcICa3wi5Ywv2wnd54QCrMwDMVwDMmwDCUIC81wh7aQC40n+9BA69IwDuVwDumwDo8HDe0wgtbwvsJnptQADvMwEAVxEAmxEAEHDw2xfPaQD+fHxf4QDBMxEiVxEimxEm0GES1xeBaxuw7ozLqh7zIxFEVxFEmxFAkGE00RdDaRE0Eo/T4RBlMxFmVxFmmxFn8FFW0xf1bRtXiIVDLH8RzQcnJxGImxGI3xGKHu3pBRdHaxuJ6IWjag+rBPyZaxGq3xGrExG7VJGbXRAPQLg5rxssRo/v8mYAGnofa6MR3VcR3ZsR01ARfzUH8cKRzFcY8EhgGw7vH80B35sR/98R8BsgzgsQ7LrWno0bIuKWUGwOKCccwC8iEhMiIlciJxYCDnUJxs5iAREpb+iv9ijyJBMiRFciRJMgMsMg4fkPo00qyYaSMbcvhKMiZlciZpciRP0gylcWFW0q/OqR5fsiBrMiiFciiJUh1vkgzP7112sqwE6rtAsCihMiqlcipr8SjFMP++ZSmZMgOdkiq98ivBMiwh0iqz0ByXRSuX6qWcUSzZsi3d8i2NkSyrcNBwBS3T8qhYES71ci/5si8LUS6n0AVBxS5jSqy8yy8RMzEVczGn/hAwo9AHAYYwMSqhgPEFGJExMTMzNXMzJ9AxjdAJ30EyL8qg9s4F8IszUTM1VXM1t88zidALWU40+0mfXJEF2JA1cTM3dXM3Kc81hdANZU82X6udyMk0b5M3kTM5lXM5t843c3AfV0E4+QmfIPEXD5M5sTM7tXM7P845a9ARzU06AZGgqjMEeJE70TM91XM93807Z9ATPVA8x7OjytM8j4s98TM/9XM/e809Y7A22UA+65Mj98AjhdEyp5M/FXRBGbRBD80/TdAXx0BAQfGW8vEneecc4chBObRDPfRDoQxCSRAaiYBCN1QHNW0a70dFMxREXfRFYTRGB0xERZAc/m3ARGHxlbLHQAGLRQ9URoE0SIV0SIeLRjHwHlMAR6GNlgbUDyoUBlaUSKV0Sqm0ShPLSClQITlASS1omp4USr8UQT/QSsm0TM30TKkKSyWwAfGRS/nnncLUOE8UQ6kRTe30TvE0Tz1KTSHQTa1OCfsPTOdUQ3OUUCFPTxE1URV1UdWJTwfQT1nsj1qOTovTR1v0RkePUTV1Uzm1U2nJUQMQUn0Sj9DRUsfUULsUB9jUU1m1VV31VfkIVP9PVBPUjZYUVaPUVCv1BrQUVn31V4E1WKFIVumPVnfUj5qUBJLVOg/Vz0pVWKE1WqV1Wj+IWOHPWJ/VkpaVWW9VUMHT/gxslFrFdVzJtVzlx1rdD1v/DUUHFVfflFIxUuJS1FzptV7t9V6HB13ZT13psomwUk4L1Vu7VUyVqqnw9WARNmEVtnP09fv4NV7tiyHd9VJ19UfdAUAXNmM1dmM59m0atvtENWLrVGBztWJ7dOi+tWNVdmVZtmWX5mO3TzzVME5bYFutgWbVIWVddmd5tmd9lmRgFvpWEops9mbbVUx79VKg82eZtmmd9mn7JWiFdgfXqGg/wGo7QGfXDjahtmu99mvB1lukdmpVrhW/kWRLdmIpFm1T8iwdMmzhNm7ldm5xZWzJtvwkqF/Z9ljh9WTN70LpNnAFd3AJ9x/s9m7P/rMTz61vm3Vv1zZmILNwJXdyKbdyQYYbKfEuBchvHfdU1dZz/1ZvLXd0Sbd0TXcWDlf7BrZ/sHZLcXYFjtapOvB0abd2bfd2OSF1VZdvB6h1XTdgkTbQrMYscbd4jfd4kVdNMNcSHxfCXrevgBdgQRNu/jV5rfd6sTd7hUB3Y9ZiRwcoTbZxgzdVK3ZyklJ70Td91Xd9W4B7uzdTD0cwO3dXP5d+WTdQ2Td/9Xd/+XcC3Pd9k5Z6MVZ6yTd84fd/2rZ/FXiBGTh//xeAs3V4QZeA03Z+vReBC7SBNXiDOTh5HxiCSZRpfPfFnjdJ3xWBwLeDVXiFWXhyPxiEDVZp/kY4A2aYhkM4huSxhXV4h3n4a18YhuFThkv4BGoYA962h5E4iZV4iYHnh4F4XWEPYi2Yc8e3gqu435g4i7V4i7l4dpz4iYFzW6Z3isW3Zoe4i9E4jdV4ja3ni8H4iC3qhuv3gq+4edn4jvE4j/XYdtz4jSM37Xh3jqm4ju14jw35kBE5kQunj/24NC8udin4hAVZjhW5ki35kjE5bxh5d5f2U87YBIr4AmI4k0m5lE35lMVmk5sviDsllLHnk53UkVF5lmm5lm1Za1R5+QbY+nKSjA+YkCdYem95mIm5mI35anI5+SQ0FMLYjCHZNmH5mKV5mqm5mscmmX2Pkutg/mSB2X4jOZCtOZzFeZzJ2WqwWffCFVxX15mjF5qfuZzhOZ7leZ5L5pxxD0nJwJVf+Z2hd1Xp+Z8BOqAFumLs2fYCONOieQT0mQJYeaAd+qEhOqITpqBTz5/fKKG5tYAnOYcluqM9+qNB2l8o+vTKOBGq153bGaXX2TZDuqVd+qVhWl9GuvRGdaNhzIAtOqZ1eqd5uqcnZqY1rytx+qZ9Oad9+qiROqmVOl2A2vISd6gP+psLeampuqqt+qqBpakpby0Z95elepmxOqzFeqzJule0WvKMi0dLGnY7uazd+q3hOq5j5awPLy+hmpvZuZfleq/5uq/92lToevCus6uN/vqvDfuwETuxuSWwA+8y7xqfFTuyJXuyKVtXGPvvTlMfp7qyObuzPfuz9eGy7e44bRqyQfu0UTu1VZvLlpcQI0ytJXa1ZXu2abu2t0G05+61CVuvbbu3ffu3gXsbXYgUSRuYg/u4kTu5lRsZcHu0HXu5oTu6pXu6S661E/G5qTu7tXu7ufuBhtsUB7u7xXu8ybu8v8q6I7EjzXu92bu93TsTmhvwUvq96bu+7fuQVa1Z4lu+N/u+/fu/ATyLdU5Y9pu/6TjAETzBFbyDdY7kLBu9M3eQF3zCKbzC07fB6ylXCryxvdrCPfzDQfx0MbzbDBfCK7GwQzzFVXzF4XbE/htOVjZc8KI6OU0cPWucO2O8Em98O3dcO3N8YlzcxzS8xyXRtJmTyLETyY9cyZeTyZXTyWkcyoMnyB9tyL97GNM5ya/cQaWcN398Ert8N8NcN7/8YfI7qM7cVsrcwEd5yQ2vQ8c8N9c8EeMcN+ucNed8Yarcrva8VvLc78Cax7e8Qe98Nf+cEAtdNRM9NQ+dYOospYScVho9t48vPRcdNS+dMyc9EDN9MztdMzedXx79iCJ9VkI97hpay9+cQz89M0+9DlsdM2OdMV/9XUadnnAOVGr97bRW0FedywedQXddDmd9MYtdMYedXUodcUj8HpK97dra17ngQ489MZ/d/gyrHTGz3S+vHV2WndmbvR66HeyaWdqLwUO3vS/HfQzTnS/bfS/XvVxenNTDfR7i3eu4lj3fXS/3HS7vPQv7/S0D3i3/PVzmHQMO3lMKnuvGeD0Hvi0fni0XngojXiwrPiwn3lsSnt5znVMyfur+2NKDfUEvHiw/PgpL/itT3itP/lo2nuMznFVavunkFz9XnipvfipnvghzXip7Pip3HlrqXeQ6flOCfulENz9/HiqXviiPXgibniijfiifnlleHuGHntVG3hqJV+m3nj+nXiirPgfDPijLvibHXliuHuuLfuzO3gZP2ua/fj/ffibTvgbrXibzPibvHliynuhj/h6w9/49YZLQ514/B58k+34GE98mD9/rH/941p7t2/5SFv/oeJvuI1/fN9/hG18kPz8kQx8kL59X/t66Av9TSv/nEpjkO189R58iV98EY38ia18iZz9XTh/wHVzwX/8YpVjYf9/Ghx/Hbz8ij38si9/czx18dn/etkzXk18EBSCFgf3XDR/7hX/5fZz7s3P6AzL3b2XywT31O0X8a24LQANEwR8g2/8f0Z/6vV/Vpx3d379nnp/3V03m778z1b/5CWA+pi63P4xy0movznrz7j8YiiNZmieaqivbui/cCjMd2zee6zvf+z8wKBwSi8bjglZDMpvOJzQqnVKr1is2/qZcZrveLzgsHpPL5nNoK0Cz2+43PC6f083qOj6v3/P7/r+c2hogYaERAGKiYotiI4AhmiDkJGWl5SVmpsKdZqfnJ2io6GgKJ+kpaqrqKqufaStsrOwsbW2QpG2u7i5vr6/D66/wMHGx8WTwsfIyc7MzFu6zdJPjIkt14rRKtHa39zd4XXI4ebn5+fc4+jp7uzut+rv8PH09Jbd9vv4+/1t8P8CAAgci+UfwIMKECrcZXCgPWzZGEB3ic2jxIkZPDTNy7Ojx4MaPIkeSbBeyJMqUKp1VXOnyJUxiJ2PSrGlz1MybOnfyLNSy5zGIj1wIpZgTKNKkPI8qber0aRam/lCnUq1KRKrVrFq3vvjJ9SvYsCuwii1r9iywLWjXsm07wavbUEWJTlwINy7evMLI6u3rVyffv4IHpwxM+DDijHcTM2780bDjyJLzQZ5s+fK6xZjxzJWIzajazaJH+wtN+jTqd5VTs26ta7Xr2LJZaZ5t+zY807h3864Fuzfw4K5+Cy/S+VpdhbWLM2/+Vrfz6NINEZ9u/bqV6ti3c2eyvDv48FS0iy9v3gb58+rXo/jOvsfxFfFBpn9vf239+/r3V8jP/z+Am0AXIIEFpuGfgQm+h6CCDZrHoIMRdueehCbMp8KFAlFYIYdOQdghiM19GCKJvY1YIoq2bZgii9yd/tgijKe9GCONmK1Y4wRCDUXXZ8rNiCOQ7PwYJJGHDVkkkn0dmSSTbt3YJJSiLRkllWFNWSWWWj1ZpY4wZBjQllmKWc6VY5rp4YBnqjlZmWu6eVOYb8pZVptz2qlSnXfqOVKcUHb5wpcA9bknobkpUSiieOWZKKMJLdoopBo+Giml+0xaKab0XJoppyZt+l+gJ4TKz6CdmkpdmqeqatOnq7o6TauvyspMqbPa2k+st+r6S667+vpar/aNWsKw+tT6K7JgBJsss60s2yy0pzwbLbWgHFstts1Mmy23lWzbLbg+fWtesSOUa8+14arLw7jruptHu+/KG0e889rLRrr3/uorbar7+strv/8KDGzAc54bwsGa1jtwtQsz/PAUDkM8cRMSU3xxEflivLEeFnP8MbsFgzyyJRrjmPAHKMtjMskbe9wyzC68HDPN7YlcM87wzpwzzx/s3DPQGvwcNNH9De2cyh0k7Q7LRd97tNNRp3Wo1FXje7PVWWcHtdZVc9111F+DXXTTMS69wdlCij02lmuzDbTbb+cct9w1l1033iTQnXfLe/M98t0tpp3B4OgE/vevfiP+seKLY9y44xQfHjnlEUBeOcOXYy7w5CgWfsHn5nS+uaqak+6v6ac/jbXqrXswuuuVpx67u7PTri7sIYZewe7k5H57o7YDD67w/sNnW7zxDSOffLTLM9+s888n+3uHveeYHELUS29n9Nsnzrr30ncf/q3ak2/1+OfLmr76rpovofUSxB+IIPXbfz/++eu/P//9+/8/AAMowAESsIAGPCACE6jABTKwgQ58IAQjKMEJUrCCFrwgBjOowQ1ysIMe/CAIQyjCEZKwhCY8IQpTqMIVsrCFLnwhDGMowxnSsIY2vCEOc6jDHfKwhz78IRCDKMQhErGIRjwiEpOoxCUysYlOfCIUoyjFKVKxila8IhazqMUtcrGLXvwiGMMoxjGSsYxmPKMJCTE/CKwRDmh8IxzjKMc50rGOdrwjHvOoxz3ysY9+/CMgAynI/kESspCGPCQiE6nIRTKykY58JCQjKclJUrKSlrwkJjOpyU1yspOe/CQm1Yg9z1SDFKA8JSpTqcpVsrKVrnwlLGMpy1nSspa2vCUuc6nLXfKyl778JTCDKcxhErOYxjwmMpOpzGUyM4Si7BGgRvmJZlKzmta8Jjazqc1tcrOb3vwmOMMpznGSs5zmPCc606nOdbKzne58JzzjKc959u+ZpfSSNDVCz33ys5/+/CdAAyrQgRK0oAY9KEITqtCFMrShDn0oRCMq0YlStKIWTaA9HRGDNpbmoh79KEhDKtKRkrSkJj0pSlOq0pWytKUufSlMYyrTmdK0pjY1YkYbsdF8/koKfO2bFft+WjqfCjV2QS0qp96H1J4ddamVaqpTI6VUB3G0AVWVxlSjmiSoajV4RO2q7L4K1shldayAE6tZEcfVtOqprAn6E4/u6ai1spU1dK3rnO6KVzfpda9qcqtfIdbXwI5psITNEmALBFdSatRHaD1sXh8L2a4ZdrJRqqxlm5TYzK6OapylHGY/W6TNEuiqCjAtS0Ir2r+odrVAaq1raQTb2MKItLQlnmRvy7PZ6hZFtgUQahEQXFrxtrdnKa5xQ4Tc5HJoucyV0G+fC73cSpdkzq2ugqLLn+EOYLH0oS52a3Td8BpovOQNkHnP+x/tqtdW6W2vft4LX/uw/lc/3OXuMuo73+nId7/s6a9/zwPgAJdHvwROKngPjLoEK1hfBn7PfXnaU882mEkDrrCLGIxheV14w9Z5sIcT1eEQR2fEJBaRiakSYWjOVcMnBlCKXyycGMvYRC6uMbZAjOPIUnjHkruxj6GlY/WsWK4t7nGQS0TjJM9myUx2jZOfbNcoSxk1VK4yaa6MZSlpGSnDxa8yhrzlyHR5zJcps5klg+Y0O0bMbLYwkN/svjjLeah0DlJwvftdJNeZQGvus5HuDOhM/XnQrC20oZUk6ERLddGM9qqjaZRnCU+YC4/mD6IvHZdMa5otnO40WtwMat9GetR3+rSpxSLq8kya/sVHtnSq1YPqWINl1rTeiq1vnZVV6zpCue41VX4NbKjwOjx6thClwSTsYc9i2cxuirOfjZRoS7snxa42jEuNbSpRe9tw6vZITHtsglzb20kBt7lpgu50v2Td7F5Jud+9HnfLGyX0rjdJ4s0dcSdb2drGt1/uDXCRCHzgHSm4wRWD8IRfZOEMBw2sH44ofW+H365+9QwkzhuHaxzjHWcUxz8+EIqL3DkhL7mg/o3yDpEcO1cFc35PvnI3yHzmxlK5zX2N85w3qOU8303Nf76ynQu9QD63TlVhHnOiF53YTG96tvkM9SoFfeqGq7rVRff0rNN361z/L9YFkvR++1vq/l8PtNnPjqSwq70bbG87rN4O92fIfe7a8rrdwXN0pJNdA+Pec8TzHnC8Cz7DaS98i+qO+GLsffGNUbzj90L4yJcY8vpoo9KXfnjKm8XynOeF5z+fi9CL3jekL32zJ4964Jx+9bBovHT+zgHZk7v1rmeB7W+/itzrHhW8770pfw98UQh/+NZSvfFjA/vY9x10zU858pNf6UFIH7rRr76Vr4/9LBd/+5fovve9pf3w2wj856A9BtA/cvOT32ibb/+Cxg9/Nct//m1mv/2H8/78F7j+/EfM8jHf80WA+q2f//0fmRwgAg4G/i0gHjSgA9JBAEagUkAgBdKLAl6golgg/jgU4PUMIK5wYASKoAa2AQmW4BmcIAqWwQSuIGBkoAuGGgzGYOepoDZ4IBtl3t3NIA0yHg/2oJX8IBByhQ0OYVQUoRFeARImYRUsIRNGjBM6Aw5a1RRC3/49oV0IIRYGmxZu4VNEoRdWDBiGYUF0IRmemxmeIVC0YHToyI6kXxVaYeCpYRZeIR1OmR3eoYykoR5+Gx/2YU2MISD+gCAOYg+wYRu6ofPFoRxmnCE61hw+Ih5GoiTuYR5WIv39ISYWhiZuYkkUoidqASgqgxsiAgWUIp+MYvWpYijKTCe24mO8IiweHCvOYinIoi1iRC3mogkgogAqogOUYkTEIi7y/mIf7KIx6k0xJqPHMeOZIaMz+swyRqMBUiI1MiA0DoMwbiMjlp01XiM4ZCM4Cs00jiOplKM53hw6piO6rCM7KswlvmMNuqN4cKM96lS+iePt6aM8SgA/9uMD/CNANoAvDmQ60KNBXl08JiSuCWQv3KM9ciJCMiQ0TCRF+o5FXuRBLqRGcmFGdqQ2OKRGiuRFFiTfQSQw2htJct5KUmRLJuRLGqRJgqTmOSJN4sdH3mRq5WR3oKQObiRH6mQsxKRM8qRQhplRHqUxzKRSSl5QNuVSJCVUOuVTFopPNha8ESXiaSVAcqU8euU7MuVUgp5UjmUvgCU7iuV1XOUbZmVZ/prlDqBlWr4lXI4eXdal6d0lXqZeVe6lS8ilOaplxXEjqwBm2xnmOCLmNSomNQqmX76eXj6ms0SmZO4eY+6CKa7hZWbdZjpjZybjZxqjY1amKoQmL5pmLo5mb6kmaZ4AaqYmZbYmv/SlbBLca87ibcJibrYia95Wb9amCOwmb8YmcIaCcHribxZnJxznJjInJiana0GncnKAcz4ncU7ncl4ndmaCdG7nPWind5YMeIbnd44neZ4neqaneq4ne7ane74nfManfM4nfdanfd4nfuanfu4nf/anf/4ngAaogA4ogRaogR4ogiaogi4ogzaogz4ohEaohE4ohVaohV4o/oZmqIZuKId2qId+KIiGqIiOKImWqImeKIqmqIquKIu2qIu+KIzGqIzOKI3WqI3eKI7mqI7uKI/2qI/+KJAGqZAOKZEWqZEeKZImqZIuKZM2qZM+KZRGqZROKZVWqZVeKZZmqZZuKZd2qZd+KZiGqZiOKZmWqZmeKZqmqZquKZu2qZu+KZzGqZzOKZ3WqZ3eKZ7mqZ7uKZ/2qZ/+KaAGqqAOKqEWqqEeKqImqqIuKqM2qqM+KqRGqqROKqVWqqVeKqZmqqZuKqd2qqd+KqiGqqiOKqmWqqmeKqqmqqquKqu2qqu+KqzGqqzOKq3Wqq3eKq7mqq7uKq/2qq/+KrAG/quwDiuxFquxHiuyJquyLiuzNquzPiu0Rqu0Tiu1Vqu1Xiu2Zqu2biu3dqu3fiu4hqu4jiu5lqu5niu6pqu6riu7tqu7viu8xqu8ziu91qu93iu+5qu+7iu/9qu//ivABqzADizBFqzBHizCJqzCLizDNqzDPizERqzETizFVqzFXizGZqzGbizHdqzHfizIhqzIjizJlqzJnizKpqzKrizLtqzLvizMxqzMzizN1qzN3izO5qzO7izP9qzP/izQBq3QDi3RFq3RHi3SJq3SLi3TNq3TPi3URq3UTi3VVq3VXi3WZq3Wbi3Xdq3Xfi3Yhq3Yji3Zlq3Zni3apq3a/q4t27at274t3Mat3M4t3dat3d4t3uat3u4t3/at3/4t4Aau4A4u4Rau4R4u4iau4i4u4zau4z4u5Eau5E4u5Vau5V4u5mau5m4u53au534u6Iau6I4u6Zau6Z4u6qau6q4u67au674u7Mau7M4u7dau7d4u7uau7u4u7/au7/4u8Aav8A4v8Rav8R4v8iav8i6v2hGmorKlEzgvnaIkD0jvmUYkE1gvo1Jv9m6jr2qvmd4jEoAv83rEVSZENwIiWxpZEJwv+v6k7q2vNUQT9yJE+uYf9A6B+9ov/JYcCKaA/GamEOzvQdxvvf1vygSw/O5U/RZw/xoaAiPH+rav/k8qhAHLrgK3ZT9ccBhmcAQjWwA78AdroAcPIwArsAhfnAt6sA9kcAqzr/T1bwmbsA64MEFwcLrB3AxXMGPl70DgsLc9cAKUcPWi8A0L8eQSsdghcfjt8AgjDAv/MBNHnhNrMLFE8RI/sfftcBHbcBar8PABMeFUMQ3bgBJ/MQyvnBjzDhmTLwgbMRpjpc2tsQdUcQ6ccUDQMeraMUDocQ+2MRhL8AzHMT56YRufMBfn8RRzHRnjAB/38SIDHCoyMCALMCXjMT/4MbBNMj5VckqiwCNvcCRvGSfvQCVfMhaLsha37iGrciBXoienMYY0MiSvsv2dsqjQsivLcgTi/nInO7Ei23LbCeMvx7Il9zAmX94oYxkxo7IxF3Iuh/I+aPKtNXMNG3NcJfIuy3Hw+rIyC3MSPjM0ywcg1/Irx6AnR7MuT/MyCx02ZzMwb/M49573FvM7I/Mgy/P8olw927M4l7G5lLM+A7TG9bMji7MgS3M+UDPo3vNCt3MYV/ACk3M6ZzJEM3L+GjQUVzQ7g3P8QqRwiS9Fe/NDe3TWuTEi/3NCt3JHn3PCoXRK//M+BzRHf7NLDxxMr7Q1GwAPq7NAtzQv6y5KY29J3/QgfvIHavQbI3VIKzU9MDTwEXVSE7TSODVP53Q7QDXlWfVpcbUIDDVWs4NW55xU43NQ/g9xWS/136X1U1+0j7H1SMs0VdcxV8P1Q7g1jtm1Thv1AYQ12tS1X6PDWG/uTj+AV4s1Xt8eXxv2YdM1U1NhKdfDYK9eY+fgMSfwYzNAZQt2YotcYctPZn91ZAfjZ8/DZPuvSNPvYi/AZv91aHf1aJt2Z58YSDvzZUtBaWt2br/DaUNwats2N5/iblf1a6N1bN+1SYvucTN2cXN2cv/xTDt2c7s2ygw3Yj93RE/3KdJ0dS93Vs92QWu3bjO0d0N2b+fCeYf3b+MzCFj37Il3U6d3Lch3nTUwPM81NcB3X5f3OtD3m9n3fQf3Iuoxf7N2gZ8feOvtgRu4f8dCg9/y/m23t36zcTcueDk8uOBZuBlP+H5jeCt4+NRxOINjt4bHN3YTA4jLW0+rthW/tyaXeIcneCWkeJWteIC3ePSKeHfpeDfQ+JPZuFnjtwXwuHlHMIx/g48f7pGb+Fk3KpEX+WqPeJQD6ZIHuZBb9ombKBA/+XinDZdbqCJmOWnjOHHHT5VftYwPZJhPOWYLeI4b8Jev55o3uVrPc5mzOZTTOXOLefliJgcnOZgS+J+nOYKe+V5HNxzyuYiusaAXDqDP5yQrOmvHNJ6P+So/uk5GeqW7uJvnt6MTOjtqup5z96gP+e58Oab3uSbEeZz7KaPjcKvTaKrH+KYzeaf3aKPX/jps23KsOygnSzpwXzmF8/qsa+Sv6/oYlzoFf06vb+exK7uEI3ueI3qiEzuoq/oeiHGz5+mrg/O2u2ixo7m0i/u4p+ga9Y62h3t6ljKwBzuZVzu073m5O/snt7utR3j3eru6q3m9zztonzisn/q+Y3tO2Tmnx7uhbrn1DLyCqjsdMzyAvnjoPPy1y2Zk27s/Uzu833qy+7tyXrzH/zvHG8fCV7wzgjzCH7zBb3TKG7e/QzzB90Gut/ygTryZm3x/7vvMj/yNcpTNJzfMf/yxYTyL8/xUG72pE/1YPrbSK7100/y0C7t7Mn3IWzrUE+Dg7PzKx7w0+HHQSymzz8/X/g+ow4s9ztOnz3/6c499ax630wd5m199l8v9dLp91WP51pP82p/9LNo93Qv33dM60kc9vqt83nN9M2De26up2v+9lB++j+o8wC9+hL7cpU9+4P/nclP+LF/+3fM9LG5+5kc9bmO+41t8aNu7xUG94o8+4qMCNbP9k2Z967v+onP+0UO+34H+e1q+rsc+70/la+M+KNO+6Z9+28te09u+aB//4KPn8DM/uev+nVP/3D9/0kv/64MCeRM/mRp/4Ac/2ns/1me5+LOnpHt52mv/fdIe+de51Fs99mf//JOn+7P/9Md/C68/8lfm/fc/AczHgeXOh1GiVsHExtbc8WY8/nEkS/NEU3VlW/eFY3mma/vGc33ne/8HBoVDYtF4RCaVKNAC17wspVNq1XrFZrVbbtf75UFZ4hsZfEan1Wt22/2Gd83ZOa0ex+f1e37f/wd8uasZJCmEOQxUXGRsdHyEbGzKmOxLFLlsyYzk7PT8BA1lrJwg9THd2lxRFW11fYWNlT0FoaztYV1FLcll2p0FDhYeJi42PkZOVkbsPYGKWo6WnqautoZrfnh+yr72/gYPFz/rFtouKx9XX2dvd3dJN/kdObepf8fP19+vtvCYxwYQU7x/BPkdRJhQ4Q9/HQSi2+Dlnh2DCy1exJjREAeHt3ZMJPTwQ8WRIjWeRJlS/uVKli31kbTl0eVMmjVtXiMIs2TEmz19/gQqyGQSnaWGBkWaVOnKojsbOjuqS+ZSqlWtWnNQkCefnFFVNL0aVuzYIVk7bqWFVgtYCGzJvoUbl5kTrU91gKQ4daPevGrl/gUcWPBgwnncJjhcWPFixuy8tn3si29jypUtf0k8I7OGyJc9fwYN0W6OdJsVdA6dWvVlunU5ckV9wLTp1bVtq2t9dnSYyVZmx74dXHi+3DF3i/bb9/jA3jFoD4ceXfp06gGbz72+pjhpaLC2VwcfHhfw09nhPTfX/a56V9/Fv1eKXhN55ubTuLfHvr1++P1poi+NPteWcwO/kIAx0D8F/sXhTwIBsejKvjHkY6jBA2dJcEENA7EQsuTW+9C3B40LsY0MZTiRkxQ3ZFGPDrWRUKgYv4rttxGpWFEoBF9ssUcff4QPL+VeM/GZHAekcAkjzQKyyf7iEVKzG5FYkse9loykyiOd5BKrGY2IEsUpwcQSOyNV1LJLNRkc0ykiryzRuTaJqFLOOrNMc009l5lTSeDCtDNOzMqUkdBHtLRyT0Xl+LLQNyGkLUnkpkQUzzsXxVS7RqUS9LxNy/tUnj7TO9NMQP+oNFNVV2X1puckddA+REPgdFZuOiWRSTdTbbVXwqAcFcZQQ8J11i09NPZWAumR0FhdfYW2FVglw9XT/mo/kjXZWnnN79pYq3WW1mjHRXNYqDZ9NVhRi9WWRme58zaCo8I9llx70VD3CGDNhfNROrO1dds8JxU3hXnpvTdhUpcluN6y8pUNYmbZDdjddrtlWDd/5UVYYY/Hi3dCfpEsuN9nMc44rZRBHdjgcOFdedcV6U30Y5tvxplDiVneeOGeI+54XZpRPpkX82guOmelNdo3ZJdHDvRnzoI2GmmiSz43ZaSxXrprfHe2Nub5oHY0aaBfzppqKZ1G7Oita/Y6birB5tlso8jWWOoKBbU6bbSJFftbrd+Wu/Ap6A6i6cAF5vphvof2+92rHabA7a0NxzzvxmHW20+8c7V7/u+M+xZabTHZPrvzt+HOvGu6NztV8MUtnr3hF0mvGnLAOwf9xNVbBz544YFI93ORl10d7uQpl5l1ZKVenvnhp5eFvOJR393s5E3WPerQNU8weuepJ7/szau4vvbJLdx+4t+HPL8+6KMvv35l1X/a6fR5563E9uW/HPykV7fw0c9+Bzwe/+7zp51N63naex8Acee9+JGsQ+JDYNwQNzX8Ja6BG7wb8iJowb+droMEvKABM7i012UmQMYL4QlN+LP/kVBya5PhQzC4Qh72MHixM9X3+kcgFfZugmETYvNiWEMfNhEUDASbA4VFxOVJMIAUHKBAxDdAJ65QirnDXukU/si5pBWxed0LYhabs8XxdTGD8skGEM1XQZBRkYlLJBwOx8gx/23RjX9MXRIXGCo5IlGQZNycGfF4RSy2sXJ93CEg7QVCEFIrjGDco+1kx8gzms6Q0tOiHyU5SRga0ZFWdFghx3bJNDZIkZvM4wwPyUcRRnKUt8SlouBYyQc2TpSdROMqMznFjbGRjrlEJjmgyErucbGVtLxjL0f4yVNysJjGrGYyhffFZmYTk7PUpDSPKE5OUjOBRcOmN7Upt102qp3MNCc5PUnMKsrymEqUZznXST5eYqtGLSylJdFpS1hOM560G6gx97kqSgZUgM50nwyfmc8bLjKWE83fNRW6/tBMIU6V37wnOVUm0Tny55cW1ec5Q1pQk2KToy+F6XTeSdKDBjKabdtoSVX6nXRCNKY/DWdGh4lQcAbVpgal5yuJqsbk9FSdQM1ZPyO3UmEO9aFJRSpO2WhPph7HqVC130wzKdaiZg9rOWVpVpeazV98FazAkyoiy4rCp6KyrjtlD1qhSdCqUlWcFE3pW1nUUHiCqLAkJIpe9ArYea6Vcfpxq2CB5FG3fPSRhwWfT/GK1YvuVamOfSxjgylZ0pZ2LGT16/o4SyRurZZrrd3sY9XTMrrG1bRAjRBmTamEXVyqtjQslVaDW1OB6oq2Fb3tDx1q1tSu9a6hFa4pYHvZ/rbStq9dHc1xL5bcwqH2WN59LmipK13rjrep5YWuc6OLCuRy92a2td0pwZtYv/h2ukf1133FK1Tj+va3unUvZQhLU8MSGLFzq6+h9Ptf0XK1mnXQbsUC/KTlpjW8dFVvHQ2cXvyyFr3W5MuCi4vdN0VYxBNGcYotMl/6ltgkhjLvMf3LYf7mRo4fVnGOD1xjzWb2wktdLx1h3GEbNtezXCTvwYasY5xxs5sjtaoAg+y74cY4RTOm8Yi7c2MsMzlh4GUdixHsYssVQhVd5vF1t8wKHHuZoRUm07DErC+1bGLJGPbxXI/szSQ3C81uts2Aoyy6De+2xf0t8zzOfOc0/nOYy4wGdG02WGU1M2/OcSZzp+68aEpneaprVnKnIz1qUk/j0kWQiVfw8hhIg5TPHomjqEvtZoOcGtVoUfUgWC1rMRrZykR2tZ5nrSb4PlnDg+bqryPq1S+12tVqBnY3fT3syQK02dYuNJDxK+2/StunAiJFrC1L7RYV+6GWxjaysahsu0L22uNmKbRBDE5nk1vAcN4zF2ztOA97a9Xv1gl9wh2ZetubMYIuLLyj7U8A15jdNuz2shM+soG7k9cGx3jGIUEhJxPwqJ8uDmoUzll5e5zH09Y4RyvCcXPDWn8Q/tTIp1xyOcs85Rsyt10Jre45frzXiFafzR/eaJNr/hnlNw9SFD/Kcnxb0efBnm3MA05xl3fw4kjHedN9NmimN3yqT+f20CUu7JnHtugg7zHWgYLwow8x22c8tLjQBXO2CX3b6a15x9WekEpevd14/TFK496aubNX6jcCd9Wj7Pe9N97x+u762z999mAH2bnqTDxP+GX3x//R5pwfe9odS0jDW50kmW/I5vXe+cHsGvQW3jnZn0n6qeSdbKjniOpzznq57C9wr98xpjlA+zpjj/O4z4rutc77Xy2feMv0eloH7wTiZ9f4MEE+rZQffeanhO2iP3fgpT/m4aOO7ovH/vaTf0ngd78lvGR8JwEv/j3Tv5mUNzbYf952FMpb/v08d78AFMBKs7/Vmr4LCCMzMBe7yz7qo6n2G8DpiT/5gzLZm70TUsAEPD2qiwh4gsAI9AxOkzAHAz/BIz8H0EDFE7bj40B/8MDVA8Gq8L0x+kATpLMOxMCK47r0Y6VJeMHdi8GeAMKSQjfKcj4lSsGtWEAelCgffEAYDEIv4b54q7+tA8DQK0BUqhvZ0r/9gyiBq4UfPMIodId+Krj6ezUjnMLQ28IMwz+o06nNEsM1JMM65L0aHL8bPEN8akMuLLnLu0I8tEMWmkAKPDYLJMImVEEke5AGxBtBHETByITOoqYSzEPhEzodPDomVLcTC7tIDI8ZPCRINMATXLlF/kzDOZQ9T8TCLARFqhjCSpQtV1y4W/szNpy3SovDWQxEKHxFZPi+KBgn5uI/LDzAHkRFXSQutOvFWPzFYpCqPewwZyLFKaNFU1JEJcxGVdzENoPDZwTHcEySjvNGnePGbkTGW/TCawzHVlFHY4y9YiRACxSDc2TEdJTGPGtHmbqOzzK65xtDC6NHJwTADcTHQtTHfRyOSCnEcSy2ckQse8S8FkRIbFTI1HDGWfTDCpRHXmy7enxCqHHEw6rGi5RCyQMmStSjK4RHPWRAgkREg8whiGxFk6yJuHrHaXwqhwxINBzIMAxJZhpJAytJmzTKAONJOiwy/oPJb3PEeexI/jw7ym3KyZY8xKgERKYESkSUyv06OZacN6ycSqsAiMU6OYBUyjyLya0sRpnsxKrMv7EEDVKUxqRESahbSxzkSrdcRbi0SrlUjIx0w7OMR0vES63Uy7ZsRIoEC18EzCcKSKcSy650O7DMyi9kS6cUyf+DIcd8TE+wLW/MR7grTHZEqYLMzLriS3SsSB/7zNe8Obu0zK9UTL80NE9bR6z0TNgMju1SRo40zMNUTZoMPqK7zHPjzRAMsXSSxdI8xr0kTtf8Q9oUvd1MTnyAnbqctIcczdNsRqFkzFKyzuv8BsE0Orbazp4ErFaauM08yDkZT/LUmbS0MrP8zasMzlas/s3uvESvZMbqNE/5BATuxDL+tEH8NE2B1EwDFanpPE/dDFABlVDDkU2unD/Nis7inLwL/bH4nFCycLfA2kgE5a3W9M6OrLXwfDsP/VBw6K3IGszKtFCPbKQNO8X3bDgWbVGccCHtHENyNFEF7bEb3cY+0dEdPYYI/cYYZbi79La7ylDpxM3DJMYERdJOCEaXIkG0dFL9hFLblFL/zM0OVdIrfYOWCxgwDVMZncwxrVGwJNK3/MAjNdM6jZYKbVMqfVMUBUMclTw6tdOf2Koq5dLZpE4SnNEU9VNDpcxAFYvSg9F/dE5TtFEGrUKzy8r1sVJHLcPEiE48zc92G1JL/m3QKX1STeXU+FBPTU3FLi1FlzQeNSVNU/VSVE1VNqFPnbRPwgTOTXWtUQ3S/tQyDrXVW3XRVfVJ3yTCQp3RTN1TYF1UqCxWY6XWWwJVX7XGtCPVUjVO2oyvatUQf1zWSaXUZt3WV+3WB/1WcJXBVGO8KLVGZs1Tb1tJ3YrTvvTUMmXXYJjTT03PXPXOei20e2XN5QLUfcVSZEXO+2TTUC0ygbVMgr3HYDlYhMWRyJTM9gRYIG3MYBXWDQXEdbVYaRhCtWrOXn3O8DrXeMVUb53WkYXZ+rnWlIXYZu0/WhVVkY1Z6lDJl21SRmXGmoVQ9lNRm63Fnb1JTYwXWQ1L/oetT5pFVACN1gvVWaS1CQgcwdsk0XKNypUtO5x9WJ+12ozQ14QEPHl1WmxUWY+lQrBVy6od22HIUhlrL17dWlgdWLbNt5YNWrGN2x0BWC/Nl5nlWm3V24gT09yE279lXEL8UQJtE68Vu/0jwPsB2sa9isayXKOdVbyN2MMlObe1yMXF3JMgA8Wpvsu9VM81V9D92sRdUkItXZdov6zt3IbF1vo0XKwt2sol3dndh7I1xLMlV0zMW96dWo38XeANhe/zyI/8V1cN22e9Kr5dx82dV+bVlMB90i4lXNbtWtedXMqdP+xNW+1FX358XIWdxvAjU6Jd1OAU3vRth3oy/l/T1DvkNVLObFUnnV/6tYRKGMo2+l7jtVnxHd9nK1/zBWCUAL3UHMXoVd2aFNr3LVJ8hbP/beDtld6fRc315V55cl9idFC0k6vc3WDP6WDqYk853VjIBTAEvjvRPc0TTuHmZd9kleGnLV5bFM9+Td7Ls+EbJmI9KWAfztHKsp6ilV8NLuJ+4KsaRVsUbt/wk910NeH7feKDAEmJJGAJ5tzrteKFhd1P9NstfofDbUoaBOPs/bsxrlnrFePlRWNqcOJsZc8pfs4qteCZjF/7q9g6lmPu4GOUO+J/2d9Ehl8/zuA7FuRhlYIoZlgPdmOIg+MtpeEa1uJH5mT/OGR+/ktiRc7B+C2wCe5kjNBSTEbZPb5kKS7jv7ziU8YN21XeyuthRA4oIF5kF/ZeR5ZlifBYAc41EF7h4X3TWIbkET3jXwbGHPbdcV1l8O3jFe3TCw7jo2Vmw3Bm6mXSUr5mMz5mMsZiW97kbIaNENbhEjrZuzVgsdRlRublCQ5kc6Zn7Gzj8z1QREVm8lXmfa5nWBQtBP5kUGbUd95BUj5hKv7nOKDlBY5L3D1GVvVnBe5ncV7o8jTRDJyRgfYghzJoshtJb67ki8YDX64tV47mdg68jzZkJhZpfCZpBtbm3CrmRiVozmVpEmtpfJvnmA5dac69urVbiOZaibZokO3m/jj26aVeDI7WYz6eaFysaKVmaklsaElNaZU2aqpO5qRW5apOBlbM4oemZJheXaGNaqn2apQGa5KlSULpBae+5RZOay0k3nJu6+rZZiFma6IG363+6q4e6rrOa0hB5/stwhd25sPIafTcZXk26aUOzfISai986r+G6qPm57XO48L27NO6Z4Vm7FGhaQzu5b3+7HUQ6zUta4W2aWjmaqQebM1Obb1mWrPVubm2wskcbf6dZNqubWEImouJ69COaMLmbAv67dgO7k9w5No17qJG7tmm6ORe5+Y27JpGUPmKbswG7uW+v6kObOwWkcP+Lx65alh+adEm7fb27bumY/KW/m/v626tnm6sFmz8Xub5Xorb5uGsRuKCdu8kjOdvfm3+dm7/Hl31Tujj/m74zm+QW28El9uMfV0NnXDpfnDxVmvqHm8KHwXUnuO+bm0HZ+7OfuXcxmsQL1HzRmwPj292/nDYjnByjnEWR1tcLm54/W8Z13EB9+hqLvDs7WkcN3KGru8Ab9PeJnDTNvADP/K101u5Lswb1+/NHucTj3JHUHDW1lq/bmcrl/BMbtsV33JR6CnExfAGL1cxt2wy31s2P/MBFfHYRXEfv2lLZHJ4dnI3LvKqjuyPVXE8323x23NkE/In/3Omhr+M5vGmxV8YDuNDB+nezfA5x/ROJWZT/lbu/R5ku4bzLM90V/m8JFdyPafYJQximR51SZBcNCTrSw9zTw/1C6/x6m11yBzUnx50MD91Q0/1xy7YJ7/ZXHeROqdgLTfzPAd2g33vWpdtYy9rP4A3KsdPN8fyaM921ZJ24Cz0FWRaa29YbK/uWw/vl+72dLdjU2d2cj93c+9wo1L3pE10Yu/xWb9veM+sEibheaf2HeZWL5dzfN9waJ/hFMcofz8Uf3Q9xXbxpnX3eN/2icd1hedgTm9lEpf1X494UBd1ie93i+f2AD48h9fuOC94hDeiT3cwkZd33MVMR990e195Wld5Prx5fnf5ncfhmR/pms93bX/3j28k/p6n3dKmeUhvcZTM1yYf9koOdKNnsI3/8hJvc5sn+n1n+aKXekW4qQQW9GUv9I7v9Jy3qHHv+kF5+LFO+RnvaKYPdj5/eoeNepKuexF+cwBvd6zXd603e4NPe16H+S9tTXGfdr4X+qHv+10M/Mbn8sjDeKBv+8U/+61PeMdHZdSNfCjPccSneI/PesbHfDAA+IBfcF//8SWPe0S3dHQf/X9X57O2ZEJ/e6BtermfWE6/+26fX0EsSqW/+qD/fNCnfJ1//bI/58I7Qo6Fe2cXdp2me2SncDX8Ycv6fc73ds8v98RX/JE//u8/durf/MoX/u03/+HnevBfCM1P+vx1/v7oW+JVf3n1z+7ly4XrZ37bX/1Kl3/vp/+SJgD4iLPcvim96aKkOOtqzf5g2AFhyXVmOozqw7ZnBLfvbN94ru987//AoHBILBqPsxpSNzoQm6TlSimdUH3N4VW15aKO3ap4TC6bz+i0eo0Ls5nuDLSaVcfb91t+s9f0c39vgoOEhYaHiIklgYBzQVBRJo5LdWmMKZVAly5fep1Fm4qio6SlpqeoqaqrrK2ur7ByoTaZZ7MgtVifNLswt5i9scLDxMXGx8g7uZK/vMFlzX7Rshae1XjXRtPJ3N3e3+BjkJSBy0/bjdma6FbPzOpJ7j/s4fX29/j5g5vmWvS08tLB/tM10EtBgzLABNTHsKHDh8f+gZrkb+E8ib4sAtQY7+C7hNZATvQIsaTJkyg3iowYqp8Ql3Q4ZpTpbGXNCypxjrSZsqfPn0CnkFyHkcE4YDThJK3IkwdMbE0/6uwY9eLQoFizat3KtavXr/ieWr1KjmzOqQSr4lrazqxStWDjyp1LN5FYam6dFr2p4OXeX9H2xkBbt7Dhw9yOKqR5t0djbWwX/Y3cIDBlhIQRa97M+Ss/wW3z7sysbLJoCpZPn3XSubXr12tAj1U9k3ZIuGVxr2b96DIE379t8+UNu7hx17IttUxemfkH08LXRg+uW9p0qX2Pa99u2DlFv5celwau/ve6dfN4SUs2z9w59/fw48ufT7+beIHo36rHn7339NTV8UdcfQQWaGAs9zVHHnb7xZQfagum199wHkDVYHkBHqjhhnIleNuFCj4oXYQCVuhfhhRGQhWIfJDYoogcxigjfZ+5+JyHJ7JYm447TphiiSqeA+OMRBZJjHtAmjgaj0kGaQZ0TGLmo5QD9lgleCgaqeWWZCAJTY1DnhemlUrONqVjwDXTno1ctummhWfmGCWZcWKA44pZYjnnenkyWOaPcF4pp6BvFmrooYgm6tWddDr5JJsh7smnpNRRahSkEI6p6KacInYnoyk6+qimQvU5aZ0jWlopqmiS2umrsOqp/ipSooFKJaHiYLoqrvqxeiN7unLiaqzEFquKh7bSaipRy/7arLOqAjirCMEaa+21oU2LxHdCDjuYtr3yGuifaUVL3preYqsud152CeazyoILJFPyZuvri8+iC++6/Baob7qlnpasn+R+Sapgap5bbaT39uvwwxBHHOvApza82L52VguYwgC3K/HHIBPyqXsUj4dxpiejbKm0Fo8rasgwx1xyqjzODG29H4qbc8EYmgtsxwvHLPTQN7d8adAMG90tzknzbLLP8P6rNNFUF+pxqC8PqnOrANO8NZ5fg+00tT+nLObUVadN19UO0mYzvmbvnPW89KLd9Nxej80102r3/t2T1HY3ive3gYfKBpSFF6234oMzvi3Sfkcu+eSUK/L22YnvnbmEYdMpN92QdV356KTb2znhp7vceG5877r457utjvnr4dJe+u0bXs5557pnDHnesgMqa+rCRg0527gn3+ZyvwfcuvDMPu888agH73vc10uv/PZcIV/x5gRbr/rhwSKcJsfYqww+9+wX4/3jbPWu/vqgR0+/6bZnnzjg+bfvvzfJ4dbSMiQ//PVvgNQjW/qOli/0aY+BD/yfBCdIQbUVsHgLhJ6ZEqjAlTnwfrsTXwVHODkcXbB6IqwbBx2nwgNWr34IdCEJZ+gZkpXDhs2DGwjvFsMU8tBl8Msg/g2HKB8T4lB0OlxhEmX4PR9CMHP8cyIRp9iQ9zGOibGT4q2wuEEuLlGLXwSiGEMnRCqasW0RVE78jlhGgrUQjLPTYsKAhsQz2tF+SuxgG1EYPimcsIlv7OEYYxfENN7xkIhMJLu8Y0XXwVF/eYwj7Ca5pEgq8pKIGtnv/gjI4XkxjIQcpCAxScqUcNKR1jvlKVmotUdC0osssyQrS0nL+Wiya6sEZStHGUpK8rKWwLRPDrHmrk02cnqfDOEvPSfKQAbzmQbboxpto8pjIk6W84Pl+egoTWh684eVxKYejVbNYSrTk67Mphw/KM5zfvOd8IznoqKYzKft8IntfGEv/ve5THn600i3lKYAR5VB8/2HnfWc5T8XyopV3oeTAy1mQTW2TeNx05AMzagwAprGiObqYBS9TiwTqkuNmlRk5gxfOuN1TwOStJmayyc4xQbGKJ70pm4UZmQgmktJorOfW4TpLnFK1JK+caXAyx9PrVm+kDawbB1NaVGnStWqJrWQGFVouVrqSF8yk4xZtapY7cFRrvLxDdd8KQYLN1KkvtKtY43rOGX61lTSE61NddUcLSpQqcr1r368xVLr6NOh/tSrGnQmYBdrT7rWzrFXxKpZg3rYytIUhoplrEmP2cMUDrabwMssHrUp0uP5VbPcC6CXPOpSyUKWsoaN7Vf5/ila1Nr2trj9bFgLO1q44pOLbXWtb3FLXFiU9bW/VatQG6vcmSb2ubItrnRZ2ty6Ure6a53sdWu7VSUG92K7na54t+hE3Wo3p9HtLmn5GlXCjheanEUhdiML3vC+lbsxXe+sbPred8YXnZ69K/lAqteKQq29oO1v6VRrTvGYF7no7S1Qt7vcLg5XwRjOcPtY2zP7qhO/HV7hd8F6Xg2bGA3HhXBPjareC28MqiX+74kvWU6B/XHF7pQwiDuJ2PTO+MdHzeKFkztkCvs4xPqFomndC2REyhiZJa5rkaE8ZR7r2LKzvWx9IdzkyD3ZwgFmMJM/jGULV3iuVf5yl9cl/hsOtzJ4bn5sldG848eemc5bnu+a98znh50wzqzjqkGbNeJwzrnPiJZzFknsYTIfmblSLPSEE83YGmfpzzi+b5lbfOfQ5vnQlJ6urTDN2bS62MBKvmiUQ21GGQPa0EV+9afrjFnY0nbTrCahmvNb3jZn2tFXfjSeby3sXEvQ1+16KLJPm13sDvrAqe7rmI1N7WoTiNTTNiCtO81bLTNaz9YOdxx7HbRfa7rY3M6xtw0tbsBaOkrYTrBWeT1pK6+73u0O9aiXLW8W03vb/rY1vvMNz/gqBsX8brS2cY3kdcKYy7smuJsirmiaxtrgeRXiXqENcWZL/FVi7reyy41x/gJrHNV55O/HV87yiSd81Z5Gd4/tnWWAt/zmaCa3t8wNbDPb/NzEDjbOb8pIt72cyzT/N8OTLvCfDx3DyYq3wps93GfvD6Fp9vjTvax1IoO7iRfvenKdDt0I35vsWx8axZO0aFgLwtQDn7eR2Z3224V8tyPfecknWuDSPvzrUK674AevnQvynOpon3vZzZ54wrNc1q3t7D4yLr0XszfGYnd8Ce+ONsPv/XlW9y7What5IA/M85kP/NLtPHPGr770dmTq4c8aZLyavPIo/6TKYd+3tY+v7bUfMN9P7venSrvfvN8S55F+N/GhPtuIf3261V1z6Sf/+tiHSAFnr0+Z/gd92N/ndPYHv2+nIj/gkI57t6vv/fHf8cbM6zv0o99+9ru+6dZ3v7u3sf3/wr3xzmV/Pqd/sdd1Bxcbocd84DeA9ddzAih+BCgzqddbwJWAgHd/6QeAY9d6EBiBIbN8F+h15CV5b0d5ZrVx0YZgU+eBLNiCn3ZqE/h/+Qd0ZzeDLshq5Sd/57d+SteA9Bd+PXiDTgaCYaaDK9h9QseAD7iAGiiEDEUx/ReDJghZKJhyS7aDTogtVnSACGh+RxiAQaiEi8d0SZiF6uJ7wGdxJGh7w4d7xcdxgIeGZlgXRCgGyGKBoBZzZRiG+NeHeziHgBiIk6crkDdrNjiGcqd4/k0oiBkWdUVRiIbog4o4iX4ohoxIQ8+3LL0DiXQniRhIhp/YgZc4VTOzidwHhg2nfjxYiaI4isrzPlwofAvEiaq4hNNHg7aYga5YLHLYKGz3ZnmYiKx3iAsHhKm4i7yINLSohoYDjIPYhieYezV1hV+IjNZ4g6Y4garniaCohzXIjdcoao5IiE8mg+C4jcaoi+FIQZlIKdk4fz9oiXxIifQoj+soT8sYeRSIUrcXjW+YgpgHj/eofMwWi7LYOqeIiur4h93IhMQ4kDHSi+Q1jeSojebIkA5Zj60IkVajjLlkRBUpkAo5jOeIjt+IkRyZkirZfG6Vjw/ZkLdYjOlI/pIraWKndzku+ZIZeYwnGYrzWJMLhodCRoHBKIy19pMwaZRICZSllJPyRZT8CI1UKI1HiZJMCTLIY5AHyTROaY806ZU76ZM8eZUEKZL72CRQ+Yyg54Wi948dZ5ZkCRQCJlwy1JVPqZaCxpZJZoWqpoBx+Zd1h5PlOIXzZXn7RY0wB5jP1JWCqY1dpZNh6Y25+JWKKTnyk4PYk5AjWZULiYiSCZmVyY5v05hw+ZgliX5JiZobGZoRwzZayYaZOZj9OJVuqXuI6ZesuRUSqVKQ1pKyKZWFSZUcuJS5aUu3GWWMQppYSH3EGZMy2ZOrWZzS2YJ2iUpFqZTD6ZxICJ3N/jmdVWWX1Ull14mdM8mdqhmZ3emdEhOeIig3L8WenZme5nmen3ma6ml3ymk28EmZY2mV9Eme/Hmf13I1rwmb+qmZG2ifzKmR6NmfAlpEjilnrhSe+8mZFnqhALqg/vmgsEFPWSdYNlOh2pma87mKDOqgHJqisAeeCJqgG1qiuOiZ8amiRVWgE9lwIciKI0qiDiijAUqjEAOfN4kOIrqj9YmiJ5qhRgqkm/eIJVOk2Vmek6mhYjmjTNopyQalLZZQWgqjPuqlPaqjSHqlr7GbSUVSLPplFwmWR8qjUUqmnmJMR9eWJNKlU/qldxqmSfqjcNqn+ZamEbqm0dmgSvqm/n76TRT6pC3qomy6pJK2iIdqKKM5pHW6qCY5qHzapm4qpZHqNzY6lL05nv8JpmI6qibaqJ1alvL2qSVIpJYqqPIZo6Waqam6NhHqnu+pqGpKmDBofHD4octZq8lQdHi4l+tjp3g6q6Qaj3nKqcL6rCfmlMiarHu6rJtJqLQKrU3JqteVTNNKrVXqrNvZrNaqrctTirq6IN9areAarlS6qeVqrutZpNJqqZcaq+16rZqKr/LqLznEra2qrvYKq2MKr8wKmv16EmY6bu1Ur2pGsFZqsPoasQnbFWw0m5vjsLcKsdl6qhKrrBUbssTlkgD7UcDZqx70d8BajSILM5AA/lcku67sCrL5apriSq4tSySMGaKYWZqMiqkYaqrvyq85y2Yla3EO97C8WouyOrM3W7SF1zxHa6C/ipsfW6g0+5w4W7NQyxALK2XNFbMDu7SLWIVxeKtdewgXGyYvG6qqk6NO665b+7NcK7dpe7ekuIxTi0Z5aYQiNnqRiLdqF3bveBl7y7eOZYGGOrQFK7gAdbgsuVKQK56iirV2m7UHi7lz67ib0rbfFjiTG7io+rR0q7l1y7lxikv2eqY6h7YcG7Qei62wi7peO0xVF7oM27o+W7oUO7tNe7WXS7tk9a+4S3XHqrcyG7zAK7R6qrynK7zQS0ueq1Jwa7r76qiA/vu50YuV9/SyKLsU06u2ZAuaj4qw2xu1yJufqhG+hfC6S3qv1hu352scE8q+nZU69ouXiauXSXuYfVm98/sQHuoK+ftFiRm/zIvA5augAYwgtitO3nu/B1TAVOts/Pu+u9fADrFaFDyRuVqIHdyFJ8u0zbu8sqvBKKxIEZxzViu/J8y1C/yiKZwolRrCoRo2NizCa+m3FaiypDfDEZnDxktXK8y6lXu9pIvEsavEvgvErcFWRUyXFiPECIex30un/nt8LOvExjCXrRDFBtzCzsvEmwu/LozAXNxQD5zFWgrGuXvElmvCjJvAmSvDaTwMWUrFYKtcbhxCB4zGc5zE/mY8xmd8x4a8YX0cuX9cyHRMyDE8uod8ril2nEPhvQAMyL/bsZn8woIcyd2RyEPsjwVqyXDcyJzMyI8MtJ68GTZmySbLWqRsOeNbkqlMtKssl5RMyrq8y1u6H7FsF7Nsx1r7vGR8y2pcR3foyi/oy8qMCO67uCVczJ1szKLgMb9MvS3VzOq0uxMbr9Jcx4QcztQ8zr23y+Z8yYy8xNAMznIcx+RsILy8x2t7znpcxSPchLXcuO/8xLocym1Ez+ZczcEMyZv8zWW8z7h8gAAdTQANygG7w8TnqwD5lsGK0KvgoQ2d0Wql0dosvlZMwsOMye5s0c68xgW80IHG0WjL/ruaXMZmu7KLTNKQirTmcM4SrNKlbMoGDbz53Lsy/dNpg9Or280Hrc6BbNRNDNTGKdTxHFhMXdGn3M7RrNMsrcpKTYdPncs4PQrPLMg93dJXndBZ3WhjvcUFPc1HfdZULc5h/Q0YXdYOLWQqzdUDbdVIndbr3Nb6C7dw3VN9jc7pjNcKLJzaq9cX7Vd/LXVZTdcfXbbZ24mGHdkSONal0NXe/NVJLdn0m9hSBdemYNmbi9nvq9mm9NdOvdikANp1K9p5TdpVlNh2UNaVXde2TNSC7c2uzRL/y9n1jM0ozdj3jLCsjda5/cOnzdkMzdSz3djCTdiQXdzAPG28rYLK/p3atK3PI13VtQ3d3C3J1W3dzH2Ow43b3Y3V0y3GlEvPp6Da8TveRV3etUvZdoja4B3ctPzYIA3f9QDbOrzVy23fwszOUU3M+n3Yu33eTvrUn33dPr3Wg2zXBf7KiXnetkDfwA3RbijRWByQUB3hAr7M3y3Fv33hfRvRv5rZ7+3hKg6h/v3fGC7KKXt5FG3WK44MCF7KIV7fL06bhIbfM13j+63gyZ3R683gYB3Sgb3TQO4+nr3XI07i+8vD/TvRZ8vNSx7ggnPjGc7RRR7eWG7bao3iV07QN9zi9szlC+7lZI7kUn3XY26+ZU7kEoXmLl7iW351Piy6b77nGjLX/qjA3oXs3gTO53/D3xUc0KkA6I7s43BO6Inh5xWu0Ylu5GKu3Uqe5I7e5ULevnSe5gC+5h+e3Wyd6Zx+4FquPZDu6TsenLVJkVoc03yex7J96E2t6nYO43iu4VXe4UBeahY+50+u47fO4yc+2gNO6sh+GA1t4J8O4VMt6m2e7CYh36Vu08y+6lfcwzK+6zQu7bEd7JFu7ZOu5s7+7A5+7N4+7pIu0Op9LJSOwYzOwOk+TdR96h7Z7uqO7fk9roPu5vOe4lle604e19Hd7NttswDv7/8u0rwm8Gfu8HUe5Sae62zM4d2+8BjvwB2d8X667BE/1Bzfcv3s0QQf8oGI/u+2nrwmH8kjv/L3CO4k39suf4mIbggtP/M4f6iAnfMcid7nwPPeufNwAPRA6fOQQfTSLvRIH5hKvw5Lb9FN//RSP/VUX/VWf/VYn/Vav/Vc3/Ve//VgH/ZiP/ZkX/Zmf/Zon/Zqv/Zs3/Zu//ZwH/dyP/d0X/d2f/d4n/d6v/d83/d+//eAH/iCP/iEX/iGf/iIn/iKv/iM3/iO//iQH/mSP/mUX/mWf/mYn/mav/mc3/me//mgH/qiP/qkX/qmf/qon/qqv/qs3/qu//qwH/uyP/u0X/u2f/u4n/u6v/u83/u+//vAH/zCP/zEX/zGf/zIn/zKv/zM3/zO//zQ/h/90j/91F/91n/92J/92r/93N/93v/94B/+4j/+5F/+5n/+6J/+6r/+7N/+7v/+8B//8j//9F//9n//+J//+r///N///v//BDAfU5fbH0Y5abUXZ7159x8MxZEszRNN1ZVt3ReO5Zmu7RvP9Z3v/R8YFA6JReMRmVQumU3nExqVTqlV6xWb1W65Xe8XHBaPyWXzGZ1Wr9lt9xsel8/pdfsdn9fv+X3/HzBQcJCw0PAQMVFxkbHR8REyUnKSstLyEjNTc5Oz0/MTNFR0lLTU9BQ1VXWVtdX1FTZWdpa21vYWN1d3l7fX9xc4WHiYuNj4GDlZeZm52fkZOlp6mrra/voaO1t7m7vb+xs8XHycvNz8HD1dfZ293f0dPl5+nr7e/h4/X3+fv9//H2BAgQMJFjR4EGFChQsZNnT4EGJEiRMpVrR4EWNGjRs5dvT4EWRIkSNJljR5EmVKlStZtnT5EmZMmTNp1rR5E2dOnTt59vT5E2hQoUOJFjV6FGlSpUuZNnX6FGpUqVOpVrV6FWtWrVu5dvX6FWxYsWPJljV7Fm1atWvZtnX7Fm5cuXPp1rV7F29evXv59vX7F3BgwYMJFzZ8GHFixYsZN3b8GHJkyZMpV7Z8GXNmzZs5d/b8GXRo0aNJlzZ9GnVq1atZt3b9GnZs2bNp17Z9G3du3bt5/vf2/Rt4cOHDiRc3fhx5cuXLmTd3/hx6dOnTqVe3fh17du3buXf3/h18ePHjyZc3fx59evXr2bd3/x5+fPnz6de3fx9/fv37+ff3/x/AAAUckMACDTwQwQQVXJDBBh18EMIIJZyQwgotvBDDDDXckMMOPfwQxBBFHJHEEk08EcUUVVyRxRZdfBHGGGWckcYabbwRxxx13JHHHn38EcgghRySyCKNPBLJJJVckskmnXwSyiilnJLKKq28EssstdySyy69/BLMMMUck8wyzTwTzTTVXJPNNt18E8445ZyTzjrtvBPPPPXck88+/fwT0EAFHZTQQg09FNFEFV2U0UYd/n0U0kglnZTSSi29FNNMNd2U0049/RTUUEUdldRSTT0V1VRVXZXVVl19FdZYZZ2V1lptvRXXXHXdlddeff0V2GCFHZbYYo09FtlklV2W2WadfRbaaKWdltpqrb0W22y13Zbbbr39FtxwxR2X3HLNPRfddNVdl9123X0X3njlnZfeeu29F9989d2X3379/RfggAUemOCCDT4Y4YQVXpjhhh1+GOKIJZ6Y4ootvhjjjDXemOOOPf4Y5JBFHpnkkk0+GeWUVV6Z5ZZdfhnmmGWemeaabb4Z55x13pnnnn3+GeighR6a6KKNPhrppJVemummnX4a6qilnprqqq2+Guus/rXemuuuvf4a7LDFHpvsss0+G+201V6b7bbdfhvuuOWem+667b4b77z13pvvvv3+G/DABR+c8MINPxzxxBVfnPHGHX8c8sgln5zyyi2/HPPMNd+c8849/xz00EUfnfTSTT8d9dRVX5311l1/HfbYZZ+d9tptvx333HXfnffeff8d+OCFH5744o0/HvnklV+e+eadfx766KWfnvrqrb8e++y135777r3/HvzwxR+f/PLNPx/99NVfn/323X8f/vjln5/++u2/H//89d+f//79/x+AARTgAAlYQAMeEIEJVOACGdhABz4QghGU4AQpWEELXhCDGdTgBjnYQQ9+EIQh/hThCElYQhOeEIUpVOEKWdhCF74QhjGU4QxpWEMb3hCHOdThDnnYQx/+EIhBFOIQiVhEIx4RiUlU4hKZ2EQnPhGKUZTiFKlYRSteEYtZ1OIWudhFL34RjGEU4xjJWEYznhGNaVTjGtnYRje+EY5xlOMc6VhHO94Rj3nU4x752Ec//hGQgRTkIAlZSEMeEpGJVOQiGdlIRz4SkpGU5CQpWUlLXhKTmdTkJjnZSU9+EpShFOUoSVlKU54SlalU5SpZ2UpXvhKWsZTlLGlZS1veEpe51OUuedlLX/4SmMEU5jCJWUxjHhOZyVTmMpnZTGc+E5rRlOY0qVlNa14Tm9nU/uY2udlNb34TnOEU5zjJWU5znhOd6VTnOtnZTne+E57xlOc86VlPe94Tn/nU5z752U9//hOgARXoQAlaUIMeFKEJVehCGdpQhz4UohGV6EQpWlGLXhSjGdXoRjnaUY9+FKQhFelISVpSk54UpSlV6UpZ2lKXvhSmMZXpTGlaU5veFKc51elOedpTn/4UqEEV6lCJWlSjHhWpSVXqUpnaVKc+FapRlepUqVpVq14Vq1nV6la52lWvfhWsYRXrWMlaVrOeFa1pVeta2dpWt74VrnGV61zpWle73hWvedXrXvnaV7/+FbCBFexgCVtYwx4WsYlV7GIZ21jHPhaykZXs/mQpW1nLXhazmdXsZjnbWc9+FrShFe1oSVta054WtalV7WpZ21rXvha2sZXtbGlbW9veFre51e1uedtb3/4WuMEV7nCJW1zjHhe5yVXucpnbXOc+F7rRle50qVtd614Xu9nV7na5213vfhe84RXveMlbXvOeF73pVe962dte974XvvGV73zpW1/73he/+dXvfvnbX//+F8ABFvCACVxgAx8YwQlW8IIZ3GAHPxjCEZbwhClcYQtfGMMZ1vCGOdxhD38YxCEW8YhJXGITnxjFKVbxilncYhe/GMYxlvGMaVxjG98YxznW8Y553GMf/xjIQRbykIlcZCMfGclJVvKS/pncZCc/GcpRlvKUqVxlK18Zy1nW8pa53GUvfxnMYRbzmMlcZjOfGc1pVvOa2dxmN78ZznGW85zpXGc73xnPedbznvncZz//GdCBFvSgCV1oQx8a0YlW9KIZ3WhHPxrSkZb0pCldaUtfGtOZ1vSmOd1pT38a1KEW9ahJXWpTnxrVqVb1qlndale/GtaxlvWsaV1rW98a17nW9a553Wtf/xrYwRb2sIldbGMfG9nJVvaymd1sZz8b2tGW9rSpXW1rXxvb2db2trndbW9/G9zhFve4yV1uc58b3elW97rZ3W53vxve8Zb3vOldb3vfG9/51ve++d1vf/8b4AEX+MAJ/l5wgx8c4QlX+MIZ3nCHPxziEZf4xClecYtfHOMZ1/jGOd5xj38c5CEX+chJXnKTnxzlKVf5ylnecpe/HOYxl/nMaV5zm98c5znX+c553nOf/xzoQRf60IledKMfHelJV/rSmd50pz8d6lGX+tSpXnWrXx3rWdf61rneda9/HexhF/vYyV52s58d7WlX+9rZ3na3vx3ucZf73Oled7vfHe951/ve+d53v/8d8IEX/OAJX3jDHx7xiVf84hnfeMc/HvKRl/zkKV95y18e85nX/OY533nPfx70oRf96ElfetOfHvWpV/3qWd96178e9rGX/expX3vb3x73udf97nnf/nvf/x74wRf+8IlffOMfH/nJV/7lBdB85z8f+tGX/vSpX33rXx/72df+9rnffe9/H/zhF//4yV9+858f/elX//rZ3373vx/+8Zf//Olff/vfH//51//++d9///8fAANQAAeQAAvQAA8QARNQAReQARvQAR8QAiNQAieQAivQAi8QAzNQAzeQAzvQAz8QBENQBEeQBEvQBE8QBVNQBVeQBVvQBV8QBmNQBmeQBmvQBm8QB3NQB3eQB3vQB38QCINQCIeQCIvQCI8QCZNQCZeQCZvQCZ8QCqNQCqeQCqvQCq8QC7NQC7eQC7vQC78QDMNQDMeQDMvQDM8QDdNQDdeQ/g3b0A3fEA7jUA7nkA7r0A7vEA/zUA/3kA/70A//EBADURAHkRAL0RAPERETUREXkREb0REfERIjURInkRIr0RIvERMzURM3kRM70RM/ERRDURRHkRRL0RRPERVTURVXkRVb0RVfERZjURZnkRZr0RZvERdzURd3kRd70Rd/ERiDURiHkRiL0RiPERmTURmXkRmb0RmfERqjURqnkRqr0RqvERuzURu3kRu70Ru/ERzDURzHkRzL0RzPER3TUR3XkR3b0R3fER7jUR7nkR7r0R7vER/zUR/3kR/7EQWXDyADUiAHkiAL0iAPEiETUiEXkiEb0iEfEiIjUiInkiIr/tIiLxIjM1IjN5IjO9IjPxIkQ1IkR5IkS9IkTxIlU1IlV5IlW9IlXxImY1ImZ5Ima9ImbxInc1Ind5Ine9InfxIog1Ioh5Ioi9IojxIpk1Ipl5Ipm9IpnxIqo1Iqp5Iqq9IqrxIrs1Irt5Iru9IrvxIsw1Isx5Isy9IszxIt01It15It29It3xIu41Iu55Iu69Iu7xIv81Iv95Iv+9Iv/xIwA1MwB5MwC9MwDxMxE1MxF5MxG9MxHxMyI1MyJ5MyK9MyLxMzM1MzN5MzO9MzPxM0Q1M0R5M0S9M0TxM1U1M1V5M1W9M1XxM2Y1M2Z5M2a9M2bxM3c1M3d5M3e9M3/n8TOIOTtQCAOIvTOI8TOYuTJ5KTOZtTOJ8TOj+nOafzOJeTOq8zOrNTOy3nOrFzJ7qTOrdTPMezccBzOq3TPJOTPNeTPQknPZkTPd/TONuTPutzb+QTOeMTPwHAPvvTP+VmP+fzOwOUOP/TQA80bZwzKxQUQRvUQb2GQa8iQvPpPa9nP0XzQkWnQp0gQ+VnQ0/lPG9gQiEBPndgRKniRK+BQFdUPddnRaGHRZVTBWKURlPUdLoTBGpUR6vTcHbUR/mzBnSUc170CITUcX40QF2ASEklRG3ARhmhRHXgSaFiSqcBSTvUfHZUea4UBa60RlsHPHPUS2P0cMaUTGcA/kkvR0uFIE0Zx0zTcwXWNFSaNEijNBLsNAeq1Cn0NBre1DzPp02Jx09NwE8JlHX+9AMKNUl7VFHxUwa8tHICtQcg1U0blU5LQFI95VLRFE8foVNF9FOngk+hwVI3FXzGNHgsFVNLFU5XB1E9gFVbtXBi9VVbwEwpB1VNNFcXh1bz8wR2tVNMNQZGlRCI1VZDVSqMtRl6lUfFZ1B7h1ZHgFm9M3VktQOmNTwZFVuRdVVvNXKeFVS9lVe3lVDf9FOEFQaUNRC4lQbU9SjcVRm2FUjDp1GhNVZFQF7ZVTqtlQPytUVn1V+bdUbB9UgV1UkJNnHktVsRFlPQ9QXg1Q/0/vVRJbYpIBYZFJZeHfUANFZ3ejUEAlZgb1Q9KVYCQFZAAdZk57VLibRWK1U+EYBj05Vlw9Rlp5UEsDRmG9ZiP5ZkB6FnH/Znk2JnjQFjv6dlG4BfbedokfZDrzVlVbZ0nDNoHeBpoVZwqnZgl/YB/rVmsxUCkjZOwXZrfXVcsVVaafZrtXZSHFZJp/YP3DZsudYqhrYY6DZ+0JYCcLRj2TZt9dZpUxZ1FBRuFwBrtdVkU0BtJ+Bky9Zr85Zaj9VvM2BxE3Zww7VxFfdxL4VvWcBu76ByV1Zuq6JzhWF02ydyLeB0a+dzYTZ1lWBzNydKVzdPSxd2aTcB8PZayzNz/iugdX+1dyVXd0PXCH43AogXUl43a8nWEWS3XIVXVJl3GGw3fXYXA6h3dkIWVq0XCaS3TEuUe2XWeWXnewfAeENHe3n3cn03fU9nfNWXbs/3UZAXcaG3Duj3bMM3Kto3F/R3fNZXcv03dmT0ZuF3CORXTWPXfjk1gTXHgFGXgM23gakWgHl2gkmHfwe4cx94USJ4YbFXES64ehdYJ0C4FkjYeyr4AlAYTOdXhYGAgyeHQU24efH3dV64eDV4X0u3hTegfEdHhrNXh21YUISYgpUXSmn4YJF4T0W4F35Ye3YYfZ04gKGYB4j4cSJUiovYiGnHiiU4i/2GijF3fMM4/oe3uIC7WAHImFDQ+G/NOBGYOFHh+Ca+uBXouHrYOI3tGEzxGGjl+Gqx2I/jVokPlXvVuHaZmI9vN5FhOJDvd5BDuJHhZJEh2Y0PQY+Z9pGX4pJTYZNhdJLJ95N9x5DrNJL/ZkI7mZIrGXY+eZQzp5XHVnpf+ZBV2QdkGZNLuU1COYppuVgzeWJ9WWhxmRZQ2Xl0WZd5x5bBF5hxtVOJ2YGFuWBFOJkjdYxtd5oxx5m9eJl3mZcV5ZjFuJsFAZqfOZyZIptH4Zy3tJrT2YfZmQHc+Ww2FZ5huZxdFZG/WXGMOZGv+YC3uV3XeZzRBJ9v2J/zIKC5eXJF96BfYZ4F/lV/Bxp3+Dl565k7P7Wh3/mi7WaSJfpbHzqIMzpuLvqbIZpNSFqbPdiSCxpyKTqYVfoYQBp4RhqmGdik25ilGdmiFxqIXRqCpXmm1Uam7bem81mnyfmmU/inm2SoCbeouaCp+/aojSKpK2Gqd+eCl1p8RbqqtyZFkxqridqnnxqMI5mNv7p7ebpt0bpktxpJzHpjxRoL4PqkExpF5foU2Pp2BtqtXWevHdeu28ZGvRqv12ajB1ts9DqDDTue//qWoxqpGVtL+lqxq1itWdixiWKyj7iy0QeiMzt4N9uyLzuaw/en+xplQfutIftuOpt5TXtwGpq1UfspAiAAUEKy/lUbCuDZsw1it98Yt48ntmX7d1wbqkX7s1HaAEq7t8emsH+bboLbuEHZufMGtkGYuGuCtmn7JG5buNdguqU7uoFiuVO6u50Vl6+bfav7u5mbXZV7vVfbmsebq897aNEbcNQ7vME5v2c7u7W7JLh7v9/gu0G6QK2gwKfgwDnXanFAvguhwauVhO07audZwhN0Sme6wvumucv7iiO8vh8cQgfcw9/7JPq7v/9bj0G8jwPcfZF7dnGXCMTWhXsYofdaxdeVxId7xDncqin8xo2mSjH8x7Vmw10cwul7dYecyEUcyXmcKEzcxEkCwI0cENb7e0fVUCearjEaS1t8y/O4/mn/N2eVmcqlQck11IQzvKedfKdZ/LTLHKbV/D5j+cyjxqSFWM7nnM3bvMzxtc4JAsqhfCSm/MvFec/5XIAxuJtpNLQLPbWXdIapHNJr/GV/2c194c/L+NLn2tGnJ8/znL0lNs4znWqKvM8nXJjxnNRLnckPPblX/R8CPdBFgtAT3RDe+8rbW04V3ch91MttXZHPVL9ZdFhzPBNgfZY3vbFP/XnkHNRDPZwJHNmhhpWN3W3u3GKn3c5bXdm53NV3QtZlPSRqPcFv/dv7FY6fNFO1uNDXXUxJ20gJOt5XmtmdQduxOc3vHUDd+dnD5nWl3dr3PazPHXGwfXD7HW98/jzV9f0ewj3cQYLcF9xnCV4Dct15xZXdgf3VKdXPL97Xi3veBbnelzXge3zhS56Z+Z3haQZ5AZ7iGffSER5uDL6gZV6juX3kbTrnocLhHf4jIt63u53XO52Hcxrj41h4GVbngZ1L6flH01ro9xflc4fmoz6v1dzmu4ZYMzrrBb67Vx7I8/3gpz6kcZ7oO/7lZ6Lne94jgB4RSNzit/hoxxzdQ3fuK/3d5T5yZRy8T5Tvh17jVZTsr/7k036Pnbvrl7xnuR7sk6baDd89xb7mB/9tFP7bEx8j1n7tO8LtzR3yjfrsK15uNfjvHztkST9xU9nWN7d3/53Gkd7qb6Hx/iWn6mOfi9kZ87HGgLWa8gm7kGd/aGp/53O/7D9/rQvf+FdC8zWfIzrfwZPfr7vdTskYxoteean/9Y9fYI11fZU1++ve9ku4928f+cN/inEf+F/G+3E9/Yvm8c0f5nfe+t22/ZHG8s2fo31i+Zd/I5y/l+GfAOZjKkK7ryinee9YS2nuYINYJ3ph5GUmWFajSrKw9sopfbcuvvO9/wODQpSwaDwik8ols+l8QqPSKbVqvWKz2i23h/pEv40uuWw+o9PqNbvtfsPjctOXLZ7j8/o9v+//AwYKHtW9EL3dDSouMjY6PkJGSk4OJCIdUmZqbnJ2en6CChZCiYHRYIam/qqusra6vsImoK6NPpXG4uZuBPD2+v4CB/PqEm/VYs0Wc+jEJRvFxHhZ/kAz89wGEUWfzm5zO196K3OCj5ufo6err7NzHTNht8vP09fb3ze+m+nj9/v/AwyIi98ya7TKCUyocCHDhp0IAkF4Ip7DihYvYsyoBCKhaSokLihlSiPJkiZPomQgLg3HZx5TwgQibCbNXzHPtSS1ct3OgwZd2uj5DSQdF0INvdyhzcY1TEc3JA3386a7nTmpYs2qdStXpE+HRO0qdizZsv7Cdrlqdi3btm6tEA35terct3bv4s1LRe2NqyKn6g0seLBbvtTQSvD7dwbhxo4fmy1nGChg/qlxISusqbkmZkeTN9YtFjrt6KEiKZeWuxh15Y+rD+toXTR1X9qdFRxabPs2796+f6uWXYQi8OLGjw/+PEU58ubOn29SflkLc+jWr2NPVX0FSN3Ts4MPL56ucLCfW3rfPX49+/ZLcqe/oFO91+/uX23OP/P+me3D6bMCYBX2mYaYUv7lcFpHBAZn4GwjlBcCgtxF6Fx86fGXoYYbEjOhhMRxGKKIIwLiYBYekpiiiuMxx+CALq4Yo4wzJsiUZYxNdGGFNPLYo2MoQgUihTY2qCMEPiKZpHFGvgYPjAXuqCQj+lEZjJRJAClNlLkIuFeXOQqZDYJNLkgfmT4sJZ+Y/l8mxuZjTHp3pZxz0lnbk66ZWKeee46Y5Y048hmooJHZdud8Ww6aqKKEuimLVXA2uqikk7aSJ5phFkSkSpBqSqmnn9bD6V/v+QmmoaCSUaWqNqE6Qak4nKpKrF4iiqeldpqpIJZj6hrRmZdG6mitwIn6a6vHItvbq8Lemqyzz2bVLK3DQluttZRUN6uTwV7brbfkaFvkkcwWq+a356Lbx7KbSutMudSmG6+8xrwr7YOdlrnuvD2s2m8v19YbMLeaDLwtvubZayu8o5J6Z6++PgwxvEMCyqLA4e6bscZc6ltJxBuDHLIyCR86scgno5xvxfWtvE/HKcMcc8MDJ3Ox/rky45yzwgcjfJ43No+rs9BDUwz0GH+2/B+mRBfhr9MBWGv0xaGaDBfNS6+p3sesJX2vmwwrXbWrBesltdhMo512GSR/uLXab8PtMsYq3xy33Wo7TDZsZ9/dN9Mdd2O234PPy3bRBAYuNeGL72s2zwfOza7hhD/9dLWO10tP5LZcPfnhQcOKddaPf163xHMDrjdemHfNuOuv02366J7DXrvrL+9Nuu27X54337uqzrvwx6bOjNvk4j688u3RLi7i0RwvefLLU88e67JrGaxu1UdQeeXQXl+s5r9LsXmN5DsPOpSt96z72KVG3xT60qsvXvzng829/ss3j3z/+wMQ/mT/Q1r9AmhAPvFqfu3D3gEbCD7z4W9cosPN/RxoQeu9Kk4sY8wE/afAC4KQNxW8ENcYmL0K7s573ntW+EQ1PvexpHMQpF8BvQbD3LEvU41C4fpGArwbNkdrxgohEYU2QI8NsYhKbNz05PfBJULxN6eaIQ5NGMUryql4RnkSD7HoxTfBb3sblM92uvjFMzZGiPk7HRBt2ESYqVCFzmohp+YRvB/m8IRt1KMVdbhHJ/6xBnnElfYKRsW8DLJtHUQjI+cIpBK8sZGS5NARS3i0SWLSOhM6JCATmclPrudlhZhiJUFpyov0D5L2GSWAFnnKV2rFk0Ey4yy/pMo7piyO/nFMFh0hZccnNgGCpUzfJQkZyNDBqJTKFCYuC+PDsEUSltK0H+3SBMxpYtNC0ezhM7PpTbt4iJOQu+Y3yykWUVpTlu9rpjnbybFw3jJKdZjVMN1pT5x0c3a2rGY8j3kbXQI0oAIdKEELatCD+gKVvWTSL/1Jrw++MVvijGAxuZlPNqrTjRWN3UX1RMt7gtRihoMPO0NqUkaVdIx9PClLLULPlJZuoy2dqTOpiCFLypSmOm3HR2kIhsncFJoO3SlRG9JTU6kxKBNdC0Kb6tSnQjWqUtWMQheqI3nAVJ85XWANQVOopUqUW8uUYUZ95MqiolWEZ/WpKbaZ1re61K07/lspXOuaDhQtVaVbtStfM4I7DXJ0r30drCd6OgqgijGwHSUsY/ux1lq66LB5LctUK2vZy2I2s5upKjkhS9eBdNarQ/XjZ7UqWNJ2FY9lRaICxwrRrGbnsY2dLVcS69nYTJa2ulVHPbl62t0Ct7Dayq0iRxvc477ir0msYmmR69xmLNeDHFxldPnY3OdiVzuprK4gmSLXrmg2vOIdL3kHylnjMnexHYJteg2G3rn+tk3NTKb51qUv4lITv9ndry6uSlFUfJe/As5Eb02r3gEjWF3DZS9Sr5vgB08iebZVLIQrrAb/sjZ/iF0jTg9s4Q8v4n8YDmqGV/vP8qI4xSpe/jEwzmtioaZ2ve+9AjND2934pu9FtLFvfWs84xUVGMRC/oTjpDvkI5sjyBiNMZKbTJ1w6XedP3YyldfGSe5al8lV3jKwjGZkizoYvlrmMpljCGXB+ZQ9LF4zm9tsWReHmaM8tbFqxzzOF9+5rJNtEVnxLGU//9nOdApwmQuNCJvl2NCKJjChY+rhRUM6y48WMxqUHOlL5xnQjhZ0pjmN6UgDLdF61XSgPf3pU9fZ1Lctl6jF4+ZXwzrWAYWzquXMEwZ3mdStDkNk2cnn1/a51sWNc5Isjepjk+ddDcYxspstN1yvmtnOnraforxsaU872+md9LaJrVFsa7vKU9v1/rDJZuxwf/qI46Ygnc0i63fDO975oTW4U81tV0A7y+71dqfrXWJhdzLMPp5ymmemaxk1Gt0K73Z8Sn3vhUNctO1GZr4jrtswThy1ALe4xS19VG5yHNPKlu8ePz7qkKNczA//NglJfvDByDvmMo85vVdOQJvLKuOW3PfGKR7IPfca2EJ/ecE/de6UI13lgHU5v5Pu9Gv7W8c6f/psM1jxf/ec6s5uoslVrvUyu1DjxiRnwr+eYNcyVOzrmTnb2+7mmie76Q+ZOoyjXm67B1zVQN9xsLPOdL9fG1VHNzvh/zvBshfe0IPPO94Tf/bIWZvddHc8hLnu8chT/qRGiunY/okO9cyjvLebjzbOeeP206O+vHB/KMElcfV+87zxPtezr4Pe+v/GvvSlaxXiQd9xDmtc977/fe8dLvzhY3dZmL/x8ZGveLAau/jOLyeWmd95uX97+guXMPCNr+bUgz/8lV39kyevh9fPHvDk5hzf2/3r22Nd9g7PPe+Xr/37xx//lJctje2v/3bymPmx1f8pXERFn/8R4GAxCP/1W/MlIIhJ39054GOIXwVaIEKR34mgXxts4PXR37T8XO21H/zdV99NII1E4AMmHgKqoIAtXgOeYAvCVQDC3/XJnwx+2LkxYPqpHw4i2AIeYAf6IE2lYLS1xwUiYRLqUgYigxBe/pgALlkMftly2J7nBR/sGRz2/d0NBl79OeEQphwLguFxvWADjuGAlSAUxp8UnuF+RZMBfmEbglQVWuHnyaGiFeH8fZ8S8mEfVgkT9p8awoEY8iAb3pjUhaD70WEPTqHEaeH6TUoe3iHESeIk8lUZFiIXWqLmzdDyYeImotXgwaEggmJIvV8NSh4qlmJfVWIq1mFe+GEsyiJNAKLVkKIbxKFGfSAVjuAr2qEHZiEjNuLNEQ8hrmK4teIx7tQn2qAy7pYW+aLXOaO45dYoquI0huIiCqP3YeORJeMA7uEsiuMs1iIiPmKE3SLj7WL5aKMhXmEhrqO9xaOnfGM3glou/tqjSTFjM+YjK9oUtNVjP37SNlljNArkTNEXLgXkQTLSQhrjt5AXL0XeQ1YaPu5eMGpi9sEjCNLe0J2jK24jRRWjRTIkly1kSWbTPloUSr6VVY1eMJ0kS3rR4hXkR8okQiakjcXkTS5RQO7ksYiXIzEYRfZHOqojRrojNwIjL9bKwNlk0cmjFxolT4IdUVIlNqkkyF2lTrkkhuVeUm6lPhJXTYZkWLpTWOmkVZolFPmkWl6LZrHQRHZJVmrVIDhlWW6hv+1dU5ogTHokXpLIT64lGrrlYGISXSqdYXJiV5KYIxqkYqakW5FlRkKmOaHlNVpfZV5cYa7hBWHWAw1l/q5Unx1MJRY6JmVy3kYyZSKSoCH1pVRipmbeI0nK5kzGpGDW5t8wZmPaG1jm5jTJ1WT65m9mUhlBH20SJ/fUI24iy5uBpvnlJG/OAXKq3WkOJ0jqnQjy5V+iJlQSI2w+ZnJWJXWKJwjtYBNyZnnq5m5O2M11p3qeEiYeZ2nCp3L6Tmx2Zn22ZGEyZ3NKVdTI5XZ65XSSZ15+JUfWWiRF51OK5DzuHHgyqH6OJ31KKBGdJ3pSaIWuJ3t2X929p4ZOUoBZXoGCqN/4x4hmaInyznKmZ7dEFcAEKGtWzG2mqF4dKDt+lUIuaFl24msKHomqaFr1Z5DuDmJqJZGGKIeO/qYZIikRRhmK4meTHlAChdaQSina8GeLestTdUujVeHn5AGQQqJvXWdmZuJqrtZdfmj+ISWEAuaVVpiVwqmJGumolemcDo6SLqkN3imeOtAnQml4+qn+UGlsyumgxgyLiim0NJW3eOlXbRAeaGl19iaaxplwHqV1+mVr1qgUTSqiiuWigmrcXGj5deqoyouedqiBoSoAxmh4fmqrwgw8VamoyirKfOOhJstBfcuj1mqEphojqOmb4h7jrSk4mmZUtumygoqu3uorOeuzykypamCsSivj6FedXuvd7CP32eq2pmqseOupguu0umW0AiVBnYuv4qegLpmwmuCxmmkm/papcXInWA7rj1pruULrvvIrzlBrtZLrv2JrVqErwa4r5o1rlCIst76U6hxswz5nikZsq5hXwoZmWgLrgyrCsBKrvV4ZF/mopjIrPfqrxCbpt6KsxgQshg7sytoNfmkrzOaMSi6su9Js2uBVyKpszsYlPlasxQJUurCru+Js3uVDvMor27Ss8ZVevjqoh+rry/qsJAVt1U4s1SIr1n6TzJ4s1wJovqFTz4ItpWTJ2Gpt2YYtxX7tlu4S0b7qxqYidDFsyURo16WmsQLmiY6ssvptJF6t2hJq4Aqu0c3skRYuLHkt2Sau4YrtPzJu4yLQ2UJu2kqumxJrtzWSHMVL/tHKLbkMouXqoXUC60g1LTHpHtSW7HeabORern227esiy+kGouvKbq+m1OHeLsZWHDQe7e4WDsY9EeECb7FZpe7izPeEa8ZG6e92nmcoLY8ayqpGofCpLsliL+DGbvFSD/JyL++KKvF+L+bWbt2OrwAhYBqK7vkOmvBy6vqy75547xr2KeM4DRMxr9F+bnsl7b223uTsaWLm2t265r22ru3Gb8FubwIHCu2Wr/kyMN6U1PxGsONeHdpBcAULZaRgsPNq8NpmKAXLTL9kjOdmrgwcWgY7gccSnecEsATK3vX+ra1JigN/cHyK7w3HiA0/8P7q8NtU4wL/cI9EYCXl/vAQi5RYWR0CI3GI8LCHyqvwqArLxu0J10gKe/AKR+9HuvALk97xyTDrzrCgPHETN6QIm/GglDGC+nAaG5F2wq8bo2AKuq8Ky7Ea11MdZ/Ed17D3rrHyUMnGmHAUSw4uum6+8g0/QciMKfL7vmIYN/Af87ESSfIkdykaw3D9WjKuwrEdb3IfE6KIHfEnL4noUa4QkzIGIW8lD8+8CXIVE/L5GLInR61vYR2Zyl86+R21QjLHjrH8snIqGxDeCnPw6uooF/MOd3IbJ/MB03Je3iAmN3OGEPMX4/I0m6vuVrNncgb65m8b7/HdQQLUiubObtFQVXMvS+3q2s9XWjE2/ndvMMOz2TqrNM9zouSVPd+zE+dh18nzPiPJNgffxv0zQENHUgq0e74zIO9HyAxyn4bzqkWC6u7oezlFjj5S34rxRudXDFKvQa8oFDMzSJNxtCIzSfNHPqMySj9HJX5cQbP0koj0Cb+0Psc0W5zjR/fFTMcy9wjDyTw0ji70846zjzaLF3ch/YIZ4KmzLbNzeJgMUt803HibVE/1Bj8zhV01nWosE2+1Wh0vLSX0V8cWwFk1vXraWJM1dkS1TuPKAK80yLQYUMPynUa0RBe1ATNffLUnXBdTB/W1vj21L3M0VAPhWa/1G8vS0iW2MespUmpyY0+toJ60ZN9Frro1/mJbdlkvdmBr8Qi59WZriHR4Nlwv9UjrT0Jx8jdnblZvoev17a80HGHLtnT6NUIXsCOjNkqFyUuKtgJ7hG//NvhyKOlG9nAvykTZNHIXBxrzpm0z94askXBb6ktAd3SP9hBRNy6DznZ70zCkTFCXDBbvdnXjtkEoDg3vddgRtnr/slOrMutgN+EU2Xw7qqoa4nLbd3b/qlfvd1tgcn3/NyWhmcsi2oDz8/VA9sg1tnh/9lD3EGzrtXTV0RgfeGGv82DDdyjJN4KTanp7eNayJ+mG+GobalyX+FqcJIinOPOwuMCuW4u7h4IvuPhstoPvG3lDOBuf98EEjIb/ePZi/niGvzdbY46M66yXIfns4ndvHveSm1Xw6DeUXzaNCgyVx3eMs17mYHmWK3mNV/iN1zX79bR1oeOEo+5sCzmFt9yat7d7w7lhv3iXZ/OV03mzNrl73nnnSjmK7/lNCGaQ/7mRazkZCPqgE/qXu7MvDTeOO6KO77h51/J6h7ZgO61mU+qQb7imJ7qdI3qievqnJ3eed5ioXzLZVbapK8SU0y9jqzpyFHpRhvmrH3So2a2NI7ej/0nouvakR2EmK1lceDen86+Gm5Z0sxqt1zmcKPuoq6pCNztWfy6rR3tMUHurw3S1Wzt7Q7qra3sQJbs5Dvu3z3KkJ5lGDzRlh0Zp/pOFnwPEuJO7N193vNN7vdv7SFb6vUPGgBIopus7IvE7jLP7vz9bmbNDU3+Iqb6YwS+Eu1eEuRM8KEf8xFN8xZusxYsUOmL8jDP8mmw83UL8uaP5+fk3Ojj8x6N8yqv8yrN8y7v8y5frXY8Muvd7r6PEycN8zuv8zvN8z/v8zwM9GNr8O+l2yN92R8t80Cv90jN90zv900N91KPb0BN9HVorzos81Uv91nN913v914N92Iu9N2k9aI18mJY8PsXx2LN927v928N93Mv93P+s0Zs8zcsB1o+D3tN93/v93wN+4Av+4BN+WZR91ROw5fK9aKR94Tv+40N+5Ev+5FN+/uVP9OEjvvQqfuPvPedb/ueDfuiL/uiTfumbvv+8BcJ3+5NvxeKf/uvDfuzL/uzTfu2j/NqDy9lLquczPu7b/u8Df/AL//ATf/EPOOb3ftF3PJF3enkb//NDf/RL//RTf/XvM/Inf5tHuIL5vowFvPWDf/iL//iTf/mb/xBjf/ar+fbzgesLF7yff/zL//zTf/3b//0Hafqr/7yP7h64/9wRAHxMhWl/GOWk1V6c9ebdfzAUR7I0TzRVV7Z1XziWZ7q2bzzXd773f2BQOCQWjUdkUrlkNp1PaFQ6pVatV2xWu+V2vV9wWDwml81ndFq9Zrfdb3hcPqfX7Xd8Xr/n/vf9f8BAwUEXBcKkhURFkEWrxkMqRckEyErLS8xMzU3OTs9P0FDRUdJS01PUVNVV1lbXV9hY2VnaWttb3FzdXd5e31/gYOFhYjPK4otJZYaPx8hE5JHlyehq62vsbO1t7m7vb/Bw8XHycvNz9HT1dfZ293f4ePl5+nr7e3zy6X0DXH7oZgCrODv3b0E+hAkVLmTY0OFDiBElTqRY0eJFjBk1buTY0eNHkCFFjiRZ0mQOg8v8pUTASOCzg+pYtjxZ0+ZNnDl17uTZ0+dPoEGFDiVa1OhRpEmVLmXa1OlTPTMlySMopSpUrFm1buXa1etXsGHFjiVb1uxZtGnVrmXb/tbtW7ijpF5dR/eJ3bh59e7l29fvX8CBBQ8mXNjwYcSJFS9m3NjxY8gb8DaZHNnyZcyZNW/m3NnzZ9ChRY8mXdr0adSpVa/eUnmJa9axZc+mXdv2bdy5de/m3dv3b+DBhQ8nLhY2opfFlS9n3tz5c+jRpU+nXt36dezZtW/nDvI4ku/dxY8nX978efTp1a9n3979e/jx5c/PGN6Iffr59e/n39//fwADFHBAAgs08EAEE0wLPyIYVPBBCCOUcEIKK7TwQgwz1HBDDjv0UD4HhQjxQxJLNPFEFFNUcUUWW3TxRRhjlHHGPUYEwkYac9RxRx579PFHIIMUckgiizTy/kgkk1RySSabdPJJKKOUckoqq7TySiyz1HJLLrv08kswwxRzTDLLNPNMNNNUc00223TzTTjjlHNOOuu0804889RzTz779PNPQAMVdFBCCzX0UEQTVXRRRht19FFII5V0UkortfRSTDPVdFNOO/X0U1BDFXVUUks19VRUU1V1VVZbdfVVWGOVdVZaa7X1Vlxz1XVXXnv19VdggxV2WGKLNfZYZJNVdllmm3X2WWijlXZaaqu19lpss9V2W2679fZbcMMVd1xyyzX3XHTTVXdddtt1911445V3XnrrtfdefPPVd19++/X3X4ADFnhgggs2+GCEE1Z4YYYbdvhhiCOW/nhiiiu2+GKMM9Z4Y4479vhjkEMWeWSSSzb5ZJRTVnllllt2+WWYY5Z5ZpprtvlmnHPWeWeee/b5Z6CDFnpooos2+mikk1Z6aaabdvppqKOWemqqq7b6aqyz1nprrrv2+muwwxZ7bLLLNvtstNNWe22223b7bbjjlntuuuu2+26889Z7b7779vtvwAMXfHDCCzf8cMTBEmBxxht3/HHII5d8csort/xyzDPXfHPOO/f8c9BDF3100ks3/XTUU1d9ddZbd/112GOXfXbaa7f9dtxz13133nv3/Xfggxd+eOKLN/545JNXfnnmm3f+eeijl3566qu3/nrss9d+e+67/vf+e/DDF3988ss3/3z001d/ffbbd/99+OOXf37667f/fvzz139//vv3/38ABlCAAyRgAQ14QAQmUIELZGADHfhACEZQghOkYAUteEEMZlCDG+RgBz34QRCGUIQjJGEJTXhCFKZQhStkYQtd+EIYxlCGM6RhDW14QxzmUIc75GEPffhDIAZRiEMkYhGNeEQkJlGJS2RiE534RChGUYpTpGIVrXhFLGZRi1vkYhe9+EUwhlGMYyRjGc14RjSmUY1rZGMb3fhGOMZRjnOkYx3teEc85lGPe+RjH/34R0AGUpCDJGQhDXlIRCZSkYtkZCMd+UhIRlKSk6RkJS15SUxm/lKTm+RkJz35SVCGUpSjJGUpTXlKVKZSlatkZStd+UpYxlKWs6RlLW15S1zmUpe7NF/ifPlLYAZTmMMkZjGNeUxkJlOZy2RmM535TGhGU5rTpGY1rXlNbGZTm9vkZje9+U1whlOc4yRnOc15TnSmU53rZGc73flOeMZTnvOkZz3teU985lOf++RnP/35T4AGVKADJWhBDXpQhCZUoQtlaEMd+lCIRlSiE6VoRS16UYxmVKMb5WhHPfpRkIZUpCMlaUlNelKUplSlK2VpS136UpjGVKYzpWlNbXpTnOZUpzvlaU99+lOgBlWoQyVqUY16VKQmValLZWpTnfpUqEZV/qpTpWpVrXpVrGZVq1vlale9+lWwhlWsYyVrWc16VrSmVa1rZWtb3fpWuMZVrnOla13tele85lWve+VrX/36V8AGVrCDJWxhDXtYxCZWsYtlbGMd+1jIRlayk6VsZS17WcxmVrOb5WxnPftZ0IZWtKMlbWlNe1rUpla1q2Vta137WtjGVrazpW1tbXtb3OZWt7vlbW99+1vgBle4wyVucY17XOQmV7nLZW5znftc6EZXutOlbnWte13sZle72+Vud737XfCGV7zjJW95zXte9KZXvetlb3vd+174xle+86Vvfe17X/zmV7/75W9//ftfAAdYwAMmcIENfGAEJ1jB/gtmcIMd/GAIR1jCE6ZwhS18YQxnWMMb5nCHPfxhEIdYxCMmcYlNfGIUp1jFK2Zxi138YhjHWMYzpnGNbXxjHOdYxzvmcY99/GMgB1nIQyZykY18ZCQnWclLZnKTnfxkKEdZylOmcpXnNBdmFAbLVuZyl738ZTDzZMuGGXOYzXxmNKdZzQkpM2HavGY4x1nOc6ZzNd4smDvXWc975nOf/SyKPAMm0H8mdKENfWhEu2HQfll0oh39aEhHWtLgmcthGj1pTGda05vmtDSSQxocdVrUoyZ1qUHKD8WEejGqzkOlWcsSU4vT1aI1CGhrfdlZzwzLNPH0p1Hia1MAewes/k4Mseew62OQFtn9gKuxe6CSpTo7IMvOslWlbQJkU/XaJcj2VLfNAWozu2Xhjsm0y82Db/NB2DpId2DafQZyn7uz8a62WqeShWlE+90UoHeypXpvEYU7qgAPArkHvu8J9JvXJlO4vDVA8GGvG9AO9wHC+2LxMDTcEJxVeFupgYV9KPXjNtC4v5068h90vKkor3i/Tw7xGZR84SCT+cY7APNfU7wUEs+5zU2D8S/U3OSU1fhaoX2FkB/16DQQ+syTunR0l1zkyriR1J9OdZI3Xdwd07rTM4BzHABdDmLHANnjYvbWdH3rkZW5vaE+BVQbNd9ZV7u+sR51oSv97WFv/rre7850tdf7YoE/gLl9HnGdyyXxeD88qHneB8ILvrE1T2vSBxJ3oloe8IG/+t7p3vfMzx3xoB+q5mNO+IxFvvAeAPsN0K7oxY9+6KN5Pb5nMoBdQ3bMph8r5mFCicfj1Penh3Xu5c77zw//9kIdvutTAoHlB7X5MZAK7i+9MNWv/ua1dwD31RB8vsfeM953BMu//g/Hoh/cjQ+r+n8PfPELf/ow+PvD3c/8+RO//slAvk7v73zP47f+y6n/k4H9K7sCdJhcsz/wi4DWSz6vUzz2S7kGzAzyu7wJ3D7RS6wBZEDJ86rnez+aqMCYCsEaIMGE60D5S0D9e0ALUMGZ/jJBADQ/D6TBm5LBFtQ+Eci/hIE1bItABERBFrhAeIu/nps90SBCuAPCEIBBv9pAEvhArvLBJbQ5IWwpKty8teM2KNypLDzBA9RAG6SpL9RCHOlCmypD6mNClwjAg7m1FdjCGkTCGaRDULhCA8TDx1BCq5DDE3DDvwJEvIq+KGgEPkQoQiS+QgjDG1TDNXRBMdRDkkrEHMxAwzNCLHTEF9BBFRDEgWHBlpPEPxRFQSDFFjjEskDFO2DEJ2TFvKI6VQxCKzTFSaSGWOy1WwQoWKTF9XM2V3SpXcTEFBjDJiTGlwpGS8TAXHQWUKRAXtzBZ1S3aESBZfyKahw7SNQr/k+sK2i7Rgl4BG/cp26cxqoLR3waR2EcxWszRpZCx2Qcwmy8RDvMxI8zx14kR3XhwXJMx0XkR0vAxx/0R8uwR9gjyJ9ix7s6OoN0BoOsJ4UEyFCEyIp6SIHExXeExoZsJ4q8yE78NoREqY2cx/LLSGBxQmesyI5ESUKQSItkw/FjyU34SLuSSbpaOoIkOJKMJ5uESXaLR5XaSZWUR5fESJ5kKKDkSGr0SaHkxGP8u5x8QaXEF5M8SaSkv6KEg1t8yqXQyiLkSjKMSrmCuptMDq9cJ7G8yvBDy4U6y6BkvXYDy5Biy6oMyLbkP7U8KLkUyZG8S23ZxoIjv7JEjrlM/ku95IzAJAO4dCuanKsDtMeqOMxzaky+BMPJNCjJrEvJSMx7xEyLuszBbMnCJErOnEgahEzoM01Z8cu/rMwHQM0GGU14hE1LY82VdM2VWsxmC0NzhDnbBCfP603N9KjfvMrgzMzevKbhlE2oZEnc7Kjk/EwoKE53Uc3VVM6lDDbrHEbaZIvj7ALpPKvmVExG3E1f605uCsDj/E6MQk/i3Df1pCj2zM4UhMn3nKj4hM7oNE9Uoc7qxM+U9M9SlE91BFDH0E8tqM/eM9CSYsVwxDkFxSYG3c5HFNCGilAKPU36fNBnslACjcTQBE2mBEliTE8NHZVfPAIEFc2hzAQJ/l3ODmWMElXGFyWrFC0rY2xQYItRarrRFt1EHXUmHr3Q1nTPH1WmIJ3ROVzRKCzSZDrSDxVBJZ2XE0VRwOzRjBPSJcXSi7PSP6jRr/JSGuU5b7QLJo2myiBRLtWnM23PDE1Te1pTLbW+No3TgoJTJKU0Nz2WKaVSCS1Tq7zTfgTU2aRTFvVT0sxTuwvRb0RUDE08Q93QwkRTQsXLSC3K8HRLRp0njrS4S/XQKD21Sp3UOnzS2AiAAGiLPb2PKhVVNKjGR/WOTMUDMJ3CV+UoJb1GvKjVZrrVWOXCXqUnXtXSTt1MUv2oYBXUChhW42RVgTrWYi1EXfUJUzXVtUhV/lXt01+VUUV9TWZ1i2gVTGSl1WzVu2V91lHd1gb41mXyw/kMV251V/uUwkUV1lltVHh9KHad13u1131NV3UVpnx1wHFVUXS1jWmdVrVQVqo01/9kWED4VceU12dIu6y71n71hHrNqoy1UWIt2IVlw39t0o4NWNsbWJ0cWYltWIct15XVqJTlV4/Vzjm92LVEWcQM2Zs42INFC2u1WJq1y59lA1zNVH0sgqINuJ4F2qSNzaDVhI29KpxNqWW005aNQZNdypf1PzYV0qcVzq292K51zqvF1G4tDJ3V2bNQ2I+N2Tws2zHIVo8Ev+qb0NCcWx81QhzEWrUF0ay1hbD1/raoFVG3dVG9DFzkHFtPZVsC/NqqlcWmzSiM69q/3ShJfdzEONuzTcW9fbZVtdxWHdzzk0/X6LZALVzjO0UxtdvEbUa6/dRZmNyDQ1xtY9RsNFxrqtzGbUfGdV29Db04fdrNFVzPhUDeLQ3MxVyyCF7GG16YJdl/BN3QhdfJMDjUjT3qjcN1WzaU1cQ/ZV5IsN06ld3ZhV59DVXvpVzxTVLn9cLdLd7tLarI3VjYddn0jd7c5YzjPV7jUF7Zu1+CXd/vJV+ldV/7ZUJ6q15LPGDsdVRqU98FrEQArgXwHaj5jatYjMcJnibcVdzFpVP5zeB1RcsPrt982uAIPo38/s3fsODf/iVgmT1fMRjXuNW5olNZRa3hpKTh601WBaZMGA5QEgZGEBYpVfTJIYYm4DziEPbgeq1gyBXhJlZiZEriIO6KFE5hsGDhnsRWAU67H2ZZDibb2Wu7Fx5jqxvQoXM5wt3htv3ih61ienRjtCriBpTiXYXjdvXf24TibdPiBeVjfPTjWuxiGz5h471iLO4KQSZMPW5DOeaCgZ3hxuO9vOVbgX27Si5Gh9tAHty7oy1jF14FJ345Qg5TQlZKO2Ym2xxl+iVULWblixK7V05lY1plWqYIREZkRYblQjZkBG5kbCxlARRQsvzITwbjepvSYy7gtatd3YQNNCzd/lBWBV7uPGEWq0OMyltuUjy+5Gs2SrVc2jUGZpOSZf5d5JGy5W6GilzOZa5AZ+INY2mW5zd+ZMed5nGutuaMZkdeuH3mTx72ufAoTRIEaE2256jY5nNcZ6bK5oJm6IX+Zr7tW/adVHHOY4R2KLK76PLN6AqFaDmVaLVo53beimoGZXz2VY/ey5T2YXL211nEQ34WY+0Lzpke2e4TSJZzEHjOaZEO5p/mKYVu5UcGy6GuZYg+6VjmS44e0qMGWKbe254m4qR+6oYgaZLOiqk2w5e2WYwNaqe+V4EgxaYOa14ja6mGBpkmCD2caqvOYZA+KfswaLZSQrh8a6gG6+2l/uiKHt6y3uq4nMy/VupDXen/pWfQwGqsxgrAbuMfHuqrTTeAoMWyhuljoGy1XYSgBDhJdOu4BrnG/jdozmRutFIGwetgOszKlqnXo+uQ1mtKZVbXDm1j7ebVxgzFVmyooO27HVzIhu3XbmmMVt7KZl2a7tBlDuiYxuewRe2Ddm6dpFruzU3oTUzo9qWydO1G7FaAvm2Yqr3u5m2vBW7lvu57yO3cfgrCRuOuRma+7lLyluyp3GuV9m6fFsX5zud+4EzJ/ewqFG+omt4GTsgW1UzzRhyuvOnSo00FN2vytkwGV037bsoH9+b1jgv0Rm+nuPD6bm8H/mrDHmaxbvB+/kZuEu/dw0ZSzb7f/q7woDvxsBQ2Na7JAl9rF2/W9M3vg9xOGNTu7YbhHp9wCg/xAT5we8jwDG8KDs9S3/bveH7vfexqGD/uaZ7y1fXl5r3T5C5yxKZyKP8EOAzE8my40m5yGydycI5v44bfGkdDH1/BL56+N/9xD2daKxcNJEfyrVzyic4+IX8DxJXvP7/vzZ7z8gZQQyf0GgVeJw+7jp7uV/w0Mo5xty1OIzecC5Q80g3wHr21O/cpIvT0RK+pTH900maNPM9zpQDwX/bzLYe8Bxf0Ee7sQVd0hx11y170dzvqHh4stqY8SgdyWr/xgMr0eKsqPmRjUi5qgRNt/tDtdYNNdVVHCla3c1fXcWmMdYjE9eHuclvvV0tnYW4PbuEW8Tpfg2Y/LIZU5k8HwQgfdjRfyzbf9PFFaHrn9FM+XWeP8wHXDWmXdmrn8xS/9luWXVmfWUTv6U4V8nEndyxf3Tu8PjEfa9xsd3H13u+89MIx9ge2NkRVXcAVZpDf93O/51OvjX//96Oo9gUmeGyvkQo/eCwN9+YOEYb/811v9HO1eG00xBFp+KcCb7Qmdl2c9zUPecM++ZUj2jCv95LncqDH35RX+aJg+V52eZ1v3YeP8nK38J+leUu1eTAd9JwneqPVXsS6t1Cr9YauTPXUeMLheH1H9jyde3zP/mi7D3qj7/jZmPqpr3qBf26st/qSffqWl/K/XfjEN/BZ9eNZN/yu7HdfX3H+DnzWFmxVg/vBkXu0d/qu73CJ9117Vva2f3bStwi/T3393QHVb32EZX3Xd33sVO3B53k7EF+Z/3z9/vJcN3zG7+PGf8usd+l0B6ymB33dX3pWZTXNFxzOL369J1+VW3bI3/3Ql769l3zUj/3W5wHuV33v//7Un33brv2oT4Mc33ags+n152lJzs7HT36sNHVIL3PbN/d432NRrc/mD5xS93oCgI+pMO0Po5y02ouz3rz7D4biSJbmiabqyrbuC8fyTNfyYtgVjjf8z9AJh8Si8YhM/iqXzKbzCY0ueUpgwmddSLfcrvcLDovH5LI5TE0GIdn2+gyPB+b0uv2Oz+v3eyP/DxgY6CdYaFgY5wWUyJZ25MhY1HMGufJjcwmSSbPZ0amyyPJpORlp5nZgqrrK2ur6ChsrOzvl1hJKm6u7y9vr+wscjFE5MypCLJysvMzc7PzMi6yI+gZtfY2drb3NDSONaRtBndNdbn6Onq7e+12DKjFevT5PX29/jw+uRTae33sIMGAeQgILAiRoMKEgfxRwRTImpF05iV0ojoD4wmJDjSk4ivPoAWMJkSZAMpzw7qTKlSxbunxZMpwokjBr2ryJM6cvkzFLjfSpM6jQoUSL/mYEyk+m0aVMmzp96oAnqCzDUkK9ijWr1ntSO1K9QG2r2LFkyzbrysSqWSUK2w4q4jauHoRy686B6ZARzWJI0/UVgzZD4BB7Uf71JrWwpsEWFBM+XLTN2smUK1ump5QU48ucO3v+DGWzJ9FRIYM+jTq1ag6kkUheDTu27NlY9g15rSEs7d28e5NtHfJrbrW+ixs/HhS4EdzIRdh9fpcIdOhwp9fF6/hLdhfKd9o+ZZpE96rhN37nlLj8sfG1z2tWoFV48/n064Nmfou9/f38+3fTb5h6rAnoX4EGHhgLgBFZgWCDDj4Ii4I7MPgBcRBeiGGGW0ho3nal4adhiCKO/ngbgdPklaF11w2h4nPStehWTR5yMeN7V2BmYmg5jubeDV1x+NGOAwBY43A9enWkUxSSyGSTTrYCoo3wPUlllVZWIeR6WU6Y5JVefuklkPqICWaZZtJG5gPyVRjlmW6+iWCaHxbZHopw3omnfXL6SGdzMMYoxJ92sShoQjLuidiWSE45j6K1dPkTpPllueeMRF4qqXiOHoponp5+2t+a3HUKaqmm3rfpgKkGyeiprr6qGqlHyQprrbbaU6mdiy15a6++XpVrn2qK+muxxia3qhO6PliooTo0u6IN0BbEaaaA0VonAvUkuxy38HhrpLXfirtoqxtgSi6b6aprblbL/h4Lb7yyETsTuPLei2+1N/K5brj75gtwwPhgO6m9Ah+M8Cxy8hrpuwk/DPEvCzscHMMRX4zxLgTXa7Bs0wpE6McGhSwyIthtfIKwPbV7Tsc6oPsvepS6zGW/Q9Kscs0xS5nKbzlnDHTQ21g8Ks1CH400K2L+3IjNST8NtY5On2h01FZfXa627lC8K9NYfw32RVU3PR69YZ+N9qwsP+Q1bSUf8uLbcJMs9x/6rg3e2OTh/d/UTcCs9Zh8N6Y32YN3uHPWgXOcuOLk+Fx42pJPTgTRRftNeeaay3x4yuyhvHnoEYPOc8+in466YJFbvnLkqb8uMJmsN+w67LbfS/pU/rVzVvdCcfdu9+/Az3Xy7mp3zm/jE2H+KPKPMc+u86wqfzz1Oi9e+uOMY5/9Wm3fDn74hH9/Pffin4/+3tZ77nLu6b+fp/uOaw9//VHLTv6w+dvP/6n4Kzi7/gkwYPJDwf5UM7zgCS+BdqALAxt4N/NRgmAFpJoEkwK98tGPLzPLII9sBrgLtk6EIzQd5Dw4wBRSLoC6Q6EKXxg0Du2vgjCsIYRoSLv12XCHvVraAefkQh4KsUo+lOEPh4jEDOFQU8arzAOJt8AnBsCBUpxiBEl4rSYaDovZ0GILdagl6RnwR7uzFM6MBkAv+mWJSWwjnI64RS66cY4Jk9AB2UjH/jzGBo9hFKMe/+ikIgYRcYMEpCHrI0g/Po+Ph2xkfNSYPDDup4p3oOITLXnJK5owDnBUnxytwcjxKVJVo2Si04IFwjMWUn+lPBckWxZKR8oyTmnq5CxvOaI0ovGVuOwlZ2JZsVX6cpirARLX2MdLYipTSXo7Zgk/ucxo7gaYH2ylcSgJwShmUpvbfIkzLSjJRFlTGMnM4Sa/CM0xdnCcXRtlCDeIznPGE55bsaU073nDWlITn/wciy6FmS159nOgx9mnK8tJ0IR6s5n6NKhCH3oNYzYUoRCtaKMomj15NAibdcAkAz36UZt8k0YUxKh2APoyVbIzeuGMIz3F6U6V/raUpQJV50pz4lCL6pSZrrPnTn9KmXe+1KYzBapR3WXSeWr0qEyt59hGas50NnWqNzHiRFFK1azCEqtqSOrFEhgvqErBp4SsqTZyysqiklKtpiwlKmMK0H+y9aA3xQlZtYrXR/YUrXntaxdlGo/ACraufi3sWb1K1LkadrHrsGrt7srYyObCsVx16VAli1l18BUsm/0V8OQl1ihAdnpSZQZig6lYT5r1cm4tY3riukuUdnays82sbZPh09HedrfmEOpgf6sb3gqXG7UNUGWHi9xVUDa17WRucp+boKe+1bnQra7STvvMy6awbvgK7RN0m9bSLgO7axUvXalbTbZO/le8QoWpec/73qGA17r0BeVV0Vvf/B4WtsDtb2D1C2CNkbet+A2wgbNIWA1qd3sFPrCDvytd1xb3wRS+2XG7NeCEvS1f3lVWSS984XkqF7CrLVhrQxzQEhu3wZZ1r4rFhmJcTbjCNHbNfeNb4xxHg8T+7XGHdQxkSWS4jywOspG3xtW7/vjITOZckUmL4+Y+uclUjupSRzxkhIkMYCwEZ5Sz6+QXS23KlePxlatn3vWKucWs/bIoyWzhBGvyzFWuM273mmU765nAa6apj/8c4z0LOs5wxlKeB03h5boZtYVGtKPD2+dFytlfjX70o2dsWTrDcFqxW3JXX5nISDev/tJInjSkRc3nBZcV1TA+samBuOhVazrVs4bKfC2N61K/esWkzrWvGaxqSQN62L3+NZUxfepgG3vZ5WV1s2P9bGUze9pQlraUoQ1fbFMb0ciGtbZh16yDdZmkoGZoDr4dSWt7Wd3RrnVi35tbMvJ31yl2t7CdLd9ub1vQ9rz1vv/NZhMTe+D2Bviy9U3oYhv8yHaErL8Xrt+GI+rhEK8vwiluNUHV0dOP+DC9gRjnMhyas/P+eLXZXe+CW1nl3kY5pfGtOtmOPBgYr7jNW+5yP+f85jyPNpoJDuieG/ziCBe6ThUN83sn3ejHjnCga8703RJ95geD0cPMtu6dI7PR/lpDt4u1DuGSF7tI8V4nmeXq9XoHtehRr/D/TN52iPsW6P6N+7SnHmi75xfpYNc5y/Xe9CRPnO2AVybe4X46FY2O40IuN1ZvlPY2993DYic1nRgf86m19+d/97n3oF74g0uU6qE/8IQJX/qB6hvzqc8x3ztPa9i3vsavLxHpZ6/Q1YM+atPB2LjHjHiSf3xfkRf45P9m5uML35qsX/5cNy955Y8r+ANDPe6h28ndXx/Ip7/99oGqe+9//6G1T6n1x//H8guO+ujHbPjznjkX+f73lId/ssXJyjF0v/KVvnzzFQx70Gd80ndyk6F97Wdn2Xd+CEhV+8d+DIhc7/eA/hCYWeqnawpHgYVlgWFWfBkoWRKIgaETLfP3fxxkfzh3PPmHYB1oe/RGf0SmWC+odM4mgMAme5kXghclfh64dxJ3gjzoejsYcEDIb0IoazdIhBbndCh2gElIUK+HhIzGgk6YVyA4ha8TF0eDdaLlcVP2LzkIg1EIfGm3hdl1g2W4cmEohrL2dWvIhmZRglRIbUfUhHL4XA4IhnZYhUY4fT+oh0YFhebnh39Ifkv4gHVIiIbHhydHgO/TFkjTJmPVhV73hVf4TK8wd42YbDuHhq3mNzXYPZz3eYuYiBWIdpZYig+Gh6iYilrVbYjYitE0eiEWh7HYgOZGi7Boi7L0/ooL2CvOAomRGHZ++DnYk4d+honJR4aMIYxpqIaiCI3R54YL5Yu7+FN3VI3WqIiDqFTaSHukiHOa6I1ZNYsglo3jeDvlSH26iI7pB44pN439Qy1QkxmS6HimtjPHmF5Lx4X8t0qeVo9bN06g2I3RKBa12I4JmD8ImZAGtor82JAa+I4MGZHgh4vHRZEVmVDqaHnsqJFJhGkZmT4BcTUBOYwT2Ifflo+sGIYRoowqqTImGXtISJDz04Yn9I4fCYjk45E6uZPcaJM+SV8zJoNC6VehxnU9aZQ2hJQdKJJLKYvgWJRJNDclKZOjpo8JB5Fp1YdoAJShOID2wnEWsnI0/mlmN2mQepWTUGlR3/OUbCl1pHiOcCk6RKmUdLlDTRl5U4mXR1c4fJltWdmXdGSXc+krJvM1wXWSWakcjSOYOMiSHCiOWnluCcZ4VOBCY3mWaQmWSPWWgxlxXvOZoMlYDzmZpIlPxdWJqDlVb6eMrHmUq8OQowmbgKSagEmVgIA2/bCYkTmErbNiYLCW7ZUsuHl/xamZ/oiW0uhUtFmbd/gzzvmcriiXazmdp1Nbq3md1yibcaid2/mE3cmTxgme24iSnOeb4aNAZ/NfonBtp/lyyqc8j6la8Vh/ZzcJm/Kdb9Z1zLOfbxiWyxmg6ACflEmf5SmRACmdCPqT5ymg/gx6i5VVoP8JoeGZi/9HoRVqnmNHnoy4lRraSBKVbg56Pn2wQu3ZMO9pnzpHVDpzUiRqgvhpG2iRobxmOjTaoWrHnJxZkFulic0IokxWowb6oUEam18pkEVqpLx4kWF5oEs6QBOTo0SqpFBKmI81pJlWpVbqRuXopOmJPgOhOf21j6jmb61BPU+6arIAfVB1lVL4OG4KpIG5oijIo0Hpo7H2plzKff+ZpXyaoDA6oIDalhe5lXtKqPykZpgzp4nqS4s6kH/qqHnEkW6IqL1USaFDd2RZnwXaqVv3Zi+qpj1qg5uoapw6g6Zaa6jKojvqqoPaWx2mmJPKcI16qbT6/oHViaS4Cj6VCm+syqvSNHiNqqWjGqx1aTzAaqOGeazG4qs0qKzE1FGos6kUeqarsj7G6lIKs5nhuJKzamXFek7xgKeleqfv5qlYdpWD1ay1aiG82a7CZZp1Gq8w9KyQwa712k+dIljLOqX6WkP8iqLiuqsAe6ISCq6qepfxZ0WvU61mdI/Ula1gGp/cqpwEC1ydCY89Rqoa67Ed2zcPa50Gi0QiS7K3Na8nS0z3Wq0qK6xaJLIF67LsCbMxq60zm5iGarP0irP6t7Psdq3Qo0M3q6PRdbEYO7Dl6q0Z+7HoyrMG+qAh+7M963abSrWlqauCerUHi3g/u6Vbyz+y/uK1YHtIYju1ZGubOmuyaEtOO+t3n8ZOYES0lEkLNUml/QqrSBut73muSXqazFqmLcu2AQZ0g9tXKWu4lKq2gpu4IQpJMdu4ivuDkBu5c8SyBFe5wEC5gfu08WmWLza3Iwu1r+qh5Eq6eiupAGqupwuyxOW2mduDQQe7TYW4sytElztstpu2g2i1uluyvNS7vnu7i1u4wssOdKeicJtakkS0RWe3S0usz8ifSdu0fvu0p5iu1xW8xltdPsa9Fimznkix35sxrom55Gu55TRw6JuX6kts7MuU4lm88Ltj3quGnQuZ+BZOzRu+reu0+XurtAbA0Su9eVu91itjuUu//tj3WwtcUbXrwPAzrLIbwcO7qxxbwSrkPhicwVGarO/bwd4RwNCwv+MbUd06wBcqRnt7kKJ7gQkbwvLKwjFMwzVMS3hrwzIMwzm8hzvMw36Jwz/8JS01t5qLwmzScYyKvzoBuHwixA6WvU8sxVPsGV9LxVeMxVkMoVasxc2xwiZsX0ebN1oLLC7cxWeMxmmsxmvMxm3sxm8Mx/kWaUUsMUeMQWRsa2Ycx3vMx33sx38MyIEsyINMyMBZTWopo3icqjesyIXsyI8MyZEsyZNMyZVsyfCrSHQswi54e018Fnp8yaEsyqNMyqVsyqeMyqlsd9sbGXbss/0rx42syrNM/su1bMu3jMu5rMu7bF2sTBTPK6qabFegzMvFbMzHjMzJrMzLzMzNLG7IyxTAnHUN4snObM3XjM3ZrM3bzM3d7M15PL9GIc0VQcyuC8vfjM7prM7rzM7t7M7vDM8JHMV5uozn7HxcfBnVHM/7zM/97M//DNABLdDpLMz1y8n2PL3zXBb6PNAN7dAPDdERLdETTdFPXNACJsYiV85Ds9EV7dEfDdIhLdIjTdIlbaUXrQtMC6dL3Ld71MAmDdMxLdMzTdM1bdM3Xa8oTVv5utKc1NF1zNM4LdRDTdRFbdRHjdRJTYE6Xbcv3dNwwNAuGdRKTdVVbdVXjdVZrdVb3b1g/kzCTh24Po3Q+aDSXG3WZ43Waa3Wa83Wbf1CTG2xQex5EzTW1TfVbo3Xea3Xe83Xfe3Xfw0qcM2mYD3XYyzYa3TXgK3Yi83Yje3Yjw3Zkd2cCr08iT3AYi3L1CjXks3Zne3Znw3aoS3aow0lXi3OnfzTpK3aq83are3arw3bsc0Vpt3Kde2vso3bua3bu83bve3bvx2Vtp2S+AzcxW3cx43cya3cy83ceJJTUd3c0S3d003d1W3d143dRpvZYZ3d3e3d3w3e4S3e403eUnvY0F3e6a3e683e7e3e783Xz53a8E3f9W3f943f+a3fEi3fwr3f/w3gAS7gA07gBX7N/v293Qau4AvO4A3u4A8O4XGM4Icd4RVu4ReO4Rmu4RvO4R3u4R8O4iEu4iNO4iVu4ieO4imu4ivO4i3u4i8O4zEu4zNO4zVu4zeO4zmu4zvO4z3u4z8O5EEu5ENO5EVu5EeO5Emu5EvO5E3u5E8O5VEu5VNO5VVu5VeO5Vmu5VvO5V3u5V8O5mEu5mNO5mVu5meO5mmu5mvO5m3u5m8O53Eu53NO53Vu53eO53mu53vO533u538O6IEu6INO6IVu6IeO6Imu6IvO6I3u6I8O6ZEu6ZNO6ZVu6ZeO6Zmu6ZvO6Z3u6Z8O6qEu6qNO6qVu6qeO6qmu6qvO6q3u6q8O/uuxLuuzTuu1buu3juu5ruu7zuu97uu/DuzBLuzDTuzFbuzHjuzJruzLzuzN7uzPDu3RLu3TTu3Vbu3Xju3Zru3bzu3d7u3fDu7hLu7jTu7lbu7nrtYCoO7rzu7t7u7vDu/xLu/zTu/1bu/3ju/5ru/7zu/97u//DvABL/ADT/AFb/AHj/AJr/ALz/AN7/APD/ERL/ETT/EVb/EXj/EZr/Ebz/Ed7/EfD/IhL/IjT/Ilb/Inj/Ipr/Irz/It7/IvD/MxL/MzT/M1b/M3j/M5r/M7z/M97/M/D/RBL/RDT/RFb/RHj/RJr/RLz/RN7/RPD/VRL/VTT/VVb/VXj/VZ/q/1W8/1Xe/1Xw/2YS/2Y0/2ZW/2Z4/2aa/2a8/2be/2bw/3cS/3c0/3dW/3d4/3ea/3e8/3fe/3fw/4gS/4g0/4hW/4h4/4ia/4i8/4je/4jw/5kS/5k0/5lW/5l4/5ma/5m8/5ne/5nw/6oS/6o0/6pW/6p4/6qa/6q8/6re/6rw/7sS/7s0/7tW/7t4/7ua/7u8/7ve/7vw/8wS/8w0/8xW/8x4/8ya/8y8/8ze/8zw/90S/900/91W/914/92a/928/93e/93w/+4S/+40/+5W/+54/+6a/+68/+7e/+7w//8S//80//9W//94//+a//+8///e///08A8jF1/rn9YZSTVntx1pt3/8FQHMnSPNFUXdnWfeFYnunavvFc3/ne/4FB4ZBYNB6RSeWS2XQ+oVHplFq1XrFZ7Zbb9X7BYfGYXDaf0Wn1mt12v+Fx+Zxet9/xef2e3/f/AQMFDwYKDQ8RExUXGRsdHyEjJScpKy0vMTM1Nzk7PT9BQ0VHSUtNT1FTVVdZW11fYWNlZ2lrbW9xc3V3eXt9f4GDhYeJi42PkZOVl5mbnZ+ho6Wnqautr7Gztbe5u72/wcPFx8nLzc/R09XX2dvd3+Hj5efp6+3v8fP19/n7/f8BBhQ4kGBBgwcRJlS4kGFDhw8hRpQ4kWJFixcxZtS4kWNHG48fQYYUOZJkSZMnUaZUuZJlS5cvYcaUOXNeAQA7",
            "title" : "H2 CH4 Atemtest"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
        "meta" : {
          "id" : "meta-12345",
          "lastUpdated" : "2024-03-13T01:43:30Z",
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-patient"
          ]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff\"> </a><p><b>id</b>: EmilEmmenegger</p><p><b>meta</b>:</p><p><b>identifier</b>: 012/08.111111</p><p><b>name</b>: Emil Emmenegger</p><p><b>gender</b>: MALE</p><p><b>birthDate</b>: Jan 01, 1981</p><p><b>maritalStatus</b>: unverheiratet <span style=\"background: LightGoldenRodYellow\">(Details : {$ech-11-maritalstatus code '5' = '5', given as 'unverheiratet'})</span></p><h3>Communications</h3><table class=\"grid\"><tr><td>-</td><td><b>Language</b></td><td><b>Preferred</b></td></tr><tr><td>*</td><td>Deutsch (Schweiz) <span style=\"background: LightGoldenRodYellow\">(Details : {urn:ietf:bcp:47 code 'de-CH' = 'German (Region=Schweiz))</span></td><td>true</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.16.756.5.30.1.123.100.1.1.1",
            "value" : "80756011110123400111"
          }
        ],
        "name" : [
          {
            "text" : "Emil Emmenegger",
            "family" : "Emmenegger",
            "given" : ["Emil"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "079 222 33 44",
            "use" : "home"
          },
          {
            "system" : "email",
            "value" : "emil.emmenegger@example.com"
          }
        ],
        "gender" : "male",
        "birthDate" : "1981-01-01",
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://fhir.ch/ig/ch-core/CodeSystem/ech-11-maritalstatus",
              "code" : "5",
              "display" : "unverheiratet"
            },
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
              "code" : "U",
              "display" : "unmarried"
            }
          ]
        },
        "communication" : [
          {
            "language" : {
              "coding" : [
                {
                  "system" : "urn:ietf:bcp:47",
                  "code" : "de-CH"
                }
              ],
              "text" : "Deutsch (Schweiz)"
            },
            "preferred" : true
          }
        ],
        "generalPractitioner" : [
          {
            "reference" : "urn:uuid:d55425b0-406c-4dde-9ea8-6b0dffbd75ab",
            "display" : "Dr. med. Theo Tillmann"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:3318e76e-570d-48d5-b599-1110cf92ee86",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "f36365f1-4b7e-4458-99af-d950b8608ea7",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-observation-results-laboratory"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_f36365f1-4b7e-4458-99af-d950b8608ea7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation f36365f1-4b7e-4458-99af-d950b8608ea7</b></p><a name=\"f36365f1-4b7e-4458-99af-d950b8608ea7\"> </a><a name=\"hcf36365f1-4b7e-4458-99af-d950b8608ea7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-observation-results-laboratory.html\">CH LAB-Report Observation Results: Laboratory Report</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://snomed.info/sct 394596001}\">Chemical pathology (qualifier value)</span>, <span title=\"Codes:{http://loinc.org 18719-5}\">Chemistry studies (set)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 50584-2}\">Lactose challenge (hydrogen breath test) panel (Exhl gas)</span></p><p><b>subject</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff\">Emil Emmenegger</a></p><p><b>effective</b>: 2024-03-13 01:43:30+0000</p><p><b>performer</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Katrin Klauser</a></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 252233000}\">Hydrogen breath test (procedure)</span></p><p><b>specimen</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-85c72094-e3e8-4d3a-8a18-c2812310fd10\">Gas-3-breath-test</a></p><p><b>device</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-b2b5e406-02d0-46de-85bb-561fe37040bb\">Breath-Test System</a></p><p><b>hasMember</b>: </p><ul><li><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-f57378f6-738b-4f2c-8ab7-03341eac9518\">Observation Lactose challenge panel-hydrogen - Exhaled gas</a></li><li><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-57c1026b-6e7d-4172-9c74-cdb87dfeedb9\">Observation Lactose challenge (methane breath test) panel - Exhaled gas</a></li></ul></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "laboratory"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "394596001",
                "display" : "Chemical pathology (qualifier value)"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "18719-5",
                "display" : "Chemistry studies (set)"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "50584-2",
              "display" : "Lactose challenge (hydrogen breath test) panel - Exhaled gas"
            }
          ],
          "text" : "Lactose challenge (hydrogen breath test) panel (Exhl gas)"
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "effectiveDateTime" : "2024-03-13T01:43:30Z",
        "performer" : [
          {
            "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
            "display" : "Katrin Klauser"
          }
        ],
        "method" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "252233000",
              "display" : "Hydrogen breath test (procedure)"
            }
          ]
        },
        "specimen" : {
          "reference" : "urn:uuid:85c72094-e3e8-4d3a-8a18-c2812310fd10",
          "display" : "Gas-3-breath-test"
        },
        "device" : {
          "reference" : "urn:uuid:b2b5e406-02d0-46de-85bb-561fe37040bb",
          "display" : "Breath-Test System"
        },
        "hasMember" : [
          {
            "reference" : "urn:uuid:f57378f6-738b-4f2c-8ab7-03341eac9518"
          },
          {
            "reference" : "urn:uuid:57c1026b-6e7d-4172-9c74-cdb87dfeedb9"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:f57378f6-738b-4f2c-8ab7-03341eac9518",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "f57378f6-738b-4f2c-8ab7-03341eac9518",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-observation-results-laboratory"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_f57378f6-738b-4f2c-8ab7-03341eac9518\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation f57378f6-738b-4f2c-8ab7-03341eac9518</b></p><a name=\"f57378f6-738b-4f2c-8ab7-03341eac9518\"> </a><a name=\"hcf57378f6-738b-4f2c-8ab7-03341eac9518\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-observation-results-laboratory.html\">CH LAB-Report Observation Results: Laboratory Report</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://snomed.info/sct 394596001}\">Chemical pathology (qualifier value)</span>, <span title=\"Codes:{http://loinc.org 18719-5}\">Chemistry studies (set)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 105751-2}\">Lactose challenge (hydrogen breath test) panel (Exhl gas)</span></p><p><b>subject</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff\">Emil Emmenegger</a></p><p><b>effective</b>: 2024-03-13 01:43:30+0000</p><p><b>performer</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Katrin Klauser</a></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 252233000}\">Hydrogen breath test (procedure)</span></p><p><b>specimen</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-85c72094-e3e8-4d3a-8a18-c2812310fd10\">Gas-3-breath-test</a></p><p><b>device</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-b2b5e406-02d0-46de-85bb-561fe37040bb\">Breath-Test System</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33490-4}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --pre dose lactose PO</span></p><p><b>value</b>: 5 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33491-2}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --30 minutes post dose lactose PO</span></p><p><b>value</b>: 9 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33492-0}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --1 hour post dose lactose PO</span></p><p><b>value</b>: 27 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33493-8}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --1.5 hours post dose lactose PO</span></p><p><b>value</b>: 47 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33494-6}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --2 hours post dose lactose PO</span></p><p><b>value</b>: 76 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33495-3}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --2.5 hours post dose lactose PO</span></p><p><b>value</b>: 96 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33496-1}\">Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --3 hours post dose lactose PO</span></p><p><b>value</b>: 59 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 51197009}\">Stomach cramps (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 308698004}\">Flatulence symptom (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 422587007}\">Nausea (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 62315008}\">Diarrhea (finding)</span></p><p><b>value</b>: false</p></blockquote></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "laboratory"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "394596001",
                "display" : "Chemical pathology (qualifier value)"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "18719-5",
                "display" : "Chemistry studies (set)"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "105751-2",
              "display" : "Lactose challenge panel-hydrogen - Exhaled gas"
            }
          ],
          "text" : "Lactose challenge (hydrogen breath test) panel (Exhl gas)"
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "effectiveDateTime" : "2024-03-13T01:43:30Z",
        "performer" : [
          {
            "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
            "display" : "Katrin Klauser"
          }
        ],
        "method" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "252233000",
              "display" : "Hydrogen breath test (procedure)"
            }
          ]
        },
        "specimen" : {
          "reference" : "urn:uuid:85c72094-e3e8-4d3a-8a18-c2812310fd10",
          "display" : "Gas-3-breath-test"
        },
        "device" : {
          "reference" : "urn:uuid:b2b5e406-02d0-46de-85bb-561fe37040bb",
          "display" : "Breath-Test System"
        },
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33490-4",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --pre dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 5,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33491-2",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --30 minutes post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 9,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33492-0",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --1 hour post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 27,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33493-8",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --1.5 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 47,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33494-6",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --2 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 76,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33495-3",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --2.5 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 96,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33496-1",
                  "display" : "Hydrogen/Expired gas [Volume Fraction] in Exhaled gas --3 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 59,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "51197009",
                  "display" : "Stomach cramps (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "308698004",
                  "display" : "Flatulence symptom (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "422587007",
                  "display" : "Nausea (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "62315008",
                  "display" : "Diarrhea (finding)"
                }
              ]
            },
            "valueBoolean" : false
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:57c1026b-6e7d-4172-9c74-cdb87dfeedb9",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "57c1026b-6e7d-4172-9c74-cdb87dfeedb9",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-observation-results-laboratory"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_57c1026b-6e7d-4172-9c74-cdb87dfeedb9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 57c1026b-6e7d-4172-9c74-cdb87dfeedb9</b></p><a name=\"57c1026b-6e7d-4172-9c74-cdb87dfeedb9\"> </a><a name=\"hc57c1026b-6e7d-4172-9c74-cdb87dfeedb9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-observation-results-laboratory.html\">CH LAB-Report Observation Results: Laboratory Report</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://snomed.info/sct 394596001}\">Chemical pathology (qualifier value)</span>, <span title=\"Codes:{http://loinc.org 18719-5}\">Chemistry studies (set)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 105750-4}\">Lactose challenge (methane breath test) panel (Exhl gas)</span></p><p><b>subject</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff\">Emil Emmenegger</a></p><p><b>effective</b>: 2024-03-13 01:43:30+0000</p><p><b>performer</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Katrin Klauser</a></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 252233000}\">Hydrogen breath test (procedure)</span></p><p><b>specimen</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-85c72094-e3e8-4d3a-8a18-c2812310fd10\">Gas-3-breath-test</a></p><p><b>device</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-b2b5e406-02d0-46de-85bb-561fe37040bb\">Breath-Test System</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33497-9}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --pre dose lactose PO</span></p><p><b>value</b>: 3 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33498-7}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --30 minutes post dose lactose PO</span></p><p><b>value</b>: 6 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33499-5}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --1 hour post dose lactose PO</span></p><p><b>value</b>: 14 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33500-0}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --1.5 hours post dose lactose PO</span></p><p><b>value</b>: 13 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33480-5}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --2 hours post dose lactose PO</span></p><p><b>value</b>: 18 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33481-3}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --2.5 hours post dose lactose PO</span></p><p><b>value</b>: 18 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33482-1}\">Methane/Expired gas [Volume Fraction] in Exhaled gas --3 hours post dose lactose PO</span></p><p><b>value</b>: 13 [ppm]<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code[ppm] = '[ppm]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 51197009}\">Stomach cramps (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 308698004}\">Flatulence symptom (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 422587007}\">Nausea (finding)</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 62315008}\">Diarrhea (finding)</span></p><p><b>value</b>: false</p></blockquote></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "laboratory"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "394596001",
                "display" : "Chemical pathology (qualifier value)"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "18719-5",
                "display" : "Chemistry studies (set)"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "105750-4",
              "display" : "Lactose challenge (methane breath test) panel - Exhaled gas"
            }
          ],
          "text" : "Lactose challenge (methane breath test) panel (Exhl gas)"
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "effectiveDateTime" : "2024-03-13T01:43:30Z",
        "performer" : [
          {
            "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
            "display" : "Katrin Klauser"
          }
        ],
        "method" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "252233000",
              "display" : "Hydrogen breath test (procedure)"
            }
          ]
        },
        "specimen" : {
          "reference" : "urn:uuid:85c72094-e3e8-4d3a-8a18-c2812310fd10",
          "display" : "Gas-3-breath-test"
        },
        "device" : {
          "reference" : "urn:uuid:b2b5e406-02d0-46de-85bb-561fe37040bb",
          "display" : "Breath-Test System"
        },
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33497-9",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --pre dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 3,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33498-7",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --30 minutes post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 6,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33499-5",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --1 hour post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 14,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33500-0",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --1.5 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 13,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33480-5",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --2 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 18,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33481-3",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --2.5 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 18,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "33482-1",
                  "display" : "Methane/Expired gas [Volume Fraction] in Exhaled gas --3 hours post dose lactose PO"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 13,
              "unit" : "[ppm]",
              "system" : "http://unitsofmeasure.org",
              "code" : "[ppm]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "51197009",
                  "display" : "Stomach cramps (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "308698004",
                  "display" : "Flatulence symptom (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "422587007",
                  "display" : "Nausea (finding)"
                }
              ]
            },
            "valueBoolean" : false
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "62315008",
                  "display" : "Diarrhea (finding)"
                }
              ]
            },
            "valueBoolean" : false
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:85c72094-e3e8-4d3a-8a18-c2812310fd10",
      "resource" : {
        "resourceType" : "Specimen",
        "id" : "85c72094-e3e8-4d3a-8a18-c2812310fd10",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-specimen"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_85c72094-e3e8-4d3a-8a18-c2812310fd10\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen 85c72094-e3e8-4d3a-8a18-c2812310fd10</b></p><a name=\"85c72094-e3e8-4d3a-8a18-c2812310fd10\"> </a><a name=\"hc85c72094-e3e8-4d3a-8a18-c2812310fd10\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-specimen.html\">CH LAB-Report Specimen</a></p></div><p><b>identifier</b>: 48736-12345-99887</p><p><b>accessionIdentifier</b>: 4e88a-12345-dd888</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0487 EXG}\">Gas, exhaled (=breath)</span></p><p><b>subject</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff\">Emil Emmenegger</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collector</b></td><td><b>Collected[x]</b></td><td><b>BodySite</b></td><td><b>FastingStatus[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-d55425b0-406c-4dde-9ea8-6b0dffbd75ab\">Practitioner Theo Tillmann (official)</a></td><td>2024-03-13 01:43:30+0000</td><td><span title=\"Codes:{http://snomed.info/sct 49852007}\">Structure of median cubital vein (body structure)</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0916 F}\">Patient was fasting prior to the procedure.</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 713791004}\">Breath specimen container (physical object)</span></td></tr></table></div>"
        },
        "identifier" : [
          {
            "value" : "48736-12345-99887"
          }
        ],
        "accessionIdentifier" : {
          "value" : "4e88a-12345-dd888"
        },
        "status" : "available",
        "type" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0487",
              "code" : "EXG",
              "display" : "Gas, exhaled (=breath)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:9b3d24a2-9d79-4d3a-b3e2-7dd8fdde5eff",
          "display" : "Emil Emmenegger"
        },
        "collection" : {
          "collector" : {
            "reference" : "urn:uuid:d55425b0-406c-4dde-9ea8-6b0dffbd75ab"
          },
          "collectedDateTime" : "2024-03-13T01:43:30Z",
          "bodySite" : {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "49852007",
                "display" : "Structure of median cubital vein (body structure)"
              }
            ]
          },
          "fastingStatusCodeableConcept" : {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0916",
                "code" : "F",
                "display" : "Patient was fasting prior to the procedure."
              }
            ]
          }
        },
        "container" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "713791004",
                  "display" : "Breath specimen container (physical object)"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:3771d254-cee2-498e-a448-c5660ccd583d",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "3771d254-cee2-498e-a448-c5660ccd583d",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_3771d254-cee2-498e-a448-c5660ccd583d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 3771d254-cee2-498e-a448-c5660ccd583d</b></p><a name=\"3771d254-cee2-498e-a448-c5660ccd583d\"> </a><a name=\"hc3771d254-cee2-498e-a448-c5660ccd583d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-practitionerrole.html\">CH LAB-Report PractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-d55425b0-406c-4dde-9ea8-6b0dffbd75ab\">Dr. med. Theo Tillmann</a></p><p><b>organization</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-8816b3f6-376f-4e2d-b83f-53e69e2b7ffb\">Organization Gruppenpraxis Messen</a></p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.16.840.1.113883.2.9.6.2.7 2211}\">Generalist Medical Practitioners</span></p></div>"
        },
        "practitioner" : {
          "reference" : "urn:uuid:d55425b0-406c-4dde-9ea8-6b0dffbd75ab",
          "display" : "Dr. med. Theo Tillmann"
        },
        "organization" : {
          "reference" : "urn:uuid:8816b3f6-376f-4e2d-b83f-53e69e2b7ffb"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "urn:oid:2.16.840.1.113883.2.9.6.2.7",
                "code" : "2211",
                "display" : "Generalist Medical Practitioners"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:d55425b0-406c-4dde-9ea8-6b0dffbd75ab",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "d55425b0-406c-4dde-9ea8-6b0dffbd75ab",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_d55425b0-406c-4dde-9ea8-6b0dffbd75ab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner d55425b0-406c-4dde-9ea8-6b0dffbd75ab</b></p><a name=\"d55425b0-406c-4dde-9ea8-6b0dffbd75ab\"> </a><a name=\"hcd55425b0-406c-4dde-9ea8-6b0dffbd75ab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-practitioner.html\">CH LAB-Report Practitioner</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000050441, <code>urn:oid:2.16.756.5.30.1.123.100.2.1.1</code>/Y274589</p><p><b>name</b>: Theo Tillmann (Official)</p><p><b>telecom</b>: ph: 033 444 22 11(Work), <a href=\"mailto:theo.tillmann@gruppenpraxis.ch\">theo.tillmann@gruppenpraxis.ch</a></p><p><b>address</b>: Doktorgasse 2 Messen 3254 CH </p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0360 MD}\">Doctor of Medicine</span></td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601000050441"
          },
          {
            "system" : "urn:oid:2.16.756.5.30.1.123.100.2.1.1",
            "value" : "Y274589"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Tillmann",
            "given" : ["Theo"],
            "prefix" : ["Dr. med."],
            "_prefix" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
                    "valueCode" : "AC"
                  }
                ]
              }
            ]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "033 444 22 11",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "theo.tillmann@gruppenpraxis.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Doktorgasse 2"],
            "city" : "Messen",
            "postalCode" : "3254",
            "country" : "CH"
          }
        ],
        "qualification" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0360",
                  "code" : "MD",
                  "display" : "Doctor of Medicine"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:8816b3f6-376f-4e2d-b83f-53e69e2b7ffb",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "8816b3f6-376f-4e2d-b83f-53e69e2b7ffb",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_8816b3f6-376f-4e2d-b83f-53e69e2b7ffb\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 8816b3f6-376f-4e2d-b83f-53e69e2b7ffb</b></p><a name=\"8816b3f6-376f-4e2d-b83f-53e69e2b7ffb\"> </a><a name=\"hc8816b3f6-376f-4e2d-b83f-53e69e2b7ffb\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601054050718</p><p><b>name</b>: Gruppenpraxis Messen</p><p><b>telecom</b>: <a href=\"tel:+41555545566\">+41555545566</a>, <a href=\"mailto:info@gruppenpraxis.ch\">info@gruppenpraxis.ch</a>, <a href=\"http://www.gruppenpraxis.ch\">http://www.gruppenpraxis.ch</a></p><p><b>address</b>: Doktorgasse 2 Messen 3254 CH </p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601054050718"
          }
        ],
        "name" : "Gruppenpraxis Messen",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+41555545566",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "info@gruppenpraxis.ch",
            "use" : "work"
          },
          {
            "system" : "url",
            "value" : "http://www.gruppenpraxis.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Doktorgasse 2"],
            "city" : "Messen",
            "postalCode" : "3254",
            "country" : "CH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "49f8e829-1242-47a9-b958-32be38d09e5b",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_49f8e829-1242-47a9-b958-32be38d09e5b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 49f8e829-1242-47a9-b958-32be38d09e5b</b></p><a name=\"49f8e829-1242-47a9-b958-32be38d09e5b\"> </a><a name=\"hc49f8e829-1242-47a9-b958-32be38d09e5b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-practitioner.html\">CH LAB-Report Practitioner</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000050717, <code>urn:oid:2.16.756.5.30.1.123.100.2.1.1</code>/L248519</p><p><b>name</b>: Katrin Klauser (Official)</p><p><b>telecom</b>: ph: 033 444 55 66(Work), <a href=\"mailto:katrin.klauser@labor-schildknecht.ch\">katrin.klauser@labor-schildknecht.ch</a></p><p><b>address</b>: Laborstrasse 23 Olten 4600 CH </p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0360 MD}\">Doctor of Medicine</span></td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601000050717"
          },
          {
            "system" : "urn:oid:2.16.756.5.30.1.123.100.2.1.1",
            "value" : "L248519"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Klauser",
            "given" : ["Katrin"],
            "prefix" : ["Dr. med."],
            "_prefix" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
                    "valueCode" : "AC"
                  }
                ]
              }
            ]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "033 444 55 66",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "katrin.klauser@labor-schildknecht.ch",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "line" : ["Laborstrasse 23"],
            "city" : "Olten",
            "postalCode" : "4600",
            "country" : "CH"
          }
        ],
        "qualification" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0360",
                  "code" : "MD",
                  "display" : "Doctor of Medicine"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:525e02f3-cac3-4cdc-a497-ce6e441b8a80",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "525e02f3-cac3-4cdc-a497-ce6e441b8a80",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-lab-report/StructureDefinition/ch-lab-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_525e02f3-cac3-4cdc-a497-ce6e441b8a80\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 525e02f3-cac3-4cdc-a497-ce6e441b8a80</b></p><a name=\"525e02f3-cac3-4cdc-a497-ce6e441b8a80\"> </a><a name=\"hc525e02f3-cac3-4cdc-a497-ce6e441b8a80\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ch-lab-practitionerrole.html\">CH LAB-Report PractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-49f8e829-1242-47a9-b958-32be38d09e5b\">Practitioner Katrin Klauser (official)</a></p><p><b>organization</b>: <a href=\"Bundle-LabResultReport-3-breath-test.html#urn-uuid-8030393e-d1c2-409f-841b-0c3af4e68494\">Organization Labor Schildknecht</a></p><p><b>code</b>: <span title=\"Codes:{urn:oid:2.16.840.1.113883.2.9.6.2.7 3212}\">Medical and Pathology Laboratory Technicians</span></p></div>"
        },
        "practitioner" : {
          "reference" : "urn:uuid:49f8e829-1242-47a9-b958-32be38d09e5b"
        },
        "organization" : {
          "reference" : "urn:uuid:8030393e-d1c2-409f-841b-0c3af4e68494"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "urn:oid:2.16.840.1.113883.2.9.6.2.7",
                "code" : "3212",
                "display" : "Medical and Pathology Laboratory Technicians"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:8030393e-d1c2-409f-841b-0c3af4e68494",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "8030393e-d1c2-409f-841b-0c3af4e68494",
        "meta" : {
          "profile" : [
            "http://fhir.ch/ig/ch-core/StructureDefinition/ch-core-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_8030393e-d1c2-409f-841b-0c3af4e68494\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 8030393e-d1c2-409f-841b-0c3af4e68494</b></p><a name=\"8030393e-d1c2-409f-841b-0c3af4e68494\"> </a><a name=\"hc8030393e-d1c2-409f-841b-0c3af4e68494\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://fhir.ch/ig/ch-core/6.0.0/StructureDefinition-ch-core-organization.html\">CH Core Organization</a></p></div><p><b>identifier</b>: <a href=\"https://www.gs1.org/standards/id-keys/gln\" title=\"Global Location Number\">GLN</a>/7601000234407</p><p><b>name</b>: Labor Schildknecht</p><p><b>telecom</b>: <a href=\"tel:+41223345566\">+41223345566</a></p><p><b>address</b>: Laborstrasse 23 Olten 4600 CH (work)</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Telecom</b></td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Dr. Katrin Klauser(Official)</td><td><a href=\"mailto:katrin.klauser@labor-schildknecht.ch\">katrin.klauser@labor-schildknecht.ch</a></td><td>Laborstrasse 23 4. Stock Olten 4600 CH </td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:2.51.1.3",
            "value" : "7601000234407"
          }
        ],
        "name" : "Labor Schildknecht",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+41223345566",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "use" : "work",
            "line" : ["Laborstrasse 23"],
            "city" : "Olten",
            "postalCode" : "4600",
            "country" : "CH"
          }
        ],
        "contact" : [
          {
            "name" : {
              "use" : "official",
              "text" : "Dr. Katrin Klauser",
              "family" : "Klauser",
              "given" : ["Katrin"],
              "prefix" : ["Dr. med."]
            },
            "telecom" : [
              {
                "system" : "email",
                "value" : "katrin.klauser@labor-schildknecht.ch",
                "use" : "work"
              }
            ],
            "address" : {
              "line" : ["Laborstrasse 23", "4. Stock"],
              "city" : "Olten",
              "postalCode" : "4600",
              "country" : "CH"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:b2b5e406-02d0-46de-85bb-561fe37040bb",
      "resource" : {
        "resourceType" : "Device",
        "id" : "b2b5e406-02d0-46de-85bb-561fe37040bb",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_b2b5e406-02d0-46de-85bb-561fe37040bb\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device b2b5e406-02d0-46de-85bb-561fe37040bb</b></p><a name=\"b2b5e406-02d0-46de-85bb-561fe37040bb\"> </a><a name=\"hcb2b5e406-02d0-46de-85bb-561fe37040bb\"> </a><p><b>identifier</b>: <code>http://example.org/labor-schildknecht.ch/devices/id</code>/345888</p><p><b>status</b>: Active</p><p><b>manufacturer</b>: QuinTron Instrument Company</p><p><b>lotNumber</b>: lot.5432</p><p><b>serialNumber</b>: 889977</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>QuinTron BreathTracker SC Analyzer</td><td>UDI Label name</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "http://example.org/labor-schildknecht.ch/devices/id",
            "value" : "345888"
          }
        ],
        "status" : "active",
        "manufacturer" : "QuinTron Instrument Company",
        "lotNumber" : "lot.5432",
        "serialNumber" : "889977",
        "deviceName" : [
          {
            "name" : "QuinTron BreathTracker SC Analyzer",
            "type" : "udi-label-name"
          }
        ]
      }
    }
  ]
}

```
