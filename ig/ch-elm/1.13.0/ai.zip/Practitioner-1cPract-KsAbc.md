# 1Pract - Giacometti - CH ELM (R4) v1.13.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1Pract - Giacometti**

## Example Practitioner: 1Pract - Giacometti

**name**: null Giacometti 

**address**: Bern 3000 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "1cPract-KsAbc",
  "name" : [
    {
      "family" : "Giacometti",
      "_given" : [
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
              "valueCode" : "unknown"
            }
          ]
        }
      ]
    }
  ],
  "address" : [
    {
      "city" : "Bern",
      "postalCode" : "3000"
    }
  ]
}

```
