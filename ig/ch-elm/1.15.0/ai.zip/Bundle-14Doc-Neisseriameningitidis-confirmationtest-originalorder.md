# 14Doc - Neisseria meningitidis - confirmation test with original order - CH ELM (R4) v1.15.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **14Doc - Neisseria meningitidis - confirmation test with original order**

## Example Bundle: 14Doc - Neisseria meningitidis - confirmation test with original order



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "14Doc-Neisseriameningitidis-confirmationtest-originalorder",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:74804773-3ab0-410e-9c94-3f888e3a5bee"
  },
  "type" : "document",
  "timestamp" : "2024-08-04T11:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:213b89cc-ce8b-471f-810b-726d835a9f23",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "213b89cc-ce8b-471f-810b-726d835a9f23",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:74804773-3ab0-410e-9c94-3f888e3a5bee"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "date" : "2024-08-04T11:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:35c0dfae-78b6-46d6-820d-c0db6e5a4aff"
      }],
      "title" : "Laborbericht vom 4.8.2024",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:6564d4ce-5ab4-433c-9228-1ec3caf159e2"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "49e08f02-546e-4121-8482-1c21763403e6",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:35c0dfae-78b6-46d6-820d-c0db6e5a4aff",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "35c0dfae-78b6-46d6-820d-c0db6e5a4aff",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002131193"
      }],
      "name" : "Nationales Zentrum für Meningokokken"
    }
  },
  {
    "fullUrl" : "urn:uuid:6564d4ce-5ab4-433c-9228-1ec3caf159e2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "6564d4ce-5ab4-433c-9228-1ec3caf159e2",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "86581-6"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "effectiveDateTime" : "2024-08-04T09:15:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:35c0dfae-78b6-46d6-820d-c0db6e5a4aff"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:ab1fd192-95af-4ac5-9fa0-c13927e22c0f"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:163f8ba2-9480-4206-8fba-0503825dff4c",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "163f8ba2-9480-4206-8fba-0503825dff4c",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000234438"
      }],
      "name" : [{
        "family" : "Giacometti",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 44 55"
      },
      {
        "system" : "email",
        "value" : "m.giacometti@ks-abc.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:3fa71ff0-9728-4731-8f2f-7d81437ae4b0",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "3fa71ff0-9728-4731-8f2f-7d81437ae4b0",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : [{
        "family" : "Gasser",
        "given" : ["Andrea"]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "andrea.gasser@sanlab.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:7c9d7645-05b2-43f4-909c-825e455ff29a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "7c9d7645-05b2-43f4-909c-825e455ff29a",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "SanLab",
      "address" : [{
        "line" : ["rue de l'église 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de l'église"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Fribourg",
        "postalCode" : "1700"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0d7b9484-0756-4114-a4e4-9506a05b66f5",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "0d7b9484-0756-4114-a4e4-9506a05b66f5",
      "practitioner" : {
        "reference" : "urn:uuid:163f8ba2-9480-4206-8fba-0503825dff4c"
      },
      "organization" : {
        "reference" : "urn:uuid:efc89964-d13b-4f29-8a4d-4d8956a25cf6"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:efc89964-d13b-4f29-8a4d-4d8956a25cf6",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "efc89964-d13b-4f29-8a4d-4d8956a25cf6",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "Kantonsspital ABC",
      "address" : [{
        "line" : ["Aortastrasse 22"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Aortastrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "22"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
            "valueString" : "Postfach 18"
          }]
        }],
        "city" : "Bern",
        "postalCode" : "3000"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:51a0f065-10be-4847-b07c-4b583070e64b",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "51a0f065-10be-4847-b07c-4b583070e64b",
      "practitioner" : {
        "reference" : "urn:uuid:3fa71ff0-9728-4731-8f2f-7d81437ae4b0"
      },
      "organization" : {
        "reference" : "urn:uuid:7c9d7645-05b2-43f4-909c-825e455ff29a"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:ab1fd192-95af-4ac5-9fa0-c13927e22c0f",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "ab1fd192-95af-4ac5-9fa0-c13927e22c0f",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "collection" : {
        "collectedDateTime" : "2024-08-02T09:15:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:fb4cda61-696a-48ea-bb53-2c939d2afa78",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "fb4cda61-696a-48ea-bb53-2c939d2afa78",
      "identifier" : [{
        "value" : "50002610"
      }],
      "status" : "completed",
      "intent" : "order",
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "requester" : {
        "reference" : "urn:uuid:0d7b9484-0756-4114-a4e4-9506a05b66f5"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:6dc3d310-833f-469b-baf7-7824cb5a4fd8",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "6dc3d310-833f-469b-baf7-7824cb5a4fd8",
      "identifier" : [{
        "value" : "98236973414"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:fb4cda61-696a-48ea-bb53-2c939d2afa78"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "86581-6"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "requester" : {
        "reference" : "urn:uuid:51a0f065-10be-4847-b07c-4b583070e64b"
      },
      "specimen" : [{
        "reference" : "urn:uuid:ab1fd192-95af-4ac5-9fa0-c13927e22c0f"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:4bfc6d09-f3ec-4d42-8e59-f5433de74510",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "4bfc6d09-f3ec-4d42-8e59-f5433de74510",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:213b89cc-ce8b-471f-810b-726d835a9f23"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:74804773-3ab0-410e-9c94-3f888e3a5bee"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:6dc3d310-833f-469b-baf7-7824cb5a4fd8"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:49e08f02-546e-4121-8482-1c21763403e6"
      },
      "performer" : [{
        "reference" : "urn:uuid:35c0dfae-78b6-46d6-820d-c0db6e5a4aff"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:ab1fd192-95af-4ac5-9fa0-c13927e22c0f"
      }],
      "result" : [{
        "reference" : "urn:uuid:6564d4ce-5ab4-433c-9228-1ec3caf159e2"
      }]
    }
  }]
}

```
