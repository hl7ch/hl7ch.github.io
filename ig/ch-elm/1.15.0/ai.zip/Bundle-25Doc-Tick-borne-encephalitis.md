# 25Doc - Tick-borne encephalitis - CH ELM (R4) v1.15.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **25Doc - Tick-borne encephalitis**

## Example Bundle: 25Doc - Tick-borne encephalitis



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "25Doc-Tick-borne-encephalitis",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
  },
  "type" : "document",
  "timestamp" : "2024-08-14T11:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:4149851f-c4e0-4896-978f-9480934a512a",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "4149851f-c4e0-4896-978f-9480934a512a",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063"
      },
      "date" : "2024-08-14T11:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:47f5a4be-b423-45b9-b7f0-43aef5fa2c03"
      }],
      "title" : "Laborbericht vom 14.8.2024",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:227f539d-44fb-43f2-8790-dbe5865e5bc3"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "c2e827fb-29ad-4c0e-856e-010351e14063",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7562295883070"
      }],
      "name" : [{
        "family" : "M",
        "given" : ["D"]
      }],
      "gender" : "male",
      "birthDate" : "1960-08-22",
      "address" : [{
        "use" : "home",
        "city" : "Bern",
        "state" : "BE",
        "postalCode" : "3000",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:47f5a4be-b423-45b9-b7f0-43aef5fa2c03",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "47f5a4be-b423-45b9-b7f0-43aef5fa2c03",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:227f539d-44fb-43f2-8790-dbe5865e5bc3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "227f539d-44fb-43f2-8790-dbe5865e5bc3",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "31828-7"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063"
      },
      "effectiveDateTime" : "2024-08-12T09:15:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:47f5a4be-b423-45b9-b7f0-43aef5fa2c03"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "91508008"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:d384caf3-058f-417f-8ae7-1f54fe136e92"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:fba26caa-cd7d-4484-b61f-3b35fbc86b4f",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "fba26caa-cd7d-4484-b61f-3b35fbc86b4f",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000234438"
      }],
      "name" : [{
        "family" : "Giacometti",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 44 55"
      },
      {
        "system" : "email",
        "value" : "m.giacometti@ks-abc.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:58d03bb8-3159-4af4-bbd0-677d1a47cbef",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "58d03bb8-3159-4af4-bbd0-677d1a47cbef",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "Kantonsspital ABC",
      "address" : [{
        "line" : ["Aortastrasse 22"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Aortastrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "22"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
            "valueString" : "Postfach 18"
          }]
        }],
        "city" : "Bern",
        "postalCode" : "3000"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:6dc65e52-f36c-4808-bb7d-5d79d1e38044",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "6dc65e52-f36c-4808-bb7d-5d79d1e38044",
      "practitioner" : {
        "reference" : "urn:uuid:fba26caa-cd7d-4484-b61f-3b35fbc86b4f"
      },
      "organization" : {
        "reference" : "urn:uuid:58d03bb8-3159-4af4-bbd0-677d1a47cbef"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:d384caf3-058f-417f-8ae7-1f54fe136e92",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "d384caf3-058f-417f-8ae7-1f54fe136e92",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063"
      },
      "collection" : {
        "collectedDateTime" : "2024-08-10T09:15:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:004324bc-a50d-41d6-a9a7-53eaf8ce3664",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "004324bc-a50d-41d6-a9a7-53eaf8ce3664",
      "identifier" : [{
        "value" : "50002755"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "31828-7"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063"
      },
      "requester" : {
        "reference" : "urn:uuid:6dc65e52-f36c-4808-bb7d-5d79d1e38044"
      },
      "specimen" : [{
        "reference" : "urn:uuid:d384caf3-058f-417f-8ae7-1f54fe136e92"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0b8c928d-75fa-4197-a3e4-dee35ad58368",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "0b8c928d-75fa-4197-a3e4-dee35ad58368",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:4149851f-c4e0-4896-978f-9480934a512a"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:004324bc-a50d-41d6-a9a7-53eaf8ce3664"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:c2e827fb-29ad-4c0e-856e-010351e14063"
      },
      "performer" : [{
        "reference" : "urn:uuid:47f5a4be-b423-45b9-b7f0-43aef5fa2c03"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:d384caf3-058f-417f-8ae7-1f54fe136e92"
      }],
      "result" : [{
        "reference" : "urn:uuid:227f539d-44fb-43f2-8790-dbe5865e5bc3"
      }]
    }
  }]
}

```
