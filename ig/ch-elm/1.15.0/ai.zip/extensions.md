# Extensions - CH ELM (R4) v1.15.0

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

* [CH ELM Extension: Department](StructureDefinition-ch-elm-ext-department.md) 
This CH ELM extension enables the representation of a department (name) of an organization directly in the resource Organization itself. 

* [CH ELM Extension: HIV code](StructureDefinition-ch-elm-ext-hiv-code.md) 
This CH ELM extension enables to provide the HIV Code. 

* [CH ELM Extension: VCT code](StructureDefinition-ch-elm-ext-vct-code.md) 
This CH ELM extension enables to provide the VCT Code. Retired. Ues identifier instead (see Guidance) 

* [Status of the processing of the document](StructureDefinition-ch-ext-elm-status.md) 
Extension to define the status of the processing of the document 

