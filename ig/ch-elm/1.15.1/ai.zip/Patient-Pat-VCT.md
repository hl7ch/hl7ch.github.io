# Pat - VCT with localpid - CH ELM (R4) v1.15.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pat - VCT with localpid**

## Example Patient: Pat - VCT with localpid



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "Pat-VCT",
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "MR"
      }]
    },
    "system" : "urn:oid:2.999.1.2.3.4",
    "value" : "kste12345"
  }],
  "name" : [{
    "_family" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
        "valueCode" : "unknown"
      }]
    },
    "_given" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
        "valueCode" : "unknown"
      }]
    }]
  }],
  "gender" : "male",
  "birthDate" : "1966-08-22",
  "address" : [{
    "use" : "home",
    "city" : "Bern",
    "state" : "BE",
    "postalCode" : "3000",
    "country" : "CH",
    "_country" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
        "valueCoding" : {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      }]
    }
  }]
}

```
