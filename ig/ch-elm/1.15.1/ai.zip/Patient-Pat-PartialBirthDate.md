# Pat - Antoine Dupont (partial birthdate) - CH ELM (R4) v1.15.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pat - Antoine Dupont (partial birthdate)**

## Example Patient: Pat - Antoine Dupont (partial birthdate)



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "Pat-PartialBirthDate",
  "identifier" : [{
    "system" : "urn:oid:2.16.756.5.32",
    "value" : "7561234567866"
  }],
  "name" : [{
    "family" : "Dupont",
    "given" : ["Antoine"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+41 76 222 55 22"
  }],
  "gender" : "female",
  "birthDate" : "1981",
  "address" : [{
    "use" : "home",
    "line" : ["Rue de la république 10"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Rue de la république"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "10"
      }]
    }],
    "city" : "Carouge",
    "state" : "GE",
    "postalCode" : "1227",
    "country" : "CH",
    "_country" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
        "valueCoding" : {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      }]
    }
  }]
}

```
