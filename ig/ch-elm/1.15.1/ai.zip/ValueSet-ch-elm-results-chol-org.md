# CH ELM Results Chol Org - CH ELM (R4) v1.15.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Chol Org**

## ValueSet: CH ELM Results Chol Org 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-chol-org | *Version*:1.15.1 |
| Active as of 2026-08-14 | *Computable Name*:ChElmResultsCholOrg |
| **Copyright/Legal**: CC0-1.0 | |

 
The "CH ELM Results Chol Org" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the "CH ELM Results Chol Org" group should refer to the provided codes to accurately and uniformly capture and report organism-related information. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-results-chol-org",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-chol-org",
  "version" : "1.15.1",
  "name" : "ChElmResultsCholOrg",
  "title" : "CH ELM Results Chol Org",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-14T07:28:03+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "The \"CH ELM Results Chol Org\" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the \"CH ELM Results Chol Org\" group should refer to the provided codes to accurately and uniformly capture and report organism-related information.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "302576007",
        "display" : "Vibrio cholerae O1 classical Ogawa (organism)"
      },
      {
        "code" : "75953000",
        "display" : "Vibrio cholerae (organism)"
      },
      {
        "code" : "125048009",
        "display" : "Vibrio cholerae serogroup O139 (organism)"
      },
      {
        "code" : "62987004",
        "display" : "Vibrio cholerae, O1 (organism)"
      },
      {
        "code" : "302575006",
        "display" : "Vibrio cholerae O1 classical Inaba (organism)"
      },
      {
        "code" : "302572009",
        "display" : "Vibrio cholerae O1 El Tor Inaba (organism)"
      },
      {
        "code" : "302573004",
        "display" : "Vibrio cholerae O1 El Tor Ogawa (organism)"
      },
      {
        "code" : "415819003",
        "display" : "Vibrio cholerae, non-O1/non-O139 (organism)"
      },
      {
        "code" : "302577003",
        "display" : "Vibrio cholerae O1 classical Hikojima (organism)"
      },
      {
        "code" : "76436009",
        "display" : "Vibrio cholerae, classical biotype (organism)"
      },
      {
        "code" : "302574005",
        "display" : "Vibrio cholerae O1 El Tor Hikojima (organism)"
      },
      {
        "code" : "58735003",
        "display" : "Vibrio cholerae, El Tor biotype (organism)"
      }]
    }]
  }
}

```
