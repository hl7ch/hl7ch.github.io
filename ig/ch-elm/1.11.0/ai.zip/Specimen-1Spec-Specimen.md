# 1Spec - Neisseria Gonorrhoeae - CH ELM (R4) v1.12.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1Spec - Neisseria Gonorrhoeae**

## Example Specimen: 1Spec - Neisseria Gonorrhoeae

**subject**: [D M Male, DoB: 1960-08-22 ( urn:oid:2.16.756.5.32#7562295883070)](Patient-Pat-001.md)

### Collections

| | |
| :--- | :--- |
| - | **Collected[x]** |
| * | 2023-07-01 |



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "1Spec-Specimen",
  "subject" : {
    "reference" : "Patient/Pat-001"
  },
  "collection" : {
    "collectedDateTime" : "2023-07-01"
  }
}

```
