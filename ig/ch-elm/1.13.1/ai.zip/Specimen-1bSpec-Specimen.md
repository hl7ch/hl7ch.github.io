# 1bSpec - Neisseria Gonorrhoeae - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1bSpec - Neisseria Gonorrhoeae**

## Example Specimen: 1bSpec - Neisseria Gonorrhoeae



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "1bSpec-Specimen",
  "subject" : {
    "reference" : "Patient/Pat-001"
  },
  "collection" : {
    "collectedDateTime" : "2023-07-10T14:10:00+02:00"
  }
}

```
