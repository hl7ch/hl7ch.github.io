# 1bSR - Order - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1bSR - Order**

## Example ServiceRequest: 1bSR - Order



## Resource Content

```json
{
  "resourceType" : "ServiceRequest",
  "id" : "1bSR-Order",
  "identifier" : [
    {
      "value" : "22000938108"
    }
  ],
  "status" : "completed",
  "intent" : "order",
  "code" : {
    "coding" : [
      {
        "system" : "http://loinc.org",
        "code" : "697-3",
        "display" : "Neisseria gonorrhoeae [Presence] in Urethra by Organism specific culture"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/Pat-001"
  },
  "requester" : {
    "reference" : "PractitionerRole/1PR-KsAbc"
  },
  "specimen" : [
    {
      "reference" : "Specimen/1bSpec-Specimen"
    }
  ]
}

```
