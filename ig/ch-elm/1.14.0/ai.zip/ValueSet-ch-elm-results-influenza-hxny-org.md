# CH ELM Results Influenza Hxny Org - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Influenza Hxny Org**

## ValueSet: CH ELM Results Influenza Hxny Org 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-influenza-hxny-org | *Version*:1.14.0 |
| Active as of 2026-05-26 | *Computable Name*:ChElmResultsInfluenzaHxnyOrg |
| **Copyright/Legal**: CC0-1.0 | |

 
The "CH ELM Results Influenza Hxny Org" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the "CH ELM Results Influenza Hxny Org" group should refer to the provided codes to accurately and uniformly capture and report organism-related information. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-results-influenza-hxny-org",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-influenza-hxny-org",
  "version" : "1.14.0",
  "name" : "ChElmResultsInfluenzaHxnyOrg",
  "title" : "CH ELM Results Influenza Hxny Org",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-26T14:50:18+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "The \"CH ELM Results Influenza Hxny Org\" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the \"CH ELM Results Influenza Hxny Org\" group should refer to the provided codes to accurately and uniformly capture and report organism-related information.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "446397006",
        "display" : "Influenza A virus subtype H2 (organism)"
      },
      {
        "code" : "446645007",
        "display" : "Influenza A virus subtype H3 (organism)"
      },
      {
        "code" : "1354812007",
        "display" : "Influenza A virus subtype H1N1v (organism)"
      },
      {
        "code" : "446649001",
        "display" : "Influenza A virus subtype H9 (organism)"
      },
      {
        "code" : "772827006",
        "display" : "Influenza A virus subtype H5N1 (organism)"
      },
      {
        "code" : "446647004",
        "display" : "Influenza A virus subtype H5 (organism)"
      },
      {
        "code" : "700349009",
        "display" : "Influenza A virus subtype H10 (organism)"
      },
      {
        "code" : "446648009",
        "display" : "Influenza A virus subtype H7 (organism)"
      }]
    }]
  }
}

```
