# 20Doc - Vibrio cholerae - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **20Doc - Vibrio cholerae**

## Example Bundle: 20Doc - Vibrio cholerae



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "20Doc-Vibrio-cholerae",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
  },
  "type" : "document",
  "timestamp" : "2024-08-14T11:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:5ce27e23-a0d6-46a9-a9eb-c40fb9a1818a",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "5ce27e23-a0d6-46a9-a9eb-c40fb9a1818a",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac"
      },
      "date" : "2024-08-14T11:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:0d4e1427-e05f-4db2-afda-c55eabaf6909"
      }],
      "title" : "Laborbericht vom 14.8.2024",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:7d7bcbb5-1e55-44ad-a9e5-c9bf33d6bd30"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "90f9c93c-4bea-46cb-bdbe-0bc08101fbac",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0d4e1427-e05f-4db2-afda-c55eabaf6909",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "0d4e1427-e05f-4db2-afda-c55eabaf6909",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:7d7bcbb5-1e55-44ad-a9e5-c9bf33d6bd30",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "7d7bcbb5-1e55-44ad-a9e5-c9bf33d6bd30",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "53942-9"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac"
      },
      "effectiveDateTime" : "2024-08-12T09:15:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:0d4e1427-e05f-4db2-afda-c55eabaf6909"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:b28199d0-7d4c-4af0-afc6-a4842e665d2c"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:1503c5eb-e2b7-4751-81ac-89b20a904884",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1503c5eb-e2b7-4751-81ac-89b20a904884",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000234438"
      }],
      "name" : [{
        "family" : "Giacometti",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 44 55"
      },
      {
        "system" : "email",
        "value" : "m.giacometti@ks-abc.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:409e7c49-ae05-44b7-a36b-aa2b7e9f5f7d",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "409e7c49-ae05-44b7-a36b-aa2b7e9f5f7d",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "Kantonsspital ABC",
      "address" : [{
        "line" : ["Aortastrasse 22"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Aortastrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "22"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
            "valueString" : "Postfach 18"
          }]
        }],
        "city" : "Bern",
        "postalCode" : "3000"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:e8f6adae-30ed-4f55-973a-3ed4f139645b",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "e8f6adae-30ed-4f55-973a-3ed4f139645b",
      "practitioner" : {
        "reference" : "urn:uuid:1503c5eb-e2b7-4751-81ac-89b20a904884"
      },
      "organization" : {
        "reference" : "urn:uuid:409e7c49-ae05-44b7-a36b-aa2b7e9f5f7d"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:b28199d0-7d4c-4af0-afc6-a4842e665d2c",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "b28199d0-7d4c-4af0-afc6-a4842e665d2c",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac"
      },
      "collection" : {
        "collectedDateTime" : "2024-08-10T09:15:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:e91c013b-d627-4345-b19b-4927bd927c3f",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "e91c013b-d627-4345-b19b-4927bd927c3f",
      "identifier" : [{
        "value" : "50002755"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "53942-9"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac"
      },
      "requester" : {
        "reference" : "urn:uuid:e8f6adae-30ed-4f55-973a-3ed4f139645b"
      },
      "specimen" : [{
        "reference" : "urn:uuid:b28199d0-7d4c-4af0-afc6-a4842e665d2c"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:2f3dff1e-eb3c-4af5-8478-7a73251ebdbc",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "2f3dff1e-eb3c-4af5-8478-7a73251ebdbc",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:5ce27e23-a0d6-46a9-a9eb-c40fb9a1818a"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:e91c013b-d627-4345-b19b-4927bd927c3f"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:90f9c93c-4bea-46cb-bdbe-0bc08101fbac"
      },
      "performer" : [{
        "reference" : "urn:uuid:0d4e1427-e05f-4db2-afda-c55eabaf6909"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:b28199d0-7d4c-4af0-afc6-a4842e665d2c"
      }],
      "result" : [{
        "reference" : "urn:uuid:7d7bcbb5-1e55-44ad-a9e5-c9bf33d6bd30"
      }]
    }
  }]
}

```
