# 66Doc - HIV Recency - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **66Doc - HIV Recency**

## Example Bundle: 66Doc - HIV Recency



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "66Doc-HivRecency",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:b9a8b9ee-9157-44af-b46e-8c683c69d6bd"
  },
  "type" : "document",
  "timestamp" : "2025-03-17T12:00:00+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/66Comp-HivRecency",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "66Comp-HivRecency",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:b9a8b9ee-9157-44af-b46e-8c683c69d6bd"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/66Pat"
      },
      "date" : "2025-03-17T12:00:00+02:00",
      "author" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "title" : "Laborbericht vom 17.03.2025",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18727-8",
            "display" : "Serology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "Observation/66Obs-HivRecency"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/DiagnosticReport/66DR-HivRecency",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "66DR-HivRecency",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "Composition/66Comp-HivRecency"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:b9a8b9ee-9157-44af-b46e-8c683c69d6bd"
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/66SR-HivRecency"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/66Pat"
      },
      "performer" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "specimen" : [{
        "reference" : "Specimen/66Spec-HivRecency"
      }],
      "result" : [{
        "reference" : "Observation/66Obs-HivRecency"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/66Pat",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "66Pat",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "extension" : [{
          "url" : "http://fhir.ch/ig/ch-elm/StructureDefinition/ch-elm-ext-hiv-code",
          "valueString" : "H5"
        }],
        "_family" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
            "valueCode" : "masked"
          }]
        },
        "_given" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
            "valueCode" : "masked"
          }]
        }]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/66Obs-HivRecency",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "66Obs-HivRecency",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "77685-6",
          "display" : "HIV 1 and 2 IgG Ab [Identifier] in Serum or Plasma by Immunoblot"
        }]
      },
      "subject" : {
        "reference" : "Patient/66Pat"
      },
      "effectiveDateTime" : "2025-03-15T14:20:00+02:00",
      "performer" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "specimen" : {
        "reference" : "Specimen/66Spec-HivRecency"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118040000",
            "display" : "Measurement of Human immunodeficiency virus 1 glycoprotein 120 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 1,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118044009",
            "display" : "Measurement of Human immunodeficiency virus 1 glycoprotein 41 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 0.5,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118052007",
            "display" : "Measurement of Human immunodeficiency virus 1 protein 31 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 0,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "117749009",
            "display" : "Measurement of Human immunodeficiency virus 1 protein 24 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 2,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118047002",
            "display" : "Measurement of Human immunodeficiency virus 1 protein 17 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 3,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118062000",
            "display" : "Measurement of Human immunodeficiency virus 2 glycoprotein 105 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 0,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "118067006",
            "display" : "Measurement of Human immunodeficiency virus 2 glycoprotein 36 antibody (procedure)"
          }]
        },
        "valueQuantity" : {
          "value" : 4,
          "unit" : "[arb'U]",
          "system" : "http://unitsofmeasure.org",
          "code" : "[arb'U]"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Specimen/66Spec-HivRecency",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "66Spec-HivRecency",
      "subject" : {
        "reference" : "Patient/66Pat"
      },
      "collection" : {
        "collectedDateTime" : "2025-03-15T14:20:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ServiceRequest/66SR-HivRecency",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "66SR-HivRecency",
      "identifier" : [{
        "value" : "36500923675"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "77685-6",
          "display" : "HIV 1 and 2 IgG Ab [Identifier] in Serum or Plasma by Immunoblot"
        }]
      },
      "subject" : {
        "reference" : "Patient/66Pat"
      },
      "requester" : {
        "reference" : "PractitionerRole/PR-PeterHauser"
      },
      "specimen" : [{
        "reference" : "Specimen/66Spec-HivRecency"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1Org-Labor",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1Org-Labor",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/PR-PeterHauser",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "PR-PeterHauser",
      "practitioner" : {
        "reference" : "Practitioner/Pract-PeterHauser"
      },
      "organization" : {
        "reference" : "Organization/Org-PeterHauser"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/Pract-PeterHauser",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "Pract-PeterHauser",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000514"
      }],
      "name" : [{
        "family" : "Hauser",
        "given" : ["Peter"]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "peter.hauser@hauserpraxis.ch"
      },
      {
        "system" : "phone",
        "value" : "+41 79 222 33 44"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/Org-PeterHauser",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Org-PeterHauser",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A74966168"
      }],
      "name" : "Praxis Dr. Hauser",
      "address" : [{
        "line" : ["Hauptstrasse 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Hauptstrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Solothurn",
        "postalCode" : "4500"
      }]
    }
  }]
}

```
