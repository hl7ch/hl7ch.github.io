# CH ELM Results Component Vs - CH ELM (R4) v1.15.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Component Vs**

## ValueSet: CH ELM Results Component Vs 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-vs | *Version*:1.15.1 |
| Active as of 2026-08-14 | *Computable Name*:ChElmResultsComponentVs |
| **Copyright/Legal**: CC0-1.0 | |

 
This CH ELM value set includes the value set URLs as codes to map in the concept maps the leading codes. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-results-component-vs",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-vs",
  "version" : "1.15.1",
  "name" : "ChElmResultsComponentVs",
  "title" : "CH ELM Results Component Vs",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-14T07:34:39+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "This CH ELM value set includes the value set URLs as codes to map in the concept maps the leading codes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://fhir.ch/ig/ch-elm/CodeSystem/ch-elm-results-component-vs",
      "concept" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-antibiotic-tb"
      },
      {
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe"
      },
      {
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-tb"
      }]
    }]
  }
}

```
