# 24Doc - Chikungunya fever - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **24Doc - Chikungunya fever**

## Example Bundle: 24Doc - Chikungunya fever



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "24Doc-Chikungunya",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:3401332d-6012-443f-9690-9331adb23aab"
  },
  "type" : "document",
  "timestamp" : "2024-09-05T12:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:c2a43079-cd73-415e-a02f-857fac73d754",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "c2a43079-cd73-415e-a02f-857fac73d754",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:3401332d-6012-443f-9690-9331adb23aab"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0"
      },
      "date" : "2024-09-05T12:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:c89b523c-62ad-47d6-b23b-4309eb8143e7"
      }],
      "title" : "Laborbericht vom 2.9.2024",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:48459a37-9801-43dc-8f38-7f3cf93be994"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "cd67c739-40a9-48cd-8544-a78a2b9ff6d0",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c89b523c-62ad-47d6-b23b-4309eb8143e7",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "c89b523c-62ad-47d6-b23b-4309eb8143e7",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:48459a37-9801-43dc-8f38-7f3cf93be994",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "48459a37-9801-43dc-8f38-7f3cf93be994",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "86515-4"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0"
      },
      "effectiveDateTime" : "2024-07-25T14:20:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:c89b523c-62ad-47d6-b23b-4309eb8143e7"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:e5804c4b-5051-406c-af65-a8ae0674eb2d"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:92073ae8-a9fc-4308-987d-beae9af442a6",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "92073ae8-a9fc-4308-987d-beae9af442a6",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000514"
      }],
      "name" : [{
        "family" : "Hauser",
        "given" : ["Peter"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 222 33 44"
      },
      {
        "system" : "email",
        "value" : "peter.hauser@hauserpraxis.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:a4160386-37ab-4313-afcf-615dbe100cb4",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "a4160386-37ab-4313-afcf-615dbe100cb4",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A74966168"
      }],
      "name" : "Praxis Dr. Hauser",
      "address" : [{
        "line" : ["Hauptstrasse 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Hauptstrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Solothurn",
        "postalCode" : "4500"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:4efa53fd-1635-4de9-afed-d468d64cb7f4",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "4efa53fd-1635-4de9-afed-d468d64cb7f4",
      "practitioner" : {
        "reference" : "urn:uuid:92073ae8-a9fc-4308-987d-beae9af442a6"
      },
      "organization" : {
        "reference" : "urn:uuid:a4160386-37ab-4313-afcf-615dbe100cb4"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:e5804c4b-5051-406c-af65-a8ae0674eb2d",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "e5804c4b-5051-406c-af65-a8ae0674eb2d",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0"
      },
      "collection" : {
        "collectedDateTime" : "2024-08-22T14:20:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:8564e794-a14e-4efd-baa8-341be26e7cd0",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "8564e794-a14e-4efd-baa8-341be26e7cd0",
      "identifier" : [{
        "value" : "26500923622"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "86515-4"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0"
      },
      "requester" : {
        "reference" : "urn:uuid:4efa53fd-1635-4de9-afed-d468d64cb7f4"
      },
      "specimen" : [{
        "reference" : "urn:uuid:e5804c4b-5051-406c-af65-a8ae0674eb2d"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:8ebae5a6-ac49-48dc-89c0-8b0050609d12",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "8ebae5a6-ac49-48dc-89c0-8b0050609d12",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:c2a43079-cd73-415e-a02f-857fac73d754"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:3401332d-6012-443f-9690-9331adb23aab"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:8564e794-a14e-4efd-baa8-341be26e7cd0"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:cd67c739-40a9-48cd-8544-a78a2b9ff6d0"
      },
      "performer" : [{
        "reference" : "urn:uuid:c89b523c-62ad-47d6-b23b-4309eb8143e7"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:e5804c4b-5051-406c-af65-a8ae0674eb2d"
      }],
      "result" : [{
        "reference" : "urn:uuid:48459a37-9801-43dc-8f38-7f3cf93be994"
      }]
    }
  }]
}

```
