# 1bOrg - Broker - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1bOrg - Broker**

## Example Organization: 1bOrg - Broker



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "1bOrg-Broker",
  "identifier" : [{
    "system" : "urn:oid:2.51.1.3",
    "value" : "7601023000119"
  }]
}

```
