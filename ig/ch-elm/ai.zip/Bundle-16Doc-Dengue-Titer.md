# 16Doc - Dengue Titer - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **16Doc - Dengue Titer**

## Example Bundle: 16Doc - Dengue Titer



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "16Doc-Dengue-Titer",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:a701332d-6012-443f-9690-9291adb2aa89"
  },
  "type" : "document",
  "timestamp" : "2024-07-25T08:30:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:5a968a6d-2ccf-408b-8ad5-6984075c5434",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "5a968a6d-2ccf-408b-8ad5-6984075c5434",
      "language" : "fr-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:a701332d-6012-443f-9690-9291adb2aa89"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20"
      },
      "date" : "2024-07-25T08:30:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:0cf2b07e-fbb9-4f46-9ad0-f453a508187d"
      }],
      "title" : "Rapport de laboratoire du 25.7.2024",
      "section" : [{
        "title" : "Résultats de l'analyse microbiologique",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:a7119e2d-999f-4687-86f2-f9f66c288ef8"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "0366cbb5-17e6-45c9-928f-414787d61a20",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0cf2b07e-fbb9-4f46-9ad0-f453a508187d",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "0cf2b07e-fbb9-4f46-9ad0-f453a508187d",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:a7119e2d-999f-4687-86f2-f9f66c288ef8",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "a7119e2d-999f-4687-86f2-f9f66c288ef8",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6811-4"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20"
      },
      "effectiveDateTime" : "2024-07-24T07:40:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:0cf2b07e-fbb9-4f46-9ad0-f453a508187d"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "U"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:a743f09e-3b8b-40ad-aeed-ac3fea230f27"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:4383a91b-aff6-4f2a-af0e-e21490d6a4c6",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "4383a91b-aff6-4f2a-af0e-e21490d6a4c6",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000121219"
      }],
      "name" : [{
        "family" : "Moreau",
        "given" : ["Jeanne"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 88 99"
      },
      {
        "system" : "email",
        "value" : "jm@hr-soleil.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c3802fdd-3526-43ab-bd18-6e745ae9debd",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "c3802fdd-3526-43ab-bd18-6e745ae9debd",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99086638"
      }],
      "name" : "hôpital régional soleil",
      "address" : [{
        "line" : ["rue des alpes 35"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue des alpes"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "35"
          }]
        }],
        "city" : "Genève",
        "postalCode" : "1202"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:2a4a2a64-94c8-4127-89f0-115c3f03fff5",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "2a4a2a64-94c8-4127-89f0-115c3f03fff5",
      "practitioner" : {
        "reference" : "urn:uuid:4383a91b-aff6-4f2a-af0e-e21490d6a4c6"
      },
      "organization" : {
        "reference" : "urn:uuid:c3802fdd-3526-43ab-bd18-6e745ae9debd"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:a743f09e-3b8b-40ad-aeed-ac3fea230f27",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "a743f09e-3b8b-40ad-aeed-ac3fea230f27",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20"
      },
      "collection" : {
        "collectedDateTime" : "2024-07-22T07:40:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:f11b136f-3d38-4330-b3a9-038f15670915",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "f11b136f-3d38-4330-b3a9-038f15670915",
      "identifier" : [{
        "value" : "28541215633"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6811-4"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20"
      },
      "requester" : {
        "reference" : "urn:uuid:2a4a2a64-94c8-4127-89f0-115c3f03fff5"
      },
      "specimen" : [{
        "reference" : "urn:uuid:a743f09e-3b8b-40ad-aeed-ac3fea230f27"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:21ecc3e7-147b-49f9-a279-c3dd2e543d19",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "21ecc3e7-147b-49f9-a279-c3dd2e543d19",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:5a968a6d-2ccf-408b-8ad5-6984075c5434"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:a701332d-6012-443f-9690-9291adb2aa89"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:f11b136f-3d38-4330-b3a9-038f15670915"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:0366cbb5-17e6-45c9-928f-414787d61a20"
      },
      "performer" : [{
        "reference" : "urn:uuid:0cf2b07e-fbb9-4f46-9ad0-f453a508187d"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:a743f09e-3b8b-40ad-aeed-ac3fea230f27"
      }],
      "result" : [{
        "reference" : "urn:uuid:a7119e2d-999f-4687-86f2-f9f66c288ef8"
      }]
    }
  }]
}

```
