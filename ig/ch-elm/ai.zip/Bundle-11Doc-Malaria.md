# 11Doc - Malaria - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **11Doc - Malaria**

## Example Bundle: 11Doc - Malaria



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "11Doc-Malaria",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:1904332d-6012-443f-9690-9291adb234fe"
  },
  "type" : "document",
  "timestamp" : "2023-09-15T11:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:c86447fc-1d7d-4365-b2a4-fd50da374dc4",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "c86447fc-1d7d-4365-b2a4-fd50da374dc4",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:1904332d-6012-443f-9690-9291adb234fe"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb"
      },
      "date" : "2023-09-15T11:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:187f9b81-4cbc-4f55-901c-bc7cadaf008f"
      }],
      "title" : "Laborbericht vom 15.09.2023",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:eb5a2099-383b-4802-84a3-c3f21417d4b0"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "53d74b79-32de-4bf2-91a6-8f94d0def5eb",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:187f9b81-4cbc-4f55-901c-bc7cadaf008f",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "187f9b81-4cbc-4f55-901c-bc7cadaf008f",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:eb5a2099-383b-4802-84a3-c3f21417d4b0",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "eb5a2099-383b-4802-84a3-c3f21417d4b0",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "70568-1"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb"
      },
      "effectiveDateTime" : "2023-09-15T09:15:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:187f9b81-4cbc-4f55-901c-bc7cadaf008f"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive (qualifier value)"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:f8ddac96-d84d-4bad-934b-48deff10bbf3"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:6d81a36f-b838-4c71-b20c-22c8607ec1d2",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "6d81a36f-b838-4c71-b20c-22c8607ec1d2",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000234438"
      }],
      "name" : [{
        "family" : "Giacometti",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 44 55"
      },
      {
        "system" : "email",
        "value" : "m.giacometti@ks-abc.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:6fcf633f-8c5e-44dd-a8ed-8b1e28e6151c",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "6fcf633f-8c5e-44dd-a8ed-8b1e28e6151c",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "Kantonsspital ABC",
      "address" : [{
        "line" : ["Aortastrasse 22"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Aortastrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "22"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
            "valueString" : "Postfach 18"
          }]
        }],
        "city" : "Bern",
        "postalCode" : "3000"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:6f70294f-29c1-47c8-ab44-16469d49e9cf",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "6f70294f-29c1-47c8-ab44-16469d49e9cf",
      "practitioner" : {
        "reference" : "urn:uuid:6d81a36f-b838-4c71-b20c-22c8607ec1d2"
      },
      "organization" : {
        "reference" : "urn:uuid:6fcf633f-8c5e-44dd-a8ed-8b1e28e6151c"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:f8ddac96-d84d-4bad-934b-48deff10bbf3",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "f8ddac96-d84d-4bad-934b-48deff10bbf3",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb"
      },
      "collection" : {
        "collectedDateTime" : "2023-09-12"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:602b8d60-9104-4737-86f6-7770b0eecdcb",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "602b8d60-9104-4737-86f6-7770b0eecdcb",
      "identifier" : [{
        "value" : "23846922417"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "70568-1"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb"
      },
      "requester" : {
        "reference" : "urn:uuid:6f70294f-29c1-47c8-ab44-16469d49e9cf"
      },
      "specimen" : [{
        "reference" : "urn:uuid:f8ddac96-d84d-4bad-934b-48deff10bbf3"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:80fa1a58-c692-4a4b-98a3-764f79b8fc93",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "80fa1a58-c692-4a4b-98a3-764f79b8fc93",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:c86447fc-1d7d-4365-b2a4-fd50da374dc4"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:1904332d-6012-443f-9690-9291adb234fe"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:602b8d60-9104-4737-86f6-7770b0eecdcb"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:53d74b79-32de-4bf2-91a6-8f94d0def5eb"
      },
      "performer" : [{
        "reference" : "urn:uuid:187f9b81-4cbc-4f55-901c-bc7cadaf008f"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:f8ddac96-d84d-4bad-934b-48deff10bbf3"
      }],
      "result" : [{
        "reference" : "urn:uuid:eb5a2099-383b-4802-84a3-c3f21417d4b0"
      }]
    }
  }]
}

```
