# 1bOrg - Labor - CH ELM (R4) v1.12.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1bOrg - Labor**

## Example Organization: 1bOrg - Labor

**identifier**: [GLN](https://www.gs1.org/standards/id-keys/gln)/7601000000415

**name**: MikroLab



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "1bOrg-Labor",
  "identifier" : [
    {
      "system" : "urn:oid:2.51.1.3",
      "value" : "7601000000415"
    }
  ],
  "name" : "MikroLab"
}

```
