# 1bOrg - Labor - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1bOrg - Labor**

## Example Organization: 1bOrg - Labor



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "1bOrg-Labor",
  "identifier" : [
    {
      "system" : "urn:oid:2.51.1.3",
      "value" : "7601000000415"
    }
  ],
  "name" : "MikroLab"
}

```
