# CH ELM FOPH Patient Name Representation - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM FOPH Patient Name Representation**

## ValueSet: CH ELM FOPH Patient Name Representation 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-foph-patient-name-representation | *Version*:1.14.0 |
| Active as of 2026-05-26 | *Computable Name*:ChElmFophPatientNameRepresentation |
| **Copyright/Legal**: CC0-1.0 | |

 
This CH ELM resource defines the codes which identify possible patient name schemas to be used. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-foph-patient-name-representation",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-foph-patient-name-representation",
  "version" : "1.14.0",
  "name" : "ChElmFophPatientNameRepresentation",
  "title" : "CH ELM FOPH Patient Name Representation",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-26T14:58:40+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "This CH ELM resource defines the codes which identify possible patient name schemas to be used.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://fhir.ch/ig/ch-elm/CodeSystem/ch-elm-foph-patient-name-representation",
      "concept" : [{
        "code" : "full-name",
        "display" : "Full Name"
      },
      {
        "code" : "initials",
        "display" : "Initials"
      },
      {
        "code" : "hiv-code",
        "display" : "HIV Code"
      },
      {
        "code" : "initials-or-vctcode",
        "display" : "Initials or VCT-Code"
      },
      {
        "code" : "conditional",
        "display" : "Conditional"
      }]
    }]
  }
}

```
