# Publish 6Doc-Influenza - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Publish 6Doc-Influenza**

## Example DocumentReference: Publish 6Doc-Influenza



## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "Publish-6Doc-Influenza",
  "contained" : [{
    "resourceType" : "Bundle",
    "id" : "6Doc-Influenza",
    "identifier" : {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:uuid:1901332d-6012-443f-9690-9291adb23a5c"
    },
    "type" : "document",
    "timestamp" : "2023-09-10T12:00:00+02:00",
    "entry" : [{
      "fullUrl" : "http://test.fhir.ch/r4/Composition/6Comp-Influenza",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "6Comp-Influenza",
        "language" : "de-CH",
        "identifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:1901332d-6012-443f-9690-9291adb23a5c"
        },
        "status" : "final",
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "version" : "http://snomed.info/sct/2011000195101",
            "code" : "4241000179101",
            "display" : "Laborbericht"
          },
          {
            "system" : "http://loinc.org",
            "code" : "11502-2",
            "display" : "Laboratory report"
          }]
        },
        "subject" : {
          "reference" : "Patient/Pat-001"
        },
        "date" : "2023-09-10T12:00:00+02:00",
        "author" : [{
          "reference" : "Organization/1Org-Labor"
        }],
        "title" : "Laborbericht vom 10.09.2023",
        "section" : [{
          "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }]
          },
          "entry" : [{
            "reference" : "Observation/6Obs-Influenza"
          }]
        }]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/DiagnosticReport/6DR-Influenza",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "6DR-Influenza",
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
          "valueReference" : {
            "reference" : "Composition/6Comp-Influenza"
          }
        }],
        "identifier" : [{
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:1901332d-6012-443f-9690-9291adb23a5c"
        }],
        "basedOn" : [{
          "reference" : "ServiceRequest/6SR-Order"
        }],
        "status" : "final",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11502-2",
            "display" : "Laboratory report"
          }]
        },
        "subject" : {
          "reference" : "Patient/Pat-001"
        },
        "performer" : [{
          "reference" : "Organization/1Org-Labor"
        }],
        "specimen" : [{
          "reference" : "Specimen/6Spec-Specimen"
        }],
        "result" : [{
          "reference" : "Observation/6Obs-Influenza"
        }]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Patient/Pat-001",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "Pat-001",
        "identifier" : [{
          "system" : "urn:oid:2.16.756.5.32",
          "value" : "7562295883070"
        }],
        "name" : [{
          "family" : "M",
          "given" : ["D"]
        }],
        "gender" : "male",
        "birthDate" : "1960-08-22",
        "address" : [{
          "use" : "home",
          "city" : "Bern",
          "state" : "BE",
          "postalCode" : "3000",
          "country" : "CH",
          "_country" : {
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
              "valueCoding" : {
                "system" : "urn:iso:std:iso:3166",
                "code" : "CH"
              }
            }]
          }
        }]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Observation/6Obs-Influenza",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "6Obs-Influenza",
        "status" : "final",
        "category" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
            "code" : "laboratory",
            "display" : "Laboratory"
          }]
        }],
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "76078-5",
            "display" : "Influenza virus A RNA [Presence] in Nasopharynx by NAA with probe detection"
          }]
        },
        "subject" : {
          "reference" : "Patient/Pat-001"
        },
        "effectiveDateTime" : "2023-09-10T14:20:00+02:00",
        "performer" : [{
          "reference" : "Organization/1Org-Labor"
        }],
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "10828004",
            "display" : "Positive"
          }]
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }],
        "specimen" : {
          "reference" : "Specimen/6Spec-Specimen"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Specimen/6Spec-Specimen",
      "resource" : {
        "resourceType" : "Specimen",
        "id" : "6Spec-Specimen",
        "subject" : {
          "reference" : "Patient/Pat-001"
        },
        "collection" : {
          "collectedDateTime" : "2023-09-08"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/ServiceRequest/6SR-Order",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "6SR-Order",
        "identifier" : [{
          "value" : "26500923622"
        }],
        "status" : "completed",
        "intent" : "order",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "76078-5",
            "display" : "Influenza virus A RNA [Presence] in Nasopharynx by NAA with probe detection"
          }]
        },
        "subject" : {
          "reference" : "Patient/Pat-001"
        },
        "requester" : {
          "reference" : "PractitionerRole/PR-PeterHauser"
        },
        "specimen" : [{
          "reference" : "Specimen/6Spec-Specimen"
        }]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/1Org-Labor",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "1Org-Labor",
        "identifier" : [{
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601002331470"
        }],
        "name" : "SanLab"
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/PR-PeterHauser",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "PR-PeterHauser",
        "practitioner" : {
          "reference" : "Practitioner/Pract-PeterHauser"
        },
        "organization" : {
          "reference" : "Organization/Org-PeterHauser"
        }
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Practitioner/Pract-PeterHauser",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "Pract-PeterHauser",
        "identifier" : [{
          "system" : "urn:oid:2.51.1.3",
          "value" : "7601000000514"
        }],
        "name" : [{
          "family" : "Hauser",
          "given" : ["Peter"]
        }],
        "telecom" : [{
          "system" : "email",
          "value" : "peter.hauser@hauserpraxis.ch"
        },
        {
          "system" : "phone",
          "value" : "+41 79 222 33 44"
        }]
      }
    },
    {
      "fullUrl" : "http://test.fhir.ch/r4/Organization/Org-PeterHauser",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "Org-PeterHauser",
        "identifier" : [{
          "system" : "urn:oid:2.16.756.5.45",
          "value" : "A74966168"
        }],
        "name" : "Praxis Dr. Hauser",
        "address" : [{
          "line" : ["Hauptstrasse 10"],
          "_line" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
              "valueString" : "Hauptstrasse"
            },
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
              "valueString" : "10"
            }]
          }],
          "city" : "Solothurn",
          "postalCode" : "4500"
        }]
      }
    }]
  }],
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:1901332d-6012-443f-9690-9291adb23a5c"
  }],
  "status" : "current",
  "content" : [{
    "attachment" : {
      "language" : "de-CH",
      "url" : "#6Doc-Influenza"
    }
  }]
}

```
