# CH ELM Results Genotype To Component Code - CH ELM (R4) v1.15.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Genotype To Component Code**

## ConceptMap: CH ELM Results Genotype To Component Code 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ConceptMap/ch-elm-results-geno-to-component-code | *Version*:1.15.0 |
| Active as of 2026-08-12 | *Computable Name*:ChElmResultsGenoToComponentCode |
| **Copyright/Legal**: CC0-1.0 | |

 
This CH ELM concept map shows for each leading code defining genotype testing results its corresponding genotyp-valueset. The target code shows the URL of the value set containing the permitted genotype codes. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "ch-elm-results-geno-to-component-code",
  "url" : "http://fhir.ch/ig/ch-elm/ConceptMap/ch-elm-results-geno-to-component-code",
  "version" : "1.15.0",
  "name" : "ChElmResultsGenoToComponentCode",
  "title" : "CH ELM Results Genotype To Component Code",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-12T07:20:00+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "This CH ELM concept map shows for each leading code defining genotype testing results its corresponding genotyp-valueset. The target code shows the URL of the value set containing the permitted genotype codes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "sourceCanonical" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-laboratory-observation-geno",
  "targetCanonical" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-vs",
  "group" : [{
    "source" : "http://snomed.info/sct",
    "target" : "http://fhir.ch/ig/ch-elm/CodeSystem/ch-elm-results-component-vs",
    "element" : [{
      "code" : "1087501000112108",
      "display" : "Carbapenemase-producing Buttiauxella",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1089101000112105",
      "display" : "Carbapenemase-producing Citrobacter amalonaticus",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1089301000112107",
      "display" : "Carbapenemase-producing Citrobacter braakii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1089501000112101",
      "display" : "Carbapenemase-producing Citrobacter",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1089701000112106",
      "display" : "Carbapenemase-producing Citrobacter farmeri",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1089901000112108",
      "display" : "Carbapenemase-producing Citrobacter freundii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1090201000112105",
      "display" : "Carbapenemase-producing Citrobacter gillenii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1090401000112109",
      "display" : "Carbapenemase-producing Citrobacter koseri",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1090601000112107",
      "display" : "Carbapenemase-producing Citrobacter murliniae",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1091001000112109",
      "display" : "Carbapenemase-producing Citrobacter sedlakii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1091201000112104",
      "display" : "Carbapenemase-producing Citrobacter werkmanii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1091401000112100",
      "display" : "Carbapenemase-producing Citrobacter youngae",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1092401000112105",
      "display" : "Carbapenemase-producing Cronobacter sakazakii",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1093401000112101",
      "display" : "Carbapenemase-producing Enterobacter",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1093601000112103",
      "display" : "Carbapenemase-producing Enterobacter asburiae",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1094301000112105",
      "display" : "Carbapenemase-producing Enterobacter hormaechei",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1096801000112108",
      "display" : "Carbapenemase-producing Klebsiella",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1097701000112102",
      "display" : "Carbapenemase-producing Klebsiella pneumoniae subsp. ozaenae",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1098201000112108",
      "display" : "Carbapenemase-producing Klebsiella pneumoniae",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1099001000112108",
      "display" : "Carbapenemase-producing Kluyvera",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1099201000112103",
      "display" : "Carbapenemase-producing Kluyvera ascorbata",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1099401000112104",
      "display" : "Carbapenemase-producing Kluyvera cryocrescens",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1099601000112101",
      "display" : "Carbapenemase-producing Kluyvera georgiana",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1099801000112102",
      "display" : "Carbapenemase-producing Kluyvera intermedia",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1100001000112108",
      "display" : "Carbapenemase-producing Leclercia",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1100201000112103",
      "display" : "Carbapenemase-producing Leclercia adecarboxylata",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1105401000112106",
      "display" : "Carbapenemase-producing Raoultella ornithinolytica",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1105601000112109",
      "display" : "Carbapenemase-producing Raoultella planticola",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1105801000112108",
      "display" : "Carbapenemase-producing Raoultella terrigena",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1106001000112106",
      "display" : "Carbapenemase-producing Salmonella",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1108301000112108",
      "display" : "Carbapenemase-producing Shigella",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1112101000112106",
      "display" : "Carbapenemase-producing Lelliottia amnigena",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1359810002",
      "display" : "Carbapenemase-producing Cronobacter",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1359811003",
      "display" : "Carbapenemase-producing Escherichia spp",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1362138006",
      "display" : "Carbapenemase-producing Lelliottia",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "1388125003",
      "display" : "Carbapenemase-producing Pluralibacter (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "308241000087107",
      "display" : "Carbapenemase-producing Pluralibacter gergoviae (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "33691000087101",
      "display" : "Carbapenemase-producing Klebsiella variicola",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "432763001",
      "display" : "Enterobacter ludwigii (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "44601000087107",
      "display" : "Carbapenemase-producing Citrobacter freundii complex",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "51271000087100",
      "display" : "Carbapenemase-producing Klebsiella oxytoca",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "734352006",
      "display" : "Carbapenemase-producing Klebsiella aerogenes (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "734353001",
      "display" : "Carbapenemase-producing Enterobacter cloacae complex (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "737528008",
      "display" : "Carbapenemase-producing Escherichia coli (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "737529000",
      "display" : "Carbapenemase-producing Enterobacter cloacae (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    },
    {
      "code" : "770392005",
      "display" : "Carbapenemase-producing Raoultella (organism)",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-cpe",
        "equivalence" : "relatedto"
      }]
    }]
  },
  {
    "source" : "http://loinc.org",
    "target" : "http://fhir.ch/ig/ch-elm/CodeSystem/ch-elm-results-component-vs",
    "element" : [{
      "code" : "94053-6",
      "display" : "Mycobacterium tuberculosis complex resistance panel by Molecular genetics method",
      "target" : [{
        "code" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-component-gene-tb",
        "equivalence" : "relatedto"
      }]
    }]
  }]
}

```
