# 63Doc - Tuberculosis Genotyping - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **63Doc - Tuberculosis Genotyping**

## Example Bundle: 63Doc - Tuberculosis Genotyping



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "63Doc-Tb-Genotyping",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:0ed5f82b-06e9-427b-8546-e841a33d49e8"
  },
  "type" : "document",
  "timestamp" : "2024-09-10T12:00:00+02:00",
  "entry" : [{
    "fullUrl" : "http://test.fhir.ch/r4/Composition/63Comp-Genotyping",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "63Comp-Genotyping",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:0ed5f82b-06e9-427b-8546-e841a33d49e8"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/Pat-003"
      },
      "date" : "2024-09-10T12:00:00+02:00",
      "author" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "title" : "Laborbericht vom 10.09.2024",
      "section" : [{
        "title" : "Genotyping",
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "726528006",
            "display" : "Genotyping (qualifier value)"
          }]
        },
        "entry" : [{
          "reference" : "Observation/63Obs-Genotyping"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/DiagnosticReport/63DR-Genotyping",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "63DR-Genotyping",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "Composition/63Comp-Genotyping"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:0ed5f82b-06e9-427b-8546-e841a33d49e8"
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/63SR-Genotyping"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/Pat-003"
      },
      "performer" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "specimen" : [{
        "reference" : "Specimen/63Spec-Genotyping"
      }],
      "result" : [{
        "reference" : "Observation/63Obs-Genotyping"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Patient/Pat-003",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "Pat-003",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567866"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 76 222 55 22"
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["Rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Observation/63Obs-Genotyping",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "63Obs-Genotyping",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "94053-6",
          "display" : "Mycobacterium tuberculosis complex resistance panel by Molecular genetics method"
        }]
      },
      "subject" : {
        "reference" : "Patient/Pat-003"
      },
      "effectiveDateTime" : "2024-09-10T14:20:00+02:00",
      "performer" : [{
        "reference" : "Organization/1Org-Labor"
      }],
      "specimen" : {
        "reference" : "Specimen/63Spec-Genotyping"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "63072-3",
            "display" : "Mycobacterium tuberculosis inhA gene isoniazid low level resistance mutation [Presence] by Molecular method"
          }]
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-applicable"
          }]
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Specimen/63Spec-Genotyping",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "63Spec-Genotyping",
      "subject" : {
        "reference" : "Patient/Pat-003"
      },
      "collection" : {
        "collectedDateTime" : "2024-09-08"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/ServiceRequest/63SR-Genotyping",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "63SR-Genotyping",
      "identifier" : [{
        "value" : "26500923622"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "94053-6",
          "display" : "Mycobacterium tuberculosis complex resistance panel by Molecular genetics method"
        }]
      },
      "subject" : {
        "reference" : "Patient/Pat-003"
      },
      "requester" : {
        "reference" : "PractitionerRole/PR-PeterHauser"
      },
      "specimen" : [{
        "reference" : "Specimen/63Spec-Genotyping"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/1Org-Labor",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1Org-Labor",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/PractitionerRole/PR-PeterHauser",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "PR-PeterHauser",
      "practitioner" : {
        "reference" : "Practitioner/Pract-PeterHauser"
      },
      "organization" : {
        "reference" : "Organization/Org-PeterHauser"
      }
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Practitioner/Pract-PeterHauser",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "Pract-PeterHauser",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000514"
      }],
      "name" : [{
        "family" : "Hauser",
        "given" : ["Peter"]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "peter.hauser@hauserpraxis.ch"
      },
      {
        "system" : "phone",
        "value" : "+41 79 222 33 44"
      }]
    }
  },
  {
    "fullUrl" : "http://test.fhir.ch/r4/Organization/Org-PeterHauser",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Org-PeterHauser",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A74966168"
      }],
      "name" : "Praxis Dr. Hauser",
      "address" : [{
        "line" : ["Hauptstrasse 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Hauptstrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Solothurn",
        "postalCode" : "4500"
      }]
    }
  }]
}

```
