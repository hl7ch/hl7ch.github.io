# 1Pract - Monika Giacometti - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1Pract - Monika Giacometti**

## Example Practitioner: 1Pract - Monika Giacometti



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "1Pract-KsAbc",
  "identifier" : [
    {
      "system" : "urn:oid:2.51.1.3",
      "value" : "7601000234438"
    },
    {
      "system" : "urn:oid:2.16.756.5.30.1.123.100.2.1.1",
      "value" : "Y604801"
    }
  ],
  "name" : [
    {
      "family" : "Giacometti",
      "given" : ["Monika"]
    }
  ],
  "telecom" : [
    {
      "system" : "email",
      "value" : "m.giacometti@ks-abc.ch"
    },
    {
      "system" : "phone",
      "value" : "+41 79 111 44 55"
    }
  ]
}

```
