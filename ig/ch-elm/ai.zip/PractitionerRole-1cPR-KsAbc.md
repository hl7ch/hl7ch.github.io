# 1PR - Monika Giacometti @ Kantonsspital ABC - CH ELM (R4) v1.12.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1PR - Monika Giacometti @ Kantonsspital ABC**

## Example PractitionerRole: 1PR - Monika Giacometti @ Kantonsspital ABC

**practitioner**: [Practitioner null Giacometti](Practitioner-1cPract-KsAbc.md)



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "1cPR-KsAbc",
  "practitioner" : {
    "reference" : "Practitioner/1cPract-KsAbc"
  }
}

```
