# CH ELM Results Mea Org - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Mea Org**

## ValueSet: CH ELM Results Mea Org 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-mea-org | *Version*:1.14.0 |
| Active as of 2026-05-26 | *Computable Name*:ChElmResultsMeaOrg |
| **Copyright/Legal**: CC0-1.0 | |

 
The "CH ELM Results Mea Org" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the "CH ELM Results Mea Org" group should refer to the provided codes to accurately and uniformly capture and report organism-related information. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-results-mea-org",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-mea-org",
  "version" : "1.14.0",
  "name" : "ChElmResultsMeaOrg",
  "title" : "CH ELM Results Mea Org",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-26T14:58:40+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [{
    "name" : "Federal Office of Public Health FOPH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
    }]
  }],
  "description" : "The \"CH ELM Results Mea Org\" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the \"CH ELM Results Mea Org\" group should refer to the provided codes to accurately and uniformly capture and report organism-related information.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CH"
    }]
  }],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "426558008",
        "display" : "Measles virus genotype A (organism)"
      },
      {
        "code" : "427290009",
        "display" : "Measles virus genotype D8 (organism)"
      },
      {
        "code" : "52584002",
        "display" : "Measles virus"
      },
      {
        "code" : "427073007",
        "display" : "Measles virus genotype B3 (organism)"
      }]
    }]
  }
}

```
