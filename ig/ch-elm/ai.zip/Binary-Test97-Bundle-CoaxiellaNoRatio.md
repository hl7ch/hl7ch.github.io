# Test97 Bundle - Coxiella without titer ratio which should raise an error - CH ELM (R4) v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test97 Bundle - Coxiella without titer ratio which should raise an error**

## Example Binary: Test97 Bundle - Coxiella without titer ratio which should raise an error

```

<Bundle xmlns="http://hl7.org/fhir">
  <id value="58Doc-Coxiella-noRatio"/>
  <identifier>
    <system value="urn:ietf:rfc:3986"/>
    <value value="urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"/>
  </identifier>
  <type value="document"/>
  <timestamp value="2025-01-20T12:00:00+02:00"/>
  <entry>
    <fullUrl value="urn:uuid:b88e3a4a-dec6-4815-a622-06a5c30d07b4"/>
    <resource>
      <Composition>
        <id value="b88e3a4a-dec6-4815-a622-06a5c30d07b4"/>
        <language value="de-CH"/>
        <identifier>
          <system value="urn:ietf:rfc:3986"/>
          <value value="urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"/>
        </identifier>
        <status value="final"/>
        <type>
          <coding>
            <system value="http://snomed.info/sct"/>
            <version value="http://snomed.info/sct/2011000195101"/>
            <code value="4241000179101"/>
            <display value="Laborbericht"/>
          </coding>
          <coding>
            <system value="http://loinc.org"/>
            <code value="11502-2"/>
            <display value="Laboratory report"/>
          </coding>
        </type>
        <subject>
          <reference value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        </subject>
        <date value="2025-01-20T12:00:00+02:00"/>
        <author>
          <reference value="urn:uuid:dcf59660-21c9-41a5-a6ee-2c956fe40177"/>
        </author>
        <title value="Laborbericht vom 20.01.2025"/>
        <section>
          <title value="Analyseergebnisse der mikrobiologischen Untersuchung"/>
          <code>
            <coding>
              <system value="http://loinc.org"/>
              <code value="18725-2"/>
              <display value="Microbiology studies (set)"/>
            </coding>
          </code>
          <entry>
            <reference value="urn:uuid:f067e8ae-acde-4490-b47f-e3fa400f59b5"/>
          </entry>
        </section>
      </Composition>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
    <resource>
      <Patient>
        <id value="9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        <identifier>
          <system value="urn:oid:2.16.756.5.32"/>
          <value value="7561234567897"/>
        </identifier>
        <name>
          <family value="Dupont"/>
          <given value="Antoine"/>
        </name>
        <gender value="female"/>
        <birthDate value="1981-02-07"/>
        <address>
          <use value="home"/>
          <line value="rue de la république 10">
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName">
              <valueString value="rue de la république"/>
            </extension>
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber">
              <valueString value="10"/>
            </extension>
          </line>
          <city value="Carouge"/>
          <state value="GE"/>
          <postalCode value="1227"/>
          <country value="CH">
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding">
              <valueCoding>
                <system value="urn:iso:std:iso:3166"/>
                <code value="CH"/>
              </valueCoding>
            </extension>
          </country>
        </address>
      </Patient>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:dcf59660-21c9-41a5-a6ee-2c956fe40177"/>
    <resource>
      <Organization>
        <id value="dcf59660-21c9-41a5-a6ee-2c956fe40177"/>
        <identifier>
          <system value="urn:oid:2.51.1.3"/>
          <value value="7601002331470"/>
        </identifier>
        <name value="SanLab"/>
      </Organization>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:f067e8ae-acde-4490-b47f-e3fa400f59b5"/>
    <resource>
      <Observation>
        <id value="f067e8ae-acde-4490-b47f-e3fa400f59b5"/>
        <status value="final"/>
        <category>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/observation-category"/>
            <code value="laboratory"/>
            <display value="Laboratory"/>
          </coding>
        </category>
        <code>
          <coding>
            <system value="http://loinc.org"/>
            <code value="9709-7"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        </subject>
        <effectiveDateTime value="2025-01-19T14:20:00+02:00"/>
        <performer>
          <reference value="urn:uuid:dcf59660-21c9-41a5-a6ee-2c956fe40177"/>
        </performer>
        <dataAbsentReason>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/data-absent-reason"/>
            <code value="not-applicable"/>
          </coding>
        </dataAbsentReason>
        <interpretation>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation"/>
            <code value="POS"/>
            <display value="Positive"/>
          </coding>
        </interpretation>
        <specimen>
          <reference value="urn:uuid:a7bb6064-feed-49f3-a7b4-058553b08c04"/>
        </specimen>
      </Observation>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:4f0a00b9-9693-46b2-a323-a1d6b079ad17"/>
    <resource>
      <Practitioner>
        <id value="4f0a00b9-9693-46b2-a323-a1d6b079ad17"/>
        <identifier>
          <system value="urn:oid:2.51.1.3"/>
          <value value="7601000000514"/>
        </identifier>
        <name>
          <family value="Hauser"/>
          <given value="Peter"/>
        </name>
        <telecom>
          <system value="phone"/>
          <value value="+41 79 222 33 44"/>
        </telecom>
        <telecom>
          <system value="email"/>
          <value value="peter.hauser@hauserpraxis.ch"/>
        </telecom>
      </Practitioner>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:c23fa7b6-24fd-4aeb-adf9-cae19280a95c"/>
    <resource>
      <Organization>
        <id value="c23fa7b6-24fd-4aeb-adf9-cae19280a95c"/>
        <identifier>
          <system value="urn:oid:2.16.756.5.45"/>
          <value value="A74966168"/>
        </identifier>
        <name value="Praxis Dr. Hauser"/>
        <address>
          <line value="Hauptstrasse 10">
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName">
              <valueString value="Hauptstrasse"/>
            </extension>
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber">
              <valueString value="10"/>
            </extension>
          </line>
          <city value="Solothurn"/>
          <postalCode value="4500"/>
        </address>
      </Organization>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:fd68a58d-7c6b-483c-83cb-5211687415da"/>
    <resource>
      <PractitionerRole>
        <id value="fd68a58d-7c6b-483c-83cb-5211687415da"/>
        <practitioner>
          <reference value="urn:uuid:4f0a00b9-9693-46b2-a323-a1d6b079ad17"/>
        </practitioner>
        <organization>
          <reference value="urn:uuid:c23fa7b6-24fd-4aeb-adf9-cae19280a95c"/>
        </organization>
      </PractitionerRole>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:a7bb6064-feed-49f3-a7b4-058553b08c04"/>
    <resource>
      <Specimen>
        <id value="a7bb6064-feed-49f3-a7b4-058553b08c04"/>
        <subject>
          <reference value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        </subject>
        <collection>
          <collectedDateTime value="2025-01-15T14:20:00+02:00"/>
        </collection>
      </Specimen>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:a5ee60ab-687f-4d24-a7c2-12826db5c2d4"/>
    <resource>
      <ServiceRequest>
        <id value="a5ee60ab-687f-4d24-a7c2-12826db5c2d4"/>
        <identifier>
          <value value="26500923675"/>
        </identifier>
        <status value="completed"/>
        <intent value="order"/>
        <code>
          <coding>
            <system value="http://loinc.org"/>
            <code value="9709-7"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        </subject>
        <requester>
          <reference value="urn:uuid:fd68a58d-7c6b-483c-83cb-5211687415da"/>
        </requester>
        <specimen>
          <reference value="urn:uuid:a7bb6064-feed-49f3-a7b4-058553b08c04"/>
        </specimen>
      </ServiceRequest>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:c49f7bcc-40eb-4c23-a58e-90f74a4e1b44"/>
    <resource>
      <DiagnosticReport>
        <id value="c49f7bcc-40eb-4c23-a58e-90f74a4e1b44"/>
        <extension url="http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition">
          <valueReference>
            <reference value="urn:uuid:b88e3a4a-dec6-4815-a622-06a5c30d07b4"/>
          </valueReference>
        </extension>
        <identifier>
          <system value="urn:ietf:rfc:3986"/>
          <value value="urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"/>
        </identifier>
        <basedOn>
          <reference value="urn:uuid:a5ee60ab-687f-4d24-a7c2-12826db5c2d4"/>
        </basedOn>
        <status value="final"/>
        <code>
          <coding>
            <system value="http://loinc.org"/>
            <code value="11502-2"/>
            <display value="Laboratory report"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:9212a59d-af0a-456a-bc90-ed71b9f583e3"/>
        </subject>
        <performer>
          <reference value="urn:uuid:dcf59660-21c9-41a5-a6ee-2c956fe40177"/>
        </performer>
        <specimen>
          <reference value="urn:uuid:a7bb6064-feed-49f3-a7b4-058553b08c04"/>
        </specimen>
        <result>
          <reference value="urn:uuid:f067e8ae-acde-4490-b47f-e3fa400f59b5"/>
        </result>
      </DiagnosticReport>
    </resource>
  </entry>
</Bundle>
```



## Resource Binary Content

application/fhir+xml:

```
{snip}
```
