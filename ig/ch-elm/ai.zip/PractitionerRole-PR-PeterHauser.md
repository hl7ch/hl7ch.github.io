# PR - Peter Hauser @ Praxis Dr. Hauser - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PR - Peter Hauser @ Praxis Dr. Hauser**

## Example PractitionerRole: PR - Peter Hauser @ Praxis Dr. Hauser



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "PR-PeterHauser",
  "practitioner" : {
    "reference" : "Practitioner/Pract-PeterHauser"
  },
  "organization" : {
    "reference" : "Organization/Org-PeterHauser"
  }
}

```
