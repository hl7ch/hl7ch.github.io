# CH ELM Results Sal Org Complete - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CH ELM Results Sal Org Complete**

## ValueSet: CH ELM Results Sal Org Complete 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-sal-org-complete | *Version*:1.13.1 |
| Active as of 2026-01-21 | *Computable Name*:ChElmResultsSalOrgComplete |
| **Copyright/Legal**: CC0-1.0 | |

 
The "CH ELM Results Sal Org Complete" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the "CH ELM Results Sal Org Complete" group should refer to the provided codes to accurately and uniformly capture and report organism-related information. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ch-elm-results-sal-org-complete",
  "url" : "http://fhir.ch/ig/ch-elm/ValueSet/ch-elm-results-sal-org-complete",
  "version" : "1.13.1",
  "name" : "ChElmResultsSalOrgComplete",
  "title" : "CH ELM Results Sal Org Complete",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-01-21T11:21:00+00:00",
  "publisher" : "Federal Office of Public Health FOPH",
  "contact" : [
    {
      "name" : "Federal Office of Public Health FOPH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.bag.admin.ch/bag/en/home/das-bag/kontakt-standort.html"
        }
      ]
    }
  ],
  "description" : "The \"CH ELM Results Sal Org Complete\" organism group provides a curated set of codes representing specific organisms. Each code within this group has been selected to ensure precise representation and consistency in relation to the primary LOINC codes. Clients utilizing the \"CH ELM Results Sal Org Complete\" group should refer to the provided codes to accurately and uniformly capture and report organism-related information.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "CH"
        }
      ]
    }
  ],
  "copyright" : "CC0-1.0",
  "compose" : {
    "include" : [
      {
        "system" : "http://snomed.info/sct",
        "concept" : [
          {
            "code" : "44844006",
            "display" : "Salmonella Zerifin (organism)"
          },
          {
            "code" : "61329007",
            "display" : "Salmonella Kodjovi (organism)"
          },
          {
            "code" : "114683003",
            "display" : "Salmonella Doel (organism)"
          },
          {
            "code" : "21816004",
            "display" : "Salmonella Zaire (organism)"
          },
          {
            "code" : "114815004",
            "display" : "Salmonella Niederoderwitz (organism)"
          },
          {
            "code" : "9818000",
            "display" : "Salmonella Charity (organism)"
          },
          {
            "code" : "404363000",
            "display" : "Salmonella IIIb 35:z52:e,n,x,z15 (organism)"
          },
          {
            "code" : "114600003",
            "display" : "Salmonella II 9,46:g,[m],[s],t:[e,n,x] (organism)"
          },
          {
            "code" : "56064009",
            "display" : "Salmonella Okatie (organism)"
          },
          {
            "code" : "404391008",
            "display" : "Salmonella group O:39 (organism)"
          },
          {
            "code" : "114870001",
            "display" : "Salmonella IIIb 47:l,v:z (organism)"
          },
          {
            "code" : "50027009",
            "display" : "Salmonella Soahanina (organism)"
          },
          {
            "code" : "404296000",
            "display" : "Salmonella II, group O:18 (organism)"
          },
          {
            "code" : "44942009",
            "display" : "Salmonella Trotha (organism)"
          },
          {
            "code" : "398358007",
            "display" : "Salmonella IIIa 63:z4,z32:- (organism)"
          },
          {
            "code" : "76968008",
            "display" : "Salmonella Fajara (organism)"
          },
          {
            "code" : "114413003",
            "display" : "Salmonella IV 16:z4,z32:- (organism)"
          },
          {
            "code" : "398375001",
            "display" : "Salmonella IIIb, group O:58 (organism)"
          },
          {
            "code" : "114575001",
            "display" : "Salmonella II 1,9,12:g,m,s,t:e,n,x (organism)"
          },
          {
            "code" : "6328001",
            "display" : "Salmonella Banjul (organism)"
          },
          {
            "code" : "47685006",
            "display" : "Salmonella Leeuwarden (organism)"
          },
          {
            "code" : "16194002",
            "display" : "Salmonella Solna (organism)"
          },
          {
            "code" : "114750003",
            "display" : "Salmonella Canary (organism)"
          },
          {
            "code" : "114882005",
            "display" : "Salmonella Buckeye (organism)"
          },
          {
            "code" : "35972009",
            "display" : "Salmonella Brunei (organism)"
          },
          {
            "code" : "2527008",
            "display" : "Salmonella II, 1,4,12,27:l,v:z39 (organism)"
          },
          {
            "code" : "114273007",
            "display" : "Salmonella Muenster var 15+ (organism)"
          },
          {
            "code" : "55453006",
            "display" : "Salmonella II 47:z:e,n,x,z15 (organism)"
          },
          {
            "code" : "114692000",
            "display" : "Salmonella II 30:a:z39 (organism)"
          },
          {
            "code" : "114706004",
            "display" : "Salmonella II 35:m,t- (organism)"
          },
          {
            "code" : "73981008",
            "display" : "Salmonella Inchpark (organism)"
          },
          {
            "code" : "65829006",
            "display" : "Salmonella Onireke (organism)"
          },
          {
            "code" : "114665006",
            "display" : "Salmonella IV 21:z4,z23:- (organism)"
          },
          {
            "code" : "16158001",
            "display" : "Salmonella Austin (organism)"
          },
          {
            "code" : "116054000",
            "display" : "Salmonella Omuna (organism)"
          },
          {
            "code" : "17680008",
            "display" : "Salmonella II 9,46:m,t:e,n,x (organism)"
          },
          {
            "code" : "114606009",
            "display" : "Salmonella Nantes (organism)"
          },
          {
            "code" : "114481006",
            "display" : "Salmonella II 1,4,12,27:k:1,6 (organism)"
          },
          {
            "code" : "69775004",
            "display" : "Salmonella Bargny (organism)"
          },
          {
            "code" : "302636007",
            "display" : "Salmonella Stuttgart (organism)"
          },
          {
            "code" : "442104002",
            "display" : "Salmonella enterica subspecies enterica serovar 3,10:-:1,6 (organism)"
          },
          {
            "code" : "114417002",
            "display" : "Salmonella Trier (organism)"
          },
          {
            "code" : "82938006",
            "display" : "Salmonella Fanti (organism)"
          },
          {
            "code" : "404342002",
            "display" : "Salmonella I, group O:35 (organism)"
          },
          {
            "code" : "398424000",
            "display" : "Salmonella IIIb 59:l,v:z53 (organism)"
          },
          {
            "code" : "32624003",
            "display" : "Salmonella Carrau (organism)"
          },
          {
            "code" : "509004",
            "display" : "Salmonella Odozi (organism)"
          },
          {
            "code" : "114890005",
            "display" : "Salmonella II 48:z:1,5 (organism)"
          },
          {
            "code" : "11958001",
            "display" : "Salmonella Niamey (organism)"
          },
          {
            "code" : "404452002",
            "display" : "Salmonella group O:43 (organism)"
          },
          {
            "code" : "12334006",
            "display" : "Salmonella Bijlmer (organism)"
          },
          {
            "code" : "67346002",
            "display" : "Salmonella Kuru (organism)"
          },
          {
            "code" : "85424004",
            "display" : "Salmonella Tilene (organism)"
          },
          {
            "code" : "114946001",
            "display" : "Salmonella II 52:z44:1,5,7 (organism)"
          },
          {
            "code" : "74731002",
            "display" : "Salmonella II, group O:57 (organism)"
          },
          {
            "code" : "114397000",
            "display" : "Salmonella II 16:e,n,x:1,6:z42 (organism)"
          },
          {
            "code" : "82243005",
            "display" : "Salmonella Kaolack (organism)"
          },
          {
            "code" : "86585006",
            "display" : "Salmonella IV 38:g,z51:- (organism)"
          },
          {
            "code" : "114836002",
            "display" : "Salmonella Bolama (organism)"
          },
          {
            "code" : "74092000",
            "display" : "Salmonella Fortune (organism)"
          },
          {
            "code" : "62340001",
            "display" : "Salmonella Kivu (organism)"
          },
          {
            "code" : "46399008",
            "display" : "Salmonella Apapa (organism)"
          },
          {
            "code" : "114386000",
            "display" : "Salmonella Arapahoe (organism)"
          },
          {
            "code" : "62866008",
            "display" : "Salmonella Kirkee (organism)"
          },
          {
            "code" : "114314008",
            "display" : "Salmonella II 11:a:d:e,n,z15 (organism)"
          },
          {
            "code" : "404615005",
            "display" : "Salmonella IIIb 50:z10:z53 (organism)"
          },
          {
            "code" : "35454005",
            "display" : "Salmonella Oslo (organism)"
          },
          {
            "code" : "302700002",
            "display" : "Salmonella 13,22:a:e,n,x (organism)"
          },
          {
            "code" : "53391009",
            "display" : "Salmonella Fass (organism)"
          },
          {
            "code" : "404444000",
            "display" : "Salmonella IIIa 42:r:- (organism)"
          },
          {
            "code" : "404331006",
            "display" : "Salmonella Rhone (organism)"
          },
          {
            "code" : "19190005",
            "display" : "Salmonella Flottbek (organism)"
          },
          {
            "code" : "64341001",
            "display" : "Salmonella II 56:e,n,x:1,7 (organism)"
          },
          {
            "code" : "114679003",
            "display" : "Salmonella II 28:I,z28:1,5 (organism)"
          },
          {
            "code" : "25535004",
            "display" : "Salmonella Beaudesert (organism)"
          },
          {
            "code" : "20266009",
            "display" : "Salmonella Glidji (organism)"
          },
          {
            "code" : "11379008",
            "display" : "Salmonella Ughelli (organism)"
          },
          {
            "code" : "75486009",
            "display" : "Salmonella Stratford (organism)"
          },
          {
            "code" : "404461002",
            "display" : "Salmonella IIIb 43:r:z (organism)"
          },
          {
            "code" : "114367008",
            "display" : "Salmonella IIIa 13,23:z4,z23,[z32]:- (organism)"
          },
          {
            "code" : "58933004",
            "display" : "Salmonella Remete (organism)"
          },
          {
            "code" : "17019004",
            "display" : "Salmonella Blijdorp (organism)"
          },
          {
            "code" : "62146001",
            "display" : "Salmonella Wuiti (organism)"
          },
          {
            "code" : "40821004",
            "display" : "Salmonella Nchanga (organism)"
          },
          {
            "code" : "398562000",
            "display" : "Salmonella IIIb (6),14:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "69573008",
            "display" : "Salmonella Egusi (organism)"
          },
          {
            "code" : "85538009",
            "display" : "Salmonella Garba (organism)"
          },
          {
            "code" : "114797002",
            "display" : "Salmonella IV 1,42:g,z51:- (organism)"
          },
          {
            "code" : "398335009",
            "display" : "Salmonella IIIb 61:z52:z35 (organism)"
          },
          {
            "code" : "115000007",
            "display" : "Salmonella V 66:z39:- (organism)"
          },
          {
            "code" : "398403005",
            "display" : "Salmonella II 3,10:z4,z24:- (organism)"
          },
          {
            "code" : "398605007",
            "display" : "Salmonella IIIb 59:i:z35 (organism)"
          },
          {
            "code" : "25382005",
            "display" : "Salmonella Sharon (organism)"
          },
          {
            "code" : "404607007",
            "display" : "Salmonella IIIb 50:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "114570006",
            "display" : "Salmonella Eschberg (organism)"
          },
          {
            "code" : "28865004",
            "display" : "Salmonella Umhlali (organism)"
          },
          {
            "code" : "71107002",
            "display" : "Salmonella Seegefeld (organism)"
          },
          {
            "code" : "25767003",
            "display" : "Salmonella Liverpool (organism)"
          },
          {
            "code" : "112286004",
            "display" : "Salmonella Altendorf (organism)"
          },
          {
            "code" : "398458008",
            "display" : "Salmonella IIIb 60:z52:z (organism)"
          },
          {
            "code" : "17939003",
            "display" : "Salmonella Lomita (organism)"
          },
          {
            "code" : "40427007",
            "display" : "Salmonella Hann (organism)"
          },
          {
            "code" : "404552004",
            "display" : "Salmonella IIIb 47:z10:z (organism)"
          },
          {
            "code" : "34778008",
            "display" : "Salmonella Maryland (organism)"
          },
          {
            "code" : "398376000",
            "display" : "Salmonella II 9,12:l,v:e,n,x (organism)"
          },
          {
            "code" : "404365007",
            "display" : "Salmonella IIIb 35:z52:z35 (organism)"
          },
          {
            "code" : "28932006",
            "display" : "Salmonella Wayne (organism)"
          },
          {
            "code" : "86876004",
            "display" : "Salmonella Entebbe (organism)"
          },
          {
            "code" : "74613008",
            "display" : "Salmonella Trachau (organism)"
          },
          {
            "code" : "68218004",
            "display" : "Salmonella Kimberley (organism)"
          },
          {
            "code" : "114478001",
            "display" : "Salmonella Farsta (organism)"
          },
          {
            "code" : "54836002",
            "display" : "Salmonella Wedding (organism)"
          },
          {
            "code" : "302688000",
            "display" : "Salmonella Svedvi (organism)"
          },
          {
            "code" : "114772001",
            "display" : "Salmonella VI 41:b:1,7 (organism)"
          },
          {
            "code" : "404337005",
            "display" : "Salmonella II 28:r:e,n,z15 (organism)"
          },
          {
            "code" : "54354005",
            "display" : "Salmonella Kaapstad (organism)"
          },
          {
            "code" : "47732006",
            "display" : "Salmonella Kano (organism)"
          },
          {
            "code" : "59107001",
            "display" : "Salmonella Fluntern (organism)"
          },
          {
            "code" : "302746002",
            "display" : "Salmonella II 45:z29:e,n,x (organism)"
          },
          {
            "code" : "41176000",
            "display" : "Salmonella Nigeria (organism)"
          },
          {
            "code" : "114651009",
            "display" : "Salmonella IIIb 21:c:e,n,x,z15 (organism)"
          },
          {
            "code" : "114268001",
            "display" : "Salmonella Goelzau var 15+ (organism)"
          },
          {
            "code" : "71614001",
            "display" : "Salmonella Ouakam (organism)"
          },
          {
            "code" : "81528009",
            "display" : "Salmonella II 38:b:1,2 (organism)"
          },
          {
            "code" : "404533005",
            "display" : "Salmonella IIIb 47:i:z (organism)"
          },
          {
            "code" : "404604000",
            "display" : "Salmonella IIIb 50:k:z (organism)"
          },
          {
            "code" : "10454004",
            "display" : "Salmonella Newlands (organism)"
          },
          {
            "code" : "114285004",
            "display" : "Salmonella Orion var 15+ (organism)"
          },
          {
            "code" : "18238001",
            "display" : "Salmonella IV 48:z4,z32:- (organism)"
          },
          {
            "code" : "404389000",
            "display" : "Salmonella IIIb 38:z52:z35 (organism)"
          },
          {
            "code" : "84287002",
            "display" : "Salmonella Duval (organism)"
          },
          {
            "code" : "38130005",
            "display" : "Salmonella Adamstown (organism)"
          },
          {
            "code" : "31557009",
            "display" : "Salmonella Pretoria (organism)"
          },
          {
            "code" : "114625007",
            "display" : "Salmonella Serrekunda (organism)"
          },
          {
            "code" : "114647007",
            "display" : "Salmonella II 18:z36:- (organism)"
          },
          {
            "code" : "128388007",
            "display" : "Salmonella Paratyphi B var. Java (organism)"
          },
          {
            "code" : "16363006",
            "display" : "Salmonella II 42:z6:1,6 (organism)"
          },
          {
            "code" : "77447006",
            "display" : "Salmonella II 48:b:z6 (organism)"
          },
          {
            "code" : "398508004",
            "display" : "Salmonella enterica subsp. enterica (organism)"
          },
          {
            "code" : "19118002",
            "display" : "Salmonella Ahepe (organism)"
          },
          {
            "code" : "404304008",
            "display" : "Salmonella IIIb 18:(k):z54 (organism)"
          },
          {
            "code" : "398466004",
            "display" : "Salmonella enterica subspecies enterica serovar Butantan var O:15, 34+ (organism)"
          },
          {
            "code" : "112301008",
            "display" : "Salmonella Adabraka (organism)"
          },
          {
            "code" : "16820003",
            "display" : "Salmonella Goldcoast (organism)"
          },
          {
            "code" : "86992008",
            "display" : "Salmonella Washington (organism)"
          },
          {
            "code" : "404305009",
            "display" : "Salmonella IIIa 18:g,z51:- (organism)"
          },
          {
            "code" : "398364000",
            "display" : "Salmonella group O:8 (organism)"
          },
          {
            "code" : "114705000",
            "display" : "Salmonella II 35:g,t:1,5 (organism)"
          },
          {
            "code" : "18129006",
            "display" : "Salmonella Ghana (organism)"
          },
          {
            "code" : "86656007",
            "display" : "Salmonella Krefeld (organism)"
          },
          {
            "code" : "114398005",
            "display" : "Salmonella II 16:g,[m],[s],t:[1,5]:[z42] (organism)"
          },
          {
            "code" : "17036007",
            "display" : "Salmonella Djibouti (organism)"
          },
          {
            "code" : "23057001",
            "display" : "Salmonella II 40:b:- (organism)"
          },
          {
            "code" : "66197006",
            "display" : "Salmonella Goverdhan (organism)"
          },
          {
            "code" : "114839009",
            "display" : "Salmonella Llobregat (organism)"
          },
          {
            "code" : "15168000",
            "display" : "Salmonella II 41:l,z13,z28:e,n,x,z15 (organism)"
          },
          {
            "code" : "31900005",
            "display" : "Salmonella Umhlatazana (organism)"
          },
          {
            "code" : "404410007",
            "display" : "Salmonella IIIa 40:z4,z23:- (organism)"
          },
          {
            "code" : "81834006",
            "display" : "Salmonella Sekondi (organism)"
          },
          {
            "code" : "55485009",
            "display" : "Salmonella Mishmarhaemek (organism)"
          },
          {
            "code" : "39761002",
            "display" : "Salmonella Shamba (organism)"
          },
          {
            "code" : "88255008",
            "display" : "Salmonella Haifa (organism)"
          },
          {
            "code" : "75329000",
            "display" : "Salmonella Casablanca (organism)"
          },
          {
            "code" : "398592009",
            "display" : "Salmonella IIIb 61:r:z53 (organism)"
          },
          {
            "code" : "75848006",
            "display" : "Salmonella Abaetetuba (organism)"
          },
          {
            "code" : "114675009",
            "display" : "Salmonella Morillons (organism)"
          },
          {
            "code" : "398609001",
            "display" : "Salmonella VI, group O:11 (organism)"
          },
          {
            "code" : "114821000",
            "display" : "Salmonella Voulte (organism)"
          },
          {
            "code" : "45651006",
            "display" : "Salmonella Schwarzengrund (organism)"
          },
          {
            "code" : "39664003",
            "display" : "Salmonella Kottbus (organism)"
          },
          {
            "code" : "55395003",
            "display" : "Salmonella Saarbruecken (organism)"
          },
          {
            "code" : "114801001",
            "display" : "Salmonella II 1,42:l,w:e,n,x (organism)"
          },
          {
            "code" : "60677006",
            "display" : "Salmonella Spartel (organism)"
          },
          {
            "code" : "26003002",
            "display" : "Salmonella Bedford (organism)"
          },
          {
            "code" : "404579000",
            "display" : "Salmonella IIIb 48:r:z (organism)"
          },
          {
            "code" : "79905007",
            "display" : "Salmonella Anecho (organism)"
          },
          {
            "code" : "64975005",
            "display" : "Salmonella Chicago (organism)"
          },
          {
            "code" : "404482008",
            "display" : "Salmonella group O:45 (organism)"
          },
          {
            "code" : "114985008",
            "display" : "Salmonella IIIb 60:i:z (organism)"
          },
          {
            "code" : "404343007",
            "display" : "Salmonella II, group O:35 (organism)"
          },
          {
            "code" : "114699009",
            "display" : "Salmonella Grandhaven (organism)"
          },
          {
            "code" : "18163008",
            "display" : "Salmonella Senftenberg (organism)"
          },
          {
            "code" : "61355008",
            "display" : "Salmonella Logone (organism)"
          },
          {
            "code" : "114518005",
            "display" : "Salmonella II 6,7:z4,z24:z42 (organism)"
          },
          {
            "code" : "404450005",
            "display" : "Salmonella IIIa 42:z4,z24:- (organism)"
          },
          {
            "code" : "37265001",
            "display" : "Salmonella II 6,8:l,v:e,n,x (organism)"
          },
          {
            "code" : "404348003",
            "display" : "Salmonella IIIb 35:(k):z (organism)"
          },
          {
            "code" : "114464002",
            "display" : "Salmonella II 1,4,12,27:a:z39 (organism)"
          },
          {
            "code" : "70689009",
            "display" : "Salmonella Yarrabah (organism)"
          },
          {
            "code" : "114866009",
            "display" : "Salmonella II 47:b:z6 (organism)"
          },
          {
            "code" : "404537006",
            "display" : "Salmonella IIIb 47:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "26793003",
            "display" : "Salmonella II 6,8:z29:1,5 (organism)"
          },
          {
            "code" : "114659006",
            "display" : "Salmonella Ibaragi (organism)"
          },
          {
            "code" : "54693005",
            "display" : "Salmonella Lerum (organism)"
          },
          {
            "code" : "52488001",
            "display" : "Salmonella Nowawes (organism)"
          },
          {
            "code" : "1888009",
            "display" : "Salmonella Wingrove (organism)"
          },
          {
            "code" : "26225002",
            "display" : "Salmonella II 3,10:a:z39 (organism)"
          },
          {
            "code" : "404409002",
            "display" : "Salmonella IIIa 40:z36:- (organism)"
          },
          {
            "code" : "114391004",
            "display" : "Salmonella IIIb 6,14:z10:z53 (organism)"
          },
          {
            "code" : "8058007",
            "display" : "Salmonella Sinthia (organism)"
          },
          {
            "code" : "114470008",
            "display" : "Salmonella II 4,12:e,n,x:1,2,7 (organism)"
          },
          {
            "code" : "404354002",
            "display" : "Salmonella IIIb 35:l,v:1,5,7 (organism)"
          },
          {
            "code" : "114694004",
            "display" : "Salmonella II 30:g,t:- (organism)"
          },
          {
            "code" : "52204003",
            "display" : "Salmonella Romanby (organism)"
          },
          {
            "code" : "40314007",
            "display" : "Salmonella IV 43:z4:z24:- (organism)"
          },
          {
            "code" : "90756007",
            "display" : "Salmonella Presov (organism)"
          },
          {
            "code" : "40618004",
            "display" : "Salmonella Visby (organism)"
          },
          {
            "code" : "398445007",
            "display" : "Salmonella I, group O:11 (organism)"
          },
          {
            "code" : "398590001",
            "display" : "Salmonella IIIb 57:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "114799004",
            "display" : "Salmonella IIIb 42:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "51446008",
            "display" : "Salmonella Apeyeme (organism)"
          },
          {
            "code" : "114354005",
            "display" : "Salmonella II 1,13,23:m,t:1,5 (organism)"
          },
          {
            "code" : "63396002",
            "display" : "Salmonella Reading (organism)"
          },
          {
            "code" : "114700005",
            "display" : "Salmonella Stoneferry (organism)"
          },
          {
            "code" : "61304001",
            "display" : "Salmonella Hatfield (organism)"
          },
          {
            "code" : "62441003",
            "display" : "Salmonella Drogana (organism)"
          },
          {
            "code" : "398584000",
            "display" : "Salmonella I, group O:8 (organism)"
          },
          {
            "code" : "398471006",
            "display" : "Salmonella IIIb 52:l,v:z53 (organism)"
          },
          {
            "code" : "84173008",
            "display" : "Salmonella Usumbura (organism)"
          },
          {
            "code" : "105773005",
            "display" : "Salmonella group O:58 (organism)"
          },
          {
            "code" : "67207001",
            "display" : "Salmonella Koumra (organism)"
          },
          {
            "code" : "76425002",
            "display" : "Salmonella II 3,10:b:z39 (organism)"
          },
          {
            "code" : "398396008",
            "display" : "Salmonella IV 51:z4,z23:- (organism)"
          },
          {
            "code" : "398573007",
            "display" : "Salmonella IIIb 53:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "60651003",
            "display" : "Salmonella Meleagridis (organism)"
          },
          {
            "code" : "398495008",
            "display" : "Salmonella IIIb 60:z52:z53 (organism)"
          },
          {
            "code" : "55580001",
            "display" : "Salmonella Daytona (organism)"
          },
          {
            "code" : "398382002",
            "display" : "Salmonella IIIb 60:i:z35 (organism)"
          },
          {
            "code" : "114885007",
            "display" : "Salmonella IV 48:g,z51:- (organism)"
          },
          {
            "code" : "42173006",
            "display" : "Salmonella Bukuru (organism)"
          },
          {
            "code" : "404464005",
            "display" : "Salmonella IIIa 43:z4,z23:- (organism)"
          },
          {
            "code" : "114763009",
            "display" : "Salmonella II 1,40:z39:1,5:z42 (organism)"
          },
          {
            "code" : "114712009",
            "display" : "Salmonella II 35:z29:e,n,x (organism)"
          },
          {
            "code" : "115003009",
            "display" : "Salmonella V 66:z81:- (organism)"
          },
          {
            "code" : "15319009",
            "display" : "Salmonella Ealing (organism)"
          },
          {
            "code" : "69006005",
            "display" : "Salmonella Kabete (organism)"
          },
          {
            "code" : "63485009",
            "display" : "Salmonella Southbank (organism)"
          },
          {
            "code" : "398397004",
            "display" : "Salmonella IIIb 65:z52:z35 (organism)"
          },
          {
            "code" : "20855009",
            "display" : "Salmonella Pullorum (organism)"
          },
          {
            "code" : "398390002",
            "display" : "Salmonella II, group O:3,10 (organism)"
          },
          {
            "code" : "302653000",
            "display" : "Salmonella Daarle (organism)"
          },
          {
            "code" : "19958004",
            "display" : "Salmonella Marylebone (organism)"
          },
          {
            "code" : "114362002",
            "display" : "Salmonella V 13,22:r:- (organism)"
          },
          {
            "code" : "85576003",
            "display" : "Salmonella Ramsey (organism)"
          },
          {
            "code" : "114724002",
            "display" : "Salmonella IIIb 38:z53:- (organism)"
          },
          {
            "code" : "441745001",
            "display" : "Salmonella enterica subspecies enterica serovar 4,[5],12:b:- (organism)"
          },
          {
            "code" : "404275007",
            "display" : "Salmonella group O:17 (organism)"
          },
          {
            "code" : "114786002",
            "display" : "Salmonella IV 41:z29:- (organism)"
          },
          {
            "code" : "114896004",
            "display" : "Salmonella IV 48:z29:- (organism)"
          },
          {
            "code" : "404393006",
            "display" : "Salmonella II, group O:39 (organism)"
          },
          {
            "code" : "114730002",
            "display" : "Salmonella II 39:l,v:1,5 (organism)"
          },
          {
            "code" : "25695005",
            "display" : "Salmonella Umbilo (organism)"
          },
          {
            "code" : "114414009",
            "display" : "Salmonella Badgary (organism)"
          },
          {
            "code" : "71443004",
            "display" : "Salmonella Sinstorf (organism)"
          },
          {
            "code" : "404299007",
            "display" : "Salmonella IV, group O:18 (organism)"
          },
          {
            "code" : "398412007",
            "display" : "Salmonella IIIb 60:z10:z35 (organism)"
          },
          {
            "code" : "21242009",
            "display" : "Salmonella Mango (organism)"
          },
          {
            "code" : "404369001",
            "display" : "Salmonella IIIa, group O:38 (organism)"
          },
          {
            "code" : "114596008",
            "display" : "Salmonella Cheltenham (organism)"
          },
          {
            "code" : "34547007",
            "display" : "Salmonella Eastbourne (organism)"
          },
          {
            "code" : "19828009",
            "display" : "Salmonella Neukoelln (organism)"
          },
          {
            "code" : "4005005",
            "display" : "Salmonella Jamaica (organism)"
          },
          {
            "code" : "3708006",
            "display" : "Salmonella Uno (organism)"
          },
          {
            "code" : "53510005",
            "display" : "Salmonella Orlando (organism)"
          },
          {
            "code" : "114621003",
            "display" : "Salmonella II 3,10:m,t:1,5 (organism)"
          },
          {
            "code" : "398558006",
            "display" : "Salmonella IIIb 65:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "1009003",
            "display" : "Salmonella Oakland (organism)"
          },
          {
            "code" : "78893002",
            "display" : "Salmonella Maiduguri (organism)"
          },
          {
            "code" : "404531007",
            "display" : "Salmonella IIIb 47:c:z35 (organism)"
          },
          {
            "code" : "404315003",
            "display" : "Salmonella IV, group O:21 (organism)"
          },
          {
            "code" : "51312006",
            "display" : "Salmonella Leipzig (organism)"
          },
          {
            "code" : "5929008",
            "display" : "Salmonella Virchow (organism)"
          },
          {
            "code" : "14145004",
            "display" : "Salmonella Gdansk (organism)"
          },
          {
            "code" : "67457006",
            "display" : "Salmonella Goelzau (organism)"
          },
          {
            "code" : "79238006",
            "display" : "Salmonella Dapango (organism)"
          },
          {
            "code" : "19430004",
            "display" : "Salmonella Fitzroy (organism)"
          },
          {
            "code" : "398453004",
            "display" : "Salmonella IIIb 60:r:z35 (organism)"
          },
          {
            "code" : "51196000",
            "display" : "Salmonella Bonariensis (organism)"
          },
          {
            "code" : "5864000",
            "display" : "Salmonella Baildon (organism)"
          },
          {
            "code" : "51518009",
            "display" : "Salmonella Giessen (organism)"
          },
          {
            "code" : "9433002",
            "display" : "Salmonella Allandale (organism)"
          },
          {
            "code" : "114544005",
            "display" : "Salmonella II 6,8:b:1,5 (organism)"
          },
          {
            "code" : "4311001",
            "display" : "Salmonella Coleypark (organism)"
          },
          {
            "code" : "114756009",
            "display" : "Salmonella II 1,40:z:z39 (organism)"
          },
          {
            "code" : "75293006",
            "display" : "Salmonella II 18:m,t:1,5 (organism)"
          },
          {
            "code" : "114658003",
            "display" : "Salmonella IIIb 21:r:z (organism)"
          },
          {
            "code" : "62365004",
            "display" : "Salmonella Farakan (organism)"
          },
          {
            "code" : "398484002",
            "display" : "Salmonella IIIb 61:z10:z35 (organism)"
          },
          {
            "code" : "114932001",
            "display" : "Salmonella Moundou (organism)"
          },
          {
            "code" : "67282009",
            "display" : "Salmonella Bury (organism)"
          },
          {
            "code" : "114373009",
            "display" : "Salmonella II 1,13,23:[z42]:1,[5],7 (organism)"
          },
          {
            "code" : "2434007",
            "display" : "Salmonella Uganda (organism)"
          },
          {
            "code" : "114714005",
            "display" : "Salmonella II 38:d:1,5 (organism)"
          },
          {
            "code" : "42675003",
            "display" : "Salmonella Gustavia (organism)"
          },
          {
            "code" : "114813006",
            "display" : "Salmonella Tema (organism)"
          },
          {
            "code" : "79596009",
            "display" : "Salmonella Ligna (organism)"
          },
          {
            "code" : "114623000",
            "display" : "Salmonella Tibati (organism)"
          },
          {
            "code" : "404300004",
            "display" : "Salmonella IIIa 18:z4,z23:- (organism)"
          },
          {
            "code" : "114602006",
            "display" : "Salmonella Ackwepe (organism)"
          },
          {
            "code" : "59384004",
            "display" : "Salmonella Selby (organism)"
          },
          {
            "code" : "84293005",
            "display" : "Salmonella Leatherhead (organism)"
          },
          {
            "code" : "114984007",
            "display" : "Salmonella II 60:g,m,t:z6 (organism)"
          },
          {
            "code" : "41655009",
            "display" : "Salmonella II 6,14:k:(e,n,x) (organism)"
          },
          {
            "code" : "131283004",
            "display" : "Salmonella serotype B, 5:d:- (organism)"
          },
          {
            "code" : "39185004",
            "display" : "Salmonella Casamance (organism)"
          },
          {
            "code" : "56929002",
            "display" : "Salmonella Assen (organism)"
          },
          {
            "code" : "46793007",
            "display" : "Salmonella Landau (organism)"
          },
          {
            "code" : "712806004",
            "display" : "Salmonella Enteritidis phage type 14b (organism)"
          },
          {
            "code" : "114811008",
            "display" : "Salmonella IIIb 42:z10:z67 (organism)"
          },
          {
            "code" : "75048007",
            "display" : "Salmonella Nashua (organism)"
          },
          {
            "code" : "404617002",
            "display" : "Salmonella IIIa 50:z29:- (organism)"
          },
          {
            "code" : "61388001",
            "display" : "Salmonella Teltow (organism)"
          },
          {
            "code" : "114775004",
            "display" : "Salmonella II 41:g,t:- (organism)"
          },
          {
            "code" : "69027000",
            "display" : "Salmonella Sya (organism)"
          },
          {
            "code" : "112300009",
            "display" : "Salmonella Yaba (organism)"
          },
          {
            "code" : "67810001",
            "display" : "Salmonella Lika (organism)"
          },
          {
            "code" : "36282006",
            "display" : "Salmonella Yolo (organism)"
          },
          {
            "code" : "114641008",
            "display" : "Salmonella IIIb 18:l,v:z53 (organism)"
          },
          {
            "code" : "39531008",
            "display" : "Salmonella II 9,46:z10:z39 (organism)"
          },
          {
            "code" : "114441004",
            "display" : "Salmonella II 17:z:l,w:z42 (organism)"
          },
          {
            "code" : "19368001",
            "display" : "Salmonella Babelsberg (organism)"
          },
          {
            "code" : "416057009",
            "display" : "Salmonella Choleraesuis var. Decatur (organism)"
          },
          {
            "code" : "5595000",
            "display" : "Salmonella Typhi (organism)"
          },
          {
            "code" : "398377009",
            "display" : "Salmonella IIIb, group O:51 (organism)"
          },
          {
            "code" : "114341003",
            "display" : "Salmonella IIIa 11:z4,z23:- (organism)"
          },
          {
            "code" : "74630005",
            "display" : "Salmonella Hofit (organism)"
          },
          {
            "code" : "114365000",
            "display" : "Salmonella II 13,22:z:- (organism)"
          },
          {
            "code" : "114916004",
            "display" : "Salmonella IIIb 50:z:z52 (organism)"
          },
          {
            "code" : "28124002",
            "display" : "Salmonella Utah (organism)"
          },
          {
            "code" : "56950006",
            "display" : "Salmonella II 48:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "57475009",
            "display" : "Salmonella II 57:d:1,5 (organism)"
          },
          {
            "code" : "114360005",
            "display" : "Salmonella II 13,23:l,w:e,n,x (organism)"
          },
          {
            "code" : "76921003",
            "display" : "Salmonella Gatow (organism)"
          },
          {
            "code" : "75447005",
            "display" : "Salmonella Straengnaes (organism)"
          },
          {
            "code" : "40685009",
            "display" : "Salmonella Demerara (organism)"
          },
          {
            "code" : "114662009",
            "display" : "Salmonella II 21:z10:[z6] (organism)"
          },
          {
            "code" : "404341009",
            "display" : "Salmonella group O:35 (organism)"
          },
          {
            "code" : "29090008",
            "display" : "Salmonella Zanzibar (organism)"
          },
          {
            "code" : "21176005",
            "display" : "Salmonella Rogy (organism)"
          },
          {
            "code" : "10353006",
            "display" : "Salmonella Bournemouth (organism)"
          },
          {
            "code" : "57924003",
            "display" : "Salmonella Oldenburg (organism)"
          },
          {
            "code" : "404587004",
            "display" : "Salmonella IIIa 48:g,z51:- (organism)"
          },
          {
            "code" : "40697005",
            "display" : "Salmonella Berta (organism)"
          },
          {
            "code" : "114525003",
            "display" : "Salmonella Tampico (organism)"
          },
          {
            "code" : "20031000",
            "display" : "Salmonella Berkeley (organism)"
          },
          {
            "code" : "66714006",
            "display" : "Salmonella Pharr (organism)"
          },
          {
            "code" : "398395007",
            "display" : "Salmonella IIIb 52:k:z53 (organism)"
          },
          {
            "code" : "398483008",
            "display" : "Salmonella Lomalinda (organism)"
          },
          {
            "code" : "404556001",
            "display" : "Salmonella IIIb 47:z52:z (organism)"
          },
          {
            "code" : "114557002",
            "display" : "Salmonella Phaliron (organism)"
          },
          {
            "code" : "114735007",
            "display" : "Salmonella II 40:a:z39 (organism)"
          },
          {
            "code" : "42971009",
            "display" : "Salmonella Dougi (organism)"
          },
          {
            "code" : "58761004",
            "display" : "Salmonella Victoriaborg (organism)"
          },
          {
            "code" : "404314004",
            "display" : "Salmonella IIIb, group O:21 (organism)"
          },
          {
            "code" : "77349005",
            "display" : "Salmonella Poeseldorf (organism)"
          },
          {
            "code" : "114370007",
            "display" : "Salmonella II 13,22:z29:e,n,x (organism)"
          },
          {
            "code" : "398345006",
            "display" : "Salmonella II, group O:59 (organism)"
          },
          {
            "code" : "3835006",
            "display" : "Salmonella Colobane (organism)"
          },
          {
            "code" : "114656004",
            "display" : "Salmonella Jambur (organism)"
          },
          {
            "code" : "114352009",
            "display" : "Salmonella II 1,13,23:g,t:1,5 (organism)"
          },
          {
            "code" : "114868005",
            "display" : "Salmonella II 47:e,n,x,z15:1,6 (organism)"
          },
          {
            "code" : "114597004",
            "display" : "Salmonella II 9,46:b:e,n,x (organism)"
          },
          {
            "code" : "59794006",
            "display" : "Salmonella Yerba (organism)"
          },
          {
            "code" : "114548008",
            "display" : "Salmonella II 6,8:m,t:e,n,x (organism)"
          },
          {
            "code" : "68916009",
            "display" : "Salmonella Muenster (organism)"
          },
          {
            "code" : "32122000",
            "display" : "Salmonella Nessa (organism)"
          },
          {
            "code" : "114919006",
            "display" : "Salmonella IV 50:z4,z32:- (organism)"
          },
          {
            "code" : "363760001",
            "display" : "Salmonella IIIb 48:k:1,5,(7) (organism)"
          },
          {
            "code" : "83141008",
            "display" : "Salmonella Kedougou (organism)"
          },
          {
            "code" : "1179074001",
            "display" : "Salmonella group E (organism)"
          },
          {
            "code" : "46667007",
            "display" : "Salmonella Oranienburg (organism)"
          },
          {
            "code" : "69053008",
            "display" : "Salmonella Ardwick (organism)"
          },
          {
            "code" : "114396009",
            "display" : "Salmonella II 16:e,n,x:1,(5),7 (organism)"
          },
          {
            "code" : "31093000",
            "display" : "Salmonella Ekotedo (organism)"
          },
          {
            "code" : "404438004",
            "display" : "Salmonella IIIa 42:g,z51:- (organism)"
          },
          {
            "code" : "398460005",
            "display" : "Salmonella II, group O:9,46 (organism)"
          },
          {
            "code" : "35647006",
            "display" : "Salmonella Avonmouth (organism)"
          },
          {
            "code" : "114754007",
            "display" : "Salmonella II 1,40:l,z28:z39 (organism)"
          },
          {
            "code" : "91477002",
            "display" : "Salmonella Fomeco (organism)"
          },
          {
            "code" : "404346004",
            "display" : "Salmonella IIIa 35:z4,z23:- (organism)"
          },
          {
            "code" : "6938001",
            "display" : "Salmonella Carmel (organism)"
          },
          {
            "code" : "72828006",
            "display" : "Salmonella Kidderminster (organism)"
          },
          {
            "code" : "114301007",
            "display" : "Salmonella Hayindogo (organism)"
          },
          {
            "code" : "65830001",
            "display" : "Salmonella Ngor (organism)"
          },
          {
            "code" : "48950006",
            "display" : "Salmonella II 9,12:m,t:e,n,x (organism)"
          },
          {
            "code" : "55975004",
            "display" : "Salmonella Cleveland (organism)"
          },
          {
            "code" : "398538005",
            "display" : "Salmonella IIIb 61:l,v:z (organism)"
          },
          {
            "code" : "302660006",
            "display" : "Salmonella II 1,9,12:g,m,[s],t:[1,5,7]:[z42] (organism)"
          },
          {
            "code" : "398486000",
            "display" : "Salmonella IIIb 1,6,14,25:z52:z35 (organism)"
          },
          {
            "code" : "66105008",
            "display" : "Salmonella Nieukerk (organism)"
          },
          {
            "code" : "404303002",
            "display" : "Salmonella IIIb 18:(k):z53 (organism)"
          },
          {
            "code" : "77145008",
            "display" : "Salmonella Steinwerder (organism)"
          },
          {
            "code" : "20862000",
            "display" : "Salmonella Soerenga (organism)"
          },
          {
            "code" : "71541000",
            "display" : "Salmonella Westphalia (organism)"
          },
          {
            "code" : "404309003",
            "display" : "Salmonella IIIa 18:z4,z32:- (organism)"
          },
          {
            "code" : "114860003",
            "display" : "Salmonella Aprad (organism)"
          },
          {
            "code" : "31602000",
            "display" : "Salmonella Businga (organism)"
          },
          {
            "code" : "404408005",
            "display" : "Salmonella IIIa 40:z29:- (organism)"
          },
          {
            "code" : "398516008",
            "display" : "Salmonella IIIa, group O:53 (organism)"
          },
          {
            "code" : "404280003",
            "display" : "Salmonella IV, group O:17 (organism)"
          },
          {
            "code" : "404313005",
            "display" : "Salmonella IIIa, group O:21 (organism)"
          },
          {
            "code" : "41533007",
            "display" : "Salmonella Israel (organism)"
          },
          {
            "code" : "114615002",
            "display" : "Salmonella II 3,10:a:e,n,x (organism)"
          },
          {
            "code" : "398526001",
            "display" : "Salmonella IV, group O:16 (organism)"
          },
          {
            "code" : "78780001",
            "display" : "Salmonella Colorado (organism)"
          },
          {
            "code" : "62272001",
            "display" : "Salmonella Newyork (organism)"
          },
          {
            "code" : "82241007",
            "display" : "Salmonella Encino (organism)"
          },
          {
            "code" : "9459004",
            "display" : "Salmonella Toricada (organism)"
          },
          {
            "code" : "12470005",
            "display" : "Salmonella Bandia (organism)"
          },
          {
            "code" : "3288007",
            "display" : "Salmonella II 65:-:1,6 (organism)"
          },
          {
            "code" : "114879000",
            "display" : "Salmonella V 48:b:- (organism)"
          },
          {
            "code" : "114816003",
            "display" : "Salmonella II 43:b:z42 (organism)"
          },
          {
            "code" : "88931007",
            "display" : "Salmonella Yehuda (organism)"
          },
          {
            "code" : "114865008",
            "display" : "Salmonella II 47:b:e,n,x,z15 (organism)"
          },
          {
            "code" : "77117002",
            "display" : "Salmonella II 16:z6:1,6 (organism)"
          },
          {
            "code" : "398612003",
            "display" : "Salmonella IIIb 60:r:z53 (organism)"
          },
          {
            "code" : "114479009",
            "display" : "Salmonella Tumodi (organism)"
          },
          {
            "code" : "53459007",
            "display" : "Salmonella Kalumburu (organism)"
          },
          {
            "code" : "64842001",
            "display" : "Salmonella Haardt (organism)"
          },
          {
            "code" : "7830000",
            "display" : "Salmonella Hallfold (organism)"
          },
          {
            "code" : "114624006",
            "display" : "Salmonella Hoboken (organism)"
          },
          {
            "code" : "114743002",
            "display" : "Salmonella II 40:g,t:z39 (organism)"
          },
          {
            "code" : "51716006",
            "display" : "Salmonella Nyeko (organism)"
          },
          {
            "code" : "404592002",
            "display" : "Salmonella IIIb, group O:50 (organism)"
          },
          {
            "code" : "302665001",
            "display" : "Salmonella II 1,9,12:z42:1,[5],7 (organism)"
          },
          {
            "code" : "2291004",
            "display" : "Salmonella London (organism)"
          },
          {
            "code" : "9004006",
            "display" : "Salmonella Aderike (organism)"
          },
          {
            "code" : "404324007",
            "display" : "Salmonella IIIb 21:k:z (organism)"
          },
          {
            "code" : "114511004",
            "display" : "Salmonella II 6,7:l,z28:e,n,x (organism)"
          },
          {
            "code" : "65463001",
            "display" : "Salmonella Bilu (organism)"
          },
          {
            "code" : "71711000",
            "display" : "Salmonella Minna (organism)"
          },
          {
            "code" : "114877003",
            "display" : "Salmonella II 47:z29:e,n,x,z15 (organism)"
          },
          {
            "code" : "15728008",
            "display" : "Salmonella Leith (organism)"
          },
          {
            "code" : "54749003",
            "display" : "Salmonella Farcha (organism)"
          },
          {
            "code" : "404405008",
            "display" : "Salmonella IIIb 40:l,v:z (organism)"
          },
          {
            "code" : "42614009",
            "display" : "Salmonella Uzaramo (organism)"
          },
          {
            "code" : "114433004",
            "display" : "Salmonella II 17:g,t:[e,n,x,z15] (organism)"
          },
          {
            "code" : "114897008",
            "display" : "Salmonella IIIb 48:z35:z52 (organism)"
          },
          {
            "code" : "14882006",
            "display" : "Salmonella II 43:e,n,x,z15:1,6 (organism)"
          },
          {
            "code" : "21207005",
            "display" : "Salmonella Cuckmere (organism)"
          },
          {
            "code" : "114971003",
            "display" : "Salmonella II 58:l,z13,z28:1,5 (organism)"
          },
          {
            "code" : "32275009",
            "display" : "Salmonella Godesberg (organism)"
          },
          {
            "code" : "83753002",
            "display" : "Salmonella Tiergarten (organism)"
          },
          {
            "code" : "67646007",
            "display" : "Salmonella Alexanderplatz (organism)"
          },
          {
            "code" : "114717003",
            "display" : "Salmonella IIIb 38:k: e,n,x,z15 (organism)"
          },
          {
            "code" : "114435006",
            "display" : "Salmonella IIIb 17:k:z (organism)"
          },
          {
            "code" : "63800006",
            "display" : "Salmonella Steinplatz (organism)"
          },
          {
            "code" : "404285008",
            "display" : "Salmonella IIIb 17:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "2191008",
            "display" : "Salmonella Ekpoui (organism)"
          },
          {
            "code" : "65211006",
            "display" : "Salmonella Luciana (organism)"
          },
          {
            "code" : "114389007",
            "display" : "Salmonella Laredo (organism)"
          },
          {
            "code" : "76384004",
            "display" : "Salmonella II 6,7:(g),m,(s),t:1,5 (organism)"
          },
          {
            "code" : "30892003",
            "display" : "Salmonella Athinai (organism)"
          },
          {
            "code" : "114382003",
            "display" : "Salmonella IIIb 6,14:l,v:z53 (organism)"
          },
          {
            "code" : "74464001",
            "display" : "Salmonella Doorn (organism)"
          },
          {
            "code" : "114630006",
            "display" : "Salmonella II 3,10:z:e,n,x (organism)"
          },
          {
            "code" : "114321008",
            "display" : "Salmonella Woodinville (organism)"
          },
          {
            "code" : "48254006",
            "display" : "Salmonella II 6,7:a:z6 (organism)"
          },
          {
            "code" : "44109007",
            "display" : "Salmonella Diourbel (organism)"
          },
          {
            "code" : "404326009",
            "display" : "Salmonella IIIb 21:l,v:z57 (organism)"
          },
          {
            "code" : "114419004",
            "display" : "Salmonella IV 16:z36:- (organism)"
          },
          {
            "code" : "398359004",
            "display" : "Salmonella IIIb 61:i:z (organism)"
          },
          {
            "code" : "398467008",
            "display" : "Salmonella group O:4 (organism)"
          },
          {
            "code" : "114933006",
            "display" : "Salmonella II 51:l,z28:z6 (organism)"
          },
          {
            "code" : "114288002",
            "display" : "Salmonella Oxford var 15+,34+ (organism)"
          },
          {
            "code" : "40399001",
            "display" : "Salmonella Oudwijk (organism)"
          },
          {
            "code" : "114328002",
            "display" : "Salmonella II 11:m,t:e,n,x (organism)"
          },
          {
            "code" : "1804009",
            "display" : "Salmonella Brijbhumi (organism)"
          },
          {
            "code" : "80014004",
            "display" : "Salmonella Concord (organism)"
          },
          {
            "code" : "361397004",
            "display" : "Salmonella Atento (organism)"
          },
          {
            "code" : "13794000",
            "display" : "Salmonella Gambaga (organism)"
          },
          {
            "code" : "35197009",
            "display" : "Salmonella Biafra (organism)"
          },
          {
            "code" : "66450003",
            "display" : "Salmonella Gambia (organism)"
          },
          {
            "code" : "9691005",
            "display" : "Salmonella Onderstepoort (organism)"
          },
          {
            "code" : "81938008",
            "display" : "Salmonella Bovismorbificans (organism)"
          },
          {
            "code" : "49297008",
            "display" : "Salmonella Ferruch (organism)"
          },
          {
            "code" : "70760001",
            "display" : "Salmonella Potosi (organism)"
          },
          {
            "code" : "404290006",
            "display" : "Salmonella IIIa 17:z4,z23:- (organism)"
          },
          {
            "code" : "38762004",
            "display" : "Salmonella Allerton (organism)"
          },
          {
            "code" : "40280008",
            "display" : "Salmonella II 1,6,14:z42:1,6 (organism)"
          },
          {
            "code" : "62626007",
            "display" : "Salmonella Volkmarsdorf (organism)"
          },
          {
            "code" : "398398009",
            "display" : "Salmonella IIIb 52:k:z35 (organism)"
          },
          {
            "code" : "57786005",
            "display" : "Salmonella Takoradi (organism)"
          },
          {
            "code" : "22117007",
            "display" : "Salmonella Georgia (organism)"
          },
          {
            "code" : "50111004",
            "display" : "Salmonella Alagbon (organism)"
          },
          {
            "code" : "116048001",
            "display" : "Salmonella, serogroup C (organism)"
          },
          {
            "code" : "17330008",
            "display" : "Salmonella Mississippi (organism)"
          },
          {
            "code" : "57587004",
            "display" : "Salmonella Carnac (organism)"
          },
          {
            "code" : "114964008",
            "display" : "Salmonella IIIb 57:c:e,n,x,z15 (organism)"
          },
          {
            "code" : "404486006",
            "display" : "Salmonella IV, group O:45 (organism)"
          },
          {
            "code" : "15091004",
            "display" : "Salmonella Messina (organism)"
          },
          {
            "code" : "114622005",
            "display" : "Salmonella II 3,10:m,t:e,n,x (organism)"
          },
          {
            "code" : "404555002",
            "display" : "Salmonella IIIb 47:z52:e,n,x,z15 (organism)"
          },
          {
            "code" : "3335004",
            "display" : "Salmonella Greiz (organism)"
          },
          {
            "code" : "65422007",
            "display" : "Salmonella Kintambo (organism)"
          },
          {
            "code" : "114493002",
            "display" : "Salmonella Maska (organism)"
          },
          {
            "code" : "114415005",
            "display" : "Salmonella II 16:z29:1,5 (organism)"
          },
          {
            "code" : "69432009",
            "display" : "Salmonella Zadar (organism)"
          },
          {
            "code" : "36807005",
            "display" : "Salmonella Canton (organism)"
          },
          {
            "code" : "24090006",
            "display" : "Salmonella Senegal (organism)"
          },
          {
            "code" : "404528006",
            "display" : "Salmonella IIIb 47:c:1,5,7 (organism)"
          },
          {
            "code" : "404599006",
            "display" : "Salmonella IIIb 50:(k):z35 (organism)"
          },
          {
            "code" : "441979009",
            "display" : "Salmonella enterica subspecies enterica serovar 9,12:-:1,5 (organism)"
          },
          {
            "code" : "89425007",
            "display" : "Salmonella Maastricht (organism)"
          },
          {
            "code" : "76657005",
            "display" : "Salmonella Heron (organism)"
          },
          {
            "code" : "2445005",
            "display" : "Salmonella Olten (organism)"
          },
          {
            "code" : "114715006",
            "display" : "Salmonella II 38:g,t:- (organism)"
          },
          {
            "code" : "398551000",
            "display" : "Salmonella IIIb 53:r:z35 (organism)"
          },
          {
            "code" : "48704004",
            "display" : "Salmonella Ceyco (organism)"
          },
          {
            "code" : "114657008",
            "display" : "Salmonella Mountmagnet (organism)"
          },
          {
            "code" : "114749003",
            "display" : "Salmonella II 40:k:z6 (organism)"
          },
          {
            "code" : "43662009",
            "display" : "Salmonella Tafo (organism)"
          },
          {
            "code" : "398580009",
            "display" : "Salmonella IIIb 65:c:1,5,7 (organism)"
          },
          {
            "code" : "114701009",
            "display" : "Salmonella Senneville (organism)"
          },
          {
            "code" : "54528001",
            "display" : "Salmonella Yeerongpilly (organism)"
          },
          {
            "code" : "114574002",
            "display" : "Salmonella II 9,12:e,n,x:1,[5],7 (organism)"
          },
          {
            "code" : "398422001",
            "display" : "Salmonella II 3,10:e,n,x:1,7 (organism)"
          },
          {
            "code" : "76212007",
            "display" : "Salmonella Milwaukee (organism)"
          },
          {
            "code" : "114853009",
            "display" : "Salmonella Imo (organism)"
          },
          {
            "code" : "398488004",
            "display" : "Salmonella enterica subsp. salamae (organism)"
          },
          {
            "code" : "42921006",
            "display" : "Salmonella Mountpleasant (organism)"
          },
          {
            "code" : "8339007",
            "display" : "Salmonella Jangwani (organism)"
          },
          {
            "code" : "404384005",
            "display" : "Salmonella IIIb 38:r:1,5,7 (organism)"
          },
          {
            "code" : "49603005",
            "display" : "Salmonella Assinie (organism)"
          },
          {
            "code" : "38701009",
            "display" : "Salmonella Heerlen (organism)"
          },
          {
            "code" : "114278003",
            "display" : "Salmonella Westhampton var 15+ (organism)"
          },
          {
            "code" : "68891004",
            "display" : "Salmonella II 3,10:l,z28:1,5 (organism)"
          },
          {
            "code" : "55653004",
            "display" : "Salmonella Ipeko (organism)"
          },
          {
            "code" : "302722009",
            "display" : "Salmonella II 21:b:1,5 (organism)"
          },
          {
            "code" : "15549007",
            "display" : "Salmonella Bamboye (organism)"
          },
          {
            "code" : "65807007",
            "display" : "Salmonella Sangalkam (organism)"
          },
          {
            "code" : "6156002",
            "display" : "Salmonella Sanga (organism)"
          },
          {
            "code" : "114909000",
            "display" : "Salmonella II 50: g,[m],s,t:[1,5] (organism)"
          },
          {
            "code" : "114337002",
            "display" : "Salmonella Euston (organism)"
          },
          {
            "code" : "398622009",
            "display" : "Salmonella Everleigh (organism)"
          },
          {
            "code" : "114462003",
            "display" : "Salmonella Koessen (organism)"
          },
          {
            "code" : "114554009",
            "display" : "Salmonella Bsilla (organism)"
          },
          {
            "code" : "404605004",
            "display" : "Salmonella IIIb 50:k:z35 (organism)"
          },
          {
            "code" : "404435001",
            "display" : "Salmonella IV, group O:42 (organism)"
          },
          {
            "code" : "114831007",
            "display" : "Salmonella IV 44:a:- (organism)"
          },
          {
            "code" : "404546000",
            "display" : "Salmonella IIIa 47:r:- (organism)"
          },
          {
            "code" : "114605008",
            "display" : "Salmonella Irchel (organism)"
          },
          {
            "code" : "84358001",
            "display" : "Salmonella II 48:z29:- (organism)"
          },
          {
            "code" : "114390003",
            "display" : "Salmonella II 1,6,14:z10:z6:z42 (organism)"
          },
          {
            "code" : "114689004",
            "display" : "Salmonella II 28:z29:e,n,x (organism)"
          },
          {
            "code" : "370578006",
            "display" : "Salmonella Typhimurium var. Copenhagen (organism)"
          },
          {
            "code" : "398342009",
            "display" : "Salmonella I, group O:3,10 (organism)"
          },
          {
            "code" : "15189009",
            "display" : "Salmonella II 6,7:g,[m],s,t:[z42] (organism)"
          },
          {
            "code" : "398393000",
            "display" : "Salmonella bongori (organism)"
          },
          {
            "code" : "404358004",
            "display" : "Salmonella IIIb35:z10:z35 (organism)"
          },
          {
            "code" : "398441003",
            "display" : "Salmonella II 3,10:g,m,s,t:[1,5] var 15+ (organism)"
          },
          {
            "code" : "10749007",
            "display" : "Salmonella Kaitaan (organism)"
          },
          {
            "code" : "56428001",
            "display" : "Salmonella Aflao (organism)"
          },
          {
            "code" : "10851004",
            "display" : "Salmonella Clerkenwell (organism)"
          },
          {
            "code" : "114506001",
            "display" : "Salmonella Winston (organism)"
          },
          {
            "code" : "398333002",
            "display" : "Salmonella IIIb 51:l,v:z (organism)"
          },
          {
            "code" : "44834009",
            "display" : "Salmonella Korovi (organism)"
          },
          {
            "code" : "114837006",
            "display" : "Salmonella Ploufragan (organism)"
          },
          {
            "code" : "131284005",
            "display" : "Salmonella serotype C2,6,8:eh:- (organism)"
          },
          {
            "code" : "442153002",
            "display" : "Salmonella enterica subspecies enterica serovar 9,12:-:1,7 (organism)"
          },
          {
            "code" : "404283001",
            "display" : "Salmonella IIIb 17:l,v:z35 (organism)"
          },
          {
            "code" : "114744008",
            "display" : "Salmonella IV 1,40:g,t:- (organism)"
          },
          {
            "code" : "114833005",
            "display" : "Salmonella IIIb 44:g,t:1,5:z42 (organism)"
          },
          {
            "code" : "27067005",
            "display" : "Salmonella II 43:z29:e,n,x (organism)"
          },
          {
            "code" : "398354009",
            "display" : "Salmonella I, group O:16 (organism)"
          },
          {
            "code" : "114300008",
            "display" : "Salmonella Bida (organism)"
          },
          {
            "code" : "404447007",
            "display" : "Salmonella IIIb 42:z10:z (organism)"
          },
          {
            "code" : "114652002",
            "display" : "Salmonella II 21:g,[m],[s],t:- (organism)"
          },
          {
            "code" : "398429005",
            "display" : "Salmonella group O:11 (organism)"
          },
          {
            "code" : "81781003",
            "display" : "Salmonella Thetford (organism)"
          },
          {
            "code" : "82098006",
            "display" : "Salmonella Niarembe (organism)"
          },
          {
            "code" : "114380006",
            "display" : "Salmonella II 6,14:m,t:e,n,x (organism)"
          },
          {
            "code" : "404601008",
            "display" : "Salmonella IIIb 50:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "51985007",
            "display" : "Salmonella Rissen (organism)"
          },
          {
            "code" : "398546006",
            "display" : "Salmonella IIIa 63:z4,z23:- (organism)"
          },
          {
            "code" : "3316004",
            "display" : "Salmonella Hithergreen (organism)"
          },
          {
            "code" : "398520007",
            "display" : "Salmonella IIIb 57:i:z (organism)"
          },
          {
            "code" : "48642004",
            "display" : "Salmonella II 1,13,23:g,[s],t:z42 (organism)"
          },
          {
            "code" : "114697006",
            "display" : "Salmonella Ockenheim (organism)"
          },
          {
            "code" : "114915000",
            "display" : "Salmonella VI 50:l,v:z67 (organism)"
          },
          {
            "code" : "404480000",
            "display" : "Salmonella Kua (organism)"
          },
          {
            "code" : "398420009",
            "display" : "Salmonella I, group O:2 (organism)"
          },
          {
            "code" : "114960004",
            "display" : "Salmonella II 56:b- (organism)"
          },
          {
            "code" : "404561004",
            "display" : "Salmonella II, group O:48 (organism)"
          },
          {
            "code" : "29019008",
            "display" : "Salmonella Singapore (organism)"
          },
          {
            "code" : "441860007",
            "display" : "Salmonella enterica subspecies enterica serovar 9,12:l,z28:- (organism)"
          },
          {
            "code" : "114523005",
            "display" : "Salmonella II 6,7:z29:[z42] (organism)"
          },
          {
            "code" : "114287007",
            "display" : "Salmonella Lexington var 15+ (organism)"
          },
          {
            "code" : "72895000",
            "display" : "Salmonella Strasbourg (organism)"
          },
          {
            "code" : "398465000",
            "display" : "Salmonella II 1,9,12,46,27:z10:1,5 (organism)"
          },
          {
            "code" : "114632003",
            "display" : "Salmonella Wagadugu (organism)"
          },
          {
            "code" : "114926006",
            "display" : "Salmonella Karaya (organism)"
          },
          {
            "code" : "398602005",
            "display" : "Salmonella II, group O:6,14 (organism)"
          },
          {
            "code" : "404458003",
            "display" : "Salmonella IIIb 43:k:z (organism)"
          },
          {
            "code" : "398603000",
            "display" : "Salmonella IIIb 58:r:z (organism)"
          },
          {
            "code" : "114693005",
            "display" : "Salmonella Torhout (organism)"
          },
          {
            "code" : "18562005",
            "display" : "Salmonella II 48:a:z6 (organism)"
          },
          {
            "code" : "114509008",
            "display" : "Salmonella Strathcona (organism)"
          },
          {
            "code" : "398438007",
            "display" : "Salmonella II 1,4,12,27:b:[e,n,x] (organism)"
          },
          {
            "code" : "39877005",
            "display" : "Salmonella Lexington (organism)"
          },
          {
            "code" : "114344006",
            "display" : "Salmonella II 1,13,23:a:1,5 (organism)"
          },
          {
            "code" : "77576006",
            "display" : "Salmonella Duesseldorf (organism)"
          },
          {
            "code" : "114538006",
            "display" : "Salmonella Lille var 14+ (organism)"
          },
          {
            "code" : "114787006",
            "display" : "Salmonella Ahoutoue (organism)"
          },
          {
            "code" : "13179007",
            "display" : "Salmonella Montreal (organism)"
          },
          {
            "code" : "12040007",
            "display" : "Salmonella Huddinge (organism)"
          },
          {
            "code" : "404578008",
            "display" : "Salmonella IIIb 48:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "116058002",
            "display" : "Salmonella Wilmington (organism)"
          },
          {
            "code" : "21329006",
            "display" : "Salmonella Djama (organism)"
          },
          {
            "code" : "20950003",
            "display" : "Salmonella Bellevue (organism)"
          },
          {
            "code" : "24896001",
            "display" : "Salmonella Harvestehude (organism)"
          },
          {
            "code" : "114911009",
            "display" : "Salmonella II 50:g,z62:e,n,x (organism)"
          },
          {
            "code" : "71121000",
            "display" : "Salmonella Adeoyo (organism)"
          },
          {
            "code" : "26964008",
            "display" : "Salmonella Welikade (organism)"
          },
          {
            "code" : "114708003",
            "display" : "Salmonella IIIb 35:k:z53 (organism)"
          },
          {
            "code" : "114781007",
            "display" : "Salmonella II 41:z:1,5 (organism)"
          },
          {
            "code" : "114881003",
            "display" : "Salmonella II 48:d:z6 (organism)"
          },
          {
            "code" : "404565008",
            "display" : "Salmonella V, group O:48 (organism)"
          },
          {
            "code" : "112294006",
            "display" : "Salmonella Hidalgo (organism)"
          },
          {
            "code" : "36702005",
            "display" : "Salmonella II 13,23:d:e,n,x (organism)"
          },
          {
            "code" : "398613008",
            "display" : "Salmonella IIIb 59:z10:z57 (organism)"
          },
          {
            "code" : "63060009",
            "display" : "Salmonella Huvudsta (organism)"
          },
          {
            "code" : "114368003",
            "display" : "Salmonella II 1,13,22:z10:z6 (organism)"
          },
          {
            "code" : "91354003",
            "display" : "Salmonella Kenya (organism)"
          },
          {
            "code" : "53308007",
            "display" : "Salmonella Bahati (organism)"
          },
          {
            "code" : "51705004",
            "display" : "Salmonella Eppendorf (organism)"
          },
          {
            "code" : "442455001",
            "display" : "Salmonella enterica subspecies enterica serovar 4,5,12:i:- (organism)"
          },
          {
            "code" : "63015008",
            "display" : "Salmonella Ilugun (organism)"
          },
          {
            "code" : "114601004",
            "display" : "Salmonella II 9,46:g,z62:- (organism)"
          },
          {
            "code" : "83479005",
            "display" : "Salmonella II 1,40:g,t:e,n,x (organism)"
          },
          {
            "code" : "112302001",
            "display" : "Salmonella Coquilhatville (organism)"
          },
          {
            "code" : "404250008",
            "display" : "Salmonella IIIb 16:(k):z35 (organism)"
          },
          {
            "code" : "38849007",
            "display" : "Salmonella Florida (organism)"
          },
          {
            "code" : "81030003",
            "display" : "Salmonella Masembe (organism)"
          },
          {
            "code" : "11903004",
            "display" : "Salmonella Mesbit (organism)"
          },
          {
            "code" : "42302007",
            "display" : "Salmonella Karamoja (organism)"
          },
          {
            "code" : "114422002",
            "display" : "Salmonella II 16:z42:1,(5),7 (organism)"
          },
          {
            "code" : "114748006",
            "display" : "Salmonella II 1,40:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "50428006",
            "display" : "Salmonella Urbana (organism)"
          },
          {
            "code" : "61807004",
            "display" : "Salmonella Warnemuende (organism)"
          },
          {
            "code" : "404566009",
            "display" : "Salmonella VI, group O:48 (organism)"
          },
          {
            "code" : "398451002",
            "display" : "Salmonella IV, group O:11 (organism)"
          },
          {
            "code" : "112296008",
            "display" : "Salmonella Virginia (organism)"
          },
          {
            "code" : "404329002",
            "display" : "Salmonella IIIa 21:z29:- (organism)"
          },
          {
            "code" : "57116007",
            "display" : "Salmonella Africana (organism)"
          },
          {
            "code" : "404396003",
            "display" : "Salmonella II, group O:40 (organism)"
          },
          {
            "code" : "404367004",
            "display" : "Salmonella I, group O:38 (organism)"
          },
          {
            "code" : "78041000",
            "display" : "Salmonella II, group O:51 (organism)"
          },
          {
            "code" : "67259007",
            "display" : "Salmonella Inpraw (organism)"
          },
          {
            "code" : "114335005",
            "display" : "Salmonella II 11:l,z28:e,n,x (organism)"
          },
          {
            "code" : "404407000",
            "display" : "Salmonella IIIb 40:z10:z35 (organism)"
          },
          {
            "code" : "105767009",
            "display" : "Salmonella group O:52 (organism)"
          },
          {
            "code" : "9393004",
            "display" : "Salmonella Molade (organism)"
          },
          {
            "code" : "417454003",
            "display" : "Non-motile Salmonella (organism)"
          },
          {
            "code" : "16981003",
            "display" : "Salmonella II 53:d:1,5 (organism)"
          },
          {
            "code" : "3540008",
            "display" : "Salmonella Aequatoria (organism)"
          },
          {
            "code" : "3846009",
            "display" : "Salmonella Gamaba (organism)"
          },
          {
            "code" : "22254006",
            "display" : "Salmonella II 41:c:z6 (organism)"
          },
          {
            "code" : "58393009",
            "display" : "Salmonella Yokoe (organism)"
          },
          {
            "code" : "21953006",
            "display" : "Salmonella II 47:z6:1,6 (organism)"
          },
          {
            "code" : "85312005",
            "display" : "Salmonella II 57:g,t:- (organism)"
          },
          {
            "code" : "398576004",
            "display" : "Salmonella I, group O:1,3,19 (organism)"
          },
          {
            "code" : "69123004",
            "display" : "Salmonella Togo (organism)"
          },
          {
            "code" : "114534008",
            "display" : "Salmonella Amersfoort var 14+ (organism)"
          },
          {
            "code" : "398533001",
            "display" : "Salmonella I, group O:9,46 (organism)"
          },
          {
            "code" : "114894001",
            "display" : "Salmonella VI 48:z10:1,5 (organism)"
          },
          {
            "code" : "114981004",
            "display" : "Salmonella II 1,59:z:z6 (organism)"
          },
          {
            "code" : "34732000",
            "display" : "Salmonella Okefoko (organism)"
          },
          {
            "code" : "34237005",
            "display" : "Salmonella Miyazaki (organism)"
          },
          {
            "code" : "89368009",
            "display" : "Salmonella Antwerpen (organism)"
          },
          {
            "code" : "20567004",
            "display" : "Salmonella Kortrijk (organism)"
          },
          {
            "code" : "114876007",
            "display" : "Salmonella Namoda (organism)"
          },
          {
            "code" : "404418000",
            "display" : "Salmonella IV, group O:41 (organism)"
          },
          {
            "code" : "38358008",
            "display" : "Salmonella Alfort (organism)"
          },
          {
            "code" : "404536002",
            "display" : "Salmonella IIIb 47:k:1,5,7 (organism)"
          },
          {
            "code" : "71672005",
            "display" : "Salmonella Malika (organism)"
          },
          {
            "code" : "398360009",
            "display" : "Salmonella IIIb 6,14:k:z (organism)"
          },
          {
            "code" : "114761006",
            "display" : "Salmonella Yekepa (organism)"
          },
          {
            "code" : "57428009",
            "display" : "Salmonella Campinense (organism)"
          },
          {
            "code" : "83318007",
            "display" : "Salmonella Abortusovis (organism)"
          },
          {
            "code" : "398442005",
            "display" : "Salmonella IIIb 61:z52:z (organism)"
          },
          {
            "code" : "80627004",
            "display" : "Salmonella Agona (organism)"
          },
          {
            "code" : "32379001",
            "display" : "Salmonella Fischerstrasse (organism)"
          },
          {
            "code" : "38514007",
            "display" : "Salmonella II 50:z10:z6 (organism)"
          },
          {
            "code" : "114502004",
            "display" : "Salmonella Nola (organism)"
          },
          {
            "code" : "398372003",
            "display" : "Salmonella IIIb 57:c:z:z60 (organism)"
          },
          {
            "code" : "90157005",
            "display" : "Salmonella Worb (organism)"
          },
          {
            "code" : "2047005",
            "display" : "Salmonella Hoghton (organism)"
          },
          {
            "code" : "6459000",
            "display" : "Salmonella Riogrande (organism)"
          },
          {
            "code" : "114676005",
            "display" : "Salmonella Douala (organism)"
          },
          {
            "code" : "404484009",
            "display" : "Salmonella II, group O:45 (organism)"
          },
          {
            "code" : "89032008",
            "display" : "Salmonella Isangi (organism)"
          },
          {
            "code" : "29192003",
            "display" : "Salmonella Benin (organism)"
          },
          {
            "code" : "114519002",
            "display" : "Salmonella IV 6,7:z4,z24:- (organism)"
          },
          {
            "code" : "114416006",
            "display" : "Salmonella II 16:z29:e,n,x (organism)"
          },
          {
            "code" : "46735003",
            "display" : "Salmonella Obogu (organism)"
          },
          {
            "code" : "404288005",
            "display" : "Salmonella IIIa 17:z36:- (organism)"
          },
          {
            "code" : "10704009",
            "display" : "Salmonella Roan (organism)"
          },
          {
            "code" : "8379003",
            "display" : "Salmonella Tucson (organism)"
          },
          {
            "code" : "404430006",
            "display" : "Salmonella group O:42 (organism)"
          },
          {
            "code" : "114725001",
            "display" : "Salmonella IIIb 38:z61:[z53] (organism)"
          },
          {
            "code" : "114342005",
            "display" : "Salmonella IV 11:z4,z23:- (organism)"
          },
          {
            "code" : "82666001",
            "display" : "Salmonella Dugbe (organism)"
          },
          {
            "code" : "5908004",
            "display" : "Salmonella Haelsingborg (organism)"
          },
          {
            "code" : "27408007",
            "display" : "Salmonella Yundum (organism)"
          },
          {
            "code" : "404352003",
            "display" : "Salmonella IIIb 35:i:z (organism)"
          },
          {
            "code" : "17464006",
            "display" : "Salmonella Amina (organism)"
          },
          {
            "code" : "16346007",
            "display" : "Salmonella Lubumbashi (organism)"
          },
          {
            "code" : "398371005",
            "display" : "Salmonella enterica subsp. houtenae (organism)"
          },
          {
            "code" : "114937007",
            "display" : "Salmonella IIIa 51:z4,z32:- (organism)"
          },
          {
            "code" : "404325008",
            "display" : "Salmonella IIIb 21:l,v:z (organism)"
          },
          {
            "code" : "48823000",
            "display" : "Salmonella Carno (organism)"
          },
          {
            "code" : "114475003",
            "display" : "Salmonella II 4,12:g,m,t:z39 (organism)"
          },
          {
            "code" : "112298009",
            "display" : "Salmonella Cochin (organism)"
          },
          {
            "code" : "114322001",
            "display" : "Salmonella Ati (organism)"
          },
          {
            "code" : "45264001",
            "display" : "Salmonella Jubilee (organism)"
          },
          {
            "code" : "114908008",
            "display" : "Salmonella II 50:e,n,x:1,7 (organism)"
          },
          {
            "code" : "3386009",
            "display" : "Salmonella Doncaster (organism)"
          },
          {
            "code" : "82784009",
            "display" : "Salmonella Gege (organism)"
          },
          {
            "code" : "54309009",
            "display" : "Salmonella Ebrie (organism)"
          },
          {
            "code" : "81662001",
            "display" : "Salmonella Uithof (organism)"
          },
          {
            "code" : "37261005",
            "display" : "Salmonella Anatum (organism)"
          },
          {
            "code" : "114791001",
            "display" : "Salmonella Orbe (organism)"
          },
          {
            "code" : "7717005",
            "display" : "Salmonella Adana (organism)"
          },
          {
            "code" : "114616001",
            "display" : "Salmonella II 3,10:a:l,v (organism)"
          },
          {
            "code" : "78907006",
            "display" : "Salmonella Good (organism)"
          },
          {
            "code" : "114726000",
            "display" : "Salmonella II 39:e,n,x:1,7 (organism)"
          },
          {
            "code" : "40216007",
            "display" : "Salmonella Anna (organism)"
          },
          {
            "code" : "71026007",
            "display" : "Salmonella Gelsenkirchen (organism)"
          },
          {
            "code" : "114677001",
            "display" : "Salmonella Catalunia (organism)"
          },
          {
            "code" : "114745009",
            "display" : "Salmonella II 1,40:g,[m],[s],t:z42 (organism)"
          },
          {
            "code" : "29335009",
            "display" : "Salmonella Sokode (organism)"
          },
          {
            "code" : "70940001",
            "display" : "Salmonella Sanjuan (organism)"
          },
          {
            "code" : "17323002",
            "display" : "Salmonella Wimborne (organism)"
          },
          {
            "code" : "51128007",
            "display" : "Salmonella Friedenau (organism)"
          },
          {
            "code" : "74936002",
            "display" : "Salmonella Abidjan (organism)"
          },
          {
            "code" : "656008",
            "display" : "Salmonella Os (organism)"
          },
          {
            "code" : "114395008",
            "display" : "Salmonella Sculcoates (organism)"
          },
          {
            "code" : "114740004",
            "display" : "Salmonella II 1,40:g,[m],[s],[t]:e,n,x (organism)"
          },
          {
            "code" : "23033001",
            "display" : "Salmonella Yalding (organism)"
          },
          {
            "code" : "114604007",
            "display" : "Salmonella Deckstein (organism)"
          },
          {
            "code" : "7516004",
            "display" : "Salmonella Malmoe (organism)"
          },
          {
            "code" : "398473009",
            "display" : "Salmonella Newlands var 15+, 34+ (organism)"
          },
          {
            "code" : "114966005",
            "display" : "Salmonella IIIb 57:z10:z (organism)"
          },
          {
            "code" : "77511007",
            "display" : "Salmonella Bazenheid (organism)"
          },
          {
            "code" : "87693007",
            "display" : "Salmonella Derkle (organism)"
          },
          {
            "code" : "51024006",
            "display" : "Salmonella Sljeme (organism)"
          },
          {
            "code" : "27987009",
            "display" : "Salmonella Adamstua (organism)"
          },
          {
            "code" : "86397006",
            "display" : "Salmonella Anfo (organism)"
          },
          {
            "code" : "398525002",
            "display" : "Salmonella IIIb 58:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "48229006",
            "display" : "Salmonella Meekatharra (organism)"
          },
          {
            "code" : "35996004",
            "display" : "Salmonella Fyris (organism)"
          },
          {
            "code" : "87019006",
            "display" : "Salmonella Ngili (organism)"
          },
          {
            "code" : "114591003",
            "display" : "Salmonella Ruanda (organism)"
          },
          {
            "code" : "114808007",
            "display" : "Salmonella Broc (organism)"
          },
          {
            "code" : "114485002",
            "display" : "Salmonella II 1,4,12,27:z:1,5 (organism)"
          },
          {
            "code" : "12662006",
            "display" : "Salmonella Amunigun (organism)"
          },
          {
            "code" : "404439007",
            "display" : "Salmonella IIIb 42:k:z (organism)"
          },
          {
            "code" : "84156006",
            "display" : "Salmonella Dembe (organism)"
          },
          {
            "code" : "83893008",
            "display" : "Salmonella Juba (organism)"
          },
          {
            "code" : "68452003",
            "display" : "Salmonella Alexanderpolder (organism)"
          },
          {
            "code" : "398362001",
            "display" : "Salmonella I, group O:54 (organism)"
          },
          {
            "code" : "114488000",
            "display" : "Salmonella II 1,4,12,27:z:e,n,x (organism)"
          },
          {
            "code" : "3567002",
            "display" : "Salmonella Angers (organism)"
          },
          {
            "code" : "114812001",
            "display" : "Salmonella Hennekamp (organism)"
          },
          {
            "code" : "114430001",
            "display" : "Salmonella II 17:e,n,x,z15:1,[5],7 (organism)"
          },
          {
            "code" : "40746009",
            "display" : "Salmonella IV Roterberg (organism)"
          },
          {
            "code" : "79153007",
            "display" : "Salmonella Tennessee (organism)"
          },
          {
            "code" : "69847009",
            "display" : "Salmonella Cairns (organism)"
          },
          {
            "code" : "404362005",
            "display" : "Salmonella IIIb 35:z52:1,5,7 (organism)"
          },
          {
            "code" : "1037005",
            "display" : "Salmonella Aragua (organism)"
          },
          {
            "code" : "53903009",
            "display" : "Salmonella Barmbek (organism)"
          },
          {
            "code" : "114869002",
            "display" : "Salmonella IIIa 47:g,z51:- (organism)"
          },
          {
            "code" : "114293004",
            "display" : "Salmonella Give var 15+, 34+ (organism)"
          },
          {
            "code" : "404403001",
            "display" : "Salmonella IIIb 40:k:z:z57 (organism)"
          },
          {
            "code" : "114586004",
            "display" : "Salmonella II 9,12:z:z39 (organism)"
          },
          {
            "code" : "72029002",
            "display" : "Salmonella Rittersbach (organism)"
          },
          {
            "code" : "34192006",
            "display" : "Salmonella II 52:c:k (organism)"
          },
          {
            "code" : "398415009",
            "display" : "Salmonella IIIa 1,13,23:z4,z24:- (organism)"
          },
          {
            "code" : "114524004",
            "display" : "Salmonella Tienba (organism)"
          },
          {
            "code" : "37093009",
            "display" : "Salmonella Hissar (organism)"
          },
          {
            "code" : "114963002",
            "display" : "Salmonella Batonrouge (organism)"
          },
          {
            "code" : "19857008",
            "display" : "Salmonella II 11:-:1,5 (organism)"
          },
          {
            "code" : "26455007",
            "display" : "Salmonella Nima (organism)"
          },
          {
            "code" : "114888009",
            "display" : "Salmonella II 48:k:z39 (organism)"
          },
          {
            "code" : "114728004",
            "display" : "Salmonella Cumberland (organism)"
          },
          {
            "code" : "25939003",
            "display" : "Salmonella Lindi (organism)"
          },
          {
            "code" : "114720006",
            "display" : "Salmonella IIIb 38:r:z:[z57] (organism)"
          },
          {
            "code" : "398472004",
            "display" : "Salmonella IIIb 53:l,v:z35 (organism)"
          },
          {
            "code" : "7747007",
            "display" : "Salmonella Kikoma (organism)"
          },
          {
            "code" : "82997004",
            "display" : "Salmonella Hull (organism)"
          },
          {
            "code" : "3801008",
            "display" : "Salmonella Ursenbach (organism)"
          },
          {
            "code" : "114867000",
            "display" : "Salmonella II 47:d:z39 (organism)"
          },
          {
            "code" : "67513009",
            "display" : "Salmonella Njala (organism)"
          },
          {
            "code" : "47887000",
            "display" : "Salmonella II 17:g,t:z39 (organism)"
          },
          {
            "code" : "32771001",
            "display" : "Salmonella Ituri (organism)"
          },
          {
            "code" : "2820001",
            "display" : "Salmonella Saintpaul (organism)"
          },
          {
            "code" : "114377005",
            "display" : "Salmonella Woodhull (organism)"
          },
          {
            "code" : "398521006",
            "display" : "Salmonella IIIa 53:z4,z23,z32:- (organism)"
          },
          {
            "code" : "398423006",
            "display" : "Salmonella IIIb 61:l,v:1,5,7:[z57] (organism)"
          },
          {
            "code" : "115408009",
            "display" : "Salmonella, serogroup D (organism)"
          },
          {
            "code" : "25520000",
            "display" : "Salmonella Ruiru (organism)"
          },
          {
            "code" : "114539003",
            "display" : "Salmonella Livingstone var 14+ (organism)"
          },
          {
            "code" : "68108004",
            "display" : "Salmonella Findorff (organism)"
          },
          {
            "code" : "404568005",
            "display" : "Salmonella IIIb 48:(k):z53 (organism)"
          },
          {
            "code" : "20314003",
            "display" : "Salmonella Staoueli (organism)"
          },
          {
            "code" : "78853000",
            "display" : "Salmonella II 1,40:g,t:1,5 (organism)"
          },
          {
            "code" : "398340001",
            "display" : "Salmonella IIIb 60:z10:z (organism)"
          },
          {
            "code" : "114282001",
            "display" : "Salmonella Uganda var 15+ (organism)"
          },
          {
            "code" : "404333009",
            "display" : "Salmonella group O:28 (organism)"
          },
          {
            "code" : "398582001",
            "display" : "Salmonella IIIa 56:z4,z23:- (organism)"
          },
          {
            "code" : "398391003",
            "display" : "Salmonella II 1,4,[5],12,27:a:e,n,x (organism)"
          },
          {
            "code" : "4918004",
            "display" : "Salmonella Hiduddify (organism)"
          },
          {
            "code" : "114530004",
            "display" : "Salmonella II 6,7:l,w:z42 (organism)"
          },
          {
            "code" : "404494004",
            "display" : "Salmonella IIIb, group O:47 (organism)"
          },
          {
            "code" : "442161007",
            "display" : "Salmonella enterica subspecies enterica serovar 6,8:-:1,2 (organism)"
          },
          {
            "code" : "404427004",
            "display" : "Salmonella IIIa 41:z4,z23:- (organism)"
          },
          {
            "code" : "70223004",
            "display" : "Salmonella Weybridge (organism)"
          },
          {
            "code" : "1934000",
            "display" : "Salmonella Ridge (organism)"
          },
          {
            "code" : "60789003",
            "display" : "Salmonella Onarimon (organism)"
          },
          {
            "code" : "114438008",
            "display" : "Salmonella Tendeba (organism)"
          },
          {
            "code" : "68541006",
            "display" : "Salmonella II 13,22:l,z28:1,5 (organism)"
          },
          {
            "code" : "42816009",
            "display" : "Salmonella Labadi (organism)"
          },
          {
            "code" : "114955003",
            "display" : "Salmonella IV 1,53:z36,z38:- (organism)"
          },
          {
            "code" : "302703000",
            "display" : "Salmonella II 1,13,23:g,m,s,t:z42 (organism)"
          },
          {
            "code" : "50853000",
            "display" : "Salmonella Goulfey (organism)"
          },
          {
            "code" : "404293008",
            "display" : "Salmonella IV 17:z29:- (organism)"
          },
          {
            "code" : "67643004",
            "display" : "Salmonella Chincol (organism)"
          },
          {
            "code" : "302691000",
            "display" : "Salmonella Simsbury (organism)"
          },
          {
            "code" : "49666004",
            "display" : "Salmonella Brazil (organism)"
          },
          {
            "code" : "69252007",
            "display" : "Salmonella Ank (organism)"
          },
          {
            "code" : "90683001",
            "display" : "Salmonella Driffield (organism)"
          },
          {
            "code" : "28090003",
            "display" : "Salmonella Yarm (organism)"
          },
          {
            "code" : "35225001",
            "display" : "Salmonella Braenderup (organism)"
          },
          {
            "code" : "62308000",
            "display" : "Salmonella Baiboukoum (organism)"
          },
          {
            "code" : "39045008",
            "display" : "Salmonella Eimsbuettel (organism)"
          },
          {
            "code" : "64456006",
            "display" : "Salmonella Bristol (organism)"
          },
          {
            "code" : "442369002",
            "display" : "Salmonella enterica subspecies enterica serovar 4,[5],12:-:1,7 (organism)"
          },
          {
            "code" : "75515002",
            "display" : "Salmonella Madiago (organism)"
          },
          {
            "code" : "17233007",
            "display" : "Salmonella Simi (organism)"
          },
          {
            "code" : "114429006",
            "display" : "Salmonella II 17:e,n,x,z15:1,6 (organism)"
          },
          {
            "code" : "114603001",
            "display" : "Salmonella Nordrhein (organism)"
          },
          {
            "code" : "47767006",
            "display" : "Salmonella Overvecht (organism)"
          },
          {
            "code" : "41331008",
            "display" : "Salmonella Schleissheim (organism)"
          },
          {
            "code" : "52941007",
            "display" : "Salmonella Plymouth (organism)"
          },
          {
            "code" : "404585007",
            "display" : "Salmonella IIIb 48:z52:e,n,x,z15 (organism)"
          },
          {
            "code" : "114424001",
            "display" : "Salmonella II 16:z42:1,6 (organism)"
          },
          {
            "code" : "71357001",
            "display" : "Salmonella Chomedey (organism)"
          },
          {
            "code" : "62656003",
            "display" : "Salmonella Schoeneberg (organism)"
          },
          {
            "code" : "57322006",
            "display" : "Salmonella Aberdeen (organism)"
          },
          {
            "code" : "88494007",
            "display" : "Salmonella Gloucester (organism)"
          },
          {
            "code" : "105766000",
            "display" : "Salmonella group O:51 (organism)"
          },
          {
            "code" : "66161002",
            "display" : "Salmonella Linguere (organism)"
          },
          {
            "code" : "72119007",
            "display" : "Salmonella Kingabwa (organism)"
          },
          {
            "code" : "65633001",
            "display" : "Salmonella Kermel (organism)"
          },
          {
            "code" : "114887004",
            "display" : "Salmonella V 48:i:- (organism)"
          },
          {
            "code" : "75114008",
            "display" : "Salmonella Mim (organism)"
          },
          {
            "code" : "114412008",
            "display" : "Salmonella II 16:z4,z24:- (organism)"
          },
          {
            "code" : "45998001",
            "display" : "Salmonella Maron (organism)"
          },
          {
            "code" : "114672007",
            "display" : "Salmonella Yardley (organism)"
          },
          {
            "code" : "398380005",
            "display" : "Salmonella IIIb, group O:60 (organism)"
          },
          {
            "code" : "404286009",
            "display" : "Salmonella IIIb 17:z10:z (organism)"
          },
          {
            "code" : "2203005",
            "display" : "Salmonella Meskin (organism)"
          },
          {
            "code" : "114753001",
            "display" : "Salmonella II 1,40:l,z28:1,5:z42 (organism)"
          },
          {
            "code" : "114947005",
            "display" : "Salmonella II 53:c:1,5 (organism)"
          },
          {
            "code" : "404590005",
            "display" : "Salmonella II, group O:50 (organism)"
          },
          {
            "code" : "43352009",
            "display" : "Salmonella Mathura (organism)"
          },
          {
            "code" : "9439003",
            "display" : "Salmonella Horsham (organism)"
          },
          {
            "code" : "114956002",
            "display" : "Salmonella Leda (organism)"
          },
          {
            "code" : "28013002",
            "display" : "Salmonella Kristianstad (organism)"
          },
          {
            "code" : "114681001",
            "display" : "Salmonella Vanier (organism)"
          },
          {
            "code" : "70194005",
            "display" : "Salmonella Dieuppeul (organism)"
          },
          {
            "code" : "53477002",
            "display" : "Salmonella Shoreditch (organism)"
          },
          {
            "code" : "441843002",
            "display" : "Salmonella enterica subspecies enterica serovar 4,[5],12:d:- (organism)"
          },
          {
            "code" : "404454001",
            "display" : "Salmonella II, group O:43 (organism)"
          },
          {
            "code" : "29305002",
            "display" : "Salmonella Teshie (organism)"
          },
          {
            "code" : "58979009",
            "display" : "Salmonella Wisbech (organism)"
          },
          {
            "code" : "398370006",
            "display" : "Salmonella IIIb 59:(k):e,n,x,z15 (organism)"
          },
          {
            "code" : "48703005",
            "display" : "Salmonella II 6,8:y:1,6:z42 (organism)"
          },
          {
            "code" : "55290005",
            "display" : "Salmonella Bonn (organism)"
          },
          {
            "code" : "114685005",
            "display" : "Salmonella Cannobio (organism)"
          },
          {
            "code" : "114299000",
            "display" : "Salmonella Eastglam (organism)"
          },
          {
            "code" : "114565004",
            "display" : "Salmonella II 1,9,12:a:z42 (organism)"
          },
          {
            "code" : "34464008",
            "display" : "Salmonella Texas (organism)"
          },
          {
            "code" : "45548005",
            "display" : "Salmonella Corvallis (organism)"
          },
          {
            "code" : "87089002",
            "display" : "Salmonella Bousso (organism)"
          },
          {
            "code" : "398543003",
            "display" : "Salmonella group O:16 (organism)"
          },
          {
            "code" : "39603007",
            "display" : "Salmonella Parkroyal (organism)"
          },
          {
            "code" : "30362003",
            "display" : "Salmonella Ayinde (organism)"
          },
          {
            "code" : "404420002",
            "display" : "Salmonella II 41:z10:z6 (organism)"
          },
          {
            "code" : "114358008",
            "display" : "Salmonella V 1,13,22:i:- (organism)"
          },
          {
            "code" : "71520006",
            "display" : "Salmonella Antsalova (organism)"
          },
          {
            "code" : "114913007",
            "display" : "Salmonella II 50:k:e,n,x:z42 (organism)"
          },
          {
            "code" : "69738009",
            "display" : "Salmonella Tonev (organism)"
          },
          {
            "code" : "59551003",
            "display" : "Salmonella Colindale (organism)"
          },
          {
            "code" : "114277008",
            "display" : "Salmonella Amsterdam var. 15+ (organism)"
          },
          {
            "code" : "404535003",
            "display" : "Salmonella IIIb 47:i:z53:(z57) (organism)"
          },
          {
            "code" : "116018004",
            "display" : "Salmonella Bethune (organism)"
          },
          {
            "code" : "5778005",
            "display" : "Salmonella Muguga (organism)"
          },
          {
            "code" : "398581008",
            "display" : "Salmonella IIIb 65:(k):z53 (organism)"
          },
          {
            "code" : "57506006",
            "display" : "Salmonella Bergedorf (organism)"
          },
          {
            "code" : "404549007",
            "display" : "Salmonella IIIb 47:r:z35 (organism)"
          },
          {
            "code" : "114663004",
            "display" : "Salmonella IIIb 21:z10:z53 (organism)"
          },
          {
            "code" : "13552001",
            "display" : "Salmonella II 1,40:(z42):1,(5),7 (organism)"
          },
          {
            "code" : "114649005",
            "display" : "Salmonella Tennenlohe (organism)"
          },
          {
            "code" : "15001007",
            "display" : "Salmonella Stockholm (organism)"
          },
          {
            "code" : "114918003",
            "display" : "Salmonella IIIa 50:z4,z32:- (organism)"
          },
          {
            "code" : "404471000",
            "display" : "Salmonella IIIb, group O:44 (organism)"
          },
          {
            "code" : "114356007",
            "display" : "Salmonella II 13,22:m,t:z42:z39 (organism)"
          },
          {
            "code" : "73525009",
            "display" : "Salmonella Enteritidis (organism)"
          },
          {
            "code" : "8741006",
            "display" : "Salmonella Madigan (organism)"
          },
          {
            "code" : "35529008",
            "display" : "Salmonella Brancaster (organism)"
          },
          {
            "code" : "75676000",
            "display" : "Salmonella Wippra (organism)"
          },
          {
            "code" : "112312008",
            "display" : "Salmonella II 17:b:z6 (organism)"
          },
          {
            "code" : "28623007",
            "display" : "Salmonella Treforest (organism)"
          },
          {
            "code" : "114898003",
            "display" : "Salmonella V 48:z35:- (organism)"
          },
          {
            "code" : "81740006",
            "display" : "Salmonella Nijmegen (organism)"
          },
          {
            "code" : "116377008",
            "display" : "Salmonella serotype C1,7:l,w:- (organism)"
          },
          {
            "code" : "81978001",
            "display" : "Salmonella Bron (organism)"
          },
          {
            "code" : "404375005",
            "display" : "Salmonella IIIb 38:(k):z54 (organism)"
          },
          {
            "code" : "80058004",
            "display" : "Salmonella Shannon (organism)"
          },
          {
            "code" : "404554003",
            "display" : "Salmonella IIIb 47:z52:1,5,7 (organism)"
          },
          {
            "code" : "85908006",
            "display" : "Salmonella Paratyphi B (organism)"
          },
          {
            "code" : "114487005",
            "display" : "Salmonella II 4,12:z:1,7 (organism)"
          },
          {
            "code" : "114324000",
            "display" : "Salmonella Missouri (organism)"
          },
          {
            "code" : "91407001",
            "display" : "Salmonella Harburg (organism)"
          },
          {
            "code" : "44768008",
            "display" : "Salmonella Putten (organism)"
          },
          {
            "code" : "28418000",
            "display" : "Salmonella Rossleben (organism)"
          },
          {
            "code" : "114289005",
            "display" : "Salmonella Muenster var 15+,34+ (organism)"
          },
          {
            "code" : "37971001",
            "display" : "Salmonella Bullbay (organism)"
          },
          {
            "code" : "10183008",
            "display" : "Salmonella Pensacola (organism)"
          },
          {
            "code" : "40288001",
            "display" : "Salmonella Moroto (organism)"
          },
          {
            "code" : "398421008",
            "display" : "Salmonella IIIa, group O:11 (organism)"
          },
          {
            "code" : "114858000",
            "display" : "Salmonella IIIa 45:z4,z23:- (organism)"
          },
          {
            "code" : "398427007",
            "display" : "Salmonella I, group O:57 (organism)"
          },
          {
            "code" : "51944002",
            "display" : "Salmonella IV 18:z36,z38,- (organism)"
          },
          {
            "code" : "25000009",
            "display" : "Salmonella Bassa (organism)"
          },
          {
            "code" : "14993009",
            "display" : "Salmonella Mampeza (organism)"
          },
          {
            "code" : "114805005",
            "display" : "Salmonella II 42:z:e,n,x,z15 (organism)"
          },
          {
            "code" : "114281008",
            "display" : "Salmonella Give var 15+ (organism)"
          },
          {
            "code" : "114361009",
            "display" : "Salmonella II 1,13,23:l,z28:z42 (organism)"
          },
          {
            "code" : "25812007",
            "display" : "Salmonella Thiaroye (organism)"
          },
          {
            "code" : "50273002",
            "display" : "Salmonella Dallgow (organism)"
          },
          {
            "code" : "8432002",
            "display" : "Salmonella Sternschanze (organism)"
          },
          {
            "code" : "25040003",
            "display" : "Salmonella Lene (organism)"
          },
          {
            "code" : "404382009",
            "display" : "Salmonella IIIb 38:l,v:z35 (organism)"
          },
          {
            "code" : "67936007",
            "display" : "Salmonella II 39:c:e,n,x (organism)"
          },
          {
            "code" : "114695003",
            "display" : "Salmonella II 30:m,t:- (organism)"
          },
          {
            "code" : "78256004",
            "display" : "Salmonella Vancouver (organism)"
          },
          {
            "code" : "114272002",
            "display" : "Salmonella Vejle var 15+ (organism)"
          },
          {
            "code" : "76778004",
            "display" : "Salmonella Zongo (organism)"
          },
          {
            "code" : "442115007",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:-:e,n,z15 (organism)"
          },
          {
            "code" : "398588002",
            "display" : "Salmonella IIIb, group O:61 (organism)"
          },
          {
            "code" : "44994006",
            "display" : "Salmonella Millesi (organism)"
          },
          {
            "code" : "404455000",
            "display" : "Salmonella IIIa, group O:43 (organism)"
          },
          {
            "code" : "404429001",
            "display" : "Salmonella IIIa 41:z4,z32:- (organism)"
          },
          {
            "code" : "31044005",
            "display" : "Salmonella Bessi (organism)"
          },
          {
            "code" : "114613009",
            "display" : "Salmonella II 1,9,12,46,27:c:z39 (organism)"
          },
          {
            "code" : "404259009",
            "display" : "Salmonella IIIb 16:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "398480006",
            "display" : "Salmonella I, group O:67 (organism)"
          },
          {
            "code" : "11579007",
            "display" : "Salmonella Cullingworth (organism)"
          },
          {
            "code" : "65650004",
            "display" : "Salmonella II 42:m,t:(e,n,x,z15) (organism)"
          },
          {
            "code" : "404339008",
            "display" : "Salmonella I, group O:30 (organism)"
          },
          {
            "code" : "404255003",
            "display" : "Salmonella IIIb 16:l,v:z35 (organism)"
          },
          {
            "code" : "114472000",
            "display" : "Salmonella II 1,4,[5],12:f,g,t:z6:z42 (organism)"
          },
          {
            "code" : "15789003",
            "display" : "Salmonella Vilvoorde (organism)"
          },
          {
            "code" : "112325000",
            "display" : "Salmonella II 56:l,z28:- (organism)"
          },
          {
            "code" : "114410000",
            "display" : "Salmonella II 16:z4,z23:- (organism)"
          },
          {
            "code" : "302740008",
            "display" : "Salmonella Odienne (organism)"
          },
          {
            "code" : "43551001",
            "display" : "Salmonella Naware (organism)"
          },
          {
            "code" : "114499003",
            "display" : "Salmonella Namibia (organism)"
          },
          {
            "code" : "398498005",
            "display" : "Salmonella IIIb (6),14:k:z53 (organism)"
          },
          {
            "code" : "114829003",
            "display" : "Salmonella IV 43:z36,z38:- (organism)"
          },
          {
            "code" : "404425007",
            "display" : "Salmonella IIIa 41:z36:- (organism)"
          },
          {
            "code" : "114922008",
            "display" : "Salmonella Ivorycoast (organism)"
          },
          {
            "code" : "65132007",
            "display" : "Salmonella Monschaui (organism)"
          },
          {
            "code" : "114463008",
            "display" : "Salmonella Huettwillen (organism)"
          },
          {
            "code" : "36050001",
            "display" : "Salmonella Granlo (organism)"
          },
          {
            "code" : "22307009",
            "display" : "Salmonella Budapest (organism)"
          },
          {
            "code" : "35373008",
            "display" : "Salmonella Istanbul (organism)"
          },
          {
            "code" : "19605006",
            "display" : "Salmonella IV 57:z4,z23:- (organism)"
          },
          {
            "code" : "114644000",
            "display" : "Salmonella IIIb 18:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "8730009",
            "display" : "Salmonella Sinchew (organism)"
          },
          {
            "code" : "114546007",
            "display" : "Salmonella II 6,8:f,g:e,n,z15 (organism)"
          },
          {
            "code" : "114994002",
            "display" : "Salmonella IIIa 62:z36:- (organism)"
          },
          {
            "code" : "79910006",
            "display" : "Salmonella Caen (organism)"
          },
          {
            "code" : "114592005",
            "display" : "Salmonella II 9,12:z29:1,5 (organism)"
          },
          {
            "code" : "84518004",
            "display" : "Salmonella Newrochelle (organism)"
          },
          {
            "code" : "398556005",
            "display" : "Salmonella IIIa, group O:13 (organism)"
          },
          {
            "code" : "114764003",
            "display" : "Salmonella II 1,40:z39:1,6 (organism)"
          },
          {
            "code" : "87630008",
            "display" : "Salmonella Norton (organism)"
          },
          {
            "code" : "114332008",
            "display" : "Salmonella IIIb 11:l,v:z53 (organism)"
          },
          {
            "code" : "59598006",
            "display" : "Salmonella Gaminara (organism)"
          },
          {
            "code" : "114773006",
            "display" : "Salmonella Sica (organism)"
          },
          {
            "code" : "26621003",
            "display" : "Salmonella IV 48:z36,z38:- (organism)"
          },
          {
            "code" : "36819002",
            "display" : "Salmonella II 13,22:k:1,5:z42 (organism)"
          },
          {
            "code" : "114702002",
            "display" : "Salmonella II 30:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "45645001",
            "display" : "Salmonella Napoli (organism)"
          },
          {
            "code" : "72414009",
            "display" : "Salmonella II 13,23:l,z28:1,5 (organism)"
          },
          {
            "code" : "64636003",
            "display" : "Salmonella Telelkebir (organism)"
          },
          {
            "code" : "114673002",
            "display" : "Salmonella II 28:g,(m),[s],t:1,5 (organism)"
          },
          {
            "code" : "85186008",
            "display" : "Salmonella Friedrichsfelde (organism)"
          },
          {
            "code" : "64847007",
            "display" : "Salmonella Lezennes (organism)"
          },
          {
            "code" : "46867005",
            "display" : "Salmonella Jericho (organism)"
          },
          {
            "code" : "33172008",
            "display" : "Salmonella Curacao (organism)"
          },
          {
            "code" : "114560009",
            "display" : "Salmonella Ramiremont (organism)"
          },
          {
            "code" : "86968000",
            "display" : "Salmonella II 9,12:a:1,5 (organism)"
          },
          {
            "code" : "67851004",
            "display" : "Salmonella Sipane (organism)"
          },
          {
            "code" : "114762004",
            "display" : "Salmonella V 1,40:z35:- (organism)"
          },
          {
            "code" : "52277009",
            "display" : "Salmonella Ikeja (organism)"
          },
          {
            "code" : "7943004",
            "display" : "Salmonella Lekke (organism)"
          },
          {
            "code" : "67874000",
            "display" : "Salmonella Birmingham (organism)"
          },
          {
            "code" : "398349000",
            "display" : "Salmonella group O:13 (organism)"
          },
          {
            "code" : "114439000",
            "display" : "Salmonella Hadejia (organism)"
          },
          {
            "code" : "40645003",
            "display" : "Salmonella Louisiana (organism)"
          },
          {
            "code" : "404345000",
            "display" : "Salmonella IIIb, group O:35 (organism)"
          },
          {
            "code" : "404330007",
            "display" : "Salmonella IIIb 21:z65:e,n,x,z15 (organism)"
          },
          {
            "code" : "404611001",
            "display" : "Salmonella IIIb 50:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "19439003",
            "display" : "Salmonella Giza (organism)"
          },
          {
            "code" : "90363005",
            "display" : "Salmonella Ligeo (organism)"
          },
          {
            "code" : "73087009",
            "display" : "Salmonella IV 38:z4,z23:- (organism)"
          },
          {
            "code" : "56632001",
            "display" : "Salmonella Durham (organism)"
          },
          {
            "code" : "86097004",
            "display" : "Salmonella II 1,42:l,z13,z28:z6 (organism)"
          },
          {
            "code" : "114759002",
            "display" : "Salmonella II 40:z4,z24:z39 (organism)"
          },
          {
            "code" : "67035008",
            "display" : "Salmonella Oxford (organism)"
          },
          {
            "code" : "7467004",
            "display" : "Salmonella Gwoza (organism)"
          },
          {
            "code" : "65834005",
            "display" : "Salmonella II 43:e,n,x,z15:1,(5),7 (organism)"
          },
          {
            "code" : "397577006",
            "display" : "Salmonella categorized by O antigen (organism)"
          },
          {
            "code" : "302624001",
            "display" : "Salmonella II 4,12,27:i:z35 (organism)"
          },
          {
            "code" : "41227004",
            "display" : "Salmonella Tshiongwe (organism)"
          },
          {
            "code" : "51584000",
            "display" : "Salmonella Stormont (organism)"
          },
          {
            "code" : "47420006",
            "display" : "Salmonella Bere (organism)"
          },
          {
            "code" : "56088006",
            "display" : "Salmonella Eberswalde (organism)"
          },
          {
            "code" : "441853001",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:k:- (organism)"
          },
          {
            "code" : "417210007",
            "display" : "Salmonella IIIb 16:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "23333007",
            "display" : "Salmonella Sao (organism)"
          },
          {
            "code" : "84972004",
            "display" : "Salmonella Remo (organism)"
          },
          {
            "code" : "42410007",
            "display" : "Salmonella Duisburg (organism)"
          },
          {
            "code" : "114590002",
            "display" : "Salmonella Treguier (organism)"
          },
          {
            "code" : "3624003",
            "display" : "Salmonella Waral (organism)"
          },
          {
            "code" : "404424006",
            "display" : "Salmonella IIIa 41:z29:- (organism)"
          },
          {
            "code" : "8922003",
            "display" : "Salmonella Shanghai (organism)"
          },
          {
            "code" : "404597008",
            "display" : "Salmonella II 50:z:e,n,x (organism)"
          },
          {
            "code" : "24564002",
            "display" : "Salmonella Livulu (organism)"
          },
          {
            "code" : "81265007",
            "display" : "Salmonella Albuquerque (organism)"
          },
          {
            "code" : "404306005",
            "display" : "Salmonella IIIb 18:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "114667003",
            "display" : "Salmonella Dibra (organism)"
          },
          {
            "code" : "2007003",
            "display" : "Salmonella Aesch (organism)"
          },
          {
            "code" : "404344001",
            "display" : "Salmonella IIIa, group O:35 (organism)"
          },
          {
            "code" : "11827001",
            "display" : "Salmonella II 1,40:a:z6 (organism)"
          },
          {
            "code" : "114738009",
            "display" : "Salmonella II 1.40:e,n,x :1,[5],7 (organism)"
          },
          {
            "code" : "114527006",
            "display" : "Salmonella IV 6,7:z36:- (organism)"
          },
          {
            "code" : "42715001",
            "display" : "Salmonella Perth (organism)"
          },
          {
            "code" : "34328008",
            "display" : "Salmonella II 16:m,t:e,n,x (organism)"
          },
          {
            "code" : "114792008",
            "display" : "Salmonella II 42:b:e,n,x,z15 (organism)"
          },
          {
            "code" : "114340002",
            "display" : "Salmonella II 11:z:z39 (organism)"
          },
          {
            "code" : "59827003",
            "display" : "Salmonella Agege (organism)"
          },
          {
            "code" : "41677008",
            "display" : "Salmonella Fufu (organism)"
          },
          {
            "code" : "84273002",
            "display" : "Salmonella Rideau (organism)"
          },
          {
            "code" : "398399001",
            "display" : "Salmonella group O:9,46,27 (organism)"
          },
          {
            "code" : "114371006",
            "display" : "Salmonella II 13,22:z39:1,7 (organism)"
          },
          {
            "code" : "67336004",
            "display" : "Salmonella Legon (organism)"
          },
          {
            "code" : "62414008",
            "display" : "Salmonella Gassi (organism)"
          },
          {
            "code" : "20442000",
            "display" : "Salmonella Borreze (organism)"
          },
          {
            "code" : "114664005",
            "display" : "Salmonella IV 21:z36:- (organism)"
          },
          {
            "code" : "4868006",
            "display" : "Salmonella Nottingham (organism)"
          },
          {
            "code" : "22590000",
            "display" : "Salmonella Maricopa (organism)"
          },
          {
            "code" : "50831002",
            "display" : "Salmonella II 40:m,t:z39 (organism)"
          },
          {
            "code" : "33136001",
            "display" : "Salmonella Elisabethville (organism)"
          },
          {
            "code" : "105772000",
            "display" : "Salmonella group O:57 (organism)"
          },
          {
            "code" : "398583006",
            "display" : "Salmonella Ohlstedt var 15+ (organism)"
          },
          {
            "code" : "398596007",
            "display" : "Salmonella IIIb 58:z52:z (organism)"
          },
          {
            "code" : "404618007",
            "display" : "Salmonella IIIa 50:z36:- (organism)"
          },
          {
            "code" : "114406003",
            "display" : "Salmonella Ivory (organism)"
          },
          {
            "code" : "21865009",
            "display" : "Salmonella Bracknell (organism)"
          },
          {
            "code" : "114965009",
            "display" : "Salmonella IIIb 57:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "404489004",
            "display" : "Salmonella IIIa 45:z4,z32:- (organism)"
          },
          {
            "code" : "43587008",
            "display" : "Salmonella Madison (organism)"
          },
          {
            "code" : "114783005",
            "display" : "Salmonella II 41:z10:1,2 (organism)"
          },
          {
            "code" : "32320000",
            "display" : "Salmonella Wilhelmsburg (organism)"
          },
          {
            "code" : "6663003",
            "display" : "Salmonella Morningside (organism)"
          },
          {
            "code" : "114807002",
            "display" : "Salmonella II 42:z:z6 (organism)"
          },
          {
            "code" : "404368009",
            "display" : "Salmonella II, group O:38 (organism)"
          },
          {
            "code" : "404257006",
            "display" : "Salmonella IIIb 16:l,v:z:(z61) (organism)"
          },
          {
            "code" : "64674006",
            "display" : "Salmonella Lyon (organism)"
          },
          {
            "code" : "404465006",
            "display" : "Salmonella IIIb 43:z52:z53 (organism)"
          },
          {
            "code" : "77843003",
            "display" : "Salmonella Mgulani (organism)"
          },
          {
            "code" : "404477001",
            "display" : "Salmonella II 44:z4,z23:- (organism)"
          },
          {
            "code" : "114266002",
            "display" : "Salmonella II 3,10:z39:1,[5],7 (organism)"
          },
          {
            "code" : "404469000",
            "display" : "Salmonella II, group O:44 (organism)"
          },
          {
            "code" : "69117009",
            "display" : "Salmonella Shomolu (organism)"
          },
          {
            "code" : "34520002",
            "display" : "Salmonella Coogee (organism)"
          },
          {
            "code" : "114405004",
            "display" : "Salmonella II 16:l,z28:z42 (organism)"
          },
          {
            "code" : "5957001",
            "display" : "Salmonella Binningen (organism)"
          },
          {
            "code" : "404451009",
            "display" : "Salmonella IIIb 42:z52:z (organism)"
          },
          {
            "code" : "75173009",
            "display" : "Salmonella Pisa (organism)"
          },
          {
            "code" : "62532006",
            "display" : "Salmonella Veneziana (organism)"
          },
          {
            "code" : "59834001",
            "display" : "Salmonella Gbadago (organism)"
          },
          {
            "code" : "26622005",
            "display" : "Salmonella Gnesta (organism)"
          },
          {
            "code" : "114851006",
            "display" : "Salmonella II 45:g,m,t:e,n,x,z15 (organism)"
          },
          {
            "code" : "43109001",
            "display" : "Salmonella Pasing (organism)"
          },
          {
            "code" : "85698004",
            "display" : "Salmonella Wernigerode (organism)"
          },
          {
            "code" : "114849007",
            "display" : "Salmonella II 45:g,m,s,t:1,5 (organism)"
          },
          {
            "code" : "114437003",
            "display" : "Salmonella Lancaster (organism)"
          },
          {
            "code" : "28141000",
            "display" : "Salmonella Bolombo (organism)"
          },
          {
            "code" : "398419003",
            "display" : "Salmonella IIIa 56:z29:- (organism)"
          },
          {
            "code" : "26685005",
            "display" : "Salmonella Stuivenberg (organism)"
          },
          {
            "code" : "78474005",
            "display" : "Salmonella Gateshead (organism)"
          },
          {
            "code" : "398357002",
            "display" : "Salmonella IIIa, group O:56 (organism)"
          },
          {
            "code" : "114758005",
            "display" : "Salmonella IV 1,40:z4,z23:- (organism)"
          },
          {
            "code" : "404253005",
            "display" : "Salmonella IIIb 16:k:z53 (organism)"
          },
          {
            "code" : "404376006",
            "display" : "Salmonella IIIb 38:(k):z55 (organism)"
          },
          {
            "code" : "112311001",
            "display" : "Salmonella Irenea (organism)"
          },
          {
            "code" : "37297001",
            "display" : "Salmonella Hermannswerder (organism)"
          },
          {
            "code" : "404478006",
            "display" : "Salmonella IIIa 44:z4,z23:- (organism)"
          },
          {
            "code" : "114793003",
            "display" : "Salmonella II 42:b:z6 (organism)"
          },
          {
            "code" : "1081002",
            "display" : "Salmonella II 9,12,(46),27:g,t:e,n,x (organism)"
          },
          {
            "code" : "114593000",
            "display" : "Salmonella II 1,9,12:z39:1,7 (organism)"
          },
          {
            "code" : "404614009",
            "display" : "Salmonella IIIb 50:r:z53 (organism)"
          },
          {
            "code" : "58041001",
            "display" : "Salmonella II 9,12:e,n,x:1,6 (organism)"
          },
          {
            "code" : "114628009",
            "display" : "Salmonella II 3,10:z:1,5 (organism)"
          },
          {
            "code" : "78528008",
            "display" : "Salmonella Warengo (organism)"
          },
          {
            "code" : "404380001",
            "display" : "Salmonella IIIb 38:k:z53 (organism)"
          },
          {
            "code" : "40465000",
            "display" : "Salmonella Surat (organism)"
          },
          {
            "code" : "76337004",
            "display" : "Salmonella Langenhorn (organism)"
          },
          {
            "code" : "1957006",
            "display" : "Salmonella Hydra (organism)"
          },
          {
            "code" : "51130009",
            "display" : "Salmonella Nakuru (organism)"
          },
          {
            "code" : "404437009",
            "display" : "Salmonella IIIb 42:(k):z35 (organism)"
          },
          {
            "code" : "114349001",
            "display" : "Salmonella Vridi (organism)"
          },
          {
            "code" : "116059005",
            "display" : "Salmonella Asylanta (organism)"
          },
          {
            "code" : "77022000",
            "display" : "Salmonella Oskarshamn (organism)"
          },
          {
            "code" : "404440009",
            "display" : "Salmonella IIIb 42:l,v:1,5,7 (organism)"
          },
          {
            "code" : "64802006",
            "display" : "Salmonella Miami (organism)"
          },
          {
            "code" : "398407006",
            "display" : "Salmonella IIIb 60:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "303216008",
            "display" : "Salmonella Mbandaka var 25 (organism)"
          },
          {
            "code" : "88022005",
            "display" : "Salmonella Javiana (organism)"
          },
          {
            "code" : "56737002",
            "display" : "Salmonella Raus (organism)"
          },
          {
            "code" : "26592005",
            "display" : "Salmonella Tamale (organism)"
          },
          {
            "code" : "114363007",
            "display" : "Salmonella II 1,13,23:z:1,5 (organism)"
          },
          {
            "code" : "114504003",
            "display" : "Salmonella IV 6,7:g:z51:- (organism)"
          },
          {
            "code" : "114668008",
            "display" : "Salmonella Soumbedioune (organism)"
          },
          {
            "code" : "404252000",
            "display" : "Salmonella IIIb 16:k:z (organism)"
          },
          {
            "code" : "398500006",
            "display" : "Salmonella IIIb 65:z10:z (organism)"
          },
          {
            "code" : "8249007",
            "display" : "Salmonella Denver (organism)"
          },
          {
            "code" : "114533002",
            "display" : "Salmonella Ohio var 14+ (organism)"
          },
          {
            "code" : "90973003",
            "display" : "Salmonella Guildford (organism)"
          },
          {
            "code" : "88248006",
            "display" : "Salmonella Congo (organism)"
          },
          {
            "code" : "114974006",
            "display" : "Salmonella IIIb 58:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "114711002",
            "display" : "Salmonella IIIb 35:r:z (organism)"
          },
          {
            "code" : "43640009",
            "display" : "Salmonella Pakistan (organism)"
          },
          {
            "code" : "39215001",
            "display" : "Salmonella Vejle (organism)"
          },
          {
            "code" : "8448001",
            "display" : "Salmonella Rovaniemi (organism)"
          },
          {
            "code" : "58045005",
            "display" : "Salmonella Hillegersberg (organism)"
          },
          {
            "code" : "6675008",
            "display" : "Salmonella Kibi (organism)"
          },
          {
            "code" : "45512008",
            "display" : "Salmonella Hindmarsh (organism)"
          },
          {
            "code" : "11750003",
            "display" : "Salmonella Lisboa (organism)"
          },
          {
            "code" : "88121001",
            "display" : "Salmonella Brisbane (organism)"
          },
          {
            "code" : "114372004",
            "display" : "Salmonella II 1,13,23:z39:1,5,7 (organism)"
          },
          {
            "code" : "49114009",
            "display" : "Salmonella Vogan (organism)"
          },
          {
            "code" : "36247005",
            "display" : "Salmonella Santhiaba (organism)"
          },
          {
            "code" : "64768003",
            "display" : "Salmonella Togba (organism)"
          },
          {
            "code" : "23837004",
            "display" : "Salmonella Tchad (organism)"
          },
          {
            "code" : "46818008",
            "display" : "Salmonella II 1,6,14:k:z6,z42 (organism)"
          },
          {
            "code" : "398497000",
            "display" : "Salmonella IIIb 61:z52:z53 (organism)"
          },
          {
            "code" : "105768004",
            "display" : "Salmonella group O:53 (organism)"
          },
          {
            "code" : "114940007",
            "display" : "Salmonella II 52:d:z39 (organism)"
          },
          {
            "code" : "114669000",
            "display" : "Salmonella II 28:b:e,n,x (organism)"
          },
          {
            "code" : "6065006",
            "display" : "Salmonella Malstatt (organism)"
          },
          {
            "code" : "48936001",
            "display" : "Salmonella II 18:y:e,n,x,z15 (organism)"
          },
          {
            "code" : "114713004",
            "display" : "Salmonella Oran (organism)"
          },
          {
            "code" : "404373003",
            "display" : "Salmonella IIIb 38:(k):z (organism)"
          },
          {
            "code" : "114567007",
            "display" : "Salmonella II 1,9,12:b:z6 (organism)"
          },
          {
            "code" : "76027002",
            "display" : "Salmonella Chichiri (organism)"
          },
          {
            "code" : "114498006",
            "display" : "Salmonella Schwabach (organism)"
          },
          {
            "code" : "114531000",
            "display" : "Salmonella II 6,7:z:z42 (organism)"
          },
          {
            "code" : "87566000",
            "display" : "Salmonella Quebec (organism)"
          },
          {
            "code" : "404543008",
            "display" : "Salmonella IIIb47:l,v:z35 (organism)"
          },
          {
            "code" : "68520000",
            "display" : "Salmonella II 6,7:z42:e,n,x:1,6 (organism)"
          },
          {
            "code" : "1056000",
            "display" : "Salmonella II, 4,12:l,z28:- (organism)"
          },
          {
            "code" : "114520008",
            "display" : "Salmonella II 6,7:z6:1,7 (organism)"
          },
          {
            "code" : "398517004",
            "display" : "Salmonella IIIb 60:z52:1,5,7 (organism)"
          },
          {
            "code" : "5956005",
            "display" : "Salmonella Kouka (organism)"
          },
          {
            "code" : "116053006",
            "display" : "Salmonella Damman (organism)"
          },
          {
            "code" : "76354007",
            "display" : "Salmonella Atakpame (organism)"
          },
          {
            "code" : "404594001",
            "display" : "Salmonella VI, group O:50 (organism)"
          },
          {
            "code" : "57072004",
            "display" : "Salmonella Solt (organism)"
          },
          {
            "code" : "398411000",
            "display" : "Salmonella IIIa 59:z29:- (organism)"
          },
          {
            "code" : "114588003",
            "display" : "Salmonella Natal (organism)"
          },
          {
            "code" : "1812001",
            "display" : "Salmonella Jerusalem (organism)"
          },
          {
            "code" : "398616000",
            "display" : "Salmonella IIIa 51:z4,z24:- (organism)"
          },
          {
            "code" : "62367007",
            "display" : "Salmonella Lovelace (organism)"
          },
          {
            "code" : "22300006",
            "display" : "Salmonella Hillsborough (organism)"
          },
          {
            "code" : "55246000",
            "display" : "Salmonella Echa (organism)"
          },
          {
            "code" : "398564004",
            "display" : "Salmonella IIIb, group O:65 (organism)"
          },
          {
            "code" : "74649009",
            "display" : "Salmonella Macallen (organism)"
          },
          {
            "code" : "398615001",
            "display" : "Salmonella IIIb 65:(k):z (organism)"
          },
          {
            "code" : "72706004",
            "display" : "Salmonella II 58:z10:1,6 (organism)"
          },
          {
            "code" : "66788002",
            "display" : "Salmonella IV 6,14:z4,z23:- (organism)"
          },
          {
            "code" : "10280001",
            "display" : "Salmonella Tabligbo (organism)"
          },
          {
            "code" : "404311007",
            "display" : "Salmonella I, group O:21 (organism)"
          },
          {
            "code" : "22001003",
            "display" : "Salmonella Lockleaze (organism)"
          },
          {
            "code" : "21838002",
            "display" : "Salmonella Annedal (organism)"
          },
          {
            "code" : "398619007",
            "display" : "Salmonella IIIb 65:i,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "24289007",
            "display" : "Salmonella Lagos (organism)"
          },
          {
            "code" : "114996000",
            "display" : "Salmonella IIIb 65:r:z35 (organism)"
          },
          {
            "code" : "114850007",
            "display" : "Salmonella II 45:g,m,s,t:e,n,x (organism)"
          },
          {
            "code" : "40637008",
            "display" : "Salmonella Ontario (organism)"
          },
          {
            "code" : "27008003",
            "display" : "Salmonella Niakhar (organism)"
          },
          {
            "code" : "114329005",
            "display" : "Salmonella Mannheim (organism)"
          },
          {
            "code" : "78040004",
            "display" : "Salmonella IV 40:m,t:- (organism)"
          },
          {
            "code" : "38676005",
            "display" : "Salmonella Bootle (organism)"
          },
          {
            "code" : "398356006",
            "display" : "Salmonella IIIa 59:z4:z23:- (organism)"
          },
          {
            "code" : "15553009",
            "display" : "Salmonella Tchamba (organism)"
          },
          {
            "code" : "114501006",
            "display" : "Salmonella II 6,7:d:z42 (organism)"
          },
          {
            "code" : "114393001",
            "display" : "Salmonella Vegesack (organism)"
          },
          {
            "code" : "89885000",
            "display" : "Salmonella Chiredzi (organism)"
          },
          {
            "code" : "2111007",
            "display" : "Salmonella Tamilnadu (organism)"
          },
          {
            "code" : "398618004",
            "display" : "Salmonella IIIb, group O:11 (organism)"
          },
          {
            "code" : "50772008",
            "display" : "Salmonella Dan (organism)"
          },
          {
            "code" : "51820003",
            "display" : "Salmonella Lechler (organism)"
          },
          {
            "code" : "114891009",
            "display" : "Salmonella IIIb 48:z:1,5,7 (organism)"
          },
          {
            "code" : "114845001",
            "display" : "Salmonella II 44:z29:e,n,x:z42 (organism)"
          },
          {
            "code" : "114427008",
            "display" : "Salmonella Luedinghausen (organism)"
          },
          {
            "code" : "398361008",
            "display" : "Salmonella V, group O:66 (organism)"
          },
          {
            "code" : "404254004",
            "display" : "Salmonella IIIb 16:l,v:1,5,7 (organism)"
          },
          {
            "code" : "114957006",
            "display" : "Salmonella Newholland (organism)"
          },
          {
            "code" : "58215003",
            "display" : "Salmonella Machaga (organism)"
          },
          {
            "code" : "3210007",
            "display" : "Salmonella II 1,44:e,n,x:1,6 (organism)"
          },
          {
            "code" : "404576007",
            "display" : "Salmonella IIIb 48:l,v:1,5,(7) (organism)"
          },
          {
            "code" : "32995008",
            "display" : "Salmonella Mons (organism)"
          },
          {
            "code" : "57861008",
            "display" : "Salmonella Tambacounda (organism)"
          },
          {
            "code" : "18913004",
            "display" : "Salmonella Bonames (organism)"
          },
          {
            "code" : "58946009",
            "display" : "Salmonella Kumasi (organism)"
          },
          {
            "code" : "302754000",
            "display" : "Salmonella II 56:l,v:z39 (organism)"
          },
          {
            "code" : "48126005",
            "display" : "Salmonella Quinhon (organism)"
          },
          {
            "code" : "404569002",
            "display" : "Salmonella IIIb 48:c:z (organism)"
          },
          {
            "code" : "38211003",
            "display" : "Salmonella II 1,9,12,(46),27:l,z13,z28:z39 (organism)"
          },
          {
            "code" : "114403006",
            "display" : "Salmonella Zigong (organism)"
          },
          {
            "code" : "398436006",
            "display" : "Salmonella group O:3,10 (organism)"
          },
          {
            "code" : "398450001",
            "display" : "Salmonella IIIb 53:k:z (organism)"
          },
          {
            "code" : "3970007",
            "display" : "Salmonella Quentin (organism)"
          },
          {
            "code" : "16762003",
            "display" : "Salmonella II 42:z10:z6 (organism)"
          },
          {
            "code" : "84044008",
            "display" : "Salmonella Minnesota (organism)"
          },
          {
            "code" : "34473000",
            "display" : "Salmonella Wangata (organism)"
          },
          {
            "code" : "14642002",
            "display" : "Salmonella II 1,9,12,(46),27:z4,z24:1,5 (organism)"
          },
          {
            "code" : "749009",
            "display" : "Salmonella Truro (organism)"
          },
          {
            "code" : "116056003",
            "display" : "Salmonella II 3,10,15:g,m,s,t:- (organism)"
          },
          {
            "code" : "47679004",
            "display" : "Salmonella Fortlamy (organism)"
          },
          {
            "code" : "66863002",
            "display" : "Salmonella Dabou (organism)"
          },
          {
            "code" : "404360002",
            "display" : "Salmonella IIIa 35:z36:- (organism)"
          },
          {
            "code" : "114803003",
            "display" : "Salmonella Spalentor (organism)"
          },
          {
            "code" : "91144009",
            "display" : "Salmonella Schalkwijk (organism)"
          },
          {
            "code" : "404397007",
            "display" : "Salmonella IIIa, group O:40 (organism)"
          },
          {
            "code" : "10112007",
            "display" : "Salmonella Alamo (organism)"
          },
          {
            "code" : "14694000",
            "display" : "Salmonella IV 11:z4,z32:- (organism)"
          },
          {
            "code" : "89085001",
            "display" : "Salmonella Lingwala (organism)"
          },
          {
            "code" : "44012008",
            "display" : "Salmonella Faji (organism)"
          },
          {
            "code" : "36210005",
            "display" : "Salmonella II 6,7:l,w:1,5,7 (organism)"
          },
          {
            "code" : "76350003",
            "display" : "Salmonella Nyanza (organism)"
          },
          {
            "code" : "20542002",
            "display" : "Salmonella IV 50:z4,z24:- (organism)"
          },
          {
            "code" : "404529003",
            "display" : "Salmonella IIIb 47:c:e,n,x,z15:(z15) (organism)"
          },
          {
            "code" : "56122007",
            "display" : "Salmonella Ogbete (organism)"
          },
          {
            "code" : "114943009",
            "display" : "Salmonella II 52:z:z39 (organism)"
          },
          {
            "code" : "114609002",
            "display" : "Salmonella II 9,46:z4,z24:z39:z42 (organism)"
          },
          {
            "code" : "61531002",
            "display" : "Salmonella Mayday (organism)"
          },
          {
            "code" : "61079001",
            "display" : "Salmonella Haouaria (organism)"
          },
          {
            "code" : "114825009",
            "display" : "Salmonella II 43:z4,z23:- (organism)"
          },
          {
            "code" : "10762006",
            "display" : "Salmonella Omifisan (organism)"
          },
          {
            "code" : "114739001",
            "display" : "Salmonella II 1,40:e,n,x,z15 :1,6 (organism)"
          },
          {
            "code" : "77114009",
            "display" : "Salmonella Dresden (organism)"
          },
          {
            "code" : "114906007",
            "display" : "Salmonella Hemingford (organism)"
          },
          {
            "code" : "44010000",
            "display" : "Salmonella Djakarta (organism)"
          },
          {
            "code" : "114540001",
            "display" : "Salmonella II 6,7:l,z28:z6 (organism)"
          },
          {
            "code" : "404540006",
            "display" : "Salmonella IIIb 47:k:z53 (organism)"
          },
          {
            "code" : "84346001",
            "display" : "Salmonella Bardo (organism)"
          },
          {
            "code" : "81490006",
            "display" : "Salmonella Balcones (organism)"
          },
          {
            "code" : "404491007",
            "display" : "Salmonella I, group O:47 (organism)"
          },
          {
            "code" : "6302004",
            "display" : "Salmonella Shipley (organism)"
          },
          {
            "code" : "404412004",
            "display" : "Salmonella IIIa 40:z4,z32:- (organism)"
          },
          {
            "code" : "312000",
            "display" : "Salmonella Amba (organism)"
          },
          {
            "code" : "8544001",
            "display" : "Salmonella Potsdam (organism)"
          },
          {
            "code" : "31517006",
            "display" : "Salmonella Richmond (organism)"
          },
          {
            "code" : "41467000",
            "display" : "Salmonella Sada (organism)"
          },
          {
            "code" : "79475004",
            "display" : "Salmonella Tamberma (organism)"
          },
          {
            "code" : "23271001",
            "display" : "Salmonella Doulassame (organism)"
          },
          {
            "code" : "404445004",
            "display" : "Salmonella IIIb 42:r:z (organism)"
          },
          {
            "code" : "404564007",
            "display" : "Salmonella IV, group O:48 (organism)"
          },
          {
            "code" : "21146003",
            "display" : "Salmonella Saphra (organism)"
          },
          {
            "code" : "114351002",
            "display" : "Salmonella II 1,13,23:g,m,[s],t:[e,n,x] (organism)"
          },
          {
            "code" : "20905000",
            "display" : "Salmonella Sunnycove (organism)"
          },
          {
            "code" : "11139006",
            "display" : "Salmonella Suberu (organism)"
          },
          {
            "code" : "114284000",
            "display" : "Salmonella Amager var 15+ (organism)"
          },
          {
            "code" : "114747001",
            "display" : "Salmonella IV 1,40:g,z51:- (organism)"
          },
          {
            "code" : "114823002",
            "display" : "Salmonella II 43:l,z13,z28:1,5 (organism)"
          },
          {
            "code" : "114991005",
            "display" : "Salmonella IIIb 61:r:z (organism)"
          },
          {
            "code" : "62686005",
            "display" : "Salmonella Mono (organism)"
          },
          {
            "code" : "4794005",
            "display" : "Salmonella Jedburgh (organism)"
          },
          {
            "code" : "46323004",
            "display" : "Salmonella Shikmonah (organism)"
          },
          {
            "code" : "404356000",
            "display" : "Salmonella IIIb 35:r:z35 (organism)"
          },
          {
            "code" : "114642001",
            "display" : "Salmonella Potengi (organism)"
          },
          {
            "code" : "114790000",
            "display" : "Salmonella II 42:b:1,5 (organism)"
          },
          {
            "code" : "114795005",
            "display" : "Salmonella II 42:e,n,x:1,6 (organism)"
          },
          {
            "code" : "61191008",
            "display" : "Salmonella Ikayi (organism)"
          },
          {
            "code" : "404534004",
            "display" : "Salmonella IIIb 47:i:z35 (organism)"
          },
          {
            "code" : "85398008",
            "display" : "Salmonella Adime (organism)"
          },
          {
            "code" : "8044005",
            "display" : "Salmonella Bareilly (organism)"
          },
          {
            "code" : "78008003",
            "display" : "Salmonella II 6,7:d:1,7 (organism)"
          },
          {
            "code" : "72958001",
            "display" : "Salmonella Dumfries (organism)"
          },
          {
            "code" : "42355001",
            "display" : "Salmonella Loenga (organism)"
          },
          {
            "code" : "404539009",
            "display" : "Salmonella IIIb 47:k:z35 (organism)"
          },
          {
            "code" : "114859008",
            "display" : "Salmonella Transvaal (organism)"
          },
          {
            "code" : "114566003",
            "display" : "Salmonella II 1,9,12:b:e,n,x (organism)"
          },
          {
            "code" : "398369005",
            "display" : "Salmonella IIIb 61:l,v:z35 (organism)"
          },
          {
            "code" : "114944003",
            "display" : "Salmonella IIIb 52:z:z52 (organism)"
          },
          {
            "code" : "51008005",
            "display" : "Salmonella Kingston (organism)"
          },
          {
            "code" : "114729007",
            "display" : "Salmonella Alma (organism)"
          },
          {
            "code" : "114986009",
            "display" : "Salmonella II 60:z:e,n,x (organism)"
          },
          {
            "code" : "114959009",
            "display" : "Salmonella II 55:k:z39 (organism)"
          },
          {
            "code" : "398528000",
            "display" : "Salmonella II, group O:11 (organism)"
          },
          {
            "code" : "114914001",
            "display" : "Salmonella II 50:k:z6 (organism)"
          },
          {
            "code" : "37420008",
            "display" : "Salmonella Westminster (organism)"
          },
          {
            "code" : "112305004",
            "display" : "Salmonella Dessau (organism)"
          },
          {
            "code" : "114392006",
            "display" : "Salmonella IIIb 6,14:z52:e,n,x,z15 (organism)"
          },
          {
            "code" : "398350000",
            "display" : "Salmonella IIIa 51:g,z51:- (organism)"
          },
          {
            "code" : "38604007",
            "display" : "Salmonella II 39:a:z39 (organism)"
          },
          {
            "code" : "55107007",
            "display" : "Salmonella Malaysia (organism)"
          },
          {
            "code" : "404371001",
            "display" : "Salmonella IV, group O:38 (organism)"
          },
          {
            "code" : "404562006",
            "display" : "Salmonella IIIa, group O:48 (organism)"
          },
          {
            "code" : "84106001",
            "display" : "Salmonella Banana (organism)"
          },
          {
            "code" : "114394007",
            "display" : "Salmonella Yoruba (organism)"
          },
          {
            "code" : "404606003",
            "display" : "Salmonella IIIb 50:k:z53 (organism)"
          },
          {
            "code" : "54551001",
            "display" : "Salmonella II 6,7:z:z39 (organism)"
          },
          {
            "code" : "114972005",
            "display" : "Salmonella II 58:l,z13,z28:z6 (organism)"
          },
          {
            "code" : "800007",
            "display" : "Salmonella Offa (organism)"
          },
          {
            "code" : "10248003",
            "display" : "Salmonella Travis (organism)"
          },
          {
            "code" : "114874005",
            "display" : "Salmonella Binche (organism)"
          },
          {
            "code" : "63877008",
            "display" : "Salmonella Champaign (organism)"
          },
          {
            "code" : "81614007",
            "display" : "Salmonella Litchfield (organism)"
          },
          {
            "code" : "65525006",
            "display" : "Salmonella Gera (organism)"
          },
          {
            "code" : "69261007",
            "display" : "Salmonella Sambre (organism)"
          },
          {
            "code" : "114541002",
            "display" : "Salmonella Valdosta (organism)"
          },
          {
            "code" : "29948004",
            "display" : "Salmonella II 30:z6:1,6 (organism)"
          },
          {
            "code" : "90726003",
            "display" : "Salmonella Lamin (organism)"
          },
          {
            "code" : "787906003",
            "display" : "Salmonella Enteritidis phage type 8 (organism)"
          },
          {
            "code" : "69033009",
            "display" : "Salmonella Escanaba (organism)"
          },
          {
            "code" : "404289002",
            "display" : "Salmonella IIIa 17:z4,z23,z32:- (organism)"
          },
          {
            "code" : "114921001",
            "display" : "Salmonella II 50:z10:z6:z42 (organism)"
          },
          {
            "code" : "398410004",
            "display" : "Salmonella Southbank var 15+, 34+ (organism)"
          },
          {
            "code" : "2872006",
            "display" : "Salmonella Frintrop (organism)"
          },
          {
            "code" : "114388004",
            "display" : "Salmonella II 1,6,14:z10:1,5 (organism)"
          },
          {
            "code" : "30290002",
            "display" : "Salmonella Mara (organism)"
          },
          {
            "code" : "404353008",
            "display" : "Salmonella IIIb 35:k:z (organism)"
          },
          {
            "code" : "114496005",
            "display" : "Salmonella II 6,7:a:z42 (organism)"
          },
          {
            "code" : "398409009",
            "display" : "Salmonella Nchanga var 15+ (organism)"
          },
          {
            "code" : "80563006",
            "display" : "Salmonella Kampala (organism)"
          },
          {
            "code" : "404580002",
            "display" : "Salmonella IIIb 48:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "404481001",
            "display" : "Salmonella Zinder (organism)"
          },
          {
            "code" : "404291005",
            "display" : "Salmonella IIIa 17:z4,z24:- (organism)"
          },
          {
            "code" : "112295007",
            "display" : "Salmonella Be (organism)"
          },
          {
            "code" : "715050006",
            "display" : "Salmonella group O:3,15 (organism)"
          },
          {
            "code" : "73541005",
            "display" : "Salmonella Bochum (organism)"
          },
          {
            "code" : "26443001",
            "display" : "Salmonella Lattenkamp (organism)"
          },
          {
            "code" : "404544002",
            "display" : "Salmonella IIIb 47:l,v:z53 (organism)"
          },
          {
            "code" : "17834009",
            "display" : "Salmonella Ord (organism)"
          },
          {
            "code" : "9357001",
            "display" : "Salmonella Ottawa (organism)"
          },
          {
            "code" : "4687003",
            "display" : "Salmonella Essen (organism)"
          },
          {
            "code" : "398490003",
            "display" : "Salmonella I, group O:6,14 (organism)"
          },
          {
            "code" : "114958001",
            "display" : "Salmonella Barry (organism)"
          },
          {
            "code" : "114788001",
            "display" : "Salmonella IV 41:z52:- (organism)"
          },
          {
            "code" : "302718004",
            "display" : "Salmonella Brooklyn (organism)"
          },
          {
            "code" : "46292001",
            "display" : "Salmonella Catanzaro (organism)"
          },
          {
            "code" : "77584005",
            "display" : "Salmonella Muenchen (organism)"
          },
          {
            "code" : "404595000",
            "display" : "Salmonella II 50:m,t:z6:z42 (organism)"
          },
          {
            "code" : "114925005",
            "display" : "Salmonella IV 51:a:- (organism)"
          },
          {
            "code" : "58006000",
            "display" : "Salmonella Carswell (organism)"
          },
          {
            "code" : "58146008",
            "display" : "Salmonella Yoff (organism)"
          },
          {
            "code" : "57255003",
            "display" : "Salmonella Ago (organism)"
          },
          {
            "code" : "114928007",
            "display" : "Salmonella II 51:c:- (organism)"
          },
          {
            "code" : "114545006",
            "display" : "Salmonella Portanigra (organism)"
          },
          {
            "code" : "13009006",
            "display" : "Salmonella Madelia (organism)"
          },
          {
            "code" : "712764007",
            "display" : "Salmonella species not Salmonella typhi (organism)"
          },
          {
            "code" : "9952003",
            "display" : "Salmonella Tanger (organism)"
          },
          {
            "code" : "114883000",
            "display" : "Salmonella II 48:e,n,x,z15:z6 (organism)"
          },
          {
            "code" : "28206007",
            "display" : "Salmonella Cannstatt (organism)"
          },
          {
            "code" : "114542009",
            "display" : "Salmonella II 6,8:a:z39 (organism)"
          },
          {
            "code" : "79617006",
            "display" : "Salmonella Jos (organism)"
          },
          {
            "code" : "114286003",
            "display" : "Salmonella Stockholm var 15+ (organism)"
          },
          {
            "code" : "404320003",
            "display" : "Salmonella IIIa 21:g,z51:- (organism)"
          },
          {
            "code" : "302674004",
            "display" : "Salmonella Mahina (organism)"
          },
          {
            "code" : "68807006",
            "display" : "Salmonella Preston (organism)"
          },
          {
            "code" : "38788001",
            "display" : "Salmonella Havana (organism)"
          },
          {
            "code" : "114526002",
            "display" : "Salmonella II 6,7:z36:z42 (organism)"
          },
          {
            "code" : "398620001",
            "display" : "Salmonella enterica subsp. indica (organism)"
          },
          {
            "code" : "66585001",
            "display" : "Salmonella Kalina (organism)"
          },
          {
            "code" : "398346007",
            "display" : "Salmonella IIIb 61:z52:1,5,7 (organism)"
          },
          {
            "code" : "6458008",
            "display" : "Salmonella Yovokome (organism)"
          },
          {
            "code" : "398389006",
            "display" : "Salmonella IIIa, group O:7 (organism)"
          },
          {
            "code" : "105781006",
            "display" : "Salmonella group O:67 (organism)"
          },
          {
            "code" : "114436007",
            "display" : "Salmonella II 17:k:- (organism)"
          },
          {
            "code" : "78367001",
            "display" : "Salmonella Bingerville (organism)"
          },
          {
            "code" : "114357003",
            "display" : "Salmonella II 1,13,23:m,t:z42 (organism)"
          },
          {
            "code" : "51488004",
            "display" : "Salmonella Abortusequi (organism)"
          },
          {
            "code" : "302637003",
            "display" : "Salmonella Cardiff (organism)"
          },
          {
            "code" : "404276008",
            "display" : "Salmonella I, group O:17 (organism)"
          },
          {
            "code" : "404258001",
            "display" : "Salmonella IIIb 16:z10:1,5,7 (organism)"
          },
          {
            "code" : "74958000",
            "display" : "Salmonella Gori (organism)"
          },
          {
            "code" : "404474008",
            "display" : "Salmonella IIIa 44:z4,z23,z32:- (organism)"
          },
          {
            "code" : "83138004",
            "display" : "Salmonella Nagoya (organism)"
          },
          {
            "code" : "58845009",
            "display" : "Salmonella Ilala (organism)"
          },
          {
            "code" : "398426003",
            "display" : "Salmonella group O:2 (organism)"
          },
          {
            "code" : "404351005",
            "display" : "Salmonella IIIb 35:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "15691000",
            "display" : "Salmonella Korbol (organism)"
          },
          {
            "code" : "398386004",
            "display" : "Salmonella II 3,10:z29:e,n,x (organism)"
          },
          {
            "code" : "40703006",
            "display" : "Salmonella Geraldton (organism)"
          },
          {
            "code" : "91661006",
            "display" : "Salmonella Weltevreden (organism)"
          },
          {
            "code" : "18578007",
            "display" : "Salmonella Ashanti (organism)"
          },
          {
            "code" : "114536005",
            "display" : "Salmonella Oranienburg var 14+ (organism)"
          },
          {
            "code" : "83230004",
            "display" : "Salmonella Belfast (organism)"
          },
          {
            "code" : "2286000",
            "display" : "Salmonella Agbeni (organism)"
          },
          {
            "code" : "11926006",
            "display" : "Salmonella Hannover (organism)"
          },
          {
            "code" : "370576005",
            "display" : "Salmonella Gallinarum (organism)"
          },
          {
            "code" : "114291002",
            "display" : "Salmonella Meleagridis var 15+, 34+ (organism)"
          },
          {
            "code" : "70004000",
            "display" : "Salmonella Honelis (organism)"
          },
          {
            "code" : "398493001",
            "display" : "Salmonella II, group O:60 (organism)"
          },
          {
            "code" : "43182007",
            "display" : "Salmonella Skansen (organism)"
          },
          {
            "code" : "5610000",
            "display" : "Salmonella Azteca (organism)"
          },
          {
            "code" : "404492000",
            "display" : "Salmonella II, group O:47 (organism)"
          },
          {
            "code" : "114381005",
            "display" : "Salmonella II 6,14,[24]:k:1,6 (organism)"
          },
          {
            "code" : "43409005",
            "display" : "Salmonella Massakory (organism)"
          },
          {
            "code" : "21618001",
            "display" : "Salmonella Morocco (organism)"
          },
          {
            "code" : "22899009",
            "display" : "Salmonella Falkensee (organism)"
          },
          {
            "code" : "7303003",
            "display" : "Salmonella II 28:m,t:(e,n,x) (organism)"
          },
          {
            "code" : "404372008",
            "display" : "Salmonella IIIb 38:(k):1,5,7 (organism)"
          },
          {
            "code" : "398561007",
            "display" : "Salmonella II, group O:9 (organism)"
          },
          {
            "code" : "59839006",
            "display" : "Salmonella Mpouto (organism)"
          },
          {
            "code" : "116376004",
            "display" : "Salmonella serotype C2,6,8:z10:- (organism)"
          },
          {
            "code" : "45091005",
            "display" : "Salmonella Enschede (organism)"
          },
          {
            "code" : "88649009",
            "display" : "Salmonella Colombo (organism)"
          },
          {
            "code" : "86669006",
            "display" : "Salmonella Overchurch (organism)"
          },
          {
            "code" : "783344000",
            "display" : "Salmonella enterica subspecies enterica serovar 4,5,12:-:- (organism)"
          },
          {
            "code" : "64539001",
            "display" : "Salmonella Abobo (organism)"
          },
          {
            "code" : "114934000",
            "display" : "Salmonella II 51:l,z28:z39 (organism)"
          },
          {
            "code" : "87975009",
            "display" : "Salmonella Kitenge (organism)"
          },
          {
            "code" : "83148002",
            "display" : "Salmonella Bama (organism)"
          },
          {
            "code" : "404432003",
            "display" : "Salmonella II, group O:42 (organism)"
          },
          {
            "code" : "398334008",
            "display" : "Salmonella I, group O:9 (organism)"
          },
          {
            "code" : "114312007",
            "display" : "Salmonella Thies (organism)"
          },
          {
            "code" : "114295006",
            "display" : "Salmonella Lexington var 15+, 34+ (organism)"
          },
          {
            "code" : "87906009",
            "display" : "Salmonella Anderlecht (organism)"
          },
          {
            "code" : "112287008",
            "display" : "Salmonella Sandiego (organism)"
          },
          {
            "code" : "34153004",
            "display" : "Salmonella Brazzaville (organism)"
          },
          {
            "code" : "58723002",
            "display" : "Salmonella Larochelle (organism)"
          },
          {
            "code" : "404570001",
            "display" : "Salmonella IIIb 48:i:z (organism)"
          },
          {
            "code" : "114552008",
            "display" : "Salmonella II 6,8:l,w:z6:z42 (organism)"
          },
          {
            "code" : "114517000",
            "display" : "Salmonella IV 6,7:z4,z23:- (organism)"
          },
          {
            "code" : "398449001",
            "display" : "Salmonella IIIa 6,7:(k):z:(z55) (organism)"
          },
          {
            "code" : "114785003",
            "display" : "Salmonella II 41:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "404463004",
            "display" : "Salmonella IIIa 43:z36:- (organism)"
          },
          {
            "code" : "69176009",
            "display" : "Salmonella Uhlenhorst (organism)"
          },
          {
            "code" : "63058007",
            "display" : "Salmonella Halle (organism)"
          },
          {
            "code" : "114990006",
            "display" : "Salmonella IIIb 61:k:z35 (organism)"
          },
          {
            "code" : "32549009",
            "display" : "Salmonella Djermaia (organism)"
          },
          {
            "code" : "48465004",
            "display" : "Salmonella Nyborg (organism)"
          },
          {
            "code" : "404359007",
            "display" : "Salmonella IIIa 35:z29:- (organism)"
          },
          {
            "code" : "53285009",
            "display" : "Salmonella Nessziona (organism)"
          },
          {
            "code" : "6272001",
            "display" : "Salmonella II 56:d:- (organism)"
          },
          {
            "code" : "47569006",
            "display" : "Salmonella Clackamas (organism)"
          },
          {
            "code" : "398511003",
            "display" : "Salmonella I, group O:13 (organism)"
          },
          {
            "code" : "114558007",
            "display" : "Salmonella Daula (organism)"
          },
          {
            "code" : "398414008",
            "display" : "Salmonella II 1,9,12:a:e,n,x (organism)"
          },
          {
            "code" : "112306003",
            "display" : "Salmonella II 1,13,22:b:z42 (organism)"
          },
          {
            "code" : "114716007",
            "display" : "Salmonella Rothenburgsort (organism)"
          },
          {
            "code" : "114835003",
            "display" : "Salmonella V 44:r:- (organism)"
          },
          {
            "code" : "114477006",
            "display" : "Salmonella Madras (organism)"
          },
          {
            "code" : "398594005",
            "display" : "Salmonella Yaba var 15+ (organism)"
          },
          {
            "code" : "26080001",
            "display" : "Salmonella Avignon (organism)"
          },
          {
            "code" : "52237001",
            "display" : "Salmonella Osnabrueck (organism)"
          },
          {
            "code" : "398481005",
            "display" : "Salmonella IIIb 60:k:z (organism)"
          },
          {
            "code" : "114671000",
            "display" : "Salmonella II 28:b:z6 (organism)"
          },
          {
            "code" : "16582001",
            "display" : "Salmonella Eboko (organism)"
          },
          {
            "code" : "39015005",
            "display" : "Salmonella Amoutive (organism)"
          },
          {
            "code" : "398470007",
            "display" : "Salmonella IIIa, group O:63 (organism)"
          },
          {
            "code" : "32854006",
            "display" : "Salmonella Sanktgeorg (organism)"
          },
          {
            "code" : "43575001",
            "display" : "Salmonella Bahrenfeld (organism)"
          },
          {
            "code" : "114992003",
            "display" : "Salmonella V 61:z35:- (organism)"
          },
          {
            "code" : "28879007",
            "display" : "Salmonella Gwale (organism)"
          },
          {
            "code" : "59316007",
            "display" : "Salmonella Losangeles (organism)"
          },
          {
            "code" : "28717009",
            "display" : "Salmonella Waycross (organism)"
          },
          {
            "code" : "114941006",
            "display" : "Salmonella Bordeaux (organism)"
          },
          {
            "code" : "114364001",
            "display" : "Salmonella II 1,13,23:z:z42 (organism)"
          },
          {
            "code" : "398593004",
            "display" : "Salmonella group O:7 (organism)"
          },
          {
            "code" : "60711005",
            "display" : "Salmonella II 30:b:z6 (organism)"
          },
          {
            "code" : "114819005",
            "display" : "Salmonella II 43:g,t:[1,5] (organism)"
          },
          {
            "code" : "114670004",
            "display" : "Salmonella Freefalls (organism)"
          },
          {
            "code" : "404319009",
            "display" : "Salmonella IIIa 21:z4,z24:- (organism)"
          },
          {
            "code" : "398527005",
            "display" : "Salmonella IIIb 65:c:z (organism)"
          },
          {
            "code" : "69712009",
            "display" : "Salmonella Kambole (organism)"
          },
          {
            "code" : "114482004",
            "display" : "Salmonella II 4,12:l,w:e,n,x (organism)"
          },
          {
            "code" : "398574001",
            "display" : "Salmonella IIIa 53:z29:- (organism)"
          },
          {
            "code" : "398388003",
            "display" : "Salmonella IIIb 53:z10:z35 (organism)"
          },
          {
            "code" : "114980003",
            "display" : "Salmonella IIIb 59:r:z35 (organism)"
          },
          {
            "code" : "398537000",
            "display" : "Salmonella 3,10:R1,z40:1,7 (organism)"
          },
          {
            "code" : "48831005",
            "display" : "Salmonella Naestved (organism)"
          },
          {
            "code" : "114951007",
            "display" : "Salmonella II 53:l,z28:z39 (organism)"
          },
          {
            "code" : "404495003",
            "display" : "Salmonella IV, group O:47 (organism)"
          },
          {
            "code" : "46474006",
            "display" : "Salmonella II 43:d:z39 (organism)"
          },
          {
            "code" : "131282009",
            "display" : "Salmonella serotype B, :-:1,2 (organism)"
          },
          {
            "code" : "404466007",
            "display" : "Salmonella IV 43:z29:- (organism)"
          },
          {
            "code" : "114703007",
            "display" : "Salmonella Gouloumbo (organism)"
          },
          {
            "code" : "398331000",
            "display" : "Salmonella IIIb 61:(k):z53 (organism)"
          },
          {
            "code" : "53230005",
            "display" : "Salmonella Goettingen (organism)"
          },
          {
            "code" : "66778003",
            "display" : "Salmonella Elokate (organism)"
          },
          {
            "code" : "22367006",
            "display" : "Salmonella Chingola (organism)"
          },
          {
            "code" : "114731003",
            "display" : "Salmonella II 39:l,z28:e,n,x (organism)"
          },
          {
            "code" : "32488009",
            "display" : "Salmonella Paratyphi C (organism)"
          },
          {
            "code" : "24666009",
            "display" : "Salmonella Worthington (organism)"
          },
          {
            "code" : "90538009",
            "display" : "Salmonella Caracas (organism)"
          },
          {
            "code" : "114510003",
            "display" : "Salmonella II 6,7:l,z28:1,5:[z42] (organism)"
          },
          {
            "code" : "18717008",
            "display" : "Salmonella Edmonton (organism)"
          },
          {
            "code" : "8455004",
            "display" : "Salmonella Kentucky (organism)"
          },
          {
            "code" : "5937000",
            "display" : "Salmonella Abadina (organism)"
          },
          {
            "code" : "37091006",
            "display" : "Salmonella Derby (organism)"
          },
          {
            "code" : "24009000",
            "display" : "Salmonella Zuilen (organism)"
          },
          {
            "code" : "74705004",
            "display" : "Salmonella Suelldorf (organism)"
          },
          {
            "code" : "398485001",
            "display" : "Salmonella IIIb (6),14:l,v:z35 (organism)"
          },
          {
            "code" : "37339002",
            "display" : "Salmonella II 1,53:d:z39 (organism)"
          },
          {
            "code" : "54131009",
            "display" : "Salmonella Praha (organism)"
          },
          {
            "code" : "35091007",
            "display" : "Salmonella Trimdon (organism)"
          },
          {
            "code" : "114903004",
            "display" : "Salmonella IV 50:a:- (organism)"
          },
          {
            "code" : "24270007",
            "display" : "Salmonella Magumeri (organism)"
          },
          {
            "code" : "71733003",
            "display" : "Salmonella Molesey (organism)"
          },
          {
            "code" : "398351001",
            "display" : "Salmonella VI, group O:6,14 (organism)"
          },
          {
            "code" : "280003",
            "display" : "Salmonella Limete (organism)"
          },
          {
            "code" : "404567000",
            "display" : "Salmonella IIIa 48:z4,z24:- (organism)"
          },
          {
            "code" : "21395009",
            "display" : "Salmonella Grampian (organism)"
          },
          {
            "code" : "404328005",
            "display" : "Salmonella IIIb 21:z10:z (organism)"
          },
          {
            "code" : "404374009",
            "display" : "Salmonella IIIb 38:(k):z35:(z56) (organism)"
          },
          {
            "code" : "404261000",
            "display" : "Salmonella IV 16:z4,z23:- (organism)"
          },
          {
            "code" : "114400009",
            "display" : "Salmonella Cardoner (organism)"
          },
          {
            "code" : "114979001",
            "display" : "Salmonella II 59:k:(z) (organism)"
          },
          {
            "code" : "404307001",
            "display" : "Salmonella IIIb 18:l,v:z (organism)"
          },
          {
            "code" : "114855002",
            "display" : "Salmonella II 45:z:1,5 (organism)"
          },
          {
            "code" : "10409000",
            "display" : "Salmonella II 6,7:g,t:e,n,x:z42 (organism)"
          },
          {
            "code" : "16049005",
            "display" : "Salmonella II 16:b:z39 (organism)"
          },
          {
            "code" : "114551001",
            "display" : "Salmonella Kallo (organism)"
          },
          {
            "code" : "404335002",
            "display" : "Salmonella II, group O:28 (organism)"
          },
          {
            "code" : "114886008",
            "display" : "Salmonella IIIb 48:i:z61 (organism)"
          },
          {
            "code" : "114857005",
            "display" : "Salmonella II 45:z:z39 (organism)"
          },
          {
            "code" : "85143008",
            "display" : "Salmonella Telhashomer (organism)"
          },
          {
            "code" : "404321004",
            "display" : "Salmonella IIIb 21:i:1,5,7 (organism)"
          },
          {
            "code" : "75380004",
            "display" : "Salmonella Bangkok (organism)"
          },
          {
            "code" : "70344002",
            "display" : "Salmonella Cerro (organism)"
          },
          {
            "code" : "82586009",
            "display" : "Salmonella II 45:m,t:1,5 (organism)"
          },
          {
            "code" : "416828006",
            "display" : "Salmonella Saintemarie (organism)"
          },
          {
            "code" : "114988005",
            "display" : "Salmonella II 60:z29:e,n,x (organism)"
          },
          {
            "code" : "114721005",
            "display" : "Salmonella Stachus (organism)"
          },
          {
            "code" : "112299001",
            "display" : "Salmonella Benfica (organism)"
          },
          {
            "code" : "404385006",
            "display" : "Salmonella IIIb 38:r:z35 (organism)"
          },
          {
            "code" : "42992009",
            "display" : "Salmonella II 1,13,23:g,m,s,t:1,5 (organism)"
          },
          {
            "code" : "29173000",
            "display" : "Salmonella Tado (organism)"
          },
          {
            "code" : "16380005",
            "display" : "Salmonella Wuppertal (organism)"
          },
          {
            "code" : "85523008",
            "display" : "Salmonella II 51:z:29:e,n,x,z15 (organism)"
          },
          {
            "code" : "81994008",
            "display" : "Salmonella Guerin (organism)"
          },
          {
            "code" : "77046007",
            "display" : "Salmonella II, group O:65 (organism)"
          },
          {
            "code" : "61375004",
            "display" : "Salmonella II 1,40:c:z39 (organism)"
          },
          {
            "code" : "404347008",
            "display" : "Salmonella Alachua (organism)"
          },
          {
            "code" : "404256002",
            "display" : "Salmonella IIIb 16:l,v:z53 (organism)"
          },
          {
            "code" : "442122004",
            "display" : "Salmonella enterica subspecies enterica serovar 3,15:-:1,6 (organism)"
          },
          {
            "code" : "114999007",
            "display" : "Salmonella V 66:z35:- (organism)"
          },
          {
            "code" : "404415002",
            "display" : "Salmonella II, group O:41 (organism)"
          },
          {
            "code" : "114954004",
            "display" : "Salmonella IIIb 53:z10:z (organism)"
          },
          {
            "code" : "42615005",
            "display" : "Salmonella Toucra (organism)"
          },
          {
            "code" : "80326003",
            "display" : "Salmonella Mampong (organism)"
          },
          {
            "code" : "114561008",
            "display" : "Salmonella II 6,8:z29:1,2 (organism)"
          },
          {
            "code" : "404620005",
            "display" : "Salmonella IIIb 50:z52:1,5,7 (organism)"
          },
          {
            "code" : "115001006",
            "display" : "Salmonella V 66:z41:- (organism)"
          },
          {
            "code" : "7730006",
            "display" : "Salmonella Rawash (organism)"
          },
          {
            "code" : "114290001",
            "display" : "Salmonella Anatum var 15+, 34+ (organism)"
          },
          {
            "code" : "27522009",
            "display" : "Salmonella II 21:z:- (organism)"
          },
          {
            "code" : "6432008",
            "display" : "Salmonella Brive (organism)"
          },
          {
            "code" : "114843008",
            "display" : "Salmonella V 44:z39:- (organism)"
          },
          {
            "code" : "50161008",
            "display" : "Salmonella II 53:d:z42 (organism)"
          },
          {
            "code" : "404411006",
            "display" : "Salmonella IV 40:z4,z32:- (organism)"
          },
          {
            "code" : "404557005",
            "display" : "Salmonella IIIb 47:z52:z35 (organism)"
          },
          {
            "code" : "398578003",
            "display" : "Salmonella II 1,13,22:g,t:1,5 (organism)"
          },
          {
            "code" : "404560003",
            "display" : "Salmonella I, group O:48 (organism)"
          },
          {
            "code" : "114899006",
            "display" : "Salmonella V 48:z39:- (organism)"
          },
          {
            "code" : "114555005",
            "display" : "Salmonella Noya (organism)"
          },
          {
            "code" : "404593007",
            "display" : "Salmonella IV, group O:50 (organism)"
          },
          {
            "code" : "79128009",
            "display" : "Salmonella Paratyphi A (organism)"
          },
          {
            "code" : "404602001",
            "display" : "Salmonella IIIb 50:i:z (organism)"
          },
          {
            "code" : "73321004",
            "display" : "Salmonella Fareham (organism)"
          },
          {
            "code" : "404479003",
            "display" : "Salmonella IV 44:z4,z23:- (organism)"
          },
          {
            "code" : "114864007",
            "display" : "Salmonella II 47:b:1,5 (organism)"
          },
          {
            "code" : "89271003",
            "display" : "Salmonella Harrisonburg (organism)"
          },
          {
            "code" : "114267006",
            "display" : "Salmonella Pietersburg (organism)"
          },
          {
            "code" : "28106004",
            "display" : "Salmonella Lome (organism)"
          },
          {
            "code" : "32681008",
            "display" : "Salmonella Orion (organism)"
          },
          {
            "code" : "45938004",
            "display" : "Salmonella Saloniki (organism)"
          },
          {
            "code" : "14368004",
            "display" : "Salmonella Bergen (organism)"
          },
          {
            "code" : "5837001",
            "display" : "Salmonella IV 40:z4,z24:- (organism)"
          },
          {
            "code" : "114432009",
            "display" : "Salmonella Lowestoft (organism)"
          },
          {
            "code" : "9479007",
            "display" : "Salmonella Wandsworth (organism)"
          },
          {
            "code" : "34033001",
            "display" : "Salmonella Nuatja (organism)"
          },
          {
            "code" : "398431001",
            "display" : "Salmonella IIIb 59:z10:z53 (organism)"
          },
          {
            "code" : "60527001",
            "display" : "Salmonella Neumuenster (organism)"
          },
          {
            "code" : "19687000",
            "display" : "Salmonella II 40:z:z39 (organism)"
          },
          {
            "code" : "114274001",
            "display" : "Salmonella Anatum var 15+ (organism)"
          },
          {
            "code" : "404581003",
            "display" : "Salmonella IIIb 48:z10:z (organism)"
          },
          {
            "code" : "114537001",
            "display" : "Salmonella Gdansk var 14+ (organism)"
          },
          {
            "code" : "404545001",
            "display" : "Salmonella IIIb 47:l,v:z57 (organism)"
          },
          {
            "code" : "38171004",
            "display" : "Salmonella II 13,23:-:1,6 (organism)"
          },
          {
            "code" : "404334003",
            "display" : "Salmonella I, group O:28 (organism)"
          },
          {
            "code" : "42391008",
            "display" : "Salmonella Vitkin (organism)"
          },
          {
            "code" : "114848004",
            "display" : "Salmonella Warmsen (organism)"
          },
          {
            "code" : "114333003",
            "display" : "Salmonella Tours (organism)"
          },
          {
            "code" : "404302007",
            "display" : "Salmonella II 18:z4,z24:- (organism)"
          },
          {
            "code" : "11166006",
            "display" : "Salmonella II, group O:58 (organism)"
          },
          {
            "code" : "404612008",
            "display" : "Salmonella IIIb 50:r:z (organism)"
          },
          {
            "code" : "48884009",
            "display" : "Salmonella Weslaco (organism)"
          },
          {
            "code" : "114387009",
            "display" : "Salmonella VI 1,6,14,25:z10:1,(2),7 (organism)"
          },
          {
            "code" : "114473005",
            "display" : "Salmonella II 1,4,12,27:g,[m],[s],t:e,n,x (organism)"
          },
          {
            "code" : "404301000",
            "display" : "Salmonella II 18:z4,z23:- (organism)"
          },
          {
            "code" : "404322006",
            "display" : "Salmonella IIIb 21:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "114978009",
            "display" : "Salmonella IIIb 59:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "90712007",
            "display" : "Salmonella Aarhus (organism)"
          },
          {
            "code" : "115655006",
            "display" : "Salmonella II 6,7:-:1,6 (organism)"
          },
          {
            "code" : "114420005",
            "display" : "Salmonella II 16:z36:e,n,z15 (organism)"
          },
          {
            "code" : "30864008",
            "display" : "Salmonella Chittagong (organism)"
          },
          {
            "code" : "75347006",
            "display" : "Salmonella Cannonhill (organism)"
          },
          {
            "code" : "114830008",
            "display" : "Salmonella II 43:z42:1,5,7 (organism)"
          },
          {
            "code" : "13511005",
            "display" : "Salmonella Bodjonegoro (organism)"
          },
          {
            "code" : "404608002",
            "display" : "Salmonella IIIb 50:l,v:z (organism)"
          },
          {
            "code" : "5612008",
            "display" : "Salmonella Enugu (organism)"
          },
          {
            "code" : "398601003",
            "display" : "Salmonella IIIa 6,7:-:1,6 (organism)"
          },
          {
            "code" : "60230009",
            "display" : "Salmonella Broughton (organism)"
          },
          {
            "code" : "88461009",
            "display" : "Salmonella II 44:g,t:z42 (organism)"
          },
          {
            "code" : "43637009",
            "display" : "Salmonella II 9,12:a:z39 (organism)"
          },
          {
            "code" : "1245005",
            "display" : "Salmonella Kiel (organism)"
          },
          {
            "code" : "404443006",
            "display" : "Salmonella IIIb 42:l,v:z53 (organism)"
          },
          {
            "code" : "114585000",
            "display" : "Salmonella II 1,9,12:z:z6 (organism)"
          },
          {
            "code" : "12517002",
            "display" : "Salmonella Eschweiler (organism)"
          },
          {
            "code" : "21164005",
            "display" : "Salmonella Bulgaria (organism)"
          },
          {
            "code" : "404613003",
            "display" : "Salmonella IIIb 50:r:z35 (organism)"
          },
          {
            "code" : "80841005",
            "display" : "Salmonella Cayar (organism)"
          },
          {
            "code" : "89716000",
            "display" : "Salmonella Brikama (organism)"
          },
          {
            "code" : "114939005",
            "display" : "Salmonella II 51:-:1,7 (organism)"
          },
          {
            "code" : "33827003",
            "display" : "Salmonella Battle (organism)"
          },
          {
            "code" : "114578004",
            "display" : "Salmonella II 1,9,12:m,t:1,5 (organism)"
          },
          {
            "code" : "20872002",
            "display" : "Salmonella Mbao (organism)"
          },
          {
            "code" : "114975007",
            "display" : "Salmonella IIIb 58:z10:z53 (organism)"
          },
          {
            "code" : "23836008",
            "display" : "Salmonella Pontypridd (organism)"
          },
          {
            "code" : "79344007",
            "display" : "Salmonella Leopoldville (organism)"
          },
          {
            "code" : "114842003",
            "display" : "Salmonella II 1,44:z39:e,n,x,z15 (organism)"
          },
          {
            "code" : "785859001",
            "display" : "Salmonella Farmingdale (organism)"
          },
          {
            "code" : "404336001",
            "display" : "Salmonella IIIb, group O:28 (organism)"
          },
          {
            "code" : "398477005",
            "display" : "Salmonella IIIb, group O:13 (organism)"
          },
          {
            "code" : "114666007",
            "display" : "Salmonella II 28:a:e,n,x (organism)"
          },
          {
            "code" : "398400008",
            "display" : "Salmonella IIIa, group O:51 (organism)"
          },
          {
            "code" : "114993008",
            "display" : "Salmonella IIIa 62:z29:- (organism)"
          },
          {
            "code" : "302669007",
            "display" : "Salmonella Waedenswil (organism)"
          },
          {
            "code" : "57887008",
            "display" : "Salmonella IV 1,53:g,z51:- (organism)"
          },
          {
            "code" : "441926004",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:y:- (organism)"
          },
          {
            "code" : "404603006",
            "display" : "Salmonella IIIb 50:k:1,5,7 (organism)"
          },
          {
            "code" : "114856001",
            "display" : "Salmonella Yopougon (organism)"
          },
          {
            "code" : "404591009",
            "display" : "Salmonella IIIa, group O:50 (organism)"
          },
          {
            "code" : "53653001",
            "display" : "Salmonella II 6,7:b:z39 (organism)"
          },
          {
            "code" : "14262001",
            "display" : "Salmonella Hilversum (organism)"
          },
          {
            "code" : "114723008",
            "display" : "Salmonella Neunkirchen (organism)"
          },
          {
            "code" : "85047006",
            "display" : "Salmonella Balili (organism)"
          },
          {
            "code" : "40681000",
            "display" : "Salmonella Goeteborg (organism)"
          },
          {
            "code" : "417653002",
            "display" : "Salmonella Subterranea (organism)"
          },
          {
            "code" : "72514007",
            "display" : "Salmonella Karachi (organism)"
          },
          {
            "code" : "404413009",
            "display" : "Salmonella group O:41 (organism)"
          },
          {
            "code" : "398529008",
            "display" : "Salmonella V, group O:13 (organism)"
          },
          {
            "code" : "114768000",
            "display" : "Salmonella V 1,40:z81:- (organism)"
          },
          {
            "code" : "404547009",
            "display" : "Salmonella IIIb 47:r:1,5,7 (organism)"
          },
          {
            "code" : "13998005",
            "display" : "Salmonella IV 53:z4,z23:-- (organism)"
          },
          {
            "code" : "65303004",
            "display" : "Salmonella Sloterdijk (organism)"
          },
          {
            "code" : "42709001",
            "display" : "Salmonella Mikawasima (organism)"
          },
          {
            "code" : "404381002",
            "display" : "Salmonella IIIb 38:l,v:z (organism)"
          },
          {
            "code" : "60142007",
            "display" : "Salmonella Ndolo (organism)"
          },
          {
            "code" : "114491000",
            "display" : "Salmonella II 1,4,12:z29:e,n,x (organism)"
          },
          {
            "code" : "43942004",
            "display" : "Salmonella Koenigstuhl (organism)"
          },
          {
            "code" : "54260008",
            "display" : "Salmonella Redhill (organism)"
          },
          {
            "code" : "29083003",
            "display" : "Salmonella Nikolaifleet (organism)"
          },
          {
            "code" : "114973000",
            "display" : "Salmonella II 58:z6:1,6 (organism)"
          },
          {
            "code" : "12837008",
            "display" : "Salmonella Aschersleben (organism)"
          },
          {
            "code" : "114303005",
            "display" : "Salmonella Oersterbro (organism)"
          },
          {
            "code" : "59130007",
            "display" : "Salmonella Augustenborg (organism)"
          },
          {
            "code" : "114778002",
            "display" : "Salmonella Ferlo (organism)"
          },
          {
            "code" : "114635001",
            "display" : "Salmonella II 3,10:z38:z42 (organism)"
          },
          {
            "code" : "52648003",
            "display" : "Salmonella Tarshyne (organism)"
          },
          {
            "code" : "5461002",
            "display" : "Salmonella Chester (organism)"
          },
          {
            "code" : "42016005",
            "display" : "Salmonella Volta (organism)"
          },
          {
            "code" : "78287002",
            "display" : "Salmonella II 35:l,z28:- (organism)"
          },
          {
            "code" : "114626008",
            "display" : "Salmonella II 3,10:l,v:z6 (organism)"
          },
          {
            "code" : "81567003",
            "display" : "Salmonella II 41:b:1,5 (organism)"
          },
          {
            "code" : "416641008",
            "display" : "Salmonella IIIa 53:z4,z24:- (organism)"
          },
          {
            "code" : "80268001",
            "display" : "Salmonella Montevideo (organism)"
          },
          {
            "code" : "9179000",
            "display" : "Salmonella Bronx (organism)"
          },
          {
            "code" : "6233000",
            "display" : "Salmonella Warragul (organism)"
          },
          {
            "code" : "398514006",
            "display" : "Salmonella IV, group O:51 (organism)"
          },
          {
            "code" : "68937001",
            "display" : "Salmonella Itami (organism)"
          },
          {
            "code" : "733501004",
            "display" : "Salmonella II rough:l,z28:z6 (organism)"
          },
          {
            "code" : "21469008",
            "display" : "Salmonella Szentes (organism)"
          },
          {
            "code" : "78243006",
            "display" : "Salmonella Newmexico (organism)"
          },
          {
            "code" : "105771007",
            "display" : "Salmonella group O:56 (organism)"
          },
          {
            "code" : "3837003",
            "display" : "Salmonella Sendai (organism)"
          },
          {
            "code" : "5372008",
            "display" : "Salmonella Eko (organism)"
          },
          {
            "code" : "404414003",
            "display" : "Salmonella I, group O:41 (organism)"
          },
          {
            "code" : "114346008",
            "display" : "Salmonella II 1,13,23:a:z42 (organism)"
          },
          {
            "code" : "11062005",
            "display" : "Salmonella Sherbrooke (organism)"
          },
          {
            "code" : "114607000",
            "display" : "Salmonella II 9,46:z:1,5 (organism)"
          },
          {
            "code" : "58134009",
            "display" : "Salmonella II 43:g,z62:e,n,x (organism)"
          },
          {
            "code" : "33613006",
            "display" : "Salmonella Holcomb (organism)"
          },
          {
            "code" : "17007007",
            "display" : "Salmonella Llandoff (organism)"
          },
          {
            "code" : "42597008",
            "display" : "Salmonella Gallen (organism)"
          },
          {
            "code" : "114646003",
            "display" : "Salmonella II 18:z10:z6 (organism)"
          },
          {
            "code" : "7031002",
            "display" : "Salmonella California (organism)"
          },
          {
            "code" : "45958003",
            "display" : "Salmonella Blukwa (organism)"
          },
          {
            "code" : "441896006",
            "display" : "Salmonella enterica subspecies enterica serovar 4,5,12:b:- (organism)"
          },
          {
            "code" : "36324007",
            "display" : "Salmonella II 30:z39:1,7 (organism)"
          },
          {
            "code" : "404433008",
            "display" : "Salmonella IIIa, group O:42 (organism)"
          },
          {
            "code" : "29115000",
            "display" : "Salmonella Kisarawe (organism)"
          },
          {
            "code" : "4614004",
            "display" : "Salmonella Galiema (organism)"
          },
          {
            "code" : "64578002",
            "display" : "Salmonella Herston (organism)"
          },
          {
            "code" : "80087003",
            "display" : "Salmonella Teko (organism)"
          },
          {
            "code" : "114789009",
            "display" : "Salmonella II 41:g,m,s,t:z6 (organism)"
          },
          {
            "code" : "114776003",
            "display" : "Salmonella Samaru (organism)"
          },
          {
            "code" : "19981002",
            "display" : "Salmonella II 6,7:k:(z6) (organism)"
          },
          {
            "code" : "404600009",
            "display" : "Salmonella IIIb 50:i:1,5,7 (organism)"
          },
          {
            "code" : "114905006",
            "display" : "Salmonella IV 50:b:- (organism)"
          },
          {
            "code" : "37286001",
            "display" : "Salmonella Penarth (organism)"
          },
          {
            "code" : "404312000",
            "display" : "Salmonella II, group O:21 (organism)"
          },
          {
            "code" : "45802005",
            "display" : "Salmonella Tejas (organism)"
          },
          {
            "code" : "398539002",
            "display" : "Salmonella IIIa, group O:59 (organism)"
          },
          {
            "code" : "47039009",
            "display" : "Salmonella Jodhpur (organism)"
          },
          {
            "code" : "114997009",
            "display" : "Salmonella IIIb 65:z52:e,n,x,z15 (organism)"
          },
          {
            "code" : "51706003",
            "display" : "Salmonella Lansing (organism)"
          },
          {
            "code" : "114654001",
            "display" : "Salmonella II 21:m,t:- (organism)"
          },
          {
            "code" : "404287000",
            "display" : "Salmonella IIIa 17:z29:- (organism)"
          },
          {
            "code" : "82140000",
            "display" : "Salmonella Uccle (organism)"
          },
          {
            "code" : "29449001",
            "display" : "Salmonella Ndjamena (organism)"
          },
          {
            "code" : "62325003",
            "display" : "Salmonella Kisii (organism)"
          },
          {
            "code" : "404379004",
            "display" : "Salmonella IIIb 38:k:z (organism)"
          },
          {
            "code" : "25487003",
            "display" : "Salmonella Eingedi (organism)"
          },
          {
            "code" : "114794009",
            "display" : "Salmonella II 42:d:z6 (organism)"
          },
          {
            "code" : "114553003",
            "display" : "Salmonella II 6,8:l,z28:e,n,x (organism)"
          },
          {
            "code" : "404426008",
            "display" : "Salmonella IIIa 41:z4,z23,z32:- (organism)"
          },
          {
            "code" : "114873004",
            "display" : "Salmonella II 47:z:z6 (organism)"
          },
          {
            "code" : "404398002",
            "display" : "Salmonella IIIb, group O:40 (organism)"
          },
          {
            "code" : "398437002",
            "display" : "Salmonella IIIb 65:c:z53 (organism)"
          },
          {
            "code" : "398401007",
            "display" : "Salmonella II, group O:4 (organism)"
          },
          {
            "code" : "110378009",
            "display" : "Salmonella enterica (organism)"
          },
          {
            "code" : "114784004",
            "display" : "Salmonella II 41:z10:e,n,x,z (organism)"
          },
          {
            "code" : "11488000",
            "display" : "Salmonella Sundsvall (organism)"
          },
          {
            "code" : "66544006",
            "display" : "Salmonella Brevik (organism)"
          },
          {
            "code" : "114948000",
            "display" : "Salmonella IIIb 53:k:z53 (organism)"
          },
          {
            "code" : "64080004",
            "display" : "Salmonella Warnow (organism)"
          },
          {
            "code" : "114841005",
            "display" : "Salmonella IV 44:z29:- (organism)"
          },
          {
            "code" : "114402001",
            "display" : "Salmonella Agbara (organism)"
          },
          {
            "code" : "6086006",
            "display" : "Salmonella Kinondoni (organism)"
          },
          {
            "code" : "114804009",
            "display" : "Salmonella II 42:z:1,5 (organism)"
          },
          {
            "code" : "114305003",
            "display" : "Salmonella Fulda (organism)"
          },
          {
            "code" : "37669003",
            "display" : "Salmonella Langford (organism)"
          },
          {
            "code" : "441840004",
            "display" : "Salmonella enterica subspecies enterica serovar 4,5,12:e,h:- (organism)"
          },
          {
            "code" : "398383007",
            "display" : "Salmonella IV, group O:6,14 (organism)"
          },
          {
            "code" : "114777007",
            "display" : "Salmonella Verona (organism)"
          },
          {
            "code" : "114707008",
            "display" : "Salmonella IIIb 35:i:z35 (organism)"
          },
          {
            "code" : "114989002",
            "display" : "Salmonella V 60:z41:- (organism)"
          },
          {
            "code" : "86837000",
            "display" : "Salmonella Mkamba (organism)"
          },
          {
            "code" : "66442007",
            "display" : "Salmonella Luke (organism)"
          },
          {
            "code" : "85893005",
            "display" : "Salmonella Tomegbe (organism)"
          },
          {
            "code" : "55932005",
            "display" : "Salmonella Cubana (organism)"
          },
          {
            "code" : "404251007",
            "display" : "Salmonella IIIb 16:i:z35 (organism)"
          },
          {
            "code" : "57101009",
            "display" : "Salmonella Poona (organism)"
          },
          {
            "code" : "105775003",
            "display" : "Salmonella group O:60 (organism)"
          },
          {
            "code" : "75104004",
            "display" : "Salmonella Bradford (organism)"
          },
          {
            "code" : "88944002",
            "display" : "Salmonella Galil (organism)"
          },
          {
            "code" : "35203007",
            "display" : "Salmonella Croft (organism)"
          },
          {
            "code" : "114770009",
            "display" : "Salmonella Burundi (organism)"
          },
          {
            "code" : "114580005",
            "display" : "Salmonella Kotu (organism)"
          },
          {
            "code" : "49831004",
            "display" : "Salmonella Deversoir (organism)"
          },
          {
            "code" : "50113001",
            "display" : "Salmonella Accra (organism)"
          },
          {
            "code" : "114379008",
            "display" : "Salmonella II 1,6,14:m,t:1,5 (organism)"
          },
          {
            "code" : "85588001",
            "display" : "Salmonella Gabon (organism)"
          },
          {
            "code" : "114852004",
            "display" : "Salmonella Verviers (organism)"
          },
          {
            "code" : "760000",
            "display" : "Salmonella Djelfa (organism)"
          },
          {
            "code" : "14219002",
            "display" : "Salmonella Kahla (organism)"
          },
          {
            "code" : "18711009",
            "display" : "Salmonella Saugus (organism)"
          },
          {
            "code" : "26494008",
            "display" : "Salmonella II 53:z:1,5 (organism)"
          },
          {
            "code" : "715049006",
            "display" : "Salmonella group O:6,7 (organism)"
          },
          {
            "code" : "116057007",
            "display" : "Salmonella Bloomsbury (organism)"
          },
          {
            "code" : "581003",
            "display" : "Salmonella Canada (organism)"
          },
          {
            "code" : "302654006",
            "display" : "Salmonella II 6,8:z29:e,n,x (organism)"
          },
          {
            "code" : "3154009",
            "display" : "Salmonella Oyonnax (organism)"
          },
          {
            "code" : "114431002",
            "display" : "Salmonella II 17:g,m,s,t:- (organism)"
          },
          {
            "code" : "114690008",
            "display" : "Salmonella Konolfingen (organism)"
          },
          {
            "code" : "398502003",
            "display" : "Salmonella IIIb 61:r:z35 (organism)"
          },
          {
            "code" : "404421003",
            "display" : "Salmonella IIIb 41:(k):z35 (organism)"
          },
          {
            "code" : "398547002",
            "display" : "Salmonella group O:1,3,19 (organism)"
          },
          {
            "code" : "398417001",
            "display" : "Salmonella IIIb 61:r:1,5,7 (organism)"
          },
          {
            "code" : "114688007",
            "display" : "Salmonella II 28:z29:1,5 (organism)"
          },
          {
            "code" : "114474004",
            "display" : "Salmonella II 1,4,12,27:g,[m],t:[1,5] (organism)"
          },
          {
            "code" : "46438002",
            "display" : "Salmonella II 43:d:z42 (organism)"
          },
          {
            "code" : "404436000",
            "display" : "Salmonella Melbourne (organism)"
          },
          {
            "code" : "404586008",
            "display" : "Salmonella IIIb 48:z52:z (organism)"
          },
          {
            "code" : "56040008",
            "display" : "Salmonella Bietri (organism)"
          },
          {
            "code" : "114426004",
            "display" : "Salmonella II 17:b:e,n,x,z15 (organism)"
          },
          {
            "code" : "114465001",
            "display" : "Salmonella II 4,12:b:1,5 (organism)"
          },
          {
            "code" : "114884006",
            "display" : "Salmonella II 48:g,m,t:- (organism)"
          },
          {
            "code" : "404448002",
            "display" : "Salmonella IIIb 42:z10:z35 (organism)"
          },
          {
            "code" : "16888008",
            "display" : "Salmonella Brandenburg (organism)"
          },
          {
            "code" : "88601003",
            "display" : "Salmonella II 50:l,w:e,n,x,z15:z42 (organism)"
          },
          {
            "code" : "24951009",
            "display" : "Salmonella Wagenia (organism)"
          },
          {
            "code" : "404357009",
            "display" : "Salmonella IIIb 35:r:z61 (organism)"
          },
          {
            "code" : "22752009",
            "display" : "Salmonella Grumpensis (organism)"
          },
          {
            "code" : "6959008",
            "display" : "Salmonella Windermere (organism)"
          },
          {
            "code" : "398368002",
            "display" : "Salmonella IIIb 60:l,v:z (organism)"
          },
          {
            "code" : "82496003",
            "display" : "Salmonella Winterthur (organism)"
          },
          {
            "code" : "10874000",
            "display" : "Salmonella Bassadji (organism)"
          },
          {
            "code" : "114709006",
            "display" : "Salmonella IIIb 35:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "47223005",
            "display" : "Salmonella Kassberg (organism)"
          },
          {
            "code" : "404459006",
            "display" : "Salmonella IIIb 43:l,v:z53 (organism)"
          },
          {
            "code" : "77842008",
            "display" : "Salmonella Amherstiana (organism)"
          },
          {
            "code" : "398343004",
            "display" : "Salmonella IIIb, group O:57 (organism)"
          },
          {
            "code" : "114800000",
            "display" : "Salmonella II 42:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "11577009",
            "display" : "Salmonella Lawndale (organism)"
          },
          {
            "code" : "45488002",
            "display" : "Salmonella Magwa (organism)"
          },
          {
            "code" : "114746005",
            "display" : "Salmonella IIIa 40:g,z51:- (organism)"
          },
          {
            "code" : "114338007",
            "display" : "Salmonella Maroua (organism)"
          },
          {
            "code" : "404318001",
            "display" : "Salmonella II 21:z4,z24:- (organism)"
          },
          {
            "code" : "404467003",
            "display" : "Salmonella group O:44 (organism)"
          },
          {
            "code" : "70456000",
            "display" : "Salmonella Ahmadi (organism)"
          },
          {
            "code" : "43833005",
            "display" : "Salmonella Fallowfield (organism)"
          },
          {
            "code" : "404571002",
            "display" : "Salmonella IIIb 48:i:z35:(z57) (organism)"
          },
          {
            "code" : "84543005",
            "display" : "Salmonella Gombe (organism)"
          },
          {
            "code" : "398392005",
            "display" : "Salmonella IIIb 58:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "114710001",
            "display" : "Salmonella IIIb 35:l,v:z35:[z67] (organism)"
          },
          {
            "code" : "114313002",
            "display" : "Salmonella Slade (organism)"
          },
          {
            "code" : "2356009",
            "display" : "Salmonella Patience (organism)"
          },
          {
            "code" : "114945002",
            "display" : "Salmonella II 52:z39:1,5,7 (organism)"
          },
          {
            "code" : "114782000",
            "display" : "Salmonella Bofflens (organism)"
          },
          {
            "code" : "45714007",
            "display" : "Salmonella Nordufer (organism)"
          },
          {
            "code" : "114612004",
            "display" : "Salmonella II 1,9,12,46,27:a:z6 (organism)"
          },
          {
            "code" : "89640003",
            "display" : "Salmonella Kalamu (organism)"
          },
          {
            "code" : "114512006",
            "display" : "Salmonella Chile (organism)"
          },
          {
            "code" : "114489008",
            "display" : "Salmonella II 4,12,:z:z39 (organism)"
          },
          {
            "code" : "11901002",
            "display" : "Salmonella Kiambu (organism)"
          },
          {
            "code" : "404317006",
            "display" : "Salmonella Baguida (organism)"
          },
          {
            "code" : "80508000",
            "display" : "Salmonella Boecker (organism)"
          },
          {
            "code" : "47508001",
            "display" : "Salmonella Johannesburg (organism)"
          },
          {
            "code" : "404472007",
            "display" : "Salmonella IV, group O:44 (organism)"
          },
          {
            "code" : "29429005",
            "display" : "Salmonella Handen (organism)"
          },
          {
            "code" : "404583000",
            "display" : "Salmonella IIIa 48:z4,z23,z32:- (organism)"
          },
          {
            "code" : "66773007",
            "display" : "Salmonella IV, group O:53 (organism)"
          },
          {
            "code" : "404277004",
            "display" : "Salmonella II, group O:17 (organism)"
          },
          {
            "code" : "114639007",
            "display" : "Salmonella IV 17:z36:- (organism)"
          },
          {
            "code" : "398439004",
            "display" : "Salmonella IIIa, group O:62 (organism)"
          },
          {
            "code" : "52004009",
            "display" : "Salmonella II 43:d:e,n,x,z15 (organism)"
          },
          {
            "code" : "114987000",
            "display" : "Salmonella IIIb 60:z10:z53 (organism)"
          },
          {
            "code" : "398515007",
            "display" : "Salmonella Zanzibar var 15+ (organism)"
          },
          {
            "code" : "398555009",
            "display" : "Salmonella II, group O:16 (organism)"
          },
          {
            "code" : "39901006",
            "display" : "Salmonella Garoli (organism)"
          },
          {
            "code" : "397502001",
            "display" : "Salmonella enterica subsp. arizonae (organism)"
          },
          {
            "code" : "26207009",
            "display" : "Salmonella II 43:a:z6 (organism)"
          },
          {
            "code" : "114765002",
            "display" : "Salmonella IIIb 40:z39:1,6 (organism)"
          },
          {
            "code" : "398336005",
            "display" : "Salmonella IIIb 60:k:z35 (organism)"
          },
          {
            "code" : "114280009",
            "display" : "Salmonella London var 15+ (organism)"
          },
          {
            "code" : "48578002",
            "display" : "Salmonella Ablogame (organism)"
          },
          {
            "code" : "114339004",
            "display" : "Salmonella II 11:z:e,n,x (organism)"
          },
          {
            "code" : "18271002",
            "display" : "Salmonella Bobo (organism)"
          },
          {
            "code" : "404584006",
            "display" : "Salmonella IIIa 48:z4,z23:- (organism)"
          },
          {
            "code" : "114409005",
            "display" : "Salmonella II 16:z:e,n,x (organism)"
          },
          {
            "code" : "57247005",
            "display" : "Salmonella II 45:z29:z42 (organism)"
          },
          {
            "code" : "398532006",
            "display" : "Salmonella IIIa 1,13,23:g,z51:- (organism)"
          },
          {
            "code" : "114294005",
            "display" : "Salmonella Orion var 15+, 34+ (organism)"
          },
          {
            "code" : "85819008",
            "display" : "Salmonella Luckenwalde (organism)"
          },
          {
            "code" : "78139003",
            "display" : "Salmonella Arechavaleta (organism)"
          },
          {
            "code" : "105778001",
            "display" : "Salmonella group O:63 (organism)"
          },
          {
            "code" : "404278009",
            "display" : "Salmonella IIIa, group O:17 (organism)"
          },
          {
            "code" : "114863001",
            "display" : "Salmonella Wenatchee (organism)"
          },
          {
            "code" : "404297009",
            "display" : "Salmonella IIIa, group O:18 (organism)"
          },
          {
            "code" : "114573008",
            "display" : "Salmonella II 9,12:d:z39 (organism)"
          },
          {
            "code" : "114513001",
            "display" : "Salmonella Poitiers (organism)"
          },
          {
            "code" : "47441000",
            "display" : "Salmonella Stanleyville (organism)"
          },
          {
            "code" : "114516009",
            "display" : "Salmonella Planckendael (organism)"
          },
          {
            "code" : "69716007",
            "display" : "Salmonella Redba (organism)"
          },
          {
            "code" : "79570007",
            "display" : "Salmonella Kokomlemle (organism)"
          },
          {
            "code" : "114589006",
            "display" : "Salmonella Franken (organism)"
          },
          {
            "code" : "404476005",
            "display" : "Salmonella IIIa 44:z4,z32:- (organism)"
          },
          {
            "code" : "57053004",
            "display" : "Salmonella Saboya (organism)"
          },
          {
            "code" : "398457003",
            "display" : "Salmonella IIIb 53:z52:z53 (organism)"
          },
          {
            "code" : "105776002",
            "display" : "Salmonella group O:61 (organism)"
          },
          {
            "code" : "31832006",
            "display" : "Salmonella II 1,40:m,t:z42 (organism)"
          },
          {
            "code" : "77231007",
            "display" : "Salmonella Doba (organism)"
          },
          {
            "code" : "105777006",
            "display" : "Salmonella group O:62 (organism)"
          },
          {
            "code" : "114682008",
            "display" : "Salmonella II 28:z:1,5 (organism)"
          },
          {
            "code" : "63734000",
            "display" : "Salmonella Mowanjum (organism)"
          },
          {
            "code" : "70605000",
            "display" : "Salmonella Manchester (organism)"
          },
          {
            "code" : "46189007",
            "display" : "Salmonella Camberene (organism)"
          },
          {
            "code" : "114633008",
            "display" : "Salmonella Okerara (organism)"
          },
          {
            "code" : "82071007",
            "display" : "Salmonella Infantis (organism)"
          },
          {
            "code" : "1179072002",
            "display" : "Salmonella group C (organism)"
          },
          {
            "code" : "114306002",
            "display" : "Salmonella Kindia (organism)"
          },
          {
            "code" : "404392001",
            "display" : "Salmonella I, group O:39 (organism)"
          },
          {
            "code" : "114348009",
            "display" : "Salmonella Sanktjohann (organism)"
          },
          {
            "code" : "114809004",
            "display" : "Salmonella IV 1,42:z4,z24:- (organism)"
          },
          {
            "code" : "114428003",
            "display" : "Salmonella Karlshamn (organism)"
          },
          {
            "code" : "46375008",
            "display" : "Salmonella Utrecht (organism)"
          },
          {
            "code" : "86698005",
            "display" : "Salmonella Haga (organism)"
          },
          {
            "code" : "52511000",
            "display" : "Salmonella Amersfoort (organism)"
          },
          {
            "code" : "302667009",
            "display" : "Salmonella Kolar (organism)"
          },
          {
            "code" : "89839003",
            "display" : "Salmonella Buzu (organism)"
          },
          {
            "code" : "404361003",
            "display" : "Salmonella IIIa 35:z4,z32:- (organism)"
          },
          {
            "code" : "54021004",
            "display" : "Salmonella Lode (organism)"
          },
          {
            "code" : "62024006",
            "display" : "Salmonella II 50:b:z6 (organism)"
          },
          {
            "code" : "14424002",
            "display" : "Salmonella Tees (organism)"
          },
          {
            "code" : "16168006",
            "display" : "Salmonella II 58:b:1,5 (organism)"
          },
          {
            "code" : "105774004",
            "display" : "Salmonella group O:59 (organism)"
          },
          {
            "code" : "10457006",
            "display" : "Salmonella Dakota (organism)"
          },
          {
            "code" : "3312002",
            "display" : "Salmonella Fresno (organism)"
          },
          {
            "code" : "114508000",
            "display" : "Salmonella II 6,7:m,t:- (organism)"
          },
          {
            "code" : "60512001",
            "display" : "Salmonella II 3,10:l,v:e,n,x (organism)"
          },
          {
            "code" : "64863004",
            "display" : "Salmonella Ljubljana (organism)"
          },
          {
            "code" : "43078007",
            "display" : "Salmonella Paris (organism)"
          },
          {
            "code" : "404622002",
            "display" : "Salmonella IIIb 50:z52:z35 (organism)"
          },
          {
            "code" : "48652000",
            "display" : "Salmonella Agodi (organism)"
          },
          {
            "code" : "18088003",
            "display" : "Salmonella Korlebu (organism)"
          },
          {
            "code" : "8428008",
            "display" : "Salmonella Ullevi (organism)"
          },
          {
            "code" : "14007002",
            "display" : "Salmonella Vom (organism)"
          },
          {
            "code" : "404416001",
            "display" : "Salmonella IIIa, group O:41 (organism)"
          },
          {
            "code" : "114408002",
            "display" : "Salmonella Gerland (organism)"
          },
          {
            "code" : "404596004",
            "display" : "Salmonella II 50:z42:1,7 (organism)"
          },
          {
            "code" : "63142006",
            "display" : "Salmonella Hato (organism)"
          },
          {
            "code" : "2399004",
            "display" : "Salmonella Quiniela (organism)"
          },
          {
            "code" : "404572009",
            "display" : "Salmonella IIIb 48:i:z53 (organism)"
          },
          {
            "code" : "90970000",
            "display" : "Salmonella Diogoye (organism)"
          },
          {
            "code" : "4867001",
            "display" : "Salmonella Malakal (organism)"
          },
          {
            "code" : "8307000",
            "display" : "Salmonella Lille (organism)"
          },
          {
            "code" : "114331001",
            "display" : "Salmonella IIIb 11:l,v:z (organism)"
          },
          {
            "code" : "114767005",
            "display" : "Salmonella II 1,40:z42:1,6 (organism)"
          },
          {
            "code" : "114696002",
            "display" : "Salmonella Mjordan (organism)"
          },
          {
            "code" : "114532007",
            "display" : "Salmonella II 6,7:z42:1,7 (organism)"
          },
          {
            "code" : "88091007",
            "display" : "Salmonella Stanley (organism)"
          },
          {
            "code" : "112290002",
            "display" : "Salmonella Goma (organism)"
          },
          {
            "code" : "44580003",
            "display" : "Salmonella India (organism)"
          },
          {
            "code" : "48932004",
            "display" : "Salmonella Kandla (organism)"
          },
          {
            "code" : "112319004",
            "display" : "Salmonella Sedgwick (organism)"
          },
          {
            "code" : "4361005",
            "display" : "Salmonella Thompson (organism)"
          },
          {
            "code" : "56626006",
            "display" : "Salmonella Palime (organism)"
          },
          {
            "code" : "114296007",
            "display" : "Salmonella Niumi (organism)"
          },
          {
            "code" : "13682001",
            "display" : "Salmonella Hessarek (organism)"
          },
          {
            "code" : "83795006",
            "display" : "Salmonella Koketime (organism)"
          },
          {
            "code" : "114780008",
            "display" : "Salmonella II 41:k:z6 (organism)"
          },
          {
            "code" : "404423000",
            "display" : "Salmonella IIIa 41:g,z51:- (organism)"
          },
          {
            "code" : "114325004",
            "display" : "Salmonella II 11:g,[m],s,t:z39 (organism)"
          },
          {
            "code" : "57636007",
            "display" : "Salmonella II 1,9,12:z29:e,n,x (organism)"
          },
          {
            "code" : "114507005",
            "display" : "Salmonella Oakey (organism)"
          },
          {
            "code" : "57024000",
            "display" : "Salmonella Charlottenburg (organism)"
          },
          {
            "code" : "398373008",
            "display" : "Salmonella IIIb 61:k:1,5,(7) (organism)"
          },
          {
            "code" : "21081003",
            "display" : "Salmonella Burgas (organism)"
          },
          {
            "code" : "64705003",
            "display" : "Salmonella Mokola (organism)"
          },
          {
            "code" : "53684004",
            "display" : "Salmonella Blockley (organism)"
          },
          {
            "code" : "114796006",
            "display" : "Salmonella II 42:g,t:- (organism)"
          },
          {
            "code" : "30335006",
            "display" : "Salmonella Tounouma (organism)"
          },
          {
            "code" : "40114001",
            "display" : "Salmonella Panama (organism)"
          },
          {
            "code" : "88455006",
            "display" : "Salmonella Kande (organism)"
          },
          {
            "code" : "60834008",
            "display" : "Salmonella Tilburg (organism)"
          },
          {
            "code" : "404441008",
            "display" : "Salmonella IIIb 42:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "36604000",
            "display" : "Salmonella Djugu (organism)"
          },
          {
            "code" : "26031006",
            "display" : "Salmonella Kibusi (organism)"
          },
          {
            "code" : "398444006",
            "display" : "Salmonella IIIa 59:z36:- (organism)"
          },
          {
            "code" : "114698001",
            "display" : "Salmonella II 30:l,z28:z6 (organism)"
          },
          {
            "code" : "57683009",
            "display" : "Salmonella Rochdale (organism)"
          },
          {
            "code" : "82647001",
            "display" : "Salmonella Blegdam (organism)"
          },
          {
            "code" : "85385004",
            "display" : "Salmonella II 45:z29:1,5 (organism)"
          },
          {
            "code" : "404530008",
            "display" : "Salmonella IIIb 47:c:z (organism)"
          },
          {
            "code" : "66496006",
            "display" : "Salmonella Mapo (organism)"
          },
          {
            "code" : "398548007",
            "display" : "Salmonella IIIa 62:z4,z23:- (organism)"
          },
          {
            "code" : "114875006",
            "display" : "Salmonella IIIa 47:z4,z23:- (organism)"
          },
          {
            "code" : "114838001",
            "display" : "Salmonella IV 1,44:z4,z32:- (organism)"
          },
          {
            "code" : "31669006",
            "display" : "Salmonella Reinickendorf (organism)"
          },
          {
            "code" : "52400005",
            "display" : "Salmonella Idikan (organism)"
          },
          {
            "code" : "32054007",
            "display" : "Salmonella Kubacha (organism)"
          },
          {
            "code" : "48365003",
            "display" : "Salmonella II 30 c:z39 (organism)"
          },
          {
            "code" : "51210001",
            "display" : "Salmonella Banalia (organism)"
          },
          {
            "code" : "51825008",
            "display" : "Salmonella Oritamerin (organism)"
          },
          {
            "code" : "26463008",
            "display" : "Salmonella Hartford (organism)"
          },
          {
            "code" : "114378000",
            "display" : "Salmonella Sylvania (organism)"
          },
          {
            "code" : "37549003",
            "display" : "Salmonella Neftenbach (organism)"
          },
          {
            "code" : "404453007",
            "display" : "Salmonella I, group O:43 (organism)"
          },
          {
            "code" : "114271009",
            "display" : "Salmonella Souza var 15+ (organism)"
          },
          {
            "code" : "404460001",
            "display" : "Salmonella IIIb 43:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "34107006",
            "display" : "Salmonella Wentworth (organism)"
          },
          {
            "code" : "10343005",
            "display" : "Salmonella Adelaide (organism)"
          },
          {
            "code" : "78970007",
            "display" : "Salmonella Seattle (organism)"
          },
          {
            "code" : "33765004",
            "display" : "Salmonella Lomnava (organism)"
          },
          {
            "code" : "70939003",
            "display" : "Salmonella II 53:z:z6 (organism)"
          },
          {
            "code" : "398541001",
            "display" : "Salmonella IIIb, group O:59 (organism)"
          },
          {
            "code" : "35504002",
            "display" : "Salmonella Borbeck (organism)"
          },
          {
            "code" : "8077009",
            "display" : "Salmonella II 1,9,12,(46),27:z10:z39 (organism)"
          },
          {
            "code" : "77822004",
            "display" : "Salmonella Amager (organism)"
          },
          {
            "code" : "114385001",
            "display" : "Salmonella Kanifing (organism)"
          },
          {
            "code" : "404624001",
            "display" : "Salmonella IIIa 50:z4,z23:- (organism)"
          },
          {
            "code" : "32244000",
            "display" : "Salmonella Tyresoe (organism)"
          },
          {
            "code" : "23865002",
            "display" : "Salmonella Amounderness (organism)"
          },
          {
            "code" : "114814000",
            "display" : "Salmonella II 43:a:1,5 (organism)"
          },
          {
            "code" : "114893007",
            "display" : "Salmonella II 48:z10:[1,5] (organism)"
          },
          {
            "code" : "84205008",
            "display" : "Salmonella II 16:z:z42 (organism)"
          },
          {
            "code" : "54984007",
            "display" : "Salmonella Fischerkietz (organism)"
          },
          {
            "code" : "398535008",
            "display" : "Salmonella IIIb 61:i:z35 (organism)"
          },
          {
            "code" : "114678006",
            "display" : "Salmonella Penilla (organism)"
          },
          {
            "code" : "72072008",
            "display" : "Salmonella Belem (organism)"
          },
          {
            "code" : "398344005",
            "display" : "Salmonella IIIa 62:z4,z32:- (organism)"
          },
          {
            "code" : "158005",
            "display" : "Salmonella Irumu (organism)"
          },
          {
            "code" : "11188006",
            "display" : "Salmonella Herzliya (organism)"
          },
          {
            "code" : "398494007",
            "display" : "Salmonella IIIb (6),14:l,v:z (organism)"
          },
          {
            "code" : "398587007",
            "display" : "Salmonella IIIb 60:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "87619005",
            "display" : "Salmonella Marseille (organism)"
          },
          {
            "code" : "24680002",
            "display" : "Salmonella Matopeni (organism)"
          },
          {
            "code" : "114970002",
            "display" : "Salmonella IIIb 58:k:z (organism)"
          },
          {
            "code" : "67231006",
            "display" : "Salmonella Nimes (organism)"
          },
          {
            "code" : "51799003",
            "display" : "Salmonella Overschie (organism)"
          },
          {
            "code" : "7963006",
            "display" : "Salmonella IV, group O:57 (organism)"
          },
          {
            "code" : "11521007",
            "display" : "Salmonella Hillingdon (organism)"
          },
          {
            "code" : "404249008",
            "display" : "Salmonella II 16 g,[m],[s],t:[e,n,x] (organism)"
          },
          {
            "code" : "29955002",
            "display" : "Salmonella Tsevie (organism)"
          },
          {
            "code" : "114302000",
            "display" : "Salmonella Petahtikve (organism)"
          },
          {
            "code" : "404417005",
            "display" : "Salmonella IIIb, group O:41 (organism)"
          },
          {
            "code" : "398339003",
            "display" : "Salmonella IIIb 61:c:1,5,(7) (organism)"
          },
          {
            "code" : "404462009",
            "display" : "Salmonella IIIb 43:r:z53 (organism)"
          },
          {
            "code" : "66570007",
            "display" : "Salmonella II 28:e,n,x:1,7 (organism)"
          },
          {
            "code" : "398577008",
            "display" : "Salmonella IIIb 53:r:z (organism)"
          },
          {
            "code" : "541005",
            "display" : "Salmonella Ahuza (organism)"
          },
          {
            "code" : "31608001",
            "display" : "Salmonella Gatuni (organism)"
          },
          {
            "code" : "31239009",
            "display" : "Salmonella Rhydyfelin (organism)"
          },
          {
            "code" : "114401008",
            "display" : "Salmonella II 16:m,t:[z42] (organism)"
          },
          {
            "code" : "114938002",
            "display" : "Salmonella Bergues (organism)"
          },
          {
            "code" : "60242004",
            "display" : "Salmonella Salford (organism)"
          },
          {
            "code" : "32365009",
            "display" : "Salmonella Tornow (organism)"
          },
          {
            "code" : "46953000",
            "display" : "Salmonella Klouto (organism)"
          },
          {
            "code" : "8051001",
            "display" : "Salmonella Homosassa (organism)"
          },
          {
            "code" : "29811007",
            "display" : "Salmonella Jukestown (organism)"
          },
          {
            "code" : "114309009",
            "display" : "Salmonella Honkong (organism)"
          },
          {
            "code" : "8052008",
            "display" : "Salmonella Agoueve (organism)"
          },
          {
            "code" : "112292005",
            "display" : "Salmonella VI 6,7:z41:1,7 (organism)"
          },
          {
            "code" : "398416005",
            "display" : "Salmonella IIIb 65:l,v:z35 (organism)"
          },
          {
            "code" : "114737004",
            "display" : "Salmonella II 40:d:- (organism)"
          },
          {
            "code" : "114310004",
            "display" : "Salmonella Ochiogu (organism)"
          },
          {
            "code" : "114892002",
            "display" : "Salmonella IV 48:z4,z23:- (organism)"
          },
          {
            "code" : "90403009",
            "display" : "Salmonella Wa (organism)"
          },
          {
            "code" : "398608009",
            "display" : "Salmonella VI, group O:7 (organism)"
          },
          {
            "code" : "114595007",
            "display" : "Salmonella II 1,9,12:l,w:e,n,x (organism)"
          },
          {
            "code" : "404475009",
            "display" : "Salmonella IIIa 44:z4,z24:- (organism)"
          },
          {
            "code" : "114572003",
            "display" : "Salmonella Bangui (organism)"
          },
          {
            "code" : "114423007",
            "display" : "Salmonella II 16:l,w:z6 (organism)"
          },
          {
            "code" : "404446003",
            "display" : "Salmonella IIIb 42:r:z53 (organism)"
          },
          {
            "code" : "70426009",
            "display" : "Salmonella II, group O:52 (organism)"
          },
          {
            "code" : "114736008",
            "display" : "Salmonella II 1,40:c:e,n,x,z15 (organism)"
          },
          {
            "code" : "114490004",
            "display" : "Salmonella Vuadens (organism)"
          },
          {
            "code" : "114930009",
            "display" : "Salmonella Harcourt (organism)"
          },
          {
            "code" : "114732005",
            "display" : "Salmonella II 39:l,z28:z39 (organism)"
          },
          {
            "code" : "114962007",
            "display" : "Salmonella II 57:a:z42 (organism)"
          },
          {
            "code" : "404610000",
            "display" : "Salmonella IIIb 50:r:1,5,(7) (organism)"
          },
          {
            "code" : "36588009",
            "display" : "Salmonella Sangera (organism)"
          },
          {
            "code" : "114543004",
            "display" : "Salmonella II 6,8:a:z52 (organism)"
          },
          {
            "code" : "11325004",
            "display" : "Salmonella Aqua (organism)"
          },
          {
            "code" : "34256000",
            "display" : "Salmonella Ayton (organism)"
          },
          {
            "code" : "45866006",
            "display" : "Salmonella Butare (organism)"
          },
          {
            "code" : "46614007",
            "display" : "Salmonella Ona (organism)"
          },
          {
            "code" : "82829005",
            "display" : "Salmonella Wichita (organism)"
          },
          {
            "code" : "32310005",
            "display" : "Salmonella Konstanz (organism)"
          },
          {
            "code" : "51190006",
            "display" : "Salmonella Glasgow (organism)"
          },
          {
            "code" : "60425007",
            "display" : "Salmonella II 3,10:l,z28:z39 (organism)"
          },
          {
            "code" : "39775009",
            "display" : "Salmonella Sanktmarx (organism)"
          },
          {
            "code" : "59235005",
            "display" : "Salmonella II 9,12:l,z28:e,n,x (organism)"
          },
          {
            "code" : "398430000",
            "display" : "Salmonella I, group O:53 (organism)"
          },
          {
            "code" : "404366008",
            "display" : "Salmonella group O:38 (organism)"
          },
          {
            "code" : "57664002",
            "display" : "Salmonella Durban (organism)"
          },
          {
            "code" : "404609005",
            "display" : "Salmonella IIIb 50:l,v:z35 (organism)"
          },
          {
            "code" : "12278000",
            "display" : "Salmonella Indiana (organism)"
          },
          {
            "code" : "71236007",
            "display" : "Salmonella Middlesbrough (organism)"
          },
          {
            "code" : "70671008",
            "display" : "Salmonella Hisingen (organism)"
          },
          {
            "code" : "114760007",
            "display" : "Salmonella II 1,40:z35:e,n,x,z15 (organism)"
          },
          {
            "code" : "2932003",
            "display" : "Salmonella Bispebjerg (organism)"
          },
          {
            "code" : "404350006",
            "display" : "Salmonella IIIa 35:g,z51:- (organism)"
          },
          {
            "code" : "112288003",
            "display" : "Salmonella Mura (organism)"
          },
          {
            "code" : "114927002",
            "display" : "Salmonella IV 51:b:- (organism)"
          },
          {
            "code" : "51480006",
            "display" : "Salmonella Westeinde (organism)"
          },
          {
            "code" : "114316005",
            "display" : "Salmonella II 11:a:z6:z42 (organism)"
          },
          {
            "code" : "404449005",
            "display" : "Salmonella IIIa 42:z4,z23:- (organism)"
          },
          {
            "code" : "20073008",
            "display" : "Salmonella Manhattan (organism)"
          },
          {
            "code" : "404406009",
            "display" : "Salmonella IIIb 40:l,v:z53 (organism)"
          },
          {
            "code" : "116049009",
            "display" : "Salmonella serotype B, 5:-:1,2 (organism)"
          },
          {
            "code" : "114582002",
            "display" : "Salmonella Powell (organism)"
          },
          {
            "code" : "67210008",
            "display" : "Salmonella Ohio (organism)"
          },
          {
            "code" : "398572002",
            "display" : "Salmonella II, group O:13 (organism)"
          },
          {
            "code" : "114854003",
            "display" : "Salmonella Kofandoka (organism)"
          },
          {
            "code" : "13421000",
            "display" : "Salmonella Ried (organism)"
          },
          {
            "code" : "398569009",
            "display" : "Salmonella IIIa 6,7:1,v:z53 (organism)"
          },
          {
            "code" : "1921001",
            "display" : "Salmonella Donna (organism)"
          },
          {
            "code" : "114631005",
            "display" : "Salmonella II 3,10:z:z39 (organism)"
          },
          {
            "code" : "404456004",
            "display" : "Salmonella IIIb, group O:43 (organism)"
          },
          {
            "code" : "114752006",
            "display" : "Salmonella Tiko (organism)"
          },
          {
            "code" : "49079007",
            "display" : "Salmonella Michigan (organism)"
          },
          {
            "code" : "398428002",
            "display" : "Salmonella enterica subsp. diarizonae (organism)"
          },
          {
            "code" : "404400003",
            "display" : "Salmonella V, group O:40 (organism)"
          },
          {
            "code" : "114550000",
            "display" : "Salmonella Magherafelt (organism)"
          },
          {
            "code" : "12924006",
            "display" : "Salmonella Breukelen (organism)"
          },
          {
            "code" : "54227005",
            "display" : "Salmonella Dadzie (organism)"
          },
          {
            "code" : "114497001",
            "display" : "Salmonella II 6,7:b:[e,n,x]:z42 (organism)"
          },
          {
            "code" : "114483009",
            "display" : "Salmonella Haduna (organism)"
          },
          {
            "code" : "114369006",
            "display" : "Salmonella II 13,22:z29:1,5 (organism)"
          },
          {
            "code" : "83254009",
            "display" : "Salmonella Angouleme (organism)"
          },
          {
            "code" : "398553002",
            "display" : "Salmonella IIIb 61:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "16732009",
            "display" : "Salmonella II, group O:56 (organism)"
          },
          {
            "code" : "398542008",
            "display" : "Salmonella I, group O:7 (organism)"
          },
          {
            "code" : "404383004",
            "display" : "Salmonella IIIb 38:l,v:z35:[z54] (organism)"
          },
          {
            "code" : "404419008",
            "display" : "Salmonella VI, group O:41 (organism)"
          },
          {
            "code" : "404577003",
            "display" : "Salmonella IIIb 48:l,v:z (organism)"
          },
          {
            "code" : "114817007",
            "display" : "Salmonella Orleans (organism)"
          },
          {
            "code" : "417719009",
            "display" : "Salmonella IIIa 53:z4,z23:- (organism)"
          },
          {
            "code" : "65214003",
            "display" : "Salmonella Haferbreite (organism)"
          },
          {
            "code" : "114907003",
            "display" : "Salmonella IV 50:d:- (organism)"
          },
          {
            "code" : "64506004",
            "display" : "Salmonella Oerlikon (organism)"
          },
          {
            "code" : "114674008",
            "display" : "Salmonella II 28:g,m,t:z39 (organism)"
          },
          {
            "code" : "33909002",
            "display" : "Salmonella Makiso (organism)"
          },
          {
            "code" : "90559002",
            "display" : "Salmonella II 6,7:g,m,(s),t:e,n,x (organism)"
          },
          {
            "code" : "404473002",
            "display" : "Salmonella V, group O:44 (organism)"
          },
          {
            "code" : "60462009",
            "display" : "Salmonella Vleuten (organism)"
          },
          {
            "code" : "112297004",
            "display" : "Salmonella Cocody (organism)"
          },
          {
            "code" : "49491006",
            "display" : "Salmonella Hadar (organism)"
          },
          {
            "code" : "404308006",
            "display" : "Salmonella IIIb 18:r:z (organism)"
          },
          {
            "code" : "12370009",
            "display" : "Salmonella Bornum (organism)"
          },
          {
            "code" : "61227007",
            "display" : "Salmonella II 1,9,12,(46),27:z10:e,n,x (organism)"
          },
          {
            "code" : "86966001",
            "display" : "Salmonella Zehlendorf (organism)"
          },
          {
            "code" : "114366004",
            "display" : "Salmonella IIIa 13,22:z4,z23:- (organism)"
          },
          {
            "code" : "114880002",
            "display" : "Salmonella II 48:d:1,2 (organism)"
          },
          {
            "code" : "11738009",
            "display" : "Salmonella Sterrenbos (organism)"
          },
          {
            "code" : "398512005",
            "display" : "Salmonella IIIb 65:(k):z35 (organism)"
          },
          {
            "code" : "26894001",
            "display" : "Salmonella Redlands (organism)"
          },
          {
            "code" : "11097007",
            "display" : "Salmonella Zega (organism)"
          },
          {
            "code" : "114969003",
            "display" : "Salmonella II 57:z42:1,6:z53 (organism)"
          },
          {
            "code" : "114434005",
            "display" : "Salmonella Zaria (organism)"
          },
          {
            "code" : "82781001",
            "display" : "Salmonella Sara (organism)"
          },
          {
            "code" : "81807008",
            "display" : "Salmonella Marshall (organism)"
          },
          {
            "code" : "114832000",
            "display" : "Salmonella Splott (organism)"
          },
          {
            "code" : "72539003",
            "display" : "Salmonella II 13,23:l,z28:z6 (organism)"
          },
          {
            "code" : "77393005",
            "display" : "Salmonella Tione (organism)"
          },
          {
            "code" : "52294006",
            "display" : "Salmonella II 58:d:z6 (organism)"
          },
          {
            "code" : "1179032006",
            "display" : "Salmonella group D (organism)"
          },
          {
            "code" : "114687002",
            "display" : "Salmonella IIIb 28:z10:z (organism)"
          },
          {
            "code" : "114648002",
            "display" : "Salmonella Delmenhorst (organism)"
          },
          {
            "code" : "398363006",
            "display" : "Salmonella IIIa 63:z36:- (organism)"
          },
          {
            "code" : "398540000",
            "display" : "Salmonella IIIb 58:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "28285008",
            "display" : "Salmonella Finkenwerder (organism)"
          },
          {
            "code" : "25037003",
            "display" : "Salmonella Emmastad (organism)"
          },
          {
            "code" : "65805004",
            "display" : "Salmonella Kamoru (organism)"
          },
          {
            "code" : "30569006",
            "display" : "Salmonella II 47:a:e,n,x,z15 (organism)"
          },
          {
            "code" : "114563006",
            "display" : "Salmonella Sindelfingen (organism)"
          },
          {
            "code" : "76347001",
            "display" : "Salmonella Tomelilla (organism)"
          },
          {
            "code" : "398413002",
            "display" : "Salmonella IV, group O:7 (organism)"
          },
          {
            "code" : "114889001",
            "display" : "Salmonella Australia (organism)"
          },
          {
            "code" : "112291003",
            "display" : "Salmonella Inganda (organism)"
          },
          {
            "code" : "80728004",
            "display" : "Salmonella Baguirmi (organism)"
          },
          {
            "code" : "404394000",
            "display" : "Salmonella group O:40 (organism)"
          },
          {
            "code" : "42781000",
            "display" : "Salmonella Yaounde (organism)"
          },
          {
            "code" : "59785000",
            "display" : "Salmonella Guarapiranga (organism)"
          },
          {
            "code" : "114467009",
            "display" : "Salmonella Tripoli (organism)"
          },
          {
            "code" : "17801007",
            "display" : "Salmonella Toulon (organism)"
          },
          {
            "code" : "404574005",
            "display" : "Salmonella IIIb 48:k:z35 (organism)"
          },
          {
            "code" : "114834004",
            "display" : "Salmonella Maritzburg (organism)"
          },
          {
            "code" : "19912000",
            "display" : "Salmonella II 28:g,m,t:e,n,x (organism)"
          },
          {
            "code" : "65252002",
            "display" : "Salmonella II 1,13,22:z39:1,5,(7) (organism)"
          },
          {
            "code" : "15844005",
            "display" : "Salmonella Maracaibo (organism)"
          },
          {
            "code" : "114827001",
            "display" : "Salmonella IV 43:z4,z32:- (organism)"
          },
          {
            "code" : "114878008",
            "display" : "Salmonella IV 47:z36:- (organism)"
          },
          {
            "code" : "24239004",
            "display" : "Salmonella II 1,40:z:z6 (organism)"
          },
          {
            "code" : "86879006",
            "display" : "Salmonella Blitta (organism)"
          },
          {
            "code" : "112309005",
            "display" : "Salmonella Orientalis (organism)"
          },
          {
            "code" : "114771008",
            "display" : "Salmonella Vaugirard (organism)"
          },
          {
            "code" : "74707007",
            "display" : "Salmonella Tudu (organism)"
          },
          {
            "code" : "79270006",
            "display" : "Salmonella II 6,7:z:z6 (organism)"
          },
          {
            "code" : "114684009",
            "display" : "Salmonella II 28:z:z39 (organism)"
          },
          {
            "code" : "114421009",
            "display" : "Salmonella Grancanaria (organism)"
          },
          {
            "code" : "398510002",
            "display" : "Salmonella IIIb 58:z52:z35 (organism)"
          },
          {
            "code" : "77211008",
            "display" : "Salmonella Stellingen (organism)"
          },
          {
            "code" : "47229009",
            "display" : "Salmonella Altona (organism)"
          },
          {
            "code" : "114967001",
            "display" : "Salmonella II 57:z29:z42 (organism)"
          },
          {
            "code" : "21218005",
            "display" : "Salmonella Lokstedt (organism)"
          },
          {
            "code" : "114961000",
            "display" : "Salmonella II 56:z:z6 (organism)"
          },
          {
            "code" : "114910005",
            "display" : "Salmonella IV 50:g,z51:- (organism)"
          },
          {
            "code" : "114920000",
            "display" : "Salmonella IIIb 50:z10:z (organism)"
          },
          {
            "code" : "78045009",
            "display" : "Salmonella Mundonobo (organism)"
          },
          {
            "code" : "78550009",
            "display" : "Salmonella Ipswich (organism)"
          },
          {
            "code" : "398341002",
            "display" : "Salmonella V, group O:60 (organism)"
          },
          {
            "code" : "48020001",
            "display" : "Salmonella Moscow (organism)"
          },
          {
            "code" : "80456008",
            "display" : "Salmonella Rubislaw (organism)"
          },
          {
            "code" : "71768003",
            "display" : "Salmonella Give (organism)"
          },
          {
            "code" : "89680007",
            "display" : "Salmonella II 48:a:z39 (organism)"
          },
          {
            "code" : "114968006",
            "display" : "Salmonella II 57:z39:e,n,x,z15 (organism)"
          },
          {
            "code" : "114645004",
            "display" : "Salmonella Leer (organism)"
          },
          {
            "code" : "30665007",
            "display" : "Salmonella Christiansborg (organism)"
          },
          {
            "code" : "46180006",
            "display" : "Salmonella Brezany (organism)"
          },
          {
            "code" : "398456007",
            "display" : "Salmonella IIIb 60:(k):z53 (organism)"
          },
          {
            "code" : "19191009",
            "display" : "Salmonella Diguel (organism)"
          },
          {
            "code" : "114620002",
            "display" : "Salmonella II 3,10:g,t:- (organism)"
          },
          {
            "code" : "114292009",
            "display" : "Salmonella Westhampton var 15+, 34+ (organism)"
          },
          {
            "code" : "114486001",
            "display" : "Salmonella Loubomo (organism)"
          },
          {
            "code" : "114636000",
            "display" : "Salmonella II 17:z10:- (organism)"
          },
          {
            "code" : "105769007",
            "display" : "Salmonella group O:54 (organism)"
          },
          {
            "code" : "711005",
            "display" : "Salmonella Tunis (organism)"
          },
          {
            "code" : "78448004",
            "display" : "Salmonella Moero (organism)"
          },
          {
            "code" : "114820004",
            "display" : "Salmonella IIIa 43:g,z51:- (organism)"
          },
          {
            "code" : "404532000",
            "display" : "Salmonella IIIb 47:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "29049005",
            "display" : "Salmonella Niloese (organism)"
          },
          {
            "code" : "75881007",
            "display" : "Salmonella Fischerhuette (organism)"
          },
          {
            "code" : "40369005",
            "display" : "Salmonella Abony (organism)"
          },
          {
            "code" : "6184007",
            "display" : "Salmonella Fulica (organism)"
          },
          {
            "code" : "76983003",
            "display" : "Salmonella Southampton (organism)"
          },
          {
            "code" : "86467002",
            "display" : "Salmonella Itutaba (organism)"
          },
          {
            "code" : "404550007",
            "display" : "Salmonella IIIb 47:r:z53:(z60) (organism)"
          },
          {
            "code" : "13411008",
            "display" : "Salmonella Freetown (organism)"
          },
          {
            "code" : "398406002",
            "display" : "Salmonella IIIa 62:g:z51:- (organism)"
          },
          {
            "code" : "23665004",
            "display" : "Salmonella Dakar (organism)"
          },
          {
            "code" : "57804003",
            "display" : "Salmonella Fann (organism)"
          },
          {
            "code" : "114949008",
            "display" : "Salmonella II 53:l,z28:e,n,x (organism)"
          },
          {
            "code" : "398492006",
            "display" : "Salmonella group O:6,14 (organism)"
          },
          {
            "code" : "115661009",
            "display" : "Salmonella Palamaner (organism)"
          },
          {
            "code" : "404431005",
            "display" : "Salmonella I, group O:42 (organism)"
          },
          {
            "code" : "114902009",
            "display" : "Salmonella V 48:z81:- (organism)"
          },
          {
            "code" : "114418007",
            "display" : "Salmonella II 16:z35:e,n,x (organism)"
          },
          {
            "code" : "71865006",
            "display" : "Salmonella Heidelberg (organism)"
          },
          {
            "code" : "42648005",
            "display" : "Salmonella Shubra (organism)"
          },
          {
            "code" : "23032006",
            "display" : "Salmonella Angoda (organism)"
          },
          {
            "code" : "114661002",
            "display" : "Salmonella IV 21:z4,z32:- (organism)"
          },
          {
            "code" : "67392004",
            "display" : "Salmonella Hvittingfoss (organism)"
          },
          {
            "code" : "60073009",
            "display" : "Salmonella Agama (organism)"
          },
          {
            "code" : "76073000",
            "display" : "Salmonella Aba (organism)"
          },
          {
            "code" : "1574002",
            "display" : "Salmonella Santiago (organism)"
          },
          {
            "code" : "404295001",
            "display" : "Salmonella I, group O:18 (organism)"
          },
          {
            "code" : "21436008",
            "display" : "Salmonella Cyprus (organism)"
          },
          {
            "code" : "13865001",
            "display" : "Salmonella Tokoin (organism)"
          },
          {
            "code" : "398563005",
            "display" : "Salmonella IIIb 61:i:z53 (organism)"
          },
          {
            "code" : "114629001",
            "display" : "Salmonella Harleystreet (organism)"
          },
          {
            "code" : "52995002",
            "display" : "Salmonella Gatineau (organism)"
          },
          {
            "code" : "32692009",
            "display" : "Salmonella II 28:g,s,t:e,n,x (organism)"
          },
          {
            "code" : "398337001",
            "display" : "Salmonella I, group O:51 (organism)"
          },
          {
            "code" : "404442001",
            "display" : "Salmonella IIIb 42:l,v:z (organism)"
          },
          {
            "code" : "40311004",
            "display" : "Salmonella Farmsen (organism)"
          },
          {
            "code" : "114399002",
            "display" : "Salmonella II g,[m],[s],t:[e,n,x] (organism)"
          },
          {
            "code" : "16109000",
            "display" : "Salmonella Coeln (organism)"
          },
          {
            "code" : "114727009",
            "display" : "Salmonella II 39:[g],m,t:[e,n,x] (organism)"
          },
          {
            "code" : "29469006",
            "display" : "Salmonella Tennyson (organism)"
          },
          {
            "code" : "114275000",
            "display" : "Salmonella Nyborg var 15+ (organism)"
          },
          {
            "code" : "62773005",
            "display" : "Salmonella Mandera (organism)"
          },
          {
            "code" : "114798007",
            "display" : "Salmonella Borromea (organism)"
          },
          {
            "code" : "302625000",
            "display" : "Salmonella Winneba (organism)"
          },
          {
            "code" : "77787000",
            "display" : "Salmonella Antonio (organism)"
          },
          {
            "code" : "6768004",
            "display" : "Salmonella Lodz (organism)"
          },
          {
            "code" : "398610006",
            "display" : "Salmonella IIIb 6,14:b:e,n,x (organism)"
          },
          {
            "code" : "47688008",
            "display" : "Salmonella Telaviv (organism)"
          },
          {
            "code" : "66713000",
            "display" : "Salmonella Livingstone (organism)"
          },
          {
            "code" : "404589001",
            "display" : "Salmonella I, group O:50 (organism)"
          },
          {
            "code" : "114317001",
            "display" : "Salmonella VI 11:b:1,7 (organism)"
          },
          {
            "code" : "127498002",
            "display" : "Salmonella serotype B,5:r:- (organism)"
          },
          {
            "code" : "57389000",
            "display" : "Salmonella Basingstoke (organism)"
          },
          {
            "code" : "114298008",
            "display" : "Salmonella Alkmaar (organism)"
          },
          {
            "code" : "398418006",
            "display" : "Salmonella IIIb 53:i:z (organism)"
          },
          {
            "code" : "3373000",
            "display" : "Salmonella Ibadan (organism)"
          },
          {
            "code" : "114638004",
            "display" : "Salmonella Aachen (organism)"
          },
          {
            "code" : "302702005",
            "display" : "Salmonella 1,13,23:g,m,s,t:1,5 (organism)"
          },
          {
            "code" : "442114006",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:-:1,2 (organism)"
          },
          {
            "code" : "398387008",
            "display" : "Salmonella IIIb 61:c:z35 (organism)"
          },
          {
            "code" : "59727006",
            "display" : "Salmonella II 1,9,12,(46),27:y:z39 (organism)"
          },
          {
            "code" : "62209006",
            "display" : "Salmonella II 58:c:z6 (organism)"
          },
          {
            "code" : "114330000",
            "display" : "Salmonella IIIb 11:k:z53 (organism)"
          },
          {
            "code" : "11342005",
            "display" : "Salmonella Othmarschen (organism)"
          },
          {
            "code" : "54295006",
            "display" : "Salmonella Lawra (organism)"
          },
          {
            "code" : "91398003",
            "display" : "Salmonella Kaduna (organism)"
          },
          {
            "code" : "61549002",
            "display" : "Salmonella Taset (organism)"
          },
          {
            "code" : "404316002",
            "display" : "Salmonella IIIa 21:z4,z23:- (organism)"
          },
          {
            "code" : "404402006",
            "display" : "Salmonella IIIb 40:i:1,5,7 (organism)"
          },
          {
            "code" : "29528000",
            "display" : "Salmonella Reubeuss (organism)"
          },
          {
            "code" : "65850002",
            "display" : "Salmonella Ball (organism)"
          },
          {
            "code" : "62314007",
            "display" : "Salmonella Mornington (organism)"
          },
          {
            "code" : "404551006",
            "display" : "Salmonella IIIb 47:z10:1,5,7 (organism)"
          },
          {
            "code" : "404428009",
            "display" : "Salmonella IIIa 41:z4,z24:- (organism)"
          },
          {
            "code" : "23342000",
            "display" : "Salmonella II 9,46:z39:1,7 (organism)"
          },
          {
            "code" : "114734006",
            "display" : "Salmonella II 39:-:1,7 (organism)"
          },
          {
            "code" : "48054000",
            "display" : "Salmonella Narashino (organism)"
          },
          {
            "code" : "114581009",
            "display" : "Salmonella II 9,12:l,z28:1,5:[z42] (organism)"
          },
          {
            "code" : "18810002",
            "display" : "Salmonella Wohlen (organism)"
          },
          {
            "code" : "49392000",
            "display" : "Salmonella Somone (organism)"
          },
          {
            "code" : "114599001",
            "display" : "Salmonella Macclesfield (organism)"
          },
          {
            "code" : "114871002",
            "display" : "Salmonella IV 47:l,v:- (organism)"
          },
          {
            "code" : "45578001",
            "display" : "Salmonella Tananarive (organism)"
          },
          {
            "code" : "114359000",
            "display" : "Salmonella IIIb 13,22:l,v:1,5,7 (organism)"
          },
          {
            "code" : "114350001",
            "display" : "Salmonella II 1,13,22:g,m,t:[1,5] (organism)"
          },
          {
            "code" : "82957002",
            "display" : "Salmonella Rechovot (organism)"
          },
          {
            "code" : "404538001",
            "display" : "Salmonella IIIb 47:k:z (organism)"
          },
          {
            "code" : "71285002",
            "display" : "Salmonella Ruzizi (organism)"
          },
          {
            "code" : "47991006",
            "display" : "Salmonella II 35:g,m,s,t:- (organism)"
          },
          {
            "code" : "23727001",
            "display" : "Salmonella Wil (organism)"
          },
          {
            "code" : "29742006",
            "display" : "Salmonella Gafsa (organism)"
          },
          {
            "code" : "72033009",
            "display" : "Salmonella Albany (organism)"
          },
          {
            "code" : "81603009",
            "display" : "Salmonella Epinay (organism)"
          },
          {
            "code" : "29189002",
            "display" : "Salmonella Tschangu (organism)"
          },
          {
            "code" : "20537005",
            "display" : "Salmonella Bokanjac (organism)"
          },
          {
            "code" : "14966006",
            "display" : "Salmonella Riverside (organism)"
          },
          {
            "code" : "404387003",
            "display" : "Salmonella IIIb 38:z10:z (organism)"
          },
          {
            "code" : "13491009",
            "display" : "Salmonella Brefet (organism)"
          },
          {
            "code" : "404488007",
            "display" : "Salmonella IIIa 45:z4,z24:- (organism)"
          },
          {
            "code" : "71605006",
            "display" : "Salmonella Toowong (organism)"
          },
          {
            "code" : "114407007",
            "display" : "Salmonella Brunflo (organism)"
          },
          {
            "code" : "81684001",
            "display" : "Salmonella Berlin (organism)"
          },
          {
            "code" : "21786003",
            "display" : "Salmonella Bruck (organism)"
          },
          {
            "code" : "80047008",
            "display" : "Salmonella Tinda (organism)"
          },
          {
            "code" : "52492008",
            "display" : "Salmonella Kisangani (organism)"
          },
          {
            "code" : "66749004",
            "display" : "Salmonella II 1,13,23:z29:e,n,x (organism)"
          },
          {
            "code" : "404260004",
            "display" : "Salmonella IIIb 16:z52:z35 (organism)"
          },
          {
            "code" : "398522004",
            "display" : "Salmonella IIIb (6),14:r:z (organism)"
          },
          {
            "code" : "114535009",
            "display" : "Salmonella Rissen var 14+ (organism)"
          },
          {
            "code" : "79264000",
            "display" : "Salmonella Pramiso (organism)"
          },
          {
            "code" : "114576000",
            "display" : "Salmonella II 9,12:g,s,t:e,n,x (organism)"
          },
          {
            "code" : "404401004",
            "display" : "Salmonella IIIb, 40:g,z51:e,n,x,z15 (organism)"
          },
          {
            "code" : "114846000",
            "display" : "Salmonella VI 45:a:e,n,x (organism)"
          },
          {
            "code" : "22831005",
            "display" : "Salmonella II 30:g,m,s:e,n,x (organism)"
          },
          {
            "code" : "114269009",
            "display" : "Salmonella enterica subspecies enterica serovar Butantan var O:15+ (organism)"
          },
          {
            "code" : "398531004",
            "display" : "Salmonella IIIb 53:z:1,5,(7) (organism)"
          },
          {
            "code" : "36510009",
            "display" : "Salmonella Teddington (organism)"
          },
          {
            "code" : "302673005",
            "display" : "Salmonella Ngaparou (organism)"
          },
          {
            "code" : "60794003",
            "display" : "Salmonella Elomrane (organism)"
          },
          {
            "code" : "32716002",
            "display" : "Salmonella Vaertan (organism)"
          },
          {
            "code" : "75343005",
            "display" : "Salmonella Aminatu (organism)"
          },
          {
            "code" : "69111005",
            "display" : "Salmonella Madjorio (organism)"
          },
          {
            "code" : "404457008",
            "display" : "Salmonella IV, group O:43 (organism)"
          },
          {
            "code" : "77961006",
            "display" : "Salmonella Chagoua (organism)"
          },
          {
            "code" : "21975008",
            "display" : "Salmonella Wien (organism)"
          },
          {
            "code" : "44536003",
            "display" : "Salmonella II, group O:53 (organism)"
          },
          {
            "code" : "26153006",
            "display" : "Salmonella Heves (organism)"
          },
          {
            "code" : "75090001",
            "display" : "Salmonella Kimuenza (organism)"
          },
          {
            "code" : "13615007",
            "display" : "Salmonella Regent (organism)"
          },
          {
            "code" : "69669000",
            "display" : "Salmonella Shangani (organism)"
          },
          {
            "code" : "64900004",
            "display" : "Salmonella Ordonez (organism)"
          },
          {
            "code" : "114315009",
            "display" : "Salmonella VI 11:a:1,5 (organism)"
          },
          {
            "code" : "15839003",
            "display" : "Salmonella II 1,40:z6:1,5 (organism)"
          },
          {
            "code" : "87578001",
            "display" : "Salmonella Kapemba (organism)"
          },
          {
            "code" : "404619004",
            "display" : "Salmonella IIIa 50:z4,z23,z32:- (organism)"
          },
          {
            "code" : "80579007",
            "display" : "Salmonella Linton (organism)"
          },
          {
            "code" : "114579007",
            "display" : "Salmonella II 1,9,12:m,t:z39 (organism)"
          },
          {
            "code" : "404338000",
            "display" : "Salmonella group O:30 (organism)"
          },
          {
            "code" : "40305002",
            "display" : "Salmonella Kasenyi (organism)"
          },
          {
            "code" : "8716004",
            "display" : "Salmonella Gokul (organism)"
          },
          {
            "code" : "404378007",
            "display" : "Salmonella IIIb 38:i:z53 (organism)"
          },
          {
            "code" : "114425000",
            "display" : "Salmonella Dahra (organism)"
          },
          {
            "code" : "54469007",
            "display" : "Salmonella Schwerin (organism)"
          },
          {
            "code" : "404298004",
            "display" : "Salmonella IIIb, group O:18 (organism)"
          },
          {
            "code" : "112308002",
            "display" : "Salmonella Lindern (organism)"
          },
          {
            "code" : "398607004",
            "display" : "Salmonella V, group O:61 (organism)"
          },
          {
            "code" : "114640009",
            "display" : "Salmonella II 17:c:z39 (organism)"
          },
          {
            "code" : "35244008",
            "display" : "Salmonella Mocamedes (organism)"
          },
          {
            "code" : "114653007",
            "display" : "Salmonella IV 21:g,z51:- (organism)"
          },
          {
            "code" : "398402000",
            "display" : "Salmonella IIIa 56:z4,z23,z32:- (organism)"
          },
          {
            "code" : "69247002",
            "display" : "Salmonella II 17:y:- (organism)"
          },
          {
            "code" : "65987009",
            "display" : "Salmonella II 3,10:g,m,s,t:[1,5] (organism)"
          },
          {
            "code" : "20268005",
            "display" : "Salmonella Taunton (organism)"
          },
          {
            "code" : "398459000",
            "display" : "Salmonella IIIa 53:g,z51:- (organism)"
          },
          {
            "code" : "114774000",
            "display" : "Salmonella II 41:d:z6 (organism)"
          },
          {
            "code" : "114924009",
            "display" : "Salmonella IIIb 50:z52:z53 (organism)"
          },
          {
            "code" : "27353005",
            "display" : "Salmonella Bambylor (organism)"
          },
          {
            "code" : "404294002",
            "display" : "Salmonella group O:18 (organism)"
          },
          {
            "code" : "64354008",
            "display" : "Salmonella Czernyring (organism)"
          },
          {
            "code" : "58052007",
            "display" : "Salmonella Louga (organism)"
          },
          {
            "code" : "404548004",
            "display" : "Salmonella IIIb 47:r:z (organism)"
          },
          {
            "code" : "398462002",
            "display" : "Salmonella II, group O:8 (organism)"
          },
          {
            "code" : "114818002",
            "display" : "Salmonella II 43:g,m,[s],t:[z42] (organism)"
          },
          {
            "code" : "47008007",
            "display" : "Salmonella II 1,40:g,t:z42 (organism)"
          },
          {
            "code" : "404588009",
            "display" : "Salmonella group O:50 (organism)"
          },
          {
            "code" : "78280000",
            "display" : "Salmonella Kimpese (organism)"
          },
          {
            "code" : "83016003",
            "display" : "Salmonella Kuessel (organism)"
          },
          {
            "code" : "31210009",
            "display" : "Salmonella IV 43:g,z51:- (organism)"
          },
          {
            "code" : "15055006",
            "display" : "Salmonella Riggil (organism)"
          },
          {
            "code" : "404493005",
            "display" : "Salmonella IIIa, group O:47 (organism)"
          },
          {
            "code" : "114571005",
            "display" : "Salmonella II 9,12:d:e,n,x (organism)"
          },
          {
            "code" : "114619008",
            "display" : "Salmonella II 3,10,[15]:g,m,s,t:[1,5] (organism)"
          },
          {
            "code" : "59099007",
            "display" : "Salmonella Menston (organism)"
          },
          {
            "code" : "114376001",
            "display" : "Salmonella VI 1,6,14,25:a:e,n,x (organism)"
          },
          {
            "code" : "57585007",
            "display" : "Salmonella Inverness (organism)"
          },
          {
            "code" : "14078008",
            "display" : "Salmonella Loanda (organism)"
          },
          {
            "code" : "2440000",
            "display" : "Salmonella Inglis (organism)"
          },
          {
            "code" : "27543005",
            "display" : "Salmonella Afula (organism)"
          },
          {
            "code" : "33296009",
            "display" : "Salmonella Taksony (organism)"
          },
          {
            "code" : "114492007",
            "display" : "Salmonella II 1,4,12,27:z39:1,[5],7 (organism)"
          },
          {
            "code" : "48339002",
            "display" : "Salmonella Vinohrady (organism)"
          },
          {
            "code" : "114618000",
            "display" : "Salmonella Lamberhurst (organism)"
          },
          {
            "code" : "404559008",
            "display" : "Salmonella group O:48 (organism)"
          },
          {
            "code" : "114847009",
            "display" : "Salmonella II 45:a:z10 (organism)"
          },
          {
            "code" : "85465004",
            "display" : "Salmonella Kaneshie (organism)"
          },
          {
            "code" : "114307006",
            "display" : "Salmonella Kinson (organism)"
          },
          {
            "code" : "91112005",
            "display" : "Salmonella Calvinia (organism)"
          },
          {
            "code" : "50136005",
            "display" : "Salmonella Typhimurium (organism)"
          },
          {
            "code" : "404262007",
            "display" : "Salmonella II 16:g,t:1,5 (organism)"
          },
          {
            "code" : "114547003",
            "display" : "Salmonella II 6,8:m,t:1,5 (organism)"
          },
          {
            "code" : "112285000",
            "display" : "Salmonella Nitra (organism)"
          },
          {
            "code" : "398476001",
            "display" : "Salmonella I, group O:52 (organism)"
          },
          {
            "code" : "114802008",
            "display" : "Salmonella II 42:r:- (organism)"
          },
          {
            "code" : "404292003",
            "display" : "Salmonella IIIa 17:z4,z32:- (organism)"
          },
          {
            "code" : "404422005",
            "display" : "Salmonella IIIb 41:c:e,n,x,z15 (organism)"
          },
          {
            "code" : "72132002",
            "display" : "Salmonella Weston (organism)"
          },
          {
            "code" : "404399005",
            "display" : "Salmonella IV, group O:40 (organism)"
          },
          {
            "code" : "404282006",
            "display" : "Salmonella IIIb 17:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "37944001",
            "display" : "Salmonella Adjame (organism)"
          },
          {
            "code" : "112307007",
            "display" : "Salmonella Midway (organism)"
          },
          {
            "code" : "398448009",
            "display" : "Salmonella Meleagridis var 15+ (organism)"
          },
          {
            "code" : "58973005",
            "display" : "Salmonella Willemstad (organism)"
          },
          {
            "code" : "404582005",
            "display" : "Salmonella IIIa 48:z36:- (organism)"
          },
          {
            "code" : "4769009",
            "display" : "Salmonella Seremban (organism)"
          },
          {
            "code" : "404434002",
            "display" : "Salmonella IIIb, group O:42 (organism)"
          },
          {
            "code" : "114901002",
            "display" : "Salmonella V 48:z65:- (organism)"
          },
          {
            "code" : "404542003",
            "display" : "Salmonella IIIb 47:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "27268008",
            "display" : "Genus Salmonella (organism)"
          },
          {
            "code" : "404470004",
            "display" : "Salmonella IIIa, group O:44 (organism)"
          },
          {
            "code" : "105779009",
            "display" : "Salmonella group O:65 (organism)"
          },
          {
            "code" : "9506004",
            "display" : "Salmonella Mbandaka (organism)"
          },
          {
            "code" : "2599003",
            "display" : "Salmonella Massenya (organism)"
          },
          {
            "code" : "398550004",
            "display" : "Salmonella Zaiman (organism)"
          },
          {
            "code" : "81493008",
            "display" : "Salmonella Moussoro (organism)"
          },
          {
            "code" : "53656009",
            "display" : "Salmonella Leiden (organism)"
          },
          {
            "code" : "398478000",
            "display" : "Salmonella Jedburgh var 15+ (organism)"
          },
          {
            "code" : "88079003",
            "display" : "Salmonella II 35:g,t:z42 (organism)"
          },
          {
            "code" : "30228001",
            "display" : "Salmonella Neudorf (organism)"
          },
          {
            "code" : "55144007",
            "display" : "Salmonella Rumford (organism)"
          },
          {
            "code" : "114583007",
            "display" : "Salmonella II 1,9,12:y:z39 (organism)"
          },
          {
            "code" : "55928004",
            "display" : "Salmonella II 47:g,t:e,n,x (organism)"
          },
          {
            "code" : "31718003",
            "display" : "Salmonella II 6,8:g,m,t:(e,n,x) (organism)"
          },
          {
            "code" : "82364007",
            "display" : "Salmonella Bredeney (organism)"
          },
          {
            "code" : "52981000",
            "display" : "Salmonella Camberwell (organism)"
          },
          {
            "code" : "114828006",
            "display" : "Salmonella Makiling (organism)"
          },
          {
            "code" : "398348008",
            "display" : "Salmonella group O:9,46 (organism)"
          },
          {
            "code" : "6851005",
            "display" : "Salmonella Vietnam (organism)"
          },
          {
            "code" : "114327007",
            "display" : "Salmonella Moers (organism)"
          },
          {
            "code" : "114824008",
            "display" : "Salmonella Arusha (organism)"
          },
          {
            "code" : "49721001",
            "display" : "Salmonella Alabama (organism)"
          },
          {
            "code" : "9541000",
            "display" : "Salmonella II 42:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "114861004",
            "display" : "Salmonella IV 45:z36,z38:- (organism)"
          },
          {
            "code" : "55274005",
            "display" : "Salmonella Edinburg (organism)"
          },
          {
            "code" : "16845000",
            "display" : "Salmonella Keve (organism)"
          },
          {
            "code" : "69040005",
            "display" : "Salmonella Cremieu (organism)"
          },
          {
            "code" : "404279001",
            "display" : "Salmonella IIIb, group O:17 (organism)"
          },
          {
            "code" : "55505009",
            "display" : "Salmonella Sheffield (organism)"
          },
          {
            "code" : "88085005",
            "display" : "Salmonella Antarctica (organism)"
          },
          {
            "code" : "67775006",
            "display" : "Salmonella Cairina (organism)"
          },
          {
            "code" : "114319003",
            "display" : "Salmonella Brindisi (organism)"
          },
          {
            "code" : "80177000",
            "display" : "Salmonella Bignona (organism)"
          },
          {
            "code" : "11893007",
            "display" : "Salmonella Irigny (organism)"
          },
          {
            "code" : "441800005",
            "display" : "Salmonella enterica subspecies enterica serovar 4,[5],12:i:- (organism)"
          },
          {
            "code" : "19890008",
            "display" : "Salmonella II 16:b:z42 (organism)"
          },
          {
            "code" : "398534007",
            "display" : "Salmonella II, group O:7 (organism)"
          },
          {
            "code" : "31592001",
            "display" : "Salmonella Mendoza (organism)"
          },
          {
            "code" : "114983001",
            "display" : "Salmonella II 60:b:- (organism)"
          },
          {
            "code" : "47579008",
            "display" : "Salmonella Brazos (organism)"
          },
          {
            "code" : "114900001",
            "display" : "Salmonella V 48:z41:- (organism)"
          },
          {
            "code" : "5325008",
            "display" : "Salmonella Menden (organism)"
          },
          {
            "code" : "81340008",
            "display" : "Salmonella Bolton (organism)"
          },
          {
            "code" : "761001",
            "display" : "Salmonella Runby (organism)"
          },
          {
            "code" : "68821008",
            "display" : "Salmonella II 52:d:e,n,x,z15 (organism)"
          },
          {
            "code" : "114719000",
            "display" : "Salmonella Taylor (organism)"
          },
          {
            "code" : "112314009",
            "display" : "Salmonella Pomona (organism)"
          },
          {
            "code" : "53814008",
            "display" : "Salmonella Emek (organism)"
          },
          {
            "code" : "114283006",
            "display" : "Salmonella Weltevreden var 15+ (organism)"
          },
          {
            "code" : "114320009",
            "display" : "Salmonella II 11:c:e,n,z15 (organism)"
          },
          {
            "code" : "86311006",
            "display" : "Salmonella Stendal (organism)"
          },
          {
            "code" : "404377002",
            "display" : "Salmonella IIIa 38:g,z51:- (organism)"
          },
          {
            "code" : "56093009",
            "display" : "Salmonella Winnipeg (organism)"
          },
          {
            "code" : "302721002",
            "display" : "Salmonella Bouake (organism)"
          },
          {
            "code" : "398549004",
            "display" : "Salmonella Lutetia (organism)"
          },
          {
            "code" : "6327006",
            "display" : "Salmonella Glostrup (organism)"
          },
          {
            "code" : "127499005",
            "display" : "Salmonella serotype B,:r:- (organism)"
          },
          {
            "code" : "14528002",
            "display" : "Salmonella IV 44:z4,z24:- (organism)"
          },
          {
            "code" : "85277006",
            "display" : "Salmonella Tallahassee (organism)"
          },
          {
            "code" : "75923007",
            "display" : "Salmonella Albert (organism)"
          },
          {
            "code" : "398469006",
            "display" : "Salmonella IIIb 53:l,v:e,n,x,z15 (organism)"
          },
          {
            "code" : "114950008",
            "display" : "Salmonella II 53:l,z28:z6 (organism)"
          },
          {
            "code" : "10556004",
            "display" : "Salmonella Norwich (organism)"
          },
          {
            "code" : "105770008",
            "display" : "Salmonella group O:55 (organism)"
          },
          {
            "code" : "114494008",
            "display" : "Salmonella II 6,7,14:a:1,5 (organism)"
          },
          {
            "code" : "398461009",
            "display" : "Salmonella IIIb 53:z52:z35 (organism)"
          },
          {
            "code" : "89423000",
            "display" : "Salmonella Kralingen (organism)"
          },
          {
            "code" : "114872009",
            "display" : "Salmonella IIIb 47:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "62099009",
            "display" : "Salmonella Westhampton (organism)"
          },
          {
            "code" : "398509007",
            "display" : "Salmonella IIIb, group O:6,14 (organism)"
          },
          {
            "code" : "57508007",
            "display" : "Salmonella II 9,12:l,v:z39 (organism)"
          },
          {
            "code" : "50823007",
            "display" : "Salmonella Akuafo (organism)"
          },
          {
            "code" : "114440003",
            "display" : "Salmonella II 17:z:1,7 (organism)"
          },
          {
            "code" : "50351007",
            "display" : "Salmonella Memphis (organism)"
          },
          {
            "code" : "404390009",
            "display" : "Salmonella IIIb 38:z52:z53 (organism)"
          },
          {
            "code" : "83560005",
            "display" : "Salmonella Moualine (organism)"
          },
          {
            "code" : "398385000",
            "display" : "Salmonella IIIb 59:l,v:z (organism)"
          },
          {
            "code" : "114995001",
            "display" : "Salmonella II 65:g,t:- (organism)"
          },
          {
            "code" : "61491002",
            "display" : "Salmonella Kpeme (organism)"
          },
          {
            "code" : "114810009",
            "display" : "Salmonella II 42:z10:1,2 (organism)"
          },
          {
            "code" : "442103008",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:-:1,5 (organism)"
          },
          {
            "code" : "17611002",
            "display" : "Salmonella Fayed (organism)"
          },
          {
            "code" : "398604006",
            "display" : "Salmonella IIIb 65:z52:z (organism)"
          },
          {
            "code" : "404573004",
            "display" : "Salmonella IIIb 48:k:z (organism)"
          },
          {
            "code" : "87110008",
            "display" : "Salmonella Landala (organism)"
          },
          {
            "code" : "114982006",
            "display" : "Salmonella IIIb 59:z52:z53 (organism)"
          },
          {
            "code" : "114686006",
            "display" : "Salmonella Libreville (organism)"
          },
          {
            "code" : "114757000",
            "display" : "Salmonella II 40:z:z42 (organism)"
          },
          {
            "code" : "302751008",
            "display" : "Salmonella Krugersdorp (organism)"
          },
          {
            "code" : "404563001",
            "display" : "Salmonella IIIb, group O:48 (organism)"
          },
          {
            "code" : "114476002",
            "display" : "Salmonella II 4,12:g,z62:- (organism)"
          },
          {
            "code" : "114952000",
            "display" : "Salmonella IIIb 53:r:z68 (organism)"
          },
          {
            "code" : "22729005",
            "display" : "Salmonella Bukavu (organism)"
          },
          {
            "code" : "4145004",
            "display" : "Salmonella Ohlstedt (organism)"
          },
          {
            "code" : "91124003",
            "display" : "Salmonella Tanzania (organism)"
          },
          {
            "code" : "48058002",
            "display" : "Salmonella Rostock (organism)"
          },
          {
            "code" : "71991008",
            "display" : "Salmonella Nanga (organism)"
          },
          {
            "code" : "114308001",
            "display" : "Salmonella Kainji (organism)"
          },
          {
            "code" : "91123009",
            "display" : "Salmonella Uppsala (organism)"
          },
          {
            "code" : "114741000",
            "display" : "Salmonella II 1,40:g,[m],[s],t:1,5 (organism)"
          },
          {
            "code" : "398440002",
            "display" : "Salmonella IIIb 58:r:z53:(57) (organism)"
          },
          {
            "code" : "12248009",
            "display" : "Salmonella II 56:z10:e,n,x (organism)"
          },
          {
            "code" : "114568002",
            "display" : "Salmonella II 1,9,12:b:z39 (organism)"
          },
          {
            "code" : "114375002",
            "display" : "Salmonella VI [1],6,14:a:1,5 (organism)"
          },
          {
            "code" : "114374003",
            "display" : "Salmonella II 1,13,23:e,n,x:1,[5],7 (organism)"
          },
          {
            "code" : "114755008",
            "display" : "Salmonella II 1,40:z:1,5 (organism)"
          },
          {
            "code" : "19891007",
            "display" : "Salmonella II 50:l,z28:z42 (organism)"
          },
          {
            "code" : "114742007",
            "display" : "Salmonella II 1,40:g,t:e,n,x,z15 (organism)"
          },
          {
            "code" : "404487002",
            "display" : "Salmonella VI, group O:45 (organism)"
          },
          {
            "code" : "30430002",
            "display" : "Salmonella IV 45:g,z51:- (organism)"
          },
          {
            "code" : "15288005",
            "display" : "Salmonella Banco (organism)"
          },
          {
            "code" : "114347004",
            "display" : "Salmonella II 1,13,23:b:[1,5]:z42 (organism)"
          },
          {
            "code" : "404404007",
            "display" : "Salmonella IIIb 40:k:z53 (organism)"
          },
          {
            "code" : "114766001",
            "display" : "Salmonella II 40:z39:1,7 (organism)"
          },
          {
            "code" : "114977004",
            "display" : "Salmonella IIIb 59:c:e,n,x,z15 (organism)"
          },
          {
            "code" : "114514007",
            "display" : "Salmonella II 6,7:z:1,5 (organism)"
          },
          {
            "code" : "404483003",
            "display" : "Salmonella I, group O:45 (organism)"
          },
          {
            "code" : "404541005",
            "display" : "Salmonella IIIb 47:l,v:1,5,(7) (organism)"
          },
          {
            "code" : "56077000",
            "display" : "Salmonella Newport (organism)"
          },
          {
            "code" : "34434000",
            "display" : "Salmonella Zwickau (organism)"
          },
          {
            "code" : "31859003",
            "display" : "Salmonella Egusitoo (organism)"
          },
          {
            "code" : "398347003",
            "display" : "Salmonella IIIb, group O:16 (organism)"
          },
          {
            "code" : "89806001",
            "display" : "Salmonella Kotte (organism)"
          },
          {
            "code" : "31745002",
            "display" : "Salmonella Lishabi (organism)"
          },
          {
            "code" : "66385002",
            "display" : "Salmonella IV Argentina (organism)"
          },
          {
            "code" : "114326003",
            "display" : "Salmonella IV 11:g,z51:- (organism)"
          },
          {
            "code" : "398519001",
            "display" : "Salmonella IIIb 65:l,v:z (organism)"
          },
          {
            "code" : "18828000",
            "display" : "Salmonella II 8:z29:e,n,x:z42 (organism)"
          },
          {
            "code" : "49452001",
            "display" : "Salmonella Cotham (organism)"
          },
          {
            "code" : "398366003",
            "display" : "Salmonella II, group O:55 (organism)"
          },
          {
            "code" : "49270001",
            "display" : "Salmonella Jalisco (organism)"
          },
          {
            "code" : "114822007",
            "display" : "Salmonella Sudan (organism)"
          },
          {
            "code" : "114577009",
            "display" : "Salmonella II 1,9,12:g,z62:[e,n,x] (organism)"
          },
          {
            "code" : "45054004",
            "display" : "Salmonella II 43:z29:z42 (organism)"
          },
          {
            "code" : "73249008",
            "display" : "Salmonella Victoria (organism)"
          },
          {
            "code" : "404281004",
            "display" : "Salmonella IIIb 17:i:z35 (organism)"
          },
          {
            "code" : "302708009",
            "display" : "Salmonella Kuntair (organism)"
          },
          {
            "code" : "114559004",
            "display" : "Salmonella Breda (organism)"
          },
          {
            "code" : "6350000",
            "display" : "Salmonella Joal (organism)"
          },
          {
            "code" : "398586003",
            "display" : "Salmonella II, group O:9,46,27 (organism)"
          },
          {
            "code" : "31454000",
            "display" : "Salmonella II 41:-:1,6 (organism)"
          },
          {
            "code" : "398566002",
            "display" : "Salmonella IIIb, group O:52 (organism)"
          },
          {
            "code" : "19374001",
            "display" : "Salmonella enteritidis, phage type 4 (organism)"
          },
          {
            "code" : "734436009",
            "display" : "Salmonella Lamphun (organism)"
          },
          {
            "code" : "114355006",
            "display" : "Salmonella II 1,13,23:m,t:e,n,x (organism)"
          },
          {
            "code" : "67092009",
            "display" : "Salmonella Morehead (organism)"
          },
          {
            "code" : "12767007",
            "display" : "Salmonella Crossness (organism)"
          },
          {
            "code" : "114468004",
            "display" : "Salmonella II 4,12:d:e,n,x (organism)"
          },
          {
            "code" : "398374002",
            "display" : "Salmonella IIIb 59:(k):z (organism)"
          },
          {
            "code" : "404623007",
            "display" : "Salmonella IV 50:z4,z23:- (organism)"
          },
          {
            "code" : "76702004",
            "display" : "Salmonella Freiburg (organism)"
          },
          {
            "code" : "83952001",
            "display" : "Salmonella IV 41:z4,z23:- (organism)"
          },
          {
            "code" : "1621003",
            "display" : "Salmonella IV 45:z4,z23:- (organism)"
          },
          {
            "code" : "404553009",
            "display" : "Salmonella IIIb 47:z10:z35 (organism)"
          },
          {
            "code" : "114826005",
            "display" : "Salmonella IV 43:z4,z23:- (organism)"
          },
          {
            "code" : "114323006",
            "display" : "Salmonella Abuja (organism)"
          },
          {
            "code" : "54697006",
            "display" : "Salmonella Techimani (organism)"
          },
          {
            "code" : "114471007",
            "display" : "Salmonella II 1,4,12,27:e,n,x:1,[5]7 (organism)"
          },
          {
            "code" : "398353003",
            "display" : "Salmonella IIIb 60:r:z (organism)"
          },
          {
            "code" : "46765008",
            "display" : "Salmonella Nanergou (organism)"
          },
          {
            "code" : "42061009",
            "display" : "Salmonella Jaffna (organism)"
          },
          {
            "code" : "114751004",
            "display" : "Salmonella II 40:l,v:e,n,x (organism)"
          },
          {
            "code" : "398491004",
            "display" : "Salmonella IIIb 65:l,v:z53 (organism)"
          },
          {
            "code" : "49029009",
            "display" : "Salmonella Epicrates (organism)"
          },
          {
            "code" : "114608005",
            "display" : "Salmonella II 9,46:z:e,n,x (organism)"
          },
          {
            "code" : "404388008",
            "display" : "Salmonella IIIb 38:z10:z53 (organism)"
          },
          {
            "code" : "30686007",
            "display" : "Salmonella Ochsenwerder (organism)"
          },
          {
            "code" : "33108006",
            "display" : "Salmonella Birkenhead (organism)"
          },
          {
            "code" : "115409001",
            "display" : "Salmonella, serogroup E (organism)"
          },
          {
            "code" : "720961001",
            "display" : "Salmonella Drac (organism)"
          },
          {
            "code" : "398434009",
            "display" : "Salmonella IIIb 65:i:e,n,x,z15 (organism)"
          },
          {
            "code" : "1291002",
            "display" : "Salmonella Frankfurt (organism)"
          },
          {
            "code" : "114627004",
            "display" : "Salmonella II 3,10:l,z28:e,n,x (organism)"
          },
          {
            "code" : "89556001",
            "display" : "Salmonella Alminko (organism)"
          },
          {
            "code" : "114862006",
            "display" : "Salmonella II 47:a:1,5 (organism)"
          },
          {
            "code" : "15578008",
            "display" : "Salmonella Dahlem (organism)"
          },
          {
            "code" : "404370000",
            "display" : "Salmonella IIIb, group O:38 (organism)"
          },
          {
            "code" : "114929004",
            "display" : "Salmonella II 51:g,s,t:e,n,x (organism)"
          },
          {
            "code" : "5369001",
            "display" : "Salmonella Ezra (organism)"
          },
          {
            "code" : "38658003",
            "display" : "Salmonella Amsterdam (organism)"
          },
          {
            "code" : "87933008",
            "display" : "Salmonella Barranquilla (organism)"
          },
          {
            "code" : "398499002",
            "display" : "Salmonella Shangani var 15+ (organism)"
          },
          {
            "code" : "3596001",
            "display" : "Salmonella Poano (organism)"
          },
          {
            "code" : "40157006",
            "display" : "Salmonella Marienthal (organism)"
          },
          {
            "code" : "398435005",
            "display" : "Salmonella IIIb 51:k:z35 (organism)"
          },
          {
            "code" : "46340008",
            "display" : "Salmonella IV 44:z36,(z38):- (organism)"
          },
          {
            "code" : "74122008",
            "display" : "Salmonella Portland (organism)"
          },
          {
            "code" : "114704001",
            "display" : "Salmonella II 35:d:1,5 (organism)"
          },
          {
            "code" : "64155002",
            "display" : "Salmonella Kunduchi (organism)"
          },
          {
            "code" : "114691007",
            "display" : "Salmonella Santander (organism)"
          },
          {
            "code" : "52730003",
            "display" : "Salmonella Typhisuis (organism)"
          },
          {
            "code" : "404485005",
            "display" : "Salmonella IIIa, group O:45 (organism)"
          },
          {
            "code" : "12964005",
            "display" : "Salmonella Souza (organism)"
          },
          {
            "code" : "77834007",
            "display" : "Salmonella Toronto (organism)"
          },
          {
            "code" : "1083004",
            "display" : "Salmonella Wyldegreen (organism)"
          },
          {
            "code" : "404284007",
            "display" : "Salmonella IIIb 17:r:z (organism)"
          },
          {
            "code" : "64078005",
            "display" : "Salmonella Lindenburg (organism)"
          },
          {
            "code" : "442106000",
            "display" : "Salmonella enterica subspecies enterica serovar 13,23:z:- (organism)"
          },
          {
            "code" : "114584001",
            "display" : "Salmonella II 1,9,12:z:1,7 (organism)"
          },
          {
            "code" : "398379007",
            "display" : "Salmonella IIIb 59:(k):z35 (organism)"
          },
          {
            "code" : "71316008",
            "display" : "Salmonella Guinea (organism)"
          },
          {
            "code" : "34051000",
            "display" : "Salmonella Sandow (organism)"
          },
          {
            "code" : "370577001",
            "display" : "Salmonella Choleraesuis var. Kunzendorf (organism)"
          },
          {
            "code" : "114733000",
            "display" : "Salmonella Hegau (organism)"
          },
          {
            "code" : "404310008",
            "display" : "Salmonella group O:21 (organism)"
          },
          {
            "code" : "83013006",
            "display" : "Salmonella Chailey (organism)"
          },
          {
            "code" : "114779005",
            "display" : "Salmonella II 41:k:1,6 (organism)"
          },
          {
            "code" : "115002004",
            "display" : "Salmonella V 66:z65:- (organism)"
          },
          {
            "code" : "10999003",
            "display" : "Salmonella Potto (organism)"
          },
          {
            "code" : "35053007",
            "display" : "Salmonella II 16:d:1,5 (organism)"
          },
          {
            "code" : "114718008",
            "display" : "Salmonella IIIb 38:(k):z35 (organism)"
          },
          {
            "code" : "53723000",
            "display" : "Salmonella Vellore (organism)"
          },
          {
            "code" : "10096007",
            "display" : "Salmonella Leoben (organism)"
          },
          {
            "code" : "65700004",
            "display" : "Salmonella Calabar (organism)"
          },
          {
            "code" : "65779004",
            "display" : "Salmonella Papuana (organism)"
          },
          {
            "code" : "88149008",
            "display" : "Salmonella Matadi (organism)"
          },
          {
            "code" : "404490008",
            "display" : "Salmonella group O:47 (organism)"
          },
          {
            "code" : "42485005",
            "display" : "Salmonella Bakau (organism)"
          },
          {
            "code" : "40998003",
            "display" : "Salmonella Etterbeek (organism)"
          },
          {
            "code" : "44629007",
            "display" : "Salmonella II 57:g,m,s,t:z42 (organism)"
          },
          {
            "code" : "23790005",
            "display" : "Salmonella Kokoli (organism)"
          },
          {
            "code" : "398552007",
            "display" : "Salmonella Florian (organism)"
          },
          {
            "code" : "16723007",
            "display" : "Salmonella Rottnest (organism)"
          },
          {
            "code" : "398433003",
            "display" : "Salmonella IIIb 60:z52:z35 (organism)"
          },
          {
            "code" : "36077005",
            "display" : "Salmonella Sarajane (organism)"
          },
          {
            "code" : "105780007",
            "display" : "Salmonella group O:66 (organism)"
          },
          {
            "code" : "114562001",
            "display" : "Salmonella Kolda (organism)"
          },
          {
            "code" : "404340005",
            "display" : "Salmonella II, group O:30 (organism)"
          },
          {
            "code" : "80232006",
            "display" : "Salmonella Choleraesuis (organism)"
          },
          {
            "code" : "404349006",
            "display" : "Salmonella IIIb 35:(k):z35 (organism)"
          },
          {
            "code" : "50785006",
            "display" : "Salmonella Alger (organism)"
          },
          {
            "code" : "441713006",
            "display" : "Salmonella enterica subspecies enterica serovar 6,7:b:- (organism)"
          },
          {
            "code" : "60913000",
            "display" : "Salmonella II 6,8:d:z6,z42 (organism)"
          },
          {
            "code" : "398597003",
            "display" : "Salmonella IIIb 53:(k):z35 (organism)"
          },
          {
            "code" : "53501002",
            "display" : "Salmonella II 13,23:k:z41 (organism)"
          },
          {
            "code" : "114556006",
            "display" : "Salmonella Benue (organism)"
          },
          {
            "code" : "404364006",
            "display" : "Salmonella IIIb 35:z52:z (organism)"
          },
          {
            "code" : "398425004",
            "display" : "Salmonella IIIa 6,7,14:z39:1,2 (organism)"
          },
          {
            "code" : "76356009",
            "display" : "Salmonella Morotai (organism)"
          },
          {
            "code" : "398595006",
            "display" : "Salmonella IIIb 59:i:z (organism)"
          },
          {
            "code" : "4267007",
            "display" : "Salmonella Stourbridge (organism)"
          },
          {
            "code" : "30552009",
            "display" : "Salmonella II 58:a:(z6) (organism)"
          },
          {
            "code" : "74115000",
            "display" : "Salmonella Widemarsh (organism)"
          },
          {
            "code" : "32531009",
            "display" : "Salmonella II 9,46:e,n,x:1,5,7 (organism)"
          },
          {
            "code" : "64619006",
            "display" : "Salmonella Thayngen (organism)"
          },
          {
            "code" : "114318006",
            "display" : "Salmonella VI 11:b:e,n,x (organism)"
          },
          {
            "code" : "75196009",
            "display" : "Salmonella enterica subspecies enterica serovar Butantan (organism)"
          },
          {
            "code" : "404575006",
            "display" : "Salmonella IIIb 48:k:z53 (organism)"
          },
          {
            "code" : "404355001",
            "display" : "Salmonella IIIb 35:r:e,n,x,z15 (organism)"
          },
          {
            "code" : "114976008",
            "display" : "Salmonella II 58:z39:e,n,x,z15 (organism)"
          },
          {
            "code" : "114484003",
            "display" : "Salmonella Finaghy (organism)"
          },
          {
            "code" : "13679006",
            "display" : "Salmonella Ahanou (organism)"
          },
          {
            "code" : "114334009",
            "display" : "Salmonella Connecticut (organism)"
          },
          {
            "code" : "404323001",
            "display" : "Salmonella IIIb 21:k:e,n,x,z15 (organism)"
          },
          {
            "code" : "404327000",
            "display" : "Salmonella IIIb 21:z10:e,n,x,z15 (organism)"
          },
          {
            "code" : "404598003",
            "display" : "Salmonella IIIb 50:(k):z (organism)"
          },
          {
            "code" : "114564000",
            "display" : "Salmonella Dunkwa (organism)"
          },
          {
            "code" : "404395004",
            "display" : "Salmonella I, group O:40 (organism)"
          },
          {
            "code" : "748001",
            "display" : "Salmonella Chandans (organism)"
          },
          {
            "code" : "114655000",
            "display" : "Salmonella Surrey (organism)"
          },
          {
            "code" : "9852002",
            "display" : "Salmonella Dahomey (organism)"
          },
          {
            "code" : "31469004",
            "display" : "Salmonella Langensalza (organism)"
          },
          {
            "code" : "56955001",
            "display" : "Salmonella Westerstede (organism)"
          },
          {
            "code" : "47143006",
            "display" : "Salmonella Benguella (organism)"
          },
          {
            "code" : "442071007",
            "display" : "Salmonella enterica subspecies enterica serovar 4,12:i:- (organism)"
          },
          {
            "code" : "404332004",
            "display" : "Salmonella II 21:c:e,n,x (organism)"
          },
          {
            "code" : "398544009",
            "display" : "Salmonella IIIb, group O:53 (organism)"
          },
          {
            "code" : "398404004",
            "display" : "Salmonella IIIa 63:g:z51:- (organism)"
          },
          {
            "code" : "8860008",
            "display" : "Salmonella Ramatgan (organism)"
          },
          {
            "code" : "20209004",
            "display" : "Salmonella Landwasser (organism)"
          },
          {
            "code" : "398474003",
            "display" : "Salmonella IIIb 59:k:z53 (organism)"
          },
          {
            "code" : "86511007",
            "display" : "Salmonella Cotia (organism)"
          },
          {
            "code" : "48584004",
            "display" : "Salmonella Akanji (organism)"
          },
          {
            "code" : "398567006",
            "display" : "Salmonella I, group O:4 (organism)"
          },
          {
            "code" : "114345007",
            "display" : "Salmonella II 1,13,23:a:e,n,x (organism)"
          },
          {
            "code" : "44451005",
            "display" : "Salmonella Roodepoort (organism)"
          },
          {
            "code" : "721062001",
            "display" : "Salmonella enterica subspecies enterica serovar O rough: nonmotile (organism)"
          },
          {
            "code" : "404468008",
            "display" : "Salmonella I, group O:44 (organism)"
          },
          {
            "code" : "398496009",
            "display" : "Salmonella IIIb 65:z52:z53 (organism)"
          },
          {
            "code" : "709136002",
            "display" : "Salmonella Maumee (organism)"
          },
          {
            "code" : "114528001",
            "display" : "Salmonella II 6,7:z39:1,5,7 (organism)"
          }
        ]
      }
    ]
  }
}

```
