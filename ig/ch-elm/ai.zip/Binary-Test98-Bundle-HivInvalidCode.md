# Test98-Bundle-HivInvalidCode - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test98-Bundle-HivInvalidCode**

## Binary: Test98-Bundle-HivInvalidCode

```

<Bundle xmlns="http://hl7.org/fhir">
  <id value="49Doc-HIV"/>
  <identifier>
    <system value="urn:ietf:rfc:3986"/>
    <value value="urn:uuid:3401332d-6012-443f-9690-6334adb23aac"/>
  </identifier>
  <type value="document"/>
  <timestamp value="2024-11-06T12:00:00+02:00"/>
  <entry>
    <fullUrl value="urn:uuid:288f3a94-5c88-461f-937c-c8948dd86ca0"/>
    <resource>
      <Composition>
        <id value="288f3a94-5c88-461f-937c-c8948dd86ca0"/>
        <language value="de-CH"/>
        <identifier>
          <system value="urn:ietf:rfc:3986"/>
          <value value="urn:uuid:3401332d-6012-443f-9690-6334adb23aac"/>
        </identifier>
        <status value="final"/>
        <type>
          <coding>
            <system value="http://snomed.info/sct"/>
            <version value="http://snomed.info/sct/2011000195101"/>
            <code value="4241000179101"/>
            <display value="Laborbericht"/>
          </coding>
          <coding>
            <system value="http://loinc.org"/>
            <code value="11502-2"/>
            <display value="Laboratory report"/>
          </coding>
        </type>
        <subject>
          <reference value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        </subject>
        <date value="2024-11-06T12:00:00+02:00"/>
        <author>
          <reference value="urn:uuid:3e25781f-bdcc-4e9f-99b2-162b4aaebc56"/>
        </author>
        <title value="Laborbericht vom 6.11.2024"/>
        <section>
          <title value="Analyseergebnisse der mikrobiologischen Untersuchung"/>
          <code>
            <coding>
              <system value="http://loinc.org"/>
              <code value="18725-2"/>
              <display value="Microbiology studies (set)"/>
            </coding>
          </code>
          <entry>
            <reference value="urn:uuid:2ead0239-152f-4db9-89dd-68c073477155"/>
          </entry>
        </section>
      </Composition>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
    <resource>
      <Patient>
        <id value="53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        <identifier>
          <system value="urn:oid:2.16.756.5.32"/>
          <value value="7561234567897"/>
        </identifier>
        <name>
          <extension url="http://fhir.ch/ig/ch-elm/StructureDefinition/ch-elm-ext-hiv-code">
            <valueString value="H"/>
          </extension>
          <family>
            <extension url="http://hl7.org/fhir/StructureDefinition/data-absent-reason">
              <valueCode value="masked"/>
            </extension>
          </family>
          <given>
            <extension url="http://hl7.org/fhir/StructureDefinition/data-absent-reason">
              <valueCode value="masked"/>
            </extension>
          </given>
        </name>
        <gender value="female"/>
        <birthDate value="1981-02-07"/>
        <address>
          <use value="home"/>
          <city value="Carouge"/>
          <state value="GE"/>
          <postalCode value="1227"/>
          <country value="CH">
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding">
              <valueCoding>
                <system value="urn:iso:std:iso:3166"/>
                <code value="CH"/>
              </valueCoding>
            </extension>
          </country>
        </address>
      </Patient>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:3e25781f-bdcc-4e9f-99b2-162b4aaebc56"/>
    <resource>
      <Organization>
        <id value="3e25781f-bdcc-4e9f-99b2-162b4aaebc56"/>
        <identifier>
          <system value="urn:oid:2.51.1.3"/>
          <value value="7601002331470"/>
        </identifier>
        <name value="SanLab"/>
      </Organization>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:2ead0239-152f-4db9-89dd-68c073477155"/>
    <resource>
      <Observation>
        <id value="2ead0239-152f-4db9-89dd-68c073477155"/>
        <status value="final"/>
        <category>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/observation-category"/>
            <code value="laboratory"/>
            <display value="Laboratory"/>
          </coding>
        </category>
        <code>
          <coding>
            <system value="http://snomed.info/sct"/>
            <code value="89293008"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        </subject>
        <effectiveDateTime value="2024-11-04T14:20:00+02:00"/>
        <performer>
          <reference value="urn:uuid:3e25781f-bdcc-4e9f-99b2-162b4aaebc56"/>
        </performer>
        <dataAbsentReason>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/data-absent-reason"/>
            <code value="not-applicable"/>
          </coding>
        </dataAbsentReason>
        <interpretation>
          <coding>
            <system value="http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation"/>
            <code value="POS"/>
            <display value="Positive"/>
          </coding>
        </interpretation>
        <specimen>
          <reference value="urn:uuid:fa064f03-0908-4958-82cb-e940cadacfd3"/>
        </specimen>
      </Observation>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:1cb13eb9-4e83-4df0-87ab-11b5cce250ba"/>
    <resource>
      <Practitioner>
        <id value="1cb13eb9-4e83-4df0-87ab-11b5cce250ba"/>
        <identifier>
          <system value="urn:oid:2.51.1.3"/>
          <value value="7601000000514"/>
        </identifier>
        <name>
          <family value="Hauser"/>
          <given value="Peter"/>
        </name>
        <telecom>
          <system value="phone"/>
          <value value="+41 79 222 33 44"/>
        </telecom>
        <telecom>
          <system value="email"/>
          <value value="peter.hauser@hauserpraxis.ch"/>
        </telecom>
      </Practitioner>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:1a06aa4d-fc32-403f-99c1-680232316b57"/>
    <resource>
      <Organization>
        <id value="1a06aa4d-fc32-403f-99c1-680232316b57"/>
        <identifier>
          <system value="urn:oid:2.16.756.5.45"/>
          <value value="A74966168"/>
        </identifier>
        <name value="Praxis Dr. Hauser"/>
        <address>
          <line value="Hauptstrasse 10">
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName">
              <valueString value="Hauptstrasse"/>
            </extension>
            <extension url="http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber">
              <valueString value="10"/>
            </extension>
          </line>
          <city value="Solothurn"/>
          <postalCode value="4500"/>
        </address>
      </Organization>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:0d4d9b6a-6a42-47a1-8abf-c715bdb5de2c"/>
    <resource>
      <PractitionerRole>
        <id value="0d4d9b6a-6a42-47a1-8abf-c715bdb5de2c"/>
        <practitioner>
          <reference value="urn:uuid:1cb13eb9-4e83-4df0-87ab-11b5cce250ba"/>
        </practitioner>
        <organization>
          <reference value="urn:uuid:1a06aa4d-fc32-403f-99c1-680232316b57"/>
        </organization>
      </PractitionerRole>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:fa064f03-0908-4958-82cb-e940cadacfd3"/>
    <resource>
      <Specimen>
        <id value="fa064f03-0908-4958-82cb-e940cadacfd3"/>
        <type>
          <text value="Material declared by Observation.code or non-mandatory"/>
        </type>
        <subject>
          <reference value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        </subject>
        <collection>
          <collectedDateTime value="2024-11-01T14:20:00+02:00"/>
        </collection>
      </Specimen>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:d78e6789-f3f0-46fe-aded-04b2da318e68"/>
    <resource>
      <ServiceRequest>
        <id value="d78e6789-f3f0-46fe-aded-04b2da318e68"/>
        <identifier>
          <value value="26500923622"/>
        </identifier>
        <status value="completed"/>
        <intent value="order"/>
        <code>
          <coding>
            <system value="http://snomed.info/sct"/>
            <code value="89293008"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        </subject>
        <requester>
          <reference value="urn:uuid:0d4d9b6a-6a42-47a1-8abf-c715bdb5de2c"/>
        </requester>
        <specimen>
          <reference value="urn:uuid:fa064f03-0908-4958-82cb-e940cadacfd3"/>
        </specimen>
      </ServiceRequest>
    </resource>
  </entry>
  <entry>
    <fullUrl value="urn:uuid:6bfcd981-5e6b-47ed-8531-aba2b9eef9cd"/>
    <resource>
      <DiagnosticReport>
        <id value="6bfcd981-5e6b-47ed-8531-aba2b9eef9cd"/>
        <extension url="http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition">
          <valueReference>
            <reference value="urn:uuid:288f3a94-5c88-461f-937c-c8948dd86ca0"/>
          </valueReference>
        </extension>
        <identifier>
          <system value="urn:ietf:rfc:3986"/>
          <value value="urn:uuid:3401332d-6012-443f-9690-6334adb23aac"/>
        </identifier>
        <basedOn>
          <reference value="urn:uuid:d78e6789-f3f0-46fe-aded-04b2da318e68"/>
        </basedOn>
        <status value="final"/>
        <code>
          <coding>
            <system value="http://loinc.org"/>
            <code value="11502-2"/>
            <display value="Laboratory report"/>
          </coding>
        </code>
        <subject>
          <reference value="urn:uuid:53b13bba-26d7-4ab7-81cd-7eaf18dc26eb"/>
        </subject>
        <performer>
          <reference value="urn:uuid:3e25781f-bdcc-4e9f-99b2-162b4aaebc56"/>
        </performer>
        <specimen>
          <reference value="urn:uuid:fa064f03-0908-4958-82cb-e940cadacfd3"/>
        </specimen>
        <result>
          <reference value="urn:uuid:2ead0239-152f-4db9-89dd-68c073477155"/>
        </result>
      </DiagnosticReport>
    </resource>
  </entry>
</Bundle>
```



## Resource Binary Content

application/fhir+xml:

```
{snip}
```
