# 59Doc - EHEC - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **59Doc - EHEC**

## Example Bundle: 59Doc - EHEC



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "59Doc-EHEC",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"
  },
  "type" : "document",
  "timestamp" : "2025-01-20T12:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:a14fc51d-b9d5-4bae-b5ca-ff384e17e2b2",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "a14fc51d-b9d5-4bae-b5ca-ff384e17e2b2",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578"
      },
      "date" : "2025-01-20T12:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:058d2b2d-34c0-4996-b104-d9836d6733a7"
      }],
      "title" : "Laborbericht vom 20.01.2025",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:ca4bc525-df7c-473d-a087-b610f1dc6048"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "b11cabe7-12a2-4107-94a0-9def47bdd578",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7561234567897"
      }],
      "name" : [{
        "family" : "Dupont",
        "given" : ["Antoine"]
      }],
      "gender" : "female",
      "birthDate" : "1981-02-07",
      "address" : [{
        "use" : "home",
        "line" : ["rue de la république 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "rue de la république"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Carouge",
        "state" : "GE",
        "postalCode" : "1227",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:058d2b2d-34c0-4996-b104-d9836d6733a7",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "058d2b2d-34c0-4996-b104-d9836d6733a7",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:ca4bc525-df7c-473d-a087-b610f1dc6048",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ca4bc525-df7c-473d-a087-b610f1dc6048",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51940-5"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578"
      },
      "effectiveDateTime" : "2025-01-19T14:20:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:058d2b2d-34c0-4996-b104-d9836d6733a7"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:f3dce220-1650-4019-9dbe-6ab18adbb0d7"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:7df5e94c-5878-43da-92d6-0624fcb0c0e0",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "7df5e94c-5878-43da-92d6-0624fcb0c0e0",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000000514"
      }],
      "name" : [{
        "family" : "Hauser",
        "given" : ["Peter"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 222 33 44"
      },
      {
        "system" : "email",
        "value" : "peter.hauser@hauserpraxis.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:4343f83a-f0eb-4d47-8646-5191f3c2df36",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "4343f83a-f0eb-4d47-8646-5191f3c2df36",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A74966168"
      }],
      "name" : "Praxis Dr. Hauser",
      "address" : [{
        "line" : ["Hauptstrasse 10"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Hauptstrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "10"
          }]
        }],
        "city" : "Solothurn",
        "postalCode" : "4500"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0df7d3fc-2b32-43af-ae5c-15821961b5d4",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "0df7d3fc-2b32-43af-ae5c-15821961b5d4",
      "practitioner" : {
        "reference" : "urn:uuid:7df5e94c-5878-43da-92d6-0624fcb0c0e0"
      },
      "organization" : {
        "reference" : "urn:uuid:4343f83a-f0eb-4d47-8646-5191f3c2df36"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:f3dce220-1650-4019-9dbe-6ab18adbb0d7",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "f3dce220-1650-4019-9dbe-6ab18adbb0d7",
      "subject" : {
        "reference" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578"
      },
      "collection" : {
        "collectedDateTime" : "2025-01-15T14:20:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:62ee45ab-fc08-4464-9c52-bbfcc4210bed",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "62ee45ab-fc08-4464-9c52-bbfcc4210bed",
      "identifier" : [{
        "value" : "26500923675"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51940-5"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578"
      },
      "requester" : {
        "reference" : "urn:uuid:0df7d3fc-2b32-43af-ae5c-15821961b5d4"
      },
      "specimen" : [{
        "reference" : "urn:uuid:f3dce220-1650-4019-9dbe-6ab18adbb0d7"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:ec00281a-19ff-41a5-94ef-91303db77c69",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "ec00281a-19ff-41a5-94ef-91303db77c69",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:a14fc51d-b9d5-4bae-b5ca-ff384e17e2b2"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:54013a2d-6012-443f-9a90-6331adb23aab"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:62ee45ab-fc08-4464-9c52-bbfcc4210bed"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:b11cabe7-12a2-4107-94a0-9def47bdd578"
      },
      "performer" : [{
        "reference" : "urn:uuid:058d2b2d-34c0-4996-b104-d9836d6733a7"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:f3dce220-1650-4019-9dbe-6ab18adbb0d7"
      }],
      "result" : [{
        "reference" : "urn:uuid:ca4bc525-df7c-473d-a087-b610f1dc6048"
      }]
    }
  }]
}

```
