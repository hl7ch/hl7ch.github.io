# 1Spec - Neisseria Gonorrhoeae - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1Spec - Neisseria Gonorrhoeae**

## Example Specimen: 1Spec - Neisseria Gonorrhoeae



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "1Spec-Specimen",
  "subject" : {
    "reference" : "Patient/Pat-001"
  },
  "collection" : {
    "collectedDateTime" : "2023-07-01"
  }
}

```
