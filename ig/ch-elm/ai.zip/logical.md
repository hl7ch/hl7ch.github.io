# Logical Model - CH ELM (R4) v1.13.1

* [**Table of Contents**](toc.md)
* **Logical Model**

## Logical Model

see [here](StructureDefinition-LaboratoryReport-mappings.md) how the different elements of the logical model are mapped to FHIR.

