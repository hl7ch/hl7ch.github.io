# 1PR - Monika Giacometti @ Kantonsspital ABC - CH ELM (R4) v1.13.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1PR - Monika Giacometti @ Kantonsspital ABC**

## Example PractitionerRole: 1PR - Monika Giacometti @ Kantonsspital ABC

**practitioner**: [Practitioner Monika Giacometti](Practitioner-1Pract-KsAbc.md)

**organization**: [Organization Kantonsspital ABC](Organization-1Org-KsAbc.md)



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "1PR-KsAbc",
  "practitioner" : {
    "reference" : "Practitioner/1Pract-KsAbc"
  },
  "organization" : {
    "reference" : "Organization/1Org-KsAbc"
  }
}

```
