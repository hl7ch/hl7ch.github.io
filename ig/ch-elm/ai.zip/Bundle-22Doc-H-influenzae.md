# 22Doc - Haemophilus influenzae - CH ELM (R4) v1.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **22Doc - Haemophilus influenzae**

## Example Bundle: 22Doc - Haemophilus influenzae



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "22Doc-H-influenzae",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
  },
  "type" : "document",
  "timestamp" : "2024-08-14T11:00:00+02:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:3d61d2b0-fe4b-4a32-8a22-6f43467f8c77",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "3d61d2b0-fe4b-4a32-8a22-6f43467f8c77",
      "language" : "de-CH",
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/2011000195101",
          "code" : "4241000179101",
          "display" : "Laborbericht"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c"
      },
      "date" : "2024-08-14T11:00:00+02:00",
      "author" : [{
        "reference" : "urn:uuid:bf7edd48-b2f6-408a-9f49-ce93b6066932"
      }],
      "title" : "Laborbericht vom 14.8.2024",
      "section" : [{
        "title" : "Analyseergebnisse der mikrobiologischen Untersuchung",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18725-2",
            "display" : "Microbiology studies (set)"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:324e1133-d0df-4c8f-8d97-ca0ba3f4b12a"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "5ed8eb22-842c-4f14-ac5f-2b1da4c4855c",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.32",
        "value" : "7562295883070"
      }],
      "name" : [{
        "family" : "M",
        "given" : ["D"]
      }],
      "gender" : "male",
      "birthDate" : "1960-08-22",
      "address" : [{
        "use" : "home",
        "city" : "Bern",
        "state" : "BE",
        "postalCode" : "3000",
        "country" : "CH",
        "_country" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-codedString",
            "valueCoding" : {
              "system" : "urn:iso:std:iso:3166",
              "code" : "CH"
            }
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:bf7edd48-b2f6-408a-9f49-ce93b6066932",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "bf7edd48-b2f6-408a-9f49-ce93b6066932",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601002331470"
      }],
      "name" : "SanLab"
    }
  },
  {
    "fullUrl" : "urn:uuid:324e1133-d0df-4c8f-8d97-ca0ba3f4b12a",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "324e1133-d0df-4c8f-8d97-ca0ba3f4b12a",
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "53607-8"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c"
      },
      "effectiveDateTime" : "2024-08-12T09:15:00+02:00",
      "performer" : [{
        "reference" : "urn:uuid:bf7edd48-b2f6-408a-9f49-ce93b6066932"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "urn:uuid:744597fb-2e62-4892-b7a9-8ec570f98631"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:332ba792-d79d-4de7-83c6-2cdf57da0f51",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "332ba792-d79d-4de7-83c6-2cdf57da0f51",
      "identifier" : [{
        "system" : "urn:oid:2.51.1.3",
        "value" : "7601000234438"
      }],
      "name" : [{
        "family" : "Giacometti",
        "given" : ["Monika"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+41 79 111 44 55"
      },
      {
        "system" : "email",
        "value" : "m.giacometti@ks-abc.ch"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c90e77ae-c89c-4074-ae01-67cba30ab724",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "c90e77ae-c89c-4074-ae01-67cba30ab724",
      "identifier" : [{
        "system" : "urn:oid:2.16.756.5.45",
        "value" : "A99684215"
      }],
      "name" : "Kantonsspital ABC",
      "address" : [{
        "line" : ["Aortastrasse 22"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Aortastrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "22"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
            "valueString" : "Postfach 18"
          }]
        }],
        "city" : "Bern",
        "postalCode" : "3000"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0bb90dd9-8ae7-4060-8508-bd90573a5dfb",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "0bb90dd9-8ae7-4060-8508-bd90573a5dfb",
      "practitioner" : {
        "reference" : "urn:uuid:332ba792-d79d-4de7-83c6-2cdf57da0f51"
      },
      "organization" : {
        "reference" : "urn:uuid:c90e77ae-c89c-4074-ae01-67cba30ab724"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:744597fb-2e62-4892-b7a9-8ec570f98631",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "744597fb-2e62-4892-b7a9-8ec570f98631",
      "type" : {
        "text" : "Material declared by Observation.code or non-mandatory"
      },
      "subject" : {
        "reference" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c"
      },
      "collection" : {
        "collectedDateTime" : "2024-08-10T09:15:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:24015685-568e-4338-b33d-8cf051bf72d9",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "24015685-568e-4338-b33d-8cf051bf72d9",
      "identifier" : [{
        "value" : "50002755"
      }],
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "53607-8"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c"
      },
      "requester" : {
        "reference" : "urn:uuid:0bb90dd9-8ae7-4060-8508-bd90573a5dfb"
      },
      "specimen" : [{
        "reference" : "urn:uuid:744597fb-2e62-4892-b7a9-8ec570f98631"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:2cf0731f-5d91-4fe4-ae17-5cc29a35daa6",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "2cf0731f-5d91-4fe4-ae17-5cc29a35daa6",
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-DiagnosticReport.composition",
        "valueReference" : {
          "reference" : "urn:uuid:3d61d2b0-fe4b-4a32-8a22-6f43467f8c77"
        }
      }],
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:ac01252d-6012-443f-9690-9291adb23433"
      }],
      "basedOn" : [{
        "reference" : "urn:uuid:24015685-568e-4338-b33d-8cf051bf72d9"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:5ed8eb22-842c-4f14-ac5f-2b1da4c4855c"
      },
      "performer" : [{
        "reference" : "urn:uuid:bf7edd48-b2f6-408a-9f49-ce93b6066932"
      }],
      "specimen" : [{
        "reference" : "urn:uuid:744597fb-2e62-4892-b7a9-8ec570f98631"
      }],
      "result" : [{
        "reference" : "urn:uuid:324e1133-d0df-4c8f-8d97-ca0ba3f4b12a"
      }]
    }
  }]
}

```
