# 1Org - Labor - CH ELM (R4) v1.13.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1Org - Labor**

## Example Organization: 1Org - Labor

**identifier**: [GLN](https://www.gs1.org/standards/id-keys/gln)/7601002331470

**name**: SanLab



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "1Org-Labor",
  "identifier" : [
    {
      "system" : "urn:oid:2.51.1.3",
      "value" : "7601002331470"
    }
  ],
  "name" : "SanLab"
}

```
