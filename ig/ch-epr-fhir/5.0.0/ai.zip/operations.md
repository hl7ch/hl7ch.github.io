# Operations - CH EPR FHIR (R4) v5.0.0

* [**Table of Contents**](toc.md)
* **Operations**

## Operations

### Mobile Patient Identifier Cross-reference Query [ITI-83]

* Find patient matches using IHE-PIXm Profile

