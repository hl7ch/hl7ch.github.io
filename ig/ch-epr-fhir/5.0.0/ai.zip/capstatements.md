# Capability Statements - CH EPR FHIR (R4) v5.0.0

* [**Table of Contents**](toc.md)
* **Capability Statements**

## Capability Statements

### EPR App (Client)

* CapabilityStatement for EPR App (client).

### EPR API (Server)

* CapabilityStatement for EPR API (server).

