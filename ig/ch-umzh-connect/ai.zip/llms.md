# ch.fhir.ig.ch-umzh-connect#1.0.0-ballot: CH UMZH Connect IG (R4)

## Pages

* [Home](index.md)
* [Fulfiller - TTL Representation](ActorDefinition-ch-umzh-connect-fulfiller.ttl.md)
* [Interactions](guidance-interactions.md)
* [Referral - Orthopedic Surgery](usecase-referral-orthopedic.md)
* [Placer - JSON Representation](ActorDefinition-ch-umzh-connect-placer.json.md)
* [Placer](ActorDefinition-ch-umzh-connect-placer.md)
* [Placer - XML Representation](ActorDefinition-ch-umzh-connect-placer.xml.md)
* [Fulfiller](ActorDefinition-ch-umzh-connect-fulfiller.md)
* [Workflow oriented API design](core-concept-workflow-api.md)
* [Artifacts Summary](artifacts.md)
* [Changelog](changelog.md)
* [Security Implementation](security-implementation.md)
* [Placer - Testing](ActorDefinition-ch-umzh-connect-placer-testing.md)
* [Reference Architecture](guidance-reference-architecture.md)
* [Workflow States](workflow-states.md)
* [Fulfiller - XML Representation](ActorDefinition-ch-umzh-connect-fulfiller.xml.md)
* [Fulfiller - Testing](ActorDefinition-ch-umzh-connect-fulfiller-testing.md)
* [](ActorDefinition-ch-umzh-connect-placer.change.history.md)
* [Registry](core-concept-registry.md)
* [Fulfiller - JSON Representation](ActorDefinition-ch-umzh-connect-fulfiller.json.md)
* [Referral - Sarcoma Tumor Board](usecase-referral-sarcoma-tumorboard.md)
* [Placer - TTL Representation](ActorDefinition-ch-umzh-connect-placer.ttl.md)
* [Security](security.md)
* [](ActorDefinition-ch-umzh-connect-fulfiller.change.history.md)

## Resources

### ValueSets

* [CH UMZH Connect ServiceRequest Category](ValueSet-ch-umzh-connect-servicerequest-category.md)

### Resource Profiles

* [CH UMZH Connect Coordination Task](StructureDefinition-ch-umzh-connect-coordinationtask.md)
* [CH UMZH Connect ServiceRequest](StructureDefinition-ch-umzh-connect-servicerequest.md)

### Basics

* [ch-umzh-connect-fulfiller](Basic-ch-umzh-connect-fulfiller.md)
* [ch-umzh-connect-placer](Basic-ch-umzh-connect-placer.md)

### CapabilityStatements

* [UMZHconnectRestServer](CapabilityStatement-ChUmzhConnectCapabilityStatement.md)

### ImplementationGuides

* [CH UMZH Connect IG (R4)](index.md)

### SearchParameters

* [ch-umzhconnectig-servicerequest-insurance](SearchParameter-ch-umzhconnectig-servicerequest-insurance.md)
* [ch-umzhconnectig-servicerequest-reasonreference](SearchParameter-ch-umzhconnectig-servicerequest-reasonreference.md)
* [ch-umzhconnectig-servicerequest-supportinginfo](SearchParameter-ch-umzhconnectig-servicerequest-supportinginfo.md)
* [ch-umzhconnectig-task-inputreference](SearchParameter-ch-umzhconnectig-task-inputreference.md)
* [ch-umzhconnectig-task-outputcanonical](SearchParameter-ch-umzhconnectig-task-outputcanonical.md)
* [ch-umzhconnectig-task-outputreference](SearchParameter-ch-umzhconnectig-task-outputreference.md)

### Examples

* [AllergyGado (AllergyIntolerance)](AllergyIntolerance-AllergyGado.md)
* [AppointmentOrthopedicConsultation (Appointment)](Appointment-AppointmentOrthopedicConsultation.md)
* [HeartFailureHFrEF (Condition)](Condition-HeartFailureHFrEF.md)
* [SarcomaKnee (Condition)](Condition-SarcomaKnee.md)
* [SuspectedACLRupture (Condition)](Condition-SuspectedACLRupture.md)
* [CoverageMeier (Coverage)](Coverage-CoverageMeier.md)
* [DocCardiologyAttachment (DocumentReference)](DocumentReference-DocCardiologyAttachment.md)
* [DocDischargeReportOrthopedics (DocumentReference)](DocumentReference-DocDischargeReportOrthopedics.md)
* [Fulfiller FHIR API (Endpoint)](Endpoint-EndpointFulfiller.md)
* [Placer FHIR API (Endpoint)](Endpoint-EndpointPlacer.md)
* [Orthopedic Surgery (HealthcareService)](HealthcareService-HealthcareServiceOrthopedicsFulfiller.md)
* [Sarcoma Tumor Board (HealthcareService)](HealthcareService-HealthcareServiceTumorboardFulfiller.md)
* [ImagingCT (ImagingStudy)](ImagingStudy-ImagingCT.md)
* [ImagingPET (ImagingStudy)](ImagingStudy-ImagingPET.md)
* [MedAspirin (Medication)](Medication-MedAspirin.md)
* [MedicationAspirin (MedicationStatement)](MedicationStatement-MedicationAspirin.md)
* [MedicationConcor (MedicationStatement)](MedicationStatement-MedicationConcor.md)
* [MedicationEntresto (MedicationStatement)](MedicationStatement-MedicationEntresto.md)
* [Fulfiller (Organization)](Organization-Fulfiller.md)
* [Placer (Organization)](Organization-Placer.md)
* [PetraMeier (Patient)](Patient-PetraMeier.md)
* [HansMuster (Practitioner)](Practitioner-HansMuster.md)
* [HansMusterRole (PractitionerRole)](PractitionerRole-HansMusterRole.md)
* [Smoking Status Inquiry (Questionnaire)](Questionnaire-QuestionnaireSmokingStatus.md)
* [QuestionnaireResponseSmokingStatus (QuestionnaireResponse)](QuestionnaireResponse-QuestionnaireResponseSmokingStatus.md)
* [ReferralOrthopedicSurgery (ServiceRequest)](ServiceRequest-ReferralOrthopedicSurgery.md)
* [ReferralTumorboard (ServiceRequest)](ServiceRequest-ReferralTumorboard.md)
* [TaskReferralOrthopedicSurgery (Task)](Task-TaskReferralOrthopedicSurgery.md)
* [TaskReferralOrthopedicSurgeryCompleted (Task)](Task-TaskReferralOrthopedicSurgeryCompleted.md)
* [TaskReferralOrthopedicSurgeryUpdated (Task)](Task-TaskReferralOrthopedicSurgeryUpdated.md)
