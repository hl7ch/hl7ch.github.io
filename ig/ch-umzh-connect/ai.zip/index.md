# Home - CH UMZH Connect IG (R4) v1.0.0-ballot

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.ch/ig/ch-umzh-connect/ImplementationGuide/ch.fhir.ig.ch-umzh-connect | *Version*:1.0.0-ballot |
| Active as of 2026-06-12 | *Computable Name*:CHUMZHConnect |
| **Copyright/Legal**: CC0-1.0 | |

### Introduction

**CH UMZH Connect** is a FHIR Implementation Guide for the University Medicine Zurich (UMZH) focusing on referral and external service order processes.

UMZH-Connect is a collaborative initiative to improve digital interoperability between healthcare providers in the Zurich ecosystem—initially focusing on university hospitals and close partners. Today, key processes such as referrals, transfers, and external orders (e.g., lab or radiology requests) still require manual re-entry of clinical and administrative information across systems, causing delays, inconsistencies, and avoidable workload. The project targets these friction points by enabling “push-button” and fully automated data exchange across participants, driven by concrete, high-value use cases that can be implemented quickly and measured in terms of business and clinical benefit.

The intended solution is an API framework and shared implementation approach that allows providers to act as API producers and consumers using standardized, interoperable interfaces (e.g. FHIR and REST). A central element is a clearly defined “data contract” (FHIR implementation guidance) that supports both read and write operations for agreed workflows — starting with core referral/order content such as reason for request, diagnoses, history, medication, procedures, and administrative data, while remaining extensible for additional use cases and participants over time. The “data contract” is based on the international Clinical Order Workflow (COW) and customized for swiss-specifics in this UMZH-Connect FHIR IG.

Initial Use Cases focus on the following resource types which are based on the profiles from [CH Core](https://fhir.ch/ig/ch-core/index.html) and [CH eTOC](https://fhir.ch/ig/ch-etoc/index.html):

* Order, service request and clinical question
* Administrative data (personal details, insurance, etc.)
* Diagnoses
* Medication
* Allergies
* Reports (documents)
* ImagingStudies

These content areas are intended to be expandable in the future.

This implementation guide is under informative ballot by [HL7 Switzerland](https://www.hl7.ch/) from August 4th, 2026 until September 30th, 2026. Please add your feedback via the 'Propose a change'-link in the footer.

[Changelog](changelog.md) with significant changes, open and closed issues.

**Download**: You can download this implementation guide in the [NPM package](https://confluence.hl7.org/display/FHIR/NPM+Package+Specification) format from [here](package.tgz).

### Workflow orientation

This implementation guide is based on the core principles of [Clinical Order Workflow IG](https://hl7.org/fhir/uv/cow/2025May/) with a focus on the [**Task at Fulfiller**](https://hl7.org/fhir/uv/cow/2025May/fulfiller-determination.html#task-at-fulfiller) principle where the Placer creates a ServiceRequest and POSTs a Task to the Fulfiller's FHIR server, with the ServiceRequest referenced in `Task.basedOn`. The Fulfiller manages the Task lifecycle and updates the Placer about progress and outcomes.

The core concepts and principles are depicted in detail here:

[Workflow oriented API design](core-concept-workflow-api.md)

* **Resource Querying**: The Placer SHALL support the `_include` parameter for querying the ServiceRequest along with all referenced resources.

### Security

This IG specifies OAuth 2.0 and OpenID Connect–based architectures for securing APIs by the use of Security profiles such as SMART on FHIR define standards and OpenID Foundation’s FAPI 2.0, which sharpens security awareness by enforcing measures to mitigate particular risk scenarios in machine-to-machine communication.

A particular focus is set on context-centric authorization, driven by the fact that authorization should be enforced based on the context of data consumption — in our case providing limited access in the context of a specific workflow object (ServiceRequest or Task).

We show approaches on how to harden eco-system exposed API's and how to enforce fine-grained authorization for our use-cases.

The detailed security concept can be found here:

[Security concept](security.md)

### Use cases

* [Orthopedic referral](usecase-referral-orthopedic.md)
* [Sarcome tumorboard referral](usecase-referral-sarcoma-tumorboard.md)

### IP Statements

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* CC0-1.0

* [Condition Category](http://fhir.ch/ig/ch-term/3.4.0/CodeSystem-ch-etoc-conditioncategory.html): [Condition/HeartFailureHFrEF](Condition-HeartFailureHFrEF.md), [Condition/SarcomaKnee](Condition-SarcomaKnee.md) and [Condition/SuspectedACLRupture](Condition-SuspectedACLRupture.md)
* [Coverage Identifier Type](http://fhir.ch/ig/ch-orf/3.0.2/CodeSystem-ch-orf-cs-coverageidentifiertype.html): [Coverage/CoverageMeier](Coverage-CoverageMeier.md)
* [EDQM - Standard Terms](http://fhir.ch/ig/ch-term/3.4.0/CodeSystem-edqm-standardterms.html): [Medication/MedAspirin](Medication-MedAspirin.md), [MedicationStatement/MedicationAspirin](MedicationStatement-MedicationAspirin.md), [MedicationStatement/MedicationConcor](MedicationStatement-MedicationConcor.md) and [MedicationStatement/MedicationEntresto](MedicationStatement-MedicationEntresto.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [CHUMZHConnect](index.md), [ChUmzhConnectCoordinationTask](StructureDefinition-ch-umzh-connect-coordinationtask.md)... Show 12 more, [ChUmzhConnectServiceRequest](StructureDefinition-ch-umzh-connect-servicerequest.md), [ChUmzhConnectServiceRequestCategoryVS](ValueSet-ch-umzh-connect-servicerequest-category.md), [Questionnaire/QuestionnaireSmokingStatus](Questionnaire-QuestionnaireSmokingStatus.md), [UMZHConnectFulfiller](ActorDefinition-ch-umzh-connect-fulfiller.md), [UMZHConnectPlacer](ActorDefinition-ch-umzh-connect-placer.md), [UMZHconnectRestServer](CapabilityStatement-ChUmzhConnectCapabilityStatement.md), [ch-umzhconnectig-servicerequest-insurance](SearchParameter-ch-umzhconnectig-servicerequest-insurance.md), [ch-umzhconnectig-servicerequest-reasonreference](SearchParameter-ch-umzhconnectig-servicerequest-reasonreference.md), [ch-umzhconnectig-servicerequest-supportinginfo](SearchParameter-ch-umzhconnectig-servicerequest-supportinginfo.md), [ch-umzhconnectig-task-inputreference](SearchParameter-ch-umzhconnectig-task-inputreference.md), [ch-umzhconnectig-task-outputcanonical](SearchParameter-ch-umzhconnectig-task-outputcanonical.md) and [ch-umzhconnectig-task-outputreference](SearchParameter-ch-umzhconnectig-task-outputreference.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://hl7.org/fhir/uv/xver-r5.r4/0.1.0/CodeSystem-v3-ucum.html): [MedicationStatement/MedicationAspirin](MedicationStatement-MedicationAspirin.md), [MedicationStatement/MedicationConcor](MedicationStatement-MedicationConcor.md) and [MedicationStatement/MedicationEntresto](MedicationStatement-MedicationEntresto.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [DICOM Controlled Terminology Definitions](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html): [ImagingStudy/ImagingCT](ImagingStudy-ImagingCT.md) and [ImagingStudy/ImagingPET](ImagingStudy-ImagingPET.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [ChUmzhConnectServiceRequest](StructureDefinition-ch-umzh-connect-servicerequest.md), [ChUmzhConnectServiceRequestCategoryVS](ValueSet-ch-umzh-connect-servicerequest-category.md)... Show 12 more, [DocumentReference/DocDischargeReportOrthopedics](DocumentReference-DocDischargeReportOrthopedics.md), [Medication/MedAspirin](Medication-MedAspirin.md), [MedicationStatement/MedicationConcor](MedicationStatement-MedicationConcor.md), [MedicationStatement/MedicationEntresto](MedicationStatement-MedicationEntresto.md), [Orthopedic Surgery](HealthcareService-HealthcareServiceOrthopedicsFulfiller.md), [Questionnaire/QuestionnaireSmokingStatus](Questionnaire-QuestionnaireSmokingStatus.md), [QuestionnaireResponse/QuestionnaireResponseSmokingStatus](QuestionnaireResponse-QuestionnaireResponseSmokingStatus.md), [Sarcoma Tumor Board](HealthcareService-HealthcareServiceTumorboardFulfiller.md), [ServiceRequest/ReferralOrthopedicSurgery](ServiceRequest-ReferralOrthopedicSurgery.md), [ServiceRequest/ReferralTumorboard](ServiceRequest-ReferralTumorboard.md), [Task/TaskReferralOrthopedicSurgeryCompleted](Task-TaskReferralOrthopedicSurgeryCompleted.md) and [Task/TaskReferralOrthopedicSurgeryUpdated](Task-TaskReferralOrthopedicSurgeryUpdated.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.2.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/AllergyGado](AllergyIntolerance-AllergyGado.md)
* [Endpoint Connection Type](http://terminology.hl7.org/7.2.0/CodeSystem-endpoint-connection-type.html): [Fulfiller FHIR API](Endpoint-EndpointFulfiller.md) and [Placer FHIR API](Endpoint-EndpointPlacer.md)
* [Endpoint Payload Type](http://terminology.hl7.org/7.2.0/CodeSystem-endpoint-payload-type.html): [Fulfiller FHIR API](Endpoint-EndpointFulfiller.md) and [Placer FHIR API](Endpoint-EndpointPlacer.md)
* [identifierType](http://terminology.hl7.org/7.2.0/CodeSystem-v2-0203.html): [ChUmzhConnectServiceRequest](StructureDefinition-ch-umzh-connect-servicerequest.md), [Patient/PetraMeier](Patient-PetraMeier.md), [ServiceRequest/ReferralOrthopedicSurgery](ServiceRequest-ReferralOrthopedicSurgery.md) and [ServiceRequest/ReferralTumorboard](ServiceRequest-ReferralTumorboard.md)
* [ParticipationType](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ParticipationType.html): [Appointment/AppointmentOrthopedicConsultation](Appointment-AppointmentOrthopedicConsultation.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ch.fhir.ig.ch-umzh-connect.r4)](package.r4.tgz) and [R4B (ch.fhir.ig.ch-umzh-connect.r4b)](package.r4b.tgz) are available.

### Dependency Table














### Globals Table

*There are no Global profiles defined*

