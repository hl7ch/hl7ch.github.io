# Terminology - CH EPREG (R4) v1.0.0

* [**Table of Contents**](toc.md)
* **Terminology**

## Terminology

### Value Sets

**Please note that there is a section for[mapping the value sets from the concept paper](mapping-concept-valuesets.md).**

* [CH EPREG VS: Blood Group](ValueSet-blood-group.md)

* [CH EPREG VS: Fetal Position](ValueSet-fetal-position.md)

* [CH EPREG VS: Fetal RhD Antigen](ValueSet-fetal-rhd-antigen.md)

* [CH EPREG VS: Parent](ValueSet-parent.md)

