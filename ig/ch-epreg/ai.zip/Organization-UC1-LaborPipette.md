# UC 1: Labor Pipette - CH EPREG (R4) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UC 1: Labor Pipette**

## Example Organization: UC 1: Labor Pipette

Language: de-CH

**name**: Labor Pipette



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "UC1-LaborPipette",
  "language" : "de-CH",
  "name" : "Labor Pipette"
}

```
