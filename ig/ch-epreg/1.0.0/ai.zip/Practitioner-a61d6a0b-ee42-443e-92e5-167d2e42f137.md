# UC 2: Tanja Allesgut - CH EPREG (R4) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UC 2: Tanja Allesgut**

## Example Practitioner: UC 2: Tanja Allesgut

Language: de-CH

**identifier**: [GLN](https://www.gs1.org/standards/id-keys/gln)/7601002322553

**name**: Tanja Allesgut 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "a61d6a0b-ee42-443e-92e5-167d2e42f137",
  "language" : "de-CH",
  "identifier" : [
    {
      "system" : "urn:oid:2.51.1.3",
      "value" : "7601002322553"
    }
  ],
  "name" : [
    {
      "family" : "Allesgut",
      "given" : ["Tanja"],
      "prefix" : ["Dr. med."]
    }
  ]
}

```
